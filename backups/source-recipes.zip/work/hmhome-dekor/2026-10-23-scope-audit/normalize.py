import json
import re
from pathlib import Path
from datetime import datetime, timezone

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
SOURCE = ROOT / 'sites/zarahome-vazo-kutuphanesi-final-378/ui/hmhome-sources.json'
navigation = json.loads(SOURCE.read_text())['categories']
nav_by_id = {c['id']: c for c in navigation}

# Explicitly selected captures. Superseded captures and the rug recommendation
# carousel are retained as evidence but are never imported as category products.
groups = {
 'storage_baskets': ['storage_baskets'],
 'storage_boxes': ['storage_boxes'],
 'cushions': ['cushions-page1-final', 'cushions-page2', 'cushions-page3'],
 'wall_decor': ['wall_decor'],
 'laundry_baskets': ['laundry_baskets'],
 'jars': ['jars'],
 'wall_hooks_storage': ['wall_hooks_storage'],
 'seat_cushions': ['seat_cushions'],
 'curtains': [f'curtains-page{i}' for i in range(1,5)],
 'rugs': ['rugs-page1', 'rugs-page2-final'],
 'throws': ['throws-page1'],
 'scented_candles': ['scented_candles-page1'],
 'reed_diffusers': ['reed_diffusers'],
 'planters': ['planters'],
 'serving_bowls_plates': ['serving_bowls_plates-page1'],
 'storage': ['storage-page1', 'storage-page2'],
 'decorations': ['decorations-page1-final']+[f'decorations-page{i}' for i in range(2,10)],
 'textiles': [f'textiles-page{i}' for i in range(1,18)],
}
labels = {
 'storage_baskets': ('Düzenleyici sepetler','duzenleyici-sepetler'),
 'storage_boxes': ('Saklama kutuları','saklama-kutulari'),
 'cushions': ('Kırlentler','kirlentler'),
 'wall_decor': ('Duvar dekorasyonu','duvar-dekorasyonu'),
 'laundry_baskets': ('Çamaşır sepetleri','camasir-sepetleri'),
 'jars': ('Kavanozlar','kavanozlar'),
 'wall_hooks_storage': ('Duvar askıları','duvar-askilari'),
 'seat_cushions': ('Minderler','minderler'),
 'curtains': ('Perdeler','perdeler'),
 'rugs': ('Halılar','halilar'),
 'throws': ('Battaniye ve örtüler','battaniyeler'),
 'scented_candles': ('Kokulu mumlar','kokulu-mumlar'),
 'reed_diffusers': ('Koku difüzörleri','koku-difuzorleri'),
 'planters': ('Saksılar','saksilar'),
 'serving_bowls_plates': ('Servis tabak ve kaseleri','servis-tabak-kaseleri'),
 'storage': ('Saklama ürünleri','saklama'),
 'decorations': ('Ev dekorasyonu','ev-dekorasyonu'),
 'textiles': ('Ev tekstili','ev-tekstili'),
}
records = {}
category_audit = []

for category_id, capture_names in groups.items():
    category = nav_by_id[category_id]
    label, slug = labels[category_id]
    category_skus = set()
    pages = []
    for capture_name in capture_names:
        file = HERE / (capture_name+'-observed.json')
        d = json.loads(file.read_text())
        counter = re.search(r'(\d+) Ürünler', d['visible_text'])
        page_skus = set()
        page_records = {}
        for raw in d['products']:
            match = re.search(r'/productpage\.(\d{10})\.html',raw['url'])
            if not match:
                raise ValueError(f'Invalid product URL {raw["url"]}')
            sku = match.group(1)
            page_skus.add(sku)
            page_records.setdefault(sku,[]).append(raw)
        for sku, raw_list in page_records.items():
            category_skus.add(sku)
            name_candidates = [r['label'] for r in raw_list if r.get('label')]
            all_images = [i for r in raw_list for i in r.get('images',[])]
            name = name_candidates[-1] if name_candidates else next((i.get('alt') for i in all_images if i.get('alt')),None)
            if not name:
                raise ValueError(f'No name for {sku}')
            images = []
            for i in all_images:
                candidates=[]
                for source in i.get('srcset','').split(','):
                    parts=source.strip().split()
                    if len(parts)==2 and parts[1].endswith('w'):
                        try: candidates.append((int(parts[1][:-1]),parts[0]))
                        except ValueError: pass
                url=max(candidates)[1] if candidates else i.get('url')
                if url and url.startswith('https://image.hm.com/'):
                    image={'url':url,'thumbnail_url':i.get('url') or url,'alt':i.get('alt') or name}
                    if not any(x['url']==url for x in images): images.append(image)
            r=records.setdefault(sku,{
                'id':'hm-source-'+sku,'sku':sku,'name':name,'brand':'H&M Home',
                'category':label,'category_id':category_id,'category_slug':slug,
                'url':f'https://www2.hm.com/tr_tr/productpage.{sku}.html',
                'source_url':f'https://www2.hm.com/tr_tr/productpage.{sku}.html',
                'reference_images':[], 'model_status':'pending_research',
                'ready_model_variants':0,
                'status_note':'Orijinal fotoğraflar kaydedildi; ölçü araştırması ve modelleme bekliyor.',
                'dimensions':None, 'source_categories':[], 'source_provenance':[],
            })
            for i in images:
                if not any(x['url']==i['url'] for x in r['reference_images']):r['reference_images'].append(i)
            membership={'id':category_id,'slug':slug,'label':label,'url':category['url']}
            if membership not in r['source_categories']:r['source_categories'].append(membership)
            provenance={'method':'live_browser_dom','observed_date':d['observed_date'],
                'category_id':category_id,'page_url':d['url'],'evidence_file':str(file),
                'scope':'product_grid_only' if d.get('grid_root_selector') else 'paired_product_card_links',
                'category_counter':int(counter.group(1)) if counter else None}
            if provenance not in r['source_provenance']:r['source_provenance'].append(provenance)
        pages.append({'url':d['url'],'unique_skus':len(page_skus),
            'counter':int(counter.group(1)) if counter else None,
            'evidence_file':str(file),'pagination':d['pagination']})
    totals={p['counter'] for p in pages}
    complete = len(totals)==1 and len(category_skus)==next(iter(totals))
    category_audit.append({'id':category_id,'slug':slug,'label':label,'source_url':category['url'],
        'status':'live_grid_complete' if complete else 'all_pages_observed_counter_mismatch',
        'observed_source_cards':len(category_skus),
        'official_counter':next(iter(totals)) if len(totals)==1 else None,
        'complete_source_grid':complete,'scan_complete':complete,'models_created':0,'pages':pages})

for category_id in ['mirrors','frames','lighting','furniture']:
    file=HERE/(category_id+'-observed.json')
    d=json.loads(file.read_text())
    category_audit.append({'id':category_id,
        'slug':{'mirrors':'aynalar','frames':'cerceveler','lighting':'aydinlatma','furniture':'mobilyalar'}[category_id],
        'label':nav_by_id[category_id]['official_navigation_label'],
        'source_url':nav_by_id[category_id]['url'],
        'status':'no_product_grid_or_counter_exposed',
        'observed_source_cards':None,'official_counter':None,
        'complete_source_grid':False,'scan_complete':False,
        'note':'Resmî sayfa açıldı fakat ürün ızgarası/sayacı görünmedi; sıfır ürün veya tamamlandı anlamına gelmez.',
        'evidence_file':str(file),'models_created':0})

original_inventory = json.loads((ROOT/'sites/zarahome-vazo-kutuphanesi-final-378/ui/hmhome-inventory.json').read_text())
existing_skus={str(p.get('sku') or p.get('product_code') or re.search(r'productpage\.(\d+)',p.get('source_url','') or p.get('url','')).group(1)) for p in original_inventory['products']}
all_records=list(records.values())
all_records.sort(key=lambda r:(r['category_id'],r['sku']))
for r in all_records:
    r['already_in_existing_166']=r['sku'] in existing_skus

summary={
    'observed_date':'2026-10-23','recorded_at_utc':datetime.now(timezone.utc).isoformat(),
    'scope':'All 22 navigation sources not previously declared complete; overlapping parent and leaf source grids, not the entire H&M website.',
    'newly_checked_navigation_sources':22,
    'newly_completed_source_grids':sum(c['complete_source_grid'] for c in category_audit),
    'sources_without_product_grid_or_counter':4,
    'observed_unique_skus':len(all_records),
    'new_unique_skus_outside_existing_166':sum(not r['already_in_existing_166'] for r in all_records),
    'existing_166_overlap':sum(r['already_in_existing_166'] for r in all_records),
    'without_reference_image':sum(not r['reference_images'] for r in all_records),
    'model_count_added':0,'categories':category_audit,
    'notes':[
        'Source categories overlap; category counts cannot be summed as unique products.',
        'Products from parent textile grids include bedding, table linens and other textile subtypes; exact source membership is preserved instead of misclassifying them as cushions.',
        'Cushion first page counter alternated86and85; final image-hydrated first page says86 while pages2and3say85. All3pages were observed and yield85uniqueSKUs. The source remains counter-mismatch rather than complete.',
        'Superseded rug page2 capture contained6recommendation products; final capture restricts to #products-listing-section and contains3official category cards.',
        'Official web-reader cache totals31baskets/10boxes/91cushions/3wall are stale and are not used as live counts.',
        'Initial9decor parent pages yielded310uniqueSKUs against311counter. Reobserving all9pages while hydrating images recovered311uniqueSKUs; final9page set agrees on311.',
        'Storage parent page1shows46while page2shows49. Final2page set yields47uniqueSKUs due changing/overlapping ordering. The source remains counter-mismatch rather than complete.',
        'No dimensions inferred, no models generated, no canonical app/model files modified.',
    ],
}
(HERE/'discovered-products.json').write_text(json.dumps(all_records,ensure_ascii=False,indent=2)+'\n')
(HERE/'scope-audit.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k not in ['categories','notes']},ensure_ascii=False,indent=2))
