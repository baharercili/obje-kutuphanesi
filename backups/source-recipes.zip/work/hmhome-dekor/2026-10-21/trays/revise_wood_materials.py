"""Own-photo wood material donors; immutable masters, native crop pixels and UVs."""
from pathlib import Path
import sys,json,hashlib,copy,shutil
import numpy as np
from PIL import Image,ImageFilter,ImageOps
sys.dont_write_bytecode=True
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R.parent/'candleholders'));import build_candleholders as C
V=C.V;sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
D={'1361866001':dict(source='1361866001-0b93123ab579.jpg',bed=(630,650,1510,2590),frame=(520,700,575,2500),rotate=True), '1361867001':dict(source='1361867001-f546e494a96b.jpg',bed=(430,985,1710,2260),frame=(450,877,1680,922),rotate=False)}
revision=R/'revision-02';revision.mkdir(exist_ok=True);crops=revision/'material-crops';crops.mkdir(exist_ok=True)
base=json.loads((R/'manifest.json').read_text());new=[];records=[]
def material(pid,key,spec,out):
 master=R/'originals'/spec['source'];im=Image.open(master);box=spec[key];crop=im.crop(box).convert('RGB');raw=crops/f'{pid}-{key}-master-pixel-crop.png';crop.save(raw)
 assert np.array_equal(np.asarray(crop),np.asarray(im.convert('RGB'))[box[1]:box[3],box[0]:box[2]])
 if spec['rotate']:crop=crop.transpose(Image.Transpose.ROTATE_90)
 w,h=crop.size;assert max(w,h)<=2048
 # Native donor pixels are never resized. Mirror padding supplies unused atlas space.
 atlas=Image.new('RGB',(2048,2048))
 for y in range(0,2048,h):
  for x in range(0,2048,w):
   p=crop
   if (x//w)%2:p=ImageOps.mirror(p)
   if (y//h)%2:p=ImageOps.flip(p)
   atlas.paste(p,(x,y))
 assert np.array_equal(np.asarray(atlas)[:h,:w],np.asarray(crop))
 a=np.asarray(atlas);lum=np.asarray(atlas.convert('L'),dtype=float);blur=np.asarray(atlas.convert('L').filter(ImageFilter.GaussianBlur(2)),dtype=float);height=(lum-blur)*.00085;dy,dx=np.gradient(height);normal=np.stack([-dx,-dy,np.ones_like(dx)],2);normal/=np.linalg.norm(normal,axis=2,keepdims=True);orm=np.zeros((2048,2048,3),np.uint8);orm[:,:,0]=255;orm[:,:,1]=102
 names={slot:f'{pid}-{key}-own-photo-{slot}-2k.png'for slot in ['albedo','normal','orm']}
 atlas.save(out/names['albedo'],optimize=True);Image.fromarray(np.clip((normal+1)*127.5,0,255).astype(np.uint8),'RGB').save(out/names['normal'],optimize=True);Image.fromarray(orm,'RGB').save(out/names['orm'],optimize=True)
 rec=dict(sku=pid,material=key,master_path=str(master),master_sha256=sha(master),master_pixels=list(im.size),master_format=im.format,crop_box_pixels=list(box),raw_crop_path=str(raw),raw_crop_pixels=list(Image.open(raw).size),raw_crop_exact_pixel_diff_max=0,orthogonal_rotation_degrees=90 if spec['rotate']else 0,geometric_resampling_count=0,native_donor_pixels=[w,h],texture_canvas_pixels=[2048,2048],atlas_method='Native unscaled donor in top-left; alternating exact mirror/flip padding. Mesh UVs use the donor once per bed/rail, without padding repeats.',no_upscaling=True,colour_operations='None; exact source RGB donor pixels retained.',material_region_only=True,excluded='Background, product edges, frame cast shadows and reflected highlights excluded from donor rectangles.',normal_method='Only two-pixel local luminance high-pass; broad plank tone and lighting are not embossed.',untouched_original_verified=True,donor_atlas_diff_max=0,albedo_sha256=sha(out/names['albedo']))
 records.append(rec)
 return dict(baseColorFactor=[1,1,1,1],baseColorTexture=names['albedo'],normalTexture=names['normal'],metallicRoughnessTexture=names['orm'],normalScale=.22,metallic=1,roughness=1,doubleSided=False,alphaMode='OPAQUE',clearcoat=.12,clearcoatRoughness=.32,extras=dict(native_resolution=2048,intrinsic_material=True,photo_pixels_baked=True,own_photo_material_crop=True,no_scene_background_or_whole_product_projection=True,baked_reflections=False,official_wood_species='Arjuna',effective_source_detail_pixels=[w,h],upscaled=False,edit_stack=str(crops/'edit-stack.json'))),(w,h)
for original in base:
 pid=original['sku']
 if pid not in D:new.append(original);continue
 e=copy.deepcopy(original);out=revision/'models'/e['id'];out.mkdir(parents=True,exist_ok=True);model=json.loads(Path(e['model_path']).read_text());mats={};donors={}
 for key in ['bed','frame']:mats[key],donors[key]=material(pid,key,D[pid],out)
 model['materials']=mats
 w,h,d=np.array(e['dimensions_cm'])/100
 for mesh in model['meshes']:
  key='bed'if 'inset-wooden-floor'in mesh['name']else'frame';mesh['material']=key;pos=np.array(mesh['positions']).reshape(-1,3);faces=np.array(mesh['indices']).reshape(-1,3)if'indices'in mesh else None
  # Finalized flat parts already have independent vertices at seams.
  normal=np.array(mesh['normals']).reshape(-1,3);uv=[];dw,dh=donors[key];cross='side-1'in mesh['name']or'side-3'in mesh['name'];lo=pos.min(0);hi=pos.max(0)
  for (x,y,z),n in zip(pos,normal):
   axis=int(np.argmax(abs(n)))
   if key=='bed'and axis==1:u=(x-lo[0])/(hi[0]-lo[0]);v=(z-lo[2])/(hi[2]-lo[2])
   elif axis==1:
    if cross:u=(z-lo[2])/(hi[2]-lo[2]);v=(x-lo[0])/(hi[0]-lo[0])
    else:u=(x-lo[0])/(hi[0]-lo[0]);v=(z-lo[2])/(hi[2]-lo[2])
   elif axis==0:u=(z-lo[2])/max(hi[2]-lo[2],1e-9);v=(y-lo[1])/max(hi[1]-lo[1],1e-9)
   else:u=(x-lo[0])/max(hi[0]-lo[0],1e-9);v=(y-lo[1])/max(hi[1]-lo[1],1e-9)
   uv.append((u*(dw-2)/2048+1/2048,v*(dh-2)/2048+1/2048))
  mesh['uvs']=np.array(uv).ravel().tolist()
 repairs=V.M.ensure_uv_faces(model['meshes'])+V.ensure_float32_uv(model['meshes'])
 model['metadata'].update(model_revision='own-photo-arjuna-v2',photo_pixels_baked=True,intrinsic_texture_derived_from_own_material_crop=True,no_scene_background_or_whole_product_projection=True,material_edit_stack=str(crops/'edit-stack.json'),predecessor_sha256=original['sha256'])
 model['metadata']['geometry_limitations']=['Local rim, floor, feet and joinery dimensions are photo-interpreted; physical outer dimensions follow the official table.','Arjuna bed and frame grain use separate unchanged RGB donors cropped from this exact product. Per-rail grain placement and unobserved side faces are interpreted; photographed bed lighting cannot be perfectly separated from intrinsic wood colour.','Marble is not involved in this material revision.']
 path=out/'model.json';dump(path,model);report=V.export_assets(path,out,e['id']);glb=out/(e['id']+'.glb');doc,binary=V.read_glb(glb);doc['samplers']=[dict(magFilter=9729,minFilter=9987,wrapS=10497,wrapT=10497)]
 for t in doc.get('textures',[]):t['sampler']=0
 V.write_glb(glb,doc,V.M.embed_tangents(doc,binary));e.update(asset_dir=str(out),model_path=str(path),glb_path=str(glb),sha256=sha(glb),bytes=glb.stat().st_size,geometry_validation=str(out/'geometry-validation.json'),material_validation=str(out/'material-validation.json'),model_revision='own-photo-arjuna-v2',material_edit_stack=str(crops/'edit-stack.json'))
 oldgeo=json.loads(Path(original['geometry_validation']).read_text());oldgeo.update(uv_triangles_repaired=repairs,material_only_revision=True,predecessor_sha256=original['sha256']);dump(out/'geometry-validation.json',oldgeo);dump(out/'material-validation.json',dict(valid=True,native_resolution=2048,own_photo_crops=True,source_masters_unchanged=True,effective_source_detail_pixels=donors,maps=[dict(path=str(out/m[k]),sha256=sha(out/m[k]))for m in mats.values()for k in['baseColorTexture','normalTexture','metallicRoughnessTexture']]))
 report['deliverable_sha256']['glb']=e['sha256'];report['glb_bytes']=e['bytes'];dump(report['files']['validation'],report);dump(out/'topology-validation.json',V.M.AQ.check(e));new.append(e);assert sha(original['glb_path'])==original['sha256'];print('WOOD SOURCE REVISION',pid,e['sha256'],flush=True)
dump(crops/'edit-stack.json',dict(originals_unchanged=True,source_photo_material_region_only=True,records=records));dump(revision/'manifest.json',new);dump(revision/'wood-only-manifest.json',[e for e in new if e['sku']in D])
