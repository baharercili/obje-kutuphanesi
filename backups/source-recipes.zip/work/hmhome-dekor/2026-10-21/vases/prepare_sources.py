from pathlib import Path
import json,re,hashlib,urllib.request,io
from PIL import Image
R=Path(__file__).resolve().parent;P=R.parent
IDS=['1353289002','1331957002','1356207001','1339079001','1351806001']
records=[];selected=[]
for pid in IDS:
 p=P/(pid+'-observed.json');q=json.loads(p.read_text());q['sku']=pid;q['brand']='H&M Home';q['source_observation_file']=str(p);q['source_observation_sha256']=hashlib.sha256(p.read_bytes()).hexdigest();records.append(q);photos={}
 for im in q['photos']:
  choices=[]
  for entry in(im.get('srcset')or'').split(','):
   fields=entry.strip().split()
   if len(fields)==2 and re.match(r'https://image\.hm\.com/.+\.jpg\?',fields[0]):choices.append((int(fields[1].rstrip('w')),fields[0]))
  if im.get('url','').startswith('https://image.hm.com/')and'.jpg?'in im['url']:choices.append((int(re.search(r'imwidth=(\d+)',im['url']).group(1)),im['url']))
  for size,url in choices:
   base=url.split('?')[0]
   if base not in photos or size>photos[base]['observed_width']:photos[base]=dict(sku=pid,product_url=q['url'],url=url,alt=im['alt'],observed_width=size,srcset_verbatim=im.get('srcset'),source_file=str(p))
 selected+=list(photos.values())
(R/'source-inventory.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n');(R/'selected-official-images.json').write_text(json.dumps(selected,ensure_ascii=False,indent=2)+'\n')
print('sources',len(records),'unique officialJPEGs',len(selected),flush=True)
for q in records:print(q['sku'],q['description'],flush=True)
if __name__=='__main__':
 out=R/'originals';out.mkdir(exist_ok=True);done=[]
 for i,p in enumerate(selected):
  path=out/(p['sku']+'-'+hashlib.sha256(p['url'].encode()).hexdigest()[:12]+'.jpg')
  if not path.exists():
   req=urllib.request.Request(p['url'],headers={'User-Agent':'Mozilla/5.0'});data=urllib.request.urlopen(req,timeout=40).read();Image.open(io.BytesIO(data)).verify();path.write_bytes(data)
  image=Image.open(path);p.update(path=str(path),sha256=hashlib.sha256(path.read_bytes()).hexdigest(),pixels=list(image.size),format=image.format,mode=image.mode,icc_profile_present=bool(image.info.get('icc_profile')),exif_orientation=image.getexif().get(274),original_bytes_unmodified=True);done.append(p);print('original',p['sku'],image.size,path.name,flush=True)
 (R/'original-image-masters.json').write_text(json.dumps(done,ensure_ascii=False,indent=2)+'\n')
