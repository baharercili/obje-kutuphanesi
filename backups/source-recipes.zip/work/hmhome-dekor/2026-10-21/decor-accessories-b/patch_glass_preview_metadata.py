from pathlib import Path
import json,struct,hashlib
R=Path(__file__).resolve().parent
note='Camın rengi, saydamlığı ve ışığı kırma görünümü görüntüleyiciye göre değişebilir; önizleme yaklaşık görünür. GLB’de fiziksel cam geçirgenliği, kırılma indisi ve cidar bilgisi korunur.'
fields=dict(quality_label='Yaklaşık cam görünümü',quality_status='preview_limited',quality_note=note,quality_pending=False)
a=json.loads((R/'manifest.json').read_text());proof=[]
for e in a:
 if e['sku']not in['1299152002','1300259001','1261191001']:continue
 p=Path(e['model_path']);m=json.loads(p.read_text());m['metadata'].update(fields);p.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n')
 p=Path(e['glb_path']);b=p.read_bytes();n=struct.unpack_from('<I',b,12)[0];d=json.loads(b[20:20+n]);tail=b[20+n:];before=json.dumps(d['materials'],sort_keys=True);d['extras']['metadata'].update(fields);j=json.dumps(d,separators=(',',':'),ensure_ascii=False).encode();j+=b' '*(-len(j)%4);p.write_bytes(struct.pack('<4sII',b'glTF',2,20+len(j)+len(tail))+struct.pack('<II',len(j),0x4e4f534a)+j+tail);assert before==json.dumps(d['materials'],sort_keys=True);e.update(fields,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=p.stat().st_size);proof.append(dict(sku=e['sku'],binary_geometry_and_images_unchanged=True,material_extensions_unchanged=True,sha256=e['sha256']))
(R/'manifest.json').write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n');(R/'glass-preview-metadata-validation.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
prior=json.loads((R/'next-family-review-manifest.json').read_text());wanted=[q['sku']for q in prior];current={q['sku']:q for q in a};(R/'next-family-corrected-review-manifest.json').write_text(json.dumps([current[s]for s in wanted],ensure_ascii=False,indent=2)+'\n');(R/'star-corrections-review-manifest.json').write_text(json.dumps([current[s]for s in ['0451338006','1359146001']],ensure_ascii=False,indent=2)+'\n');(R/'last-two-review-manifest.json').write_text(json.dumps([current[s]for s in ['1359291001','1299157015']],ensure_ascii=False,indent=2)+'\n')
(R/'withdrawn-families.json').write_text(json.dumps([dict(family='frozen-family-03',status='withdrawn',reason='Siyah yıldız uç sayısı beş yerine altı olmalıydı; düzeltilmiş04 ailesi ve cam görünüm notları bekleniyor.',manifest_sha256='0f97f6db02a235636920c51c31a2f41e7492a548f28bf25fb57474b3974e665d')],ensure_ascii=False,indent=2)+'\n')
