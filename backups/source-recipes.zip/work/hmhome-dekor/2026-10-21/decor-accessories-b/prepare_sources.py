from pathlib import Path
import json,re,hashlib,urllib.request,io,concurrent.futures,shutil
from PIL import Image
P=Path(__file__).resolve().parent;ROOT=P.parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(name,data):
 f=P/name;tmp=f.with_suffix(f.suffix+'.tmp');tmp.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n');tmp.replace(f)
rows=json.loads((P/'source-category-slice.json').read_text())['products'];selected=[];sources=[];out=P/'originals';out.mkdir(exist_ok=True);captures=P/'source-captures';captures.mkdir(exist_ok=True)
for row in rows:
 sku=row['product_code'];f=ROOT/'pdp-observed'/(sku+'.json');capture=None
 if f.exists():
  digest=sha(f);dst=captures/(sku+'-'+digest[:12]+'.json')
  if not dst.exists():shutil.copyfile(f,dst)
  capture=json.loads(dst.read_text());capture=capture if capture.get('identity_verified')is True else None
  if capture:sources.append(dict(sku=sku,url=row['url'],category_title=row['title'],official_capture=capture,source_evidence_file=str(dst),source_evidence_sha256=digest))
 photos=(capture.get('photos',[])if capture else[])+row.get('images',[]);choices={}
 for im in photos:
  candidates=[]
  for item in(im.get('srcset')or'').split(','):
   s=item.strip().split()
   if len(s)==2 and s[0].startswith('https://image.hm.com/')and'.jpg?'in s[0]:candidates.append((int(s[1].rstrip('w')),s[0]))
  if im.get('url','').startswith('https://image.hm.com/')and'.jpg?'in im['url']:
   m=re.search(r'imwidth=(\d+)',im['url']);candidates.append((int(m.group(1))if m else 0,im['url']))
  for width,url in candidates:
   base=url.split('?')[0]
   if base not in choices or width>choices[base]['observed_width']:choices[base]=dict(sku=sku,product_url=row['url'],url=url,alt=im.get('alt',''),observed_width=width,source_file=str(dst)if capture else str(P/'source-category-slice.json'),source_kind='official_live_pdp_gallery'if capture else'official_category_card')
 selected+=list(choices.values())
for f in P.glob('observed-cache-gallery-*.json'):
 for q in json.loads(f.read_text()):
  for url in q.get('urls',[]):
   url=url.rstrip(':')
   if not url.startswith('https://image.hm.com/')or'.jpg?'not in url:continue
   selected.append(dict(sku=q['sku'],product_url=q.get('url')or q.get('ref_id'),url=url,alt=q.get('alt',''),observed_width=2160,source_file=str(f),source_kind='official_cached_pdp_gallery_link'))
selected=list({(q['sku'],q['url']):q for q in selected}.values())
write('source-inventory.json',sources);write('selected-official-images.json',selected)
masters={(m['sku'],m['url']):m for m in json.loads((P/'original-image-masters.json').read_text())}if(P/'original-image-masters.json').exists()else{};prior_errors=json.loads((P/'photo-download-errors.json').read_text())if(P/'photo-download-errors.json').exists()else[];known404={e['url']:e for e in prior_errors if '404' in e['error']};errors=[]
def fetch(im):
 path=out/(im['sku']+'-'+hashlib.sha256(im['url'].encode()).hexdigest()[:12]+'.jpg')
 if not path.exists():
  req=urllib.request.Request(im['url'],headers={'User-Agent':'Mozilla/5.0'});data=urllib.request.urlopen(req,timeout=35).read();Image.open(io.BytesIO(data)).verify();path.write_bytes(data)
 a=Image.open(path);return dict(im,path=str(path),sha256=sha(path),pixels=list(a.size),format=a.format,mode=a.mode,icc_profile_present=bool(a.info.get('icc_profile')),exif_orientation=a.getexif().get(274),original_bytes_unmodified=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=6)as pool:
 errors.extend(known404[im['url']]for im in selected if im['url']in known404)
 tasks={pool.submit(fetch,im):im for im in selected if im['url']not in known404}
 for f in concurrent.futures.as_completed(tasks):
  im=tasks[f]
  try:
   m=f.result();key=(m['sku'],m['url']);new=key not in masters
   if not new:assert masters[key]['sha256']==m['sha256'],'Immutable source master changed: '+m['path']
   masters[key]=m
   if new:print('NEW PHOTO',m['sku'],m['pixels'],flush=True)
  except Exception as e:errors.append(dict(sku=im['sku'],url=im['url'],error=repr(e)));print('ERROR',im['sku'],repr(e),flush=True)
write('original-image-masters.json',list(masters.values()));write('photo-download-errors.json',errors);print('CAPTURES',len(sources),'PHOTOS',len(masters),'errors',len(errors),flush=True)
