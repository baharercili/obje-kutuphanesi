from pathlib import Path
import json,re
from collections import Counter
p=Path(__file__).resolve().parent;rows=json.loads((p/'source-category-slice.json').read_text())['products'];cache={q['sku']:q for q in json.loads((p/'cached-research-inventory.json').read_text())};live={q['sku']:q for q in json.loads((p/'source-inventory.json').read_text())};photos=json.loads((p/'original-image-masters.json').read_text());manifest={q['sku']:q for q in json.loads((p/'manifest.json').read_text())};out=[]
frozen={}
for f in sorted(p.glob('frozen-family-*/manifest.json')):
 if f.parent.name=='frozen-family-03':continue # Withdrawn: superseded by corrected six-point-star family04.
 for e in json.loads(f.read_text()):frozen[e['sku']]=dict(e,frozen_manifest=str(f))
for row in rows:
 sku=row['product_code'];q=cache[sku];cap=live.get(sku,{}).get('official_capture');refs=[im for im in photos if im['sku']==sku];evidence=bool(q['status']=='cached_measurement_evidence')or bool(cap and re.search(r'\d+(?:[.,]\d+)?\s*cm',cap.get('description',''))) or bool(cap and cap.get('size_selector_observed',{}).get('numeric_anchor')) or sku in['0746539004','1105071002','1244824004','1244814003','1355409001'];status='pending_geometry'if evidence and refs else'pending_measurements'if refs else'pending_research'
 if sku in manifest:status='quality_review'
 if sku in frozen:status='ready'
 out.append(dict(sku=sku,title=row['title'],url=row['url'],status=status,official_measurement_evidence_available=evidence,official_image_count=len(refs),source_images=[dict(url=i['url'],alt=i['alt'])for i in refs],source_evidence_files=([live[sku]['source_evidence_file']]if cap else[])+list(set(s['source_file']for s in q['official_cached_sources'])),source_notes=('Resmî canlı PDP kimliği, kendi galeri fotoğrafları ve mevcut ölçü alanları kaydedildi. Sayısal fiziksel dayanak yoksa model ölçeği uydurulmadı.'if cap else'Resmî kategori ve erişilebilir resmî PDP önbellek kanıtları kullanıldı; sayısal fiziksel dayanak yoksa model ölçeği uydurulmadı.'),model_id=(frozen.get(sku)or manifest.get(sku,{})).get('id'),frozen_manifest=frozen.get(sku,{}).get('frozen_manifest')))
(p/'all62-status.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(Counter(q['status']for q in out))
