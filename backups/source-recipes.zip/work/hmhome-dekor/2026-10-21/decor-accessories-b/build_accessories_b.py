from pathlib import Path
import sys,json,math,hashlib,shutil,importlib.util
sys.dont_write_bytecode=True
import numpy as np
from PIL import Image,ImageFilter,ImageDraw,ImageFont
R=Path(__file__).resolve().parent;H=R.parent;Z=H.parents[1]/'zarahome-dekor'
sp=importlib.util.spec_from_file_location('hm_vase_helpers',H/'vases/build_vases.py');V=importlib.util.module_from_spec(sp);sp.loader.exec_module(V)
B=V.B;M=V.M;S=V.S;finalize=V._finalize;export_assets=V.export_assets;read_glb=V.read_glb;write_glb=V.write_glb;T=math.tau
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def mesh(name,mat,v,f,uv=None,flat=False):return B.solid(name,mat,v,f,uv,flat)
def merge(parts,name,mat):
 vs=[];fs=[];uv=[]
 for p in parts:
  off=len(vs);vs+=p['_vertices'];uv+=p['_uvs'];fs += [tuple(i+off for i in f)for f in p['_faces']]
 return mesh(name,mat,vs,fs,uv,mat.startswith('egg')or mat=='paper')
def tube(name,mat,pts,r,sides=8,closed=False):return B.tube(name,mat,pts,r,r,sides,closed,guide=[0,0,1])
def sheet(name,mat,outline,thick=0.00013,mapper=None):
 # A convex polygon with true physical edge walls; coordinates are in its local XY plane.
 n=len(outline);v=[];uv=[]
 for sign in[-1,1]:
  for x,y in outline:
   v.append(mapper(x,y,sign*thick/2)if mapper else(x,y,sign*thick/2));uv.append((x*20,y*20))
 f=[]
 for i in range(1,n-1):f.extend([(0,i+1,i),(n,n+i,n+i+1)])
 for i in range(n):j=(i+1)%n;f.extend([(i,j,n+i),(j,n+j,n+i)])
 return mesh(name,mat,v,f,uv,True)
def bank(key,color,kind='paper',photo=None,crop=None):
 out=R/'materials'/key;out.mkdir(parents=True,exist_ok=True);n=2048;rng=np.random.default_rng(int(hashlib.sha256(key.encode()).hexdigest()[:8],16));fine=rng.normal(size=(n,n)).astype(np.float32)
 cloud=np.asarray(Image.fromarray(rng.normal(size=(128,128)).astype(np.float32),'F').resize((n,n),Image.Resampling.BICUBIC));height=fine*.025+cloud*.035
 rgb=np.array(color,np.float32)[None,None,:]+fine[:,:,None]*.8+cloud[:,:,None]*1.1;rough=.82;metal=0
 if kind=='metal':rgb+=fine[:,:,None]*.3;rough=.26;metal=1;height*=.15
 if kind=='tinsel':rough=.43;metal=.85;height*=.08
 if kind in ['glass','satin']:
  rough=.11 if kind=='glass'else .45;metal=0;height*=.04 if kind=='glass'else .25
 if kind=='fur':
  source=Image.open(photo).convert('RGB');patch=source.crop(crop);patch.save(out/'fur-donor-crop.png');base=np.asarray(patch.resize((n,n),Image.Resampling.LANCZOS),np.float32)
  target=np.array([194.0,169.0,159.0],np.float32);gain=target/np.maximum(base.mean((0,1)),1);base*=gain
  # Symmetric repeat joins preserve real donor fibres without copying the product silhouette or studio background.
  tile=Image.new('RGB',(n,n));q=Image.fromarray(np.clip(base,0,255).astype(np.uint8)).resize((n//2,n//2),Image.Resampling.LANCZOS);tile.paste(q,(0,0));tile.paste(q.transpose(Image.Transpose.FLIP_LEFT_RIGHT),(n//2,0));tile.paste(q.transpose(Image.Transpose.FLIP_TOP_BOTTOM),(0,n//2));tile.paste(q.transpose(Image.Transpose.ROTATE_180),(n//2,n//2));rgb=np.asarray(tile,np.float32);height=np.mean(rgb,2)/255*.35+fine*.02;rough=.96
  dump(out/'donor-edit-stack.json',dict(master=photo,master_sha256=sha(photo),master_pixels=list(source.size),crop_box_original_pixels=crop,operations=['Single source crop from immutable original','Lanczos resample to donor tile','Deterministic mirrored repeat; no product background pixels','Channel exposure matched to the same-product isolated front fabric; source masters remain untouched'],generated_pixels=False,channel_gain= gain.tolist(),target_intrinsic_fur_rgb=[194,169,159],effective_donor_pixels=list(patch.size)))
 dy,dx=np.gradient(height);normal=np.stack([-dx,-dy,np.ones_like(dx)],2);normal/=np.linalg.norm(normal,axis=2,keepdims=True);orm=np.zeros((n,n,3),np.uint8);orm[:,:,0]=255;orm[:,:,1]=np.clip(rough*255+cloud*2,0,255);orm[:,:,2]=int(metal*255)
 for slot,data in [('albedo',np.clip(rgb,0,255).astype(np.uint8)),('normal',np.clip((normal+1)*127.5,0,255).astype(np.uint8)),('orm',orm)]:Image.fromarray(data,'RGB').save(out/(slot+'-2k.png'),optimize=True)
 return dict(baseColorFactor=[1,1,1,1],baseColorTexture=str(out/'albedo-2k.png'),normalTexture=str(out/'normal-2k.png'),metallicRoughnessTexture=str(out/'orm-2k.png'),metallic=1,roughness=1,normalScale=.4 if kind=='fur'else .24,doubleSided=False,alphaMode='OPAQUE',extras=dict(native_resolution=2048,photo_pixels_baked=bool(photo),photo_donor_surface_only=bool(photo),baked_reflections=False,material_kind=kind))

def star():
 p=[];outline=[]
 for j in range(16):
  a=math.pi/2+j*T/16;r=(.110 if j%4==0 else .078)if j%2==0 else .012;outline.append((r*math.cos(a),.230+r*math.sin(a)))
 v=[];uv=[];f=[]
 for sign in[-1,1]:
  off=len(v);v.extend([(x,y,0)for x,y in outline]);uv.extend([(x/.22+.5,(y-.12)/.22)for x,y in outline]);ci=len(v);v.append((0,.230,sign*.002));uv.append((.5,.5))
  for k in range(8):
   tip=2*k;left=(tip-1)%16;right=(tip+1)%16;x,y=outline[tip];ri=len(v);v.append((x*.45,.230+(y-.230)*.45,sign*.009));uv.append((x/.22*.45+.5,(y-.230)/.22*.45+.5));f.extend([(ci,off+left,ri),(off+left,off+tip,ri),(off+tip,off+right,ri),(off+right,ci,ri)])
 p.append(mesh('eight-point-closed-folded-paper-star-with-own-radial-ridges','paper',v,f,uv,True))
 pts=[]
 for t in np.linspace(0,1,520):
  a=T*6.1*t;r=.0120*(1-.55*t);pts.append((r*math.cos(a),.001+.118*t,r*math.sin(a)))
 p.append(tube('real-open-metal-wire-coil-tree-top-mount','metal',pts,.0006,10))
 return p,dict(paper=bank('star-paper',[237,237,224]),metal=bank('star-wire',[173,170,154],'metal')),['Eight long/short folded arms with physical narrow front/back radial ridges','Open six-turn metal wire spring base; no flat photographic card'],dict(w=22,h=34,d=2.5,official={'height_cm':34,'width_cm':22,'bottom_diameter_cm':2.5},estimated=['depth_cm','paper_body_height_cm','coil_turn_count','wire_gauge_mm'],note='Resmî toplam yükseklik34cm, genişlik22cm ve alt çap2,5cm korundu. Yıldız kâğıt kısmının kat kalınlığı1,8cm, kâğıt yıldız/spiral boy oranı ve tel çapı fotoğraf tahminidir; tel spiral modelin2,5cm dış derinliğini belirler.',primary='f263dbbbb045',name='Kâğıt ve metal tel yılbaşı ağacı yıldızı',material='Beyaz kalın kâğıt ve metal tel',color='Beyaz/Gümüş rengi')

def eggs(pid='0746539004',h=.07,colors=None):
 colors=colors or[[235,221,184],[168,108,72],[133,134,109]];p=[];materials={}
 for c,rgb in enumerate(colors):materials['egg'+str(c)]=bank(pid+'-paper-'+str(c),rgb)
 materials['cord']=bank(pid+'-cotton-cord',[201,185,142])
 for i in range(6):
  cx=(i%3-1)*.061;cy=(1-i//3)*.115;lamella=[]
  # Independently closed physical radial leaves leave open air between paper lamellae.
  leaves=[]
  for k in range(32):
   a=T*k/32+.08;poly=[(0,0)]+[(h*.317*math.sin(t)*(1-.12*math.cos(t)),h*(.5-.5*math.cos(t)))for t in np.linspace(.04,math.pi-.04,44)]+[(0,h)]
   def mp(r,y,z):
    ang=a;rr=r+.0007;return(cx+rr*math.cos(ang)-z*math.sin(ang),cy+y,rr*math.sin(ang)+z*math.cos(ang))
   leaves.append(sheet('independent-curved-thin-paper-leaf-'+str(k),'egg'+str(i%3),poly,.00035,mp))
  p.append(merge(leaves,'twenty-six-genuinely-open-radial-paper-leaves-'+str(i+1),'egg'+str(i%3)))
  pts=[(cx+.006*math.sin(t),cy+h+.032*(1-math.cos(t))/2,.0003*math.cos(t))for t in np.linspace(0,T,90,endpoint=False)];p.append(tube('cotton-hanging-loop-'+str(i+1),'cord',pts,.00045,6,True))
 return p,materials,['Six independently formed egg ornaments in the official three-colour set','Twenty-six individually closed thin curved paper lamellae with real open air channels between leaves','Cotton hanging loops; staggered display arrangement is a layout estimate'],dict(w=16.8,h=21.7,d=4.5,official={'each_egg_approximate_height_cm':h*100,'pieces':6},estimated=['each_egg_width_cm','each_egg_depth_cm','hanging_cord_size_cm','set_display_bounds_cm'],note='Resmî yaklaşık7cm ölçü tek yumurta gövdesine aittir; altı parçanın grup yerleşimi, en/derinlik ve askı ipi boyları fotoğraf tahminidir. Grup dış sınırı ürünün resmî tek parça ölçüsü olarak sunulmaz.',primary='4764553bec59',name="6’lı petek kâğıt Paskalya süsü",material='Petek karton ve kumaş askı ipi',color='Açık bej/Kahverengi/Haki',bundle=True,official_piece_dimensions_cm=[None,h*100,None])

def snowflake(pid,radius):
 p=[];material='paper';bodies=[]
 def mapper(a):
  def mp(x,y,z):
   # y = radial direction; x = tangent; folded fan has a deep centre and raised alternate crease.
   radial=y;x=x*2;theta=a+x/max(radial,.001);zz=.14*radius*(radial/radius)*math.cos(12*theta);return(radial*math.sin(theta),radial*math.cos(theta),zz+z)
  return mp
 # Twelve scalloped branches, split folds, three real oval perforations per branch edge.
 for k in range(12):
  a=T*k/12;mp=mapper(a)
  # Tapered radial paper stem reaches each scalloped point.
  stem=[(-radius*.008,radius*.002),(radius*.008,radius*.002),(radius*.029,radius*.68),(radius*.010,radius*.97),(0,radius),(-radius*.010,radius*.97),(-radius*.029,radius*.68)]
  bodies.append(sheet('folded-radial-spine-'+str(k),material,stem,radius*.0011,mp))
  for side in[-1,1]:
   for j,(rr,xx,ry,rx)in enumerate([(.54,.040,.15,.035),(.74,.064,.100,.031),(.865,.041,.065,.022)]):
    rings=[]
    for inner in[False,True]:
     poly=[]
     for t in np.linspace(0,T,40,endpoint=False):poly.append((side*(xx+rx*math.cos(t))*radius,(rr+ry*math.sin(t))*radius))
     rings.append(poly)
    # Closed ribbon around an actual hole: outer ellipse and inner ellipse linked by front/back strips.
    v=[];uv=[]
    for sign in[-1,1]:
     for inn in[False,True]:
      for t in np.linspace(0,T,40,endpoint=False):
       x=side*(xx+(rx-(min(.024,rx*.60) if inn else 0))*math.cos(t))*radius;y=(rr+(ry-(min(.024,ry*.25) if inn else 0))*math.sin(t))*radius;v.append(mp(x,y,sign*radius*.00055));uv.append((x/radius,y/radius))
    f=[];n=40
    for i in range(n):j2=(i+1)%n
    # Index orders are subsequently oriented consistently by the geometry checker.
    for i in range(n):
     q=(i+1)%n
     for A,Bb,C,D in[(i,q,40+i,40+q),(80+i,120+i,80+q,120+q),(i,80+i,q,80+q),(40+i,40+q,120+i,120+q)]:f.extend([(A,Bb,C),(Bb,D,C)])
    bodies.append(mesh('real-lace-oval-cutout-'+str((k,side,j)),material,v,f,uv,False))
  # Solid triangular core connects pleats below the perforated branches.
  bodies.append(sheet('triangular-fan-core-'+str(k),material,[(-radius*.067,radius*.43),(0,radius*.003),(radius*.067,radius*.43)],radius*.0011,mp))
 p.append(merge(bodies,'twelve-folded-paper-spokes-with-real-oval-lace-apertures','paper'))
 cord=[(radius*.018*math.sin(t),radius+radius*.34*(1-math.cos(t))/2,-radius*.005)for t in np.linspace(0,T,100,endpoint=False)];p.append(tube('fine-hanging-cord','cord',cord,radius*.0022,6,True))
 return p,dict(paper=bank(pid+'-green-paper',[17,54,47]),cord=bank(pid+'-green-cord',[58,94,82])),['Folded twelve-spoke radial fan with deep paper creases','Separate scalloped loops and genuinely open oval lace cutouts; not alpha planes','Dark green paper and a fine hanging cord'],dict(w=radius*200,h=radius*234,d=radius*11,official={'paper_body_diameter_cm':radius*200},estimated=['fold_depth_cm','hanging_cord_length_cm','paper_thickness_mm','cutout_layout'],note=f'Resmî çap{radius*200:g}cm yalnız kâğıt süs gövdesine aittir. Katlanma derinliği, delik/kıvrım yerleşimi ve askı ipi fotoğraftan yorumlandı. Askı dahil yükseklik tahmindir.',primary='bd7743497494'if pid=='1244824004'else'5373f4930aef',name='Delikli ve katlanmış koyu yeşil kâğıt kar tanesi süs',material='Kalın koyu yeşil kâğıt',color='Koyu yeşil',body_dimensions_cm=[radius*200,radius*200,radius*11])

def stocking():
 pid='1355409001';p=[];primary=R/'originals/1355409001-b19180b48c7d.jpg';fur=bank(pid+'-actual-fur-front',[186,152,132],'fur',str(primary),[760,1450,1300,1990]);materials={'fur':fur,'lining':bank(pid+'-lining',[172,143,124],'paper'),'button':bank(pid+'-button',[30,25,23],'metal')}
 # The boot has a real toe, heel, tapered ankle and a long slightly slanted shaft.
 nodes=np.array([[.003,.045,.006,.005],[.012,.040,.045,.014],[.033,.028,.075,.020],[.062,.007,.086,.024],[.096,-.019,.072,.023],[.130,-.029,.060,.022],[.190,-.013,.059,.020],[.270,.006,.060,.019],[.355,.025,.061,.019],[.380,.031,.061,.020]])
 def state(y,inner=False):
  x=V.smooth_radius(y,nodes[:,0],nodes[:,1]);rx=V.smooth_radius(y,nodes[:,0],nodes[:,2]);rz=V.smooth_radius(y,nodes[:,0],nodes[:,3]);return x,max(.002,rx-(.003 if inner else 0)),max(.002,rz-(.003 if inner else 0))
 def shell(name,mat,ys,inside=False,flare=0):
  v=[];uv=[];n=96;rings=[]
  seq=[(False,list(ys)),(True,list(ys)[::-1])]
  for inner,heights in seq:
   for y in heights:
    x,rx,rz=state(y,inner);rx+=flare;rz+=flare;ring=[]
    for j in range(n):
     a=T*j/n;zz=rz*math.sin(a);xx=x+rx*math.cos(a);ring.append(len(v));v.append((xx,y-.22*xx*min(1,y/.30),zz));uv.append((j/n,y/.38*2.4))
    rings.append(ring)
  f=[]
  for k in range(len(rings)-1):
   for j in range(n):a=rings[k][j];b=rings[k][(j+1)%n];c=rings[k+1][j];d=rings[k+1][(j+1)%n];f.extend([(a,b,c),(b,d,c)])
  for j in range(n):a=rings[-1][j];b=rings[-1][(j+1)%n];c=rings[0][j];d=rings[0][(j+1)%n];f.extend([(a,b,c),(b,d,c)])
  return mesh(name,mat,v,f,uv)
 p.append(shell('soft-hollow-boot-toe-heel-and-long-stockings-shaft','fur',np.linspace(.003,.380,105)))
 p.append(shell('real-folded-over-thick-furry-cuff-with-open-upper-mouth','fur',np.linspace(.311,.380,20),flare=.003))
 pts=[(-.031+.010*math.cos(t),.381+.033*(1+math.sin(t))*.5,-.001+.002*math.cos(t))for t in np.linspace(0,T,100,endpoint=False)];p.append(tube('actual-furry-fabric-hanging-loop','fur',pts,.004,10,True))
 button=B.lathe('small-dark-hanger-button','button',[(0,0),(.0073,0),(.0075,.001),(.0073,.0025),(0,.0025)],48,False)
 button['_vertices']=[(x-.031,.410+z,y+.006)for x,y,z in button['_vertices']];p.append(button)
 # Three-dimensional short fibres follow the boot surface, including a natural uneven outline.
 rng=np.random.default_rng(1355409);strands=[]
 for i in range(2100):
  y=rng.uniform(.020,.379);a=rng.uniform(0,T);x,rx,rz=state(y);normal=np.array([math.cos(a)*.35,.12,math.sin(a)]);normal/=np.linalg.norm(normal);point=np.array([x+rx*math.cos(a),y,rz*math.sin(a)]);length=rng.uniform(.0012,.0028);lean=np.array([rng.uniform(-.002,.002),rng.uniform(-.0025,.001),0]);pts=[point+normal*.0004,point+normal*(length*.65)+lean*.4,point+normal*length+lean];strands.append(tube('pile-fibre-'+str(i),'fur',pts,rng.uniform(.00004,.00007),4))
 p.append(merge(strands,'individual-short-soft-fur-fibres-following-the-boot-surface','fur'))
 return p,materials,['Own curved boot silhouette with rounded toe, real heel and tapered ankle; never a cushion slab','Open upper mouth with inner textile shell and a physical folded furry cuff','Real short 3D pile fibres, visible textile hanging loop and small dark button','Gift wrapping and white styled bow excluded because they are absent from the isolated product image'],dict(w=22.2,h=42,d=5.6,official={'height_cm':42},estimated=['overall_width_cm','overall_depth_cm','cuff_height_cm','hanging_loop_size_cm','wall_thickness_mm'],note='Resmî yükseklik42cm’dir. Yüksekliğin askı dahil yorumlanması, en22,2cm, derinlik5,6cm, iç astar ve yerel tüylü kesit fotoğraf tahminidir. Beyaz hediye kurdelesi ürüne ait olmadığı için eklenmedi.',primary='b19180b48c7d',name='Kabarık tüylü kahverengi yılbaşı çorabı',material='Gerçek yakın plan fotoğrafından tüylü polyester yüzey; üç boyutlu kısa tüyler',color='Açık kahverengi')

def smooth_profile(pr,n=180):
 ys=np.linspace(pr[0][1],pr[-1][1],n);return[(V.smooth_radius(y,[q[1]for q in pr],[q[0]for q in pr]),y)for y in ys]
def ball(name,mat,center,rx,ry=None,rz=None,n=20,m=14):
 ry=rx if ry is None else ry;rz=rx if rz is None else rz
 profile=[(rx*math.sin(a),center[1]+ry*math.cos(a))for a in np.linspace(math.pi,0,m+1)];profile[0]=(0,center[1]-ry);profile[-1]=(0,center[1]+ry);return B.lathe(name,mat,profile,n,False,(center[0],0,center[2]),rz/rx)
def ribbon_loop(name,mat,cx,y0,length,width,depth=.00035):
 # A soft narrow flat ribbon folded into a real loop, closed around its cross-section.
 pts=[(cx+.002*math.sin(t),y0+length*(1-math.cos(t))*.5,.0018*math.sin(t))for t in np.linspace(0,T,100,endpoint=False)];return tube(name,mat,pts,width/2,8,True)
def hanging_eye(name,mat,cx,y,r=.004,z=0):return tube(name,mat,[(cx+r*math.cos(a),y+r*math.sin(a),z)for a in np.linspace(0,T,64,endpoint=False)],r*.24,10,True)
def beaded_star():
 pid='1359146001';points=[]
 # The official9cm refers to the star, without the long satin hanger.
 r=.04975
 for i in range(10):a=math.pi/2+T*i/10;rr=r if i%2==0 else r*.46;points.append(np.array([rr*math.cos(a),rr*math.sin(a)+.04025,0]))
 # Own official close-up shows a gently bent wire, not knife-point corners.
 rounded=[]
 for i,corner in enumerate(points):
  prev=points[(i-1)%10];nxt=points[(i+1)%10];trim=.0015 if i%2==0 else .0018
  a=corner+(prev-corner)*trim/np.linalg.norm(prev-corner);b=corner+(nxt-corner)*trim/np.linalg.norm(nxt-corner)
  rounded.extend([(1-t)**2*a+2*(1-t)*t*corner+t*t*b for t in np.linspace(0,1,7)])
 p=[tube('gently-rounded-steel-open-five-point-star-armature','wire',rounded,.00058,10,True)];beads=[]
 path=np.array(rounded+[rounded[0]]);lengths=np.linalg.norm(np.diff(path,axis=0),axis=1);cum=np.r_[0,np.cumsum(lengths)]
 for i,distance in enumerate(np.linspace(0,cum[-1],round(cum[-1]/.0016),endpoint=False)):
  segment=min(len(lengths)-1,np.searchsorted(cum,distance,side='right')-1);t=(distance-cum[segment])/lengths[segment];pt=path[segment]*(1-t)+path[segment+1]*t;beads.append(ball('small-faceted-glass-bead-'+str(i),'beads',pt,.00128,.00102,.00132,10,6))
 p.append(merge(beads,'actual-small-glass-beads-over-the-wire-star-frame','beads'))
 allp=np.concatenate([np.array(q['_vertices'])for q in p]);low=allp[:,1].min();high=allp[:,1].max()
 for q in p:q['_vertices']=[(x,(y-low)*.09/(high-low),z)for x,y,z in q['_vertices']]
 top=.09;p.append(hanging_eye('small-metal-connector-eye','wire',0,top+.004,.003));p.append(ribbon_loop('white-satin-hanging-ribbon','satin',0,top+.007,.081,.0014))
 mats=dict(wire=bank(pid+'-steel',[183,176,157],'metal'),beads=bank(pid+'-seedglass',[219,211,192],'glass'),satin=bank(pid+'-satin',[229,227,216],'satin'));mats['beads'].update(transmission=.12,ior=1.52,clearcoat=.7,clearcoatRoughness=.05)
 return p,mats,['Open five-point steel armature, fully covered by physical faceted glass seed beads','Small connector ring and its actual long white satin hanging loop; no paper star face'],dict(w=9.7,h=18.5,d=.35,official={'decoration_height_cm':9},estimated=['star_width_cm','hanger_length_cm','bead_diameter_mm','set_bounds_cm'],note='Resmî süs yüksekliği9cm yıldız gövdesine aittir. Askı kurdelesi, yıldız eni/derinliği ve tek tek boncuk boyları fotoğraf tahminidir; askı dahil model yüksekliği ayrıca gösterilir.',primary='3a3e18023f79',name='Cam boncuklu açık yıldız yılbaşı süsü',material='Paslanmaz çelik çerçeve, cam boncuklar ve saten polyester askı',color='Gümüş rengi/Beyaz')

def red_glass(pid):
 smooth=pid=='1299152002';p=[];h=.08 if smooth else .08;radius=.04;n=192;ys=np.linspace(.0003,h-.0003,110);v=[];uv=[];rings=[]
 for inside,heights in[(False,ys),(True,ys[::-1])]:
  for y in heights:
   f=y/h
   if smooth:
    # Squashed antique onion with a visible pointed lower tail.
    rx=V.smooth_radius(f,[0,.08,.22,.45,.65,.85,1],[.001,.008,.031,.040,.036,.022,.0045])
   else:rx=radius/1.037*math.sin(math.acos(1-2*f))
   ring=[]
   for j in range(n):
    a=T*j/n;rr=rx*(1 if smooth else 1+.037*math.cos(12*a))-(.00085 if inside else 0);rr=max(.0005,rr);ring.append(len(v));v.append((rr*math.cos(a),y,rr*math.sin(a)));uv.append((j/n,f))
   rings.append(ring)
 f=[]
 for k in range(len(rings)):
  ra=rings[k];rb=rings[(k+1)%len(rings)]
  for j in range(n):a=ra[j];bb=ra[(j+1)%n];c=rb[j];d=rb[(j+1)%n];f.extend([(a,bb,c),(bb,d,c)])
 p.append(mesh('hollow-squashed-onion-glass-body-with-lower-point'if smooth else'hollow-rounded-glass-body-with-twelve-soft-vertical-flutes','glass',v,f,uv));p.append(hanging_eye('actual-moulded-glass-hanging-eye','glass',0,.085,.0042));p.append(ribbon_loop('fine-gold-colour-hanging-cord','cord',0,.089,.090,.00055))
 mats=dict(glass=bank(pid+'-ruby-glass',[224,18,26],'glass'),cord=bank(pid+'-gold-cord',[173,144,70],'metal'));mats['glass'].update(transmission=.75,ior=1.50,thickness=.00085,attenuationColor=[.92,.04,.035],attenuationDistance=.010,clearcoat=1,clearcoatRoughness=.04,nativePreviewOpacity=.78)
 return p,mats,['Actual distinct squashed onion/rounded ribbed silhouette from this SKU’s isolated photograph','Physical hollow glass shell, integrated glass hanging eye and fine gold cord','Transparent ruby glass is a physical transmission material; studio reflections are excluded from texture'],dict(w=8.0,h=18.1,d=8.0,official={'body_diameter_cm':8},estimated=['body_height_cm','glass_wall_thickness_mm','hanging_loop_size_cm','cord_length_cm'],note='Resmî8cm çap en geniş cam gövde kesitine uygulanır. Gövde yüksekliği, askı, cidar ve iç kesit fotoğraftan yorumlandı; askı dahil dış yükseklik üreticinin resmî ölçüsü değildir.',primary='ba9ce81c8977'if smooth else'a768c34abc70',name='Kırmızı el üflemesi görünümlü cam yılbaşı süsü'if smooth else'Kırmızı dikey oluklu cam yılbaşı süsü',material='İçi boş yakut kırmızısı cam ve ince altın rengi askı',color='Kırmızı')

def glass_pair():
 pid='1261191001';p=[];n=128;m=80
 for k in range(2):
  cx=(k-.5)*.045;cy=.014*k;v=[];uv=[];rings=[]
  for inside,fs in[(False,np.linspace(.006,.994,m)),(True,np.linspace(.994,.006,m))]:
   for f in fs:
    y=.040*f;rr=.015*math.sin(math.acos(1-2*f))*(1-.13*math.cos(math.pi*f));ring=[]
    for j in range(n):
     a=T*j/n;dimple=.00042*(math.sin(7*a+f*22)+.4*math.sin(11*a-f*31))*math.sin(math.pi*f);r=max(.0007,rr+dimple-(.0007 if inside else 0));ring.append(len(v));v.append((cx+r*math.cos(a),cy+y,r*math.sin(a)));uv.append((j/n,f))
    rings.append(ring)
  faces=[]
  for i in range(len(rings)):
   a=rings[i];b=rings[(i+1)%len(rings)]
   for j in range(n):z=(j+1)%n;faces.extend([(a[j],b[j],a[z]),(a[z],b[j],b[z])])
  raw=mesh('hand-bubbled-hollow-clear-borosilicate-egg-'+str(k+1),'glass',v,faces,uv);pos=np.array(v);span=np.ptp(pos,axis=0);raw['_vertices']=[(cx+(x-cx)*.03/span[0],y,z*.03/span[2])for x,y,z in v];p.append(raw);p.append(hanging_eye('integrated-clear-glass-eye-'+str(k+1),'glass',cx,cy+.0416,.0028));p.append(ribbon_loop('very-fine-white-thread-'+str(k+1),'thread',cx,cy+.045,.049,.00028))
 mat=bank(pid+'-borosilicate',[251,251,248],'glass');mat.update(transmission=.97,ior=1.47,thickness=.0007,attenuationColor=[.97,.99,1],attenuationDistance=.5,clearcoat=1,clearcoatRoughness=.03,nativePreviewOpacity=.22)
 return p,dict(glass=mat,thread=bank(pid+'-thread',[235,235,224])),['Two independently formed hollow egg shells with real geometric bubbly waviness','Actual integrated glass eyes and thin white hanging threads','Transparent borosilicate with physical transmission, refraction and tiny wall thickness'],dict(w=7.8,h=11.4,d=3.0,official={'each_width_cm':3,'each_height_cm':4.5,'pieces':2},estimated=['wall_thickness_mm','dimple_layout','hanger_length_cm','set_display_bounds_cm'],note='Resmî tek cam süs eni3cm ve gövde yüksekliği4,5cm korunur. İkinci parçanın yerleşimi, cidar, cam kabarcıkları ve ip boyları fotoğraf tahminidir; setin ortak dış zarfı resmî ölçü değildir.',primary='25c0704a49d1',name='2’li kabarcık dokulu şeffaf cam Paskalya süsü',material='Şeffaf borosilikat cam ve ince beyaz ip',color='Şeffaf',bundle=True,official_piece_dimensions_cm=[3,4.5,None])

def tinsel(pid):
 color={'1294288002':[180,133,35],'1294288003':[195,199,198],'1294288004':[8,105,49]}[pid];p=[];rng=np.random.default_rng(int(pid));filaments=[]
 # Dense three-dimensional strips radiate through the whole9.5cm sphere; no textured card or smooth sphere substitute.
 for i in range(3800):
  u=rng.uniform(-1,1);a=rng.uniform(0,T);rad=math.sqrt(1-u*u);direction=np.array([rad*math.cos(a),u,rad*math.sin(a)]);root=direction*rng.uniform(.022,.037)+[0,.0475,0];side=rng.normal(size=3);side-=direction*np.dot(side,direction);side/=np.linalg.norm(side);length=rng.uniform(.010,.023);tip=root+direction*length+side*rng.uniform(-.013,.013);mid=root*(.52)+tip*.48+side*rng.uniform(-.004,.004);tangent=tip-root;tangent/=np.linalg.norm(tangent);normal=np.cross(tangent,side);normal/=np.linalg.norm(normal);binormal=np.cross(tangent,normal);width=rng.uniform(.00025,.00065);th=.000055;v=[]
  for t,pt in enumerate([root,mid,tip]):
   twist=rng.uniform(-.9,.9);nn=normal*math.cos(twist)+binormal*math.sin(twist);bb=-normal*math.sin(twist)+binormal*math.cos(twist)
   for xx,zz in[(-1,-1),(1,-1),(1,1),(-1,1)]:v.append(tuple(pt+nn*xx*width/2+bb*zz*th/2))
  faces=[(0,2,1),(0,3,2),(8,9,10),(8,10,11)]
  for t in range(2):
   for j in range(4):n=(j+1)%4;a=t*4+j;b=t*4+n;c=a+4;d=b+4;faces.extend([(a,b,c),(b,d,c)])
  filaments.append(mesh('crinkled-reflective-PET-tinsel-strip-'+str(i),'tinsel',v,faces,flat=True))
 p.append(merge(filaments,'thousands-of-real-radial-metallic-PET-strips','tinsel'));pp=np.array(p[0]['_vertices']);span=np.ptp(pp,axis=0);mid=(pp.max(0)+pp.min(0))/2;p[0]['_vertices']=[tuple((np.array(q)-mid)*.095/span+[0,.0475,0])for q in p[0]['_vertices']];p.append(ribbon_loop('coordinating-fine-hanging-loop','cord',0,.094,.061,.0005));mat=bank(pid+'-tinsel',color,'tinsel');mat['roughness']=1
 return p,dict(tinsel=mat,cord=bank(pid+'-cord',color,'metal')),['Dense radial three-dimensional narrow PET strips fill the actual spherical pom-pom','Every strand is a closed thin reflective solid; no sphere or billboard stands in for the tinsel','Fine coordinating hanger with gold/silver/green material specific to the SKU'],dict(w=9.5,h=15.6,d=9.5,official={'pom_pom_diameter_cm':9.5},estimated=['strip_count','strip_width_mm','hanging_loop_size_cm'],note='Resmî9,5cm çap püsküllü ponpon gövdesine aittir. Tek tek şeritler ve askı ipi boyu fotoğraf tahminidir; askı dahil yükseklik ayrıca verilir. Diğer piyasalardaki paket ölçüsü olabilecek çelişkili hücreler gövde ölçüsü olarak alınmadı.',primary={'1294288002':'','1294288003':'','1294288004':'52cd60fc7f3a'}[pid],name='Altın rengi simli ponpon yılbaşı süsü'if pid.endswith('002')else'Gümüş rengi simli ponpon yılbaşı süsü'if pid.endswith('003')else'Yeşil simli ponpon yılbaşı süsü',material='Parlak metalik görünümlü PET şeritler ve askı ipi',color={'1294288002':'Altın rengi','1294288003':'Gümüş rengi','1294288004':'Yeşil'}[pid])

def black_star_set():
 pid='0451338006';parts=[];r=.0225
 for k in range(6):
  cx=(k%3-1)*.057;cy=(1-k//3)*.085;outline=[]
  for j in range(12):a=math.pi/2+T*j/12;rr=r if j%2==0 else r*.56;outline.append((cx+rr*math.cos(a),cy+.0225+rr*math.sin(a)))
  v=[(x,y,0)for x,y in outline]+[(cx,cy+.0225,.0035),(cx,cy+.0225,-.0007)];uv=[((x-cx)/.045+.5,(y-cy)/.045)for x,y in outline]+[(.5,.5),(.5,.5)];f=[]
  for j in range(12):n=(j+1)%12;f.extend([(12,j,n),(13,n,j)])
  parts.append(mesh('pressed-six-point-closed-black-metal-star-'+str(k+1),'black',v,f,uv,True));parts.append(ribbon_loop('fine-gold-twine-hanger-'+str(k+1),'cord',cx,cy+.045,.032,.00040))
 mat=bank(pid+'-black-metal',[26,25,25],'metal');mat['roughness']=.9
 return parts,dict(black=mat,cord=bank(pid+'-gold-thread',[151,130,76],'metal')),['Six actual six-point pressed metal stars, counted against the full-resolution own official close-up','Raised front facets and a thin closed reverse','Small glittering gold-colour textile hanging cords; all six are parts of the same official set'],dict(w=16,h=16,d=.42,official={'approximate_each_size_cm':4.5,'pieces':6},estimated=['per_axis_star_dimensions_cm','relief_depth_cm','cord_length_cm','set_display_bounds_cm'],note='Resmî yaklaşık4,5cm boyut, her yıldızın en geniş kesitine uygulanır; üretici bu etikette eksen belirtmez. Kaynak fotoğraftaki altı uçlu form korundu. Kabartma, ip ve altı parçanın ortak yerleşimi fotoğraf tahminidir.',primary='977c5bb78e98',name='6’lı siyah metal yıldız yılbaşı süsü',material='Kabartmalı siyah metal ve simli kumaş askı ipi',color='Siyah',bundle=True)
def silver_stripe_material(pid):
 mat=bank(pid+'-silver-glitter-stripes',[228,229,224],'metal');f=Path(mat['baseColorTexture']);n=2048;rng=np.random.default_rng(34990003);u=np.arange(n)[None,:]/n;mask=(np.abs(np.sin(T*u*5))<.040).astype(np.float32);mask=np.broadcast_to(mask,(n,n));noise=rng.random((n,n));rgb=np.asarray(Image.open(f),np.float32).copy();rgb-=mask[:,:,None]*(22+noise[:,:,None]*25);orm=np.zeros((n,n,3),np.uint8);orm[:,:,0]=255;orm[:,:,1]=np.clip((.10*(1-mask)+(.43+.3*noise)*mask)*255,0,255);orm[:,:,2]=255;Image.fromarray(np.clip(rgb,0,255).astype(np.uint8)).save(f);Image.fromarray(orm).save(mat['metallicRoughnessTexture']);mat.update(clearcoat=.7,clearcoatRoughness=.07);return mat

def silver_pair(pid='1354990003'):
 parts=[]
 for k,(h,rx,cx,cy)in enumerate([(.135,.031,-.043,0),(.080,.035,.043,.020)]):
  if k==0:pr=[(.0005,0),(.007,.015),(.024,.045),(.031,.069),(.028,.092),(.016,.116),(.005,.130),(.004,.132)]
  else:pr=[(.0005,0),(.011,.009),(.028,.022),(.035,.041),(.030,.058),(.015,.070),(.004,.077)]
  outer=smooth_profile(pr,150);inner=[(max(.0003,r-.0008),max(.001,y))for r,y in outer[::-1]if y>.001];profile=[(0,0)]+outer+inner+[(0,.001)]
  raw=B.lathe('elongated-pointed-hollow-silver-glass-ornament'if k==0 else'round-pointed-hollow-silver-glass-ornament','silver',profile,192,False,offset=(cx,cy,0));raw['_uvs']=[(uv[0],(y-cy)/h)for uv,(x,y,z)in zip(raw['_uvs'],raw['_vertices'])];parts.append(raw);parts.append(B.cylinder('fluted-silver-cap-'+str(k+1),'silver',.0041,cy+outer[-1][1]-.001,cy+h,offset=(cx,0,0),n=40));parts.append(hanging_eye('metal-hanger-eye-'+str(k+1),'silver',cx,cy+h+.0022,.0022));parts.append(ribbon_loop('pale-grey-velvet-hanger-'+str(k+1),'velvet',cx,cy+h+.004,.070,.0018))
 return parts,dict(silver=green_stripe_glass_material(pid)if pid=='1354990002'else silver_stripe_material(pid),velvet=bank(pid+'-velvet',[24,67,34]if pid=='1354990002'else[197,192,179],'satin')),['One elongated pointed and one shorter rounded ornament, preserving the two official individual heights','Real hollow shells with separate small caps and pale grey velvet hangers','Ten fine longitudinal silver-glitter lines are intrinsic material strips, with metallic highlights supplied by lighting rather than baked studio images'],dict(w=15.5,h=21,d=7.0,official={'small_height_cm':8,'medium_height_cm':13.5,'pieces':2},estimated=['body_width_cm','body_depth_cm','glass_wall_thickness_mm','hanger_length_cm','set_display_bounds_cm'],note='Resmî küçük süs yüksekliği8cm, orta süs yüksekliği13,5cm’dir. Cam gövdelerin eni/derinliği, kadife askı ve set yerleşimi fotoğraf tahminidir. Her parçanın ölçüsü ayrı korunur; set dış zarfı resmî ölçü olarak sunulmaz.',primary='72cc36c87d29'if pid=='1354990002'else'a3640869eb68',name='2’li yeşil sim çizgili cam yılbaşı süsü'if pid=='1354990002'else'2’li gümüş renkli sim çizgili cam yılbaşı süsü',material='Yeşil cam, simli çizgiler ve yeşil kadife askı'if pid=='1354990002'else'Gümüş renkli cam, simli çizgiler ve açık gri kadife askı',color='Yeşil'if pid=='1354990002'else'Gümüş rengi',bundle=True,official_piece_dimensions_cm=[[None,13.5,None],[None,8,None]])

# Real thin radial sheets, individually closed. Profile coordinates are photo-specific, not smooth closed ball stand-ins.
PAPER_PROFILES={
'egg':[(0,0),(.07,.50),(.20,.84),(.43,1),(.67,.91),(.87,.64),(1,0)],
'onion':[(0,0),(.08,.18),(.18,.63),(.38,.96),(.56,1),(.76,.78),(.89,.40),(.96,.34),(1,0)],
'finial':[(0,0),(.34,.40),(.46,.24),(.55,.75),(.67,1),(.78,.74),(.89,.44),(.92,.25),(.97,.30),(1,0)],
'double':[(0,0),(.16,.43),(.33,.66),(.42,.46),(.49,.81),(.58,1),(.68,.83),(.77,.48),(.86,.36),(.92,.40),(1,0)],
'icicle':[(0,0),(.18,.28),(.43,.42),(.51,.30),(.57,.90),(.65,1),(.75,.86),(.83,.36),(.89,.35),(.95,.42),(1,0)],
'diamond':[(0,0),(.36,.53),(.52,1),(.68,.52),(1,0)],
'lantern':[(0,0),(.18,.42),(.28,1),(.72,1),(.82,.42),(1,0)],
'star':[(0,0),(.27,.31),(.40,1),(.60,1),(.73,.31),(1,0)],
'bell':[(0,0),(.06,.50),(.20,1),(.36,.75),(.60,.49),(.84,.35),(.94,.28),(1,0)],
'candy_round':[(0,.80),(.04,.83),(.12,.62),(.24,.31),(.32,.63),(.44,.96),(.52,1),(.65,.85),(.76,.31),(.88,.62),(.96,.83),(1,.80)],
'candy_cylinder':[(0,.84),(.04,.86),(.16,.51),(.23,.33),(.27,.33),(.28,1),(.72,1),(.73,.33),(.77,.33),(.84,.51),(.96,.86),(1,.84)],
'bunny':[(0,0),(.10,.74),(.28,1),(.45,.82),(.54,.47),(.59,.36),(.64,.62),(.75,.67),(.84,.46),(.87,.16),(1,0)]}

PAPER_PROFILES.update({
'four_tier':[(0,.05),(.08,.18),(.20,.52),(.28,.28),(.40,.70),(.45,.68),(.54,.27),(.65,1),(.70,.94),(.79,.24),(.90,.60),(.95,.58),(1,.35)],
'four_spindle':[(0,.05),(.15,.17),(.43,.48),(.49,.43),(.54,.27),(.57,.55),(.63,.27),(.72,.95),(.77,1),(.84,.80),(.88,.28),(.93,.62),(.97,.40),(1,.38)],
'four_double':[(0,.06),(.15,.10),(.42,.44),(.50,.62),(.57,.61),(.62,.27),(.71,.95),(.79,1),(.87,.84),(.95,.34),(1,.30)],
'four_flange':[(0,.10),(.15,.22),(.42,.66),(.49,.35),(.56,.88),(.60,1),(.65,.83),(.69,.34),(.79,.59),(.87,.54),(1,.36)],
'set_spool':[(0,.06),(.10,.22),(.29,.48),(.33,1),(.75,1),(.78,.45),(.92,.20),(1,.06)],
'set_urn':[(0,.05),(.15,.28),(.33,.58),(.44,.35),(.51,.66),(.67,1),(.82,.94),(.95,.47),(1,.20)],
'set_onion':[(0,.08),(.08,.25),(.16,.71),(.36,.98),(.55,1),(.78,.78),(.92,.37),(1,.12)],
'set_fan':[(0,.05),(.10,.40),(.24,.63),(.40,.71),(.51,.83),(.55,1),(.59,1),(.62,.63),(.80,.28),(1,.08)],
'set_ufo':[(0,.08),(.48,.98),(.56,1),(.60,.70),(.82,.48),(.98,.30),(1,.08)],
'set_lantern':[(0,.20),(.08,.24),(.16,.65),(.36,.92),(.55,1),(.76,.90),(.92,.57),(.96,.28),(1,.28)]})

def paper_body(name,mat,width,height,profile,cx=0,cy=0,leaves=32,phase=.10,edge_mat=None,alt_mat=None,twist=0):
 nodes=PAPER_PROFILES[profile];ys=np.linspace(0,1,84);radii=[max(.00025,V.smooth_radius(float(t),[a for a,b in nodes],[b for a,b in nodes])*width*.5)for t in ys];parts=[];edges=[]
 for j in range(leaves):
  angle=T*j/leaves+phase;ma=alt_mat if alt_mat and j%2 else mat;v=[];uv=[];faces=[]
  def mp(r,y,z):
   a=angle+twist*y/height;rr=r+.00035;return(cx+rr*math.cos(a)-z*math.sin(a),cy+y,rr*math.sin(a)+z*math.cos(a))
  for t,rad in zip(ys,radii):
   for r,z in[(0,-.000095),(rad,-.000095),(0,.000095),(rad,.000095)]:v.append(mp(r,t*height,z));uv.append((r*20,t*height*20))
  for i in range(len(ys)-1):
   a=i*4;b=a+4
   for A,Bb,C,D in[(a,a+1,b,b+1),(a+2,b+2,a+3,b+3),(a,b,a+2,b+2),(a+1,a+3,b+1,b+3)]:faces.extend([(A,Bb,C),(Bb,D,C)])
  for a in[0,(len(ys)-1)*4]:faces.extend([(a,a+2,a+1),(a+1,a+2,a+3)])
  parts.append(mesh(name+'-closed-thin-radial-paper-leaf-'+str(j),ma,v,faces,uv,True))
  if edge_mat:edges.append(tube(name+'-subtle-glitter-cut-edge-'+str(j),edge_mat,[mp(r,t*height,0)for t,r in zip(ys,radii)],.000045,4))
 out=[]
 for ma in set(q['material']for q in parts):out.append(merge([q for q in parts if q['material']==ma],name+'-open-paper-leaves-'+ma,ma))
 if edges:out.append(merge(edges,name+'-subtle-glitter-on-real-cut-edges',edge_mat))
 return out

def egg_family(pid):
 little=pid.startswith('1214591');h=.035 if little else .07;striped=pid in['0746539015','1214591007'];colors={
'0746539012':[[135,144,36],[81,143,105],[25,66,41]],'0746539013':[[218,121,142],[224,172,26],[195,40,38]],'0746539015':[[234,176,26],[172,67,69],[105,116,44]],'0746539016':[[239,178,25]]*3,'1214591001':[[153,95,62],[118,119,88],[235,220,177]],'1214591002':[[218,121,142],[224,172,26],[195,40,38]],'1214591007':[[214,166,34],[139,78,80],[90,100,47]]}[pid];p=[];mats={};factor=h/.07
 for j,c in enumerate(colors):mats['paper'+str(j)]=bank(pid+'-dyed-paper-'+str(j),c)
 if striped:mats['ivory']=bank(pid+'-alternate-cream-paper',[240,233,211])
 mats['cord']=bank(pid+'-coordinating-cotton',[201,187,143])
 for j in range(6):
  cx=(j%3-1)*.061*factor;cy=(1-j//3)*.115*factor;w=h*.64;p+=paper_body('egg-'+str(j+1),'paper'+str(j%3),w,h,'egg',cx,cy,leaves=32,alt_mat='ivory'if striped else None);p.append(ribbon_loop('cotton-hanging-loop-'+str(j+1),'cord',cx,cy+h,.040*factor,.00045*factor))
 return p,mats,['Six distinct physical open-paper eggs;32 thin closed radial lamellae per egg','SKU-specific dyed paper palette; alternate cream leaves only in the officially striped colourway','Cotton hangers and estimated staggered set display; no studio scene is baked onto the body'],dict(w=16.8*factor,h=22.5*factor,d=h*64,official={'each_approximate_height_cm':h*100,'pieces':6},estimated=['each_width_cm','each_depth_cm','cord_length_cm','set_display_bounds_cm','colour_distribution_within_set'],note=f'Resmî tek yumurta yüksekliği yaklaşık{h*100:g}cm’dir. En/derinlik, askı, kat sayısı ve set yerleşimi fotoğraf tahminidir. Yalnız fotoğrafta görülen renkler kullanıldı; yalnız stil görselinde görülen set içi dağılım ayrıca yorumdur.',primary='',name='6’lı petek kâğıt Paskalya süsü',material='Gerçek açık petek yapılı boyalı kâğıt ve kumaş ip',color={'0746539012':'Yeşil tonları','0746539013':'Pembe/Sarı/Kırmızı','0746539015':'Sarı/Kırmızı/Yeşil ve krem çizgili','0746539016':'Sarı','1214591001':'Kahverengi/Yeşil/Krem','1214591002':'Pembe/Sarı/Kırmızı','1214591007':'Zeytin yeşili/Sarı/Tozlu pembe'}[pid],bundle=True,official_piece_dimensions_cm=[None,h*100,None])

def paper_finial_set(pid):
 count=4 if pid.startswith('1299165')else 2 if pid.startswith('1293863')or pid in['1355013001','1355013002','1355013003','1355013004','0429934017']else 6 if pid=='1293864004'else 12
 if count==4:
  shapes=['four_tier','four_spindle','four_double','four_flange'];hs=[.105]*4;ws=[.052,.054,.052,.040];c={'1299165001':[235,225,190],'1299165002':[26,57,38],'1299165004':[142,87,55]}[pid];alts=False;gold=True;official={'decoration_height_cm':10.5,'pieces':4};color={'1299165001':'Krem','1299165002':'Koyu yeşil','1299165004':'Kahverengi'}[pid]
 elif pid in['1293863008','1293863005']:
  shapes=['onion','finial'];hs=[.07,.08];ws=[.067,.062];c=[105,59,35]if pid=='1293863008'else[15,47,31];alts=False;gold=True;official={'small_height_cm':7,'large_height_cm':8,'pieces':2};color='Kahverengi'if pid=='1293863008'else'Yeşil'
 elif pid in['1355013001','1355013002','1355013003','1355013004']:
  shapes=['candy_cylinder','candy_round'];hs=[.077,.074];ws=[.032,.038];c=[29,65,43]if pid=='1355013002'else[174,22,33]if pid in['1355013001','1355013003']else[235,225,195];alts=pid in['1355013001','1355013002'];gold=True;official={'width_range_cm':[3.2,3.8],'pieces':2};color=('Yeşil/Krem'if pid=='1355013002'else'Kırmızı/Krem')if alts else'Kırmızı'if pid=='1355013003'else'Krem'
 elif pid=='0429934017':
  shapes=['diamond','onion'];hs=[.095,.090];ws=[.09,.09];c=[24,29,27];alts=False;gold=True;official={'nominal_body_diameter_cm':9,'pieces':2};color='Siyah/Altın rengi'
 elif pid=='1293864004':
  shapes=['set_spool','set_onion','set_ufo','set_urn','set_fan','set_lantern'];hs=[.047,.048,.052,.052,.041,.045];ws=[.043,.044,.050,.043,.049,.041];c=[151,14,32];alts=False;gold=True;official={'smallest_height_cm':4.1,'largest_height_cm':5.2,'pieces':6};color='Kırmızı'
 else:
  shapes=['set_spool','set_urn','set_onion','set_fan','set_lantern','set_ufo']*2;hs=[.045,.050,.047,.045,.043,.044]*2;ws=[.050,.040,.050,.043,.047,.039]*2;c=[233,225,199]if pid=='1354975001'else[159,22,40];alts=pid=='1354975003';gold=True;official={'approximate_height_range_cm':[4,5],'pieces':12};color='Krem'if pid=='1354975001'else'Kırmızı/Krem/Altın rengi'
 mats=dict(paper=bank(pid+'-paper',c),edge=bank(pid+'-glitter-cut-edge',[166,139,68],'metal'),cord=bank(pid+'-cord',[184,158,90]))
 if pid=='1355013003':mats['cord']=bank(pid+'-red-cord',[166,24,34])
 if alts:mats['cream']=bank(pid+'-alternating-cream-paper',[238,230,201])
 cols=min(6,count);spacing=max(ws)*1.38;rows=math.ceil(count/cols);p=[]
 for i,(shape,h,w)in enumerate(zip(shapes,hs,ws)):
  cx=(i%cols-(cols-1)/2)*spacing;cy=(rows-1-i//cols)*(max(hs)+.070);p+=paper_body('individual-'+str(i+1)+'-'+shape,'paper',w,h,shape,cx,cy,leaves=32,alt_mat='cream'if alts else None,edge_mat='edge'if gold else None,twist=.22 if pid=='0429934017'else 0);p.append(ribbon_loop('gold-cotton-hanger-'+str(i+1),'cord',cx,cy+h,.060 if count>2 else .075,.00035))
 note='Resmî ölçü etiketi: '+json.dumps(official,ensure_ascii=False)+'. Gövde formları bu SKU’nun orijinal fotoğrafına göre ayrı kuruldu. Askılar, kat sayısı, en/derinlik ve setin ortak yerleşimi fotoğraf tahminidir; aralık verilen ürünlerde tek tek biçimlere boy ataması resmî ayrı etiket değildir.'
 if False:note+=' Aynı gerçek SKU’nun resmî GB galerisinde kırmızı/krem çizgili ürün doğrulandı; TR kategori kartı eski kahverengi kutu fotoğrafı taşıyor. Bu renk farkı ayrıca doğrulama bekliyor.'
 return p,mats,['Every set member has its own curved finial/lantern/candy profile, not repeated spheres','Individually closed thin radial paper leaves leave genuine open interior channels','Fine glitter follows only the real cut edges; hangers are separate physical loops'],dict(w=count*spacing*100,h=(max(hs)+.075)*100,d=max(ws)*100,official=official,estimated=['individual_axes_not_explicitly_labelled','paper_thickness_mm','hanging_loop_size_cm','set_display_bounds_cm'],note=note,primary={'1354975001':'fffe3bc2f9b7','1354975003':'e69925f76c62','1293864004':'22c8fdddfcc4','1293863005':'c0e0e406a29c','1355013003':'3ff9ff25dc15','1355013002':'9f235a98d18c','1355013001':'a6d2192e70df'}.get(pid,''),name=str(count)+'’li petek kâğıt yılbaşı süsü',material='Açık petek kâğıt, simli kesim kenarları ve kumaş askı',color=color,bundle=True,quality_note='')

def bunny_pair():
 pid='1044644001';p=[];mats=dict(paper=bank(pid+'-cream-paper',[234,225,197]),cord=bank(pid+'-jute',[173,147,101]))
 for k in range(2):
  start=len(p);cx=(k-.5)*.085;cy=.013*k;p+=paper_body('honeycomb-bunny-'+str(k+1),'paper',.060,.082,'bunny',cx,cy,32)
  for side in[-1,1]:
   ear=[(-.006,0),(-.005,.017),(0,.030),(.005,.017),(.006,0)];p.append(sheet('white-paper-bunny-ear-'+str((k,side)),'paper',ear,.00045,lambda x,y,z:(cx+side*.009+x+side*y*.18,cy+.059+y,z-.0004)))
  for part in p[start:]:part['_vertices']=[(x,cy+(y-cy)*.09/.089,z)for x,y,z in part['_vertices']]
  p.append(ribbon_loop('jute-hanging-loop-'+str(k+1),'cord',cx,cy+.078,.069,.0006))
 return p,mats,['Two distinct rabbit silhouettes combine broad honeycomb bodies, smaller heads and real thin paired ears','Paper ears, open radial body folds and jute hangers are all separate physical geometry'],dict(w=15,h=16.2,d=6,official={'each_height_cm':9,'pieces':2},estimated=['each_width_cm','each_depth_cm','ear_split_and_local_shape','cord_length_cm','set_display_bounds_cm'],note='Resmî tek tavşan yüksekliği9cm’dir; kulak dahil gövde ölçeği buna göre kurulur. En/derinlik, açık kat yerleşimi ve jüt askı boyları fotoğraf tahminidir.',primary='',name='2’li tavşan biçimli petek kâğıt Paskalya süsü',material='Krem petek kâğıt ve jüt askı',color='Krem',bundle=True)

def pinecone_set():
 pid='1299133002';parts=[]
 for k in range(6):
  cx=(k%3-1)*.055;cy=(1-k//3)*.105;core=B.lathe('narrow-moulded-pinecone-core','silver',[(0,0),(.002,0),(.007,.010),(.013,.027),(.014,.040),(.010,.052),(.004,.058),(0,.060)],72,False);item=[core];scales=[]
  for row in range(9):
   y=.007+row*.0055;r=V.smooth_radius(y,[0,.01,.027,.04,.052,.06],[.002,.007,.013,.014,.010,.003]);n=7 if row<2 or row>6 else 9
   for j in range(n):
    a=T*(j+.5*(row%2))/n;outline=[(-.0045,0),(-.005,.002),(-.003,.005),(0,.006),(.003,.005),(.005,.002),(.0045,0),(0,-.002)]
    def mp(x,t,z):
     radial=r*.75+.0045*(1-t/.008)+z;return(radial*math.cos(a)+x*math.sin(a),y+t,radial*math.sin(a)-x*math.cos(a))
    scales.append(sheet('overlapping-moulded-cone-scale-'+str((row,j)),'silver',outline,.00065,mp))
  item.append(merge(scales,'nine-ranks-of-physical-overlapping-pinecone-scales','silver'));pos=np.concatenate([np.array(q['_vertices'])for q in item]);lo=pos.min(0);hi=pos.max(0);sc=np.array([.038,.060,.038])/(hi-lo);mid=np.array([(lo[0]+hi[0])/2,lo[1],(lo[2]+hi[2])/2])
  for q in item:q['_vertices']=[tuple((np.array(v)-mid)*sc+[cx,cy,0])for v in q['_vertices']]
  parts+=item;parts.append(ribbon_loop('fine-silver-thread-loop-'+str(k+1),'cord',cx,cy+.060,.049,.00035))
 mat=bank(pid+'-silver-glitter-polymer',[197,199,194],'tinsel');mat['metallic']=.9
 return parts,dict(silver=mat,cord=bank(pid+'-silver-cord',[201,203,198],'metal')),['Six own narrow pinecones, each calibrated to the official6cm height','Nine staggered ranks of moulded overlapping physical scales with real relief and a pointed lower tip','Silver glitter polymer appearance and separate thin hanging loops; packaging excluded'],dict(w=14.8,h=21.8,d=3.8,official={'each_height_cm':6,'pieces':6},estimated=['each_width_cm','each_depth_cm','scale_count_and_relief','hanging_loop_size_cm','set_display_bounds_cm'],note='Resmî tek kozalak gövdesi yüksekliği6cm korunur. En/derinlik3,8cm, pul dizilimi, sim dokusu ve ip boyları fotoğraf tahminidir; setin ortak dış zarfı resmî ölçü değildir.',primary='',name='6’lı gümüş simli çam kozalağı yılbaşı süsü',material='Gümüş simli polistiren gövde ve ince askı ipi',color='Gümüş rengi',bundle=True)

def swept_ribbon(name,mat,points,width=.032,th=.0008,tail=False):
 points=np.array(points,float);v=[];uv=[]
 for i,pt in enumerate(points):
  direction=points[min(i+1,len(points)-1)]-points[max(i-1,0)];direction/=np.linalg.norm(direction);across=np.cross(direction,[0,0,1]);across/=np.linalg.norm(across);normal=np.cross(across,direction);ww=width*(.65+.35*math.sin(math.pi*i/(len(points)-1)))if not tail else width
  for k,(u,z)in enumerate([(-1,-1),(1,-1),(-1,1),(1,1)]):v.append(tuple(pt+across*u*ww*.5+normal*z*th*.5));uv.append(((u+1)/2,i/(len(points)-1)*2))
 f=[]
 for i in range(len(points)-1):
  a=i*4;b=a+4
  for A,Bb,C,D in[(a,a+1,b,b+1),(a+2,b+2,a+3,b+3),(a,b,a+2,b+2),(a+1,a+3,b+1,b+3)]:f.extend([(A,Bb,C),(Bb,D,C)])
 for a in[0,(len(points)-1)*4]:f.extend([(a,a+2,a+1),(a+1,a+2,a+3)])
 return mesh(name,mat,v,f,uv)
def bow_woven_material(pid):
 source=R/'originals/1205343004-d492425c1b2b.jpg';out=R/'materials'/('woven-source-'+pid);out.mkdir(exist_ok=True,parents=True);im=Image.open(source).convert('RGB');box=[1250,1900,1510,2160];crop=im.crop(box);crop.save(out/'source-donor-crop.png');a=np.asarray(crop,np.float32);low=np.asarray(crop.filter(ImageFilter.GaussianBlur(15)),np.float32);detail=np.clip((a-low)*.60+np.array([188,190,191]),0,255).astype(np.uint8);q=Image.fromarray(detail).resize((1024,1024),Image.Resampling.LANCZOS);tile=Image.new('RGB',(2048,2048));tile.paste(q,(0,0));tile.paste(q.transpose(Image.Transpose.FLIP_LEFT_RIGHT),(1024,0));tile.paste(q.transpose(Image.Transpose.FLIP_TOP_BOTTOM),(0,1024));tile.paste(q.transpose(Image.Transpose.ROTATE_180),(1024,1024));tile.save(out/'albedo-2k.png');h=np.mean(np.asarray(tile,np.float32),2)/255;dy,dx=np.gradient(h*4);nn=np.stack([-dx,dy,np.ones_like(h)],2);nn/=np.linalg.norm(nn,axis=2,keepdims=True);Image.fromarray(np.clip((nn+1)*127.5,0,255).astype(np.uint8)).save(out/'normal-2k.png');orm=np.zeros((2048,2048,3),np.uint8);orm[:,:,0]=255;orm[:,:,1]=160;orm[:,:,2]=95;Image.fromarray(orm).save(out/'orm-2k.png');dump(out/'donor-edit-stack.json',dict(master=str(source),master_sha256=sha(source),master_pixels=list(im.size),crop_box_original_pixels=box,operations=['Crop only same-product woven fabric','Subtract low-frequency photographic lighting from donor weave','Set intrinsic silver-grey mean; preserve measured high-frequency woven detail','Lanczos resample and mirrored repeat to2K'],effective_donor_pixels=list(crop.size),generated_pixels=False,source_master_unchanged=True))
 return dict(baseColorTexture=str(out/'albedo-2k.png'),normalTexture=str(out/'normal-2k.png'),metallicRoughnessTexture=str(out/'orm-2k.png'),metallic=1,roughness=1,normalScale=.65,doubleSided=False,alphaMode='OPAQUE',extras=dict(native_resolution=2048,photo_pixels_baked=True,photo_donor_surface_only=True,baked_reflections=False,material_kind='woven_silver_polyester'))
def bow_cloth(name,side,tail=False):
 nu,nv=70,26;v=[];uv=[];f=[]
 for layer in[-1,1]:
  for i,u in enumerate(np.linspace(0,1,nu)):
   for j,t in enumerate(np.linspace(-1,1,nv)):
    if not tail:
     x=side*(.005+.055*u);hh=.008+.019*u**.55;y=.112+t*hh;z=.001+(.016*math.sin(math.pi*u)**.8+.004*math.sin(t*math.pi*2)*(1-u))*math.cos(t*math.pi/2)
    else:
     y=.106-.103*u+.018*((t+1)/2)*u**9;x=side*(.017+.008*u+.017*t);z=.004+.005*math.sin(math.pi*u)+.0015*math.sin(t*math.pi)
    v.append((x,y,z+layer*.00045));uv.append((i/(nu-1)*1.7,(t+1)/2))
 N=nu*nv
 for i in range(nu-1):
  for j in range(nv-1):
   a=i*nv+j;b=a+nv;f.extend([(a,a+1,b),(a+1,b+1,b),(N+a,N+b,N+a+1),(N+a+1,N+b,N+b+1)])
 boundary=list(range(nv))+[i*nv+nv-1 for i in range(1,nu)]+list(range((nu-1)*nv+nv-2,(nu-1)*nv-1,-1))+[i*nv for i in range(nu-2,0,-1)]
 for i,a in enumerate(boundary):b=boundary[(i+1)%len(boundary)];f.extend([(a,N+a,b),(b,N+a,N+b)])
 return mesh(name,'velvet',v,f,uv)
def velvet_bow():
 pid='1205343004';parts=[]
 for side in[-1,1]:parts +=[bow_cloth('broad-square-ended-gathered-woven-loop-'+str(side),side),bow_cloth('long-diagonally-cut-woven-ribbon-tail-'+str(side),side,True)]
 parts.append(ball('soft-centre-woven-knot','velvet',(0,.110,.008),.007,.011,.006,40,28));pos=np.concatenate([np.array(q['_vertices'])for q in parts]);lo=pos.min(0);hi=pos.max(0);mid=np.array([(lo[0]+hi[0])/2,lo[1],(lo[2]+hi[2])/2]);sc=np.array([.12,.145,.026])/(hi-lo)
 for q in parts:q['_vertices']=[tuple((np.array(v)-mid)*sc)for v in q['_vertices']]
 parts.append(ribbon_loop('fine-silver-hanging-thread','cord',0,.145,.070,.0004));mat=bow_woven_material(pid)
 return parts,dict(velvet=mat,cord=bank(pid+'-silver-thread',[185,186,180],'metal')),['Broad square-ended woven cloth loops gather towards a soft centre knot','Real cloth thickness and three-dimensional folds; diagonally cut long tails follow own source','Same-product2K donor preserves the silver woven grain without photographic lighting or background'],dict(w=12,h=21.7,d=2.6,official={'bow_width_cm':12,'bow_height_cm':14.5},estimated=['bow_depth_cm','local_ribbon_width_cm','hanging_loop_size_cm'],note='Resmî fiyonk gövdesi genişliği12cm ve yüksekliği14,5cm korunur. Derinlik2,6cm, yerel dokuma kumaş kıvrımları ve askı ipi boyu fotoğraf tahminidir; askı dahil yükseklik resmî gövde ölçüsü değildir.',primary='dc86d64bc102',name='Gümüş grisi dokuma fiyonk yılbaşı ağacı süsü',material='Gümüş grisi dokuma kumaş ve ince askı ipi',color='Gümüş rengi')

def plastic_pair():
 pid='1359291001';parts=[];offsets=[-.036,.036];star=[];cx=offsets[0];r=.021;outline=[]
 for j in range(24):
  a=math.pi/2+T*j/24;rr=r*(1 if j%4 in[0,1]else .78);outline.append((rr*math.cos(a),rr*math.sin(a)))
 v=[(x,y,.0007)for x,y in outline]+[(x,y,-.002)for x,y in outline]+[(0,0,.0045)];f=[]
 for j in range(24):n=(j+1)%24;f.extend([(48,j,n),(24,j+24,n+24),(j,j+24,n),(n,j+24,n+24)])
 # Reverse face uses a fan centre distinct from the perimeter.
 v.append((0,0,-.002))
 f=[q for q in f if len(set(q))==3]
 f=[q for q in f if q[0]!=24]
 for j in range(24):f.append((49,(j+1)%24+24,j+24))
 raw=mesh('six-lobed-chrome-plastic-snowflake-with-convex-front','silver',v,f,flat=True);raw['_vertices']=[(x+cx,y+.022,z)for x,y,z in raw['_vertices']];parts.append(raw)
 ribs=[]
 for k in range(6):
  a=math.pi/2+T*k/6;unit=np.array([math.cos(a),math.sin(a),0]);cross=np.array([-math.sin(a),math.cos(a),0]);start=np.array([cx,.022,.0048]);ribs.append(tube('raised-snowflake-stem-'+str(k),'glitter',[start,start+unit*.018],.00048,6))
  for t in[.008,.013]:
   for side in[-1,1]:root=start+unit*t;ribs.append(tube('raised-snowflake-branch-'+str((k,t,side)),'glitter',[root,root+unit*.004+cross*.0038*side],.00042,6))
 parts+=ribs;parts.append(B.cylinder('snowflake-ornament-cap','silver',.0035,.043,.049,offset=(cx,0,0),n=36));parts.append(hanging_eye('snowflake-connector-eye','silver',cx,.052,.003));parts.append(ribbon_loop('snowflake-silver-hanger','cord',cx,.055,.077,.0004))
 cx=offsets[1];boots=[]
 for side in[-1,1]:
  bx=cx+side*.010;boots.append(ball('rounded-shoe-toe-'+str(side),'silver',(bx,.007,.007),.009,.007,.014,32,20));profile=[(0,.009),(.006,.009),(.007,.019),(.007,.037),(.0085,.042),(.0085,.045),(.0065,.045),(.0055,.042),(.0055,.019),(0,.019)];boots.append(B.lathe('physical-boot-shaft-and-open-cuff-'+str(side),'silver',profile,64,False,offset=(bx,0,0)))
  for a,b in[(-1,1),(1,-1)]:boots.append(tube('crossed-raised-boot-strapping-'+str((side,a)), 'glitter',[(bx+a*.006,.016,.014),(bx+b*.006,.033,.009)],.00065,6))
  boots.append(tube('sparkling-boot-sole-border-'+str(side),'glitter',[(bx+.009*math.cos(t),.003,.007+.014*math.sin(t))for t in np.linspace(0,T,70,endpoint=False)],.00065,6,True))
 parts+=boots;parts.append(B.cylinder('boot-pair-central-cap','silver',.0035,.043,.049,offset=(cx,0,0),n=36));parts.append(hanging_eye('boots-connector-eye','silver',cx,.052,.003));parts.append(ribbon_loop('boots-silver-hanger','cord',cx,.055,.077,.0004))
 for part in parts:
  if part['material']=='cord':part['_vertices']=[(x,y-.005,z)for x,y,z in part['_vertices']]
  else:part['_vertices']=[(x,y*.05/.05575,z)for x,y,z in part['_vertices']]
 mat=bank(pid+'-silver-polymer',[223,225,220],'metal');glitter=bank(pid+'-silver-glitter',[194,197,191],'tinsel')
 return parts,dict(silver=mat,glitter=glitter,cord=bank(pid+'-silver-cord',[196,198,193],'metal')),['One actual raised six-lobed snowflake and one paired-boot figurine; both remain parts of one official two-piece set','Snowflake branching veins, convex chrome relief, real boot feet/shafts/cuffs and crossed raised boot straps','Physical separate caps and silver hanging loops; no generic bauble substitutes'],dict(w=11.5,h=13.4,d=3.4,official={'approximate_height_range_cm':[3,5],'pieces':2},estimated=['per_design_height_assignment','all_width_and_depth_axes','raised_moulded_detail','hanger_length_cm','set_display_bounds_cm'],note='Resmî yükseklik etiketi tasarıma bağlı yaklaşık3–5cm aralığı verir. Kar tanesi ve çift botun tek tek eksenleri, kabartma, kapak ve askı boyu fotoğraf tahminidir; üretici her tasarım için ayrı kesin ölçü vermedi.',primary='',name='2’li gümüş renkli kar tanesi ve bot yılbaşı süsü',material='Gümüş görünümlü kalıplanmış plastik, simli kabartma ve kumaş askı',color='Gümüş rengi',bundle=True)

def caviar_tin():
 pid='1299157015';p=[];cy=.038;body=B.lathe('actual-round-glass-tin-with-closed-reverse-recessed-face-and-raised-rim','silver',[(0,-.010),(.031,-.010),(.034,-.008),(.035,-.005),(.035,.004),(.033,.007),(.030,.007),(.029,.003),(0,.003)],160,False);body['_vertices']=[(x,cy+z*.038/.035,y)for x,y,z in body['_vertices']];p.append(body)
 semi=[(.030*math.cos(t),cy+.033*math.sin(t))for t in np.linspace(-math.pi/2,math.pi/2,100)];plate=sheet('separate-right-half-tin-lid-with-real-perimeter-wall','lid',semi,.0012,lambda x,y,z:(x,y,.007+z));plate['_uvs']=[(.5+x/.07,y/.076)for x,y,z in plate['_vertices']];p.append(plate)
 for r in[.025,.020]:p.append(tube('embossed-half-lid-concentric-ridge-'+str(r),'silver',[(r*math.cos(t),cy+r*1.1*math.sin(t),.008)for t in np.linspace(-math.pi/2,math.pi/2,100)],.00045,6))
 # A dense bed of actual black seed beads with tiny visible holes, matching the photographed caviar side.
 rng=np.random.default_rng(1299157);beads=[]
 p.append(sheet('dark-recess-beneath-densely-packed-caviar-beads','beads',[(.0295*math.cos(t),cy+.0325*math.sin(t))for t in np.linspace(math.pi/2,3*math.pi/2,120)],.0007,lambda x,y,z:(x,y,.004+z)))
 for i in range(900):
  while True:
   x=rng.uniform(-.029,-.001);y=rng.uniform(-.032,.032)
   if (x/.029)**2+(y/.032)**2<.95:break
  rad=rng.uniform(.0007,.0009);loop=[(x+rad*math.cos(t),cy+y+rad*math.sin(t),.0045+rng.uniform(0,.0005))for t in np.linspace(0,T,12,endpoint=False)];beads.append(tube('black-glass-seed-bead-'+str(i),'beads',loop,rad*.60,5,True))
 p.append(merge(beads,'three-dimensional-black-caviar-seed-bead-bed','beads'));p.append(swept_ribbon('actual-spoon-handle-along-centre-of-tin','silver',[(.001,.012,.013),(.002,.024,.013),(.002,.052,.012),(.002,.070,.010)],.0023,.0008,True));p.append(ball('actual-spoon-bowl-at-the-lower-edge','silver',(.001,.007,.013),.0063,.008,.0019,40,22));p.append(B.cylinder('chrome-ornament-neck-and-cap','silver',.0054,.072,.083,n=48));p.append(hanging_eye('actual-thin-metal-connector-eye','silver',0,.088,.0045));
 # Calibrate the complete ornament body, cap, eye and spoon to the official7×9.5cm face bounds.
 vv=np.concatenate([np.array(q['_vertices'])for q in p]);lo=vv.min(0);hi=vv.max(0);mid=np.array([(lo[0]+hi[0])/2,lo[1],(lo[2]+hi[2])/2]);scale=np.array([.07,.095,.029])/(hi-lo)
 for q in p:q['_vertices']=[tuple((np.array(v)-mid)*scale)for v in q['_vertices']]
 p.append(ribbon_loop('long-silver-hanging-cord','cord',0,.095,.105,.00035));silver=bank(pid+'-silver-glass',[226,228,222],'metal');black=bank(pid+'-black-caviar-beads',[16,17,18],'glass');black['metallic']=.2;black['roughness']=.65
 lid=bank(pid+'-embossed-lid',[226,228,222],'metal');emboss_caviar(lid)
 return p,dict(silver=silver,lid=lid,beads=black,cord=bank(pid+'-silver-cord',[184,187,180],'metal')),['Actual circular caviar-tin ornament, recessed black seed-bead half and raised silver half lid','Physical concentric lid relief and an actual small spoon along the centre','Full neck, cap, wire eye and long separate hanging cord; no photographed studio reflections baked'],dict(w=7,h=20.1,d=2.9,official={'ornament_width_cm':7,'ornament_height_cm':9.5},estimated=['ornament_depth_cm','bead_count','spoon_and_lid_relief','hanger_length_cm'],note='Resmî süs gövdesi7×9,5cm korunur; derinlik2,9cm, boncuk/kaşık/kapak kabartması ve ip boyu fotoğraf tahminidir. Kapaktaki caviar yazısı ayrı2K kabartma normal haritasıyla korunur; harf biçimi ve yerleşimi fotoğraftan yorumlandı.',primary='',name='Havyar kutusu ve kaşık biçimli cam yılbaşı süsü',material='Gümüş renkli cam, siyah cam boncuk görünümlü havyar ve ince askı',color='Gümüş rengi/Siyah',quality_note='Kapak yazısının karakter biçimi ve kabartması fotoğraftan yorumlandı.')

def emboss_caviar(mat):
 n=2048;mask=Image.new('L',(n,n));font=ImageFont.truetype('/System/Library/Fonts/Supplemental/Times New Roman.ttf',170)
 for char,theta in zip('caviar',np.linspace(.82,-.82,6)):
  tile=Image.new('L',(330,330));draw=ImageDraw.Draw(tile);box=draw.textbbox((0,0),char,font=font);draw.text(((330-(box[2]-box[0]))/2-box[0],(330-(box[3]-box[1]))/2-box[1]),char,font=font,fill=255);tile=tile.rotate(math.degrees(theta)-90,Image.Resampling.BICUBIC);x=int(n*(.5+.31*math.cos(theta)));y=int(n*(.5-.34*math.sin(theta)));mask.paste(tile,(x-165,y-165),tile)
 h=np.asarray(mask.filter(ImageFilter.GaussianBlur(.5)),np.float32)/255;dy,dx=np.gradient(h*3.6);normal=np.stack([-dx,dy,np.ones_like(dx)],2);normal/=np.linalg.norm(normal,axis=2,keepdims=True);Image.fromarray(np.clip((normal+1)*127.5,0,255).astype(np.uint8)).save(mat['normalTexture']);mat['normalScale']=.8;folder=Path(mat['normalTexture']).parent;mask.save(folder/'caviar-lettering-height-mask.png');dump(folder/'lettering-evidence.json',dict(source_word='caviar',source_photo=str(R/'originals/1299157015-1f12bbda3c20.jpg'),source_photo_sha256=sha(R/'originals/1299157015-1f12bbda3c20.jpg'),font_form_photo_interpreted=True,operations=['Literal source lettering typeset along the lid arc','Normal relief derived from a local height mask; no photographic reflection or background baked'],source_master_unchanged=True))

def radial_paper_honeycomb(name,mat,width,height,cx=0,cy=0,leaves=36):
 parts=[];ny,nr=70,9
 for j in range(leaves):
  v=[];uv=[];f=[];angle=T*j/leaves
  for layer in[-1,1]:
   for i,t in enumerate(np.linspace(0,1,ny)):
    rad=V.smooth_radius(float(t),[0,.08,.22,.45,.70,.88,1],[.34,.43,.50,.50,.43,.25,.012])*width
    for k,u in enumerate(np.linspace(0,1,nr)):
     a=angle+(-1)**j*(math.pi/leaves)*math.cos(t*math.pi*4)*math.sin(u*math.pi/2);rr=.0004+u*rad;z=layer*.00009;v.append((cx+rr*math.cos(a)-z*math.sin(a),cy+t*height,rr*math.sin(a)+z*math.cos(a)));uv.append((u,t))
  N=ny*nr
  for i in range(ny-1):
   for k in range(nr-1):a=i*nr+k;b=a+nr;f.extend([(a,b,a+1),(a+1,b,b+1),(N+a,N+a+1,N+b),(N+a+1,N+b+1,N+b)])
  boundary=list(range(nr))+[i*nr+nr-1 for i in range(1,ny)]+list(range((ny-1)*nr+nr-2,(ny-1)*nr-1,-1))+[i*nr for i in range(ny-2,0,-1)]
  for k,a in enumerate(boundary):b=boundary[(k+1)%len(boundary)];f.extend([(a,N+a,b),(b,N+a,N+b)])
  parts.append(mesh(name+'-individual-curved-honeycomb-sheet-'+str(j),mat,v,f,uv,True))
 return parts # Closed sheets touch only at physical glue rows; retain separate solids.
def yellow_bunny():
 pid='1319423002';p=radial_paper_honeycomb('standing-yellow-egg','paper',.10,.142)
 pos=np.concatenate([np.array(q['_vertices'])for q in p]);lo=pos.min(0);hi=pos.max(0)
 for q in p:q['_vertices']=[(x*.10/(hi[0]-lo[0]),y,z*.10/(hi[2]-lo[2]))for x,y,z in q['_vertices']]
 for side in[-1,1]:
  ear=[(-.011*math.sin(math.pi*t)**.70,.065*t)for t in np.linspace(0,1,35)]+[(.011*math.sin(math.pi*t)**.70,.065*t)for t in np.linspace(1,0,35)[1:-1]]
  p.append(sheet('two-softly-curved-paper-rabbit-ears-'+str(side),'paper',ear,.0005,lambda x,y,z:(side*.025+x+side*y*.30,.120+y,z)))
 return p,dict(paper=bank(pid+'-yellow',[240,189,49])),['A real open diamond honeycomb egg with elongated source silhouette','Two gently curved paper ears join the upper egg; no hanging loop added','Official widest10cm is applied to the egg body;14.2cm height scope is explicitly photo-interpreted'],dict(w=11,h=18.5,d=10,official={'widest_diameter_cm':10,'height_cm':14.2},estimated=['height_label_body_only_interpretation','overall_height_including_ears_cm','overall_width_including_ears_cm','ear_length_cm','sheet_thickness_mm','honeycomb_cell_size'],note='Resmî en geniş çap10cm gövdede korunur. Resmî14,2cm yüksekliğin kulaksız gövdeye uygulanması fotoğraf oranına dayalı ölçü yorumudur; kulak dahil18,5cm toplam yükseklik ve yaklaşık11cm toplam en tahmindir. Üretici yükseklik kapsamını ayrıca etiketlemedi.',primary='',name='Sarı tavşan kulaklı petek kâğıt Paskalya süsü',material='Sarı petek kâğıt ve ince kâğıt kulaklar',color='Sarı',quality_note='Resmî14,2cm yüksekliğin kulaksız gövdeye ait olduğu fotoğraftan yorumlandı; kulak dahil18,5cm toplam yükseklik tahmindir.')

def striped_green_pair():
 pid='1293863003';parts=[];mats=dict(paper=bank(pid+'-green',[26,62,41]),cream=bank(pid+'-cream',[235,224,185]),edge=bank(pid+'-glitter',[167,140,69],'metal'),cord=bank(pid+'-cord',[185,157,88]))
 for k,(h,w,shape)in enumerate([(.07,.067,'onion'),(.08,.062,'finial')]):
  cx=(k-.5)*.092;cy=.018*(1-k);parts+=paper_body('own-alternating-green-cream-'+str(k+1),'paper',w,h,shape,cx,cy,32,alt_mat='cream',edge_mat='edge');parts.append(ribbon_loop('gold-cord-'+str(k+1),'cord',cx,cy+h,.075,.00035))
 return parts,mats,['Two distinct source silhouettes, with green and cream paper leaves alternating physically','Actual gold glitter follows the cut edges; own two official heights are preserved'],dict(w=16,h=17,d=6.7,official={'small_height_cm':7,'large_height_cm':8,'pieces':2},estimated=['body_width_cm','body_depth_cm','hanging_loop_size_cm','set_display_bounds_cm'],note='Resmî küçük süs7cm, büyük süs8cm’dir. En/derinlik, askı ve set dış zarfı fotoğraf tahminidir. Yeşil/krem kâğıt sırası bu SKU’nun kendi resmî fotoğrafına bağlıdır.',primary='',name='2’li yeşil ve krem çizgili petek kâğıt yılbaşı süsü',material='Yeşil/krem kâğıt, simli kenarlar ve kumaş askı',color='Yeşil/Krem',bundle=True)
def star_row():
 pid='1354955001';parts=[];pitch=.085;fold=.32
 for k in range(7):
  c=(k-3)*pitch*math.cos(fold);z=0;outline=[]
  for j in range(16):a=math.pi/2+T*j/16;r=.0425 if j%2==0 else .012;outline.append((r*math.cos(a),.065+r*math.sin(a)))
  # Source is truly thin paper. Eight long pointed arms meet a narrow connecting neck.
  def mp(x,y,t):return(c+x*math.cos(fold),y,z+(-1)**k*x*math.sin(fold)+t)
  v=[mp(x,y,t)for t in[-.0002,.0002]for x,y in outline]+[mp(0,.065,-.0002),mp(0,.065,.0002)];f=[]
  for j in range(16):n=(j+1)%16;f.extend([(32,n,j),(33,16+j,16+n),(j,n,16+j),(n,16+n,16+j)])
  raw=mesh('eight-point-folded-standing-star-'+str(k+1),'paper',v,f,flat=True);parts.append(raw)
  parts.append(sheet('real-star-stem-'+str(k+1),'paper',[(-.002,.014),(.002,.014),(.003,.035),(-.003,.035)],.00040,mp));parts.append(sheet('accordion-base-panel-'+str(k+1),'paper',[(-pitch/2,0),(pitch/2,0),(pitch/2,.014),(-pitch/2,.014)],.00040,mp))
  if k<6:parts.append(sheet('narrow-horizontal-star-bridge-'+str(k+1),'paper',[(.036,.061),(.049,.061),(.049,.065),(.036,.065)],.00040,mp))
 # The actual displayed width/height are calibrated to the labelled overall axes.
 pos=np.concatenate([np.array(q['_vertices'])for q in parts]);lo=pos.min(0);hi=pos.max(0);sc=np.array([.595,.11,1]) / np.array([hi[0]-lo[0],hi[1]-lo[1],1])
 for q in parts:q['_vertices']=[tuple(np.array(v)*sc)for v in q['_vertices']]
 mat=bank(pid+'-metallic-gold-paper',[183,156,83],'metal');mat['roughness']=.85
 return parts,dict(paper=mat),['Seven source-counted eight-point paper stars form a real standing accordion row','Separate physical narrow stems, horizontal links and zigzag base panels','Official59.5cm length and11cm height calibrated; fold depth is explicitly estimated'],dict(w=59.5,h=11,d=5.4,official={'height_cm':11,'length_cm':59.5},estimated=['fold_depth_cm','paper_thickness_mm','fold_angle_degrees','local_star_and_bridge_dimensions'],note='Resmî yükseklik11cm ve uzunluk59,5cm korunur. Kâğıt kalınlığı, zikzak açısı ve katlı derinlik fotoğraf tahminidir; tam açık/katlı uzunluk semantiği üretici tarafından ayrıca etiketlenmedi.',primary='1da012dd3011',name='Katlanabilir altın rengi yıldız sırası yılbaşı süsü',material='Metalik altın yüzeyli kalın kâğıt',color='Altın rengi')
def white_tassels():
 pid='1355097002';p=[];rng=np.random.default_rng(1355097)
 for k in range(2):
  cx=(k-.5)*.045;cy=.009*k;threads=[]
  for j in range(600):
   a=T*j/600;r=.0125*math.sqrt(rng.uniform(.03,1));pts=[]
   for t in np.linspace(0,1,14):
    rr=r*(.42+.58*t);pts.append((cx+rr*math.cos(a)+.00055*math.sin(t*4+a),cy+.080-.078*t+rng.uniform(-.0002,.0002),rr*math.sin(a)))
   threads.append(tube('individual-long-white-filament-'+str(j),'silk',pts,.000085,5))
  p.append(merge(threads,'hundreds-of-individual-white-tassel-threads-'+str(k+1),'silk'))
  pr=[(0,.078),(.006,.078),(.005,.081),(.006,.085),(.005,.089),(.006,.093),(.005,.096),(.006,.100),(.004,.104),(0,.106)];raw=B.lathe('three-soft-bulb-wrapped-neck-'+str(k+1),'silk',pr,96,False,offset=(cx,cy,0));p.append(raw)
  for yy in[.082,.090,.098]:
   for winding in range(5):p.append(tube('real-satin-waist-wrap-'+str((k,yy,winding)),'silk',[(cx+.0058*math.cos(a),cy+yy+winding*.00027,.0058*math.sin(a))for a in np.linspace(0,T,70,endpoint=False)],.0002,5,True))
  for strand in range(2):
   pts=[]
   for t in np.linspace(0,T,140,endpoint=False):
    x=.0014*math.sin(t);y=.106+.046*(1-math.cos(t))/2;theta=t*20+strand*math.pi;pts.append((cx+x+.00035*math.cos(theta),cy+y,.00035*math.sin(theta)))
   p.append(tube('twisted-double-cotton-hanger-'+str((k,strand)),'cord',pts,.00023,6,True))
 # Label height interpretation is explicit; width is applied to each tassel including fine fringes.
 allv=np.concatenate([np.array(q['_vertices'])for q in p]);lo=allv.min(0);hi=allv.max(0);s=.14/(hi[1]-lo[1])
 for q in p:q['_vertices']=[(x,(y-lo[1])*s,z)for x,y,z in q['_vertices']]
 return p,dict(silk=bank(pid+'-white-satin',[239,237,225],'satin'),cord=bank(pid+'-white-cord',[234,231,217],'satin')),['Two real tassels with600 individually modelled fine hanging textile strands each','Source-specific three wrapped neck sections and double twisted hanging cord','Door knob and styled room objects excluded'],dict(w=7,h=14,d=2.5,official={'height_cm':14,'width_cm':2.5,'pieces':2},estimated=['height_label_includes_hanging_loop_interpretation','body_depth_cm','thread_count_and_thickness','set_display_bounds_cm'],note='Resmî yükseklik14cm ve genişlik2,5cm’dir. Yüksekliğin askı dahil uygulanması, gövde/askı oranı, iplik sayısı, derinlik ve set yerleşimi fotoğrafa dayalı yorumdur.',primary='103dd8ed63e6',name='2’li beyaz iplikli yılbaşı püskülü',material='Beyaz polyester iplikler ve burgu askı',color='Beyaz',bundle=True)
def glass_candies(pid='1354985001'):
 p=[];clear=bank(pid+'-clear-glass',[252,251,243],'glass');clear.update(transmission=.97,ior=1.5,thickness=.0007,attenuationColor=[.98,.99,.99],attenuationDistance=.1,nativePreviewOpacity=.23);red=bank(pid+'-painted-band',[189,14,32]if pid=='1354985001'else[215,218,211]if pid=='1354985002'else[185,151,67],'glass'if pid=='1354985001'else'tinsel');red.update(transmission=.12 if pid=='1354985001'else 0,ior=1.5,clearcoat=.8);mats=dict(clear=clear,red=red,cord=bank(pid+'-white-cord',[239,237,229],'satin'))
 for k in range(2):
  cx=(k-.5)*.063;cy=.012*k;bodyh=.044;start=.023;center=cy+start+bodyh/2
  # Continuous solid glass shell, with flared wavy open-wrapper forms at both poles.
  p.append(ball('transparent-rounded-candy-centre-'+str(k+1),'clear',(cx,center,0),.020,.022,.020,160,90))
  for side in[-1,1]:
   v=[];uv=[];f=[];N=80;ny=34
   for inner in[False,True]:
    for i,t in enumerate(np.linspace(0,1,ny)):
     yy=center+side*(.021+.024*t);base=.004+.0128*t**.9
     for j in range(N+1):
      a=T*(j%N)/N+side*.8*t;r=base*(1+.16*t*math.cos(6*a))-(.0007 if inner else 0);v.append((cx+r*math.cos(a),yy,r*math.sin(a)));uv.append((j/N,t))
   M=ny*(N+1)
   for i in range(ny-1):
    for j in range(N):a=i*(N+1)+j;b=a+N+1;f.extend([(a,b,a+1),(a+1,b,b+1),(M+a,M+a+1,M+b),(M+a+1,M+b+1,M+b)])
   for i in[0,ny-1]:
    for j in range(N):a=i*(N+1)+j;f.extend([(a,a+1,M+a),(a+1,M+a+1,M+a)])
   p.append(mesh('wavy-twisted-clear-glass-wrapper-end-'+str((k,side)),'clear',v,f,uv))
  # Eight red helical paint strips follow this candy's own diagonal source pattern.
  for band in range(8):
   v=[];uv=[];f=[];ny,nx=52,8
   for layer in[0,1]:
    for i,t in enumerate(np.linspace(.025,.975,ny)):
     theta=math.pi*t;rr=.020*math.sin(theta)+layer*.000035;yy=center-.022*math.cos(theta)
     for j,u in enumerate(np.linspace(-1,1,nx)):
      a=band*T/8+1.6*(t-.5)+u*.155;v.append((cx+rr*math.cos(a),yy,rr*math.sin(a)));uv.append(((u+1)/2,t))
   M=ny*nx
   for i in range(ny-1):
    for j in range(nx-1):a=i*nx+j;b=a+nx;f.extend([(a,b,a+1),(a+1,b,b+1),(M+a,M+a+1,M+b),(M+a+1,M+b+1,M+b)])
   boundary=list(range(nx))+[i*nx+nx-1 for i in range(1,ny)]+list(range((ny-1)*nx+nx-2,(ny-1)*nx-1,-1))+[i*nx for i in range(ny-2,0,-1)]
   for j,a in enumerate(boundary):b=boundary[(j+1)%len(boundary)];f.extend([(a,M+a,b),(b,M+a,M+b)])
   p.append(mesh('own-diagonal-red-painted-candy-band-'+str((k,band)),'red',v,f,uv))
  p.append(ribbon_loop('white-thread-hanging-loop-'+str(k+1),'cord',cx,center+.045,.070,.00035))
 return p,mats,['Two actual rounded wrapped candies with separately flared twisted transparent glass ends','Eight diagonal painted or metallic bands physically follow each three-dimensional centre','No bowl, cutlery or styled-room objects are added'],dict(w=11,h=17.3,d=4,official={'each_width_cm':4,'each_height_cm':9,'pieces':2},estimated=['glass_depth_cm','glass_wall_thickness_mm','hanging_loop_length_cm','paint_strip_layout','set_display_bounds_cm'],note='Resmî tek cam şeker4×9cm’dir. Derinlik, cidar, ip ve renkli veya metalik kıvrımlı bantların gizli yüzlere devamı fotoğrafa dayalı yorumdur; askı ve set zarfı ayrıca tahmin olarak tutulur.',primary='4db33d728e8e'if pid=='1354985001'else'',name='2’li kırmızı çizgili cam şeker yılbaşı süsü'if pid=='1354985001'else'2’li gümüş çizgili cam şeker yılbaşı süsü'if pid=='1354985002'else'2’li altın çizgili cam şeker yılbaşı süsü',material='Boyalı veya metalik sim çizgili saydam cam; beyaz askı ipi',color='Kırmızı/Saydam'if pid=='1354985001'else'Gümüş rengi/Saydam'if pid=='1354985002'else'Altın rengi/Saydam',bundle=True)

def perforated_tree_panel(name,mapper):
 width=.056;bottom=.023;top=.110;outline=[(-.0035,.012),(.0035,.012),(.0035,bottom)]
 # Ten descending source-observed branch tiers create the actual cut pine silhouette.
 right=[(0,top)]
 for level in range(1,11):
  y=top-(top-bottom)*level/10;rad=width*.5*level/10;right.extend([(rad*.72,y+.0035),(rad,y),(rad*.55,y+.0005)])
 outline=[(-.0035,.012),(.0035,.012),(.0035,bottom)]+list(reversed(right))+[(-x,y)for x,y in right[1:]]+[(-.0035,bottom)]
 holes=[(0,.098,.0013),(-.004,.085,.0014),(.006,.077,.0013),(-.011,.067,.0015),(.001,.061,.0015),(.011,.053,.0016),(-.014,.045,.0017),(-.004,.038,.0012),(.015,.032,.0015),(.003,.028,.0014)]
 step=.00045;xs=np.arange(-.029,.029+step,step);ys=np.arange(.012,.111+step,step);v=[];uv=[];f=[];indices={};edge={}
 def inside(x,y):
  c=False
  for i,(a,b)in enumerate(outline):
   aa,bb=outline[i-1]
   if (b>y)!=(bb>y)and x<(aa-a)*(y-b)/(bb-b)+a:c=not c
  return c and not any((x-hx)**2+(y-hy)**2<r*r for hx,hy,r in holes)
 def vertex(ix,iy,side):
  key=(ix,iy,side)
  if key not in indices:indices[key]=len(v);v.append(mapper(xs[ix],ys[iy],side*.000175));uv.append((xs[ix]*10+.5,ys[iy]*10))
  return indices[key]
 mask=np.array([[inside((xs[ix]+xs[ix+1])/2,(ys[iy]+ys[iy+1])/2)for ix in range(len(xs)-1)]for iy in range(len(ys)-1)])
 # Resolve diagonal-only grid contacts so the physical paper perimeter remains manifold.
 for repeat in range(3):
  for iy in range(mask.shape[0]-1):
   for ix in range(mask.shape[1]-1):
    a,b,c,d=mask[iy,ix],mask[iy,ix+1],mask[iy+1,ix],mask[iy+1,ix+1]
    if a and d and not b and not c:mask[iy,ix+1]=True
    elif b and c and not a and not d:mask[iy,ix]=True
 for iy in range(len(ys)-1):
  for ix in range(len(xs)-1):
   if not mask[iy,ix]:continue
   corners=[(ix,iy),(ix+1,iy),(ix+1,iy+1),(ix,iy+1)];front=[vertex(x,y,1)for x,y in corners];back=[vertex(x,y,-1)for x,y in corners];f.extend([(front[0],front[1],front[2]),(front[0],front[2],front[3]),(back[0],back[2],back[1]),(back[0],back[3],back[2])])
   for i,a in enumerate(corners):b=corners[(i+1)%4];key=tuple(sorted((a,b)));edge[key]=(a,b)if key not in edge else None
 for item in edge.values():
  if item is None:continue
  a,b=item;af=vertex(*a,1);bf=vertex(*b,1);ab=vertex(*a,-1);bb=vertex(*b,-1);f.extend([(af,ab,bf),(bf,ab,bb)])
 return mesh(name,'paper',v,f,uv,True)
def cream_tree_row():
 pid='1354955003';p=[];count=9;pitch=.595/count;fold=.35
 for k in range(count):
  c=(k-(count-1)/2)*pitch*math.cos(fold)
  def mp(x,y,t):return(c+x*math.cos(fold),y,(-1)**k*x*math.sin(fold)+t)
  p.append(perforated_tree_panel('individual-real-perforated-paper-tree-'+str(k+1),mp));p.append(sheet('folded-base-panel-'+str(k+1),'paper',[(-pitch/2,0),(pitch/2,0),(pitch/2,.014),(-pitch/2,.014)],.00035,mp))
  if k<count-1:p.append(sheet('thin-connected-paper-branch-bridge-'+str(k+1),'paper',[(.020,.030),(.047,.030),(.047,.038),(.020,.038)],.00035,mp))
 pos=np.concatenate([np.array(q['_vertices'])for q in p]);span=pos.max(0)-pos.min(0)
 for q in p:q['_vertices']=[(x*.595/span[0],y*.11/span[1],z)for x,y,z in q['_vertices']]
 return p,dict(paper=bank(pid+'-cream-card',[235,229,207])),['Nine pine silhouettes counted against the full own official front photo','Actual circular cut holes go through closed thin paper; no painted holes','Continuous zigzag base, narrow trunks and real joining branch strips'],dict(w=59.5,h=11,d=3,official={'height_cm':11,'length_cm':59.5},estimated=['fold_depth_cm','fold_angle_degrees','paper_thickness_mm','local_perforation_size_and_branch_shape'],note='Resmî yükseklik11cm ve uzunluk59,5cm korunur. Kâğıt kalınlığı, kat derinliği ve yerel dal/delik ayrıntıları fotoğraf tahminidir; delikler gerçek açık geometridir.',primary='a1cb55bc8436',name='Katlanabilir krem kâğıt çam ağacı sırası yılbaşı süsü',material='Delikli krem kalın kâğıt',color='Krem')

def green_stripe_glass_material(pid):
 m=bank(pid+'-green-glitter-glass',[67,120,27],'glass');n=2048;u=np.arange(n)[None,:]/n;mask=np.broadcast_to(np.abs(np.sin(T*u*5))<.045,(n,n));a=np.asarray(Image.open(m['baseColorTexture'])).copy();a[mask]=[26,62,24];Image.fromarray(a).save(m['baseColorTexture']);orm=np.asarray(Image.open(m['metallicRoughnessTexture'])).copy();orm[:,:,1]=np.where(mask,150,35);orm[:,:,2]=0;Image.fromarray(orm).save(m['metallicRoughnessTexture']);m.update(transmission=.67,ior=1.5,thickness=.0008,attenuationColor=[.32,.64,.08],attenuationDistance=.02,clearcoat=.9,nativePreviewOpacity=.82);return m
def red_flake():
 p,m,f,s=snowflake('1244824002',.20);m=dict(paper=bank('1244824002-dark-red-paper',[126,18,35]),cord=bank('1244824002-burgundy-cord',[130,27,41]));s.update(primary='fe65936c6f49',name='Delikli ve katlanmış koyu kırmızı kâğıt kar tanesi süsü',material='Kalın koyu kırmızı kâğıt',color='Koyu kırmızı');body=np.array(p[0]['_vertices']);s['body_dimensions_cm']=(body.max(0)-body.min(0)).tolist();s['body_dimensions_cm']=[x*100 for x in s['body_dimensions_cm']];s['d']=s['body_dimensions_cm'][2];return p,m,f,s

def orb_material(pid,swirl=False):
 silver=pid in['1354994001','1355065006'];m=bank(pid+'-own-glass-finish',[222,224,218]if silver else[235,234,218],'metal'if silver else'satin');n=2048;rng=np.random.default_rng(int(pid));a=np.asarray(Image.open(m['baseColorTexture']),np.float32).copy();orm=np.asarray(Image.open(m['metallicRoughnessTexture'])).copy();orm[:,:,2]=255 if silver else 20;orm[:,:,1]=50 if silver else 65
 if swirl:
  v=np.arange(n)[:,None]/n;u=np.arange(n)[None,:]/n;turns=16 if pid in['1355065002','1355065003']else 7;phase=(v*turns-u)%1;mask=phase<(.29 if pid in['1355065002','1355065003']else .48)
  if pid in['1355065002','1355065003']:a[:]=[188,18,35]if pid=='1355065002'else[94,126,44];a[mask]=[241,236,221];orm[:,:,2]=0;orm[:,:,1]=40
  else:a[mask]=[209,212,205];orm[:,:,1]=np.where(mask,160,30);a+=rng.normal(0,3,(n,n,1))
 else:
  cloud=np.asarray(Image.fromarray(rng.random((80,80)).astype(np.float32),'F').resize((n,n),Image.Resampling.BICUBIC));a+=np.stack([np.sin(cloud*10)*4,np.cos(cloud*8)*3,np.sin(cloud*7+1)*5],2)
 Image.fromarray(np.clip(a,0,255).astype(np.uint8)).save(m['baseColorTexture']);Image.fromarray(orm).save(m['metallicRoughnessTexture']);m.update(transmission=0 if silver else .20,ior=1.5,thickness=.0008,clearcoat=.9,clearcoatRoughness=.05);return m
def spherical_ornament(pid):
 swirl=pid.startswith('1355065');silver=pid in['1354994001','1355065006'];p=[];h=.08;r=.04
 pr=[(0,0)]+[(r*math.sin(a),h*(1-math.cos(a))*.5)for a in np.linspace(.01,math.pi-.01,100)]+[(0,h)]+[(max(.0001,r*math.sin(a)-.0008),.0008+(h-.0016)*(1-math.cos(a))*.5)for a in np.linspace(math.pi-.01,.01,100)]+[(0,.0008)];p.append(B.lathe('hollow-source-round-glass-body','glass',pr,192,False))
 if not swirl:
  rng=np.random.default_rng(int(pid));bumps=[]
  for i in range(1000):
   yy=rng.uniform(-1,1);a=rng.uniform(0,T);rr=math.sqrt(1-yy*yy);normal=np.array([rr*math.cos(a),yy,rr*math.sin(a)]);pt=normal*.0397+[0,.04,0];size=rng.uniform(.00024,.00056);bumps.append(ball('raised-individual-glass-surface-droplet-'+str(i),'glass',pt,size,size,size,10,7))
  p.append(merge(bumps,'thousand-real-raised-textured-glass-droplets','glass'));allv=np.concatenate([np.array(q['_vertices'])for q in p]);sp=allv.max(0)-allv.min(0)
  for q in p:q['_vertices']=[(x*.08/sp[0],y,z*.08/sp[2])for x,y,z in q['_vertices']]
 mat=orb_material(pid,swirl);capmat=bank(pid+'-silver-cap',[193,198,188],'metal');cord=bank(pid+'-pale-velvet',[227,225,212],'satin');mats=dict(glass=mat,cap=capmat,cord=cord)
 if swirl:p.append(hanging_eye('integrated-glass-hanger-eye','glass',0,.084,.004))
 else:p.append(B.cylinder('real-stamped-silver-ornament-cap','cap',.0062,.078,.087,n=64));p.append(hanging_eye('small-metal-hanger-eye','cap',0,.089,.003))
 p.append(ribbon_loop('white-or-pale-velvet-hanging-loop','cord',0,.090,.075,.0012))
 return p,mats,['Real hollow round glass body with explicit0.8mm wall','Photo-specific spiral paint/glitter artwork carried by full2K material UV'if swirl else'One thousand actual small raised glass droplets cover the source-specific textured surface','Separate top connector, cap where photographed, and its own pale velvet hanger'],dict(w=8,h=16.7,d=8,official={'body_diameter_cm':8},estimated=['body_height_cm','glass_wall_thickness_mm','pattern_or_surface_droplet_layout','hanging_loop_size_cm'],note='Resmî cam gövde çapı8cm korunur. Gizli yüzlerde desen/doku devamı, yükseklik, cidar ve askı boyu fotoğraf tahminidir. Stüdyo yansımaları kaplamaya basılmadı.',primary={'1355065003':'4086526862aa','1355065002':'a02ee3f77e01','1355065006':'','1354994002':'9e5ff0fc93e9','1354994001':''}[pid],name='Yeşil/beyaz spiral cam yılbaşı süsü'if pid=='1355065003'else'Kırmızı/beyaz spiral cam yılbaşı süsü'if pid=='1355065002'else'Gümüş spiral cam yılbaşı süsü'if pid=='1355065006'else'Beyaz dokulu cam yılbaşı süsü'if pid=='1354994002'else'Gümüş dokulu cam yılbaşı süsü',material='Spiral desenli cam ve kadife askı'if swirl else'Kabarcıklı cam, metal kapak ve kadife askı',color='Yeşil/Beyaz'if pid=='1355065003'else'Kırmızı/Beyaz'if pid=='1355065002'else'Beyaz'if pid=='1354994002'else'Gümüş rengi')

def ski_goggle_pair(pid):
 p=[];gold=pid=='1359291004';cx=-.038
 for side in[-1,1]:
  # Narrow curved ski boards with real thickness and gently upturned tips.
  points=[(cx+side*.0035,.050*t,.0005+.0035*(max(0,(t-.78)/.22))**2)for t in np.linspace(0,1,70)];p.append(swept_ribbon('individual-rounded-upturned-ski-'+str(side),'metal',points,.0053,.0011,True));p.append(B.cylinder('small-raised-ski-binding-'+str(side),'metal',.0015,.018,.026,n=24,offset=(cx+side*.0035,0,.002)))
 for yy in[.010,.037]:p.append(tube('photographed-glitter-cross-ski-band-'+str(yy),'glitter',[(cx-.006,.000+yy,.0017),(cx+.006,yy+.001,.0017)],.0005,6))
 p.append(hanging_eye('ski-connector-eye','metal',cx,.052,.002));p.append(ribbon_loop('ski-hanging-thread','cord',cx,.054,.060,.0003));cx=.030
 outline=[]
 for theta in np.linspace(0,T,90,endpoint=False):
  xx=.022*math.copysign(abs(math.cos(theta))**.53,math.cos(theta));yy=.011+.010*math.copysign(abs(math.sin(theta))**.67,math.sin(theta))
  if yy<.011:yy+=.004*math.exp(-(xx/.0055)**2)
  outline.append((cx+xx,yy,.004-.003*(xx/.022)**2))
 n=len(outline);vv=outline+[(x,y,z-.0035)for x,y,z in outline]+[(cx,.011,.004),(cx,.011,.0005)];ff=[]
 for i in range(n):j=(i+1)%n;ff.extend([(2*n,i,j),(2*n+1,n+j,n+i),(i,n+i,j),(j,n+i,n+j)])
 p.append(mesh('single-wide-curved-ski-mask-visor-with-lower-nose-notch','metal',vv,ff));p.append(tube('continuous-rounded-ski-mask-frame','metal',outline,.0009,8,True));strap=[(cx+.022*math.cos(a),.011,-.003-.008*math.sin(a))for a in np.linspace(0,math.pi,100)];p.append(tube('three-dimensional-rear-goggle-strap','metal',strap,.0018,8));p.append(B.cylinder('goggle-neck','metal',.002,.020,.024,n=32,offset=(cx,0,0)));p.append(hanging_eye('goggles-connector-eye','metal',cx,.027,.0025));p.append(ribbon_loop('goggles-fine-hanging-thread','cord',cx,.030,.060,.0003))
 return p,dict(metal=bank(pid+'-coated-polymer',[177,149,75]if gold else[219,222,215],'metal'),glitter=bank(pid+'-silver-glitter',[225,224,213],'tinsel'),cord=bank(pid+'-coordinating-thread',[177,150,77]if gold else[191,196,185],'metal')),['Actual two-piece ski and goggle designs, not generic hanging baubles','Real paired upturned ski boards, bindings and glitter straps','One broad curved ski-mask visor with a rounded continuous frame, true lower nose notch and rear strap'],dict(w=11,h=11.4,d=2,official={'approximate_height_range_cm':[3,5],'pieces':2},estimated=['individual_design_height_assignment','all_width_and_depth_axes','coated_detail_and_hanging_loop_dimensions'],note='Resmî tasarıma bağlı yaklaşık3–5cm yükseklik aralığı korunur. Tek tasarıma boy ataması, en/derinlik, kayak bağları, gözlük arka kayışı ve askılar fotoğraf tahminidir; her tasarım için ayrı kesin ölçü yayımlanmadı.',primary='',name='2’li altın renkli kayak ve kayak gözlüğü süsü'if gold else'2’li gümüş renkli kayak ve kayak gözlüğü süsü',material='Metalik kaplı plastik, simli detaylar ve kumaş askı',color='Altın rengi'if gold else'Gümüş rengi',bundle=True)

def twisted_metal():
 pid='1354993004';v=[];uv=[];f=[];ny,nx=210,16
 for side in[-1,1]:
  for i,t in enumerate(np.linspace(0,1,ny)):
   r=.014*math.sin(math.pi*t)**.85+.00045;a=T*(3.3*t)
   for j,u in enumerate(np.linspace(-1,1,nx)):v.append((u*r*math.cos(a)-side*.00022*math.sin(a),t*.09,u*r*math.sin(a)+side*.00022*math.cos(a)));uv.append(((u+1)/2,t*3))
 N=ny*nx
 for i in range(ny-1):
  for j in range(nx-1):a=i*nx+j;b=a+nx;f.extend([(a,b,a+1),(a+1,b,b+1),(N+a,N+a+1,N+b),(N+a+1,N+b+1,N+b)])
 boundary=list(range(nx))+[i*nx+nx-1 for i in range(1,ny)]+list(range((ny-1)*nx+nx-2,(ny-1)*nx-1,-1))+[i*nx for i in range(ny-2,0,-1)]
 for i,a in enumerate(boundary):b=boundary[(i+1)%len(boundary)];f.extend([(a,N+a,b),(b,N+a,N+b)])
 p=[mesh('continuous-variable-width-polished-twisted-metal-blade','silver',v,f,uv)];p.append(hanging_eye('integrated-silver-hanging-eye','silver',0,.092,.0024));p.append(ribbon_loop('white-velvet-hanging-loop','velvet',0,.095,.080,.0011))
 return p,dict(silver=bank(pid+'-polished-silver',[220,223,215],'metal'),velvet=bank(pid+'-white-velvet',[231,230,217],'satin')),['One continuous thin metal blade twists into the actual open double-spiral spindle form','Variable width, fine tips, real edge thickness and a separate velvet hanger'],dict(w=3,h=17.7,d=3,official={'approximate_size_range_cm':[8,10]},estimated=['individual_design_length_cm','width_cm','depth_cm','metal_gauge_mm','twist_count','hanging_loop_length_cm'],note='Resmî etikette tasarıma bağlı yaklaşık8–10cm verilir; görünen metal tasarım9cm gövdeyle yorumlandı. En/derinlik, metal kalınlığı, burgu sayısı ve askı boyu fotoğraf tahminidir.',primary='',name='Burgu biçimli gümüş metal yılbaşı süsü',material='Parlak gümüş metal ve beyaz kadife askı',color='Gümüş rengi')

def straw_stars():
 pid='1355071001';p=[];mats={key:bank(pid+'-'+key,rgb)for key,rgb in [('straw0',[216,179,111]),('straw1',[231,203,151]),('straw2',[205,165,96]),('thread',[233,230,213])]} 
 for item in range(4):
  start=len(p);cx=(item%2-.5)*.090;cy=(1-item//2)*.125;flower=item in[0,3];strands=[];ties=[]
  for arm in range(6):
   a=math.pi/2+arm*T/6;unit=np.array([math.cos(a),math.sin(a),0]);perp=np.array([-math.sin(a),math.cos(a),0]);origin=np.array([cx,cy+.0325,0]);mat='straw'+str(arm%3)
   if flower:
    # Source flower has6 tied bundles and5 real cut straw lengths fanning from each bundle.
    knot=origin+unit*.017
    for j in range(5):
     angle=a+(j-2)*.13;end=origin+np.array([math.cos(angle),math.sin(angle),0])*(.0325-abs(j-2)*.0005);pts=[knot, .5*(knot+end)+[0,0,.00025],end];strands.append(B.tube('flat-straw-fanned-cut-length-'+str((arm,j)),mat,pts,.00020,.00072,7,False,guide=[0,0,1]))
    for side in[-1,1]:
     pts=[origin+unit*r+perp*side*.0035*math.sin(math.pi*(r-.003)/.014)+[0,0,.0003]for r in np.linspace(.003,.017,20)];strands.append(B.tube('folded-inner-flower-petal-'+str((arm,side)),mat,pts,.00021,.00072,7,False,guide=[0,0,1]))
   else:
    knot=origin+unit*.028
    for j in range(5):
     base=origin+unit*.004+perp*(j-2)*.0013;end=origin+unit*(.0325+(j%2)*.0004)+perp*(j-2)*.00065;pts=[base,(base+knot)*.5+[0,0,.00025],knot,end];strands.append(B.tube('individual-pointed-star-straw-splinter-'+str((arm,j)),mat,pts,.00019,.00067,7,False,guide=[0,0,1]))
   for winding in range(3):
    pts=[knot+perp*.0016*math.cos(t)+np.array([0,0,.00065*math.sin(t)])+unit*winding*.00035 for t in np.linspace(0,T,45,endpoint=False)];ties.append(tube('real-white-thread-bundle-binding-'+str((arm,winding)),'thread',pts,.00019,6,True))
  # The visible central white-thread hexagon joins the six arm bundles without a solid disc.
  pts=[(cx+.0095*math.cos(a),cy+.0325+.0095*math.sin(a),.0009)for a in np.linspace(0,T,6,endpoint=False)];ties.append(tube('open-central-white-thread-hexagon','thread',pts,.00023,6,True))
  p+=strands+ties;body=p[start:];pos=np.concatenate([np.array(q['_vertices'])for q in body]);lo=pos[:,1].min();hi=pos[:,1].max();sc=.065/(hi-lo)
  for q in body:q['_vertices']=[(cx+(x-cx)*sc,cy+(y-lo)*sc,z)for x,y,z in q['_vertices']]
  p.append(ribbon_loop('white-cotton-hanging-loop-'+str(item+1),'thread',cx,cy+.065,.070,.00065))
 return p,mats,['Four real straw ornaments: two six-point tied stars and two six-bundle sunburst flowers','Every straw splinter is a separate closed flattened strand; centre remains an open tied structure','Own-source white thread bindings and thin white hanging loops; no filled star-card substitute'],dict(w=17,h=26,d=.6,official={'nominal_each_height_cm':6.5,'approximate_design_height_range_cm':[6,7],'pieces':4},estimated=['straw_cross_section_mm','binding_thread_diameter_mm','hanger_length_cm','set_display_bounds_cm'],note='Resmî beden yüksekliği6,5cm ve tasarıma bağlı yaklaşık6–7cm aralığı korunur. Tek tek hasır en/kalınlığı, bağlama ipi, askı boyu ve dörtlü yerleşim fotoğraf tahminidir; iki yıldızın altı ucu kendi yakın planında doğrulandı.',primary='9130c3e4ab44',name='4’lü hasır yıldız ve kar tanesi yılbaşı süsü',material='Doğal hasır parçalar ve beyaz bağlama/askı ipi',color='Bej/Beyaz',bundle=True)

def tree_skirt_material():
 pid='1353729001';source=R/'originals/1353729001-ab6c8ceeb762.jpg';out=R/'materials'/('source-windowpane-'+pid);out.mkdir(parents=True,exist_ok=True);im=Image.open(source).convert('RGB');box=[570,1060,755,1235];patch=im.crop(box);patch.save(out/'same-product-one-windowpane-cell.png');a=np.asarray(patch,np.float32)
 # Only a clean interior fabric cell is used; no hole, slit, ties, wall or silhouette enters the texture.
 low=np.asarray(patch.filter(ImageFilter.GaussianBlur(25)),np.float32);a=np.clip(a-(low-low.mean((0,1)))*.35,0,255);tile=Image.fromarray(a.astype(np.uint8)).resize((2048,2048),Image.Resampling.LANCZOS);tile.save(out/'albedo-2k.png');gray=np.asarray(tile.convert('L'),np.float32)/255;micro=gray-np.asarray(tile.convert('L').filter(ImageFilter.GaussianBlur(6)),np.float32)/255;dy,dx=np.gradient(micro*1.8);nn=np.stack([-dx,-dy,np.ones_like(dx)],2);nn/=np.linalg.norm(nn,axis=2,keepdims=True);Image.fromarray(np.clip((nn+1)*127.5,0,255).astype(np.uint8)).save(out/'normal-2k.png');orm=np.zeros((2048,2048,3),np.uint8);orm[:,:,0]=255;orm[:,:,1]=235;Image.fromarray(orm).save(out/'orm-2k.png');dump(out/'donor-edit-stack.json',dict(master=str(source),master_sha256=sha(source),master_pixels=list(im.size),crop_box_original_pixels=box,effective_donor_pixels=list(patch.size),estimated_windowpane_pitch_cm=12,operations=['Interior same-product fabric cell crop, excluding white background and ties','Partial low-frequency lighting removal from the same crop','Small perspective aspect correction to a square repeating cell','Lanczos resample to2K; physical weave remains limited by donor resolution'],generated_pixels=False,source_master_unchanged=True))
 return dict(baseColorTexture=str(out/'albedo-2k.png'),normalTexture=str(out/'normal-2k.png'),metallicRoughnessTexture=str(out/'orm-2k.png'),metallic=1,roughness=1,normalScale=.55,doubleSided=False,extras=dict(native_resolution=2048,photo_pixels_baked=True,photo_donor_surface_only=True,baked_reflections=False,material_kind='own_windowpane_cotton'))
def little_spring_eggs():
 pid='1214591007';p=[];colors=[[214,166,34],[139,78,80],[90,100,47]];mats={'white':bank(pid+'-pale-paper-outer-leaves',[239,233,214]),'cord':bank(pid+'-white-cotton-hangers',[230,227,211])}
 for k,c in enumerate(colors):mats['paper'+str(k)]=bank(pid+'-own-dyed-paper-'+str(k),c)
 for egg in range(6):
  cx=(egg%3-1)*.0305;cy=(1-egg//3)*.0575;ny,nr,leaves=64,8,32;h=.035;width=.0224;groups={}
  for j in range(leaves):
   v=[];uv=[];f=[];angle=T*j/leaves+.10
   for layer in[-1,1]:
    for t in np.linspace(0,1,ny):
     radius=max(.00013,math.sin(math.pi*t)**.70*width*.5*(1-.11*math.cos(math.pi*t)))
     for u in np.linspace(0,1,nr):
      a=angle+(-1)**j*(math.pi/leaves)*math.cos(t*math.pi*4)*math.sin(u*math.pi/2);r=.00013+u*radius;z=layer*.000045;v.append((cx+r*math.cos(a)-z*math.sin(a),cy+t*h,r*math.sin(a)+z*math.cos(a)));uv.append((u,t))
   N=ny*nr
   for i in range(ny-1):
    for k in range(nr-1):a=i*nr+k;b=a+nr;f.extend([(a,b,a+1),(a+1,b,b+1),(N+a,N+a+1,N+b),(N+a+1,N+b+1,N+b)])
   edge=list(range(nr))+[i*nr+nr-1 for i in range(1,ny)]+list(range((ny-1)*nr+nr-2,(ny-1)*nr-1,-1))+[i*nr for i in range(ny-2,0,-1)]
   for i,a in enumerate(edge):b=edge[(i+1)%len(edge)];f.extend([(a,N+a,b),(b,N+a,N+b)])
   mat='white'if j%2 else'paper'+str(egg%3);groups.setdefault(mat,[]).append(mesh('thin-warped-honeycomb-leaf-'+str((egg,j)),mat,v,f,uv,True))
  for mat,parts in groups.items():p.append(merge(parts,'egg-'+str(egg+1)+'-actual-open-diamond-honeycomb-'+mat,mat))
  p.append(ribbon_loop('white-cotton-loop-'+str(egg+1),'cord',cx,cy+h,.045,.00020))
 return p,mats,['Six actual open diamond honeycomb eggs, with32 warped thin closed leaves each','Two yellow, two dusty pink and two olive eggs with pale alternating paper faces from this exactSKU photograph','Real fine white cotton hanging loops; source packaging and background excluded'],dict(w=8.4,h=13.8,d=2.24,official={'each_height_cm':3.5,'pieces':6},estimated=['each_width_cm','each_depth_cm','paper_lamella_and_cell_size','hanging_loop_size_cm','set_display_bounds_cm'],note='Resmî tek yumurta gövdesi yüksekliği3,5cm’dir. Yaklaşık2,24cm en/derinlik, petek hücreleri, açık renk kâğıt yüzleri, askı uzunluğu ve set yerleşimi fotoğraf tahminidir; askılar dahil grup dış zarfı resmî ölçü değildir.',primary='bca1206f0534',name='6’lı zeytin yeşili, sarı ve tozlu pembe petek Paskalya süsü',material='Gerçek açık petek kâğıt ve ince beyaz pamuk ip',color='Zeytin yeşili/Sarı/Tozlu pembe',bundle=True,official_piece_dimensions_cm=[None,3.5,None])

def cotton_tree_skirt():
 pid='1353729001';v=[];uv=[];f=[];nr,nt=48,288;ri=.050;ro=.600;gap=.007;th=.0008
 def height(x,z):return .003+.0010*math.sin(17*x+6*z)+.00065*math.cos(24*z-4*x)
 for layer in[-1,1]:
  for i,r in enumerate(np.linspace(ri,ro,nr)):
   start=-math.pi/2+math.asin(gap/r);end=3*math.pi/2-math.asin(gap/r)
   for j,t in enumerate(np.linspace(start,end,nt)):
    x=r*math.cos(t);z=r*math.sin(t);v.append((x,height(x,z)+layer*th/2,z));uv.append((x/.12,z/.12))
 N=nr*nt
 for i in range(nr-1):
  for j in range(nt-1):
   a=i*nt+j;b=a+nt;f.extend([(a,b,a+1),(a+1,b,b+1),(N+a,N+a+1,N+b),(N+a+1,N+b+1,N+b)])
 boundary=list(range(nt))+[i*nt+nt-1 for i in range(1,nr)]+list(range((nr-1)*nt+nt-2,(nr-1)*nt-1,-1))+[i*nt for i in range(nr-2,0,-1)]
 for i,a in enumerate(boundary):b=boundary[(i+1)%len(boundary)];f.extend([(a,N+a,b),(b,N+a,N+b)])
 p=[mesh('thin-round-woven-cotton-with-real-central-hole-and-parallel-radial-opening','cotton',v,f,uv)]
 # Separate narrow folded hems preserve the source perimeter, hole and slit construction.
 for name,r in [('outer-round-hem',ro-.002),('central-hole-hem',ri+.001)]:
  start=-math.pi/2+math.asin(gap/r);end=3*math.pi/2-math.asin(gap/r);pts=[(r*math.cos(t),height(r*math.cos(t),r*math.sin(t))+.0006,r*math.sin(t))for t in np.linspace(start,end,360)];p.append(B.tube(name,'binding',pts,.0010,.00045,8,False,guide=[0,1,0]))
 for side in[-1,1]:
  pts=[(side*(gap+.001),height(side*(gap+.001),-r)+.0006,-r)for r in np.linspace(ri,ro,150)];p.append(B.tube('sewn-slit-edge-'+str(side),'binding',pts,.0011,.00045,8,False,guide=[0,1,0]))
 for i,r in enumerate([.12,.32,.52]):
  z0=-r
  for side in[-1,1]:
   points=[(side*.048*math.sin(t),.015*math.sin(2*t),.006+.008*math.sin(t))for t in np.linspace(.02,math.pi-.02,70)];q=swept_ribbon('actual-cotton-bow-loop-'+str((i,side)),'binding',points,.0085,.0007);q['_vertices']=[(x,height(x,z0+y)+z,z0+y)for x,y,z in q['_vertices']];p.append(q)
   pts=[(side*(.003+.034*t),-.004-.063*t,.004+.002*math.sin(t*math.pi))for t in np.linspace(0,1,40)];q=swept_ribbon('actual-cotton-bow-tail-'+str((i,side)),'binding',pts,.009,.0007,True);q['_vertices']=[(x,height(x,z0+y)+z,z0+y)for x,y,z in q['_vertices']];p.append(q)
  p.append(ball('soft-small-knot-of-tie-'+str(i),'binding',(0,height(0,z0)+.007,z0),.007,.005,.006,32,20))
 vv=np.array(p[0]['_vertices']);sx=1.2/np.ptp(vv[:,0]);sz=1.2/np.ptp(vv[:,2])
 for q in p:q['_vertices']=[(x*sx,y,z*sz)for x,y,z in q['_vertices']]
 return p,dict(cotton=tree_skirt_material(),binding=bank(pid+'-plain-cotton-ties-and-hem',[53,58,32])),['Actual120cm round thin cotton skirt laid on the ground, never an upright cushion','Real central tree opening and parallel radial slit with separately sewn hems','Exactly three actual fabric bow closures with folded loops, tails and soft knots','Same-product windowpane textile donor isolated from its official photograph; planar physical-scale UV, no white background bake'],dict(w=120,h=2.2,d=120,official={'diameter_cm':120},estimated=['cloth_thickness_mm','central_hole_diameter_cm','slit_gap_cm','tie_length_and_width_cm','windowpane_pitch_cm','subtle_fabric_ripple_and_drape'],note='Resmî D120cm dış çap korunur. Yaklaşık10cm merkez deliği,1,4cm yarık aralığı,0,8mm kumaş kalınlığı,12cm kare ritmi ve üç bağcığın yerel ölçüleri fotoğraf tahminidir. Kumaş yatay serilmiş gösterilir; ağaç ve dekor eklenmedi.',primary='ab6c8ceeb762',name='Koyu yeşil kareli pamuklu yılbaşı ağacı eteği',material='Kendi ürün fotoğrafından kareli pamuk dokuma, düz pamuk bağlar ve katlı dikiş kenarları',color='Koyu yeşil/Beyaz')

FUN={'1353729001':cotton_tree_skirt,'1355065003':lambda:spherical_ornament('1355065003'),'1355071001':straw_stars,'1244824002':red_flake,'1354990002':lambda:silver_pair('1354990002'),'1355065002':lambda:spherical_ornament('1355065002'),'1355065006':lambda:spherical_ornament('1355065006'),'1354994002':lambda:spherical_ornament('1354994002'),'1354994001':lambda:spherical_ornament('1354994001'),'1354985002':lambda:glass_candies('1354985002'),'1354985003':lambda:glass_candies('1354985003'),'1359291004':lambda:ski_goggle_pair('1359291004'),'1359291002':lambda:ski_goggle_pair('1359291002'),'1354993004':twisted_metal,'1354955003':cream_tree_row,'1354955001':star_row,'1354985001':glass_candies,'1355097002':white_tassels,'1293863003':striped_green_pair,'1319423002':yellow_bunny,'1299133002':pinecone_set,'1205343004':velvet_bow,'1359291001':plastic_pair,'1299157015':caviar_tin,'0451338006':black_star_set,'1354990003':silver_pair,'1359146001':beaded_star,'1299152002':lambda:red_glass('1299152002'),'1300259001':lambda:red_glass('1300259001'),'1261191001':glass_pair,'1294288002':lambda:tinsel('1294288002'),'1294288003':lambda:tinsel('1294288003'),'1294288004':lambda:tinsel('1294288004'),'1355409001':stocking,'1105071002':star,'0746539004':eggs,'1244824004':lambda:snowflake('1244824004',.2),'1244814003':lambda:snowflake('1244814003',.06)}
for pid in ['0746539012','0746539013','0746539015','0746539016','1214591001','1214591002','1214591007']:FUN[pid]=lambda pid=pid:egg_family(pid)
for pid in ['1299165001','1299165002','1299165004','1355013001','1355013002','1355013003','1293863008','1293863005','1355013004','0429934017','1293864004','1354975001','1354975003']:FUN[pid]=lambda pid=pid:paper_finial_set(pid)
FUN['1044644001']=bunny_pair
FUN['1214591007']=little_spring_eggs

def build(pid):
 rows=json.loads((R/'source-category-slice.json').read_text())['products'];row=next(q for q in rows if q['product_code']==pid);capture=next((q for q in json.loads((R/'source-inventory.json').read_text())if q['sku']==pid),None)
 if capture is None:
  cached=next(q for q in json.loads((R/'cached-research-inventory.json').read_text())if q['sku']==pid)['preferred_cached_source'];assert cached and cached['dimension_evidence'];capture=dict(official_capture=dict(description=cached['raw_excerpt'],materials=cached['raw_excerpt'].split('Materials')[-1]),source_evidence_file=cached['source_file'],cached_source=cached['url'],source_market=cached['market'])
 refs=[q for q in json.loads((R/'original-image-masters.json').read_text())if q['sku']==pid];parts,materials,features,spec=FUN[pid]();fmt=lambda x:format(x,'g').replace('.','p');id='hm-'+pid+'-h'+fmt(spec['h'])+'-w'+fmt(spec['w'])+'-d'+fmt(spec['d']);out=R/'models'/id;out.mkdir(parents=True,exist_ok=True)
 # Dimensions reported below are actual asset bounds. Official single-body anchors are preserved in metadata.
 pos=np.concatenate([np.array(p['_vertices'])for p in parts]);lo=pos.min(0);hi=pos.max(0);center=np.array([(lo[0]+hi[0])/2,lo[1],(lo[2]+hi[2])/2]);scale=np.ones(3)
 if pid in['1355409001','1105071002']:scale=np.array([spec['w'],spec['h'],spec['d']])/100/(hi-lo)
 meshes=[];checks=[]
 for p in parts:
  p['_vertices']=[tuple((np.array(v)-center)*scale)for v in p['_vertices']];p=V.orient(p);m,c=finalize(p);meshes.append(m);checks.append(c)
 repair=M.ensure_uv_faces(meshes)+V.ensure_float32_uv(meshes);maps=[]
 for key,mat in materials.items():
  for slot in['baseColorTexture','normalTexture','metallicRoughnessTexture']:
   f=Path(mat[slot]);dst=out/(key+'-'+f.name);shutil.copyfile(f,dst);mat[slot]=dst.name;maps.append(dict(material=key,slot=slot,path=str(dst),sha256=sha(dst),native_resolution=[2048,2048]))
 allv=np.concatenate([np.array(m['positions']).reshape(-1,3)for m in meshes]);actual=(allv.max(0)-allv.min(0))*100;primary=next(q for q in refs if spec['primary']in q['path']);refs.sort(key=lambda q:q['path']!=primary['path']);cap=capture['official_capture'];meta=dict(id=id,sku=pid,brand='H&M Home',name=spec['name'],category='Dekorasyon ve aksesuarlar',url=row['url'],dimensions_cm=actual.tolist(),source_dimensions_hwd_cm=[spec['official'].get('height_cm'),spec['official'].get('width_cm'),None],official_measurements=spec['official'],estimated_dimensions=True,estimated_fields=spec['estimated'],scale_note=spec['note'],material_label=spec['material'],color=spec['color'],source_market=capture.get('source_market','Türkiye'),source_size_pointer=str(R/'source-inventory.json')+'#sku='+pid,source_evidence_files=list(dict.fromkeys([capture['source_evidence_file'],str(R/'source-category-slice.json')]+[q['source_file']for q in refs])),source_images=[dict(url=q['url'],alt=q['alt'])for q in refs],original_image=primary['path'],original_image_url=primary['url'],original_image_sha256=primary['sha256'],original_images=[{k:q[k]for k in['path','url','sha256']}for q in refs],variant_status_verbatim='Resmî ürün kimliği ve fiziksel ölçü dayanağı doğrulandı; fotoğrafa dayalı eksenler açıkça işaretlendi.',description_verbatim=cap.get('description',''),materials_verbatim=cap.get('materials',''),units='metres',up_axis='Y',origin='bottom bounding-box centre',native_texture_resolution=2048,source_image_masters_immutable=True,photo_pixels_baked=pid in['1355409001','1205343004','1353729001'],geometry_limitations=['Yerel kesitler, kâğıt/tel kalınlığı, askı ve set düzeni fotoğrafa dayalı yorumdur; üretici CAD verisi değildir.','Sahne aksesuarları ürün geometrisine eklenmedi.']);meta['quality_note']=spec.get('quality_note','');meta['quality_pending']=bool(meta['quality_note']);meta.update({k:spec[k]for k in['bundle','official_piece_dimensions_cm','body_dimensions_cm']if k in spec})
 if pid in['1299152002','1300259001','1261191001','1354985001','1354985002','1354985003','1354990002','1354994002','1354994001','1355065002','1355065006','1355065003']:
  meta.update(quality_label='Yaklaşık cam görünümü',quality_status='preview_limited',quality_note='Camın rengi, saydamlığı ve ışığı kırma görünümü görüntüleyiciye göre değişebilir; önizleme yaklaşık görünür. GLB’de fiziksel cam geçirgenliği, kırılma indisi ve cidar bilgisi korunur.',quality_pending=False)
 dump(out/'model.json',dict(metadata=meta,materials=materials,meshes=meshes));dump(out/'geometry-validation.json',dict(valid=True,features=features,mesh_count=len(meshes),meshes=checks,uv_repaired=repair,closed_material_solids=True,actual_bounds_cm=actual.tolist()));dump(out/'material-validation.json',dict(valid=True,native_resolution=2048,maps=maps,photo_pixels_baked=pid in['1355409001','1205343004','1353729001'],baked_reflections=False));report=export_assets(out/'model.json',out,id);glb=out/(id+'.glb');doc,binary=read_glb(glb);doc['samplers']=[dict(magFilter=9729,minFilter=9987,wrapS=10497,wrapT=10497)]
 for t in doc.get('textures',[]):t['sampler']=0
 binary=M.embed_tangents(doc,binary);write_glb(glb,doc,binary);report['deliverable_sha256']['glb']=sha(glb);report['glb_bytes']=glb.stat().st_size;dump(report['files']['validation'],report)
 e={k:meta[k]for k in['id','sku','brand','name','category','url','dimensions_cm','source_dimensions_hwd_cm','official_measurements','estimated_dimensions','estimated_fields','scale_note','material_label','color','source_market','source_size_pointer','source_evidence_files','source_images','original_image','original_image_url','original_image_sha256','original_images','variant_status_verbatim']};e.update({k:meta[k]for k in['quality_label','quality_status']if k in meta});e.update(quality_note=meta['quality_note'],quality_pending=meta['quality_pending'],asset_dir=str(out),model_path=str(out/'model.json'),glb_path=str(glb),sha256=sha(glb),bytes=glb.stat().st_size,model_revision='hmhome-accessories-b-photo-specific-v1',geometry_validation=str(out/'geometry-validation.json'),material_validation=str(out/'material-validation.json'),size_source_kind='official_cached_PDP'if capture.get('cached_source')else'official_tr_live_observed',size_source_urls=[capture.get('cached_source',row['url'])]);dump(out/'topology-validation.json',M.AQ.check(e));manifest=json.loads((R/'manifest.json').read_text())if(R/'manifest.json').exists()else[];manifest=[q for q in manifest if q['sku']!=pid];manifest.append(e);dump(R/'manifest.json',manifest);print('BUILT',pid,'triangles',sum(q['triangles']for q in checks),'bytes',e['bytes'],flush=True)
if __name__=='__main__':
 for pid in sys.argv[1:]or list(FUN):build(pid)
