from pathlib import Path
import json,shutil,hashlib
from PIL import Image
R=Path(__file__).resolve().parent;F=R.parent/'source-recovery-decor/manifest.json';recovery=json.loads(F.read_text());masters=json.loads((R/'original-image-masters.json').read_text());urls={q['url']for q in masters};photo=[]
for e in recovery['products']:
 for q in e['images']:
  if q['url']in urls:continue
  src=Path(q['original_image']);dst=R/'originals'/src.name
  if not dst.exists():shutil.copyfile(src,dst)
  digest=hashlib.sha256(dst.read_bytes()).hexdigest();assert digest==q['sha256'];im=Image.open(dst);masters.append(dict(sku=e['sku'],product_url=e['tr_url'],url=q['url'],alt=q['image_search_caption'],observed_width=im.width,source_file=q['source_evidence_file'],source_kind='official_cached_exact_sku_image_search',path=str(dst),sha256=digest,pixels=list(im.size),format=im.format,mode=im.mode,original_bytes_unmodified=True));urls.add(q['url']);photo.append(e['sku'])
(R/'original-image-masters.json').write_text(json.dumps(masters,ensure_ascii=False,indent=2)+'\n');(R/'recovery-import-evidence.json').write_text(json.dumps(dict(source_manifest=str(F),imported_photo_SKUs=photo,all_sources_labelled_by_market=True),ensure_ascii=False,indent=2)+'\n');print('IMPORTED',photo,'MASTER_COUNT',len(masters))
