from pathlib import Path
import json,hashlib
R=Path(__file__).resolve().parent;masters=json.loads((R/'original-image-masters.json').read_text());models={q['sku']:q for q in json.loads((R/'manifest.json').read_text())};live={q['sku']:q for q in json.loads((R/'source-inventory.json').read_text())};rows=json.loads((R/'source-category-slice.json').read_text())['products'];out=[]
for row in rows:
 sku=row['product_code'];refs=[q for q in masters if q['sku']==sku];current=[q for q in refs if q['source_kind']=='official_live_pdp_gallery'];refs=current or refs;seen=set();chosen=[]
 for q in refs:
  base=q['url'].split('?')[0]
  if base in seen:continue
  seen.add(base);chosen.append(q)
 e=models.get(sku,{});primary=e.get('original_image_url','').split('?')[0];chosen.sort(key=lambda q:q['url'].split('?')[0]!=primary)
 out.append(dict(sku=sku,url=row['url'],source_images=[dict(url=q['url'],alt=q['alt'])for q in chosen],original_images=[dict(path=q['path'],url=q['url'],sha256=q['sha256'])for q in chosen],source_evidence_files=list(dict.fromkeys(q['source_file']for q in chosen)),binding_rule='Own exactSKU official live gallery takes precedence; otherwise own exactSKU cached primary gallery/category evidence. URL query and original bytes are unchanged.',full_live_gallery_observed=bool(current),source_model_primary_image_url=e.get('original_image_url')))
(R/'gallery-bindings.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');proof=[]
for f in sorted(R.glob('frozen-family-*/manifest.json')):
 if f.parent.name=='frozen-family-03':continue
 for e in json.loads(f.read_text()):
  for q in e['original_images']:assert hashlib.sha256(Path(q['path']).read_bytes()).hexdigest()==q['sha256'];proof.append(q['path'])
assert all(hashlib.sha256(Path(q['path']).read_bytes()).hexdigest()==q['sha256']for q in masters)
(R/'image-master-preservation-validation.json').write_text(json.dumps(dict(valid=True,current_master_bindings=len(masters),frozen_original_references_checked=len(proof),all_frozen_original_SHA_preserved=True,all_current_original_SHA_preserved=True,only_own_derivatives_edited=True),ensure_ascii=False,indent=2)+'\n');print('GALLERIES',len(out),'with_photos',sum(bool(q['source_images'])for q in out),'masters',len(masters))
