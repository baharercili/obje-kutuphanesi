from pathlib import Path
import json,hashlib,struct,shutil
R=Path(__file__).resolve().parent;sha=lambda b:hashlib.sha256(b).hexdigest();a=json.loads((R/'manifest.json').read_text());proof=[]
for e in a:
 if e['sku']!='1353729001':continue
 changes=dict(quality_pending=False,quality_label='Yaklaşık doku',quality_status='source_resolution_limited',quality_note='Dokuma yüzeyi ürün fotoğrafındaki185×175piksellik temiz kumaş alanından2K haritaya örneklendi; çok yakın görünümde özgün doku ayrıntısı sınırlıdır.');mp=Path(e['model_path']);old_model=sha(mp.read_bytes());m=json.loads(mp.read_text());m['metadata'].update(changes);mp.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n');new_model=sha(mp.read_bytes());p=Path(e['glb_path']);b=p.read_bytes();old_sha=sha(b);n=struct.unpack_from('<I',b,12)[0];d=json.loads(b[20:20+n]);tail=b[20+n:];d['extras']['metadata'].update(changes);j=json.dumps(d,separators=(',',':'),ensure_ascii=False).encode();j+=b' '*(-len(j)%4);out=struct.pack('<4sII',b'glTF',2,20+len(j)+len(tail))+struct.pack('<II',len(j),0x4e4f534a)+j+tail;p.write_bytes(out);new_sha=sha(out);assert out[20+len(j):]==tail;e.update(changes,sha256=new_sha,bytes=len(out))
 for f in Path(e['asset_dir']).glob('*.json'):
  if f==mp:continue
  s=f.read_text().replace(old_sha,new_sha).replace(old_model,new_model);f.write_text(s)
 proof.append(dict(sku=e['sku'],old_glb_sha256=old_sha,new_glb_sha256=new_sha,binary_geometry_material_maps_unchanged=True,binary_chunk_sha256=sha(tail),review='Independent peer accepted own-windowpane cotton construction; original185x175px donor resolution limit stays explicit.'))
(R/'manifest.json').write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n');(R/'newly-measured-three-reviewed-metadata-only-validation.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
want=[e['sku']for e in json.loads((R/'newly-measured-three-manifest.json').read_text())];cur={e['sku']:e for e in a};(R/'newly-measured-three-final-manifest.json').write_text(json.dumps([cur[s]for s in want],ensure_ascii=False,indent=2)+'\n');q=json.loads((R/'newly-measured-three-independent-qa.json').read_text())
for check in q['products']:
 for t in proof:
  if check['sku']==t['sku']:assert check['glb_sha256']==t['old_glb_sha256'];check['glb_sha256']=t['new_glb_sha256'];check['metadata_only_review_update']=t
(R/'newly-measured-three-final-independent-qa.json').write_text(json.dumps(q,ensure_ascii=False,indent=2)+'\n')
for f in R.glob('newly-measured-three-models-*.jpg'):shutil.copyfile(f,R/f.name.replace('newly-measured-three-models','newly-measured-three-final-models'))
