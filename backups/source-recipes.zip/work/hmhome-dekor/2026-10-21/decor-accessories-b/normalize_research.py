from pathlib import Path
import json,re
P=Path(__file__).resolve().parent
rows=json.loads((P/'source-category-slice.json').read_text())['products'];by={q['product_code']:[]for q in rows}
for f in sorted(P.glob('official-search-*.json')):
 text=json.loads(f.read_text())
 for part in text.split('--------------------------------------------------------------------------------'):
  m=re.search(r'https://www2\.hm\.com/([^/]+)/productpage\.(\d+)\.html',part)
  if not m or m[2]not in by:continue
  lines=part.splitlines();descpart=re.split(r'\n(?:Description|Açıklama|Descripción|Beschreibung|Descrizione|Beskrivning|Omschrijving|Opis|Descrição)\n',part)[-1]
  dimensional=[l.strip()for l in descpart.splitlines()if re.search(r'\d+(?:[.,]\d+)?\s*(?:cm|mm)(?:\W|$)',l)]
  by[m[2]].append(dict(url=m[0],market=m[1],source_file=str(f),source_type='official_cached_PDP',identity_verified=m[2]in descpart,dimension_evidence=dimensional,raw_excerpt=descpart[:6000]))
result=[]
for row in rows:
 sku=row['product_code'];src=by[sku];src.sort(key=lambda a:(not bool(a['dimension_evidence']),0 if a['market']=='tr_tr'else 1 if a['market'].startswith('en_')else 2))
 result.append(dict(sku=sku,title=row['title'],url=row['url'],official_cached_sources=src,preferred_cached_source=src[0]if src else None,status='cached_measurement_evidence'if any(x['dimension_evidence']for x in src)else'pending_measurements'if src else'pending_research'))
(P/'cached-research-inventory.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
(P/'cache-source-urls.json').write_text(json.dumps([dict(sku=r['sku'],url=r['preferred_cached_source']['url'])for r in result if r['preferred_cached_source']],ensure_ascii=False,indent=2)+'\n')
from collections import Counter
print(Counter(r['status']for r in result))
for r in result:
 p=r['preferred_cached_source'];print(r['sku'],r['status'],p['dimension_evidence'][:3]if p else'')
