"""Freeze explicitly reviewed delivery records, without altering any model bytes."""
from pathlib import Path
import json,hashlib,sys
from collections import Counter
R=Path(__file__).resolve().parent
FAMILY01={'1319209002','1347756001','1247880003','1247880004'}
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,q):p.write_text(json.dumps(q,ensure_ascii=False,indent=2)+'\n')
def run():
 manifest=R/'frozen-family-02-manifest.json';combined=R/'frozen-delivery-manifest.json'
 assert not manifest.exists()and not combined.exists(),'Frozen outputs already exist; use a new revision folder.'
 q=json.loads((R/'independent-validation.json').read_text());assert q['valid']and q['models']==36
 peer=R/'peer-review-disposition.json';assert peer.exists(),'Independent visual peer review dispositions required.'
 review=json.loads(peer.read_text());assert review['resolved_for_freeze']
 entries=json.loads((R/'manifest.json').read_text());out=[]
 for e in entries:
  if e['sku']in FAMILY01:continue
  if e['sku']in review.get('excluded_skus',[]):continue
  check=next(q for q in q['checks']if q['sku']==e['sku']);assert check['valid']and check['sha256']==sha(e['glb_path'])==e['sha256']
  assert e['bytes']==Path(e['glb_path']).stat().st_size<40*1024*1024
  path=Path(e['asset_dir']);views={k:str(path/(k+'.png'))for k in['on','yan','on-capraz','ustten']};assert all(Path(p).exists()for p in views.values());scn=path/(e['id']+'.scn');assert scn.exists();comparison=R/(e['id']+'-comparison.jpg');assert comparison.exists()
  e=dict(e,frozen=True,model_status='ready_with_interpretations',native_renders=views,scn_path=str(scn),source_comparison_path=str(comparison),independent_validation_file=str(R/'independent-validation-family-02.json'),visual_validation_file=str(peer),dimensions_status='official_partial_photo_scaled'if e['estimated_dimensions']else'official_exact_axes',source_photo_masters_unchanged=True)
  e['visual_quality_limitations']=['Reconstructed from exact-SKU official photographs, not a manufacturer scan/CAD. Unlabelled thicknesses, hidden surfaces, hanging cords and set display arrangements are interpretations.']
  if e['sku']in['1299157028','1299157029']:e['visual_quality_limitations'].append('Only own category front image was accessible; hidden side/rear details are interpreted.')
  if e['sku']in['1355087004','1355065005','1355050001']:e['visual_quality_limitations'].append('Native SceneKit uses an alpha fallback; actual GLB stores transmission/IOR/volume. Thin clear parts can be faint on the pale comparison background.')
  out.append(e)
 assert len(out)==25 and len({e['sku']for e in out})==25
 included={e['sku']for e in out}
 dump(R/'independent-validation-family-02.json',dict(q,models=25,checks=[c for c in q['checks']if c['sku']in included]))
 dump(manifest,out)
 first=json.loads((R/'revision-02/frozen-manifest.json').read_text());wood=json.loads((R/'revision-03/frozen-manifest.json').read_text());first=[e for e in first if e['sku']!='1319209002']+wood
 deliver=first+out;assert len(deliver)==29 and len({e['sku']for e in deliver})==29;dump(combined,deliver)
 hashes=[]
 for e in deliver:
  path=Path(e['asset_dir']);paths=[Path(e['glb_path']),Path(e['model_path'])]+list(path.glob('*-2k.png'))+list(path.glob('*.scn'))+[path/(s+'.png')for s in['on','yan','on-capraz','ustten']]
  hashes.extend({'sku':e['sku'],'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}for p in paths)
 dump(R/'frozen-delivery-file-hashes.json',hashes)
 inventory=json.loads((R/'all62-status.json').read_text());bindings={e['sku']:e for e in deliver}
 for p in inventory['products']:
  if p['sku']in review['excluded_skus']:p.update(status='quality_revision_in_progress',reason='Independent peer review found a concrete local form mismatch. The unfrozen draft is excluded from delivery until corrected and rechecked.')
  if p['sku']in bindings:
   e=bindings[p['sku']];p.update(status='ready_with_interpretations',reason='Own-SKU official anchor, immutable originals, closed actual 3D geometry, independent GLB QA and visual review completed. Unlabelled axes/patterns remain explicitly interpreted.',model_id=e['id'],model_manifest=str(combined),glb_sha256=e['sha256'],dimensions_cm=e['dimensions_cm'],estimated_fields=e.get('estimated_fields',[]))
 inventory['counts']=dict(Counter(p['status']for p in inventory['products']));inventory['frozen_delivery_manifest']=str(combined);inventory['frozen_delivery_manifest_sha256']=sha(combined);dump(R/'all62-status.json',inventory)
 dump(R/'delivery-summary.json',{'source_cards':62,'frozen_models':29,'new_family_models':25,'retained_revision_models':4,'pending_source_cards':26,'pending_quality_models':7,'counts':inventory['counts'],'family_manifest':str(manifest),'family_manifest_sha256':sha(manifest),'combined_manifest':str(combined),'combined_manifest_sha256':sha(combined),'total_glb_bytes':sum(e['bytes']for e in deliver),'max_glb_bytes':max(e['bytes']for e in deliver),'original_photo_masters':117,'site_or_git_changed':False})
 print(json.dumps(json.loads((R/'delivery-summary.json').read_text()),ensure_ascii=False,indent=2))
if __name__=='__main__':run()
