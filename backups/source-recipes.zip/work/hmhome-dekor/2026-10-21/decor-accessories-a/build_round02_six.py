"""Six newly accessible exact-SKU bell/tray/paper/metal/fabric/bottle forms."""
from pathlib import Path
import sys,math,json
sys.dont_write_bytecode=True
import numpy as np
from PIL import Image,ImageDraw,ImageFont
import build_accessories as A
import build_ornaments as O
from round02_tree_panel import perforated_tree_panel
B=A.B;T=math.tau
def sheet(name,mat,points,thick,mapper):
 n=len(points);v=[];uv=[];f=[]
 for sign in[-1,1]:
  for x,y in points:v.append(mapper(x,y,sign*thick/2));uv.append((x*10+.5,y*10))
 for i in range(1,n-1):f.extend([(0,i+1,i),(n,n+i,n+i+1)])
 for i in range(n):j=(i+1)%n;f.extend([(i,j,n+i),(j,n+j,n+i)])
 return A.raw(name,mat,v,f,uv)
def bells():
 p=[]
 for k,x in enumerate([-.037,.037]):
  off=k*.035
  profile=[(.0247,.001),(.025,.0025),(.0248,.005),(.021,.007),(.018,.018),(.014,.033),(.011,.038),(.006,.040),(0,.040),(0,.0385),(.0058,.0385),(.0098,.0365),(.0125,.0315),(.0165,.0165),(.0198,.006),(.0235,.004),(.0235,.001)]
  p.append(B.lathe('genuinely-hollow-flared-polished-steel-bell-'+str(k),'steel',[(r,y+off)for r,y in profile],160,True,offset=(x,0,0)))
  p.append(B.cylinder('bell-internal-clapper-stem-'+str(k),'steel',.0008,off+.007,off+.030,offset=(x,0,0),n=24));p.append(O.sphere('real-bell-clapper-weight-'+str(k),'steel',.0030,(x,off+.007,0),n=40));p.append(O.eye('small-steel-top-eye-'+str(k),'steel',(x,off+.042,0),.002))
  p.append(O.ribbon_loop('finite-width-beige-velvet-hanging-loop-'+str(k),'velvet',(x,off+.045,0),.095,.0035));cy=off+.141
  for sign in[-1,1]:
   pts=[(x+sign*.0125*(1-math.cos(a)),cy+.005*math.sin(a),.0020*math.sin(a))for a in np.linspace(0,T,97)[:-1]];p.append(B.tube('small-actual-velvet-bow-loop-'+str(k)+'-'+str(sign),'velvet',pts,.00016,.0018,8,True,guide=[0,0,1]));p.append(B.tube('small-bow-free-tail-'+str(k)+'-'+str(sign),'velvet',[(x,cy,.001),(x+sign*.014,cy-.010,.002),(x+sign*.025,cy-.022,0)],.00018,.0018,8,False,guide=[0,0,1]))
  p.append(O.sphere('soft-small-velvet-bow-centre-'+str(k),'velvet',.0025,(x,cy,.001),scale=(1.4,.8,.7),n=32))
 return p,['Two actual hollow stainless-steel bells with flared rims, ceiling thickness, interior clapper stems and weights','Separate top eyes, finite-width beige velvet hanging loops and tied bows with two free tails','Official decoration H4 W5 cm is assigned to each bell body; unlabelled ribbon length, depth and set display layout are photo interpretations'],{'set_quantity':2,'piece_dimensions_cm':{'bell_body_height':4,'bell_body_width':5},'source_axis_ambiguity':'Source labels Süsleme:H4/W5. The photographic bell-body ratio supports that assignment; ribbons/overall set bounds are not official dimensions.'}
def earclip(points):
 q=np.asarray(points,float);area=np.sum(q[:,0]*np.roll(q[:,1],-1)-q[:,1]*np.roll(q[:,0],-1));ids=list(range(len(q)))if area>0 else list(reversed(range(len(q))));tri=[]
 def cross(a,b):return a[0]*b[1]-a[1]*b[0]
 while len(ids)>3:
  for k,b in enumerate(ids):
   a=ids[k-1];c=ids[(k+1)%len(ids)];pa,pb,pc=q[a],q[b],q[c]
   if cross(pb-pa,pc-pb)<=1e-14:continue
   valid=True
   for j in ids:
    if j in[a,b,c]:continue
    pp=q[j]
    if cross(pb-pa,pp-pa)>=-1e-13 and cross(pc-pb,pp-pb)>=-1e-13 and cross(pa-pc,pp-pc)>=-1e-13:valid=False;break
   if valid:tri.append((a,b,c));ids.pop(k);break
  else:raise ValueError('Non-simple dish outline')
 tri.append(tuple(ids));return tri
def red_tree_tray():
 right=[(0,.100),(.020,.081),(.041,.054),(.041,.045),(.034,.039),(.044,.025),(.061,.005),(.063,-.006),(.057,-.014),(.066,-.032),(.085,-.059),(.085,-.067),(.078,-.073),(.030,-.073),(.028,-.100)]
 outline=right+[(-x,z)for x,z in reversed(right[1:])]
 for repeat in range(2):
  curved=[]
  for k,a in enumerate(outline):b=outline[(k+1)%len(outline)];curved.extend([(a[0]*.75+b[0]*.25,a[1]*.75+b[1]*.25),(a[0]*.25+b[0]*.75,a[1]*.25+b[1]*.75)])
  outline=curved
 n=len(outline);v=[];uv=[];f=[];rings=[(.96,0),(.985,.003),(1,.014),(.99,.018),(.945,.017),(.88,.004)]
 for sc,y in rings:
  for x,z in outline:v.append((x*sc,y,z*sc));uv.append((x/.17+.5,z/.20+.5))
 for j in range(len(rings)-1):
  for i in range(n):a=j*n+i;b=j*n+(i+1)%n;c=(j+1)*n+i;d=(j+1)*n+(i+1)%n;f.extend([(a,c,b),(b,c,d)])
 triangles=earclip(outline)
 for a,b,c in triangles:f.extend([(a,c,b),((len(rings)-1)*n+a,(len(rings)-1)*n+b,(len(rings)-1)*n+c)])
 return[A.raw('actual-shallow-red-tree-shaped-glass-tray-floor-wall-rounded-rim','rubyglass',v,f,uv)],['Actual horizontal shallow tree-shaped dish: three softened branch tiers, trunk, solid underside, recessed floor and raised rounded rim','Concave tree outline is genuinely triangulated rather than using a full rectangular or photo-plane base','Official G17/Y20 labels are mapped to plan width17 and plan length20 cm; vertical rim height1.8 cm is explicitly estimated from own photo'],{'source_axis_mapping':{'source_width_17_cm':'model_width_X_cm','source_labelled_height_20_cm':'model_plan_length_Z_cm'},'source_axis_ambiguity':'The official page uses Alt parça:G17/Y20. Own full plan photos clearly show a shallow horizontal dish; source Y20 is the tree’s plan length, not a20 cm vertical wall. Model vertical height1.8 cm is photo-estimated.'}
def green_tree_row():
 p=[];count=9;pitch=.595/count;fold=.35
 for k in range(count):
  c=(k-(count-1)/2)*pitch*math.cos(fold)
  def mapper(x,y,t):return(c+x*math.cos(fold),y,(-1)**k*x*math.sin(fold)+t)
  p.append(perforated_tree_panel('own-green-row-real-cut-paper-tree-'+str(k+1),mapper));p.append(sheet('own-continuous-accordion-base-'+str(k+1),'paper',[(-pitch/2,0),(pitch/2,0),(pitch/2,.014),(-pitch/2,.014)],.00035,mapper))
  if k<count-1:p.append(sheet('thin-real-paper-tree-joining-bridge-'+str(k+1),'paper',[(.020,.030),(.047,.030),(.047,.038),(.020,.038)],.00035,mapper))
 return p,['Nine own-photo observed pine silhouettes on a continuous folded paper base','Physical350µm closed paper, actual small cut-through ornaments, narrow trunks and connected branch bridges','Same-family closed perforation mesher adapted read-only from B; own green SKU photo/count/material and explicit source measurement semantics retained'],{'tree_count_observed':9,'source_axis_ambiguity':'Source H11/L59.5 does not label folded vs unfolded length. L59.5 is applied to the model’s overall horizontal envelope; fold depth/angle and local cut-out contours remain photo interpretations.','perforation_interpretation':'Small bright circles/stars in the backlit exact-SKU photo are reconstructed as physical openings; exact die-cut contours are interpreted.'}
def metal_tree():
 profile=[(0,0),(.003,0),(.003,.006)];height=.090
 for j in range(7):
  y=.006+j*.0115;r=.027*(1-j/7.6)
  profile.extend([(r*.50,y),(r*.98,y+.0008),(r,y+.0025),(r*.83,y+.0048),(r*.38,y+.0108)])
 profile.extend([(.0015,height),(0,height)]);g=B.lathe('own-seven-swept-rounded-silver-metal-tree-tiers','chrome',profile,144,False,ellipse=.48)
 # Swept lips introduce the source’s diagonal, softly twisted ridges in physical geometry.
 g['_vertices']=[(x,y+.0015*math.sin(math.atan2(z/.48,x)+y*90)*min(1,math.hypot(x,z/.48)/.010),z)for x,y,z in g['_vertices']];p=[g,O.eye('small-aluminium-tree-top-eye','chrome',(0,.093,0),.002),O.ribbon_loop('white-velvet-tree-loop','velvet',(0,.096,0),.080,.0035)]
 return p,['Seven physically swept rounded tier lips and a narrow bottom trunk, not a flat tree graphic','Polished aluminium surface, separate real top eye and white finite-width velvet loop','Official design-dependent approximate8–10 cm range is retained; nominal9 cm body and unlabelled depth/loop are declared photo interpretations'],{'source_axis_ambiguity':'Official approx8–10 cm depends on design and has no exact axis/piece assignment. A nominal9 cm tree body is an estimate within that range, not an official size.','nominal_interpreted_body_height_cm':9}
def closed_grid(name,mat,points,nu,nv,periodic=False):
 v=[];uv=[];f=[]
 for side in[-1,1]:
  for j in range(nu):
   t=j/(nu if periodic else nu-1)
   for i in range(nv):u=i/(nv-1);v.append(points(t,u,side));uv.append((t,u))
 layer=nu*nv
 for side in[0,1]:
  for j in range(nu if periodic else nu-1):
   jj=(j+1)%nu
   for i in range(nv-1):a=side*layer+j*nv+i;b=side*layer+jj*nv+i;f.extend([(a,a+1,b),(a+1,b+1,b)])
 for j in range(nu if periodic else nu-1):
  jj=(j+1)%nu
  for i in[0,nv-1]:a=j*nv+i;b=jj*nv+i;f.extend([(a,b,a+layer),(b,b+layer,a+layer)])
 if not periodic:
  for j in[0,nu-1]:
   for i in range(nv-1):a=j*nv+i;f.extend([(a,a+layer,a+1),(a+1,a+layer,a+layer+1)])
 return A.raw(name,mat,v,f,uv)
def gold_velvet_bow():
 p=[]
 for sign in[-1,1]:
  def loop(t,u,side):
   a=T*t;across=2*u-1;half=.0025+.016*(max(0,math.sin(a/2))**.65);x=sign*(.006+.027*(1-math.cos(a)));y=.112+across*half;z=.006*math.sin(a)+.0055*math.sin(across*math.pi*3)*(1-math.sin(a/2))**1.4;dx=sign*.027*math.sin(a);dz=.006*math.cos(a);normal=np.array([-dz,0,dx]);normal/=np.linalg.norm(normal);q=np.array([x,y,z])+normal*side*.00018;return tuple(q)
  p.append(closed_grid('own-pleated-real-velvet-bow-loop-'+str(sign),'velvet',loop,128,15,True))
  def tail(t,u,side):
   across=2*u-1;end=.008*(1+sign*across);x=sign*(.008+.020*t)+across*(.010+.007*t);y=.108*(1-t)+end*t;z=.002*math.sin(math.pi*t)+.0015*math.sin(across*math.pi)*(.3+.7*t)+side*.0002;return(x,y,z)
  p.append(closed_grid('broad-cut-diagonal-velvet-bow-tail-'+str(sign),'velvet',tail,65,15))
 p.append(A.capped('soft-wrapped-fabric-centre-knot','velvet',[(A.M.G.rounded(.015,.012,.002,64,cy=0),.101),(A.M.G.rounded(.016,.013,.002,64,cy=0),.111),(A.M.G.rounded(.014,.011,.002,64,cy=0),.122)]))
 vv=np.concatenate([g['_vertices']for g in p]);lo=vv.min(0);hi=vv.max(0)
 for g in p:g['_vertices']=[(x*.12/(hi[0]-lo[0]),(y-lo[1])*.145/(hi[1]-lo[1]),z)for x,y,z in g['_vertices']]
 p.append(O.ribbon_loop('thin-gold-bow-suspension-thread','gold',(0,.148,0),.095,.0006))
 return p,['Two real closed cloth ribbon loops with hollow folded returns, pinched three-pleat attachments and finite0.36 mm thickness','Separate broad draped tails with diagonal-cut tips and a soft wrapped centre knot','Official body W12 H14.5 cm is preserved; unlabelled suspension cord, depth, weave and exact folds are own-photo interpretations'],{'piece_dimensions_cm':{'body_width':12,'body_height':14.5},'source_axis_ambiguity':'Official12×14.5cm is assigned to the fabric bow body; thin hanging thread is unlabelled and photo-scaled.'}
def silver_bottles():
 p=[]
 left=[(0,0),(.010,0),(.012,.003),(.014,.029),(.015,.046),(.014,.053),(.011,.058),(.007,.062),(.006,.070),(.0055,.075),(0,.075)]
 right=[(0,0),(.012,0),(.014,.003),(.014,.027),(.012,.035),(.006,.046),(.004,.051),(.004,.066),(.0048,.067),(.0048,.070),(0,.070)]
 for k,(x,profile)in enumerate([(-.032,left),(.032,right)]):
  mat='chrome'if k==0 else'glitter';p.append(B.lathe('own-silver-cocktail-shaker'if k==0 else'own-short-glitter-champagne-bottle',mat,profile,144,False,offset=(x,0,0)))
  if k==0:
   for ya,yb,r in[(.036,.039,.0148),(.062,.069,.0062)]:p.append(B.lathe('observed-shaker-glitter-band-'+str(ya),'glitter',[(r,ya),(r,yb),(r+.0002,yb),(r+.0002,ya)],96,True,offset=(x,0,0)))
   label=[(.0141,.020),(.0149,.035),(.0151,.035),(.0143,.020)];h=.075
  else:
   p.append(B.lathe('smooth-silver-champagne-neck','chrome',[(0,.048),(.0044,.048),(.0046,.066),(.0048,.070),(0,.070)],96,False,offset=(x,0,0)));label=[(.0141,.009),(.0141,.024),(.0143,.024),(.0143,.009)];h=.070
  labelled=B.lathe('own-readable-printed-label-'+str(k),'label'+str(k),label,144,True,offset=(x,0,0));ya=min(y for r,y in label);yb=max(y for r,y in label);labelled['_uvs']=[(math.atan2(zz,xx-x)/T+.5,(yb-yy)/(yb-ya))for xx,yy,zz in labelled['_vertices']];p.append(labelled);p.append(B.lathe('own-crimped-silver-top-cap-'+str(k),'chrome',[(0,h-.001),(.006,h-.001),(.006,h+.003),(.0055,h+.004),(0,h+.004)],64,False,offset=(x,0,0)));p.append(O.eye('actual-fine-silver-top-eye-'+str(k),'chrome',(x,h+.007,0),.003));p.append(O.ribbon_loop('thin-silver-hanging-thread-'+str(k),'chrome',(x,h+.010,0),.085,.0006))
 return p,['Two genuinely different own-source glass silhouettes: tapered cocktail shaker and shorter champagne bottle','Actual mirrored silver/glitter band placement, separate caps, fine eyes and thin hanging cords','Observed Joyeux NOËL / Happy HOLIDAYS labels reconstructed typographically; no full photograph plane or studio reflections are baked'],{'set_quantity':2,'piece_dimensions_cm':[{'piece':'cocktail_shaker','body_height':7.5},{'piece':'champagne_bottle','body_height':7}],'source_axis_ambiguity':'Official7 and7.5cm heights are not individually named. Taller shaker is assigned7.5 and shorter champagne7 by photograph; cap/loop inclusion, widths and depths are interpreted.','quality_status':'preview_limited','quality_label':'Yaklaşık cam görünümü','quality_note':'Camın renk, yansıma ve kırılma görünümü tarayıcıda yaklaşık gösterilir; malzemeli GLB’yi proje ışığında değerlendirin.'}
_mat=A.material
def material(pid,key,kind,rgb,rough=.45,metal=0):
 bank,m=_mat(pid,key,'metal'if kind in['rubyglass','label0','label1']else kind,rgb,rough,metal)
 if kind=='rubyglass':m.update(baseColorFactor=[.58,.008,.035,.72],alphaMode='BLEND',transmission=.55,ior=1.50,thickness=.0035,attenuationColor=[.55,.008,.025],attenuationDistance=.08)
 if kind.startswith('label'):
  image=Image.new('RGB',(2048,2048),(191,194,189));draw=ImageDraw.Draw(image);italic=ImageFont.truetype('/System/Library/Fonts/Supplemental/Georgia Italic.ttf',150);roman=ImageFont.truetype('/System/Library/Fonts/Supplemental/Times New Roman.ttf',150);word='Joyeux'if kind=='label0'else'Happy';last='NOËL'if kind=='label0'else'HOLIDAYS'
  for cx in[512,1536]:draw.text((cx,870),word,font=italic,anchor='mm',fill=(45,49,47));draw.text((cx,1160),last,font=roman,anchor='mm',fill=(235,238,233))
  image.save(bank/m['baseColorTexture'],optimize=True)
 return bank,m
A.material=material
entries=[
 ('1354997002','2’li kadife askılı paslanmaz çelik çan',bells,[1,1,1],[4,5,None],True,'Paslanmaz çelik %100 · Poliamid kadife askı',{'steel':('metal',[211,214,209],.07,1),'velvet':('paper',[200,168,116],.60,0)},['overall_set_bounds_cm','ribbon_loop_length_cm','depth_cm'],1),
 ('1354953001','Kırmızı cam çam ağacı biçimli tepsi',red_tree_tray,[17,1.8,20],[20,17,None],False,'Cam %100 · Kırmızı',{'rubyglass':('rubyglass',[242,242,238],.10,0)},['vertical_wall_height_cm','glass_wall_thickness_mm','rounded_local_outline'],1),
 ('1354955002','Katlanabilir koyu yeşil kağıt çam sırası',green_tree_row,[59.5,11,3],[11,None,None],False,'Kağıt %100 · Koyu yeşil/Beyaz',{'paper':('paper',[22,62,47],.77,0)},['fold_depth_cm','fold_angle_degrees','paper_thickness_mm','local_cutout_contours','folded_vs_unfolded_length_assignment'],1),
 ('1354993002','Gümüş metal çam ağacı yılbaşı süsü',metal_tree,[1,1,1],[None,None,None],True,'Alüminyum %100 · Gümüş rengi',{'chrome':('metal',[213,216,211],.07,1),'velvet':('paper',[236,233,219],.64,0)},['nominal_body_height_within_official_range','width_cm','depth_cm','hanging_loop_height_cm','local_tier_profile'],2),
 ('1205343005','Altın rengi kadife fiyonk yılbaşı süsü',gold_velvet_bow,[1,1,1],[14.5,12,None],True,'Polyester %91 · Metalize lif %9 · Kadife',{'velvet':('paper',[224,203,162],.66,0),'gold':('metal',[189,155,71],.28,1)},['overall_hanging_height_cm','depth_cm','ribbon_fold_geometry','thread_length_cm'],1),
 ('1355430001','2’li gümüş şişe biçimli cam yılbaşı süsü',silver_bottles,[1,1,1],[None,None,None],True,'Cam %100 · Gümüş kaplama ve sim',{'chrome':('metal',[213,216,212],.06,1),'glitter':('glitter',[215,216,210],.35,1),'label0':('label0',[190,194,189],.28,1),'label1':('label1',[190,194,189],.28,1)},['individual_labelled_height_assignment','per_piece_width_cm','per_piece_depth_cm','overall_set_bounds_cm','hanging_loop_lengths_cm'],2)]
for sku,title,builder,dims,hwd,derive,label,mats,estimated,primary in entries:
 refs=[p for p in json.loads((A.R/'original-image-masters.json').read_text())if p['sku']==sku];A.SPECS[sku]={'name':title,'dims':dims,'hwd':hwd,'derive_dimensions':derive,'build':builder,'estimated':estimated,'label':label,'color':label.split(' · ')[-1],'semantics':'Aynı gerçek SKU’nun resmî fiziksel ankrajı metadata içinde aynen korunur; eksen eşlemesi ve etiketsiz tüm boy/yüzey/askı ayrıntıları açık fotoğraf yorumudur.','materials':mats,'primary_hash':Path(refs[primary]['path']).stem.split('-')[-1]}
if __name__=='__main__':
 for sku in sys.argv[1:]or[e[0]for e in entries]:A.build(sku)
