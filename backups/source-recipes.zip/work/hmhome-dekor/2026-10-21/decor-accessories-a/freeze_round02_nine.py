"""Immutable new nine only. No prior36 file or manifest is changed."""
from pathlib import Path
import json,hashlib
from collections import Counter
R=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
manifest=R/'frozen-source-recovery-01-manifest.json';assert not manifest.exists()
entries=json.loads((R/'source-round-02/first-nine-review-manifest.json').read_text());assert len(entries)==9
assert sha(R/'source-round-02/first-nine-review-manifest.json')=='b0013f6b6628d5d46aaccb26e2efac56bf4191c6502910cdf3054481592d013e'
prior=json.loads((R/'frozen-all36-file-hashes.json').read_text());assert all(sha(p['path'])==p['sha256']for p in prior)
qa=json.loads((R/'source-round-02/independent-first-nine-validation.json').read_text());assert qa['valid']and qa['models']==9
peer=R/'source-round-02/peer-first-nine-review.json';dump(peer,{'valid':True,'reviewer':'/root/coverage_decor','date':'2026-10-22','accepted_skus':[e['sku']for e in entries],'reviewed_manifest_sha256':'b0013f6b6628d5d46aaccb26e2efac56bf4191c6502910cdf3054481592d013e','result':'All nine accepted at declared photographic approximation level. Own source silhouettes, cavities, loops, nine-tree count and local assembly were reviewed. No new silhouette blocker. Glass tray and silver bottles retain preview_limited. Native lighting alone is not reason for broad metal recolouring.'})
masters=json.loads((R/'original-image-masters.json').read_text());hashes=[];final=[]
for e in entries:
 assert e['sha256']==sha(e['glb_path'])==next(q['sha256']for q in qa['checks']if q['sku']==e['sku']);assert e['bytes']<40*1024*1024
 folder=Path(e['asset_dir']);views={k:str(folder/(k+'.png'))for k in['on','yan','on-capraz','ustten']};comparison=R/(e['id']+'-comparison.jpg');scn=folder/(e['id']+'.scn');assert comparison.exists()and scn.exists()and all(Path(p).exists()for p in views.values())
 refs=[q for q in masters if q['sku']==e['sku']];assert set(p['url']for p in refs)==set(p['url']for p in e['source_images']);assert all(sha(p['path'])==p['sha256']and p['original_bytes_unmodified']for p in refs)
 for p in e['source_evidence_files']:assert Path(p).exists()
 final.append(dict(e,frozen=True,quality_pending=False,model_status='ready_with_interpretations',model_revision='hmhome-source-recovery-peer-reviewed-v1',native_renders=views,scn_path=str(scn),source_comparison_path=str(comparison),independent_validation_file=str(R/'source-round-02/independent-first-nine-validation.json'),visual_validation_file=str(peer),dimensions_status='official_partial_photo_scaled',source_photo_masters_unchanged=True))
 for p in[Path(e['model_path']),Path(e['glb_path']),comparison,scn]+list(folder.glob('*-2k.png'))+[Path(v)for v in views.values()]+[Path(q['path'])for q in refs]:hashes.append({'sku':e['sku'],'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)})
dump(manifest,final);dump(R/'source-round-02/frozen-first-nine-file-hashes.json',hashes)
status=json.loads((R/'all62-status.json').read_text());bind={e['sku']:e for e in final}
for p in status['products']:
 if p['sku']in bind:e=bind[p['sku']];p.update(status='ready_with_interpretations',reason='Own source/model peer review and independent GLB QA passed; immutable recovery batch accepted.',model_manifest=str(manifest),model_id=e['id'],glb_sha256=e['sha256'])
status['counts']=dict(Counter(p['status']for p in status['products']));dump(R/'all62-status.json',status)
dump(R/'source-round-02/first-nine-delivery-summary.json',{'models':9,'manifest':str(manifest),'manifest_sha256':sha(manifest),'total_glb_bytes':sum(e['bytes']for e in final),'maximum_glb_bytes':max(e['bytes']for e in final),'prior36_hashes_unchanged':True,'own_original_photos_unchanged':True,'source_card_total':62,'final_measurement_pending_skus':['1250064006','1250064007','1250064008','1250456002'],'remaining_physical_model_candidates':13})
print(sha(manifest),sum(e['bytes']for e in final))
