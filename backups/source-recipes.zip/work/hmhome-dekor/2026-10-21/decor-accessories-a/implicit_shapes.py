import numpy as np
import build_accessories as A
def raw_mesh(b,name,mat,v,f):
 used=np.unique(f);remap=np.full(len(v),-1,int);remap[used]=np.arange(len(used));v=v[used];f=remap[f];b.append(A.raw(name,mat,v.tolist(),f.tolist(),[(q[0]*30,q[1]*30)for q in v]))
def ell_sdf(p,c,r):return (np.linalg.norm((p-np.array(c))/np.array(r),axis=-1)-1)*min(r)
def cap_sdf(p,a,b,r1,r2=None):
 a=np.array(a);v=np.array(b)-a;t=np.clip(np.einsum('...i,i->...',p-a,v)/np.dot(v,v),0,1);rr=r1 if r2 is None else r1+(r2-r1)*t
 return np.linalg.norm(p-a-t[...,None]*v,axis=-1)-rr
def smin(a,b,k):
 q=np.clip(.5+.5*(b-a)/k,0,1);return b*(1-q)+a*q-k*q*(1-q)
def marching_tetra(b,name,mat,field,bounds,step):
 lo=np.array(bounds[0]);hi=np.array(bounds[1]);shape=np.maximum(8,np.ceil((hi-lo)/step).astype(int)+1);axes=[np.linspace(lo[k],hi[k],shape[k])for k in range(3)];grid=np.stack(np.meshgrid(*axes,indexing='ij'),axis=-1);values=field(grid);print('implicit grid',name,shape.tolist(),flush=True)
 # A consistent six-tetrahedra split around the same cube body diagonal.
 offsets=np.array([[0,0,0],[1,0,0],[1,1,0],[0,1,0],[0,0,1],[1,0,1],[1,1,1],[0,1,1]])
 tets=[[0,1,2,6],[0,2,3,6],[0,3,7,6],[0,7,4,6],[0,4,5,6],[0,5,1,6]]
 flat=values.reshape(-1);nx,ny,nz=shape;cell=np.stack(np.meshgrid(np.arange(nx-1),np.arange(ny-1),np.arange(nz-1),indexing='ij'),axis=-1).reshape(-1,3)
 ids=(cell[:,0,None]+offsets[None,:,0])*(ny*nz)+(cell[:,1,None]+offsets[None,:,1])*nz+cell[:,2,None]+offsets[None,:,2];vv=[];ff=[];edge_cache={};points=grid.reshape(-1,3)
 for tet in tets:
  ti=ids[:,tet];vals=flat[ti];mask=np.any(vals<0,axis=1)&np.any(vals>0,axis=1);ti=ti[mask];vals=vals[mask]
  for row,fv in zip(ti,vals):
   inside=[k for k in range(4)if fv[k]<0];outside=[k for k in range(4)if fv[k]>0];poly=[]
   if len(inside)==1:edges=[(inside[0],j)for j in outside]
   elif len(inside)==3:edges=[(outside[0],j)for j in inside]
   else:edges=[(inside[0],outside[0]),(inside[0],outside[1]),(inside[1],outside[1]),(inside[1],outside[0])]
   for a,c in edges:
    ia,ic=sorted([int(row[a]),int(row[c])]);t=flat[ia]/(flat[ia]-flat[ic])
    # Snap crossings within two percent of a grid vertex to that vertex.
    # This removes sub-micron sliver triangles without making holes. All
    # incident tetrahedra share the same cache key and exact position.
    snap=None;key=('vertex',snap)if snap is not None else('edge',ia,ic)
    if key not in edge_cache:
     edge_cache[key]=len(vv);vv.append(points[snap]if snap is not None else points[ia]+t*(points[ic]-points[ia]))
    poly.append(edge_cache[key])
   outcentre=points[row[outside]].mean(axis=0);incentre=points[row[inside]].mean(axis=0);outdir=outcentre-incentre
   faces=[poly[:3]]if len(poly)==3 else[poly[:3],[poly[0],poly[2],poly[3]]]
   for face in faces:
    if len(set(face))<3:continue
    a,c,e=[vv[j]for j in face]
    if np.dot(np.cross(c-a,e-a),outdir)<0:face=[face[0],face[2],face[1]]
    ff.append(face)
 # Collapse only numerical isosurface slivers using the manifold link
 # condition. This changes no silhouette detail at the sampling scale.
 vv=np.asarray(vv);ff=np.asarray(ff,int)
 for iteration in range(1800):
  tri=vv[ff];area=np.linalg.norm(np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]),axis=1)/2;bad=np.where(area<2e-11)[0]
  if not len(bad):break
  collapsed=False
  for ix in bad:
   face=ff[ix];edges=[(int(face[j]),int(face[(j+1)%3]))for j in range(3)];edges.sort(key=lambda e:np.linalg.norm(vv[e[0]]-vv[e[1]]))
   for a,c in edges:
    fa=ff[np.any(ff==a,axis=1)];fc=ff[np.any(ff==c,axis=1)];common=set(np.unique(fa))&set(np.unique(fc));common-={a,c};adj=ff[np.any(ff==a,axis=1)&np.any(ff==c,axis=1)]
    opposite=set(np.unique(adj))-{a,c}
    if len(adj)!=2 or common!=opposite:continue
    ff[ff==c]=a;ff=ff[(ff[:,0]!=ff[:,1])&(ff[:,1]!=ff[:,2])&(ff[:,2]!=ff[:,0])];collapsed=True;break
   if collapsed:break
  if not collapsed:raise ValueError('No manifold-preserving sliver collapse')
 else:raise ValueError('Unresolved isosurface slivers')
 print('implicit mesh',name,len(vv),len(ff),'clean passes',iteration,flush=True)
 edges=np.sort(np.concatenate([ff[:,[0,1]],ff[:,[1,2]],ff[:,[2,0]]]),axis=1);counts=np.unique(edges,axis=0,return_counts=True)[1];assert(counts==2).all(),np.unique(counts,return_counts=True)
 raw_mesh(b,name,mat,vv,ff)
