from pathlib import Path
import sys,json,hashlib,shutil,math
sys.dont_write_bytecode=True
import numpy as np
from PIL import Image,ImageFilter
P=Path(__file__).resolve().parent.parent;R=P/'revision-03';R.mkdir(exist_ok=True);sys.path.insert(0,str(P));import build_accessories as A
e=next(e for e in json.loads((P/'revision-02/frozen-manifest.json').read_text())if e['sku']=='1319209002');before=A.sha(e['glb_path']);out=R/'models'/e['id'];out.mkdir(parents=True,exist_ok=True);model=json.loads(Path(e['model_path']).read_text());records=[]
for key,m in model['materials'].items():
 for slot in['baseColorTexture','normalTexture','metallicRoughnessTexture']:shutil.copyfile(Path(e['asset_dir'])/m[slot],out/m[slot])
 src=np.asarray(Image.open(out/m['baseColorTexture']),dtype=np.float32);a=src.copy();band=128;left=src[:,0,:];right=src[:,-1,:];boundary=(left+right)/2
 for x in range(band):
  t=x/(band-1);t=t*t*(3-2*t);a[:,x,:]=boundary*(1-t)+src[:,x,:]*t;a[:,-1-x,:]=boundary*(1-t)+src[:,-1-x,:]*t
 a=np.clip(a,0,255).astype(np.uint8);assert np.array_equal(a[:,band:-band,:],src[:,band:-band,:]);Image.fromarray(a,'RGB').save(out/m['baseColorTexture'],optimize=True);lum=a.astype(np.float32).mean(2);local=np.asarray(Image.fromarray(lum.astype(np.uint8),'L').filter(ImageFilter.GaussianBlur(2)));dy,dx=np.gradient((lum-local)*.07/45);normal=np.stack([-dx,-dy,np.ones_like(dx)],2);normal/=np.linalg.norm(normal,axis=2,keepdims=True);Image.fromarray(np.clip((normal+1)*127.5,0,255).astype(np.uint8),'RGB').save(out/m['normalTexture'],optimize=True);m['extras']['periodic_boundary_correction']=True;records.append({'material':key,'boundary_band_px':128,'unmasked_pixels_unchanged':True,'pixel_diff_max_outside_mask':0,'albedo_sha256':A.sha(out/m['baseColorTexture'])})
for mesh in model['meshes']:
 if mesh['material']!='body':continue
 pos=np.array(mesh['positions']).reshape(-1,3);uv=[]
 for x,y,z in pos:
  fac=max(abs(x)/.100,abs(z)/.075,1e-9);xx=x/fac;zz=z/fac
  if abs(zz)>=.075-1e-8:distance=(xx+.100)if zz>0 else(.350+.100-xx)
  else:distance=(.200+.075-zz)if xx>0 else(.550+zz+.075)
  uv.append((distance/.200*(1560/2048),y/.050*(400/2048)))
 mesh['uvs']=np.array(uv).ravel().tolist()
A.M.ensure_uv_faces(model['meshes']);A.H.ensure_float32_uv(model['meshes']);model['metadata'].update(model_revision='hmhome-photo-fidelity-v3',wood_uv_revision='Recomputed continuous rectangular perimeter mapping from physical positions; predecessor UV repair offsets are not reused.',wood_periodic_boundary_band_px=128,predecessor_sha256=e['sha256']);A.dump(out/'model.json',model);report=A.export_assets(out/'model.json',out,e['id']);glb=out/(e['id']+'.glb');doc,binary=A.read_glb(glb);doc['samplers']=[{'magFilter':9729,'minFilter':9987,'wrapS':10497,'wrapT':10497}]
for t in doc.get('textures',[]):t['sampler']=0
A.write_glb(glb,doc,A.M.embed_tangents(doc,binary));entry=dict(e);entry.update(asset_dir=str(out),model_path=str(out/'model.json'),glb_path=str(glb),sha256=A.sha(glb),bytes=glb.stat().st_size,model_revision='hmhome-photo-fidelity-v3',frozen=False,independent_validation=str(R/'independent-validation.json'),geometry_validation=str(out/'geometry-validation.json'),material_validation=str(out/'material-validation.json'))
for k in['native_renders','scn_path','native_scn_sha256','source_comparison_path']:entry.pop(k,None)
A.dump(R/'manifest.json',[entry]);A.dump(R/'texture-boundary-validation.json',{'valid':True,'source_master_unchanged':A.sha(e['original_image'])==e['original_image_sha256'],'predecessor_glb_unchanged':A.sha(e['glb_path'])==before,'records':records});print('WOOD REV03',entry['sha256'],entry['bytes'])
