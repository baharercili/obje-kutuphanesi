"""Independent check of the delivered GLB bytes, identities and immutable masters."""
from pathlib import Path
import json,struct,hashlib,io,re
import numpy as np
from PIL import Image
R=Path(__file__).resolve().parent
IDS={'1353289002','1331957002','1356207001','1339079001','1351806001'}
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def glb(p):
 b=p.read_bytes();magic,version,length=struct.unpack_from('<4sII',b);assert magic==b'glTF'and version==2 and length==len(b)
 off=12;doc=None;binary=None
 while off<len(b):
  size,kind=struct.unpack_from('<II',b,off);data=b[off+8:off+8+size];off+=8+size
  if kind==0x4E4F534A:doc=json.loads(data)
  elif kind==0x004E4942:binary=data
 assert doc and binary is not None
 return doc,binary
def check(e):
 path=Path(e['glb_path']);doc,binary=glb(path);meta=doc['extras']['metadata'];model=json.loads(Path(e['model_path']).read_text());assert meta==model['metadata'];assert sha(path)==e['sha256'];assert meta['brand']=='H&M Home'and meta['sku']==e['sku'];assert meta['units']=='metres'and meta['up_axis']=='Y';assert meta['diameter_semantics']==e['diameter_semantics'];assert meta['estimated_fields']==e['estimated_fields'];assert all('uri'not in q for q in doc['buffers']);assert all(not any(k in q for k in['matrix','translation','rotation','scale'])for q in doc['nodes'])
 def arr(index):
  a=doc['accessors'][index];v=doc['bufferViews'][a['bufferView']];dt={5126:'<f4',5125:'<u4',5123:'<u2',5121:'u1'}[a['componentType']];ch={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}[a['type']];sz=np.dtype(dt).itemsize
  return np.ndarray((a['count'],ch),dtype=dt,buffer=binary,offset=v.get('byteOffset',0)+a.get('byteOffset',0),strides=(v.get('byteStride',ch*sz),sz)).copy()
 positions=[];checks=[]
 for mesh in doc['meshes']:
  for p in mesh['primitives']:
   att=p['attributes'];pos=arr(att['POSITION']).astype(float);nor=arr(att['NORMAL']).astype(float);uv=arr(att['TEXCOORD_0']).astype(float);tan=arr(att['TANGENT']).astype(float);faces=arr(p['indices']).reshape(-1,3);assert p.get('mode',4)==4;assert all(np.isfinite(q).all()for q in[pos,nor,uv,tan]);assert faces.max()<len(pos)
   assert abs(np.linalg.norm(nor,axis=1)-1).max()<2e-5;assert abs(np.linalg.norm(tan[:,:3],axis=1)-1).max()<2e-5;assert abs(np.einsum('ij,ij->i',nor,tan[:,:3])).max()<2e-5;assert set(np.unique(tan[:,3]))<={-1,1}
   du=uv[faces[:,1]]-uv[faces[:,0]];dv=uv[faces[:,2]]-uv[faces[:,0]];det=du[:,0]*dv[:,1]-du[:,1]*dv[:,0];assert np.all(abs(det)>0),(e['id'],mesh['name'],'float32 UV collapse')
   vertices,mapping=np.unique(np.round(pos,9),axis=0,return_inverse=True);f=mapping[faces];directed=np.concatenate((f[:,[0,1]],f[:,[1,2]],f[:,[2,0]]));edges,inv,counts=np.unique(np.sort(directed,axis=1),axis=0,return_counts=True,return_inverse=True);assert np.all(counts==2);orientation=np.where(directed[:,0]<directed[:,1],1,-1);assert np.all(np.bincount(inv,weights=orientation)==0)
   a,b,c=vertices[f[:,0]],vertices[f[:,1]],vertices[f[:,2]];areas=np.linalg.norm(np.cross(b-a,c-a),axis=1);assert np.all(areas>1e-14);vol=float(np.einsum('ij,ij->i',a,np.cross(b,c)).sum()/6);assert vol>0
   checks.append(dict(mesh=mesh['name'],vertices=len(pos),triangles=len(f),closed=True,consistent_winding=True,volume_m3=vol,unit_normals=True,unit_orthogonal_tangents=True,nondegenerate_float32_uvs=True));positions.append(pos)
 positions=np.concatenate(positions);lo=positions.min(0);hi=positions.max(0);dims=np.array(e['dimensions_cm'])/100;assert np.allclose(hi-lo,dims,atol=2e-7);assert abs(lo[1])<1e-8;assert abs((hi+lo)[[0,2]]).max()<2e-7
 assert sum(q['volume_m3']for q in checks)<np.prod(dims)*.55
 embedded=[]
 for im in doc['images']:
  assert'uri'not in im and im['mimeType']=='image/png';v=doc['bufferViews'][im['bufferView']];pixels=Image.open(io.BytesIO(binary[v.get('byteOffset',0):v.get('byteOffset',0)+v['byteLength']]));assert pixels.size==(2048,2048)and pixels.mode=='RGB';embedded.append(dict(name=im.get('name'),pixels=[2048,2048],embedded=True))
 for ma in doc['materials']:
  assert not ma.get('doubleSided',False);p=ma['pbrMetallicRoughness'];assert'baseColorTexture'in p and'metallicRoughnessTexture'in p and'normalTexture'in ma
 for ma in model['materials'].values():
  assert ma['extras']['intrinsic_material']and (not ma['extras']['photo_pixels_baked']or ma['extras'].get('own_photo_material_crop'))and not ma['extras']['baked_reflections'];orm=np.array(Image.open(Path(e['asset_dir'])/ma['metallicRoughnessTexture']));assert orm[:,:,2].min()==orm[:,:,2].max();assert int(orm[0,0,2])in[0,255]
 return dict(id=e['id'],sku=e['sku'],sha256=sha(path),valid=True,bounds_min_m=lo.tolist(),bounds_max_m=hi.tolist(),dimensions_cm=((hi-lo)*100).tolist(),meshes=checks,embedded_images=embedded,source_metadata_embedded=True,diameter_semantics=meta['diameter_semantics'],estimated_fields=meta['estimated_fields'])
if __name__=='__main__':
 entries=json.loads((R/'manifest.json').read_text());checks=[check(e)for e in entries]
 for e in entries:
  assert e['bytes']<40*1024*1024
  for p in e['original_images']:assert sha(p['path'])==p['sha256']
 old=json.loads((R/'frozen-predecessors-unchanged.json').read_text())
 for p,h in old['sha256'].items():assert sha(p)==h
 dump(R/'independent-validation.json',dict(valid=True,models=len(checks),checks=checks,source_photos_unchanged=True,frozen_predecessors_unchanged=True,self_contained_glbs=True,all_texture_canvases_2k=True,material_crop_resampling_count=0));print('INDEPENDENT REVISION QA PASSED:',len(checks),'models',flush=True)
