"""Perforated folded paper as real closed-thickness geometry; no photo planes."""
from pathlib import Path
import sys,math,json
sys.dont_write_bytecode=True
import numpy as np
from PIL import Image,ImageDraw,ImageFilter
import build_accessories as A
from build_ornaments import eye
B=A.B;T=math.tau
def folded_snowflake(radius=.06,design=0,res=384,offset=(0,0,0),name='lace-star'):
 mask=Image.new('1',(res,res));d=ImageDraw.Draw(mask);arms=8 if design!=1 else 12
 def xy(x,y,a):return(res/2+(x*math.cos(a)-y*math.sin(a))*res*.475,res/2+(x*math.sin(a)+y*math.cos(a))*res*.475)
 outline=[(0,1),(-.025,.88),(-.09,.94),(-.135,.91),(-.14,.82),(-.20,.82),(-.23,.76),(-.22,.68),(-.28,.66),(-.30,.61),(-.28,.52),(-.20,.46),(-.25,.42),(-.20,.30),(0,0)]
 outline+= [(-x,y)for x,y in reversed(outline[1:-1])]
 if design==1:outline=[(0,1),(-.06,.72),(-.20,.82),(-.13,.55),(-.24,.54),(-.16,.32),(0,0),(.16,.32),(.24,.54),(.13,.55),(.20,.82),(.06,.72)]
 for k in range(arms):
  a=T*k/arms;d.polygon([xy(x,y,a)for x,y in outline],fill=1)
  holes=[(-.10,.54,.045,.155),(.10,.54,.045,.155),(-.13,.77,.030,.070),(.13,.77,.030,.070),(0,.81,.027,.080)]
  if design==1:holes=[(0,.57,.025,.16),(-.07,.70,.018,.055),(.07,.70,.018,.055)]
  if design==2:holes+=[(-.20,.62,.028,.037),(.20,.62,.028,.037)]
  for cx,cy,rx,ry in holes:d.polygon([xy(cx+rx*math.cos(t),cy+ry*math.sin(t),a)for t in np.linspace(0,T,36)[:-1]],fill=0)
 d.ellipse((res*.46,res*.46,res*.54,res*.54),fill=1);q=np.array(mask,dtype=bool)
 # A diagonal-only raster contact would become a four-face thickness edge.
 # Join that subpixel contact into a finite paper bridge before meshing.
 for repeat in range(20):
  a=q[:-1,:-1];b=q[:-1,1:];c=q[1:,:-1];e=q[1:,1:];bad=(a&e&~b&~c)|(b&c&~a&~e);ys,xs=np.where(bad)
  if not len(xs):break
  q[ys,xs]=True;q[ys+1,xs]=True;q[ys,xs+1]=True;q[ys+1,xs+1]=True
 else:raise ValueError('Unresolved diagonal-only paper contacts')
 ids={};v=[];uv=[];f=[];step=2*radius/(res*.95);th=.00018
 def vertex(x,y,side):
  key=(x,y,side)
  if key not in ids:
   xx=(x-res/2)*step;yy=(y-res/2)*step;r=math.hypot(xx,yy);ang=math.atan2(yy,xx);zz=r*.18*math.cos(arms*ang)+side*th/2;ids[key]=len(v);v.append((xx+offset[0],yy+offset[1],zz+offset[2]));uv.append((x/res,y/res))
  return ids[key]
 for y,x in np.argwhere(q):
  corners=[(x,y),(x+1,y),(x+1,y+1),(x,y+1)];front=[vertex(a,b,1)for a,b in corners];back=[vertex(a,b,-1)for a,b in corners];f.extend([(front[0],front[1],front[2]),(front[0],front[2],front[3]),(back[2],back[1],back[0]),(back[3],back[2],back[0])])
  for i,(nx,ny)in enumerate([(x,y-1),(x+1,y),(x,y+1),(x-1,y)]):
   if nx<0 or ny<0 or nx>=res or ny>=res or not q[ny,nx]:a=i;b=(i+1)%4;f.extend([(front[a],back[a],front[b]),(front[b],back[a],back[b])])
 vv=np.asarray(v);lo=vv[:,:2].min(0);hi=vv[:,:2].max(0);mid=(lo+hi)/2;factor=2*radius/max(hi-lo)
 vv[:,:2]=(vv[:,:2]-mid)*factor+np.array(offset[:2]);vv[:,2]=(vv[:,2]-offset[2])*factor+offset[2]
 return A.raw(name,'paper',vv.tolist(),f,uv)
def lace_single(diameter,design=0):
 r=diameter/200;parts=[folded_snowflake(r,design,512 if diameter>=40 else 384)];parts.append(B.tube('thin-white-or-red-suspension-cord','cord',[(.0012*math.sin(a),r+.05*(1+math.cos(a)),0)for a in np.linspace(0,T,129)[:-1]],.00025,.00025,6,True,guide=[0,0,1]));return parts,['Perforated lace-cut paper with actual through-holes, physical0.18 mm thickness and eight radial accordion ridges','Own rounded scalloped eight-arm silhouette and paired long teardrop/outer cut-outs','Real suspension cord; no photograph or alpha card used as geometry'],{'piece_dimensions_cm':{'diameter':diameter},'pattern_interpretation':'Lace outline and hole placement are reconstructed from the exact photo; individual die-cut contours are interpreted, not manufacturer CAD.','paper_thickness_interpreted_mm':.18}
def lace_six():
 parts=[]
 for k in range(6):
  r=.085/2;x=(k%3-1)*.11;y=(k//3)*.17+r;parts.append(folded_snowflake(r,k%3,192,(x,y,0),'separate-lace-paper-star-'+str(k+1)));parts.append(B.tube('own-white-hanging-cord-'+str(k),'cord',[(x+.0010*math.sin(a),y+r+.027*(1+math.cos(a)),0)for a in np.linspace(0,T,97)[:-1]],.00020,.00020,6,True,guide=[0,0,1]))
 return parts,['Six actual lace-cut folded stars in three distinct photographed designs; one product SKU','8.5 cm body diameter retained for each; real perforations and thin paper thickness','3×2 arrangement and cord length are photo-scaled display layout'],{'set_quantity':6,'piece_dimensions_cm':{'diameter':8.5},'pattern_interpretation':'Three photographed die-cut families reconstructed; precise small hole contours interpreted.'}
def houses():
 parts=[];panel=.567/10;theta=math.radians(35);cursor=-.567*math.cos(theta)/2
 heights=[.130,.100,.142,.150,.135,.145,.130,.150,.136,.139]
 for k,h in enumerate(heights):
  local=[];wall=h*.75;w=panel
  # Physical paper fields and narrow window mullions leave all windows genuinely open.
  for xx in[-w/2+.002,w/2-.002]:local.append(B.box('side-pier-'+str(k)+'-'+str(xx),'paper',.004,wall,.0003,(xx,wall/2,0)))
  levels=4;wy=wall/levels
  for row in range(levels+1):local.append(B.box('floor-band-'+str(k)+'-'+str(row),'paper',w,.004,.0003,(0,.002+row*(wall-.004)/levels,0)))
  for col in[-1,0,1]:
   x=col*w*.25
   for row in range(levels):
    y=(row+.5)*wy
    for dx in[-w*.075,w*.075,0]:local.append(B.box('window-real-vertical-crossbar-'+str(k)+'-'+str(col)+'-'+str(row)+'-'+str(dx),'paper',.0010,wy-.004,.0003,(x+dx,y,0)))
    local.append(B.box('window-real-horizontal-crossbar-'+str(k)+'-'+str(col)+'-'+str(row),'paper',w*.15,.0010,.0003,(x,y,0)))
  # Characteristic bell/step/triangle gables are built as solid thin trapezoid bands.
  roof=h-wall;style=k%4
  for j in range(28):
   t=(j+.5)/28;y=wall+t*roof
   if style==0:ww=w*(.18+.78*(.5+.5*math.cos(math.pi*t)))
   elif style==1:ww=w*(1-.86*t)
   elif style==2:ww=w*(1 if t<.2 else .75 if t<.50 else .42 if t<.78 else .14)
   else:ww=w*(.15+.85*(1-t)**.6)
   local.append(B.box('solid-cut-paper-gable-profile-'+str(k)+'-'+str(j),'paper',ww,roof/28,.0003,(0,y,0)))
  angle=theta*(1 if k%2==0 else-1);cx=cursor+panel*math.cos(theta)/2;cz=panel*math.sin(theta)/2
  for g in local:
   g['_vertices']=[(cx+x*math.cos(angle)+z*math.sin(angle),y,cz-x*math.sin(angle)+z*math.cos(angle))for x,y,z in g['_vertices']];g['name']='facade-'+str(k+1)+'-'+g['name'];parts.append(g)
  cursor+=panel*math.cos(theta)
 return parts,['Ten distinct cream paper row-house façades with bell, triangular and stepped roof profiles','Real open multi-pane windows, separate fine crossbars, substantial paper fields and thin300µm thickness','Accordion display: ten5.67 cm panels preserve official unfolded length56.7 cm;35° folding angle is photo interpretation'],{'unfolded_length_cm':56.7,'photo_interpreted_facade_count':10,'photo_interpreted_fold_degrees':35,'bounds_semantics':'Official H15 cm and unfolded length56.7 cm. Folded width and depth are display interpretations.'}
for sku,name,diam,color,rgb,design in[
 ('1244824001','Büyük kağıt kar tanesi süs',40,'Beyaz',[239,232,210],0),('1244814001','Kağıt kar tanesi süs',12,'Beyaz',[239,232,210],0),('1244814002','Kağıt kar tanesi süs',12,'Kırmızı',[139,17,35],0)]:
 A.SPECS[sku]={'name':name,'dims':[diam,diam*1.52,diam*.30],'hwd':[None,None,None],'build':lambda d=diam,t=design:lace_single(d,t),'derive_dimensions':True,'estimated':['overall_hanging_height_cm','folded_depth_cm','die_cut_outline_interpretation'],'label':'Kağıt %100 · '+color,'color':color,'semantics':f'Resmî kağıt gövde çapı {diam} cm; asma ipi dahil toplam yükseklik, kâğıt kalınlığı ve kat derinliği fotoğraftan yorumlanır. Kesim deseninin yerel ayrıntıları yorumdur.','materials':{'paper':('paper',rgb,.69,0),'cord':('paper',rgb,.73,0)}}
A.SPECS['1355009001']={'name':'6’lı dantel kesimli kağıt yılbaşı süsü','dims':[30.5,30,3],'hwd':[None,None,None],'build':lace_six,'derive_dimensions':True,'estimated':['overall_display_bounds_cm','hanging_cord_length_cm','die_cut_outline_interpretation'],'label':'Kağıt %100 · Krem','color':'Krem','semantics':'Resmî çap8.5 cm her kağıt süs gövdesine aittir; set tek SKU, üç farklı tasarımdan ikişer parça. Toplam yerleşim ve kat derinliği fotoğraftan yorumlanmıştır.','materials':{'paper':('paper',[240,232,210],.69,0),'cord':('paper',[237,233,219],.74,0)}}
A.SPECS['1354954001']={'name':'Ev sıralı katlanabilir kağıt yılbaşı süsü','dims':[46.45,15,3.3],'hwd':[15,None,None],'build':houses,'derive_dimensions':True,'estimated':['folded_display_width_cm','folded_display_depth_cm','individual_window_and_gable_contours'],'label':'Kağıt %100 · Krem','color':'Krem','semantics':'Resmî yükseklik15 cm ve açılmış uzunluk56.7 cm korunur. Katlı yerleşimin genişlik/derinliği ve cephe ayrıntıları kendi fotoğraflarından yorumdur.','materials':{'paper':('paper',[237,229,204],.71,0)}}
if __name__=='__main__':
 for sku in sys.argv[1:]or['1244824001','1244814001','1244814002','1355009001','1354954001']:A.build(sku)
