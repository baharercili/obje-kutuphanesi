"""Observed H&M forms, closed material solids, immutable photos, intrinsic 2K PBR."""
from pathlib import Path
import sys,json,math,hashlib,shutil,importlib.util,fcntl
sys.dont_write_bytecode=True
import numpy as np
from PIL import Image
R=Path(__file__).resolve().parent; P=R.parent; Z=P.parents[1]/'zarahome-dekor'
sys.path.insert(0,str(Z))
from export_catalog import export_assets,read_glb,write_glb
from vase_geometry import _finalize
def module(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
H=module('hm_vase_helpers_readonly',P/'vases/build_vases.py');M=H.M;B=H.B;T=math.tau
def dump(path,x):Path(path).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def raw(name,mat,v,f,uv=None):return B.solid(name,mat,v,f,uv)
def outline(w,d,r=.006,n=192):return M.G.rounded(w,d,r,n,cy=0)
def ring(name,mat,profiles):
 n=len(profiles[0][0]);v=[];uv=[];f=[]
 for shape,y in profiles:
  for i,(x,z)in enumerate(shape):v.append((x,y,z));uv.append((y*17,i/n))
 for j in range(len(profiles)):
  for i in range(n):a=j*n+i;c=j*n+(i+1)%n;b=((j+1)%len(profiles))*n+i;d=((j+1)%len(profiles))*n+(i+1)%n;f.extend([(a,b,c),(c,b,d)])
 return raw(name,mat,v,f,uv)
def capped(name,mat,profiles,planar=False):
 n=len(profiles[0][0]);v=[];uv=[];f=[]
 for shape,y in profiles:
  for i,(x,z)in enumerate(shape):v.append((x,y,z));uv.append((x*5+.5,z*5+.5)if planar else(i/n,y*8))
 for j in range(len(profiles)-1):
  for i in range(n):a=j*n+i;c=j*n+(i+1)%n;b=(j+1)*n+i;d=(j+1)*n+(i+1)%n;f.extend([(a,b,c),(c,b,d)])
 for j in[0,len(profiles)-1]:
  center=len(v);v.append((0,profiles[j][1],0));uv.append((.5,.5))
  for i in range(n):f.append((center,j*n+i,j*n+(i+1)%n)if j==len(profiles)-1 else(center,j*n+(i+1)%n,j*n+i))
 return raw(name,mat,v,f,uv)
def wood_box():
 outer=lambda w,d: outline(w,d,.006)
 parts=[ring('rounded-Arjuna-box-four-continuous-walls-and-visible-open-interior','body',[(outer(.197,.147),.0005),(outer(.200,.150),.003),(outer(.200,.150),.047),(outer(.199,.149),.050),(outer(.185,.135),.050),(outer(.184,.134),.046),(outer(.184,.134),.005),(outer(.191,.141),.0005)]),capped('real-solid-Arjuna-box-inner-floor','top',[(outer(.188,.138),.001),(outer(.188,.138),.006)],True),capped('separate-removable-stackable-lid-with-real-shallow-top-recess','top',[(outer(.198,.148),.051),(outer(.200,.150),.0525),(outer(.200,.150),.059),(outer(.198,.148),.060),(outer(.180,.130),.060),(outer(.173,.123),.057),(outer(.172,.122),.055)],True)]
 return parts,['Own 20×15 cm rounded rectangular Arjuna wood box, real hollow body and separate 5 mm floor','Removable 9 mm lid has a broad shallow recessed stacking tray, rounded inner transition and continuous real rim','Fine dark lid/body reveal; no invented hinges, knob or dividers'],{}
def marble_jar():
 body=B.lathe('hollow-marble-jar-with-rounded-solid-base-and-polished-thick-rim','stone',[(0,0),(.036,0),(.0405,.0005),(.0425,.0025),(.0425,.087),(.0418,.090),(.0365,.090),(.036,.088),(.036,.008),(.034,.006),(0,.006)],192,False)
 lid=B.lathe('separate-flat-removable-marble-lid-with-real-recessed-locator','stone',[(0,.0895),(.033,.0895),(.035,.091),(.0408,.091),(.0425,.092),(.0425,.0988),(.0417,.100),(0,.100)],192,False)
 body['_uvs']=[(math.atan2(z,x)/T+.5,y/.100)for x,y,z in body['_vertices']]
 lid['_uvs']=[(x/.085+.5,z/.085+.5)for x,y,z in lid['_vertices']]
 return[body,lid],['Own beige-brown fossil-like cloudy marble, straight cylindrical wall with rounded lower corner','Real hollow body, solid bottom, separate flat circular lid and interior locator','Fine dark lid/body reveal; no invented knob or feet'],{}
def striped_bauble_set():
 parts=[]
 for k in range(6):
  x=(k%3-1)*.060;row=(k//3)*.150;r=.0225
  profile=[(r*math.sin(a),row+r-r*math.cos(a))for a in np.linspace(0,math.pi,65)];profile[0]=(0,row);profile[-1]=(0,row+.045)
  parts.append(B.lathe('satin-thread-striped-spherical-bauble-'+str(k+1),'stripe',profile,144,False,offset=(x,0,0)))
  parts.append(B.lathe('fluted-warm-gold-cap-'+str(k+1),'gold',[(0,row+.044),(.005,row+.044),(.0054,row+.045),(.0053,row+.048),(.0048,row+.049),(0,row+.049)],64,False,offset=(x,0,0)))
  for j in range(18):
   a=T*j/18;parts.append(B.tube('cap-crimp-'+str(k)+'-'+str(j),'gold',[(x+.0051*math.cos(a),row+.0448,.0051*math.sin(a)),(x+.0051*math.cos(a),row+.048,.0051*math.sin(a))],.00017,.00017,6,False,guide=[0,1,0]))
  wire=[(x+.0022*math.cos(a),row+.051+.0022*math.sin(a),0)for a in np.linspace(0,T,65)[:-1]];parts.append(B.tube('true-gold-hanger-eye-'+str(k),'gold',wire,.00032,.00032,8,True,guide=[0,0,1]))
  loop=[(x+.0018*math.sin(a),row+.081+.0275*math.cos(a),.0004*math.sin(a*2))for a in np.linspace(0,T,97)[:-1]];parts.append(B.tube('real-narrow-satin-hanging-ribbon-loop-'+str(k),'ribbon',loop,.00065,.00014,8,True,guide=[0,0,1]))
  parts.append(B.tube('small-ribbon-knot-'+str(k),'ribbon',[(x-.001,.106+row,0),(x+.001,.109+row,.0005),(x-.001,.110+row,0),(x+.001,.112+row,-.0005)],.0008,.0005,8,False,guide=[0,0,1]))
 return parts,['Six real spherical 4.5 cm ornaments under one SKU, separate solid caps with eighteen physical crimps each','Own alternating satin-thread stripe colours, fine intrinsic thread normals and individual gold hanging eyes','Six genuine narrow ribbon loops; 3×2 display layout is a modelling arrangement, not an official overall product dimension'],{'set_quantity':6,'piece_dimensions_cm':{'diameter':4.5},'bounds_semantics':'Six-piece display layout. Official 4.5 cm is per sphere; all overall layout axes are explicitly estimated.','display_layout':'3 columns × 2 rows; each spherical body preserves official diameter 4.5 cm.'}
def material(pid,key,kind,rgb,rough=.45,metal=0):
 if kind=='metal'and'glitter'in key:kind='glitter'
 out=R/'materials'/pid;out.mkdir(parents=True,exist_ok=True);N=2048;rng=np.random.default_rng(int(hashlib.sha256((pid+key).encode()).hexdigest()[:8],16));u=np.arange(N,dtype=np.float32)[None,:]/N;v=np.arange(N,dtype=np.float32)[:,None]/N
 fine=rng.normal(0,1,(N,N)).astype(np.float32);a=rng.normal(0,1,(24,24)).astype(np.float32);cloud=np.asarray(Image.fromarray(a,'F').resize((N,N),Image.Resampling.BICUBIC),dtype=np.float32)
 if kind=='wood':
  warp=u+.003*np.sin(T*v*.7)+.001*np.sin(T*v*3.3)+cloud*.00035
  positions=rng.uniform(0,1,380);widths=rng.uniform(.00012,.0016,380);strength=rng.uniform(.15,1,380);grain=np.zeros((N,N),np.float32)
  for pos,wide,amp in zip(positions,widths,strength):grain-=np.exp(-((warp-pos)/wide)**2)*amp
  grain=np.clip(grain,-2.4,0)+cloud*.09
  color=np.array(rgb,dtype=np.float32)[None,None,:]+grain[:,:,None]*np.array([22,16,10])+fine[:,:,None]*.35;height=grain*.055+fine*.007;rr=rough+grain*.018
 elif kind=='marble':
  def field(n):return np.asarray(Image.fromarray(rng.normal(0,1,(n,n)).astype(np.float32),'F').resize((N,N),Image.Resampling.BICUBIC))
  f=field(9)*.65+cloud*.32+field(86)*.12;patch=(np.tanh((f-.12)*5)+1)/2;cream=np.array([225,212,188]);brown=np.array([137,107,78]);veins=np.exp(-((f-.02)/.018)**2);fossil=field(178)*.10;color=cream[None,None,:]*(1-patch[:,:,None])+brown[None,None,:]*patch[:,:,None]+fossil[:,:,None]*np.array([20,18,15])+veins[:,:,None]*6+fine[:,:,None]*.18;height=fine*.006;rr=rough+f*.012
 elif kind.startswith('stripe_'):
  green=kind.endswith('green');cycle=(u*(8 if green else 6))%1;dark=(cycle<(.27 if green else .50)).astype(np.float32);light=np.array([225,221,204]if green else[172,18,43]);deep=np.array([7,46,31]if green else[88,5,20]);threads=np.sin(T*u*1600)*.6+fine*.15;color=light[None,None,:]*(1-dark[:,:,None])+deep[None,None,:]*dark[:,:,None]+threads[:,:,None]*2;color=np.broadcast_to(color,(N,N,3));height=np.broadcast_to(np.sin(T*u*1600)*.15,(N,N));rr=rough+threads*.018
 elif kind=='paper':
  fiber=np.sin(T*(u*837+v*.13))*.25+fine*.12;color=np.array(rgb,dtype=np.float32)[None,None,:]+cloud[:,:,None]*1.2+fiber[:,:,None];height=fiber*.014;rr=np.broadcast_to(rough,(N,N))
 elif kind=='glitter':
  cell=5;side=(N+cell-1)//cell;facets=rng.uniform(-1,1,(side,side,3)).astype(np.float32);facet=np.repeat(np.repeat(facets,cell,axis=0),cell,axis=1)[:N,:N]
  color=np.array(rgb,dtype=np.float32)[None,None,:]+facet[:,:,2,None]*19;height=np.zeros((N,N),np.float32);rr=np.clip(rough+facet[:,:,2]*.19,.08,.73)
 elif kind=='metal':
  color=np.broadcast_to(np.array(rgb,dtype=np.float32)[None,None,:],(N,N,3));height=np.zeros((N,N),np.float32);rr=np.broadcast_to(rough,(N,N))
 else:
  color=np.array(rgb,dtype=np.float32)[None,None,:]+cloud[:,:,None]*1.4+fine[:,:,None]*.35;height=fine*.025;rr=rough+fine*.01
 rr=np.broadcast_to(rr,(N,N));dy,dx=np.gradient(height);normal=np.stack([-dx,-dy,np.ones_like(dx)],axis=2)
 if kind=='glitter':normal[:,:,:2]=facet[:,:,:2]*.65
 normal/=np.linalg.norm(normal,axis=2,keepdims=True);orm=np.zeros((N,N,3),np.uint8);orm[:,:,0]=255;orm[:,:,1]=np.clip(rr*255,8,250);orm[:,:,2]=int(metal*255)
 name=pid+'-'+key
 for slot,arr in [('albedo',np.clip(color,0,255).astype(np.uint8)),('normal',np.clip((normal+1)*127.5,0,255).astype(np.uint8)),('orm',orm)]:Image.fromarray(arr,'RGB').save(out/(name+'-'+slot+'-2k.png'),optimize=True)
 return out,dict(baseColorFactor=[1,1,1,1],baseColorTexture=name+'-albedo-2k.png',normalTexture=name+'-normal-2k.png',metallicRoughnessTexture=name+'-orm-2k.png',normalScale=.32,metallic=1,roughness=1,doubleSided=False,alphaMode='OPAQUE',extras={'native_resolution':2048,'intrinsic_material':True,'photo_pixels_baked':False,'baked_reflections':False,'appearance_photo_interpreted':True,'individual_grain_or_marble_pattern_approximate':True})
SPECS={'1319209002':{'name':'Arjuna ahşap düzenleyici kutu','dims':[20,6,15],'hwd':[6,20,15],'build':wood_box,'estimated':[],'label':'Arjuna masif ahşap · Kahverengi','color':'Kahverengi','semantics':'Resmî Y6 × G20 × D15 cm aynen korundu. Duvar, kapak ve sığ üst girinti kalınlıkları kendi fotoğrafından yorumlandı.','materials':{'body':('wood',[113,76,45],.40,0),'top':('wood',[113,76,45],.40,0)},'primary_hash':'09c2d70b2849'}}
SPECS['1347756001']={'name':'Kapaklı mermer kap','dims':[8.5,10,8.5],'hwd':[10,None,None],'build':marble_jar,'estimated':[],'label':'Mermer %100 · Açık bej/Kahverengi','color':'Açık bej/Kahverengi','semantics':'Resmî yükseklik 10 cm ve çap 8,5 cm. Çap iki yatay eksende aynen korundu; duvar ve kapak yerel profilleri fotoğraftan yorumlandı.','materials':{'stone':('marble',[180,164,142],.30,0)},'primary_hash':'40d86b0e845'}
for sku,col,kind,ribbon,primary in [('1247880003','Kırmızı/Bordo','stripe_red',[98,8,26],'c194fe84e426'),('1247880004','Krem/Koyu yeşil','stripe_green',[7,43,28],'f1aa4d8900a')]:
 SPECS[sku]={'name':'6’lı küçük saten ip kaplı yılbaşı süsü','dims':[16.5,26.2,4.5],'hwd':[None,None,None],'build':striped_bauble_set,'derive_dimensions':True,'estimated':['overall_display_width_cm','overall_display_height_cm','ribbon_loop_length_cm'],'label':'Polietilen %80 · Poliamid %20 · '+col,'color':col,'semantics':'Resmî çap 4,5 cm her kürenin gövdesine aittir. Set tek SKU kaydıdır. 3×2 sergileme yerleşiminin toplam genişliği/yüksekliği ve kurdele uzunluğu fotoğraftan yorumlanmıştır; resmî set ölçüsü değildir.','materials':{'stripe':(kind,[0,0,0],.30,0),'gold':('smooth',[195,158,83],.23,1),'ribbon':('smooth',ribbon,.46,0)},'primary_hash':primary}
def record_entry(entry,out):
 dump(out/'entry.json',entry)
 with(R/'.manifest.lock').open('w')as lock:
  fcntl.flock(lock,fcntl.LOCK_EX);path=R/'manifest.json';manifest=json.loads(path.read_text())if path.exists()else[];manifest=[e for e in manifest if e['id']!=entry['id']and e['sku']!=entry['sku']]+[entry];temp=R/'manifest.next.json';dump(temp,manifest);temp.replace(path)
def build(pid):
 for frozen in[R/'frozen-family-01-manifest.json',R/'frozen-family-02-manifest.json',R/'frozen-delivery-manifest.json',R/'frozen-quality-completion-01-manifest.json',R/'frozen-all36-manifest.json',R/'frozen-source-recovery-01-manifest.json',R/'frozen-source-recovery-02-manifest.json',R/'frozen-all58-manifest.json']:
  if frozen.exists()and pid in[e['sku']for e in json.loads(frozen.read_text())]:raise RuntimeError('Frozen reviewed source and model may not be rebuilt: '+pid)
 s=SPECS[pid];sources=json.loads((R/'source-inventory.json').read_text());q=next(q for q in sources if q['sku']==pid);assert q['identity_verified']and(q['official_measurements']or q.get('official_measurement_ranges'));refs=[p for p in json.loads((R/'original-image-masters.json').read_text())if p['sku']==pid];assert refs
 primary=next((p for p in refs if s.get('primary_hash','___')in p['path']),refs[0]);parts,features,extra=s['build']();positions=np.concatenate([np.asarray(g['_vertices'])for g in parts]);lo=positions.min(0);hi=positions.max(0)
 if s.get('derive_dimensions'):s['dims']=[round(float(v),5)for v in(hi-lo)*100]
 fmt=lambda x:format(x,'g').replace('.','p');w,h,d=s['dims'];id=f'hm-{pid}-h{fmt(h)}-w{fmt(w)}-d{fmt(d)}';out=R/'models'/id;out.mkdir(parents=True,exist_ok=True);dims=np.array(s['dims'])/100;scale=dims/(hi-lo);center=np.array([(lo[0]+hi[0])/2,lo[1],(lo[2]+hi[2])/2]);meshes=[];checks=[]
 for g in parts:
  g['_vertices']=[tuple((np.array(v)-center)*scale)for v in g['_vertices']];g=H.orient(g);m,c=_finalize(g);H.S.flatcap_normals(m);meshes.append(m);checks.append(c)
 repairs=M.ensure_uv_faces(meshes)+H.ensure_float32_uv(meshes);mats={};maps=[]
 for key,args in s['materials'].items():
  bank,ma=material(pid,key,*args);mats[key]=ma
  for slot in['baseColorTexture','normalTexture','metallicRoughnessTexture']:
   src=bank/ma[slot];target=out/src.name;shutil.copyfile(src,target);maps.append({'material':key,'slot':slot,'path':str(target),'sha256':sha(target),'native_resolution':[2048,2048]})
 meta=dict(id=id,sku=pid,brand='H&M Home',name=s['name'],category='Dekoratif aksesuarlar',url=q['url'],dimensions_cm=s['dims'],source_dimensions_hwd_cm=s['hwd'],official_measurements=q['official_measurements'],official_measurement_labels=q['official_measurement_labels'],estimated_dimensions=bool(s['estimated']),estimated_fields=s['estimated'],diameter_semantics=s['semantics'],scale_note=s['semantics']+' Üretici CAD veya taraması değildir.',material_label=s['label'],color=s['color'],source_market=q.get('source_market','Türkiye'),source_observation_file=q['source_observation_file'],source_evidence_files=[q['source_observation_file']],source_size_pointer=q['source_observation_file']+'#description',source_images=[{'url':p['url'],'alt':p['alt']}for p in refs],original_image=primary['path'],original_image_url=primary['url'],original_image_sha256=primary['sha256'],original_images=[{'path':p['path'],'url':p['url'],'sha256':p['sha256']}for p in refs],variant_status_verbatim='Resmî ürün kimliği ve fiziksel ölçü ankrajı doğrulandı',units='metres',up_axis='Y',origin='bottom bounding-box centre',native_texture_resolution=2048,photo_pixels_baked=False,baked_reflections=False,source_anomalies=[],description_verbatim=q['description'],material_description_verbatim=q.get('materials',''),geometry_limitations=['Local contours, hidden thicknesses, intrinsic surface patterns and unlabelled assembly dimensions are interpretations from the exact source gallery.']);meta.update(extra);meta['official_measurement_ranges']=q.get('official_measurement_ranges',[])
 meta['source_evidence_files']=q.get('source_evidence_files',meta['source_evidence_files']);meta['source_size_pointer']=q.get('source_size_pointer',meta['source_size_pointer'])
 if any(m.get('transmission',0)>0 for m in mats.values()):meta.update(quality_status='preview_limited',quality_label='Yaklaşık cam görünümü',quality_note='Camın renk, yansıma ve kırılma görünümü tarayıcıda yaklaşık gösterilir; malzemeli GLB’yi proje ışığında değerlendirin.')
 dump(out/'model.json',{'metadata':meta,'materials':mats,'meshes':meshes});dump(out/'geometry-validation.json',{'valid':True,'features':features,'mesh_count':len(meshes),'meshes':checks,'closed_material_solids':True,'triangles':sum(c['triangles']for c in checks),'uv_repairs':repairs});dump(out/'material-validation.json',{'valid':True,'native_resolution':2048,'maps':maps,'photo_pixels_baked':False,'baked_reflections':False})
 report=export_assets(out/'model.json',out,id);glb=out/(id+'.glb');doc,binary=read_glb(glb);doc['samplers']=[{'magFilter':9729,'minFilter':9987,'wrapS':10497,'wrapT':10497}]
 for t in doc.get('textures',[]):t['sampler']=0
 binary=M.embed_tangents(doc,binary);write_glb(glb,doc,binary);report['deliverable_sha256']['glb']=sha(glb);report['glb_bytes']=glb.stat().st_size;dump(report['files']['validation'],report)
 fields=['id','sku','brand','name','category','url','dimensions_cm','source_dimensions_hwd_cm','official_measurements','estimated_dimensions','estimated_fields','diameter_semantics','scale_note','material_label','color','source_market','source_size_pointer','source_evidence_files','source_images','original_image','original_image_url','original_image_sha256','original_images','variant_status_verbatim'];entry={k:meta[k]for k in fields};entry.update(asset_dir=str(out),model_path=str(out/'model.json'),glb_path=str(glb),sha256=sha(glb),bytes=glb.stat().st_size,model_revision='hmhome-photo-specific-v1',geometry_validation=str(out/'geometry-validation.json'),material_validation=str(out/'material-validation.json'),size_source_kind='official_tr_public_pdp'if q.get('source_market','Türkiye')in['Türkiye','tr_tr']else'official_other_market_same_exact_sku',size_source_urls=[q.get('dimension_source_url',q.get('official_source_url',q['url']))]);entry.update(extra);entry.update({k:meta[k]for k in['quality_status','quality_label','quality_note']if k in meta});dump(out/'topology-validation.json',M.AQ.check(entry));record_entry(entry,out);print('BUILT',id,entry['bytes'],flush=True)
if __name__=='__main__':
 for pid in sys.argv[1:]or SPECS:build(pid)
