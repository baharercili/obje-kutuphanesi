"""Concrete peer/root photo corrections only. Eight accepted peers and prior45 stay unchanged."""
from pathlib import Path
import sys,math,json
sys.dont_write_bytecode=True
import numpy as np
from PIL import Image
import build_accessories as A
import build_round02_figures as F
import implicit_shapes as I
B=A.B;O=F.O;T=math.tau

def marshmallow_mug():
 p,features,extra=F.mug();p=[g for g in p if not g['name'].startswith('separate-rounded-marshmallow')and not any(q in g['name']for q in['real-crimped-top-cap','physical-top-cap-flute','separate-real-hanger-eye','finite-width-hanging-cord'])]
 # F.mug has already placed/photographically scaled the mug. Reconstruct its own short soft cubes in that same envelope.
 cupmax=max(y for g in p for x,y,z in g['_vertices']);rscale=.07/.062 # source mug+handle body envelope
 for layer,(y,r,count,w)in enumerate([(.057,.0145,6,.014),(.067,.0100,4,.014),(.077,.0048,2,.013)]):
  for k in range(count):
   a=T*k/count+layer*.9;x=r*math.cos(a);z=r*math.sin(a);height=.013
   profiles=[]
   for factor,yy in[(.72,0),(.94,.0014),(1,.003),(1,.010),(.92,.012),(.68,.013)]:profiles.append((A.outline(w*factor,w*.92*factor,.0038*factor,48),y+yy))
   g=A.capped('short-rounded-cube-marshmallow-'+str(layer)+'-'+str(k),'snow',profiles);angle=.22*math.sin(k+layer)
   g['_vertices']=[(x+xx*math.cos(angle)-zz*math.sin(angle),yy,z+xx*math.sin(angle)+zz*math.cos(angle))for xx,yy,zz in g['_vertices']];p.append(g)
 F.finish_body(p);F.hanger(p,.095)
 return p,['Own red cocoa mug/rounded handle and chocolate rim retained','Twelve actual short soft rounded cube/cylinder marshmallows in three staggered layers, with softened flat end faces rather than a pile of perfect spheres','Own HOT COCOA source lettering, gold cap and physically connected eye/cord'],extra

def joined_boots():
 p=[]
 def field(q):
  fields=[]
  for x in[-.017,.017]:
   shaft=I.ell_sdf(q,(x,.055,-.005),(.019,.045,.0165));foot=I.ell_sdf(q,(x,.012,.008),(.0185,.014,.025));instep=I.ell_sdf(q,(x,.029,0),(.0175,.024,.019));fields.append(I.smin(I.smin(shaft,instep,.008),foot,.008))
  return I.smin(fields[0],fields[1],.020)
 I.marching_tetra(p,'one-fused-puffy-double-boot-glass-casting-with-joined-centre','bootglass',field,[[-.041,-.005,-.028],[.041,.105,.040]],.00125)
 body=p[0];body['_uvs']=[(x/.082+.5,1-y/.105)for x,y,z in body['_vertices']]
 def front(x,y):
  zs=np.linspace(-.020,.045,100);pts=np.column_stack([zs*0+x,zs*0+y,zs]);val=field(pts);inside=np.where(val<0)[0]
  if not len(inside):return .009
  lo=zs[inside[-1]];hi=.045
  for j in range(24):mid=(lo+hi)/2;fv=field(np.array([x,y,mid]));lo,hi=(mid,hi)if fv<0 else(lo,mid)
  return(lo+hi)/2+.00045
 for k,x in enumerate([-.017,.017]):
  for j in range(6):
   y=.026+j*.009
   for sign in[-1,1]:
    pts=[]
    for tt in np.linspace(0,1,25):xx=x+(.0105*(2*tt-1));yy=y+.009*(tt if sign==1 else 1-tt);pts.append((xx,yy,front(xx,yy)))
    p.append(B.tube('real-white-crossed-lace-X-'+str(k)+'-'+str(j)+'-'+str(sign),'white',pts,.00055,.00055,6,False,guide=[0,0,1]))
  cy=.086
  for sign in[-1,1]:
   pts=[]
   for a in np.linspace(0,T,65)[:-1]:xx=x+sign*.0035*(1-math.cos(a));yy=cy+.0022*math.sin(a);pts.append((xx,yy,front(xx,yy)+.0005))
   p.append(B.tube('own-upper-white-lace-bow-loop-'+str(k)+'-'+str(sign),'white',pts,.0005,.0005,6,True,guide=[0,0,1]));pts=[]
   for tt in np.linspace(0,1,20):xx=x+sign*.004*tt;yy=cy-.009*tt;pts.append((xx,yy,front(xx,yy)+.0006))
   p.append(B.tube('separate-upper-lace-bow-tail-'+str(k)+'-'+str(sign),'white',pts,.0005,.0005,6,False,guide=[0,0,1]))

 F.finish_body(p);p.append(B.cylinder('short-central-cast-neck-bridging-rounded-shaft-saddle','gold',.004,.088,.097,n=40));F.hanger(p,.097) # closed cast bridge joins the real central saddle to the cap.
 return p,['One continuous smoothly fused puffy double-boot glass casting: rounded twin shaft tops, joined middle seam and rounded projecting toes','Separate white criss-cross X laces and two upper bow loops/free tails per shaft follow the actual curved front surface','Rounded sole edges and champagne glitter/bright gold cuff/toe regions retained from own front plus side photo; no full-height open central slit'],dict(F.GLASS_NOTE,piece_dimensions_cm={'official_labelled_width':7,'official_labelled_height':9.5},source_axis_ambiguity='Official W7/H9.5 anchor the joined glass pair body. Its depth, central saddle/cap placement, cord and fine lace relief are own two-angle interpretations.')

def embossed_snowflake_set():
 p,features,extra=F.small_boots_snowflake();p=[g for g in p if not any(q in g['name']for q in['own-solid-rounded-six-lobed-gold-snowflake','embossed-six-lobe-starburst-ridge'])];sx=-.039;sy=.027;na=192;nr=32;v=[];uv=[];faces=[];segments=[]
 for k in range(6):
  a=math.pi/2+T*k/6;d=np.array([math.cos(a),math.sin(a)]);segments.append((np.zeros(2),d*.0215))
  for rr in[.007,.012,.016]:
   for sign in[-1,1]:segments.append((d*rr,d*rr+np.array([math.cos(a+sign*.85),math.sin(a+sign*.85)])*.006))
 def zface(x,y):
  q=np.array([x,y]);r=np.linalg.norm(q);h=.0028+.0010*(1-min(1,(r/.023)**2))
  for a,b in segments:
   ab=b-a;t=np.clip(np.dot(q-a,ab)/np.dot(ab,ab),0,1);dist=np.linalg.norm(q-(a+t*ab));h+=.0006*math.exp(-(dist/.0009)**2)
  return h
 for side in[-1,1]:
  v.append((sx,sy,side*.003));uv.append((.5,.5))
  for j in range(1,nr+1):
   for k in range(na):a=T*k/na;rmax=.023*(.86+.14*math.cos(6*(a-math.pi/2)));r=rmax*j/nr;x=r*math.cos(a);y=r*math.sin(a);z=zface(x,y)if side==1 else-.0025;v.append((sx+x,sy+y,z));uv.append((x/.046+.5,y/.046+.5))
 layer=1+na*nr
 for s in[0,1]:
  off=s*layer
  for k in range(na):faces.append((off,off+1+k,off+1+(k+1)%na))
  for j in range(nr-1):
   for k in range(na):a=off+1+j*na+k;b=off+1+j*na+(k+1)%na;c=a+na;d=b+na;faces.extend([(a,b,c),(b,d,c)])
 for k in range(na):a=1+(nr-1)*na+k;b=1+(nr-1)*na+(k+1)%na;faces.extend([(a,b,a+layer),(b,b+layer,a+layer)])
 p.append(A.raw('own-six-lobed-closed-cast-with-real-branch-fork-embossed-channels','gold',v,faces,uv))
 for k,(a,b)in enumerate(segments):
  pts=[]
  for tt in np.linspace(0,1,35):q=a+(b-a)*tt;pts.append((sx+q[0],sy+q[1],zface(q[0],q[1])+.00025))
  p.append(B.tube('actual-raised-glitter-snowflake-branch-or-fork-'+str(k),'goldglitter',pts,.00030,.00075,6,False,guide=[0,0,1]))
 extra['source_shape_evidence']='The own2160px close-up shows a closed six-lobed metallic cast with raised main branches, three pairs of forks per ray and recessed reflective channels. Dark areas are reflections/embossing; through-open holes are not evidenced. See source-round-02/snowflake-original-detail.jpg.'
 return p,['Source-specific six-lobed softly rounded closed gold casting with an evenly thick body, not a central umbrella/pyramid fan','Six actual embossed main branches and36 physical forks, raised glitter coverage and recessed channels between them','Own full-resolution same-SKU close-up supports relief channels; no unsupported through-holes are introduced']+features[1:],extra

_original_material=F.material
def material(pid,key,kind,rgb,rough=.45,metal=0):
 if kind!='bootglass':return _original_material(pid,key,kind,rgb,rough,metal)
 bank,m=F.BASE(pid,key,'glitter',[216,199,163],.33,1);n=2048;y=.105*(1-np.arange(n)[:,None]/n);x=.082*(np.arange(n)[None,:]/n-.5);shaft=(y>.025)&(y<.087);arr=np.array(Image.open(bank/m['baseColorTexture'])).astype(float);arr+=np.where(shaft[:,:,None],np.array([2,3,3]),np.array([0,-9,-29]))[...,:];Image.fromarray(np.clip(arr,0,255).astype('uint8'),'RGB').save(bank/m['baseColorTexture'],optimize=True);return bank,m
A.material=material
A.SPECS['1299157022']['build']=marshmallow_mug
A.SPECS['1299157027']['build']=joined_boots;A.SPECS['1299157027']['materials']['bootglass']=('bootglass',[216,199,163],.33,1)
A.SPECS['1359291003']['build']=embossed_snowflake_set
if __name__=='__main__':
 for pid in sys.argv[1:]or['1299157022','1359291003','1299157027']:A.build(pid)
