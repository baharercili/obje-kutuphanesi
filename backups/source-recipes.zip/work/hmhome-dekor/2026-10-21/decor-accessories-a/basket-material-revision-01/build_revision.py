"""Photo-only material replacement. Never writes frozen assets, UVs or other geometry."""
from pathlib import Path
import sys,json,copy,hashlib,io,math,shutil
sys.dont_write_bytecode=True
import numpy as np
from PIL import Image,ImageFilter,ImageCms
R=Path(__file__).resolve().parent;A=R.parent
sys.path.insert(0,str(A));import build_accessories as H
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,q):Path(p).write_text(json.dumps(q,ensure_ascii=False,indent=2)+'\n')
SPECS={'1314660002':{'donor':'1314660002-6d0a3bd0a1a4.jpg','crop':[56,600,2104,2648],'tile':1,'wall_scale':[1.05,18.0],'loop_scale':[18.0,.30],'planar_scale':[3.0,3.0]},'1314660001':{'donor':'1314660001-cbc5216f9eaf.jpg','crop':[56,1000,1080,2024],'tile':2,'wall_scale':[.75,14.0],'loop_scale':[14.0,.22],'planar_scale':[2.6,2.6]}}

def blur(a,r):return np.asarray(Image.fromarray(a.astype('float32'),'F').filter(ImageFilter.GaussianBlur(r)))
def gauss(a,r):
 # PIL's float GaussianBlur is unsupported on some hosts; RGB/L channel is sufficient for low-frequency illumination.
 return np.asarray(Image.fromarray(np.clip(a*65535,0,65535).astype('uint16'),'I;16').convert('F'))if False else np.asarray(Image.fromarray(np.clip(a*255,0,255).astype('uint8'),'L').filter(ImageFilter.GaussianBlur(r)),dtype=float)/255

def periodic(a,width):
 out=a.copy();n=len(out)
 for k in range(width):
  mix=(1-k/width)**2*.5;left=a[:,k].copy();right=a[:,-1-k].copy();out[:,k]=left*(1-mix)+right*mix;out[:,-1-k]=right*(1-mix)+left*mix
 a=out.copy()
 for k in range(width):
  mix=(1-k/width)**2*.5;top=a[k].copy();bottom=a[-1-k].copy();out[k]=top*(1-mix)+bottom*mix;out[-1-k]=bottom*(1-mix)+top*mix
 return out

def maps(sku,spec,out):
 master=A/'originals'/spec['donor'];im=Image.open(master);master_hash=sha(master);icc=im.info.get('icc_profile',b'');crop=im.crop(tuple(spec['crop']));raw=np.asarray(crop).copy();crop_path=out/'donor-native-crop.png';crop.save(crop_path,icc_profile=icc)
 assert np.array_equal(np.array(Image.open(crop_path)),np.array(im)[spec['crop'][1]:spec['crop'][3],spec['crop'][0]:spec['crop'][2]])
 srgb=ImageCms.createProfile('sRGB');converted=ImageCms.profileToProfile(crop,ImageCms.ImageCmsProfile(io.BytesIO(icc)),srgb,outputMode='RGB')if icc else crop.convert('RGB');rgb=np.asarray(converted,dtype=float)/255
 lin=np.where(rgb<=.04045,rgb/12.92,((rgb+.055)/1.055)**2.4);lum=np.sum(lin*np.array([.2126,.7152,.0722]),axis=2);low=gauss(lum,128 if spec['tile']==1 else 64);gain=np.clip(np.median(low)/np.maximum(low,.02),.94,1.06);corrected=np.clip(lin*gain[:,:,None],0,1);srgb_pixels=np.where(corrected<=.0031308,corrected*12.92,1.055*corrected**(1/2.4)-.055)
 tile=periodic(srgb_pixels,64);tex=np.tile(tile,(spec['tile'],spec['tile'],1));assert tex.shape==(2048,2048,3)
 # Fine local contrast only. No floor/contact shadow, coarse photographic shading or procedural wood wave is imported.
 gray=np.sum(tex*np.array([.2126,.7152,.0722]),axis=2);local=gauss(gray,9);detail=gray-local;relief=np.abs(detail)*2+.15*detail;relief=gauss(np.clip(relief*2,0,1),1.1)/2;dy,dx=np.gradient(relief);normal=np.stack([-dx*9,dy*9,np.ones_like(dx)],axis=2);normal/=np.linalg.norm(normal,axis=2,keepdims=True);rough=np.clip((.72 if sku.endswith('2')else .77)+np.abs(detail)*.36,.65,.91);orm=np.zeros((2048,2048,3),dtype=np.uint8);orm[:,:,0]=255;orm[:,:,1]=(rough*255).astype('uint8');orm[:,:,2]=0
 paths={}
 for key,pixels in [('albedo',(np.clip(tex,0,1)*255).astype('uint8')),('normal',((normal+1)*127.5).astype('uint8')),('orm',orm)]:
  path=out/(sku+'-own-fiber-'+key+'-2k.png');Image.fromarray(pixels,'RGB').save(path,optimize=True,icc_profile=ImageCms.ImageCmsProfile(srgb).tobytes()if key=='albedo'else None);paths[key]=path
 registry=json.loads((A/'original-image-masters.json').read_text());source=next(p for p in registry if Path(p['path'])==master);assert source['sha256']==master_hash==sha(master)
 report={'source_master':str(master),'source_url':source['url'],'source_jpeg_sha256':master_hash,'master_pixel_dimensions':list(im.size),'master_format':im.format,'master_mode':im.mode,'master_bit_depth':8,'master_icc_bytes':len(icc),'master_icc_sha256':hashlib.sha256(icc).hexdigest(),'master_exif_orientation':im.getexif().get(274,1),'source_crop_box_xyxy':spec['crop'],'donor_native_pixels':list(crop.size),'donor_crop':str(crop_path),'donor_crop_sha256':sha(crop_path),'raw_crop_pixel_identity':True,'geometric_resampling':False,'tiling':{'native_tile_repetitions_each_axis':spec['tile'],'no_upscale':True,'edge_blend_pixels':64,'edge_blend_method':'Only opposing64px boundary bands are cross-faded for periodic material continuity. Centre pixels retain the colour-corrected donor values.'},'edit_stack':['Exact native-pixel crop from immutable own-SKU JPEG. Crop contains material only; no floor/background/contact shadow.','Convert embedded c2 ICC to explicit sRGB without spatial resampling.','Remove only ±6% low-frequency illumination variation in linear RGB; preserve real dark binding threads and fibre colours.','Blend opposing64px tile edge strips, then repeat native tile without resampling if needed.','Derive approximate tangent normal/roughness from fine local fibre/stitch contrast; no measured height or scanned roughness claimed.'],'output_pixels':[2048,2048],'output_format':'PNG RGB8','effective_native_tile_detail_pixels':list(crop.size),'photo_material_only':True,'no_full_object_photo_card':True,'no_baked_environment_or_floor_shadow':True,'normal_roughness_note':'Photographic local-contrast estimates, not measured material scans. Coarse band relief remains approved unchanged geometry.','outputs':{k:{'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size}for k,p in paths.items()}}
 dump(out/'donor-edit-stack.json',report);return paths,report

def revision(sku):
 spec=SPECS[sku];old=next(q for q in json.loads((A/'frozen-source-recovery-02-manifest.json').read_text())if q['sku']==sku);out=R/old['id'];out.mkdir(exist_ok=True);paths,donor=maps(sku,spec,out);doc,binary=H.read_glb(Path(old['glb_path']));doc=copy.deepcopy(doc);model=json.loads(Path(old['model_path']).read_text());original_model=copy.deepcopy(model);old_doc,old_bin=H.read_glb(Path(old['glb_path']));replacement={}
 for i,mat in enumerate(doc['materials']):
  key=mat['name']
  if key in['grass','grassLight']:
   for slot,mapkey in [('baseColorTexture','albedo'),('normalTexture','normal'),('metallicRoughnessTexture','orm')]:
    info=mat.get(slot)or mat['pbrMetallicRoughness'][slot];imageindex=doc['textures'][info['index']]['source'];replacement[doc['images'][imageindex]['bufferView']]=paths[mapkey].read_bytes();doc['images'][imageindex]['name']=paths[mapkey].name
   mat['normalTexture']['scale']=.48;mat['extras']={'official_material_donor':True,'photo_material_only':True,'donor_edit_stack':str(out/'donor-edit-stack.json')}
   mm=model['materials'][key];mm.update(baseColorTexture=paths['albedo'].name,normalTexture=paths['normal'].name,metallicRoughnessTexture=paths['orm'].name,normalScale=.48);mm['extras'].update(official_material_donor=True,photo_material_only=True,photo_pixels_baked=True,baked_reflections=False,donor_edit_stack=str(out/'donor-edit-stack.json'),effective_native_tile_detail_pixels=donor['donor_native_pixels'])
  else:
   for slot in['baseColorTexture','normalTexture','metallicRoughnessTexture']:
    source=Path(old['asset_dir'])/model['materials'][key][slot];shutil.copyfile(source,out/source.name)
 # Material-only texture transforms orient photographic fibres consistently with existing UV conventions.
 originals=len(doc['materials']);variants={};model_variants={}
 for mesh,modelmesh in zip(doc['meshes'],model['meshes']):
  name=mesh['name'];role='wall'if'real-hollow-rounded' in name else'planar'if any(w in name for w in['floor','lid-with-soft'])else'loop'
  for prim in mesh['primitives']:
   idx=prim['material'];base=doc['materials'][idx]['name']
   if base not in['grass','grassLight']:continue
   key=(idx,role)
   if key not in variants:
    transform={'rotation':math.pi/2,'scale':spec['wall_scale'],'offset':[1,0]}if role=='wall'else{'scale':spec['planar_scale']if role=='planar'else spec['loop_scale'],'offset':[0,0]}
    mm=copy.deepcopy(doc['materials'][idx]);mm['name']=base+'_'+role
    for slot in['baseColorTexture','normalTexture','metallicRoughnessTexture']:
     info=mm.get(slot)or mm['pbrMetallicRoughness'][slot];info['extensions']={'KHR_texture_transform':transform}
    variants[key]=len(doc['materials']);doc['materials'].append(mm);j=copy.deepcopy(model['materials'][base]);j['texture_transform']=transform;model['materials'][mm['name']]=j
   prim['material']=variants[key];modelmesh['material']=doc['materials'][variants[key]]['name']
 doc['extensionsUsed']=sorted(set(doc.get('extensionsUsed',[])+['KHR_texture_transform']))
 # Repack individual views; nonimage geometry bytes and every accessor remain exact. Image views deduplicate identical maps.
 new=bytearray();seen={};geometry=[]
 imageset={q['bufferView']for q in doc['images']}
 for i,v in enumerate(doc['bufferViews']):
  oldview=old_doc['bufferViews'][i];payload=replacement.get(i,old_bin[oldview.get('byteOffset',0):oldview.get('byteOffset',0)+oldview['byteLength']]);digest=hashlib.sha256(payload).hexdigest();key=(digest,len(payload))
  if i not in imageset:geometry.append({'buffer_view':i,'bytes':len(payload),'old_sha256':hashlib.sha256(old_bin[oldview.get('byteOffset',0):oldview.get('byteOffset',0)+oldview['byteLength']]).hexdigest(),'new_sha256':digest,'identical':payload==old_bin[oldview.get('byteOffset',0):oldview.get('byteOffset',0)+oldview['byteLength']]})
  if i in imageset and key in seen:offset=seen[key]
  else:
   while len(new)%4:new.append(0)
   offset=len(new);new.extend(payload)
   if i in imageset:seen[key]=offset
  v['byteOffset']=offset;v['byteLength']=len(payload)
 doc['buffers'][0]['byteLength']=len(new)
 note={'revision':'own-photo-fiber-material-v1','previous_glb_sha256':old['sha256'],'geometry_unchanged':True,'official_donor_edit_stack':str(out/'donor-edit-stack.json'),'donor_native_pixels':donor['donor_native_pixels'],'material_photo_pixels':True,'source_jpeg_unchanged':True,'scope':'Only grass/grassLight albedo, local-contrast normal/roughness and material texture coordinate transforms. No vertex, index, normal, tangent, UV, dimensions or node transform change.'}
 model['metadata'].update(material_revision=note,photo_pixels_baked=True,baked_reflections=False);doc['extras']['metadata']=copy.deepcopy(model['metadata']);dump(out/'model.json',model);target=out/(old['id']+'.glb');H.write_glb(target,doc,bytes(new))
 assert doc['accessors']==old_doc['accessors']and doc['nodes']==old_doc['nodes'];assert all(p['identical']for p in geometry)
 strip=lambda m:[{k:v for k,v in q.items()if k!='material'}for q in m]
 assert strip(model['meshes'])==strip(original_model['meshes'])
 data_old=b''.join(old_bin[v.get('byteOffset',0):v.get('byteOffset',0)+v['byteLength']]for i,v in enumerate(old_doc['bufferViews'])if i not in imageset);data_new=b''.join(bytes(new)[v.get('byteOffset',0):v.get('byteOffset',0)+v['byteLength']]for i,v in enumerate(doc['bufferViews'])if i not in imageset);assert data_old==data_new
 proof={'valid':True,'sku':sku,'stable_id':old['id'],'previous_glb_path':old['glb_path'],'previous_glb_sha256':old['sha256'],'new_glb_path':str(target),'new_glb_sha256':sha(target),'nonimage_geometry_buffer_bytes':len(data_old),'old_geometry_buffers_sha256':hashlib.sha256(data_old).hexdigest(),'new_geometry_buffers_sha256':hashlib.sha256(data_new).hexdigest(),'all_accessors_unchanged':True,'all_nodes_transforms_unchanged':True,'model_mesh_data_unchanged_except_material_binding':True,'vertex_index_normal_uv_tangent_buffers_identical':True,'nonimage_views':geometry,'original_jpeg_sha256':donor['source_jpeg_sha256'],'original_jpeg_unchanged':sha(donor['source_master'])==donor['source_jpeg_sha256']};dump(out/'geometry-byte-identity.json',proof)
 entry=copy.deepcopy(old);entry.update(asset_dir=str(out),glb_path=str(target),model_path=str(out/'model.json'),sha256=sha(target),bytes=target.stat().st_size,frozen=False,quality_pending=True,model_status='material_review_pending',model_revision='hmhome-own-photo-fiber-material-v1',material_revision=note,geometry_identity_file=str(out/'geometry-byte-identity.json'),donor_edit_stack=str(out/'donor-edit-stack.json'));entry.pop('native_renders',None);entry.pop('scn_path',None);entry.pop('source_comparison_path',None);entry['material_validation']=str(out/'donor-edit-stack.json');dump(out/'entry.json',entry);assert entry['bytes']<40*1024*1024,(sku,entry['bytes']);print('MATERIAL ONLY',sku,entry['bytes'],len(geometry),'identical geometry views',flush=True);return entry
if __name__=='__main__':dump(R/'candidate-manifest.json',[revision(sku)for sku in SPECS])
