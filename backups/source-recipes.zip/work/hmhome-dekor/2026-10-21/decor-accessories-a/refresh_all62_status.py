"""Refresh mutable complete source coverage; never edit any frozen asset or manifest."""
from pathlib import Path
from collections import Counter
import json
R=Path(__file__).resolve().parent
def dump(p,q):p.write_text(json.dumps(q,ensure_ascii=False,indent=2)+'\n')
inventory=json.loads((R/'all62-status.json').read_text());records={q['sku']:q for q in json.loads((R/'source-inventory.json').read_text())};masters=json.loads((R/'original-image-masters.json').read_text());models={q['sku']:q for q in json.loads((R/'manifest.json').read_text())};frozen={q['sku']for q in json.loads((R/'frozen-all36-manifest.json').read_text())};eligible=[]
if(R/'frozen-source-recovery-01-manifest.json').exists():frozen.update(q['sku']for q in json.loads((R/'frozen-source-recovery-01-manifest.json').read_text()))
if(R/'frozen-all58-manifest.json').exists():frozen.update(q['sku']for q in json.loads((R/'frozen-all58-manifest.json').read_text()))
for p in inventory['products']:
 if p['sku']in frozen:continue
 sku=p['sku'];q=records.get(sku);refs=[q for q in masters if q['sku']==sku]
 if not q or not q.get('identity_verified'):continue
 anchor=bool(q.get('official_measurements')or q.get('official_measurement_ranges'))
 p.update(identity_verified=True,official_source_url=q.get('dimension_source_url',q.get('official_source_url',q['url'])),source_market=q.get('source_market'),source_evidence_file=q['source_observation_file'],official_measurements=q.get('official_measurements',{}),official_measurement_ranges=q.get('official_measurement_ranges',[]),original_images=[{'url':q['url'],'path':q['path'],'sha256':q['sha256']}for q in refs])
 if anchor and refs:
  status='model_qa_in_progress'if sku in models else'ready_to_model';reason='Live exact-SKU official physical anchor and own immutable gallery recovered; model remains outside frozen delivery until real geometry and image review pass.';eligible.append(sku)
 elif not anchor:status='pending_measurements';reason='Exact-SKU official gallery and description recovered, but no numeric physical anchor is present. No model or official scale is invented.'
 else:status='pending_gallery';reason='Official physical anchor present; a usable own original gallery is still required.'
 p.update(status=status,reason=reason,model_id=models[sku]['id']if sku in models else None)
inventory['counts']=dict(Counter(q['status']for q in inventory['products']));inventory['round02_physical_candidates']=eligible;dump(R/'all62-status.json',inventory);dump(R/'source-round-02/physical-model-candidates.json',[p for p in inventory['products']if p['sku']in eligible]);dump(R/'source-round-02/pending-measurements.json',[p for p in inventory['products']if p['status']=='pending_measurements']);print(inventory['counts'],'round02 physical candidates',len(eligible))
