"""Review outputs only; immutable source photographs are never edited."""
from pathlib import Path
import sys,json,hashlib
sys.dont_write_bytecode=True
from PIL import Image,ImageOps,ImageDraw
import build_accessories as A
R=Path(__file__).resolve().parent
FROZEN={'1319209002','1347756001','1247880003','1247880004'}
if(R/'frozen-family-02-manifest.json').exists():FROZEN.update(e['sku']for e in json.loads((R/'frozen-family-02-manifest.json').read_text()))
if(R/'frozen-quality-completion-01-manifest.json').exists():FROZEN.update(e['sku']for e in json.loads((R/'frozen-quality-completion-01-manifest.json').read_text()))
if(R/'frozen-source-recovery-01-manifest.json').exists():FROZEN.update(e['sku']for e in json.loads((R/'frozen-source-recovery-01-manifest.json').read_text()))
if(R/'frozen-all58-manifest.json').exists():FROZEN.update(e['sku']for e in json.loads((R/'frozen-all58-manifest.json').read_text()))
PREFERRED={
 '1293371001':1,'1293371002':1,'1293371004':1,'1293370001':1,'1293370002':0,'1293370004':1,
 '1105071012':1,'1114258020':0,'1355065005':1,'1355087004':1,'1354987001':1,'1355097003':0,
 '1354990004':1,'1213918001':1,'1244824001':1,'1244814001':1,'1244814002':1,'1355009001':0,
 '1354954001':1,'1354996001':1,'1354993001':1,'1354993003':0,'1355050001':0,'1299157029':0,
 '1299157028':0,'1293864001':0,'1293864008':0,'1293864009':0,'1354975002':0,'1214591006':1,
 '1359291005':1,'1359291006':0}
def primary():
 entries=json.loads((R/'manifest.json').read_text());masters=json.loads((R/'original-image-masters.json').read_text());changes=[]
 for e in entries:
  if e['sku'] in FROZEN:continue
  refs=[p for p in masters if p['sku']==e['sku']];p=refs[min(PREFERRED.get(e['sku'],0),len(refs)-1)]
  if e['original_image']==p['path']:continue
  model=json.loads(Path(e['model_path']).read_text());doc,binary=A.read_glb(Path(e['glb_path']))
  assert model['metadata']==doc['extras']['metadata']
  fields={'original_image':p['path'],'original_image_url':p['url'],'original_image_sha256':p['sha256']}
  e.update(fields);model['metadata'].update(fields);doc['extras']['metadata'].update(fields)
  A.dump(Path(e['model_path']),model);A.write_glb(Path(e['glb_path']),doc,binary);e['sha256']=A.sha(e['glb_path']);e['bytes']=Path(e['glb_path']).stat().st_size
  A.dump(Path(e['asset_dir'])/'entry.json',e)
  validation=Path(e['asset_dir'])/(e['id']+'.validation.json')
  if validation.exists():
   q=json.loads(validation.read_text());q['deliverable_sha256']['glb']=e['sha256'];q['glb_bytes']=e['bytes'];A.dump(validation,q)
  changes.append({'sku':e['sku'],'primary_original':p['path'],'source_master_sha256':p['sha256'],'glb_sha256':e['sha256']})
 A.dump(R/'manifest.json',entries);A.dump(R/'review-primary-selection.json',changes)
 print('Updated source primary without changing mesh/material bytes:',len(changes))
def picture(path,size):
 im=Image.open(path)
 if im.mode=='RGBA':
  background=Image.new('RGBA',im.size,(246,246,243,255));im=Image.alpha_composite(background,im)
 return ImageOps.contain(im.convert('RGB'),size,Image.Resampling.LANCZOS)
def contacts():
 entries=[e for e in json.loads((R/'manifest.json').read_text())if e['sku'] not in FROZEN];rows=[]
 for e in entries:
  out=Path(e['asset_dir']);views=[Path(e['original_image'])]+[out/(s+'.png')for s in['on','yan','on-capraz','ustten']]
  if not all(p.exists()for p in views):print('WAITING',e['sku']);continue
  canvas=Image.new('RGB',(1800,440),'white');d=ImageDraw.Draw(canvas);d.text((12,6),e['sku']+' | '+e['name']+' | '+str(e['dimensions_cm'])+' cm',fill='black')
  for k,(p,label) in enumerate(zip(views,['Original master · own SKU','Native front','Native side','Native 45°','Native above'])):
   im=picture(p,(350,390));canvas.paste(im,(k*360+(360-im.width)//2,44+(390-im.height)//2));d.text((k*360+12,27),label,fill='black')
  path=R/(e['id']+'-comparison.jpg');canvas.save(path,quality=94,subsampling=0);rows.append((e,canvas))
 for start in range(0,len(rows),6):
  batch=rows[start:start+6];sheet=Image.new('RGB',(1800,440*len(batch)),'white')
  for k,(_,im) in enumerate(batch):sheet.paste(im,(0,k*440))
  prefix='review-pending-contact-'if(R/'frozen-family-02-manifest.json').exists()else'review-contact-'
  sheet.save(R/(prefix+str(start//6+1).zfill(2)+'.jpg'),quality=93,subsampling=0)
 print('Comparisons:',len(rows))
if __name__=='__main__':
 if 'primary' in sys.argv:primary()
 if 'contacts' in sys.argv:contacts()
