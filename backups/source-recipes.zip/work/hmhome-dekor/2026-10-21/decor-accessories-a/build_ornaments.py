"""Bounded exact-SKU ornaments, physical loops/ribbons/cavities, intrinsic PBR."""
from pathlib import Path
import sys,math,json
sys.dont_write_bytecode=True
import numpy as np
import build_accessories as A
B=A.B;T=math.tau
def sphere(name,mat,r,center=(0,0,0),scale=(1,1,1),n=80):
 profile=[(r*math.sin(a),r-r*math.cos(a))for a in np.linspace(0,math.pi,41)];profile[0]=(0,0);profile[-1]=(0,2*r);p=B.lathe(name,mat,profile,n,False);p['_vertices']=[tuple(np.array([x,y-r,z])*scale+center)for x,y,z in p['_vertices']];return p
def shell(name,mat,r,center=(0,0,0)):
 angles=np.linspace(math.pi,.075,81);profile=[(r*math.sin(a),r+r*math.cos(a))for a in angles];profile[0]=(0,0);ri=r-.0008;profile+=[(ri*math.sin(a),r+ri*math.cos(a))for a in np.linspace(.075,math.pi,81)];profile[-1]=(0,.0008);return B.lathe(name,mat,profile,144,False,offset=center)
def eye(name,mat,c,r=.002,wire=.00025):return B.tube(name,mat,[(c[0]+r*math.cos(a),c[1]+r*math.sin(a),c[2])for a in np.linspace(0,T,65)[:-1]],wire,wire,8,True,guide=[0,0,1])
def ribbon_loop(name,mat,c,height=.045,width=.003):return B.tube(name,mat,[(c[0]+.0035*math.sin(a),c[1]+height/2*(1+math.cos(a)),c[2]+.00035*math.sin(2*a))for a in np.linspace(0,T,97)[:-1]],.00012,width/2,8,True,guide=[0,0,1])
def star_mesh(name,mat,points=8,width=.22,height=.26,cy=.21,thickness=.024,phase=math.pi/2):
 v=[(0,cy,thickness/2),(0,cy,-thickness/2)];uv=[(.5,.5),(.5,.5)];f=[]
 for k in range(points*2):
  a=phase+T*k/(points*2);fac=1 if k%2==0 else .26
  if points==8 and k%4==2:fac*=.72
  v.append((width/2*fac*math.cos(a),cy+height/2*fac*math.sin(a),0));uv.append((v[-1][0]/width+.5,(v[-1][1]-cy)/height+.5))
 for k in range(points*2):a=2+k;b=2+(k+1)%(points*2);f.extend([(0,a,b),(1,b,a)])
 p=A.raw(name,mat,v,f,uv);p['_flat_normals']=True;return p
def paper_star():
 parts=[star_mesh('eight-point-raised-folded-paper-star','paper')];pts=[]
 for t in np.linspace(0,1,401):a=T*8*t;rr=.0125*(1-.46*t);pts.append((rr*math.cos(a),.0007+.105*t,rr*math.sin(a)))
 parts.append(B.tube('true-tapered-eight-turn-gold-wire-mount','gold',pts,.00065,.00065,8,False,guide='radial'));return parts,['Eight unequal long/short raised paper rays with actual facets and double surface','Real tapered open metal-wire coil; bottom mount diameter 2.5 cm, overall official H34 W22 cm'],{'source_axis_ambiguity':'Star depth is photo-scaled. Official lower diameter applies to the mount, not the star.'}
def single_satin():
 parts=[sphere('eight-cm-satin-thread-sphere','stripe',.04,(0,.04,0),n=144),B.lathe('small-gold-crimp-cap','gold',[(0,.078),(.006,.078),(.0065,.080),(.006,.084),(0,.084)],80,False),eye('gold-hanger-eye','gold',(0,.087,0),.003),ribbon_loop('wide-green-satin-ribbon-loop','ribbon',(0,.090,0),.055,.004)]
 return parts,['Own 8 cm sphere, eight alternating ivory/dark-green satin-thread bands','Gold cap, distinct metal eye and real finite-width green hanging ribbon'],{'piece_dimensions_cm':{'diameter':8},'bounds_semantics':'Official diameter is spherical body only. Overall height including ribbon is photo interpretation.'}
def striped_glass():
 parts=[shell('true-hollow-champagne-glass-sphere','glass',.04),eye('small-glass-hanging-eye','glass',(0,.084,0),.003,.00065),ribbon_loop('flat-beige-velvet-hanger','velvet',(0,.089,0),.060,.0045)]
 for band in range(8):
  pts=[]
  for t in np.linspace(0,1,193):phi=.12+(.87*math.pi)*t;a=T*band/8+T*.65*t;r=.0401;pts.append((r*math.sin(phi)*math.cos(a),r-r*math.cos(phi),r*math.sin(phi)*math.sin(a)))
  parts.append(B.tube('physical-wavy-gold-glitter-band-'+str(band),'glitter',pts,.00016,.0030,8,False,guide='radial'))
 return parts,['Hollow translucent champagne glass with real mouth/rim thickness','Eight raised spiral glitter ribbons follow the sphere, plus separate clear eye and beige velvet loop'],{'piece_dimensions_cm':{'diameter':8},'bounds_semantics':'Official body diameter8 cm; total hanging loop height photo-scaled.'}
def candy_canes():
 parts=[]
 for k,x in enumerate([-.025,.025]):
  start=len(parts)
  pts=[(x+.010,.003+t*.078,0)for t in np.linspace(0,1,50)]
  pts +=[(x+.010*math.cos(a),.081+.010*math.sin(a),0)for a in np.linspace(0,math.pi,65)[1:]]
  g=B.tube('bent-red-glass-candy-cane-'+str(k),'red',pts,.0038,.0038,16,False,guide=[0,0,1]);parts.append(g)
  # Spiral glitter enamel around the real curved cane rather than a printed front stripe.
  p=np.array(pts);length=np.r_[0,np.cumsum(np.linalg.norm(np.diff(p,axis=0),axis=1))];stripes=[]
  for i,c in enumerate(p):
   tangent=p[min(i+1,len(p)-1)]-p[max(i-1,0)];tangent/=np.linalg.norm(tangent);normal=np.array([0.,0.,1.]);bi=np.cross(tangent,normal);ang=T*length[i]/.014;stripes.append(c+.00385*(normal*math.cos(ang)+bi*math.sin(ang)))
  parts.append(B.tube('white-spiral-glitter-stripe-'+str(k),'whiteglitter',stripes,.0003,.0012,8,False,guide=[0,0,1]))
  vv=np.concatenate([g['_vertices']for g in parts[start:]]);low=vv[:,1].min();high=vv[:,1].max()
  for g in parts[start:]:g['_vertices']=[(xx,(yy-low)*.110/(high-low),zz)for xx,yy,zz in g['_vertices']]
  parts.append(eye('silver-hanger-eye-'+str(k),'silver',(x+.001,.114,0),.002,.0003));parts.append(ribbon_loop('thin-silver-cord-loop-'+str(k),'silver',(x+.001,.117,0),.040,.0007))
 return parts,['Two physically bent red glass candy canes with rounded section and real curved return','Raised white glitter spiral follows straight body and curved hook; separate silver cap/eye/cord'],{'set_quantity':2,'piece_dimensions_cm':{'height':11},'source_axis_ambiguity':'Official height11 cm is retained as the cane body anchor; hanging loop and width/depth are photo interpretations.','bounds_semantics':'Two-piece display layout, not an official set footprint.'}
def tassels():
 pieces=[]
 for q,x in enumerate([-.025,.025]):
  for layer,count,scale in[(0,90,1),(1,65,.72),(2,35,.4)]:
   for k in range(count):
    a=T*k/count+layer*.7;points=[]
    for t in np.linspace(0,1,35):
     r=(.004*(1-t)+.0121*t**.55)*scale;aa=a+.025*math.sin(T*t*2+k*.8);points.append((x+r*math.cos(aa),.063-.062*t+.0008*math.sin(k*1.3)*t,r*math.sin(aa)))
    pieces.append(B.tube('individual-cotton-fringe-'+str(q)+'-'+str(layer)+'-'+str(k),'yarn',points,.00030,.00030,5,False,guide='radial'))
  pieces.append(sphere('round-wrapped-yarn-head-'+str(q),'yarn',.006,(x,.0864,0),scale=(1,1.15,1),n=64))
  for j in range(18):
   a=T*j/18;pts=[(x+.0062*math.sin(t)*math.cos(a+.12*math.sin(t)),.0864+.0070*math.cos(t),.0062*math.sin(t)*math.sin(a+.12*math.sin(t)))for t in np.linspace(.06,math.pi-.06,80)];pieces.append(B.tube('real-wrapped-yarn-knotted-head-'+str(q)+'-'+str(j),'yarn',pts,.00040,.00040,6,False,guide='radial'))
  for segment,cy in enumerate([.0760,.0680]):
   pieces.append(B.lathe('distinct-rounded-wrapped-neck-barrel-'+str(q)+'-'+str(segment),'yarn',[(0,cy-.0031),(.0036,cy-.0031),(.0046,cy-.0026),(.0052,cy-.0016),(.0052,cy+.0016),(.0046,cy+.0026),(.0036,cy+.0031),(0,cy+.0031)],64,False,offset=(x,0,0)))
   for j in range(15):
    a=T*j/15;pts=[(x+(.0036+.0018*math.sin(t))*math.cos(a+.2*math.sin(t)),cy+.0032*math.cos(t),(.0036+.0018*math.sin(t))*math.sin(a+.2*math.sin(t)))for t in np.linspace(.03,math.pi-.03,55)];pieces.append(B.tube('separate-yarn-wrap-on-neck-barrel-'+str(q)+'-'+str(segment)+'-'+str(j),'yarn',pts,.00035,.00035,6,False,guide='radial'))
  for k,y in enumerate([.0642,.0720,.0796]):pieces.append(B.tube('thin-separating-neck-tie-'+str(q)+'-'+str(k),'yarn',[(x+.0035*math.cos(a),y,.0035*math.sin(a))for a in np.linspace(0,T,65)[:-1]],.00060,.00060,8,True,guide=[0,1,0]))
  for strand in range(3):
   pts=[]
   for a in np.linspace(0,T,161)[:-1]:
    base=np.array([x+.002*math.sin(a),.116+.023*math.cos(a),0]);t=T*strand/3+a*18;pts.append(tuple(base+np.array([.00055*math.cos(t),0,.00055*math.sin(t)])))
   pieces.append(B.tube('three-ply-braided-cord-loop-'+str(q)+'-'+str(strand),'yarn',pts,.0004,.0004,6,True,guide=[0,0,1]))
 return pieces,['Two dark-green cotton tassels, 190 separate closed fringe strands on each piece','Own round head plus two distinct rounded wrapped barrel neck segments, three thin separating ties and three-ply braided real hanging loops','Flat-cut yet individually irregular fringe ends; no opaque cone substituted for yarn'],{'set_quantity':2,'piece_dimensions_cm':{'width':2.5,'height':14},'bounds_semantics':'Official W2.5 H14 cm is per tassel; total display width and round section depth are interpreted.'}
def gold_ornament_pair():
 parts=[]
 for k,(x,height,radius)in enumerate([(-.035,.135,.029),(.035,.080,.035)]):
  profile=[]
  for t in np.linspace(0,1,81):
   r=radius*(math.sin(math.pi*t)**(.85 if k==0 else .52))*(.65+.35*t if k==0 else 1)
   if k==1 and t<.25:r=radius*(math.sin(math.pi*.25)**.52)*(t/.25)
   profile.append((r,height*t))
  profile[0]=(0,0);profile[-1]=(0,height);parts.append(B.lathe('elongated-teardrop'if k==0 else'flattened-round-gold-glass','goldglass',profile,160,False,offset=(x,0,0),ellipse=.60 if k else .85))
  for j in range(12):
   a=T*j/12;pts=[(x+r*math.cos(a),y,r*(.60 if k else .85)*math.sin(a))for r,y in profile[1:-1]];parts.append(B.tube('raised-glitter-meridian-'+str(k)+'-'+str(j),'glitter',pts,.0002,.00045,6,False,guide='radial'))
  parts.append(B.cylinder('gold-cap-'+str(k),'goldglass',.004,height-.001,height+.004,offset=(x,0,0),n=48));parts.append(ribbon_loop('golden-velvet-loop-'+str(k),'velvet',(x,height+.005,0),.052,.004))
 return parts,['One long teardrop and one flattened round glass ornament, matching the actual two-piece gallery','Separate raised glitter meridians, small caps and gold/beige velvet hanging loops'],{'set_quantity':2,'piece_dimensions_cm':{'small_height':8,'medium_height':13.5},'source_axis_ambiguity':'Labelled small/medium heights8 and13.5 cm are body-height anchors; loop inclusion is not explicit. Width/depth and arrangement are photo-scaled.'}
def bunnies():
 import implicit_shapes as I
 def field(p):
  body=I.ell_sdf(p,(0,.012,0),(.0108,.012,.0069));neck=I.ell_sdf(p,(-.0025,.022,0),(.0063,.008,.0064));head=I.ell_sdf(p,(-.003,.027,0),(.0080,.0071,.0067));f=I.smin(I.smin(body,neck,.004),head,.004)
  for z in[-.0035,.0035]:f=I.smin(f,I.cap_sdf(p,(.001,.032,z),(.013,.035,z*.90),.0030,.0018),.003)
  return I.smin(f,I.ell_sdf(p,(.0095,.0115,0),(.004,.0042,.0048)),.0025)
 base=[];I.marching_tetra(base,'one-continuous-smooth-stoneware-bunny-cast','ceramic',field,[[-.016,-.003,-.011],[.019,.041,.011]],.00040);v=np.array(base[0]['_vertices']);lo=v[:,1].min();hi=v[:,1].max();base[0]['_vertices']=[(x,(y-lo)*.035/(hi-lo),z)for x,y,z in v];parts=[]
 for k,x in enumerate([-.026,.026]):
  p=dict(base[0]);p['_vertices']=[(xx+x,yy,zz)for xx,yy,zz in base[0]['_vertices']];p['name']+='-'+str(k);parts.append(p);parts.append(eye('small-real-silver-wire-hanging-eye-'+str(k),'silver',(x-.001,.0355,0),.0014,.00025));pts=[(x-.001+.0010*math.sin(a),.037+.032*(1+math.cos(a)),0)for a in np.linspace(0,T,129)[:-1]];parts.append(B.tube('thin-white-cotton-hanging-cord-'+str(k),'ribbon',pts,.00022,.00022,6,True,guide=[0,0,1]))
 return parts,['Two continuous smoothly blended stoneware bunny castings, body/neck/head joined without snowman-like primitive seams','Own swept paired ears and subtle haunch/tail profile, real small silver wire eye and thin white cotton cord; no invented painted eyes'],{'set_quantity':2,'piece_dimensions_cm':{'height':3.5},'source_axis_ambiguity':'Official 3.5 cm is the ceramic bunny-body height; white suspension cords and display layout are interpreted.'}
def snow_globe():
 parts=[shell('true-hollow-eight-cm-transparent-sphere','glass',.04),eye('clear-glass-top-hanging-eye','glass',(0,.084,0),.003,.0007),ribbon_loop('silver-thread-hanger','silver',(0,.088,0),.058,.0006)]
 prof=[(0,.0015),(.014,.002),(.020,.004),(.027,.010),(.029,.013),(.025,.014),(0,.014)];parts.append(B.lathe('irregular-white-faux-snow-bed','snow',prof,128,False))
 for k,(x,y,z,w,h,d)in enumerate([(-.006,.023,0,.025,.021,.022),(.006,.038,-.001,.019,.018,.016),(.002,.052,.001,.014,.014,.013)]):
  parts.append(B.box('metallic-burgundy-gift-box-'+str(k),'redgift',w,h,d,(x,y,z)));parts.append(B.box('raised-glitter-gift-ribbon-x-'+str(k),'ribbonred',w+.0004,h+.0004,.002,(x,y,z)));parts.append(B.box('raised-glitter-gift-ribbon-z-'+str(k),'ribbonred',.002,h+.0004,d+.0004,(x,y,z)))
  for a in[-1,1]:parts.append(eye('little-ribbon-bow-'+str(k)+'-'+str(a),'ribbonred',(x+a*.002,y+h/2+.001,z),.002,.00045))
 rng=np.random.default_rng(1355087004)
 for k in range(110):
  a=rng.uniform(0,T);r=.027*math.sqrt(rng.uniform());y=.014+rng.uniform(0,.002);parts.append(sphere('separate-faux-snow-granule-'+str(k),'snow',rng.uniform(.0004,.0009),(r*math.cos(a),y,r*math.sin(a)),n=12))
 return parts,['Hollow transparent 8 cm glass sphere with actual clear hanging eye','Three separately stacked burgundy gift boxes with raised red glitter ribbons and bows','White snow bed plus110 real closed snow granules; no front photograph plane'],{'piece_dimensions_cm':{'diameter':8},'bounds_semantics':'Official sphere diameter8 cm retained; eye/cord height and internal gift/snow proportions photo-interpreted.'}
_mat=A.material
def material(pid,key,kind,rgb,rough=.45,metal=0):
 bank,m=_mat(pid,key,'metal'if kind=='glass'else kind,rgb,rough,metal)
 if kind=='glass':m.update(baseColorFactor=[1,1,.97,.48 if pid=='1355065005'else .22],alphaMode='BLEND',transmission=.55 if pid=='1355065005'else .90,ior=1.48,thickness=.0008,attenuationColor=[.99,.98,.96],attenuationDistance=.20)
 return bank,m
A.material=material
specs=[
 ('1105071012','Sekiz köşeli kağıt yılbaşı ağacı yıldızı',[22,34,2.4],[34,22,None],paper_star,['depth_cm'],'Kağıt · Metal tel · Altın rengi',{'paper':('paper',[209,180,115],.57,0),'gold':('metal',[193,151,66],.27,1)}),
 ('1114258020','Saten ip kaplı çizgili yılbaşı süsü',[8,14.5,8],[None,None,None],single_satin,['overall_height_including_ribbon_cm'],'Saten ip · Beyaz/Koyu yeşil',{'stripe':('stripe_green',[0,0,0],.24,0),'gold':('metal',[194,158,78],.22,1),'ribbon':('paper',[8,44,29],.38,0)}),
 ('1355065005','Dalgalı sim çizgili cam süs',[8,14.9,8],[None,None,None],striped_glass,['overall_height_including_ribbon_cm'],'Cam · Altın rengi · Bej kadife askı',{'glass':('glass',[244,233,207],.09,0),'velvet':('paper',[180,149,102],.62,0),'glitter':('metal',[206,176,111],.36,1)}),
 ('1354987001','2’li baston biçimli cam yılbaşı süsü',[7.8,16.1,1.0],[11,None,None],candy_canes,['overall_display_width_cm','depth_cm','hanging_loop_height_cm'],'Cam · Kırmızı/Beyaz baston',{'red':('metal',[185,12,27],.16,1),'whiteglitter':('paper',[238,235,220],.59,0),'silver':('metal',[190,191,186],.26,1)}),
 ('1355097003','2’li koyu yeşil yılbaşı püskülü',[7.5,14,2.5],[14,2.5,None],tassels,['overall_display_width_cm','depth_cm'],'Pamuklu ip · Koyu yeşil',{'yarn':('paper',[15,68,47],.72,0)}),
 ('1354990004','2’li simli altın cam süs',[14,19.2,5.0],[None,None,None],gold_ornament_pair,['per_piece_width_cm','per_piece_depth_cm','overall_display_bounds_cm','labelled_height_loop_inclusion'],'Cam · Altın rengi · Kadife askı',{'goldglass':('metal',[210,178,98],.07,1),'glitter':('metal',[200,157,68],.41,1),'velvet':('paper',[185,146,91],.60,0)}),
 ('1213918001','2’li stoneware paskalya tavşanı',[7.4,6.5,2.2],[3.5,None,None],bunnies,['per_piece_width_cm','depth_cm','overall_hanging_height_cm','display_layout_width_cm'],'Stoneware · Beyaz sırlı seramik',{'ceramic':('metal',[242,240,227],.27,0),'ribbon':('paper',[232,230,214],.67,0),'silver':('metal',[190,191,188],.27,1)}),
 ('1355087004','Hediye detaylı karlı cam küre',[8,14.9,8],[None,None,None],snow_globe,['overall_height_including_cord_cm','internal_gift_proportions'],'Cam · Beyaz dekoratif kar · Bordo hediyeler',{'glass':('glass',[249,250,247],.045,0),'snow':('paper',[242,241,235],.84,0),'silver':('metal',[194,195,190],.25,1),'redgift':('glitter',[148,9,39],.22,0),'ribbonred':('glitter',[164,14,40],.38,0)})]
for sku,name,dims,hwd,builder,est,label,mats in specs:
 A.SPECS[sku]={'name':name,'dims':dims,'hwd':hwd,'build':builder,'estimated':est,'label':label,'color':label.split(' · ')[-1],'semantics':'Resmî aynı-SKU ölçü ankrajları official_measurements içinde aynen korunur. '+', '.join(est)+' alanları kendi ürün fotoğrafından yorumlanmıştır; resmî ölçü değildir.','materials':mats}
for sku in['1354987001','1354990004','1213918001']:A.SPECS[sku]['derive_dimensions']=True
if __name__=='__main__':
 for sku in sys.argv[1:]or[x[0]for x in specs]:A.build(sku)
