"""Two woven seagrass baskets and two own-pattern120cm tree skirts. No master is edited."""
from pathlib import Path
import sys,json,math,hashlib
sys.dont_write_bytecode=True
import numpy as np
from PIL import Image,ImageFilter
import build_accessories as A
import build_ornaments as O
B=A.B;T=math.tau;BASE=O._mat

def basket(cream=False):
 p=[];w=.320;d=.260;rad=.060 if cream else .052;n=192
 shape=lambda W,D:A.outline(W,D,rad,n)
 p.append(A.ring('real-hollow-rounded-rectangular-seagrass-basket-walls','grass',[(shape(w-.004,d-.004),.003),(shape(w,d),.012),(shape(w,d),.201),(shape(w-.004,d-.004),.204),(shape(w-.012,d-.012),.204),(shape(w-.014,d-.014),.198),(shape(w-.014,d-.014),.009),(shape(w-.008,d-.008),.003)]))
 p.append(A.capped('solid-woven-basket-floor','grass',[(shape(w-.010,d-.010),.002),(shape(w-.010,d-.010),.008)],True))
 p.append(A.capped('separate-lift-off-lid-with-soft-rounded-cover-edge','grass',[(shape(w-.008,d-.008),.2045),(shape(w-.001,d-.001),.207),(shape(w,d),.216),(shape(w-.004,d-.004),.220)],True))
 # Several real fine twisted filaments per horizontal coiled course. Texture adds only finer fibers.
 courses=48 if cream else 9
 for row in range(courses):
  y=.012+row*.182/(courses-1)
  if not cream:
   pts=[(x,y,z)for x,z in shape(w+.0004,d+.0004)];p.append(B.tube('nine-large-horizontal-braided-grass-band-core-'+str(row),'grass',pts,.0085,.0030,12,True,guide=[0,1,0]))
  strands=3 if cream else 9
  for strand in range(strands):
   pts=[]
   for j,(x,z)in enumerate(shape(w+.0005,d+.0005)):
    a=T*j/n;normal=np.array([x/(w/2)**2,0,z/(d/2)**2]);normal/=np.linalg.norm(normal)
    if cream:
     q=np.array([x,y+(strand-1)*.0011,z]);q+=normal*(.0005*math.sin(j*T*14/n+row*.8+strand));q[1]+=.0004*math.cos(j*T*14/n+row*.8+strand)
    else:
     phase=j*T*22/n+T*strand/strands;cross=(strand-(strands-1)/2)*.0018;q=np.array([x,y+cross+.0008*math.sin(phase),z])+normal*(.0022+.0008*math.cos(phase))
    pts.append(q)
   p.append(B.tube('real-twisted-grass-band-filament-'+str(row)+'-'+str(strand),'grassLight'if(row+strand)%3==0 else'grass',pts,.00065,.00085,5,True,guide=[0,1,0]))
 # Fine bound warp stitches pass through courses rather than a plain cuboid surface.
 for k in range(64 if cream else 0):
  ix=int(k*n/64);x,z=shape(w+.001,d+.001)[ix];norm=np.array([x/(w/2)**2,0,z/(d/2)**2]);norm/=np.linalg.norm(norm);pts=[]
  for t in np.linspace(0,1,81):q=np.array([x,.010+t*.189,z])+norm*.0009*math.sin(t*courses*math.pi);pts.append(q)
  p.append(B.tube('individual-over-under-grass-binding-'+str(k),'grassLight',pts,.00035,.00045,5,False,guide=[0,1,0]))
 # Lid top courses are genuine crossed grass, clipped to the rounded lid footprint.
 for axis in[0,1]:
  extent=(d if axis==0 else w)/2
  for row,c in enumerate(np.linspace(-extent+.005,extent-.005,44)):
   other=(w if axis==0 else d)/2;rr=rad;edge=extent-rr;available=other if abs(c)<=edge else other-rr+math.sqrt(max(0,rr*rr-(abs(c)-edge)**2))
   for strand in[-1,1]:
    pts=[]
    for t in np.linspace(-available+.004,available-.004,65):
     x,z=(t,c+strand*.0006)if axis==0 else(c+strand*.0006,t);pts.append((x,.219+.0005*math.sin(t*650+row*math.pi)+axis*.0006,z))
    p.append(B.tube('real-cross-woven-lid-top-'+str(axis)+'-'+str(row)+'-'+str(strand),'grassLight'if row%3==0 else'grass',pts,.00055,.00070,5,False,guide=[0,1,0]))
 for side in[-1,1]:
  x=side*.160
  p.append(B.tube('covered-short-side-brown-loop-handle-'+str(side),'handle',[(x+side*.018*math.sin(math.pi*t),.150-.004*math.sin(math.pi*t),-.046+.092*t)for t in np.linspace(0,1,65)],.0015,.011,12,False,guide=[1,0,0]))
  for z in[-.046,.046]:
   p.append(B.box('handle-end-attachment-patch-'+str(side)+'-'+str(z),'handle',.002,.025,.020,(x+side*.001,.150,z)))
   for sign in[-1,1]:p.append(B.tube('visible-cross-stitch-'+str(side)+'-'+str(z)+'-'+str(sign),'thread',[(x+side*.0025,.140,z-sign*.007),(x+side*.0025,.160,z+sign*.007)],.00035,.00035,6,False,guide=[1,0,0]))
 return p,['Actual rounded rectangular hollow seagrass body, solid floor and separate removable lid with a fine reveal','Own cream fine coiled courses/vertical bindings, or nine large horizontal brown braided bands with nine separate twisted fibers per band; crossed woven lid courses','Two covered brown short-side strap handles with attachment patches and cross stitches','Own cream fine weave or brown coarser coiled grass palette retained; no generic solid box substituted'],{'piece_dimensions_cm':{'official_width':32,'official_height':22,'official_depth':26},'source_axis_ambiguity':'Official W32/H22/D26 describe basket body/lid. Covered handles project beyond short sides; their dimensions and the fine weave count/thickness are photo interpretations. The final envelope is scaled to official32×22×26, with handle projection included; hidden inner wall/floor are interpreted.'}

def cloth_ring(pid):
 # A physical closed annular cloth sheet with a radial slit. Centre hole and ties remain open geometry.
 nr=48;na=256;r0=.050;gap=.007;v=[];uv=[];f=[]
 def yy(r,a):return .003+.0025*math.sin(a*7+.5)*(r/.6)**2+.0014*math.sin(r*44+a*3)
 for side in[-1,1]:
  for j in range(nr):
   r=r0+(.6-r0)*j/(nr-1)
   for k in range(na):
    a=math.pi/2+gap+(T-2*gap)*k/(na-1);x=r*math.cos(a);z=r*math.sin(a);v.append((x,yy(r,a)+side*.00055,z));uv.append((x/1.2+.5,z/1.2+.5))
 layer=nr*na
 for side in[0,1]:
  for j in range(nr-1):
   for k in range(na-1):a=side*layer+j*na+k;b=a+na;f.extend([(a,a+1,b),(a+1,b+1,b)])
 for j in[0,nr-1]:
  for k in range(na-1):a=j*na+k;f.extend([(a,a+layer,a+1),(a+1,a+layer,a+layer+1)])
 for k in[0,na-1]:
  for j in range(nr-1):a=j*na+k;b=a+na;f.extend([(a,b,a+layer),(b,b+layer,a+layer)])
 p=[A.raw('real-draped-circular-cloth-annulus-with-open-radial-slit','fabric',v,f,uv)]
 for radius in[r0+.002,.596]:
  pts=[]
  for a in np.linspace(math.pi/2+gap,T+math.pi/2-gap,321):pts.append((radius*math.cos(a),yy(radius,a)+.0007,radius*math.sin(a)))
  p.append(B.tube('actual-fine-stitched-circular-hem-'+str(radius),'fabric',pts,.0010,.0010,6,False,guide=[0,1,0]))
 # Three own-source bow ties connect the two actual slit edges, rather than printed ribbons.
 for k,z in enumerate([.145,.350,.550]):
  for sign in[-1,1]:
   pts=[(sign*.011+.034*sign*(1-math.cos(a)),.007+.002*math.sin(a),z+.016*math.sin(a))for a in np.linspace(0,T,65)[:-1]];p.append(B.tube('real-fabric-slit-tie-bow-loop-'+str(k)+'-'+str(sign),'tie',pts,.0006,.0045,8,True,guide=[0,1,0]))
   p.append(B.tube('separate-fabric-tie-free-tail-'+str(k)+'-'+str(sign),'tie',[(sign*.006,.008,z),(sign*.025,.006,z+.026),(sign*.014,.004,z+.052)],.0006,.0040,8,False,guide=[0,1,0]))
  p.append(B.box('soft-stitched-tie-centre-'+str(k),'tie',.013,.005,.010,(0,.007,z)))
 return p,['Real finite1.1mm cloth annulus with a true centre opening and radial slit','Three separate finite-width tied fabric bows bridge the slit, with six loops and six free tails','Fine physical outer/inner hems, slight cloth waviness and source-specific circular print/plaid UV','Official diameter120cm is anchored by this exact SKU’s liveTR size selector, not borrowed from another SKU'],{'piece_dimensions_cm':{'official_diameter':120},'source_axis_ambiguity':'Official BEDEN:D120 is diameter120cm. Centre-hole diameter10cm, slit gap, cloth thickness/waviness, hem and tie dimensions are own-photo estimates. Overall vertical thickness is not an official size.','source_pattern_method':'Own same-SKU pattern is reconstructed intrinsically; no full object photo plane or studio background is applied.','source_pattern_trace':str(A.R/'source-round-02/leaf-pattern-trace.json')if pid=='1366871001'else None,'source_pattern_effective_detail_pixels':1768 if pid=='1366871001'else None}

def material(pid,key,kind,rgb,rough=.45,metal=0):
 bank,m=BASE(pid,key,'paper'if kind in['grass','fabric_plaid','fabric_leaf']else kind,rgb,rough,metal);n=2048;u=np.arange(n,dtype=np.float32)[None,:]/n;v=np.arange(n,dtype=np.float32)[:,None]/n;rng=np.random.default_rng(int(pid))
 if kind=='grass':
  # Intrinsic coiled/fibrous colour. Broad actual courses are geometry, not baked shadows.
  wave=np.sin(T*(u*19+.009*np.sin(T*v*6)))*.7+np.sin(T*(u*587+v*.6))*.8+rng.normal(0,.32,(n,n));color=np.array(rgb)[None,None,:]+wave[:,:,None]*np.array([3.0,2.8,2.3]);Image.fromarray(np.clip(color,0,255).astype('uint8'),'RGB').save(bank/m['baseColorTexture'],optimize=True)
 if kind=='fabric_plaid':
  # Own red/white/burgundy source: broad red field with fine pale orthogonal lines and darker paired overchecks.
  x=np.broadcast_to(u,(n,n));y=np.broadcast_to(v,(n,n));line=np.minimum((x*10+.12)%1,1-(x*10+.12)%1)<.006;line|=np.minimum((y*10+.08)%1,1-(y*10+.08)%1)<.006;deep=(np.minimum((x*5+.20)%1,1-(x*5+.20)%1)<.015)|(np.minimum((y*5+.17)%1,1-(y*5+.17)%1)<.015);color=np.zeros((n,n,3),np.float32)+[141,7,32];color[deep]=[105,5,26];color[line]=[197,167,163];noise=rng.normal(0,.6,(n,n));color+=noise[:,:,None];Image.fromarray(np.clip(color,0,255).astype('uint8'),'RGB').save(bank/m['baseColorTexture'],optimize=True);m['extras']['own_source_pattern_reconstructed']=True
 if kind=='fabric_leaf':
  # Trace only the own official green printed motif into an intrinsic flat-colour weave.
  refs=[q for q in json.loads((A.R/'original-image-masters.json').read_text())if q['sku']==pid];p=refs[0];im=Image.open(p['path']).convert('RGB');arr=np.array(im);green=(arr[:,:,0]<100)&(arr[:,:,1]<105)&(arr[:,:,2]<85)
  # Source front product circle is measured from its isolated pale cloth boundary.
  body=(arr[:,:,0]<238)&(arr[:,:,1]<238)&(arr[:,:,2]<232);ys,xs=np.where(body[500:2700,100:2060]);xs=xs+100;ys=ys+500;left,right=xs.min(),xs.max();top,bottom=ys.min(),ys.max();cx=(left+right)/2;cy=1615.;radius=(right-left)/2
  # Map the master’s observed pattern mask to the2K material canvas. Nearest sampling never invents fine photograph pixels.
  xx=((np.arange(n)/n-.5)*2*radius+cx).astype(int);yy=((np.arange(n)/n-.5)*2*radius+cy).astype(int);mask=green[np.clip(yy,0,im.height-1)[:,None],np.clip(xx,0,im.width-1)[None,:]];X=np.broadcast_to(u-.5,(n,n));Y=np.broadcast_to(v-.5,(n,n));rr=np.sqrt(X*X+Y*Y);mask&=(rr>.24)&(rr<.488);mask&=~((abs(X)<.014)&(Y>.02))
  tex=np.zeros((n,n,3),np.float32)+[214,201,178];tex[mask]=[47,52,33];weave=np.sin(T*u*960)*.7+np.sin(T*v*1060)*.7+rng.normal(0,.24,(n,n));tex+=weave[:,:,None];Image.fromarray(np.clip(tex,0,255).astype('uint8'),'RGB').save(bank/m['baseColorTexture'],optimize=True)
  evidence=A.R/'source-round-02/leaf-pattern-trace.json';A.dump(evidence,{'source_master':p['path'],'source_sha256':p['sha256'],'master_unchanged':A.sha(p['path'])==p['sha256'],'method':'Threshold own dark-green print to binary motif; re-render flat intrinsic green on procedural beige woven base. No source RGB/background/reflections copied. Narrow slit/tie region is omitted as geometry occupies that slit.','source_circle_pixel_bounds':[int(left),int(top),int(right),int(bottom)],'source_effective_diameter_pixels':int(2*radius),'output_native_canvas_pixels':[2048,2048],'geometric_uv_mapping':'XY source circle -> XZ cloth plane','intrinsic_palette_rgb':{'fabric':[214,201,178],'print':[47,52,33]}});m['extras'].update(own_source_pattern_reconstructed=True,source_pattern_trace=str(evidence),photo_pattern_mask_used=True)
 return bank,m
A.material=material
entries=[
('1314660002','Kahverengi kapaklı deniz çayırı sepeti',lambda:basket(False),[32,22,26],[22,32,26],False,{'grass':('grass',[117,80,47],.78,0),'grassLight':('grass',[145,108,68],.76,0),'handle':('paper',[103,54,31],.53,0),'thread':('paper',[172,120,80],.66,0)},'Deniz yosunu %100 · Kahverengi',1),
('1314660001','Açık bej kapaklı deniz çayırı sepeti',lambda:basket(True),[32,22,26],[22,32,26],False,{'grass':('grass',[206,196,164],.80,0),'grassLight':('grass',[219,210,182],.80,0),'handle':('paper',[124,65,36],.53,0),'thread':('paper',[178,122,78],.66,0)},'Deniz yosunu %100 · Açık bej',1),
('1366871001','Yaprak baskılı pamuk keten yılbaşı ağacı eteği',lambda:cloth_ring('1366871001'),[1,1,1],[None,None,None],True,{'fabric':('fabric_leaf',[214,201,178],.82,0),'tie':('paper',[214,201,178],.82,0)},'Pamuk %70 · Keten %30 · Açık bej/Koyu yeşil',0),
('1353729002','Kareli pamuklu yılbaşı ağacı eteği',lambda:cloth_ring('1353729002'),[1,1,1],[None,None,None],True,{'fabric':('fabric_plaid',[141,7,32],.82,0),'tie':('paper',[141,7,32],.82,0)},'Pamuk %100 · Kırmızı/Beyaz/Bordo',0)]
for sku,title,fn,dims,hwd,derive,mats,label,primary in entries:
 refs=[p for p in json.loads((A.R/'original-image-masters.json').read_text())if p['sku']==sku];A.SPECS[sku]={'name':title,'dims':dims,'hwd':hwd,'derive_dimensions':derive,'build':fn,'estimated':['local_wall_or_cloth_thickness','weave_or_stitch_geometry','handles_lid_or_slit_tie_dimensions','unlabelled_vertical_drape'if derive else'hidden_inner_floor_thickness'],'label':label,'color':label.split(' · ')[-1],'semantics':'Kendi SKU’sunun resmî fiziksel ölçüleri aynen korunur. Yerel örgü, kumaş kalınlığı, kulp/kapak veya etek deliği/bağcığı ve görünmeyen ayrıntılar kendi fotoğraflarından yorumdur; üretici CAD/tarama değildir.','materials':mats,'primary_hash':Path(refs[primary]['path']).stem.split('-')[-1]}
if __name__=='__main__':
 for pid in sys.argv[1:]or[q[0]for q in entries]:A.build(pid)
