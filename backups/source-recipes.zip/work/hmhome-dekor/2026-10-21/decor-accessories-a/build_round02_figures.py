"""Nine exact-SKU ornaments, actual cast assemblies, closed geometry and intrinsic PBR."""
from pathlib import Path
import sys,json,math
sys.dont_write_bytecode=True
import numpy as np
from PIL import Image,ImageDraw,ImageFont
import build_accessories as A
import build_ornaments as O
import implicit_shapes as I
B=A.B;T=math.tau;BASE=O._mat
GLASS_NOTE={'quality_status':'preview_limited','quality_label':'Yaklaşık cam görünümü','quality_note':'Camın renk, yansıma ve kırılma görünümü tarayıcıda yaklaşık gösterilir; malzemeli GLB’yi proje ışığında değerlendirin.'}
def finish_body(p,w=.07,h=.095):
 v=np.concatenate([np.asarray(g['_vertices'])for g in p]);lo=v.min(0);hi=v.max(0)
 for g in p:g['_vertices']=[((x-(hi[0]+lo[0])/2)*w/(hi[0]-lo[0]),(y-lo[1])*h/(hi[1]-lo[1]),z)for x,y,z in g['_vertices']]
 return p

def hanger(p,h,mat='gold',r=.005,cord=.09,width=.0007,x0=0):
 p.append(B.lathe('real-crimped-top-cap',mat,[(0,h-.001),(r,h-.001),(r*1.05,h+.002),(r*.88,h+.005),(0,h+.005)],64,False,offset=(x0,0,0)))
 for j in range(16):a=T*j/16;p.append(B.tube('physical-top-cap-flute-'+str(j),mat,[(x0+r*math.cos(a),h,r*math.sin(a)),(x0+r*.95*math.cos(a),h+.004,r*.95*math.sin(a))],.00015,.00015,5,False,guide=[0,1,0]))
 p.append(O.eye('separate-real-hanger-eye',mat,(x0,h+.008,0),.003,.0003));p.append(O.ribbon_loop('finite-width-hanging-cord',mat,(x0,h+.011,0),cord,width));return p

def mug():
 p=[B.lathe('real-red-mug-with-hollow-inner-lip-solid-floor','red',[(0,0),(.019,0),(.021,.003),(.023,.038),(.023,.043),(.0205,.043),(.0195,.038),(.017,.005),(0,.005)],128,False)]
 p.append(B.tube('rounded-physical-cocoa-mug-handle','red',[(.020+.013*math.sin(a),.027+.015*math.cos(a),0)for a in np.linspace(0,math.pi,97)],.003,.003,12,False,guide=[0,0,1]))
 p.append(B.lathe('dark-chocolate-irregular-dripping-rim','cocoa',[(.0203,.039),(.0241,.039),(.0242,.043),(.0204,.043)],128,True))
 for k in range(6):a=T*k/6+.2;p.append(O.sphere('short-cocoa-drip-'+str(k),'cocoa',.003,(.0234*math.cos(a),.039-.001*(k%3),.0234*math.sin(a)),scale=(.7,1.5,.7),n=24))
 for layer,(y,r,count)in enumerate([(.046,.016,6),(.055,.012,5),(.063,.007,3)]):
  for k in range(count):a=T*k/count+layer*.8;p.append(O.sphere('separate-rounded-marshmallow-'+str(layer)+'-'+str(k),'snow',.007,(r*math.cos(a),y,r*math.sin(a)),scale=(1,1.04,.93),n=32))
 body=p[0];body['_uvs']=[(.5-math.atan2(z,x)/T,1-y/.043)for x,y,z in body['_vertices']]
 finish_body(p);hanger(p,.095)
 return p,['Actual closed red mug shell with interior lip and solid floor, rounded loop handle and dark cocoa drip rim','Fourteen individually rounded white marshmallows, small top cap, separate eye and gold cord','Own HOT COCOA lettering reconstructed on the mug material; no photograph plane'],dict(GLASS_NOTE,piece_dimensions_cm={'official_labelled_width':7,'official_labelled_height':9.5},source_axis_ambiguity='Official W7/H9.5 labels apply to the figurative ornament without clarifying cord inclusion. They anchor the assembled mug/marshmallow body envelope. Cord, depth, handle and local details are photo-scaled.')

def boot_shape(name,mat,w=.03,h=.075,d=.036,x=0):
 # Continuous shaft/instep/toe loft. Front faces +Z; the rounded foot projects in depth.
 profiles=[]
 for y,ww,dd,zz in[(0,.77,1.0,.004),(.002,.94,1.05,.004),(.008,1,1.05,.004),(.015,.97,.94,.003),(.022,.84,.77,-.002),(.030,.76,.62,-.006),(.045,.81,.63,-.006),(.067,.85,.65,-.006),(.074,.83,.63,-.006),(.075,.77,.57,-.006)]:
  profiles.append(([(xx+x,zz0+zz)for xx,zz0 in A.outline(w*ww,d*dd,.006,96)],y*h/.075))
 return A.capped(name,mat,profiles)

def gold_boots():
 p=[]
 for k,x in enumerate([-.0175,.0175]):
  p.append(boot_shape('continuous-rounded-gold-boot-shaft-instep-toe-'+str(k),'gold',.032,.095,.041,x))
  p.append(A.ring('thin-white-glitter-boot-surface-'+str(k),'goldglitter',[(A.outline(.027,.026,.006,96)+np.array([x,-.006]),.025),(A.outline(.028,.027,.006,96)+np.array([x,-.006]),.086),(A.outline(.0275,.0265,.006,96)+np.array([x,-.006]),.086),(A.outline(.0265,.0255,.006,96)+np.array([x,-.006]),.025)]))
  for y in np.linspace(.009,.083,7):
   xx=.011*(1-.15*y/.095);pts=[(x-xx,y,.010),(x,y-.006,.0135),(x+xx,y+.005,.010)];p.append(B.tube('raised-white-cross-lace-'+str(k)+'-'+str(y),'white',pts,.00052,.00052,6,False,guide=[0,0,1]))
  for y in[.0015,.0055]:p.append(B.tube('stacked-rounded-gold-sole-edge-'+str(k)+'-'+str(y),'gold',[(xx+x,y,zz+.004)for xx,zz in A.outline(.033,.043,.006,128)],.0008,.0008,6,True,guide=[0,1,0]))
 finish_body(p);hanger(p,.095)
 return p,['Two continuous boot castings with real rounded toes, forward-projecting insteps and depth verified by own second angle','Distinct stacked sole edges, gold cuff bands, pale textured shafts and seven separate white criss-cross lace rows per boot','A connected pair remains one SKU; no extra ankle joint or flat front-photo card'],dict(GLASS_NOTE,set_quantity=1,piece_dimensions_cm={'official_labelled_width':7,'official_labelled_height':9.5},source_axis_ambiguity='Official W7/H9.5 anchor the pair body envelope. Front and own recovered side angle determine the interpreted depth/sole/toe/lace relief; hanging cord is unlabelled.')

def small_boots_snowflake():
 p=[]
 for k,x in enumerate([.018,.039]):
  p.append(boot_shape('small-gold-pair-boot-'+str(k),'gold',.020,.049,.025,x))
  for y in[.003,.047]:p.append(B.tube('gold-boot-edge-'+str(k)+'-'+str(y),'gold',[(xx+x,y,zz+.004)for xx,zz in A.outline(.021,.027,.004,64)],.0007,.0007,6,True,guide=[0,1,0]))
  for j in range(5):y=.013+j*.006;p.append(B.tube('own-crossed-glitter-lace-'+str(k)+'-'+str(j),'goldglitter',[(x-.008,y,.011),(x+.008,y+.006,.011)],.0007,.0007,6,False,guide=[0,0,1]))
 sx=-.039;sy=.027
 # Own snowflake is a broad solid six-lobed embossed casting, not an open forked wire star.
 outline=[]
 for k in range(12):
  a=math.pi/2+T*k/12;r=.023 if k%2==0 else .0165;outline.append((sx+r*math.cos(a),sy+r*math.sin(a)))
 for repeat in range(2):
  smooth=[]
  for k,a in enumerate(outline):b=outline[(k+1)%len(outline)];smooth.extend([(a[0]*.78+b[0]*.22,a[1]*.78+b[1]*.22),(a[0]*.22+b[0]*.78,a[1]*.22+b[1]*.78)])
  outline=smooth
 n=len(outline);vv=[(sx,sy,.006),(sx,sy,-.003)]+[(x,y,0)for x,y in outline];ff=[]
 for k in range(n):a=2+k;b=2+(k+1)%n;ff.extend([(0,a,b),(1,b,a)])
 p.append(A.raw('own-solid-rounded-six-lobed-gold-snowflake','gold',vv,ff))
 for k in range(6):
  a=math.pi/2+T*k/6
  for sign in[-1,1]:
   pts=[(sx+r*math.cos(a+sign*.08),sy+r*math.sin(a+sign*.08),.006*(1-r/.026)+.0004)for r in np.linspace(.002,.021,30)];p.append(B.tube('embossed-six-lobe-starburst-ridge-'+str(k)+'-'+str(sign),'goldglitter',pts,.00045,.00075,6,False,guide=[0,0,1]))
 for x,h in[(-.039,.052),(.0285,.050)]:p.append(O.eye('small-ornament-cap-eye-'+str(x),'gold',(x,h+.003,0),.002,.0003));p.append(O.ribbon_loop('separate-gold-cord-'+str(x),'gold',(x,h+.006,0),.080,.0006))
 return p,['A real six-arm three-dimensional snowflake with twelve forked branches and raised starburst ridges','Separate paired boot casting, rounded toes/shaft edges and crossed glitter lace relief','Two physical decorations under one set SKU; nominal snowflake4.6 cm span and boots4.9 cm tall are interpretations within official design-dependent3–5 cm range'],{'set_quantity':2,'nominal_interpreted_piece_dimensions_cm':{'snowflake_span':4.6,'boots_height':4.9},'source_axis_ambiguity':'Official approx3–5cm varies by design and does not assign individual dimensions. These nominal piece sizes, all depth/cord lengths and display layout are declared estimates within the official range.'}

def mitten():
 p=[]
 def field(q):
  f=I.ell_sdf(q,(0,.040,0),(.025,.039,.014));thumb=I.ell_sdf(q,(-.024,.051,.002),(.013,.021,.012));return I.smin(f,thumb,.008)
 I.marching_tetra(p,'one-continuous-rounded-mitten-with-real-thumb','white',field,[[-.042,-.004,-.019],[.031,.085,.020]],.00115)
 # Physical fine raised knit columns, fitted to the curved own-photo white body.
 for k in range(18):
  a=T*k/18;points=[]
  for y in np.linspace(.010,.068,70):rr=math.sqrt(max(.01,1-((y-.040)/.039)**2));points.append((.025*rr*math.cos(a)+.0005*math.sin(y*1450+k),y,.014*rr*math.sin(a)))
  p.append(B.tube('physical-white-knit-rib-'+str(k),'white',points,.00050,.00050,5,False,guide='radial'))
 p.append(B.lathe('thick-ribbed-white-mitten-cuff','white',[(0,.073),(.020,.073),(.023,.077),(.023,.088),(.020,.091),(0,.091)],96,False,ellipse=.65))
 for k in range(24):a=T*k/24;p.append(B.tube('raised-cuff-rib-'+str(k),'white',[(.023*math.cos(a),.077,.015*math.sin(a)),(.023*math.cos(a),.087,.015*math.sin(a))],.00065,.00065,6,False,guide=[0,1,0]))
 for zsign in[-1,1]:
  for k in range(6):
   a=T*k/6;pts=[]
   for r in np.linspace(0,.014,10):x=r*math.cos(a);y=.042+r*math.sin(a);z=zsign*.014*math.sqrt(max(.03,1-(x/.026)**2-((y-.040)/.042)**2));pts.append((x,y,z+zsign*.0008))
   p.append(B.tube('own-gold-painted-snowflake-ray-'+str(zsign)+'-'+str(k),'goldglitter',pts,.0006,.0006,6,False,guide=[0,0,1]))
   for sign in[-1,1]:
    rr=.009;cx=rr*math.cos(a);cy=.042+rr*math.sin(a);pts=[]
    for tt in np.linspace(0,.006,5):x=cx+tt*math.cos(a+sign*.85);y=cy+tt*math.sin(a+sign*.85);z=zsign*.014*math.sqrt(max(.03,1-(x/.026)**2-((y-.040)/.042)**2));pts.append((x,y,z+zsign*.0008))
    p.append(B.tube('snowflake-gold-fork-'+str(zsign)+'-'+str(k)+'-'+str(sign),'goldglitter',pts,.00045,.00045,6,False,guide=[0,0,1]))
 finish_body(p);hanger(p,.095)
 return p,['One continuously rounded mitten with an integrated thumb and genuine front/back depth','Eighteen actual knit ribs, thick24-rib cuff and separate thin gold snowflake rays/forks fitted to the curved face','Own white/gold same-SKU front and side photos determine local knit/cuff/thumb proportions'],dict(GLASS_NOTE,piece_dimensions_cm={'official_labelled_width':7,'official_labelled_height':9.5},source_axis_ambiguity='Official W7/H9.5 anchors the mitten/cuff body; unlabelled depth, fine knit relief and cord are interpretations, not knitted textile composition. Official material remains painted glass100%.')

def skate():
 p=[]
 outline=[(-.032,0),(.029,0),(.038,.006),(.038,.015),(.030,.024),(.009,.031),(.001,.046),(-.003,.081),(-.012,.089),(-.027,.087),(-.030,.079),(-.027,.044),(-.033,.025)]
 for repeat in range(3):
  smooth=[]
  for k,a in enumerate(outline):b=outline[(k+1)%len(outline)];smooth.extend([(a[0]*.8+b[0]*.2,a[1]*.8+b[1]*.2),(a[0]*.2+b[0]*.8,a[1]*.2+b[1]*.8)])
  outline=smooth
 n=len(outline);vv=[];ff=[]
 for scale,z in[(.83,-.015),(.96,-.013),(1,-.007),(1,.007),(.96,.013),(.83,.015)]:
  for x,y in outline:vv.append((x*scale,(y-.044)*scale+.044,z))
 for j in range(5):
  for k in range(n):a=j*n+k;b=j*n+(k+1)%n;c=(j+1)*n+k;d=(j+1)*n+(k+1)%n;ff.extend([(a,b,c),(b,d,c)])
 # Concave cap triangulation by deterministic ear clipping.
 ids=list(range(n));xy=np.array(outline);area=np.sum(xy[:,0]*np.roll(xy[:,1],-1)-xy[:,1]*np.roll(xy[:,0],-1))
 if area<0:ids.reverse()
 def cross(a,b):return a[0]*b[1]-a[1]*b[0]
 triangles=[]
 while len(ids)>3:
  for j,b in enumerate(ids):
   a=ids[j-1];c=ids[(j+1)%len(ids)];pa,pb,pc=xy[a],xy[b],xy[c]
   if cross(pb-pa,pc-pb)<=1e-14:continue
   if any(cross(pb-pa,xy[k]-pa)>=-1e-13 and cross(pc-pb,xy[k]-pb)>=-1e-13 and cross(pa-pc,xy[k]-pc)>=-1e-13 for k in ids if k not in[a,b,c]):continue
   triangles.append((a,b,c));ids.pop(j);break
  else:raise ValueError('skate outline not simple')
 triangles.append(tuple(ids))
 for a,b,c in triangles:ff.extend([(a,c,b),(5*n+a,5*n+b,5*n+c)])
 p.append(A.raw('continuous-rounded-bevelled-white-ice-skate-side-profile','snowglitter',vv,ff))
 # Sole blade is a true thin metal runner, separate from boot casting.
 path=[(-.035,-.002,0),(-.028,-.004,0),(.028,-.004,0),(.041,.001,0),(.042,.006,0)];p.append(B.tube('rounded-gold-ice-skate-runner','gold',path,.0016,.0030,10,False,guide=[0,0,1]))
 for x in[-.026,.022]:p.append(B.box('gold-runner-support-'+str(x),'gold',.004,.008,.006,(x,.002,0)))
 for k in range(7):y=.026+k*.007;x=-.004-(y-.026)*.28;p.append(B.tube('visible-gold-criss-cross-skate-lace-'+str(k),'goldglitter',[(x-.009,y,.0165),(x+.008,y+.006,.0165)],.00075,.00075,6,False,guide=[0,0,1]))
 finish_body(p);hanger(p,.095,x0=-.017)
 return p,['One smooth continuous white boot casting with ankle, rounded instep/toe and separate gold metallic runner','Actual runner supports, curved front runner end, seven raised gold lace crosses and white glitter surface','No flat shoe image or block substituted for the photographed side silhouette'],dict(GLASS_NOTE,piece_dimensions_cm={'official_labelled_width':7,'official_labelled_height':9.5},source_axis_ambiguity='Official W7/H9.5 anchors the assembled skate body including blade. Cast depth, laces, runner thickness and suspension are photo interpretations.')

def satin_red():
 p=[O.sphere('own-eight-cm-red-burgundy-satin-thread-ball','satinred',.04,(0,.04,0),n=144)];p.append(B.lathe('small-real-gold-satin-ball-cap','gold',[(0,.079),(.005,.079),(.0055,.083),(0,.084)],64,False));p.append(O.eye('small-gold-satin-eye','gold',(0,.087,0),.003));p.append(O.ribbon_loop('finite-width-red-satin-hanging-ribbon','ribbon',(0,.090,0),.068,.004));return p,['Actual8 cm sphere with six broad own-photo burgundy/red satin sectors and intrinsic directional thread normals','Gold cap, separate eye and finite4 mm red ribbon','Official polyethylene80/polyamide20 retained; no invented glass transmission'],{'piece_dimensions_cm':{'diameter':8},'bounds_semantics':'Body diameter8 cm is official; cap, ribbon and their resulting total hanging height are photo interpretations.'}

def textured_gold():
 r=.04;p=[O.sphere('eight-cm-gold-textured-glass-body','gold',r,(0,r,0),n=144)];rng=np.random.default_rng(1354994003)
 # Larger source droplets are actual glass relief, finer crinkle remains intrinsic PBR.
 for k in range(630):
  y=1-2*(k+.5)/630;a=k*math.pi*(3-math.sqrt(5));s=math.sqrt(1-y*y);rr=r+.0001;pos=(rr*s*math.cos(a),r+rr*y,rr*s*math.sin(a));p.append(O.sphere('actual-irregular-raised-glass-droplet-'+str(k),'goldglitter',rng.uniform(.00020,.00048),pos,scale=(1,rng.uniform(.8,1.2),1),n=10))
 p.append(B.lathe('crimped-gold-textured-ball-cap','gold',[(0,.079),(.006,.079),(.0065,.083),(0,.085)],64,False));p.append(O.eye('fine-gold-ball-eye','gold',(0,.088,0),.0025));p.append(O.ribbon_loop('finite-white-velvet-hanging-loop','white',(0,.092,0),.073,.004));return p,['Eight-cm sphere with630 genuine irregular small raised glass droplets plus intrinsic fine gold crinkle PBR','Source champagne-gold mirrored glass, real cap/eye and finite-width white velvet hanger','Full sphere is not replaced by a textured front card'],dict(GLASS_NOTE,piece_dimensions_cm={'diameter':8},source_axis_ambiguity='Official diameter8 cm refers to the glass body. Tiny relief, cap, white velvet loop and total hanging height are photo interpretations. Maximum droplet tips exceed the nominal smooth body diameter slightly.')

def pine(name,x,z,height=.038):
 p=[]
 profile=[(0,.011),(.001,.011)]
 for j in range(8):y=.011+j*height/9;r=.010*(1-j/9);profile.extend([(r,y),(r*.85,y+.002),(r*.25,y+height/9)])
 profile.extend([(.0004,.011+height),(0,.011+height)]);p.append(B.lathe(name+'-continuous-green-pine','pine',profile,48,False,offset=(x,0,z)))
 for j in range(6):
  y=.013+j*height/8;r=.009*(1-j/8);p.append(B.tube(name+'-snow-tier-'+str(j),'snow',[(x+r*math.cos(a),y+.001*math.sin(5*a),z+r*math.sin(a))for a in np.linspace(0,T,49)[:-1]],.0006,.0006,5,True,guide=[0,1,0]))
 return p

def globe(kind):
 p=[O.shell('true-thick-hollow-clear-eight-cm-globe','glass',.04),O.eye('actual-clear-glass-top-eye','glass',(0,.084,0),.003,.0007),O.ribbon_loop('fine-silver-globe-cord','silver',(0,.087,0),.072,.00065)]
 p.append(B.lathe('rounded-white-faux-snow-ground','snow',[(0,.001),(.012,.001),(.021,.004),(.028,.010),(.027,.014),(.020,.015),(0,.015)],96,False))
 if kind=='reindeer':
  p+=pine('first-tall-own-snowy-tree',-.014,-.005,.043);p+=pine('second-small-own-snowy-tree',.016,-.012,.026)
  p.append(O.sphere('reindeer-horizontal-rounded-body','brown',.011,(.002,.025,.006),scale=(1.4,.75,.65),n=48));p.append(O.sphere('reindeer-raised-neck','brown',.006,(.015,.033,.006),scale=(.7,1.7,.75),n=40));p.append(O.sphere('reindeer-real-head-and-muzzle','brown',.005,(.018,.043,.006),scale=(1.3,.75,.6),n=32))
  for zz in[.002,.010]:p.append(O.sphere('two-upright-reindeer-ears-'+str(zz),'brown',.002,(.017,.047,zz),scale=(.6,1.8,.40),n=20))
  for xx in[-.009,.011]:
   for zz in[.002,.010]:p.append(B.tube('four-separate-reindeer-legs-'+str(xx)+'-'+str(zz),'brown',[(xx,.024,zz),(xx-.002,.014,zz)],.0014,.0010,8,False,guide=[0,0,1]))
  for zz in[.002,.010]:
   p.append(B.tube('real-branched-antler-beam-'+str(zz),'antler',[(.017,.046,zz),(.018,.053,zz),(.014,.060,zz),(.010,.064,zz)],.0008,.00065,6,False,guide=[0,0,1]))
   for j,(x,y)in enumerate([(.017,.051),(.016,.056),(.013,.060)]):p.append(B.tube('separate-antler-prong-'+str(zz)+'-'+str(j),'antler',[(x,y,zz),(x+.004,y+.004,zz),(x+.004,y+.007,zz)],.00055,.00045,6,False,guide=[0,0,1]))
  p.append(O.sphere('small-real-reindeer-tail','brown',.0025,(-.014,.029,.006),scale=(1.4,.55,.6),n=20));features=['Miniature real four-legged reindeer with raised neck/head, branching paired antlers and small tail','Two distinct snow-dusted green pine trees, curved faux snow ground and individual granules']
 else:
  p+=pine('own-tall-rear-snowy-tree',-.017,-.011,.047)
  p.append(B.box('actual-golden-house-walls','house',.031,.025,.026,(.004,.027,.004)))
  # Real triangular gable and two pitched roof panels, solid closed volume.
  vv=[(-.012,.039,-.009),(.020,.039,-.009),(.004,.053,-.009),(-.012,.039,.017),(.020,.039,.017),(.004,.053,.017)];ff=[(0,2,1),(3,4,5),(0,1,3),(1,4,3),(1,2,4),(2,5,4),(2,0,5),(0,3,5)];p.append(A.raw('actual-gabled-house-roof-solid','snow',vv,ff))
  p.append(B.box('small-house-chimney','house',.005,.012,.006,(.013,.048,-.002)))
  for x in[-.004,.012]:
   pts=[(x-.003,.021,.0175),(x-.003,.029,.0175),(x,.032,.0175),(x+.003,.029,.0175),(x+.003,.021,.0175),(x-.003,.021,.0175)];p.append(B.tube('arched-front-window-white-frame-'+str(x),'snow',pts[:-1],.0006,.0006,6,True,guide=[0,0,1]));p.append(B.tube('front-window-crossbar-'+str(x),'snow',[(x-.0025,.026,.0175),(x+.0025,.026,.0175)],.0004,.0004,6,False,guide=[0,0,1]));p.append(B.tube('front-window-mullion-'+str(x),'snow',[(x,.021,.0175),(x,.031,.0175)],.0004,.0004,6,False,guide=[0,0,1]))
  p.append(B.tube('house-arched-door-frame','snow',[(-.001,.015,.018),(-.001,.022,.018),(.002,.026,.018),(.005,.022,.018),(.005,.015,.018)],.0006,.0006,6,False,guide=[0,0,1]));features=['Actual small gold/beige house with separate walls, triangular gable, pitched white snow roof and chimney','Raised white arched window/door frames and a separate tall green snowy pine; no house photograph plane']
 rng=np.random.default_rng(703 if kind=='reindeer' else 702)
 for k in range(85):a=rng.uniform(0,T);r=.025*math.sqrt(rng.random());p.append(O.sphere('separate-actual-faux-snow-granule-'+str(k),'snow',rng.uniform(.00035,.00075),(r*math.cos(a),.014+rng.uniform(0,.0015),r*math.sin(a)),n=10))
 return p,['Hollow clear8 cm glass sphere with physical wall, own top eye and fine silver cord']+features,dict(GLASS_NOTE,piece_dimensions_cm={'diameter':8},bounds_semantics='Official8 cm refers to the spherical body; eye, cord and all interior miniature dimensions are photo interpretations. Browser transmission/refraction remains approximate.')

# Material patterns below encode intrinsic colour/relief only; original photographs remain untouched.
def material(pid,key,kind,rgb,rough=.45,metal=0):
 bank,m=BASE(pid,key,'metal'if kind in['clear','cocoalabel','satinred']else kind,rgb,rough,metal)
 if kind=='clear':m.update(baseColorFactor=[.97,.99,1,.15],alphaMode='BLEND',transmission=.97,ior=1.50,thickness=.0008,attenuationColor=[.96,.98,1],attenuationDistance=.8)
 if kind=='cocoalabel':
  im=Image.open(bank/m['baseColorTexture']);d=ImageDraw.Draw(im);font=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial Rounded Bold.ttf',200)
  for x in[512,1536]:
   for word,cy in[('HOT',710),('COCOA',1260)]:
    patch=Image.new('RGBA',(1000,260),(0,0,0,0));draw=ImageDraw.Draw(patch);draw.text((500,130),word,font=font,anchor='mm',fill=(235,232,220,255));patch=patch.resize((1000,650),Image.Resampling.LANCZOS);im.paste(patch,(x-500,cy-325),patch)

  im.save(bank/m['baseColorTexture'],optimize=True)
 if kind=='satinred':
  n=2048;u=np.arange(n)[None,:]/n;v=np.arange(n)[:,None]/n;band=(u*6)%1;rgb=np.where((band<.24)[:,:,None],np.array([183,20,48]),np.array([99,6,27]));threads=np.sin(T*u*1600);rgb=np.broadcast_to(rgb,(n,n,3))+np.broadcast_to(threads,(n,n))[:,:,None]*2;Image.fromarray(np.clip(rgb,0,255).astype('uint8'),'RGB').save(bank/m['baseColorTexture'],optimize=True);nn=np.zeros((n,n,3),np.uint8);nn[:,:,0]=np.broadcast_to((127+threads*22).astype('uint8'),(n,n));nn[:,:,1]=127;nn[:,:,2]=253;Image.fromarray(nn,'RGB').save(bank/m['normalTexture'],optimize=True)
 return bank,m
A.material=material
entries=[
('1299157022','Marşmelovlu sıcak çikolata kupası cam süs',mug,{'red':('cocoalabel',[151,8,22],.13,1),'cocoa':('metal',[42,24,16],.25,0),'snow':('paper',[239,237,224],.62,0),'gold':('metal',[209,178,106],.13,1)},'Cam %100 · Kırmızı/Koyu kahverengi/Beyaz/Altın rengi',[9.5,7,None],1),
('1359291003','2’li altın kar tanesi ve bot yılbaşı süsü',small_boots_snowflake,{'gold':('metal',[218,195,139],.11,1),'goldglitter':('glitter',[218,195,139],.40,1)},'Polistiren %100 · Altın rengi',[None,None,None],1),
('1114258019','Kırmızı ve bordo saten ip kaplı yılbaşı süsü',satin_red,{'satinred':('satinred',[0,0,0],.30,0),'gold':('metal',[192,160,88],.18,1),'ribbon':('paper',[132,9,32],.52,0)},'Polietilen %80 · Poliamid %20 · Saten',[None,None,None],1),
('1299157025','Beyaz altın paten biçimli cam yılbaşı süsü',skate,{'snowglitter':('glitter',[233,234,225],.50,0),'gold':('metal',[215,184,110],.12,1),'goldglitter':('glitter',[213,183,116],.38,1)},'Cam %100 · Beyaz/Altın rengi',[9.5,7,None],1),
('1299157027','Altın beyaz botlar biçimli cam yılbaşı süsü',gold_boots,{'gold':('metal',[215,190,131],.11,1),'goldglitter':('glitter',[204,187,153],.43,1),'white':('paper',[234,230,216],.53,0)},'Cam %100 · Altın rengi/Beyaz',[9.5,7,None],0),
('1299157026','Beyaz altın eldiven biçimli cam yılbaşı süsü',mitten,{'white':('paper',[231,229,212],.62,0),'gold':('metal',[201,177,111],.19,1),'goldglitter':('glitter',[192,167,104],.43,1)},'Cam %100 · Beyaz/Altın rengi',[9.5,7,None],1),
('1354994003','Dokulu altın cam yılbaşı süsü',textured_gold,{'gold':('glitter',[212,197,164],.25,1),'goldglitter':('glitter',[218,203,171],.37,1),'white':('paper',[238,236,224],.59,0)},'İç kısım Cam %100 · Altın rengi',[None,None,None],1),
('1355087003','Ren geyiği ve ladinli saydam cam küre',lambda:globe('reindeer'),{'glass':('clear',[245,248,249],.06,0),'silver':('metal',[202,205,200],.15,1),'snow':('paper',[237,237,228],.78,0),'pine':('paper',[27,59,43],.78,0),'brown':('paper',[77,51,35],.64,0),'antler':('metal',[67,47,33],.57,0)},'Cam %60 · Akrilik %40 · Saydam/Beyaz/Kahverengi/Koyu yeşil',[None,None,None],1),
('1355087002','Karlı ev ve ladinli saydam cam küre',lambda:globe('house'),{'glass':('clear',[245,248,249],.06,0),'silver':('metal',[202,205,200],.15,1),'snow':('paper',[237,237,228],.78,0),'pine':('paper',[27,59,43],.78,0),'house':('metal',[174,133,62],.39,0)},'Cam %60 · Akrilik %40 · Saydam/Beyaz/Koyu bej/Koyu yeşil',[None,None,None],1)]
for sku,title,fn,mats,label,hwd,primary in entries:
 refs=[q for q in json.loads((A.R/'original-image-masters.json').read_text())if q['sku']==sku];A.SPECS[sku]={'name':title,'dims':[1,1,1],'derive_dimensions':True,'hwd':hwd,'build':fn,'estimated':['unlabelled_depth_cm','cap_and_suspension_dimensions_cm','local_cast_or_miniature_geometry','individual_3_to_5_cm_range_assignment'if sku=='1359291003'else'local_surface_relief'], 'label':label,'color':label.split(' · ')[-1],'semantics':'Aynı SKU’nun resmî fiziksel ölçü ankrajı aynen korunur; etiketsiz eksen, askı ve yerel biçim/yüzey ayrıntıları kendi özgün fotoğraflarından yorumlanmıştır. Toplam askılı veya set sergileme zarfı resmî ürün ölçüsü değildir.','materials':mats,'primary_hash':Path(refs[primary]['path']).stem.split('-')[-1]}
if __name__=='__main__':
 for pid in sys.argv[1:]or[q[0]for q in entries]:A.build(pid)
