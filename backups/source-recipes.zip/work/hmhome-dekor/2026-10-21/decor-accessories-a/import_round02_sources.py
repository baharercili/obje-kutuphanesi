"""Append genuine new parent PDP captures for the26 pending source cards only.

No frozen SKU or existing original-master record is altered. Network reads are only
observed official image URLs, without custom headers/proxies or generated URLs.
"""
from pathlib import Path
import sys,json,hashlib,copy,concurrent.futures,re
sys.dont_write_bytecode=True
import prepare_sources as S
R=S.R;OUT=R/'source-round-02'
def collect():
 seeds={e['product_code']:e for e in json.loads((R/'selected-category-products.json').read_text())['products']};queue=json.loads((R/'pending-browser-queue.json').read_text());data=json.loads((R/'source-inventory.json').read_text());records={e['sku']:e for e in data};imports=[]
 frozen={e['sku']for e in json.loads((R/'frozen-all58-manifest.json').read_text())}if(R/'frozen-all58-manifest.json').exists()else set()
 for target in queue:
  sku=target['sku']
  if sku in frozen:continue
  path=R.parent/'pdp-observed'/(sku+'.json')
  if not path.exists():continue
  raw=json.loads(path.read_text());previous=records.get(sku);checksum=S.sha(path)
  if not raw.get('identity_verified')or raw.get('url')!=seeds[sku]['url']:continue
  if previous and checksum==previous.get('parent_capture_sha256',previous.get('source_observation_sha256')):continue
  assert raw['sku']==sku
  folder=OUT/'raw';folder.mkdir(parents=True,exist_ok=True);snapshot=folder/(sku+'-'+checksum[:12]+'.json')
  if snapshot.exists():assert S.sha(snapshot)==checksum
  else:snapshot.write_bytes(path.read_bytes())
  q=copy.deepcopy(raw);dims,labels=S.dimension_evidence(q.get('description',''));q.update(source_market='tr_tr',source_gallery_market='tr_tr',official_source_url=q['url'],parent_capture_sha256=checksum,source_observation_file=str(snapshot),source_observation_sha256=checksum,source_evidence_files=[str(snapshot)],official_measurements=dims,official_measurement_labels=labels,official_measurement_ranges=[],seed_title=seeds[sku]['title'])
  selector=q.get('size_selector_observed',{});anchor=selector.get('numeric_anchor',{})
  if anchor.get('axis')=='diameter'and anchor.get('unit')=='cm'and isinstance(anchor.get('value'),(int,float)):
   q['official_measurements']['diameter_cm']=[float(anchor['value'])];q['official_measurement_labels'].append(selector.get('text',''));q['source_size_pointer']=str(snapshot)+'#size_selector_observed';q['dimension_source_url']=q['url']
  match=re.search(r'yaklaşık\s*(\d+(?:[.,]\d+)?)\s*[–-]\s*(\d+(?:[.,]\d+)?)\s*cm',q.get('description',''),re.I)
  if match:q['official_measurement_ranges']=[{'axis':'per_piece_height_or_overall_length_cm','minimum':float(match[1].replace(',','.')),'maximum':float(match[2].replace(',','.')),'approximate':True,'meaning':'Manufacturer approximate range depending on design; individual assignment is a photo interpretation.','source_url':q['url'],'transcription':match[0]}]
  if not(dims or q['official_measurement_ranges'])and previous and(previous.get('official_measurements')or previous.get('official_measurement_ranges')):
   q.update(official_measurements=previous.get('official_measurements',{}),official_measurement_labels=previous.get('official_measurement_labels',[]),official_measurement_ranges=previous.get('official_measurement_ranges',[]),source_market=previous.get('source_market','tr_tr'),dimension_source_url=previous.get('official_source_url',previous['url']),source_size_pointer=previous['source_observation_file']+'#description');q['source_evidence_files'].append(previous['source_observation_file'])
  records[sku]=q;imports.append({'sku':sku,'parent_capture_sha256':checksum,'snapshot':str(snapshot),'dimension_anchor':bool(q['official_measurements']or q['official_measurement_ranges']),'photos':S.selected_photos(q,seeds[sku])})
 if imports:
  old_order=[q['sku']for q in data];S.dump(R/'source-inventory.json',[records[k]for k in old_order]+[q for k,q in records.items()if k not in old_order])
 OUT.mkdir(exist_ok=True);log=OUT/'capture-imports.json';history=json.loads(log.read_text())if log.exists()else[];seen={(q['sku'],q['parent_capture_sha256'])for q in history};S.dump(log,history+[q for q in imports if(q['sku'],q['parent_capture_sha256'])not in seen]);return imports
def download(imports):
 imports=json.loads((OUT/'capture-imports.json').read_text())
 masters=json.loads((R/'original-image-masters.json').read_text());seen={(q['sku'],q['url'])for q in masters};todo=[p for q in imports for p in q['photos']if(p['sku'],p['url'])not in seen];done=[];errors=[]
 with concurrent.futures.ThreadPoolExecutor(max_workers=3)as pool:
  pending={pool.submit(S.download,p):p for p in todo}
  for future in concurrent.futures.as_completed(pending):
   try:done.append(future.result())
   except Exception as e:errors.append(dict(pending[future],error=str(e)))
 order={(p['sku'],p['url']):i for i,p in enumerate(todo)};done.sort(key=lambda q:order[(q['sku'],q['url'])]);S.dump(R/'original-image-masters.json',masters+done);S.dump(OUT/'download-errors.json',errors);print('New immutable exact-SKU masters:',len(done),'unavailable observed URLs:',len(errors))
if __name__=='__main__':
 imports=collect();print('Genuine new own-SKU parent captures:',len(imports),[q['sku']for q in imports])
 if '--download'in sys.argv:download(imports)
