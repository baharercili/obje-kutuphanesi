from pathlib import Path
import sys,math,json
sys.dont_write_bytecode=True
import numpy as np
from PIL import Image,ImageDraw,ImageFont
import build_accessories as A
import build_ornaments as O
B=A.B;T=math.tau
def puff_star():
 n=240;radial=24;v=[];uv=[];f=[];rings=[]
 for side in[1,-1]:
  center=len(v);v.append((0,0,side*.0035));uv.append((.5,.5));rr=[]
  for j in range(1,radial+1):
   rho=j/radial;ring=[]
   for k in range(n):
    segment=k//24;t=(k%24)/24;a=math.pi/2+T*segment/10;b=math.pi/2+T*(segment+1)/10;ra=.045 if segment%2==0 else .017;rb=.017 if segment%2==0 else .045
    x=(1-t)*ra*math.cos(a)+t*rb*math.cos(b);y=(1-t)*ra*math.sin(a)+t*rb*math.sin(b);z=side*(.00020+.00330*math.sqrt(max(0,1-rho*rho)));ring.append(len(v));v.append((rho*x,rho*y,z));uv.append((v[-1][0]/.09+.5,v[-1][1]/.09+.5))
   rr.append(ring)
  for k in range(n):f.append((center,rr[0][k],rr[0][(k+1)%n]))
  for a,b in zip(rr,rr[1:]):
   for k in range(n):q=(k+1)%n;f.extend([(a[k],b[k],a[q]),(a[q],b[k],b[q])])
  rings.append(rr[-1])
 for k in range(n):q=(k+1)%n;a=rings[0];b=rings[1];f.extend([(a[k],b[k],a[q]),(a[q],b[k],b[q])])
 parts=[A.raw('smooth-puffed-five-point-chrome-star','chrome',v,f,uv),O.eye('small-star-hanger-eye','chrome',(0,.047,0),.002),O.ribbon_loop('cream-velvet-star-loop','velvet',(0,.049,0),.045,.004)]
 return parts,['Smoothly puffed five-point silver metal star with tapered curved rays, real front/back thickness and polished profile','Separate small metal hanging eye and beige flat velvet loop'],{'source_axis_ambiguity':'Manufacturer gives approximately8–10 cm depending on design without a labelled axis. A9 cm body envelope is a declared estimate within that range, never an official exact dimension.'}
def candy():
 parts=[O.sphere('puffed-polished-candy-centre','chrome',.020,(0,0,0),scale=(1,.90,.56),n=128)]
 for sign in[-1,1]:
  profile=[(.003,.018),(.003,.023),(.004,.027),(.010,.038),(.015,.048),(.0146,.048),(.0096,.038),(.0036,.027),(.0026,.023),(.0026,.018)];g=B.lathe('hollow-pleated-twisted-foil-end-'+str(sign),'chrome',profile,128,True,ellipse=.35)
  vv=[]
  for x,y,z in g['_vertices']:
   a=math.atan2(z/.35,x);q=max(0,(y-.023)/.025);pleat=1+q*(.16*math.cos(8*a+q*.75)+.08*math.sin(13*a-q*4));vv.append((sign*(y+.0009*q*math.sin(5*a+q*3)),x*pleat,z*pleat+.0014*q*math.sin(3*a+q*5)))
  g['_vertices']=vv;parts.append(g)
 parts+=[O.eye('silver-candy-hanger-eye','chrome',(0,.020,0),.002),O.ribbon_loop('white-velvet-candy-loop','velvet',(0,.023,0),.047,.004)]
 return parts,['Rounded chrome centre and two separate genuinely hollow flared wrapper ends','Eight real longitudinal foil pleats on each twisted end; asymmetric subtle depth, real hanger and velvet loop'],{'source_axis_ambiguity':'Official approximately8–10 cm varies by design without an explicit axis. The candy’s9.6 cm horizontal body length is a photo-scaled interpretation within that range.'}
def jewel(name,c,r=.00064):
 p=B.lathe(name,'crystal',[(0,0),(r,.00005),(r,.0003),(r*.52,.00065),(0,.0008)],8,False);p['_vertices']=[(c[0]+x,c[1]+z,c[2]+y)for x,y,z in p['_vertices']];p['_flat_normals']=True;return p
def rhinestone_bow():
 parts=[];paths=[]
 for sign in[-1,1]:
  points=[]
  for a in np.linspace(0,T,121)[:-1]:
   u=.018*math.cos(a);v=.0125*math.sin(a);rot=sign*.45;points.append((sign*.018+u*math.cos(rot)-v*math.sin(rot),.054+u*math.sin(rot)+v*math.cos(rot),.0005*math.sin(a)))
  paths.append((points,True))
 for sign in[-1,1]:
  points=[]
  for t in np.linspace(0,1,90):points.append((sign*(.001+.022*t-.005*math.sin(math.pi*t)),.045-.044*t,.0010*math.sin(math.pi*t)))
  paths.append((points,False))
 for k,(pts,closed)in enumerate(paths):
  parts.append(B.tube('actual-open-rhinestone-bow-ribbon-'+str(k),'chrome',pts,.00035,.0032,8,closed,guide=[0,0,1]));p=np.array(pts)
  for j in range(0,len(p),3):
   tang=p[(j+1)%len(p)]-p[(j-1)%len(p)];tang/=np.linalg.norm(tang);cross=np.cross(tang,[0,0,1])
   for row in[-1,0,1]:c=p[j]+cross*row*.0016+np.array([0,0,.0004]);parts.append(jewel('separate-faceted-rhinestone-'+str(k)+'-'+str(j)+'-'+str(row),c))
 parts.append(B.box('small-ribbon-centre-knot','chrome',.009,.007,.0012,(0,.044,.0008)))
 for j in range(4):
  for i in range(5):parts.append(jewel('knot-rhinestone-'+str(j)+'-'+str(i),((i-2)*.0016,.0415+j*.0016,.0015)))
 vv=np.concatenate([p['_vertices']for p in parts]);lo=vv.min(0);hi=vv.max(0)
 for p in parts:p['_vertices']=[((x-(lo[0]+hi[0])/2)*.073/(hi[0]-lo[0]),(y-lo[1])*.073/(hi[1]-lo[1]),z)for x,y,z in p['_vertices']]
 parts.append(O.ribbon_loop('thin-silver-bow-cord','chrome',(0,.074,0),.040,.0006))
 return parts,['Two true open bow loops, curved split tails and separate central knot','Hundreds of individually faceted transparent rhinestones in three rows follow actual ribbon geometry','7.3 cm official body width and height; cord length and body depth photo-scaled'],{'piece_dimensions_cm':{'width':7.3,'height':7.3},'source_axis_ambiguity':'The7.3×7.3 cm anchor is assigned to the bow body; unlabelled hanging cord is explicitly interpreted.'}
def champagne_pair():
 parts=[];x=-.035
 parts.append(B.lathe('silver-champagne-bottle-profile','silver',[(0,0),(.009,0),(.011,.003),(.011,.041),(.010,.048),(.004,.055),(.0035,.063),(.004,.066),(.0038,.070),(0,.070)],128,False,offset=(x,0,0)))
 parts.append(B.lathe('silver-glitter-bottle-lower-band','glitter',[(.0111,.004),(.0111,.022),(.0113,.022),(.0113,.004)],96,True,offset=(x,0,0)));parts.append(B.lathe('silver-glitter-shoulder','glitter',[(.0102,.045),(.0094,.051),(.0045,.056),(.0047,.056),(.0096,.051),(.0104,.045)],96,True,offset=(x,0,0)));parts.append(B.lathe('printed-celebrate-label','label',[(.01115,.023),(.01115,.040),(.0113,.040),(.0113,.023)],128,True,offset=(x,0,0)))
 parts+=[O.eye('bottle-eye','silver',(x,.072,0),.0016),O.ribbon_loop('bottle-thin-cord','silver',(x,.074,0),.042,.00055)]
 x=.035
 parts.append(B.lathe('true-hollow-coupe-bowl','glitter',[(.003,.039),(.010,.041),(.019,.049),(.021,.058),(.0202,.058),(.0182,.050),(.009,.042),(.0022,.040)],144,True,offset=(x,0,0)));parts.append(B.cylinder('clear-slender-coupe-stem','glass',.0015,.006,.040,offset=(x,0,0)));parts.append(B.lathe('clear-coupe-foot','glass',[(0,0),(.015,0),(.016,.001),(.014,.003),(.002,.006),(0,.006)],96,False,offset=(x,0,0)));parts+=[O.eye('coupe-small-eye','silver',(x+.010,.059,0),.0015),O.ribbon_loop('coupe-thin-cord','silver',(x+.010,.061,0),.042,.00055)]
 return parts,['Distinct70 mm bottle and smaller hollow champagne coupe with real clear stem/foot','Own LET’S CELEBRATE label, silver glitter bands, separate top eyes and thin hanging cords','Single two-piece product SKU; bottle/coupe widths, glass height and display placement are explicit interpretations'],{'set_quantity':2,'piece_dimensions_cm':{'source_maximum_height':7},'source_axis_ambiguity':'Official height7 cm has no per-piece label. It is assigned to the taller bottle by photograph; coupe height is estimated.'}
def gondola():
 p=[];w=.07;d=.042
 p.append(A.capped('gondola-rounded-blown-glass-glitter-lower-cabin','glitter',[(A.outline(w*.80,d*.83),.001),(A.outline(w*.89,d*.92),.004),(A.outline(w,d),.037),(A.outline(w*.98,d*.98),.042)]))
 for x in np.linspace(-.030,.030,19):p.append(B.tube('physical-fine-glitter-gold-lower-cabin-rib-'+str(x),'glitter',[(x,.006,.0200),(x,.039,.0210)],.0004,.0004,6,False,guide=[0,0,1]))
 for sx in[-1,1]:
  for sz in[-1,1]:p.append(B.tube('four-tapered-gold-window-pillars-'+str(sx)+'-'+str(sz),'gold',[(sx*w*.48,.041,sz*d*.48),(sx*w*.40,.085,sz*d*.40)],.0016,.0016,8,False,guide=[0,1,0]))
 for sz in[-1,1]:
  p.append(B.box('translucent-broad-gondola-window-'+str(sz),'glass',.055,.038,.0008,(0,.063,sz*d*.43)))
  for x in[-.018,0,.018]:p.append(B.box('thin-front-window-divider-'+str(sz)+'-'+str(x),'gold',.0012,.041,.0012,(x,.063,sz*d*.44)))
 p.append(B.box('broad-gold-gondola-roof','gold',w*.90,.005,d*.90,(0,.088,0)));p.append(B.cylinder('gondola-roof-eye-base','gold',.005,.090,.095,n=48));p.append(O.eye('gondola-hanging-eye','gold',(0,.098,0),.002));p.append(O.ribbon_loop('gondola-thin-gold-hanger','gold',(0,.100,0),.080,.0006))
 return p,['Own cable-car cabin: gold/glitter lower box, four tapered posts, broad translucent panes and front window mullions','Separate roof, raised roof eye base and fine gold hanger','Hidden cabin depth and local construction profiles are explicitly inferred from the available exact-SKU front photograph'],{'piece_dimensions_cm':{'width':7,'height':9.5},'source_axis_ambiguity':'Official W7 H9.5 cm is used as cabin-body anchor; roof eye/cord inclusion is not explicit.','limited_gallery':True,'quality_limitations':['Only the official source-card front photo was accessible; rear and side profiles are interpretations.']}
def beanie():
 p=[];profile=[(.031,0),(.035,.002),(.035,.010),(.033,.013)]
 for t in np.linspace(0,1,50)[1:]:profile.append((.032*math.sqrt(max(0,1-t*t)),.012+.052*t))
 profile[-1]=(0,.064);profile.append((0,.0625))
 for t in np.linspace(1,0,50)[1:]:profile.append((.0305*math.sqrt(max(0,1-t*t)),.012+.0505*t))
 profile.extend([(.030,0)]);p.append(B.lathe('hollow-blown-glass-beanie-and-rolled-cuff','gold',profile,144,True))
 for k in range(18):
  a=T*k/18;pts=[]
  for t in np.linspace(0,.98,75):r=.0322*math.sqrt(1-t*t);aa=a+.04*math.sin(math.pi*t);pts.append((r*math.cos(aa),.012+.052*t,r*math.sin(aa)))
  p.append(B.tube('raised-knitted-gold-glass-rib-'+str(k),'glitter',pts,.0008,.0008,6,False,guide='radial'))
 for y in[.0025,.0055,.0085]:p.append(B.tube('rolled-cuff-welt-'+str(y),'gold',[(.0352*math.cos(a),y,.0352*math.sin(a))for a in np.linspace(0,T,145)[:-1]],.0008,.0008,8,True))
 p.append(O.sphere('soft-rust-coloured-pompom-core','pom',.012,(0,.079,0),n=64));rng=np.random.default_rng(1299157028)
 for k in range(420):
  a=rng.uniform(0,T);h=rng.uniform(-1,1);n=np.array([math.sqrt(1-h*h)*math.cos(a),h,math.sqrt(1-h*h)*math.sin(a)]);c=np.array([0,.079,0]);tangent=np.cross(n,[0,1,0]);pts=[c+n*(.011+.004*t)+tangent*(.0007*math.sin(T*t*1.4+k))for t in np.linspace(0,1,12)];p.append(B.tube('separate-rust-pompom-fibre-'+str(k),'pom',pts,.00012,.00012,5,False,guide=[0,1,0]))
 vv=np.concatenate([g['_vertices']for g in p]);lo=vv.min(0);hi=vv.max(0)
 for g in p:g['_vertices']=[(x*.070/(hi[0]-lo[0]),(y-lo[1])*.095/(hi[1]-lo[1]),z*.070/(hi[2]-lo[2]))for x,y,z in g['_vertices']]
 p.append(O.ribbon_loop('thin-gold-beanie-hanger','gold',(0,.096,0),.070,.0006));return p,['Hollow polished gold glass beanie with true turned cuff, three raised welts and18 separate curved knit ribs','Rust pompom has a soft rounded core and420 individual closed fine fibres','Pompom composition is not inferred as official material; visible surface and depth are photo interpretations'],{'piece_dimensions_cm':{'width':7,'height':9.5},'source_axis_ambiguity':'Official7×9.5 cm is assigned to the body including pompom; cord excluded as a photo-scaled addition.','limited_gallery':True,'quality_limitations':['Only official source-card front accessible. Rear surface and depth are explicitly interpreted.']}
_material=A.material
def material(pid,key,kind,rgb,rough=.4,metal=0):
 bank,m=_material(pid,key,'metal'if kind in['label','crystal']else kind,rgb,rough,metal)
 if kind=='label':
  image=Image.new('RGB',(2048,2048),(191,192,188));draw=ImageDraw.Draw(image);font=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',110)
  for cx in[512,1536]:draw.multiline_text((cx,1024),"LET’S\nCELEBRATE",font=font,anchor='mm',align='center',fill=(60,63,60),spacing=35)
  image.save(bank/m['baseColorTexture'],optimize=True)
 if kind=='crystal':m.update(transmission=.65,ior=1.50,thickness=.0008)
 return bank,m
A.material=material
items=[
 ('1354993003','Kabarık metal yıldız yılbaşı süsü',puff_star,'Gümüş rengi metal',{'chrome':('metal',[205,206,202],.08,1),'velvet':('paper',[228,219,195],.62,0)}),
 ('1354993001','Şeker biçimli metal yılbaşı süsü',candy,'Gümüş rengi metal · Krem kadife',{'chrome':('metal',[205,206,202],.08,1),'velvet':('paper',[228,219,195],.62,0)}),
 ('1354996001','Taşlı fiyonk biçimli yılbaşı süsü',rhinestone_bow,'Gümüş renkli metal · Şeffaf dekoratif taşlar',{'chrome':('metal',[187,189,184],.17,1),'crystal':('crystal',[235,237,234],.09,0)}),
 ('1355050001','2’li şampanya temalı cam yılbaşı süsü',champagne_pair,'Cam · Gümüş rengi · Sim detay',{'silver':('metal',[202,204,200],.10,1),'glitter':('metal',[194,196,192],.43,1),'glass':('glass',[246,247,240],.06,0),'label':('label',[190,191,187],.35,1)}),
 ('1299157029','Teleferik biçimli cam yılbaşı süsü',gondola,'Cam · Altın rengi · Sim detay',{'gold':('metal',[198,161,80],.13,1),'glitter':('metal',[189,151,67],.44,1),'glass':('glass',[244,243,230],.11,0)}),
 ('1299157028','Ponponlu bere biçimli cam yılbaşı süsü',beanie,'Cam · Altın rengi · Pas rengi ponpon',{'gold':('metal',[199,165,87],.12,1),'glitter':('metal',[191,151,64],.40,1),'pom':('paper',[149,70,25],.83,0)})]
for sku,name,builder,label,mats in items:
 A.SPECS[sku]={'name':name,'dims':[1,1,1],'hwd':[None,None,None],'build':builder,'derive_dimensions':True,'estimated':['hanging_loop_height_cm','unlabelled_or_range_axes_cm','depth_cm','local_surface_profiles'],'label':label,'color':label,'semantics':'Aynı gerçek SKU’nun official_measurements / official_measurement_ranges ankrajı aynen korunur. Resmî etikette bulunmayan eksenler, askı dahil toplam ölçüler ve yerel biçimler fotoğraf yorumudur; resmî kesin ölçü değildir.','materials':mats}
_gondola=gondola
def gondola_exact_width():
 p,f,e=_gondola();v=np.concatenate([g['_vertices']for g in p]);factor=.070/(v[:,0].max()-v[:,0].min())
 for g in p:g['_vertices']=[(x*factor,y,z)for x,y,z in g['_vertices']]
 return p,f,e
A.SPECS['1299157029']['build']=gondola_exact_width
if __name__=='__main__':
 for sku in sys.argv[1:]or[x[0]for x in items]:A.build(sku)
