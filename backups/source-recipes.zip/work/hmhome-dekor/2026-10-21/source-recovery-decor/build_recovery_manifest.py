from pathlib import Path
import json,re,hashlib,urllib.request
from PIL import Image,ImageOps,ImageDraw,ImageFont
R=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
targets=json.loads((R/'target-23.json').read_text())['targets'];ids={e['sku']for e in targets};sources=json.loads((R/'cached-primary-records.json').read_text());sources={s['sku']:s['official_sources']for s in sources};found={sku:[]for sku in ids};rejected=[]
for f in sorted(R.glob('*.json')):
 if f.name in['target-23.json','cached-primary-records.json','manifest.json']:continue
 try:data=json.loads(f.read_text())
 except Exception:continue
 if not isinstance(data,dict)or'content'not in data:continue
 text='\n'.join(c['text']for c in data['content']if c['type']=='text')
 for section in text.split('--------------------------------------------------------------------------------'):
  source=re.search(r'https://www2\.hm\.com/[^\s)]+productpage\.(\d{10})\.html',section);image=re.search(r'Image URL:\s*(https://[^\s#]+)',section)
  if not(source and image):continue
  sku=source.group(1);url=image.group(1)
  if sku not in ids or not url.startswith('https://image.hm.com/'):
   rejected.append(dict(source_url=source.group(0),source_sku=sku,image_url=url,reason='Not an exact requested SKU on the official image.hm.com asset host.'));continue
  if url not in[p['url']for p in found[sku]]:found[sku].append(dict(url=url,source_page_url=source.group(0),source_evidence_file=str(f),identity_binding='Exact ten-digit SKU in the official PDP URL returned with this image.',image_search_caption=section.split('Image URL:',1)[1].split('#',1)[-1].strip(),srcset_verbatim=None,entire_gallery_verified=False))
originals=R/'originals';originals.mkdir(exist_ok=True)
for sku,photos in found.items():
 for p in photos:
  out=originals/(sku+'-'+hashlib.sha256(p['url'].encode()).hexdigest()[:12]+'.jpg')
  if not out.exists():
   req=urllib.request.Request(p['url'],headers={'User-Agent':'Mozilla/5.0'})
   with urllib.request.urlopen(req,timeout=40)as response:payload=response.read()
   out.write_bytes(payload)
  im=Image.open(out);assert im.format=='JPEG';p.update(original_image=str(out),sha256=sha(out),pixels=list(im.size),original_bytes_unmodified=True)
products=[]
for e in targets:
 ss=sources[e['sku']];measure=[]
 for s in ss:
  lines=[line.strip()for line in s['text'].splitlines()if re.search(r'\d',line)and re.search(r'\bcm\b|inches|inch|[¼½¾] inch',line,re.I)]
  if lines:measure.append(dict(source_url=s['url'],source_market=s['url'].split('/')[3],verbatim_lines=lines,evidence_file=s['evidence_file']))
 photos=found[e['sku']]
 products.append(dict(sku=e['sku'],brand='H&M Home',title=e['title'],tr_url=e['url'],baseline_status=e['status'],baseline_official_image_count=e['official_image_count'],baseline_measurement_evidence_available=e['official_measurement_evidence_available'],status='exact_sku_image_recovered'if photos else'cached_text_only'if ss else'not_recovered_in_cache',official_sources=[dict(url=s['url'],evidence_file=s['evidence_file'],title=s['text'].splitlines()[0])for s in ss],measurement_evidence=measure,images=photos,scan_complete=False,limitations=['Search-image result binds exact official SKU and asset, but does not prove complete PDP gallery.','Cross-market official sources are labelled by source URL; they are not represented as newly captured Turkish DOM.','Unreported dimensions and colour variants are not inferred.']))
pending=[]
for sku in['1353729001','1355065003','1248654003','1214591007']:
 f=R/('anchor-'+sku+'.json');pending.append(dict(sku=sku,status='no_numeric_anchor_recovered',evidence_file=str(f),note='Exact SKU plus cm/diameter search returned no result. The broader cached tree skirt page only says Small; this is not a physical scale.'))
for sku,f in[('1354955002','focused-a-green-row.json'),('1299157027','focused-a-gold-boot.json')]:pending.append(dict(sku=sku,status='no_additional_exact_sku_gallery_recovered',evidence_file=str(R/f),note='Image results referenced different official product IDs; rejected rather than rebound to this SKU.'))
dump(R/'manifest.json',dict(brand='H&M Home',date='2026-10-22',scope='Bounded public-primary cache recovery for the 23 B pending_research source identities; parent later resumed normal browser capture, so duplicate B gallery research stopped.',source_file=str(R/'target-23.json'),target_source_cards=23,exact_sku_image_products=sum(bool(p['images'])for p in products),unique_exact_sku_images=sum(len(p['images'])for p in products),official_cached_text_products=sum(bool(p['official_sources'])for p in products),products=products,additional_checks=pending,rejected_different_sku_results=rejected,limitations=['No access-control bypass, cookies, account authentication or restricted API was used.','Direct web-reader cache misses and timeouts were recorded. Full galleries remain for parent browser capture.','Only actually returned image URLs were fetched; an imwidth was never added to a URL that lacked it.','No asset models or other agents files were changed.']))
photos=[(p['sku'],im)for p in products for im in p['images']]
if photos:
 canvas=Image.new('RGB',(len(photos)*500,800),'#efeee8');draw=ImageDraw.Draw(canvas);font=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',18)
 for k,(sku,p)in enumerate(photos):
  im=ImageOps.contain(Image.open(p['original_image']).convert('RGB'),(470,700),Image.Resampling.LANCZOS);canvas.paste(im,(k*500+(500-im.width)//2,50));draw.text((k*500+20,15),sku+' · '+str(p['pixels']),font=font,fill='black')
 canvas.save(R/'recovered-source-contact.png',optimize=True)
print('RECOVERY',len(products),'targets',len(photos),'exact-SKU original images',sum(bool(p['official_sources'])for p in products),'cached official source identities',flush=True)
