"""Locally integrate immutable H&M batches and every observed source card."""
from pathlib import Path
from urllib.parse import urlsplit
from collections import defaultdict
import argparse, copy, hashlib, importlib.util, json, re, shutil, sys

P=Path(__file__).resolve().parent
ROOT=P.parents[2]
SITE=ROOT/'sites/zarahome-vazo-kutuphanesi-final-378'
ZARA=ROOT/'work/zarahome-dekor/completeness-repair-2026-10-21'
CATEGORIES={'vases':('Vazolar','vazolar'),'candleholders':('Mumluk ve şamdanlar','mumluklar'),'trays':('Dekoratif tepsiler','tepsiler'),'decor_accessories':('Dekoratif aksesuarlar','aksesuarlar')}
def read(path): return json.loads(Path(path).read_text())
def write(path,value): Path(path).write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def rows(value):
    if isinstance(value,list):return value
    return next((value[k] for k in ['models','products','entries','records'] if isinstance(value.get(k),list)),[])
def readable(value):
    if not isinstance(value,str):return value
    try:value=value.encode('latin1').decode('utf8')
    except (UnicodeEncodeError,UnicodeDecodeError):pass
    value=re.sub(r'(?<=[A-Za-zÇĞİÖŞÜçğıöşü])(?=\d)',' ',value)
    value=re.sub(r'(?<=\d)(?=cm\b|mm\b|kg\b)',' ',value)
    return value.replace('üreticiCAD’si','üreticinin CAD dosyası')

def photos(items,title,primary=None):
    found={}
    for raw in items:
        if isinstance(raw,str):raw={'url':raw}
        if not isinstance(raw,dict):continue
        candidates=[]
        for part in (raw.get('srcset') or '').split(','):
            match=re.fullmatch(r'\s*(https://\S+)\s+(\d+)w\s*',part)
            if match:candidates.append((int(match[2]),match[1]))
        url=raw.get('url') or raw.get('currentSrc') or raw.get('src')
        if url:candidates.append((0,url))
        candidates=[(width,url) for width,url in candidates if urlsplit(url).scheme=='https' and urlsplit(url).hostname=='image.hm.com' and urlsplit(url).path.endswith('.jpg')]
        if not candidates:continue
        width,url=max(candidates)
        key=urlsplit(url).path
        if key in found and width<=found[key][0]:continue
        thumb=next((u for w,u in candidates if w==256),url)
        alt=readable(raw.get('alt','').removeprefix('Büyük resmi görüntüle: ')) or title
        found[key]=(width,dict(url=url,thumbnail_url=thumb,alt=alt))
    keys=list(found)
    if primary and urlsplit(primary).path in keys:
        key=urlsplit(primary).path;keys.remove(key);keys.insert(0,key)
    return [found[key][1] for key in keys]

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('manifests',nargs='*',help='Only reviewed, immutable manifest snapshots; defaults to approved-batches.json')
    parser.add_argument('--statuses',action='append',default=[])
    parser.add_argument('--photos',action='append',default=[])
    args=parser.parse_args()
    if not args.manifests:
        selection=read(P/'approved-batches.json')
        for item in selection['reviewed_batches']:assert sha(item['file'])==item['sha256'],'Frozen batch changed: '+item['file']
        args.manifests=[item['file'] for item in selection['reviewed_batches']]
        args.statuses=[str(P/file) for file in selection.get('statuses',[])]+args.statuses
        args.photos=[str(P/file) for file in selection.get('photos',[])]+args.photos
    assert args.manifests
    # The Zara and Hipicon source catalogs are a frozen, independent baseline.
    frozen=read(P/'zara-local-baseline/lock.json')
    for item in frozen['files']:
        if item['file']!='model-manifest.json':assert sha(SITE/item['file'])==item['sha256'],item['file']
    inventory=read(P/'observed-category-inventory.json')
    source_by_sku={};category_by_sku={};observed_categories={}
    for category in inventory['categories']:
        observed_categories[category['id']]=category
        for card in category.get('products',[]):
            sku=card['product_code'];assert sku not in source_by_sku,sku
            source_by_sku[sku]=card;category_by_sku[sku]=category
    assert len(source_by_sku)==166
    entries=[];batch_evidence=[]
    for file in args.manifests:
        path=Path(file).resolve();batch=rows(read(path));entries+=batch
        batch_evidence.append(dict(path=str(path),sha256=sha(path),models=len(batch)))
    assert len({e['id'] for e in entries})==len(entries),'Duplicate model IDs'
    assert {e['sku'] for e in rows(read(P/'vases/manifest.json'))} <= {e['sku'] for e in entries},'Keep all five frozen vases'
    for entry in entries:
        assert entry['sku'] in source_by_sku,entry['sku']
        assert entry['brand']=='H&M Home' and entry['id'].startswith('hm-')
        assert re.fullmatch(r'\d{10}',entry['sku']) and entry['url']=='https://www2.hm.com/tr_tr/productpage.'+entry['sku']+'.html'
        assert sha(entry['glb_path'])==entry['sha256'] and Path(entry['glb_path']).stat().st_size==entry['bytes']
        assert 12<entry['bytes']<=96*1024*1024
    spec=importlib.util.spec_from_file_location('zara_quality_helpers',ZARA/'integrate_repair.py')
    sys.path.insert(0,str(ZARA));quality=importlib.util.module_from_spec(spec);spec.loader.exec_module(quality)
    previous=read(P/'root-hmhome-independent-qa.json').get('checks',[])
    cached={(c['master']['id'],c['master']['sha256']):c for c in previous}
    checks=[cached.get((e['id'],e['sha256'])) or dict(master=quality.validate(e),topology=quality.audit(e)) for e in entries]
    write(P/'root-hmhome-independent-qa.json',dict(valid=True,models=len(entries),checks=checks))
    # Good public captures only. An Access Denied page never supplies product data.
    captures={}
    for path in list(P.glob('*-observed.json'))+list((P/'pdp-observed').glob('*.json')):
        value=read(path)
        if value.get('identity_verified') is True or (value.get('sku') in source_by_sku and value.get('photos') and 'Access Denied' not in value.get('title','')):
            sku=value.get('sku') or path.name.split('-')[0];captures[sku]=value
    status_by_sku={}
    for file in args.statuses:
        for status in rows(read(file)):
            sku=status.get('sku') or status.get('product_code')
            if sku in source_by_sku:status_by_sku[sku]=status
    extra_photos=defaultdict(list)
    for file in args.photos:
        for photo in rows(read(file)):
            if photo.get('sku') in source_by_sku:extra_photos[photo['sku']].append(photo)
    combined=read(P/'zara-local-baseline/model-manifest.json')
    catalog=[];by_sku=defaultdict(list)
    preview=copy.deepcopy(read(P/'zara-local-baseline/ui__preview.json'));preview.update(batchId='hmhome-obje-kutuphanesi',models=[])
    fields=['id','name','sku','brand','url','dimensions_cm','material_label','estimated_dimensions','size_source_kind','size_source_urls','source_market','scale_note','quality_status','quality_label','quality_note','estimated_axes','estimated_fields','scene_variants','default_scene_index','set_quantity','official_measurements','source_anomalies']
    for entry in entries:
        category=category_by_sku[entry['sku']];category_id=category['id'];label,slug=CATEGORIES[category_id]
        filename=entry['id']+'.glb';target=SITE/'model-source'/filename
        if not target.exists() or sha(target)!=entry['sha256']:shutil.copy2(entry['glb_path'],target)
        combined['models'].append(dict(id=entry['id'],name=entry['name'],filename=filename,accepted_filenames=[filename],bytes=entry['bytes'],sha256=entry['sha256'],key='models/'+entry['sha256']+'.glb'))
        record={key:entry[key] for key in fields if key in entry}
        for key in ['scale_note','quality_note']:
            if record.get(key):record[key]=readable(record[key])
        raw_photos=entry.get('source_images',[])+captures.get(entry['sku'],{}).get('photos',[])
        record.update(category=label,category_id=category_id,category_slug=slug,category_source_url=category['source_url'],glb_url='/models/'+filename+'?v='+entry['sha256'],reference_images=photos(raw_photos,entry['name'],entry.get('original_image_url')),reference_photo_scope='exact_product',reference_source_url=entry['url'],reference_observed_date='2026-10-21')
        assert record['reference_images'],entry['id']
        catalog.append(record);by_sku[entry['sku']].append(record)
        model={key:record[key] for key in ['id','name','sku','url','dimensions_cm','category','estimated_dimensions','size_source_kind','size_source_urls','source_market','quality_status','quality_label','quality_note','scene_variants','default_scene_index','set_quantity'] if key in record}
        notes=[record.get('scale_note'),record.get('quality_note')]
        model.update(materialLabel=entry['material_label'],source_notes=list(dict.fromkeys(note for note in notes if note)),materials={},meshes=[])
        preview['models'].append(model)
    references=[];coverage=[]
    for category in inventory['categories']:
        if category['id'] not in CATEGORIES:continue
        label,slug=CATEGORIES[category['id']]
        current=[]
        for card in category.get('products',[]):
            sku=card['product_code'];ready=by_sku.get(sku,[]);status=status_by_sku.get(sku,{})
            title=ready[0]['name'] if ready else readable(card['title'])
            raw=card.get('images',[])+captures.get(sku,{}).get('photos',[])+status.get('source_images',[])+status.get('photos',[])+extra_photos.get(sku,[])
            refs=ready[0]['reference_images'] if ready else photos(raw,title,status.get('original_image_url'))
            state='ready' if ready else status.get('model_status',status.get('status','pending_model'))
            state={'pending_source':'pending_research','pending_gallery':'pending_research','pending_reference_views':'pending_research','pending_no_anchor':'pending_measurements','pending_measurements_or_source':'pending_research','ready_to_model':'pending_model','quality_review':'pending_model','in_progress':'pending_model'}.get(state,state)
            if state not in ['ready','pending_model','pending_measurements','pending_research']:state='pending_model'
            if not ready and state=='ready':state='pending_model'
            reason=status.get('pending_reason') or status.get('reason') or ('Modelleme ve görsel kontrol bekliyor.' if state=='pending_model' else 'Resmî ölçü bilgisi bekleniyor.' if state=='pending_measurements' else 'Ürün sayfası ve ölçüler doğrulanıyor.')
            record=dict(id='hm-source-'+sku,sku=sku,brand='H&M Home',name=title,url=card['url'],category=label,category_id=category['id'],category_slug=slug,reference_images=refs,reference_photo_scope='exact_product',model_status=state,model_ids=[r['id'] for r in ready],ready_model_variants=len(ready),status_note='Malzemeli GLB hazır.' if ready else readable(reason),observed_date='2026-10-21')
            if ready:
                record.update(model_url='/hmhome?model='+ready[0]['id']+'#koleksiyon',dimensions_cm=ready[0]['dimensions_cm'],material_label=ready[0]['material_label'])
                for key in ['quality_status','quality_label','quality_note']:
                    if ready[0].get(key):record[key]=ready[0][key]
                if record.get('quality_note'):record['status_note']+=' '+record['quality_note']
            elif status.get('dimensions_cm'):record['dimensions_cm']=status['dimensions_cm']
            current.append(record);references.append(record)
        coverage.append(dict(id=category['id'],slug=slug,label=label,source_url=category['source_url'],observed_source_cards=len(current),ready_source_cards=sum(r['model_status']=='ready' for r in current),ready_model_variants=sum(r['ready_model_variants'] for r in current),pending_source_cards=sum(r['model_status']!='ready' for r in current),scan_complete=True))
    assert len(references)==166 and len({r['sku'] for r in references})==166
    combined['model_count']=len(combined['models']);combined['total_bytes']=sum(e['bytes'] for e in combined['models'])
    assert combined['model_count']==1234+len(entries)
    write(SITE/'model-manifest.json',combined);write(SITE/'ui/hmhome-catalog.json',catalog);write(SITE/'ui/hmhome-preview.json',preview)
    sources=read(P/'category-navigation.json')
    for category in sources['categories']:
        live=observed_categories.get(category['id'])
        if live and live['scan_complete']:category.update(current_visible_category_count=live['official_visible_card_count'],count_status='live_browser_grid_complete')
    write(SITE/'ui/hmhome-sources.json',sources)
    ready_cards=len(by_sku);counts=dict(source_cards=166,ready_source_cards=ready_cards,ready_model_variants=len(entries),pending_source_cards=166-ready_cards,categories=4)
    write(SITE/'ui/hmhome-inventory.json',dict(brand='H&M Home',observed_date='2026-10-21',updated_date='2026-10-22',count_semantics='Dört kategorinin gözlenen ürün kartları; tüm H&M kataloğu değildir. Setlerin ayrı parçaları model sayısını artırabilir.',counts=counts,categories=coverage,products=references))
    template=(SITE/'ui/hmhome.html').read_text()
    template=re.sub(r'<strong data-hm-count>.*?</strong>|<strong>\d+</strong>',f'<strong data-hm-count>{len(entries)}</strong>',template,count=1)
    template=re.sub(r'hazır (?:boy ve renk varyantı|model varyantı)<br>\d+ kategori',f'hazır model varyantı<br>{len(set(e["category"] for e in catalog))} kategori',template)
    template=re.sub(r'data-results-count>.*?</span>',f'data-results-count>{len(entries)} model</span>',template)
    template=re.sub(r'data-coverage-note>.*?</p>','data-coverage-note>Hazır modeller burada. Dört kategorideki 166 kaynak ürünün tamamını ve bekleyen modelleri envanterde inceleyebilirsin.</p>',template,flags=re.S)
    template=re.sub(r'<a class="reference-catalog-link" data-category-inventory.*?</a>','<a class="reference-catalog-link" data-category-inventory href="/hmhome-envanter">Bu kategorinin tüm ürünleri ve bekleyenler ↗</a>',template)
    template=template.replace('Şimdilik yalnız vazolar kategorisi bu bölümün hazır model sayısına dahil.','Dört kategorideki kaynak ürünlerin tamamı envanterde tutuluyor; hazır model sayısı doğrulanan dosyalardan hesaplanıyor.')
    template=re.sub(r'<meta name="description"[^>]+>','<meta name="description" content="H&M Home ürünlerinin orijinal fotoğrafları, malzemeli 3D modelleri ve 166 ürünlük kaynak envanteri.">',template)
    (SITE/'ui/hmhome.html').write_text(template)
    recipes=SITE/'recipes/hmhome-2026-10-21';recipes.mkdir(parents=True,exist_ok=True)
    for filename in ['observed-category-inventory.json','category-navigation.json','root-hmhome-independent-qa.json','integrate_expansion.py']:shutil.copy2(P/filename,recipes/filename)
    if (P/'approved-batches.json').exists():shutil.copy2(P/'approved-batches.json',recipes/'approved-batches.json')
    write(recipes/'integrated-batches.json',batch_evidence)
    report=dict(valid=True,zara_variants_preserved=1234,hipicon_photo_records_preserved=19,hmhome_products=ready_cards,hmhome_model_variants=len(entries),hmhome_source_inventory=166,total_model_variants=combined['model_count'],cloud_published=False,local_url='http://127.0.0.1:18937/hmhome',batches=batch_evidence)
    write(P/'integration-report.json',report)
    sequence=read(ZARA/'user-work-sequence.json');sequence.update(updated_date='2026-10-22',local_ready_models=combined['model_count'],current_stage='H&M Home full observed categories expansion in progress')
    sequence['hmhome'].update(status='expansion_in_progress_locally',ready_model_variants=len(entries),ready_products=ready_cards,retained_source_cards=166,inventory_url='http://127.0.0.1:18937/hmhome-envanter')
    sequence['integration_order']='Preserve frozen Zara1234 baseline; integrate reviewed immutable H&M manifests with integrate_expansion.py.'
    write(ZARA/'user-work-sequence.json',sequence)
    print(json.dumps(report,ensure_ascii=False))

if __name__=='__main__':main()
