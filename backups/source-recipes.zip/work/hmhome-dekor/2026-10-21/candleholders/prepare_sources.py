"""Read current official captures, retain exact observed JPEGs, never edit originals."""
from pathlib import Path
import json,re,hashlib,urllib.request,io,concurrent.futures
from PIL import Image,ImageOps,ImageDraw,ImageFont
R=Path(__file__).resolve().parent;P=R.parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
cat=json.loads((R/'official-category-34-cards.json').read_text());records=[];selected=[];missing=[]
for card in cat['products']:
 pid=card['product_code'];candidates=[P/'pdp-observed'/(pid+'.json'),P/(pid+'-observed.json'),R/'source-observed'/(pid+'.json')];source=next((p for p in candidates if p.exists()),None)
 if source:
  q=json.loads(source.read_text());q.update(sku=pid,brand='H&M Home',source_observation_file=str(source),source_observation_sha256=sha(source),category_card=card);records.append(q);images=q.get('photos',q.get('images',[]))
 else:missing.append(dict(sku=pid,url=card['url'],title=card['title']));images=[]
 photos={}
 for im in images:
  choices=[]
  for entry in(im.get('srcset')or'').split(','):
   fields=entry.strip().split()
   if len(fields)==2 and re.match(r'https://image\.hm\.com/.+\.jpg\?',fields[0]):choices.append((int(fields[1].rstrip('w')),fields[0]))
  if im.get('url','').startswith('https://image.hm.com/')and'.jpg?'in im['url']:choices.append((int(re.search(r'imwidth=(\d+)',im['url']).group(1)),im['url']))
  for size,url in choices:
   base=url.split('?')[0]
   if base not in photos or size>photos[base]['observed_width']:photos[base]=dict(sku=pid,product_url=card['url'],url=url,alt=im.get('alt',''),observed_width=size,srcset_verbatim=im.get('srcset'),source_file=str(source))
 selected+=list(photos.values())
dump(R/'source-inventory.json',records);dump(R/'selected-official-images.json',selected);dump(R/'pending-source-captures.json',missing)
print('Observed PDPs',len(records),'/34; unique JPEGs',len(selected),flush=True)
def download(p):
 out=R/'originals';out.mkdir(exist_ok=True);path=out/(p['sku']+'-'+hashlib.sha256(p['url'].encode()).hexdigest()[:12]+'.jpg')
 if not path.exists():
  req=urllib.request.Request(p['url'],headers={'User-Agent':'Mozilla/5.0'});data=urllib.request.urlopen(req,timeout=40).read();Image.open(io.BytesIO(data)).verify();path.write_bytes(data)
 im=Image.open(path);p.update(path=str(path),sha256=sha(path),pixels=list(im.size),format=im.format,mode=im.mode,icc_profile_present=bool(im.info.get('icc_profile')),exif_orientation=im.getexif().get(274),original_bytes_unmodified=True);return p
if __name__=='__main__':
 with concurrent.futures.ThreadPoolExecutor(max_workers=4)as pool:done=list(pool.map(download,selected))
 dump(R/'original-image-masters.json',done)
 font=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',16)
 for start in range(0,len(done),12):
  panel=Image.new('RGB',(1600,1460),'#eeeae3');draw=ImageDraw.Draw(panel)
  for i,p in enumerate(done[start:start+12]):
   im=Image.open(p['path']);thumb=ImageOps.contain(im,(380,430),Image.Resampling.LANCZOS);x=i%4*400;y=i//4*480;panel.paste(thumb,(x+(400-thumb.width)//2,y+28));draw.text((x+8,y+4),Path(p['path']).name,font=font,fill='black')
  panel.save(R/f'source-contact-{start//12+1:02}.png',optimize=True)
 for q in records:print(q['sku'],q.get('description',q.get('text',''))[:1400],flush=True)
