"""Native 2K intrinsic material maps. Official photographs remain immutable references."""
from pathlib import Path
import hashlib,math,json
import numpy as np
from PIL import Image
R=Path(__file__).resolve().parent
T=math.tau
def bank(key,kind,color):
 out=R/'materials'/key;out.mkdir(parents=True,exist_ok=True);n=2048;rng=np.random.default_rng(int(hashlib.sha256(key.encode()).hexdigest()[:8],16));u=np.arange(n,dtype=np.float32)[None,:]/n;v=np.arange(n,dtype=np.float32)[:,None]/n
 def noise(k):
  a=rng.normal(size=(k,k)).astype(np.float32);a=np.tile(a,(3,3));im=Image.fromarray(a,'F').resize((n*3,n*3),Image.Resampling.BICUBIC);return np.asarray(im,dtype=np.float32)[n:2*n,n:2*n].copy()
 fine=rng.normal(size=(n,n)).astype(np.float32);cloud=noise(13)*.7+noise(47)*.3;grain=noise(337);rgb=np.array(color,dtype=np.float32)[None,None,:]+cloud[:,:,None]*1.2+fine[:,:,None]*.15;height=fine*.008+grain*.014;rough=np.full((n,n),.25,dtype=np.float32);metal=np.zeros((n,n),dtype=np.float32)
 if kind in['silver','gold']:
  rgb=np.array(color,dtype=np.float32)[None,None,:]+cloud[:,:,None]*1.0+grain[:,:,None]*.3;rough[:]=.19 if kind=='silver'else .22;rough+=grain*.012+np.sin(T*v*850)*.007;metal[:]=1;height=fine*.0015
 elif kind=='blackmetal':rough[:]=.43;rough+=grain*.02;rgb+=grain[:,:,None]*1.1;height+=grain*.03
 elif kind in['glass','bubbleglass','swirlglass']:
  rgb=np.full((n,n,3),255,dtype=np.float32);rough[:]=.045;rough+=grain*.001;height=fine*.0005
  if kind=='swirlglass':
   phase=T*(u*3+v**1.8*.9+.06*np.sin(v*T*2));vein=np.exp(-np.square(np.sin(phase)/.16));vein+=.4*np.exp(-np.square(np.sin(phase+.24)/.11));vein=np.clip(vein,0,1);rgb=np.array([235,228,212],np.float32)[None,None,:]+vein[:,:,None]*np.array([18,24,35]);clear=np.clip((.085-v)*65,0,1);rgb=rgb*(1-clear[:,:,None])+255*clear[:,:,None];trans=.35*(1-vein*.85)*(1-clear)+.98*clear;transrgb=np.repeat(np.clip(trans[:,:,None]*255,0,255).astype(np.uint8),3,2);Image.fromarray(transrgb,'RGB').save(out/f'{key}-transmission-2k.png',optimize=True);rough[:]=.08;rough+=vein*.025;height+=grain*.002
  if kind=='bubbleglass':
   relief=np.zeros((n,n),np.float32)
   for _ in range(110):
    xx=rng.integers(0,n);yy=rng.integers(0,n);rad=rng.uniform(3,11);dx=np.minimum(abs(np.arange(n)-xx),n-abs(np.arange(n)-xx));dy=abs(np.arange(n)-yy);relief+=np.exp(-(dx[None,:]**2+dy[:,None]**2)/(rad**2))*.8
   height+=relief;rough+=relief*.012
 elif kind=='marble':
  broad=noise(8);calcium=noise(31);micro=noise(139);rgb=np.array(color,dtype=np.float32)[None,None,:]+broad[:,:,None]*8+calcium[:,:,None]*5+micro[:,:,None]*2;lines=np.abs(np.sin(T*(u*2.4+v*3.5+cloud*.2+broad*.12)));vein=np.exp(-np.square(lines/.027))*(.3+.7*np.clip(calcium+.5,0,1));rgb-=vein[:,:,None]*np.array([30,47,52]);height=grain*.024+fine*.006;rough[:]=.30;rough+=micro*.02
 else:
  pin=(rng.random((n,n))>.997).astype(np.float32);rgb-=pin[:,:,None]*rng.uniform(2,9,(n,n,1));height+=pin*.018;rough[:]=.22;rough+=grain*.016
 dy,dx=np.gradient(height);normal=np.stack([-dx,-dy,np.ones_like(dx)],2);normal/=np.linalg.norm(normal,axis=2,keepdims=True);orm=np.stack([np.ones_like(rough)*255,np.clip(rough*255,8,245),metal*255],2).astype(np.uint8)
 for slot,data in[('albedo',np.clip(rgb,0,255).astype(np.uint8)),('normal',np.clip((normal+1)*127.5,0,255).astype(np.uint8)),('orm',orm)]:Image.fromarray(data,'RGB').save(out/f'{key}-{slot}-2k.png',optimize=True)
 mat=dict(baseColorFactor=[1,1,1,1],baseColorTexture=f'{key}-albedo-2k.png',normalTexture=f'{key}-normal-2k.png',metallicRoughnessTexture=f'{key}-orm-2k.png',normalScale=.35 if kind not in['glass','bubbleglass']else .08,metallic=1,roughness=1,doubleSided=False,alphaMode='OPAQUE',clearcoat=.4 if kind=='ceramic'else 0,clearcoatRoughness=.12,extras=dict(native_resolution=2048,intrinsic_material=True,photo_pixels_baked=False,baked_reflections=False,photo_guided_palette=True,pattern='Approximate local material; natural and handmade per-piece variations are not pixel-exact reproductions.'))
 if kind in['glass','bubbleglass','swirlglass']:mat.update(transmission=.98,ior=1.5,thickness=.003,attenuationColor=[q/255 for q in color],attenuationDistance=.045);mat['extras'].update(optical_parameters_estimated=True,real_transmission=True,nominal_ior=1.5)
 if kind=='swirlglass':mat.update(transmission=1,transmissionTexture=f'{key}-transmission-2k.png');mat['extras'].update(intrinsic_white_glass_flow=True,variable_physical_transmission=True)
 return out,mat
