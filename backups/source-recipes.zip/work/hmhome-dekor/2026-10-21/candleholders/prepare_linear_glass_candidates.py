"""Separate material candidates; the held eleven reviewed assets remain untouched."""
from pathlib import Path
import json,hashlib,copy,shutil
import build_candleholders as C
R=Path(__file__).resolve().parent;V=C.V
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def linear(v):
 s=v/255
 return s/12.92 if s<=.04045 else ((s+.055)/1.055)**2.4
held=json.loads((R/'glass-review-manifest.json').read_text());entries=[]
for original in held:
 if original['photo_specific_family']not in ['block','sphere_cube']:continue
 e=copy.deepcopy(original);old=Path(e['asset_dir']);out=R/'glass-linear-candidates'/e['id'];out.mkdir(parents=True,exist_ok=True)
 source=json.loads(Path(e['model_path']).read_text())
 for p in old.glob('*-2k.png'):shutil.copyfile(p,out/p.name)
 fam=e['photo_specific_family']
 for key,m in source['materials'].items():
  if not m.get('transmission'):continue
  m['extras'].update(optical_parameters_estimated=True,linear_colour_encoding=True)
  if fam=='block' and key=='accent':
   target=C.S[e['sku']]['accent'];m['baseColorFactor']=[linear(v)for v in target]+[1];m['attenuationColor']=[1,1,1]
   m['extras']['colour_approach']='Observed sRGB photo tint converted to linear glTF baseColorFactor; neutral volume absorption avoids applying the same tint twice.'
  elif fam=='sphere_cube':
   target=[190,31,44];m['baseColorFactor']=[1,1,1,1];m['attenuationColor']=[linear(v)for v in target];m['attenuationDistance']=.05
   m['extras']['colour_approach']='Neutral dielectric surface with source-photo sRGB tint converted to linear volume absorption over an estimated 50 mm optical path.'
 source['metadata']['optical_colour_note']='Cam yüzeyindeki renk katsayıları doğrusal glTF uzayındadır; fotoğraf renkleri sRGB dönüşümüyle yorumlanmıştır. Optik soğurma ve kalınlık üretici verisi değil, PBR tahminidir.'
 source['metadata']['candidate_revision']='linear-glass-v2'
 modelpath=out/'model.json';dump(modelpath,source)
 e.update(asset_dir=str(out),model_path=str(modelpath),glb_path=str(out/(e['id']+'.glb')),optical_colour_note=source['metadata']['optical_colour_note'],candidate_revision='linear-glass-v2',previous_candidate_sha256=original['sha256'])
 report=V.export_assets(modelpath,out,e['id']);path=Path(e['glb_path']);doc,binary=V.read_glb(path);doc['samplers']=[dict(magFilter=9729,minFilter=9987,wrapS=10497,wrapT=33071)]
 for t in doc.get('textures',[]):t['sampler']=0
 binary=V.M.embed_tangents(doc,binary);V.write_glb(path,doc,binary)
 e.update(sha256=sha(path),bytes=path.stat().st_size,geometry_validation=str(out/'geometry-validation.json'),material_validation=str(out/'material-validation.json'))
 for n in ['geometry-validation.json','material-validation.json']:
  if (old/n).exists():shutil.copyfile(old/n,out/n)
 report['deliverable_sha256']['glb']=e['sha256'];report['glb_bytes']=e['bytes'];dump(report['files']['validation'],report);dump(out/'topology-validation.json',V.M.AQ.check(e));entries.append(e);print('LINEAR GLASS CANDIDATE',e['sku'],e['sha256'],flush=True)
for original in held:assert sha(original['glb_path'])==original['sha256']
dump(R/'glass-linear-candidate-manifest.json',entries)
dump(R/'glass-held-manifest-verification.json',dict(held_original_glbs_unchanged=True,checks=[dict(id=e['id'],sha256=e['sha256'])for e in held]))
