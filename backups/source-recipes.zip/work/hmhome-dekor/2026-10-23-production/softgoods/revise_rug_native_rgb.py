"""Immutable rug colour revision after root's actual Three.js contrast review."""
from pathlib import Path
import sys,json,hashlib,shutil,io
sys.dont_write_bytecode=True
import numpy as np
from PIL import Image
import build_softgoods as B
R=Path(__file__).resolve().parent;V=R/'rug-material-revision-01';sha=B.sha;dump=B.dump

def attrs(doc,blob):
 result=[]
 for a in doc['accessors']:
  v=doc['bufferViews'][a['bufferView']];data=blob[v.get('byteOffset',0):v.get('byteOffset',0)+v['byteLength']];result.append(dict(descriptor=a,bytes_sha256=hashlib.sha256(data).hexdigest()))
 return result

def create():
 assert not(V/'FINAL-FROZEN.json').exists();V.mkdir(exist_ok=True);out=[];audit=[];proof=[]
 rows=[e for f in sorted(R.glob('frozen-batch-*-manifest.json'))for e in json.loads(f.read_text())if e['category']=='Halılar'];assert len(rows)==39 and len({e['sku']for e in rows})==39
 for e in rows:
  folder=V/'models'/e['id'];folder.mkdir(parents=True,exist_ok=True);old=Path(e['asset_dir']);model=json.loads(Path(e['model_path']).read_text());ma=model['materials']['fabric'];prov=json.loads(Path(ma['extras']['texture_provenance']).read_text());oldim=Image.open(old/ma['baseColorTexture']).convert('RGB')
  if e['sku']=='1228033001':
   # This plain rug has only a furniture-detail photo. Its already isolated,
   # periodic native floor-weave donor was never palette-quantized. Preserve it.
   image=oldim.copy();crop=None;policy='Existing isolated sameSKU periodic512px donor unchanged; no complete front observed.'
  else:
   crop=Image.open(e['original_image']).convert('RGB').crop(prov['crop_box_original_pixels']);image=crop.resize(oldim.size,Image.Resampling.LANCZOS)if crop.size!=oldim.size else crop.copy();policy='Own isolated complete flat rug crop, single antialiased resize to the existing native atlas size. Full RGB; no colour quantization, whitening, contrast compression or palette reduction.'
  aa=np.asarray(image,float);bb=np.asarray(oldim,float);lum=aa.mean(2);dark=lum<110;delta=bb.mean(2)-lum;record=dict(sku=e['sku'],source_pixels=e.get('original_image'),mapped_pixels=list(image.size),colour_policy=policy,old_min_luma=float(bb.mean(2).min()),native_min_luma=float(lum.min()),native_dark_pixels=int(dark.sum()),dark_mean_luma_loss_in_old=float(delta[dark].mean())if dark.any()else 0.,dark_max_luma_loss_in_old=float(delta[dark].max())if dark.any()else 0.,max_channel_error_in_old=float(abs(bb-aa).max()),mean_channel_error_in_old=float(abs(bb-aa).mean()),native_under110_retained=True,review_origin='Root actual Three.js contact-11-1/2 caught cars/flecks whitened; all39 subsequently audited.');audit.append(record)
  for key in ['geometry-validation.json','material-validation.json']:
   shutil.copyfile(old/key,folder/key)
  for definition in model['materials'].values():
   for slot in ['baseColorTexture','normalTexture','metallicRoughnessTexture']:shutil.copyfile(old/definition[slot],folder/definition[slot])
  image.save(folder/ma['baseColorTexture'],optimize=True,compress_level=9);newprov=dict(prov);newprov.update(previous_albedo_policy=prov.get('operations'),operations=[policy,'Original ownSKU JPEG and crop coordinates preserved. Source and revised RGB pixels compared directly.','Geometry,UV,NORMAL,TANGENT,indices and all non-albedo embedded textures retained byte-for-byte.'],mapped_artwork_pixels=list(image.size),colour_quantized=False,contrast_reduced=False,source_upscaled=False,previous_glb_sha256=e['sha256'],audit=record);dump(folder/'native-rgb-provenance.json',newprov);ma['extras']['texture_provenance']=str(folder/'native-rgb-provenance.json')
  meta=model['metadata'];meta.update(material_revision='hmhome-rug-native-rgb-2026-10-24-r1',texture_resolution_policy='Own complete rug crop at the recorded native atlas size, no palette reduction;2K PBR normal/roughness. Plain1228033001 retains its native512px detail donor. Geometry/UV byte-preserved.',source_evidence_files=meta['source_evidence_files']+[str(folder/'native-rgb-provenance.json')]);dump(folder/'model.json',model)
  doc,blob=B.read_glb(e['glb_path']);before=attrs(doc,blob);doc['extras']['metadata']=meta;replacement={}
  image_names={im['name']:im for im in doc['images']};image_entry=image_names[ma['baseColorTexture']];replacement[image_entry['bufferView']]=(folder/ma['baseColorTexture']).read_bytes();newblob=bytearray()
  for i,v in enumerate(doc['bufferViews']):
   data=replacement.get(i,blob[v.get('byteOffset',0):v.get('byteOffset',0)+v['byteLength']]);newblob.extend(b'\0'*((-len(newblob))%4));v['byteOffset']=len(newblob);v['byteLength']=len(data);newblob.extend(data)
  doc['buffers'][0]['byteLength']=len(newblob);gp=folder/(e['id']+'.glb');B.write_glb(gp,doc,bytes(newblob));dd,bbin=B.read_glb(gp);assert before==attrs(dd,bbin);assert model['meshes']==json.loads(Path(e['model_path']).read_text())['meshes'];assert gp.stat().st_size<40*1024*1024,(e['sku'],gp.stat().st_size)
  preservation=dict(sku=e['sku'],id=e['id'],previous_glb_sha256=e['sha256'],revision_glb_sha256=sha(gp),all_geometry_accessors_byte_identical=True,model_meshes_identical=True,all_original_JPEGs_unchanged=all(sha(x['path'])==x['sha256']for x in e['original_images']),accessors=before);dump(folder/'binary-preservation.json',preservation);proof.append(preservation)
  maps=[dict(material=name,slot=slot,path=str(folder/definition[slot]),pixels=list(Image.open(folder/definition[slot]).size),sha256=sha(folder/definition[slot]))for name,definition in model['materials'].items()for slot in ['baseColorTexture','normalTexture','metallicRoughnessTexture']];dump(folder/'material-validation.json',dict(valid=True,maps=maps,source_masters_unchanged=True,no_source_photo_upscale=True,colour_quantization=False,texture_provenance=str(folder/'native-rgb-provenance.json')))
  q=dict(e);q.update(asset_dir=str(folder),model_path=str(folder/'model.json'),glb_path=str(gp),sha256=sha(gp),bytes=gp.stat().st_size,geometry_validation=str(folder/'geometry-validation.json'),material_validation=str(folder/'material-validation.json'),source_evidence_files=meta['source_evidence_files'],texture_resolution_policy=meta['texture_resolution_policy'],model_revision=meta['material_revision'],previous_glb_sha256=e['sha256'],frozen=False,native_renders={},quality_pending=True,model_status='material_revision_review');dump(folder/'entry.json',q);out.append(q);dump(V/'manifest.json',out);print('REVISED',e['sku'],gp.stat().st_size,flush=True)
 dump(V/'contrast-audit-all39.json',dict(review_origin='Root actual browser review caught contrast loss in frozen11. Original frozen masters unchanged.',products=audit));dump(V/'binary-preservation.json',dict(valid=True,models=proof));shutil.copyfile(R/'rug-material-intrinsic-contrast-diagnosis.json',V/'root-caught-first-three-diagnosis.json');shutil.copyfile(R/'native-render-rugs.swift',V/'native-render-configuration.swift')
 for n in [1,2]:
  source=R/'rugs-all39-review/browser-review'/('contact-11-'+str(n)+'.jpg')
  if source.exists():shutil.copyfile(source,V/source.name)
 print('REVISED ALL',len(out),sha(V/'manifest.json'),flush=True)

if __name__=='__main__':create()
