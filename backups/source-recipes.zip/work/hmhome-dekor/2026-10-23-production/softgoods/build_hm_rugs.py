"""Every queued exact-SKU rug: official plan, own isolated flat artwork and edge."""
import sys
sys.dont_write_bytecode=True
import json,re,math
import numpy as np
from PIL import Image,ImageFilter
import build_shaped_softgoods as C
S=C.S;R=C.R;B=C.B;T=math.tau
IRREGULAR={'1257810001','1257815002','1258966002'}
ROUND={'1346317001','1346318001'}
TUFTED={'1310155001','1310158001','1342570001'}
FRINGE={'1267344001':.025,'1342565001':.09,'1346319001':.045,'1346319002':.045}
FRINGE_CROP={'1267344001':(.016,.022),'1342565001':(.050,.054),'1346319001':(.023,.025),'1346319002':(.023,.025)}

def source_box(hero):
 a=np.asarray(Image.open(hero['path']).convert('RGB'),float);r,g,b=a.transpose(2,0,1);lum=a.mean(2);mask=((r-b>3)&(lum<245))|(lum<215);mask[:150]=False;mask[-150:]=False;mask[:,:65]=False;mask[:,-65:]=False
 rows=np.flatnonzero(mask.sum(1)>60);cols=np.flatnonzero(mask.sum(0)>60);assert len(rows)and len(cols);return [int(cols[0]+3),int(rows[0]+3),int(cols[-1]-2),int(rows[-1]-2)]

def texture(pid,hero,w,d):
 out=R/'materials'/pid/'own-rug-face';out.mkdir(parents=True,exist_ok=True);im=Image.open(hero['path']).convert('RGB');box=source_box(hero)
 if pid=='1228033001':box=[60,1700,572,2212]
 if pid in FRINGE_CROP:
  a,b=FRINGE_CROP[pid];height=box[3]-box[1];box=[box[0],round(box[1]+a*height),box[2],round(box[3]-b*height)]
 crop=im.crop(box);crop.save(out/'donor-crop-native.png');a=np.asarray(crop,float);n=max(crop.size);scale=min(1.,1536/n);size=[max(1,round(x*scale))for x in crop.size];face=crop.resize(size,Image.Resampling.LANCZOS)if scale<1 else crop.copy();quant=face.quantize(colors=48,method=Image.Quantize.MEDIANCUT).convert('RGB');quant.save(out/'albedo-native.png');palette=np.asarray(quant,float);colour=np.median(palette.reshape(-1,3),axis=0)
 if pid=='1228033001':
  # This exact category image contains a chair. Only the clear floor weave crop
  # is used as a periodic textile donor; no chair/styling pixels enter the rug.
  own=np.asarray(crop,float);low=np.asarray(crop.filter(ImageFilter.GaussianBlur(15)),float);own=np.clip((own-low)*.75+np.median(own.reshape(-1,3),axis=0),0,255);coord=np.arange(2048)%512;Image.fromarray(own[coord[:,None],coord[None,:]].astype(np.uint8)).save(out/'albedo-native.png');size=[2048,2048]
 N=2048;rng=np.random.default_rng(int(pid));yy,xx=np.mgrid[0:N,0:N].astype(float);pitch=3.4 if 'JÜT'in C.own(pid)[0]['productHeading']else 2.6;grain=.035*np.sin(T*xx/pitch)*np.cos(T*yy/pitch)+rng.normal(0,.012,(N,N));height=np.asarray(face.convert('L').filter(ImageFilter.GaussianBlur(1)).resize((N,N),Image.Resampling.BILINEAR),float)/255;low=np.asarray(Image.fromarray(np.rint(height*255).astype(np.uint8)).filter(ImageFilter.GaussianBlur(12)),float)/255;height=(height-low)*1.5+grain;dy,dx=np.gradient(height);normal=np.stack([-dx*3,dy*3,np.ones_like(dx)],2);normal/=np.linalg.norm(normal,axis=2,keepdims=True);Image.fromarray(np.rint((normal+1)*127.5).astype(np.uint8)).save(out/'normal-2k.png');orm=np.zeros((N,N,3),np.uint8);orm[:,:,0]=255;orm[:,:,1]=np.clip(239-grain*60,218,250);Image.fromarray(orm).save(out/'orm-2k.png');C.dump(out/'texture-provenance.json',dict(source_path=hero['path'],source_sha256=hero['sha256'],source_pixels=hero['pixels'],crop_box_original_pixels=box,crop_pixels=list(crop.size),mapped_artwork_pixels=size,operations=['Immutable ownSKU product-only crop from the official flat product image','Downsample at most once;48-colour intrinsic yarn palette limits broad photographic lighting without replacing the design','Fine weave normal/roughness and thickness are estimates; the original pattern orientation is preserved']if pid!='1228033001'else['OwnSKU clear floor-only512px donor, excluding all chair/styling pixels','Broad illumination removed, native donor repeated without upscaling','Full rug is a plain woven interpretation from the sameSKU detail source; no whole rug front was observed'],source_master_unchanged=C.sha(hero['path'])==hero['sha256'],source_upscaled=False,background_pixels_baked=False,full_marketing_photo_wrapped=False,source_photo_pose='top-down rug plane',whole_product_front=pid!='1228033001'))
 ma=dict(baseColorFactor=[1,1,1,1],metallic=1,roughness=1,baseColorTexture=str(out/'albedo-native.png'),normalTexture=str(out/'normal-2k.png'),metallicRoughnessTexture=str(out/'orm-2k.png'),normalScale=.38,doubleSided=False,extras=dict(intrinsic_material=True,photo_pixels_baked=True,photo_donor_surface_only=True,baked_reflections=False,texture_provenance=str(out/'texture-provenance.json'),atlas_tile_metres=1.,physical_sheen=dict(sheenColorFactor=[.055,.05,.04],sheenRoughnessFactor=.94)))
 plain=R/'materials'/pid/'own-rug-backing';plain.mkdir(parents=True,exist_ok=True)
 for key,value in [('albedo',colour),('normal',[128,128,255]),('orm',[255,240,0])]:Image.new('RGB',(4,4),tuple(round(float(x))for x in value)).save(plain/(key+'.png'))
 back=json.loads(json.dumps(ma));back.update(baseColorTexture=str(plain/'albedo.png'),normalTexture=str(plain/'normal.png'),metallicRoughnessTexture=str(plain/'orm.png'));back['extras'].update(photo_pixels_baked=False,constant_PBR_map_no_artificial_upscale=True);return ma,back,box

def outline(pid,hero,box):
 if pid in ROUND:return np.array([(.5+.5*math.cos(t),.5+.5*math.sin(t))for t in np.linspace(0,T,256,endpoint=False)])
 if pid not in IRREGULAR:return np.array([[0,0],[1,0],[1,1],[0,1]])
 a=np.asarray(Image.open(hero['path']).convert('RGB'),float);x0,y0,x1,y1=box;out=[]
 for t in np.linspace(0,T,256,endpoint=False):
  ca,sa=math.cos(t),math.sin(t);maximum=min(1/max(abs(ca),1e-9),1/max(abs(sa),1e-9));last=.3
  for rad in np.linspace(.1,maximum,380):
   u=.5+.5*ca*rad;v=.5+.5*sa*rad;xx=int(np.clip(x0+u*(x1-x0),0,a.shape[1]-1));yy=int(np.clip(y0+v*(y1-y0),0,a.shape[0]-1));r,g,b=a[yy,xx];inside=(r-b>3 and (r+g+b)/3<245)or(r+g+b)/3<215
   if inside:last=rad
   elif rad-last>.025 and last>.35:break
  out.append((.5+.5*ca*max(.2,last-.008),.5+.5*sa*max(.2,last-.008)))
 out=np.array(out);out=(np.roll(out,1,0)+out*2+np.roll(out,-1,0))/4;out=(out-out.min(0))/(out.max(0)-out.min(0));return out

def geometry(pid,w,d,t,contour,fringe):
 bodyd=d-2*fringe
 def top(u,v):return t
 if pid in TUFTED:
  a=np.asarray(Image.open(R/'materials'/pid/'own-rug-face/albedo-native.png').convert('RGB'),float);lum=a.mean(2)
  mask=(lum>np.quantile(lum,.86))if pid=='1342570001'else(lum<np.quantile(lum,.38))if pid=='1310155001'else(lum<110)
  mask=np.asarray(Image.fromarray(np.rint(mask*255).astype(np.uint8)).filter(ImageFilter.GaussianBlur(.8)),float)/255
  def top(u,v):return t*(.72+.28*mask[min(mask.shape[0]-1,round(v*(mask.shape[0]-1))),min(mask.shape[1]-1,round(u*(mask.shape[1]-1)))])
 if len(contour)==4:
  N=129 if pid in TUFTED else 65;verts=[];uv=[];faces=[]
  for layer in [0,1]:
   for j,v in enumerate(np.linspace(0,1,N)):
    for i,u in enumerate(np.linspace(0,1,N)):verts.append(((u-.5)*w,top(u,v)if layer==0 else 0,(v-.5)*bodyd));uv.append((u,v))
  n=N*N
  for layer in [0,1]:
   for j in range(N-1):
    for i in range(N-1):a=layer*n+j*N+i;b=a+N;faces.extend([(a,b,a+1),(a+1,b,b+1)]if layer==0 else[(a,a+1,b),(a+1,b+1,b)])
  edge=list(range(N))+[j*N+N-1 for j in range(1,N)]+list(range((N-1)*N+N-2,(N-1)*N-1,-1))+[j*N for j in range(N-2,0,-1)]
  for j,a in enumerate(edge):b=edge[(j+1)%len(edge)];faces.extend([(a,b,a+n),(b,b+n,a+n)])
  parts=[B.solid('closed-woven-rug-face-and-backing','fabric',verts,faces,uv)];path=[(verts[i][0],t*.55,verts[i][2])for i in edge]
 else:
  pts=np.array([[(u-.5)*w,(v-.5)*bodyd]for u,v in contour]);n=len(pts);verts=[(x,t,z)for x,z in pts]+[(x,0,z)for x,z in pts]+[(0,t,0),(0,0,0)];uv=contour.tolist()*2+[[.5,.5],[.5,.5]];faces=[]
  for j in range(n):k=(j+1)%n;faces.extend([(2*n,j,k),(2*n+1,n+k,n+j),(j,n+j,k),(k,n+j,n+k)])
  parts=[B.solid('closed-own-photo-contour-rug','fabric',verts,faces,uv)];path=[(x,t*.55,z)for x,z in pts]
 backing=json.loads(json.dumps(parts[0]));backing['name']='closed-unobserved-plain-textile-backing';backing['material']='back';backing['_vertices']=[(x,y*.18,z)for x,y,z in backing['_vertices']];parts[0]['_vertices']=[(x,t*.18 if y==0 else y,z)for x,y,z in parts[0]['_vertices']];parts.append(backing)
 parts.append(B.tube('continuous-soft-bound-textile-edge','back',path,.00075,.00075,5,True,guide=[0,1,0]));rng=np.random.default_rng(int(pid));fibres=[]
 if pid in TUFTED:
  loops=[]
  for i in range(3500):
   u,v=rng.uniform(.003,.997,2);x=(u-.5)*w;z=(v-.5)*bodyd;y=top(u,v);ang=rng.uniform(0,T);r=.00065;points=[(x+math.cos(ang)*r*f,y-.00012+math.sin(math.pi*f)*.0015,z+math.sin(ang)*r*f)for f in[0,.25,.5,.75,1.]];q=B.tube('closed-fine-raised-tuft-loop','fabric',points,.00015,.00012,3,False,guide=[0,1,0]);q['_uvs']=[(u,v)]*len(q['_vertices']);loops.append(q)
  parts.append(S.merge(loops,'many-physical-tuft-loops-following-source-relief','fabric'))
 if pid in ROUND:
  braids=[];pitch=.020;maximum=(w/2-.007)*T/pitch
  for phase in [0,T/3,2*T/3]:
   path=[]
   for ang in np.linspace(.8,maximum,max(200,int(maximum/T*180))):
    r=pitch*ang/T+.0018*math.sin(ang*21+phase);path.append((r*math.cos(ang),t+.0007+.0006*math.cos(ang*21+phase),r*math.sin(ang)))
   braids.append(B.tube('continuous-interwoven-concentric-cloth-strip','fabric',path,.0015,.00055,4,False,guide=[0,1,0]))
  parts.append(S.merge(braids,'three-strand-physical-spiral-braided-weave','fabric'))
 if fringe:
  for sign in [-1,1]:
   for x in np.arange(-w*.495,w*.495,.005):
    for k in range(3):
     p=[x+k*.00035,t*.45,sign*bodyd/2];q=[p[0]+rng.uniform(-.0015,.0015),p[1],p[2]+sign*fringe*rng.uniform(.80,1.)];fibres.append(B.tube('closed-observed-short-edge-fringe-yarn','back',[p,q],.00025,.00020,4,False,guide=[0,1,0]))
  parts.append(S.merge(fibres,'physical-fringes-on-two-short-ends','back'))
 return parts

def build(pid):
 cap,ep,refs,hero=C.own(pid);label=cap['sizes'];pair=re.search(r'(\d+(?:[.,]\d+)?)\s*[Xx×]\s*(\d+(?:[.,]\d+)?)',label);circle=re.search(r'\bD\s*(\d+(?:[.,]\d+)?)',label)
 if pair:short,long=sorted(float(x.replace(',','.'))for x in pair.groups());w,d=short/100,long/100;official=dict(selected_plan_label=pair.group(0),width_cm=short,length_cm=long)
 elif circle:w=d=float(circle.group(1).replace(',','.'))/100;official=dict(selected_plan_label=circle.group(0),diameter_cm=w*100)
 else:raise ValueError('No exactSKU official rug plan '+pid)
 if pid=='1353720001':w,d=d,w;official.update(width_cm=w*100,length_cm=d*100)
 name=cap['productHeading'];t=.014 if'TÜFTE'in name else .009 if'YÜN'in name or'ASİMETRİK'in name else .007 if'JÜT'in name else .005;fringe=d*sum(FRINGE_CROP[pid])/2 if pid in FRINGE_CROP else 0;ma,back,box=texture(pid,hero,w,d);contour=outline(pid,hero,box);parts=geometry(pid,w,d,t,contour,fringe);note=f'Resmî seçili plan etiketi {official["selected_plan_label"]} korunur. Yaklaşık {t*100:g} cm kalınlık, kenar dikişi, arka yüz ve {fringe*100:g} cm saçak fotoğraf yorumudur. Desen yalnız bu SKU’nun kendi tam ürün fotoğrafından; kaynak üst kenarı modelin -Z yönüne bakar.';C.finish(pid,parts,dict(fabric=ma,back=back),cap,ep,refs,hero,[w,t,d],official,'irregular_rug'if pid in IRREGULAR else'round_rug'if pid in ROUND else'rectangular_rug',['thickness_cm','bound_edge_geometry','reverse_surface','fringe_length_cm'],note,dict(category='Halılar',source_dimensions_hwd_cm=[None,w*100,d*100],estimated_thickness_cm=t*100,fringe_length_cm_estimated=fringe*100,official_plan_dimensions_cm=[w*100,d*100],source_orientation_note='Complete own rug photo top maps to-Z on the horizontalXZ ground plane.',quality_label='Dokuma/kalınlık yorumu',quality_status='photo_interpreted',quality_note='Plan ölçüsü resmî seçili bedendir. Kalınlık, kenar/saçak ayrıntısı ve görünmeyen arka yüz fotoğraf yorumudur.'if pid!='1228033001'else'Resmî plan korundu. Tam ürün ön fotoğrafı bulunmadığından kendiSKU detay fotoğrafının yalnız boş kumaş bölümüyle düz dokuma yüzey yorumlandı; mobilya aksesuarları eklenmedi.'))

if __name__=='__main__':
 rows=json.loads((R/'joined-softgoods-queue.json').read_text())['products'];ids=sys.argv[1:]or[e['sku']for e in rows if e['category_id']=='rugs']
 for pid in ids:build(pid)
