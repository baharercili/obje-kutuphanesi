"""Source-specific physical locks and native pigment roots/tips, from R5 bases.

Preserves every R5 BIN byte and original image. Own intrinsic PNGs supply pigment
samples, not a spatial studio illumination map. New hair colour is standard
linear glTF COLOR_0 (UNSIGNED_BYTE normalized); no replacement RGB image is made.
"""
from pathlib import Path
import copy, importlib.util, inspect, json, math, sys
import numpy as np
from PIL import Image
sys.dont_write_bytecode=True
D=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('old_bounded_fur_R6',D.parent/'fur-projecting-own-three-r6/build_projecting_fur_three.py')
B=importlib.util.module_from_spec(spec);spec.loader.exec_module(B)
B.D=D
OLD={e['sku']:e for e in json.loads(B.SOURCE.read_text())}
CFG={
 '1355345001':dict(kind='grey_clustered_root_tip',centres=3000,strands=3,rings=11,sides=5,width=[.0025,.0045],
                  length=[.022,.038],rise=[.009,.017],curl=[.003,.006],
                  undercoat=5000,wisps=2200,factor=[1,1,1,1],
                  label='Koyu dip ve açık uçlu iri gri tutamlar · R5 katlı poz'),
 '1357963001':dict(kind='cream_coherent_soft_locks',centres=2400,strands=3,rings=11,sides=6,width=[.003,.006],
                  length=[.023,.038],rise=[.008,.018],curl=[.005,.009],
                  undercoat=0,wisps=1800,factor=[1,1,1,1],
                  label='Birlikte kıvrılan iri krem tutamlar · R5 katlı poz'),
}
B.CFG=CFG
COLOR_CACHE={}
B.COLOR_CACHE=COLOR_CACHE

# Parallel-transport the rounded cross-section. A fixed up-vector can abruptly
# flip at a near-vertical lock segment and create the appearance of cut ribbons.
tube_source=inspect.getsource(B.tubes)
old_frame=''' guide=np.zeros_like(tangent);guide[:,:,1]=1;guide[abs(tangent[:,:,1])>.95]=[0,0,1]
 across=np.cross(tangent,guide);across/=np.linalg.norm(across,axis=2,keepdims=True);up=np.cross(across,tangent)'''
new_frame=''' guide=np.zeros((count,3));guide[:,1]=1;guide[abs(tangent[:,0,1])>.95]=[0,0,1]
 across=np.empty_like(tangent);across[:,0]=np.cross(tangent[:,0],guide);across[:,0]/=np.linalg.norm(across[:,0],axis=1,keepdims=True)
 for j in range(1,k):
  q=across[:,j-1]-tangent[:,j]*(across[:,j-1]*tangent[:,j]).sum(1)[:,None]
  length=np.linalg.norm(q,axis=1,keepdims=True);assert length.min()>1e-7
  across[:,j]=q/length
 up=np.cross(across,tangent)'''
assert tube_source.count(old_frame)==1
exec(compile(tube_source.replace(old_frame,new_frame),str(__file__)+':parallel-transport-rounded-locks','exec'),B.__dict__)

def linear(a):
 a=np.asarray(a,float)/255
 return np.where(a<=.04045,a/12.92,((a+.055)/1.055)**2.4)

def palette(sku,rng):
 old=OLD[sku];p=Path(old['asset_dir'])/'fabric-fabric-fabric-albedo-2k.png'
 im=np.asarray(Image.open(p).convert('RGB')).reshape(-1,3).astype(float)
 lum=im@np.array([.2126,.7152,.0722])
 ranges=[(.01,.15),(.40,.65),(.95,.999)] if sku=='1355345001'else[(.12,.40),(.42,.70),(.80,.99)]
 banks=[];report=[]
 for lo,hi in ranges:
  subset=im[(lum>=np.quantile(lum,lo))&(lum<=np.quantile(lum,hi))]
  banks.append(subset);report.append(dict(quantile=[lo,hi],median_srgb=np.median(subset,0).tolist(),pixels=len(subset)))
 return banks,dict(source_intrinsic_png=str(p),sha256=B.sha(p),original_rgb_pixels_unchanged=True,
                   pigment_banks=report,linear_srgb_conversion=True,
                   spatial_photo_shadows_not_copied=True,
                   no_replacement_RGB_image=True,
                   pigment_assignment='Only intrinsic native pigment samples and quantiles; dark/light hair root-to-tip grouping is photo interpretation, not measured manufacturer fibre construction.')

def choose_color(bank,rng,count):
 return linear(bank[rng.integers(len(bank),size=count)])

def uniform_centres(d,b,sku,count):
 p,n,uv,lo,hi=B.sample_actual_top(d,b,sku,count*3)
 spacing=math.sqrt(np.prod(hi-lo)/count)
 cell=np.floor((p[:,[0,2]]-lo)/spacing).astype(int)
 _,first=np.unique(cell,axis=0,return_index=True)
 rng=np.random.default_rng(int(sku)+719)
 if len(first)>count:first=rng.choice(first,count,False)
 elif len(first)<count:
  unused=np.setdiff1d(np.arange(len(p)),first);first=np.r_[first,rng.choice(unused,count-len(first),False)]
 return p[first],n[first],uv[first],lo,hi

def tube_colors(paths,width,thick,sides,root_rgb,tip_rgb,at,transition=.70):
 verts,faces,metric=B.tubes(paths,width,thick,sides)
 count,k,_=paths.shape
 blend=np.clip((np.linspace(0,1,k)-.08)/transition,0,1)**.72
 colour=root_rgb[:,None,:]*(1-blend[None,:,None])+tip_rgb[:,None,:]*blend[None,:,None]
 colour=np.repeat(colour[:,:,None,:],sides,axis=2).reshape(count,k*sides,3)
 colour=np.concatenate([colour,root_rgb[:,None,:],tip_rgb[:,None,:]],1)
 colour=np.c_[colour.reshape(-1,3),np.ones(count*(k*sides+2))]
 colour=np.rint(np.clip(colour,0,1)*255).astype('u1')
 uv0=(at[:,None,:]+metric*.002).reshape(-1,2)
 return verts,faces,metric.reshape(-1,2),uv0,colour

def restrain(vertices,roots,lower,upper):
 bad=((vertices[:,:,0]<lower[0])|(vertices[:,:,0]>upper[0])|(vertices[:,:,2]<lower[2])|(vertices[:,:,2]>upper[2])).any(1)
 if bad.any():
  off=vertices[bad]-roots[bad,None,:];scale=np.ones(len(off))
  for axis in [0,2]:
   pos=np.maximum(off[:,:,axis].max(1),1e-12);neg=np.maximum(-off[:,:,axis].min(1),1e-12)
   scale=np.minimum(scale,(upper[axis]-roots[bad,axis])*.99/pos)
   scale=np.minimum(scale,(roots[bad,axis]-lower[axis])*.99/neg)
  assert scale.min()>0
  off[:,:,[0,2]]*=scale[:,None,None];vertices[bad]=roots[bad,None,:]+off
 return int(bad.sum())

def clustered_mesh(d,b,sku,cfg):
 rng=np.random.default_rng(int(sku)+707)
 p,n,uv,lo,hi=uniform_centres(d,b,sku,cfg['centres'])
 banks,palette_proof=palette(sku,rng)
 oldpos=np.concatenate([B.array(d,b,pr['attributes']['POSITION'])for m in d['meshes']for pr in m['primitives']])
 lower,upper=oldpos.min(0),oldpos.max(0)
 angle=(1.35*np.sin(uv[:,0]*9+uv[:,1]*4)+1.1*np.cos(uv[:,1]*10-uv[:,0]*3)
        +rng.normal(0,.30,len(p)))
 if sku=='1357963001':angle=rng.uniform(0,math.tau,len(p))
 direction=np.c_[np.cos(angle),np.zeros(len(p)),np.sin(angle)]
 direction-=n*(direction*n).sum(1)[:,None];direction/=np.linalg.norm(direction,axis=1,keepdims=True)
 edge=np.minimum(p[:,[0,2]]-lo,hi-p[:,[0,2]]).min(1)<.035
 inward=np.c_[(lo[0]+hi[0])/2-p[:,0],np.zeros(len(p)),(lo[1]+hi[1])/2-p[:,2]]
 inward-=n*(inward*n).sum(1)[:,None];inward/=np.linalg.norm(inward,axis=1,keepdims=True)
 direction[edge]=inward[edge]
 side=np.cross(n,direction)
 # Locks share phase, curl radius, direction and loft. Individual strands
 # deviate gently; thousands of independent velvet microfibres are not reused.
 phase=rng.uniform(-.35,.35,len(p));radius=rng.uniform(*cfg['curl'],len(p))
 loft=rng.uniform(*cfg['rise'],len(p));length=rng.uniform(*cfg['length'],len(p))
 cloud=.5+.5*np.sin(uv[:,0]*11+np.cos(uv[:,1]*8))*np.cos(uv[:,1]*10-uv[:,0]*4)
 if sku=='1355345001':loft*=.70+.30*cloud
 roots=[];normals=[];coords=[];paths=[];root_rgb=[];tip_rgb=[];widths=[];thickness=[]
 for strand in range(cfg['strands']):
  radial=(strand-(cfg['strands']-1)/2)*.0022
  root=p+side*radial
  root[:,[0,2]]=np.clip(root[:,[0,2]],lower[[0,2]]+.0015,upper[[0,2]]-.0015)
  rows=[];w=rng.uniform(*cfg['width'],len(p));h=loft*rng.uniform(.90,1.10,len(p))
  for f in np.linspace(0,1,cfg['rings']):
   if sku=='1357963001':
    turn=f*math.tau*(.69+.08*np.sin(uv[:,0]*19+uv[:,1]*11))
    along=length*f*.55+radius*(np.sin(turn+phase)-np.sin(phase))
    curl=radius*(np.cos(phase)-np.cos(turn+phase))
   else:
    along=length*f;curl=radius*np.sin(f*math.pi*1.30+phase)*np.sin(math.pi*f*.88)
   rows.append(root+n*(.0005+h*np.sin(math.pi*f*.89))[:,None]+direction*along[:,None]+side*curl[:,None])
  roots.append(root);normals.append(n);coords.append(uv);paths.append(np.stack(rows,1));widths.append(w);thickness.append(w*rng.uniform(.60,.82,len(p)))
  root_rgb.append(choose_color(banks[0] if sku=='1355345001'else banks[1],rng,len(p)))
  tip_rgb.append(choose_color(banks[2],rng,len(p)))
 roots=np.concatenate(roots);coords=np.concatenate(coords);mainpaths=np.concatenate(paths)
 verts,faces,uv1,uv0,color=tube_colors(mainpaths,np.concatenate(widths),np.concatenate(thickness),cfg['sides'],np.concatenate(root_rgb),np.concatenate(tip_rgb),coords,.65 if sku=='1355345001'else .82)
 restrained=restrain(verts,roots,lower,upper)
 groups=[(verts.reshape(-1,3),faces,uv1,uv0,color)]
 if cfg['undercoat']:
  q,nn,at,_,_=B.sample_actual_top(d,b,sku,cfg['undercoat']);a=rng.uniform(0,math.tau,len(q));tt=np.c_[np.cos(a),np.zeros(len(q)),np.sin(a)];tt-=nn*(tt*nn).sum(1)[:,None];tt/=np.linalg.norm(tt,axis=1,keepdims=True)
  L=rng.uniform(.007,.014,len(q));H=rng.uniform(.0025,.005,len(q));pp=np.stack([q+nn*(.0003+H*math.sin(math.pi*f*.85))[:,None]+tt*(L*f)[:,None]for f in np.linspace(0,1,4)],1)
  width=rng.uniform(.0016,.0032,len(q));dark=choose_color(banks[0],rng,len(q));mid=choose_color(banks[0],rng,len(q))
  vv,ff,u1,u0,cc=tube_colors(pp,width,width*.65,3,dark,mid,at);restrain(vv,q,lower,upper);groups.append((vv.reshape(-1,3),ff,u1,u0,cc))
 # Sparse physically loose fine ends soften the silhouette of broad locks.
 take=rng.choice(len(roots),cfg['wisps'],False);pp=mainpaths[take][:,[0,3,6,8,10]].copy();pp[:,1:]+=np.array([0,.0013,0]);fine_root=np.concatenate(root_rgb)[take];fine_tip=np.concatenate(tip_rgb)[take]
 vv,ff,u1,u0,cc=tube_colors(pp,np.full(len(take),.00020),np.full(len(take),.00016),3,fine_root,fine_tip,coords[take]);restrain(vv,roots[take],lower,upper);groups.append((vv.reshape(-1,3),ff,u1,u0,cc))
 xyz=[];ff=[];u1=[];u0=[];colour=[];offset=0
 for v,f,a,z,c in groups:
  xyz.append(v);ff.append(f+offset);u1.append(a);u0.append(z);colour.append(c);offset+=len(v)
 xyz=np.concatenate(xyz).astype('<f4');faces=np.concatenate(ff);uv1=np.concatenate(u1).astype('<f4');uv0=np.concatenate(u0).astype('<f4');COLOR_CACHE[sku]=np.concatenate(colour)
 normal,tangent=B.normals_and_tangents(xyz,faces,uv1)
 palette_proof.update(physical_centred_locks=cfg['centres'],coherently_curved_strands_per_lock=cfg['strands'],broad_strand_width_m=cfg['width'],normal_loft_m=cfg['rise'],coherent_curl_radius_m=cfg['curl'],native_dark_undercoat_strands=cfg['undercoat'],loose_fine_end_strands=cfg['wisps'],all_colour_from_this_SKU_own_intrinsic_RGB=True,root_to_tip_colour_space='linear RGB, quantized glTF normalized unsigned byte COLOR_0',physical_cloud_field_changes_direction_and_loft_not_a_photo_shadow_map=True)
 B.dump(D/(sku+'-own-pigment-clustered-lock-proof.json'),palette_proof)
 proof=dict(clump_centres_on_exact_R5_upper_triangles=True,child_roots_on_local_R5_surface_tangent_interpreted=True,root_offsets_max_m=.0044,old_R5_body_prefix_and_origin_unchanged=True,clusters=cfg['centres'],coherent_main_strands=cfg['centres']*cfg['strands'],undercoat_strands=cfg['undercoat'],fine_loose_ends=cfg['wisps'],width_m=cfg['width'],normal_rise_m=cfg['rise'],curl_radius_m=cfg['curl'],edge_restrained_main_strands=restrained,all_source_pigment_and_hidden_fibre_construction_photo_interpreted=True,own_RGB_palette_proof=str(D/(sku+'-own-pigment-clustered-lock-proof.json')))
 return xyz,normal,uv0,uv1,tangent,faces,proof

B.new_bundle_mesh=clustered_mesh
source=inspect.getsource(B.build)
source=source.replace("a=np.asarray(a,'<u4'if component==5125 else'<f4')", "a=np.asarray(a,'<u4'if component==5125 else'u1'if component==5121 else'<f4')")
a="indices=acc(faces.reshape(-1,1),'SCALAR',5125,34963)";assert source.count(a)==1
source=source.replace(a,"attrs['COLOR_0']=acc(COLOR_CACHE[sku],'VEC4',5121);d['accessors'][attrs['COLOR_0']]['normalized']=True\n "+a)
a="pbr=material['pbrMetallicRoughness'];pbr['baseColorFactor']=cfg['factor'];";assert source.count(a)==1
source=source.replace(a,a+"pbr.pop('baseColorTexture',None);")
source=source.replace('texCoord=1,scale=.42','texCoord=1,scale=.22').replace('normalScale=.42','normalScale=.22')
a="author['extras'].update(";assert source.count(a)==1;source=source.replace(a,"author.pop('baseColorTexture',None)\n "+a)
a='indices=faces.reshape(-1).tolist()))';assert source.count(a)==1;source=source.replace(a,"colorsLinearNormalizedBytes=COLOR_CACHE[sku].reshape(-1).tolist(),"+a)
source=source.replace('own-source-projecting-volumetric-pile-R6','own-source-clustered-locks-native-root-tip-pigment-R7')
exec(compile(source,str(__file__)+':R5-prefix-preserving-coloured-lock-build','exec'),B.__dict__)

if __name__=='__main__':
 assert B.sha(B.SOURCE)==B.SOURCE_SHA
 selected=sys.argv[1:]or list(CFG);assert set(selected)<=set(CFG)
 manifest=D/'candidate-two-clustered-locks-manifest.json';rows=json.loads(manifest.read_text())if manifest.exists()else[]
 for sku in selected:
  assert sku not in {e['sku']for e in rows}
  entry=B.build(OLD[sku]);entry['pigment_grouping_proof']=str(D/(sku+'-own-pigment-clustered-lock-proof.json'))
  # COLOR_0 is finite standard UNORM8; the geometry audit separately verifies
  # float vectors, embedded maps, closed topology, bounds, and all old masters.
  d,b=B.glb(entry['glb_path']);a=d['accessors'][d['meshes'][-1]['primitives'][0]['attributes']['COLOR_0']]
  assert a['componentType']==5121 and a['normalized']is True and a['type']=='VEC4'
  assert a['count']==len(COLOR_CACHE[sku]);assert(COLOR_CACHE[sku][:,3]==255).all()
  rows.append(entry);B.dump(manifest,rows)
