"""Approved R4 pose, exact-SKU surfaces and separately authored source-specific details."""
from pathlib import Path
import json,sys,copy,math,shutil
sys.dont_write_bytecode=True
import numpy as np
from PIL import Image,ImageFilter
import build_shaped_softgoods as C
import build_organic_throw_pilots_v2 as O
import build_organic_throw_pilots_v4 as W
P=C.R;V=P/'organic-throws-final';S=C.S;B=C.B;G=C.G;M=C.M;TAU=math.tau
read=lambda p:json.loads(Path(p).read_text())
RECIPES=read(P/'organic-revision-recipes-27.json')['recipes']
OLD={e['sku']:e for f in P.glob('frozen-batch-1[678]-manifest.json') for e in read(f)}
PILOTS={e['sku']:e for e in read(P/'organic-throws-revision-04/manifest.json')}

def sample(grid,normals,uv,u,v):
    ni,nj=np.array(grid.shape[:2])-1;a,b=u*ni,v*nj;i,j=min(int(a),ni-1),min(int(b),nj-1);a-=i;b-=j
    def mix(field):return field[i,j]*(1-a)*(1-b)+field[i+1,j]*a*(1-b)+field[i,j+1]*(1-a)*b+field[i+1,j+1]*a*b
    p=mix(grid);n=mix(normals);n/=np.linalg.norm(n);return p,n,mix(uv)

def top(grid,normals,uv,u,v,thick):
    # Invert the projected artwork coordinates on the actual exposed outer
    # quarter. Index fractions are not UV fractions across the finite U bends.
    at=np.array([.571+u*.429,.429*(1-v)])
    target=np.array([u,v])
    for _ in range(6):
        p,n,t=sample(grid,normals,uv,*at);J=[]
        for axis in range(2):
            shift=np.zeros(2);shift[axis]=.0001
            J.append((sample(grid,normals,uv,*(at+shift))[2]-t)/.0001)
        step=np.linalg.solve(np.stack(J,1),target-t);at=np.clip(at+step,[.574,.001],[.998,.426])
    p,n,t=sample(grid,normals,uv,*at)
    if n[1]<0:n=-n
    return p+n*(thick/2+.0001),n,t

def local_uv(raw,at,scale=.0004):
    xy=np.asarray(raw['_uvs']);xy=(xy-xy.min(0))/np.maximum(xy.max(0)-xy.min(0),1e-9);raw['_uvs']=[tuple(at+q*scale) for q in xy];return raw

def fibres(pid,grid,normals,uv,thick,family):
    rng=np.random.default_rng(int(pid));parts=[]
    fur=family=='fur_or_quilted_pile';boucle=family=='boucle';wool=family=='long_fringed_wool';count=8000 if fur else 6000 if boucle else 4500 if wool else 2200
    length_range=RECIPES[pid].get('surface_pile_length_mm',[.7,1.4])
    for k in range(count):
        if k<count*.78:u,v=rng.uniform(.60,.997),rng.uniform(.003,.42);sgn=1
        elif k<count*.93:u,v=rng.uniform(.003,.42),rng.uniform(.003,.42);sgn=-1
        else:u,v=rng.uniform(.445,.555),rng.uniform(.003,.42);sgn=0
        p,n,t=sample(grid,normals,uv,u,v)
        if sgn:
            if n[1]*sgn<0:n=-n
        elif np.dot(n,p-grid.mean((0,1)))<0:n=-n
        # Keep the observed quilt channels open rather than burying them in
        # the neighbouring 5–10mm pile. Taper the same own-source tufts locally.
        quilt=RECIPES[pid].get('visible_quilt_grid')
        channel=1.
        if quilt:
            spans=np.ptp(grid[:,:,[0,2]],axis=(0,1));phase=t*np.array(quilt);distance=np.minimum(phase%1,1-phase%1)*spans/np.array(quilt);channel=float(np.clip((distance.min()-.002)/.009,0,1))
            if channel<.08:continue
        p=p+n*(thick/2+.00012);side=grid[min(int(u*(len(grid)-1))+1,len(grid)-1),0]-grid[max(int(u*(len(grid)-1))-1,0),0];side-=n*np.dot(side,n)
        if np.linalg.norm(side)<1e-5:side=np.cross(n,[0,0,1.])
        side/=np.linalg.norm(side);cross=np.cross(n,side);L=rng.uniform(*length_range)/1000*(.12+.88*channel);phase=rng.uniform(0,TAU)
        if boucle:
            points=[p-n*.00010,p+n*L*.65+side*L*.15,p+n*L+side*L*.6,p+n*L*.65+side*L,p+side*L*.9]
            rx,ry=.00028,.00022
        elif fur:
            # Open wavy centreline with capped mesh ends, never a surface-following ring.
            points=[p+n*L*(.50*math.sin(math.pi*f*.80)) + side*L*.65*f + cross*L*.22*(math.sin(f*TAU*.8+phase)-math.sin(phase))*f for f in np.linspace(0,1,6)]
            rx,ry=(.00070,.00030) if pid=='1357963001' else (.00048,.00025)
        else:
            points=[p-n*.00012,p+n*L*.6+side*L*.2,p+n*L*.8+side*L*.55,p+n*L*.45+side*L*.85];rx,ry=(.00020,.00015) if wool else (.00015,.00012)
        raw=B.tube('source-specific-closed-mesh-open-ended-fibre','fabric',points,rx,ry,3 if pid=='1348907002'else 4,False,guide=side.tolist());parts.append(local_uv(raw,t))
    return S.merge(parts,'own-'+family+'-pile-on-exposed-front-turn-and-reverse','fabric')

def cables(pid,grid,normals,uv,thick):
    parts=[]
    for sign in [-1,1]:
        for k in range(-5,9):
            pts=[];coords=[]
            for u in np.linspace(.005,.995,180):
                v=(k-sign*3*u)/5
                if .005<v<.995:
                    p,n,t=top(grid,normals,uv,float(u),float(v),thick);pts.append(p+n*.0010);coords.append(t)
            if len(pts)>2:
                raw=B.tube('observed-three-by-five-diamond-knit-cable','fabric',pts,.0010,.00080,5,False,guide=[0,1,0]);at=np.mean(coords,0);parts.append(local_uv(raw,at))
    return S.merge(parts,'physical-knit-diamond-cables-follow-soft-folded-front','fabric')

def quilt_seams(grid,normals,uv,thick):
    parts=[]
    for axis,lines in [(0,[1/3,2/3]),(1,[.2,.4,.6,.8])]:
        for line in lines:
            pts=[]
            for along in np.linspace(.005,.995,120):
                u,v=(line,along) if axis==0 else (along,line);p,n,t=top(grid,normals,uv,u,v,thick);pts.append(p+n*.0001)
            parts.append(B.tube('source-quilt-joined-soft-channel-stitch','yarn',pts,.00035,.00024,4,False,guide=[0,1,0]))
    return S.merge(parts,'physical-source-three-by-five-quilt-seam-traces','yarn')

def blanket_stitches(grid,normals,uv,thick):
    parts=[]
    for axis in [0,1]:
        for edge in [.005,.995]:
            for k in range(100 if axis==0 else 80):
                f=(k+.5)/(100 if axis==0 else 80);p,n,t=top(grid,normals,uv,edge if axis==0 else f,f if axis==0 else edge,thick);step=np.array([.003,0,0]) if axis==0 else np.array([0,0,.003]);points=[p-step+n*.0005,p+n*.0010,p+step-n*.0010];parts.append(B.tube('individual-source-black-blanket-stitch','yarn',points,.00045,.00035,4,False,guide=[0,1,0]))
    return S.merge(parts,'visible-source-black-blanket-stitch-border','yarn')

def fringe(pid,grid,normals,uv,length,family):
    if not length:return []
    rng=np.random.default_rng(int(pid));wool=family=='long_fringed_wool';chenille=family=='chenille';fine=family=='linen_woven';count=25 if wool else 45 if chenille else 108 if fine else 58;radius=.0039 if wool else .0012 if chenille else .00043 if fine else .00075;parts=[]
    for k in range(count):
        u=.55+.445*(k+.5)/count;p,n,t=sample(grid,normals,uv,u,0);direction=-(grid[min(round(u*(len(grid)-1)),len(grid)-1),1]-grid[min(round(u*(len(grid)-1)),len(grid)-1),0]);direction[1]=0;direction/=np.linalg.norm(direction);cross=np.array([direction[2],0,-direction[0]]);L=length*rng.uniform(.88,1.10);phase=rng.uniform(0,TAU);bend=rng.uniform(-.015,.015) if wool else rng.uniform(-.007,.007)
        points=[p+direction*L*f+cross*(bend*math.sin(math.pi*f*.8)+radius*.45*math.sin(f*TAU*2.6+phase)*f)+np.array([0,-(.020 if wool else .008)*math.sin(math.pi*f*.75)+radius*.3*math.cos(f*TAU*2.6+phase)*f,0]) for f in np.linspace(0,1,35 if wool else 25)]
        raw=B.tube('source-own-colour-loose-fringe-cord','yarn',points,radius,radius*.9,8 if wool else 5,False,guide=[0,1,0]);parts.append(raw)
        if chenille or family=='boucle':
            for j in range(3):
                tip=points[-1]+cross*(j-1)*radius*.4;pts=[tip,tip+direction*.004+cross*(j-1)*.0015,tip+direction*.008+cross*(j-1)*.002+np.array([0,-.001,0])];parts.append(B.tube('loose-chenille-fringe-end','yarn',pts,.0002,.00015,3,False,guide=[0,1,0]))
    return [S.merge(parts,'source-visible-exposed-'+str(count)+'-fringe-cords','yarn')]

def materials(pid,old,folder,out,span,family):
    mats=copy.deepcopy(old['materials']);proof=[]
    for name,ma in mats.items():
        for slot in ['baseColorTexture','normalTexture','metallicRoughnessTexture']:
            src=folder/ma[slot];dst=out/(name+'-'+Path(ma[slot]).name);shutil.copyfile(src,dst);ma[slot]=dst.name
        if name=='yarn':
            for slot,file,colour in [('normalTexture','yarn-flat-normal.png',(128,128,255)),('metallicRoughnessTexture','yarn-rough-nonmetal-orm.png',(255,248,0))]:Image.new('RGB',(128,128),colour).save(out/file);ma[slot]=file
            ma['normalScale']=.2;ma['baseColorFactor']=[1,1,1,1]
            continue
        provenance=read(folder/Path(ma['extras']['texture_provenance']).name);box=provenance['crop_box_original_pixels'];microbox=provenance['micro_crop_relative_pixels'];absolute=[box[0]+microbox[0],box[1]+microbox[1],box[0]+microbox[2],box[1]+microbox[3]];source=Image.open(provenance['source_path']).convert('RGB');crop=source.crop(absolute);crop.save(out/'own-yarn-micro-native.png');a=np.asarray(crop,float);res=(a-np.asarray(crop.filter(ImageFilter.GaussianBlur(2)),float)).mean(2);n=2048;yy,xx=np.indices((n,n));x=xx*.4/n;y=yy*.4/n;grain=res[yy%crop.height,xx%crop.width]
        if family=='linen_woven':
            wx=.0028;wy=.0031;warp=np.exp(-((((x/wx)%1)-.5)/.24)**2);weft=np.exp(-((((y/wy)%1)-.5)/.23)**2);height=.00026*warp*(.7+.3*np.cos(TAU*y/wy))+.00023*weft*(.7-.3*np.cos(TAU*x/wx))+grain*.000004
        elif family=='knitted_cable':
            phase=(x/.002+(np.floor(y/.003)%2)*.5)%1;path=(y/.003-abs(phase-.5))%1;dist=np.minimum(path,1-path);height=.00025*np.exp(-(dist/.25)**2)+grain*.000006
        elif family in ['chenille','boucle']:
            xxp=x/(.0018 if family=='chenille' else .0022);yyp=y/.0025;rad=np.sqrt((((xxp%1)-.5)/.36)**2+(((yyp%1)-.5)/.43)**2);height=np.exp(-((rad-1)/.28)**2)*(.00055 if family=='chenille' else .00075)+grain*.000006
        else:height=.00006*np.sin(TAU*x/.0012)*np.cos(TAU*y/.0014)+grain*.000008
        dy,dx=np.gradient(height,.4/n,.4/n);normal=np.stack((-dx,dy,np.ones_like(dx)),2);normal/=np.linalg.norm(normal,axis=2,keepdims=True);Image.fromarray(np.rint((normal+1)*127.5).astype(np.uint8)).save(out/'own-physical-yarn-normal-2k.png');ma['normalTexture']='own-physical-yarn-normal-2k.png';ma['normalScale']=1.0;ma['extras']['normal_orm_uv_scale']=[span[0]/.4,span[1]/.4]
        if pid.startswith('1348754'):ma['baseColorFactor']=[.72,.72,.72,1]
        proof.append(dict(material=name,own_albedo_byte_identical_to_frozen=True,source_path=provenance['source_path'],source_sha256=provenance['source_sha256'],micro_native_box=absolute,own_micro_pixels=list(crop.size),normal_family=family,output_pixels=[n,n],source_master_unchanged=C.sha(provenance['source_path'])==provenance['source_sha256'],geometric_resampling_count=0,normal_scale_photo_estimated=True))
    C.dump(out/'own-surface-provenance.json',dict(valid=True,materials=proof,all_original_RGB_bytes_preserved=True,physical_geometry_separately_attached_to_exterior=True));return mats

def build(pid):
    assert pid in OLD and pid not in PILOTS
    for frozen in V.glob('frozen-family-*/manifest.json'):
        if (frozen.parent/'FINAL-FROZEN.json').exists():
            assert pid not in {x['sku'] for x in read(frozen)}, 'Never rebuild an immutable delivered family'
    assert not(V/'FINAL-FROZEN.json').exists();e=OLD[pid];recipe=RECIPES[pid];family=recipe['surface_family'];old=read(e['model_path']);folder=Path(e['asset_dir']);out=V/'models'/e['id'];out.mkdir(parents=True,exist_ok=True)
    plan=e.get('official_plan_dimensions_cm') or e['estimated_unfolded_plan_cm'];width,length=np.asarray(plan)/100;frlen=recipe.get('fringe_length_cm',0)/100;thick=recipe['thickness_mm']/1000;radius=.007 if family in ['long_fringed_wool','boucle','fur_or_quilted_pile'] else .004
    grid,normals,uv,extra=O.grid_for(width,length-2*frlen,thick,radius)
    if recipe.get('visible_quilt_grid'):
        # The blanket remains finite cloth, not an inflated pad. Soft source cell
        # transitions and shallow stitched channels deform all four real layers.
        pu=uv[:,:,0]*3;pv=uv[:,:,1]*5
        # A source-specific three-by-five cell field. The 6.5mm rounded
        # chamber rise is estimated; true cells and channels deform cloth,
        # rather than repeating a photographed seam in the fibre albedo.
        grid[:,:,1]+=.0065*np.sin(math.pi*(pu%1))**2*np.sin(math.pi*(pv%1))**2
        normals=np.cross(np.gradient(grid,axis=1),np.gradient(grid,axis=0));normals/=np.linalg.norm(normals,axis=2,keepdims=True)
    parts=[O.T.C.shell('continuous-four-layer-organic-own-source-cloth','fabric',grid,normals,thick,uv)]+fringe(pid,grid,normals,uv,frlen,family)
    if family in ['long_fringed_wool','boucle','chenille','fur_or_quilted_pile'] or pid=='1348917001':parts.append(fibres(pid,grid,normals,uv,thick,family))
    if family=='knitted_cable':parts.append(cables(pid,grid,normals,uv,thick))
    if recipe.get('visible_quilt_grid'):parts.append(quilt_seams(grid,normals,uv,thick))
    if pid=='1298464008':parts.append(blanket_stitches(grid,normals,uv,thick))
    meshes=[];checks=[]
    for raw in parts:
        removed=C.clean_collapsed_fibres(raw);mesh,qa=S._finalize(G.orient(raw));qa['rare_collapsed_fibre_solids_removed']=removed;meshes.append(mesh);checks.append(qa)
    repairs=M.ensure_uv_faces(meshes)+G.ensure_float32_uv(meshes);body=np.asarray(meshes[0]['positions']).reshape(-1,3);lo=body.min(0);hi=body.max(0);meshes=[W.warp_mesh(m,lo,hi) for m in meshes]
    if family=='long_fringed_wool':
        yarn=next(m for m in meshes if m['material']=='yarn');fuzz,qa,_=W.fringe_fuzz(yarn);meshes.append(fuzz);checks.append(qa)
    positions=np.concatenate([np.asarray(m['positions']).reshape(-1,3) for m in meshes]);lo=positions.min(0);hi=positions.max(0);centre=np.array([(lo[0]+hi[0])/2,lo[1],(lo[2]+hi[2])/2]);dims=((hi-lo)*100).tolist()
    for m in meshes:m['positions']=(np.asarray(m['positions']).reshape(-1,3)-centre).reshape(-1).tolist()
    mats=materials(pid,old,folder,out,extra['posed_artwork_span_m'],family);official=bool(e.get('official_plan_dimensions_cm'));note=('Resmî' if official else 'KendiSKU fotoğrafından tahmini, resmî olmayan')+' açık plan '+str(plan[0])+'×'+str(plan[1])+' cm korunur. Dört gerçek katın organik yatay pozu R4 actual incelemede onaylanan yöntemle kurulmuştur. Kat hacmi, değişken kumaş kalınlığı, kenar kayması, fiziksel lif/örgü/kordon ölçeği ve görünmeyen desen fazı fotoğraf yorumudur.'
    if frlen:note+=' Açıkta görünen tek püskül sırası kendi kaynak karakteriyle kurulmuştur; kat içinde görünmeyen diğer püsküller ayrıca yeniden modellenmez. Püskül uzunluğu yaklaşık'+str(recipe['fringe_length_cm'])+' cm’dir; nominal etiketin püskül dahil kapsamı açıklanmaz.'
    meta=copy.deepcopy(old['metadata']);meta.update(id=e['id'],dimensions_cm=dims,scale_note=note,quality_status='photo_interpreted',quality_label='Katlı poz / desen yorumu' if official else 'Tahmini ölçek / desen',quality_note='Kendi ürününün RGB desen ve kumaş pikselleri korunmuştur. '+family+' yüzeyi, katlar, görünmeyen yerleşim ve yerel dikiş/lifler fotoğraftan yaklaşık yorumdur.',product_form='four_layer_organic_folded_throw',surface_family=family,folded_layers=4,pose='Root actual-approved R4 soft finite-radius fold; source-specific pile, edge and fringe geometry.',cloth_body_plan_cm=[width*100,(length-2*frlen)*100],nominal_unfolded_plan_cm=plan,nominal_plan_official=official,estimated_fringe_length_cm=recipe.get('fringe_length_cm',0),fringe_length_cm_estimated=recipe.get('fringe_length_cm',0),short_side_fold_radius_mm=(2*radius+thick)*1000*1.7,long_side_fold_radius_mm=radius*1000*1.7,estimated_fields=sorted(set(old['metadata']['estimated_fields']+['folded_pose_dimensions','natural_edge_curl_and_layer_shift','physical_yarn_pile_and_seam_scale'])),previous_glb_sha256=e['sha256'],revision_reason='Remaining25 source-specific surfaces on actual-approved R4 organic pose; old rejected rigid-book masters untouched.',source_evidence_files=e['source_evidence_files']+[str(P/'organic-revision-recipes-27.json'),str(out/'own-surface-provenance.json')],**{k:v for k,v in extra.items() if k in ['artwork_mapping','posed_artwork_span_m']})
    C.dump(out/'model.json',dict(metadata=meta,materials=mats,meshes=meshes));C.dump(out/'geometry-validation.json',dict(valid=True,meshes=checks,uv_repairs=repairs,positive_smooth_pose_Jacobian=True,physical_surface_details_follow_new_cloth=True,finite_closed_cloth_not_filled_pillow=True));C.dump(out/'material-validation.json',dict(valid=True,own_original_RGB_byte_preserved=True,own_source_masters_unchanged=all(C.sha(i['path'])==i['sha256'] for i in e['original_images'])));report=S.export_assets(out/'model.json',out,e['id']);glb=out/(e['id']+'.glb');doc,blob=S.read_glb(glb)
    for ma in doc['materials']:
        if ma['name']=='fabric':
            for t in [ma['normalTexture'],ma['pbrMetallicRoughness']['metallicRoughnessTexture']]:t.setdefault('extensions',{})['KHR_texture_transform']=dict(scale=mats['fabric']['extras']['normal_orm_uv_scale'])
        sheen=mats[ma['name']]['extras'].get('physical_sheen')
        if sheen:ma.setdefault('extensions',{})['KHR_materials_sheen']=sheen
    doc['extensionsUsed']=sorted(set(doc.get('extensionsUsed',[]))|{'KHR_texture_transform','KHR_materials_sheen'});blob=M.embed_tangents(doc,blob);S.write_glb(glb,doc,blob);report['deliverable_sha256']['glb']=C.sha(glb);report['glb_bytes']=glb.stat().st_size;C.dump(Path(report['files']['validation']),report)
    entry={**e,**meta,'asset_dir':str(out),'model_path':str(out/'model.json'),'glb_path':str(glb),'sha256':C.sha(glb),'bytes':glb.stat().st_size,'geometry_validation':str(out/'geometry-validation.json'),'material_validation':str(out/'material-validation.json'),'frozen':False,'quality_pending':True,'actual_browser_review_passed':False,'model_status':'ready_for_browser_review','model_revision':'source-specific-organic-throw-R4-2026-10-24-v1'};assert entry['bytes']<40*1024*1024;C.dump(out/'entry.json',entry);rows=read(V/'manifest.json') if (V/'manifest.json').exists() else [];C.dump(V/'manifest.json',[x for x in rows if x['sku']!=pid]+[entry]);print(json.dumps(dict(sku=pid,id=e['id'],bytes=entry['bytes'],family=family,dimensions_cm=dims)),flush=True)

if __name__=='__main__':
    V.mkdir(exist_ok=True)
    for pid in sys.argv[1:] or [pid for pid in OLD if pid not in PILOTS]:build(pid)
