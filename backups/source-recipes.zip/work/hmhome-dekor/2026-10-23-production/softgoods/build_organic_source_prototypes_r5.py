"""Only three source-specific R5 candidates; accepted R4 pilots remain immutable."""
from pathlib import Path
import json,sys,copy,math,shutil
sys.dont_write_bytecode=True
import numpy as np
from PIL import Image,ImageFilter
import build_organic_fleet as F
C=F.C;P=F.P;S=F.S;B=F.B;G=F.G;M=F.M;T=math.tau
V=P/'organic-source-prototypes-r5';TARGETS=['1338614001','1333785001','1355863001'];read=lambda p:json.loads(Path(p).read_text())
QU=[.14,.415,.69,.96];QV=[.205,.415,.625,.835]
def quilt_field(uv,span):
    distances=[];cells=[]
    for axis,lines in enumerate([QU,QV]):
        a=uv[...,axis];bounds=np.array([0]+lines+[1]);ix=np.clip(np.searchsorted(bounds,a,side='right')-1,0,len(bounds)-2);q=(a-bounds[ix])/np.maximum(bounds[ix+1]-bounds[ix],1e-5);cells.append(np.sin(np.pi*q)**2);distances.append(np.min(np.abs(a[...,None]-np.array(lines)),axis=-1)*span[axis])
    distance=np.minimum(*distances);channel=np.exp(-(distance/.0045)**2);return cells[0]*cells[1],channel,distance

def grid_for(pid,plan,thick,fringe):
    # The same continuous two-by-two fold topology as R4, with a larger true
    # U radius and asymmetric soft volume, rather than many parallel plates.
    radius=.011 if pid!='1355863001'else .012
    grid,normals,uv,extra=F.O.grid_for(plan[0],plan[1]-2*fringe,thick,radius)
    span=np.array(extra['posed_artwork_span_m'])
    if pid=='1355863001':
        puff,channel,distance=quilt_field(uv,span);grid[:,:,1]+=.012*puff-.0018*channel
    elif pid=='1333785001':
        a=uv[:,:,0]*3+uv[:,:,1]*5;b=uv[:,:,0]*3-uv[:,:,1]*5;d=np.minimum(np.minimum(a%1,1-a%1),np.minimum(b%1,1-b%1));grid[:,:,1]+=.0023*np.exp(-(d/.075)**2)
    normals=np.cross(np.gradient(grid,axis=1),np.gradient(grid,axis=0));normals/=np.linalg.norm(normals,axis=2,keepdims=True)
    return grid,normals,uv,extra

def soft_deform(a,lo,hi):
    w,d=hi[[0,2]]-lo[[0,2]];h=hi[1]-lo[1];x=(a[:,0]-lo[0])/w;z=(a[:,2]-lo[2])/d;y=(a[:,1]-lo[1])/h
    ex=np.exp(-np.maximum(np.minimum(x,1-x),0)/.11);ez=np.exp(-np.maximum(np.minimum(z,1-z),0)/.09)
    q=a.copy();q[:,1]=lo[1]+(a[:,1]-lo[1])*1.28
    q[:,1]+=.018*np.sin(math.pi*x+.25)*np.cos(math.pi*z+.8)+.010*np.sin(T*(.85*x+.22*z)+.5)*np.sin(math.pi*z+.2)
    q[:,1]+=.011*(ex+ez)*np.sin(math.pi*(1.35*x+.70*z)+.5)+.006*(y-.5)*np.sin(T*z+.6)
    q[:,0]+=.010*(y-.5)*np.sin(math.pi*z+.5)+.006*np.sin(math.pi*x)**2*np.sin(T*z+.7)
    q[:,2]+=.010*(y-.5)*np.cos(math.pi*x+.4)+.008*np.sin(math.pi*z)**2*np.sin(T*x+.5)
    return q

def warp(m,lo,hi):
    a=np.round(np.asarray(m['positions']).reshape(-1,3),9);n=np.asarray(m['normals']).reshape(-1,3);q=soft_deform(a,lo,hi);eps=1e-5;js=[]
    for k in range(3):
        delta=np.zeros(3);delta[k]=eps;js.append((soft_deform(a+delta,lo,hi)-soft_deform(a-delta,lo,hi))/(2*eps))
    J=np.stack(js,2);assert np.linalg.det(J).min()>.3
    nn=np.linalg.solve(np.transpose(J,(0,2,1)),n[...,None])[...,0];nn/=np.linalg.norm(nn,axis=1,keepdims=True);r=copy.deepcopy(m);r['positions']=q.reshape(-1).tolist();r['normals']=nn.reshape(-1).tolist();return r

def knit_loops(grid,normals,uv,thick,span):
    # True individual round U-shaped yarn stitches, softly angled inside each
    # lozenge; no straight diagonal tube grid standing in for knitted fabric.
    parts=[];nx,ny=int(span[0]/.007),int(span[1]/.0075);rng=np.random.default_rng(1333785001)
    for j in range(ny):
        for i in range(nx):
            u=(i+.5+(j%2)*.18)/nx;v=(j+.5)/ny
            if not(.02<u<.98 and .02<v<.98):continue
            p,n,t=F.top(grid,normals,uv,float(u),float(v),thick)
            if np.linalg.norm(t-[u,v])>.006:continue
            tx=np.array([1.,0,0])-n*n[0];tx/=np.linalg.norm(tx);ty=np.cross(tx,n);ty/=np.linalg.norm(ty)
            # Adjacent diamond fields change the direction of the knitted wale.
            parity=int(math.floor(u*3+v*5)+math.floor(u*3-v*5))%2;angle=.32 if parity else -.32;xx=tx*math.cos(angle)+ty*math.sin(angle);yy=-tx*math.sin(angle)+ty*math.cos(angle)
            pts=[]
            for ax,ay,az in [(-.26,-.48,0),(-.46,-.04,.22),(-.31,.40,.38),(0,.53,.43),(.31,.40,.38),(.46,-.04,.22),(.26,-.48,0)]:pts.append(p+xx*ax*.0065+yy*ay*.007+n*(.0006+az*.0015))
            raw=B.tube('real-soft-U-shaped-knitted-yarn-stitch','fabric',pts,.00064,.00054,3,False,guide=n.tolist());parts.append(F.local_uv(raw,t,.00025))
    return S.merge(parts,'individual-knit-stitches-follow-source-diamond-wales','fabric')

def quilt_seams(grid,normals,uv,thick):
    parts=[]
    for axis,lines in [(0,QU),(1,QV)]:
        for line in lines:
            pts=[]
            for t in np.linspace(.01,.99,125):
                u,v=(line,t)if axis==0 else(t,line);p,n,_=F.top(grid,normals,uv,float(u),float(v),thick);pts.append(p+n*.00025)
            parts.append(B.tube('soft-source-quilt-stitched-channel','yarn',pts,.00040,.0003,4,False,guide=[0,1,0]))
    return S.merge(parts,'own-photo-partial-cell-phase-quilting-seams','yarn')

def quilt_pile(grid,normals,uv,thick,span):
    rng=np.random.default_rng(1355863001);parts=[]
    for _ in range(6500):
        u,v=rng.uniform(.02,.98,2);p,n,t=F.top(grid,normals,uv,float(u),float(v),thick);_,channel,distance=quilt_field(t,span)
        if distance<.006:continue
        tx=np.array([1.,0,0])-n*n[0];tx/=np.linalg.norm(tx);ty=np.cross(tx,n);L=rng.uniform(.003,.006);phase=rng.uniform(0,T);points=[]
        for f in np.linspace(0,1,5):points.append(p+n*(L*.45*math.sin(math.pi*f*.8))+tx*L*.7*f+ty*L*.22*(math.sin(f*T*.7+phase)-math.sin(phase))*f)
        raw=B.tube('open-wavy-capped-mesh-plush-quilt-tuft','fabric',points,.00065,.00035,3,False,guide=n.tolist());parts.append(F.local_uv(raw,t,.0003))
    return S.merge(parts,'visible-plush-hav-clear-of-real-quilt-channels','fabric')

def materials(pid,previous,out,span):
    old=read(previous['model_path']);mats=copy.deepcopy(old['materials'])
    for name,ma in mats.items():
        for slot in['baseColorTexture','normalTexture','metallicRoughnessTexture']:
            src=Path(previous['asset_dir'])/ma[slot];dst=out/(name+'-'+Path(ma[slot]).name);shutil.copyfile(src,dst);ma[slot]=dst.name
    ma=mats['fabric'];master=Path(previous['original_image']);im=Image.open(master).convert('RGB')
    box={'1338614001':[620,520,1004,904],'1333785001':[570,850,954,1234],'1355863001':[680,800,808,928]}[pid];patch=im.crop(box);patch.save(out/'own-native-donor.png');a=np.asarray(patch,float);low=np.asarray(patch.filter(ImageFilter.GaussianBlur(12 if pid=='1338614001'else 3)),float);res=a-low;n=2048;yy,xx=np.indices((n,n));X=xx/n*span[0];Y=yy/n*span[1]
    # One final mapping from native own fibres to their photo-estimated physical
    # size. Unique donor resolution is reported separately from the 2K map.
    native_pixel_m=span[0]/1185;scale=span[0]/(n*native_pixel_m);ix=np.floor(xx*scale).astype(int)%patch.width;iy=np.floor(yy*scale*span[1]/span[0]).astype(int)%patch.height;grain=res[iy,ix];base=np.median(a.reshape(-1,3),0)
    if pid=='1338614001':
        rgb=np.clip(base+grain*.90,0,255);px=.0012;py=.0014;wx=np.cos(T*X/px);wy=np.cos(T*Y/py);h=.00016*np.maximum(wx,0)*(1+.3*wy)+.00015*np.maximum(wy,0)*(1-.3*wx)+grain.mean(2)*.000004;ao=np.ones((n,n))*255;rough=np.clip(242+grain.mean(2)*.15,225,250)
    elif pid=='1333785001':
        phase1=xx/n*3+yy/n*5;phase2=xx/n*3-yy/n*5;d=np.minimum(np.minimum(phase1%1,1-phase1%1),np.minimum(phase2%1,1-phase2%1));ridge=np.exp(-(d/.08)**2);direction=np.where((np.floor(phase1)+np.floor(phase2))%2,1,-1);wale=(X+direction*Y*.33)/.0032;course=Y/.004;h=.00040*(np.sin(T*wale)*.5+.5)*(np.cos(T*course)*.5+.5)+.0011*ridge+grain.mean(2)*.000004;rgb=np.clip(base+grain*.70-ridge[:,:,None]*2.5,0,255);ao=255-ridge*7;rough=np.clip(246+grain.mean(2)*.1,235,252)
    else:
        coords=np.stack((xx/n,yy/n),2);puff,channel,distance=quilt_field(coords,span);h=.0018*(1-channel)+grain.mean(2)*.000006;rgb=np.clip(base+grain*.75,0,255);ao=255-channel*42;rough=np.clip(247+grain.mean(2)*.1,235,253)
    dy,dx=np.gradient(h,span[1]/n,span[0]/n);normal=np.stack((-dx,dy,np.ones_like(dx)),2);normal/=np.linalg.norm(normal,axis=2,keepdims=True);orm=np.stack([ao,rough,np.zeros_like(ao)],2)
    for name,data in [('own-albedo-r5',rgb),('own-normal-r5',(normal+1)*127.5),('own-orm-r5',orm)]:Image.fromarray(np.clip(np.rint(data),0,255).astype(np.uint8)).save(out/(name+'.png'))
    ma.update(baseColorTexture='own-albedo-r5.png',normalTexture='own-normal-r5.png',metallicRoughnessTexture='own-orm-r5.png',normalScale=1,baseColorFactor=[1,1,1,1]);ma['extras']['normal_orm_uv_scale']=[1,1];ma['extras']['physical_sheen']['sheenColorFactor']=[.045,.04,.035]
    proof=dict(source_path=str(master),source_sha256=C.sha(master),source_pixels=list(im.size),native_crop_box=box,unique_native_donor_pixels=list(patch.size),donor_exact_original_crop=True,source_master_unchanged=C.sha(master)==next(x['sha256']for x in previous['original_images']if x['path']==str(master)),low_frequency_photo_fold_illumination_removed=True,own_native_high_frequency_yarn_preserved=True,photo_estimated_native_pixel_world_metres=native_pixel_m,one_final_sampling_to_physical_material=True,no_other_SKU_pixels=True,no_marketing_background_wrapped=True,palette_quantization=False,output_pixels=[n,n],physical_pile_channels_and_knit_structure_separately_authored=True)
    C.dump(out/'own-source-native-provenance-r5.json',proof);ma['extras']['texture_provenance']=str(out/'own-source-native-provenance-r5.json');return mats

def build(pid):
    assert pid in TARGETS and not(V/'FINAL-FROZEN.json').exists();prev=next(x for x in read(F.V/'manifest.json')if x['sku']==pid);out=V/'models'/prev['id'];out.mkdir(parents=True,exist_ok=True);plan=np.array(prev.get('official_plan_dimensions_cm')or prev['estimated_unfolded_plan_cm'])/100;fringe=.075 if pid=='1338614001'else 0;thick=.0025 if pid=='1338614001'else .004
    grid,normals,uv,extra=grid_for(pid,plan,thick,fringe);parts=[F.O.T.C.shell('continuous-finite-four-layer-soft-source-cloth','fabric',grid,normals,thick,uv)]
    if fringe:parts+=F.fringe(pid,grid,normals,uv,fringe,'linen_woven')
    if pid=='1333785001':parts.append(knit_loops(grid,normals,uv,thick,extra['posed_artwork_span_m']))
    if pid=='1355863001':parts.extend([quilt_seams(grid,normals,uv,thick),quilt_pile(grid,normals,uv,thick,extra['posed_artwork_span_m'])])
    meshes=[];checks=[]
    for raw in parts:
        removed=C.clean_collapsed_fibres(raw);m,qa=S._finalize(G.orient(raw));qa['collapsed_solids_removed']=removed;meshes.append(m);checks.append(qa)
    repairs=M.ensure_uv_faces(meshes)+G.ensure_float32_uv(meshes);body=np.asarray(meshes[0]['positions']).reshape(-1,3);lo=body.min(0);hi=body.max(0);meshes=[warp(m,lo,hi)for m in meshes];pos=np.concatenate([np.array(m['positions']).reshape(-1,3)for m in meshes]);lo=pos.min(0);hi=pos.max(0);origin=np.array([(lo[0]+hi[0])/2,lo[1],(lo[2]+hi[2])/2]);dims=((hi-lo)*100).tolist()
    for m in meshes:m['positions']=(np.array(m['positions']).reshape(-1,3)-origin).reshape(-1).tolist()
    mats=materials(pid,prev,out,extra['posed_artwork_span_m']);meta=copy.deepcopy(read(prev['model_path'])['metadata']);note='Kendi ürün fotoğrafına göre yeniden kurulan yumuşak dört katlı poz, geniş yuvarlak kat dönüşü ve düzensiz kenarlar yorumdur. Açık plan ölçüsü fotoğraftan tahmin edilmiştir; resmî üretici ölçüsü değildir. '
    note+=('Özgün keten iplik ve melanj ayrıntısı kullanıldı; ince dokuma ölçeği tahminidir.'if pid=='1338614001'else'Elmas alanlarda ayrı fiziksel örgü ilmekleri ve yerel hav vardır; ilmek çapı/yoğunluğu fotoğraf yorumudur.'if pid=='1333785001'else'Kendi fotoğrafındaki kısmi kapitone hücre düzeni, yumuşak bombe ve havı kısaltan kanallarla kuruldu; hücre yüksekliği ve hav ölçeği tahminidir.')
    meta.update(dimensions_cm=dims,product_form='four_layer_organic_folded_throw',model_revision='bounded-source-specific-organic-r5',quality_note=note,quality_status='photo_interpreted',quality_label='Tahmini ölçek / kumaş pozu',scale_note=note,previous_glb_sha256=prev['sha256'],pose='Finite-radius continuous four-layer fold with asymmetric broad drape and rounded layer-dependent edges; source reconstruction, not manufacturer data.',source_evidence_files=meta['source_evidence_files']+[str(out/'own-source-native-provenance-r5.json')],estimated_fields=sorted(set(meta['estimated_fields']+['source_specific_knit_or_quilt_surface','broad_soft_pose_and_layer_shifts'])))
    C.dump(out/'model.json',dict(metadata=meta,materials=mats,meshes=meshes));C.dump(out/'geometry-validation.json',dict(valid=True,closed_mesh_checks=checks,uv_repairs=repairs,common_positive_Jacobian_soft_warp=True,all_detail_roots_follow_cloth=True,no_outer_reverse_shell_covering_front=True));C.dump(out/'material-validation.json',dict(valid=True,source_master_unchanged=True,own_native_yarn_or_pile=True,old_frozen_models_untouched=True));report=S.export_assets(out/'model.json',out,prev['id']);glb=out/(prev['id']+'.glb');doc,blob=S.read_glb(glb)
    for ma in doc['materials']:
        sheen=mats[ma['name']]['extras'].get('physical_sheen')
        if sheen:ma.setdefault('extensions',{})['KHR_materials_sheen']=sheen
    doc['extensionsUsed']=sorted(set(doc.get('extensionsUsed',[]))|{'KHR_materials_sheen'});blob=M.embed_tangents(doc,blob);S.write_glb(glb,doc,blob);report['deliverable_sha256']['glb']=C.sha(glb);report['glb_bytes']=glb.stat().st_size;C.dump(Path(report['files']['validation']),report)
    e={**prev,**meta,'asset_dir':str(out),'model_path':str(out/'model.json'),'glb_path':str(glb),'sha256':C.sha(glb),'bytes':glb.stat().st_size,'geometry_validation':str(out/'geometry-validation.json'),'material_validation':str(out/'material-validation.json'),'frozen':False,'quality_pending':True,'actual_browser_review_passed':False,'model_status':'ready_for_browser_review'};assert e['bytes']<40*1024*1024;C.dump(out/'entry.json',e);rows=read(V/'manifest.json')if(V/'manifest.json').exists()else[];C.dump(V/'manifest.json',[x for x in rows if x['sku']!=pid]+[e]);print(pid,e['sha256'],e['bytes'],dims,flush=True)
if __name__=='__main__':
    V.mkdir(exist_ok=True)
    for sku in sys.argv[1:]or TARGETS:build(sku)
