"""One bounded own-grey candidate: independent fine closed fibres, no haircards.

Every immutable R5 byte is retained. R7's 9,000 centre curves provide only the
shared macro-flow and native linear pigment. Each carries six independent fine
strands with distinct root, length, phase and free tip. There is no shared card,
alpha atlas, or broad visible carrier surface.
"""
from pathlib import Path
import copy, hashlib, importlib.util, io, json, math, subprocess, sys
import numpy as np
from PIL import Image
sys.dont_write_bytecode=True
D=Path(__file__).resolve().parent
T=D.parent.parent/'textiles';sys.path.insert(0,str(T))
from freeze_polar_knit_review_candidates import glb,sha,dump,attr
from clean_remaining_robe_material_revision02 import write_glb
import specific_binary_native_material as V
spec=importlib.util.spec_from_file_location('cream_r8_readonly_helpers',D.parent/'cream-curved-haircards-prototype-r8/build_cream_haircards.py')
H=importlib.util.module_from_spec(spec);spec.loader.exec_module(H)
B=H.B
SKU='1355345001'
R7=D.parent/'fur-clustered-own-two-r7/frozen-own-root-tip-grey-and-coherent-cream-locks-02-manifest.json'
R7SHA='d6fc6b4268c78fa2ad5cb5ed4b205a45e25a0f1401eddfe87cffef038b1e2a8d'

def interpolate(rows,parameters):
 """Independent parameter per fibre and station, with bounded tip extension."""
 q=parameters*(rows.shape[1]-1);index=np.minimum(np.floor(q).astype(int),rows.shape[1]-2)
 f=q-index;ids=np.arange(len(rows))[:,None]
 return rows[ids,index]*(1-f[:,:,None])+rows[ids,index+1]*f[:,:,None]

def fine_fibres(source7,od,ob):
 d,b=glb(source7['glb_path']);p=d['meshes'][-1]['primitives'][0]
 pos=B.array(d,b,p['attributes']['POSITION']).astype(float)
 colours=H.read_colour(d,b,p['attributes']['COLOR_0'])
 parents=9000;source_rings=11;source_sides=5;source_per=source_rings*source_sides+2
 assert len(pos)>parents*source_per
 macro=pos[:parents*source_per].reshape(parents,source_per,3)[:,:source_rings*source_sides].reshape(parents,source_rings,source_sides,3).mean(2)
 pigment=colours[:parents*source_per].reshape(parents,source_per,4)[:,:source_rings*source_sides].reshape(parents,source_rings,source_sides,4)[:,:,0,:].astype(float)
 # This SKU's source has a longer, laid and slowly turning pile, unlike the
 # accepted cream's short curly flow. The original grey roots and native
 # pigment remain exact; only this explicit source-photo fibre pose changes.
 original_macro_sha=hashlib.sha256(macro.astype('<f8').tobytes()).hexdigest()
 root=macro[:,0:1].copy();delta=macro-root;f=np.linspace(0,1,source_rings)
 endpoint=delta[:,-1,:][:,[0,2]]
 lateral=delta[:,:,[0,2]]-endpoint[:,None,:]*f[None,:,None]
 macro[:,:,[0,2]]=root[:,:,[0,2]]+endpoint[:,None,:]*f[None,:,None]*1.45+lateral*.25
 macro[:,:,1]=root[:,:,1]+delta[:,:,1]*.65
 interpreted_macro_sha=hashlib.sha256(macro.astype('<f8').tobytes()).hexdigest()

 children=6;count=parents*children;stations=4;sides=3
 rng=np.random.default_rng(int(SKU)+1010)
 macros=np.repeat(macro,children,axis=0);pigments=np.repeat(pigment,children,axis=0)
 # No parent-aligned end contour: length and tip position are independently
 # distributed for each single fibre, including siblings of the same parent.
 end=rng.uniform(.72,1.14,count)
 fraction=np.array([0.,.31,.67,1.])
 parameter=end[:,None]*fraction[None,:]
 centres=interpolate(macros,parameter)
 t0,a0,u0=H.frames(macros)
 across=interpolate(a0,parameter);up=interpolate(u0,parameter)
 across/=np.linalg.norm(across,axis=2,keepdims=True);up/=np.linalg.norm(up,axis=2,keepdims=True)
 phase=rng.uniform(0,math.tau,count);frequency=rng.uniform(.25,.60,count)
 rootx=rng.uniform(-.0008,.0008,count);rooty=rng.uniform(-.0006,.0006,count)
 amp=rng.uniform(.0006,.0018,count)
 free=centres.copy()
 wave=np.sin(fraction[None,:]*math.pi*frequency[:,None]+phase[:,None])
 wave-=np.sin(phase)[:,None]
 dx=rootx[:,None]+amp[:,None]*fraction[None,:]**1.25*wave
 dy=rooty[:,None]+amp[:,None]*fraction[None,:]**1.45*np.cos(fraction[None,:]*math.pi*frequency[:,None]+phase[:,None])*.65
 centres+=across*dx[:,:,None]+up*dy[:,:,None]
 centres[:,:,1]+=.00012
 # Keep all new roots/tips within the unchanged R5 nominal footprint.
 oldpos=np.concatenate([B.array(od,ob,q['attributes']['POSITION'])for m in od['meshes']for q in m['primitives']])
 lo,hi=oldpos.min(0),oldpos.max(0)
 widths=rng.uniform(.00020,.00060,count);tips=rng.uniform(.00003,.00008,count)
 width=widths[:,None]*np.array([1.,.85,.40,0.])[None,:];width[:,-1]=tips
 tangent,span,up=H.frames(centres)
 angle=np.arange(sides)*math.tau/sides
 radial=span[:,:,None,:]*np.cos(angle)[None,None,:,None]+up[:,:,None,:]*np.sin(angle)[None,None,:,None]
 sidepos=centres[:,:,None,:]+radial*width[:,:,None,None]*.5
 vertices=np.concatenate([sidepos.reshape(count,stations*sides,3),centres[:,0:1],centres[:,-1:]],axis=1)
 bad=((vertices[:,:,0]<lo[0])|(vertices[:,:,0]>hi[0])|(vertices[:,:,2]<lo[2])|(vertices[:,:,2]>hi[2])).any(1)
 if bad.any():
  root=macros[:,0];off=vertices[bad]-root[bad,None,:];scale=np.ones(int(bad.sum()))
  for axis in [0,2]:
   scale=np.minimum(scale,(hi[axis]-root[bad,axis])*.99/np.maximum(off[:,:,axis].max(1),1e-12))
   scale=np.minimum(scale,(root[bad,axis]-lo[axis])*.99/np.maximum(-off[:,:,axis].min(1),1e-12))
  assert scale.min()>0
  off[:,:,[0,2]]*=scale[:,None,None];vertices[bad]=root[bad,None,:]+off
 # Analytic smooth cylindrical normals/tangents; the thin solid has a closed
 # triangular section, not a flat ribbon/card. Recompute the centre frames
 # after the bounded edge adjustment to retain valid unit orthogonal vectors.
 centres=vertices[:,:stations*sides].reshape(count,stations,sides,3).mean(2)
 tangent,span,up=H.frames(centres)
 radial=span[:,:,None,:]*np.cos(angle)[None,None,:,None]+up[:,:,None,:]*np.sin(angle)[None,None,:,None]
 circle=-span[:,:,None,:]*np.sin(angle)[None,None,:,None]+up[:,:,None,:]*np.cos(angle)[None,None,:,None]
 normal=np.concatenate([radial.reshape(count,stations*sides,3),-tangent[:,0:1],tangent[:,-1:]],1)
 tang=np.concatenate([circle.reshape(count,stations*sides,3),span[:,0:1],span[:,-1:]],1)
 flow=np.concatenate([np.repeat(tangent[:,:,None,:],sides,axis=2).reshape(count,stations*sides,3),tangent[:,0:1],tangent[:,-1:]],1)
 handed=np.where((np.cross(normal,tang)*flow).sum(2)<0,-1.,1.)
 tan=np.concatenate([tang,handed[:,:,None]],2)
 local=[]
 for j in range(stations-1):
  for a in range(sides):
   b0=(a+1)%sides;x=j*sides+a;y=j*sides+b0;z=(j+1)*sides+a;w=(j+1)*sides+b0
   local.extend([(x,z,y),(y,z,w)])
 for a in range(sides):
  b0=(a+1)%sides;local.append((stations*sides,a,b0));local.append((stations*sides+1,(stations-1)*sides+b0,(stations-1)*sides+a))
 per=stations*sides+2
 faces=(np.asarray(local,np.uint32)[None,:,:]+np.arange(count,dtype=np.uint32)[:,None,None]*per)
 flat=vertices.reshape(-1,3);trip=flat[faces.reshape(-1,3)]
 volumes=np.einsum('ij,ij->i',trip[:,0],np.cross(trip[:,1],trip[:,2])).reshape(count,-1).sum(1)/6
 assert abs(volumes).min()>1e-14
 negative=volumes<0;faces[negative]=faces[negative][:,:,[0,2,1]]
 # Own native source pigment is interpolated only along its own parent flow.
 cc=np.clip(np.rint(interpolate(pigments,parameter)),0,255).astype('u1');cc[:,:,3]=255
 cc=np.concatenate([np.repeat(cc[:,:,None,:],sides,axis=2).reshape(count,stations*sides,4),cc[:,0:1],cc[:,-1:]],1)
 uv=np.empty((count,per,2));arc=np.c_[np.zeros(count),np.cumsum(np.linalg.norm(np.diff(centres,axis=1),axis=2),axis=1)]
 uv[:,:stations*sides,0]=np.tile(np.arange(sides)/sides,(count,stations))
 uv[:,:stations*sides,1]=np.repeat(arc, sides,axis=1)
 uv[:,stations*sides:,:]=np.stack([np.c_[np.zeros(count),np.zeros(count)],np.c_[np.zeros(count),arc[:,-1]]],axis=1)
 xyz=vertices.reshape(-1,3).astype('<f4');normal=normal.reshape(-1,3).astype('<f4');tan=tan.reshape(-1,4).astype('<f4');uv=uv.reshape(-1,2).astype('<f4')
 assert np.isfinite(xyz).all() and np.isfinite(normal).all() and np.isfinite(tan).all() and np.isfinite(uv).all()
 assert np.max(abs(np.linalg.norm(normal,axis=1)-1))<1e-5
 assert np.max(abs((normal*tan[:,:3]).sum(1)))<1e-5
 assert np.max(abs(np.linalg.norm(tan[:,:3],axis=1)-1))<1e-5
 proof=dict(source_R7_manifest=str(R7),source_R7_glb_sha256=source7['sha256'],
   source_macro_curves=parents,source_macro_centres_sha256=original_macro_sha,interpreted_laid_macro_centres_sha256=interpreted_macro_sha,
   own_grey_flow_interpretation=dict(planar_length_factor=1.45,lateral_curl_factor=.25,normal_loft_factor=.65,not_a_manufacturer_fibre_measurement=True),
   independent_children_per_parent=children,individual_fibres=count,stations=stations,closed_section_sides=sides,vertices_per_fibre=per,
   single_fibre_root_width_m=[.00020,.00060],single_fibre_free_tip_width_m=[.00003,.00008],
   independently_varied_length_parent_parameter=[.72,1.14],independent_root_offset_phase_tip_spread=True,
   coarse_coherent_macroflow_preserved_but_no_common_tip_boundary=True,
   no_haircards_no_alpha_no_broad_visible_carrier=True,own_source_linear_pigment_only=True,
   alpha_opaque_only=True,analytical_smooth_cylindrical_normal=True,
   tangent_orthogonal_unit_and_finite=True,positive_closed_volumes=True,edge_restrained_fibres=int(bad.sum()),
   no_photo_lighting_or_shadow_map=True,physical_fine_fur_is_photo_interpretation=True)
 return xyz,normal,uv,tan,cc.reshape(-1,4),faces.reshape(-1,3),proof

def build():
 assert sha(R7)==R7SHA and sha(B.SOURCE)==B.SOURCE_SHA
 old=next(e for e in json.loads(B.SOURCE.read_text())if e['sku']==SKU)
 source7=next(e for e in json.loads(R7.read_text())if e['sku']==SKU)
 assert sha(old['glb_path'])==old['sha256'] and sha(source7['glb_path'])==source7['sha256']
 out=D/'models'/old['id'];assert not out.exists();out.parent.mkdir(exist_ok=True)
 subprocess.run(['/usr/bin/ditto','--clone',old['asset_dir'],str(out)],check=True)
 od,ob=glb(old['glb_path']);d=copy.deepcopy(od);binary=bytearray(ob)
 xyz,normal,uv,tangent,colours,faces,proof=fine_fibres(source7,od,ob)
 print('FIBRES',54000,'VERTICES',len(xyz),'TRIANGLES',len(faces),flush=True)
 def view(content,target=None):
  binary.extend(b'\0'*(-len(binary)%4));v=dict(buffer=0,byteOffset=len(binary),byteLength=len(content));binary.extend(content)
  if target:v['target']=target
  d['bufferViews'].append(v);return len(d['bufferViews'])-1
 def acc(a,kind,component=5126,target=34962):
  a=np.asarray(a,'<u4'if component==5125 else'u1'if component==5121 else'<f4');i=len(d['accessors'])
  item=dict(bufferView=view(a.tobytes(),target),componentType=component,count=len(a),type=kind,min=a.min(0).tolist(),max=a.max(0).tolist())
  if component==5121:item['normalized']=True
  d['accessors'].append(item);return i
 attrs=dict(POSITION=acc(xyz,'VEC3'),NORMAL=acc(normal,'VEC3'),TEXCOORD_0=acc(uv,'VEC2'),TANGENT=acc(tangent,'VEC4'),COLOR_0=acc(colours,'VEC4',5121))
 indices=acc(faces.reshape(-1,1),'SCALAR',5125,34963)
 material=dict(name='own-grey-independent-fine-physical-fibres',pbrMetallicRoughness=dict(baseColorFactor=[1,1,1,1],metallicFactor=0.,roughnessFactor=.85),alphaMode='OPAQUE',doubleSided=True,
   extensions=dict(KHR_materials_sheen=dict(sheenColorFactor=[.65,.65,.65],sheenRoughnessFactor=.85)))
 mi=len(d['materials']);d['materials'].append(material);mesh=len(d['meshes']);name='54000-free-tapered-individual-grey-fibres-no-carrier'
 d['meshes'].append(dict(name=name,primitives=[dict(attributes=attrs,indices=indices,material=mi,mode=4)]))
 node=len(d['nodes']);d['nodes'].append(dict(name=name,mesh=mesh));d['scenes'][0]['nodes'].append(node)
 if 'KHR_materials_sheen'not in d.get('extensionsUsed',[]):d.setdefault('extensionsUsed',[]).append('KHR_materials_sheen')
 oldpos=np.concatenate([B.array(od,ob,p['attributes']['POSITION'])for m in od['meshes']for p in m['primitives']]);allpos=np.r_[oldpos,xyz]
 meta=copy.deepcopy(od['extras']['metadata']);meta.update(dimensions_cm=((allpos.max(0)-allpos.min(0))*100).tolist(),
   model_revision='own-grey-independent-long-laid-free-fibres-candidate-R11',
   quality_label='Koyu dip ve açık uçlu uzun ince lifler · Yumuşak dört kat · Yaklaşık ölçek')
 meta['quality_note']+=(' Tutam akışı kendi önceki merkez eğrilerinden korunarak 54.000 ayrı ince kapalı life ayrıldı; '
   'her lifin boyu, fazı, kökü ve serbest ucu farklıdır. Geniş kart/atlas/alfa taşıyıcısı yoktur. '
   'Lineer COLOR_0 yalnız bu gri ürünün kendi koyu dip/açık uç pigmentinden gelir; nötr faktör1 uygulanır. '
   'Alt-piksel gerçek zamanlı görünüm ve liflerin gölge davranışı ayrıca denetlenmelidir.')
 meta['source_evidence_files']=meta['source_evidence_files']+[str(R7),str(out/'R5-prefix-own-pigment-and-independent-fibre-proof.json')]
 d['extras']['metadata']=meta
 target=out/Path(old['glb_path']).name;write_glb(target,d,bytes(binary));nd,nb=glb(target);assert nb[:len(ob)]==ob
 attrs_same=[]
 for mesh in od['meshes']:
  for prim in mesh['primitives']:
   for key,i in {**prim['attributes'],'indices':prim['indices']}.items():
    assert attr(od,ob,i)==attr(nd,nb,i);attrs_same.append(dict(mesh=mesh['name'],attribute=key,sha256=attr(nd,nb,i),byte_identical=True))
 model=json.loads((out/'model.json').read_text());model['metadata']=meta
 model['materials']['own-grey-independent-fine-physical-fibres']=dict(baseColorFactor=[1,1,1,1],metallic=0,roughness=.85,doubleSided=True,
   extras=dict(vertex_color_single_native_pigment_source=True,no_carrier_no_alpha=True,physical_sheen=dict(sheenColorFactor=[.65,.65,.65],sheenRoughnessFactor=.85)))
 model['meshes'].append(dict(name=name,material='own-grey-independent-fine-physical-fibres',positions=xyz.reshape(-1).tolist(),normals=normal.reshape(-1).tolist(),uvs=uv.reshape(-1).tolist(),indices=faces.reshape(-1).tolist(),colorsLinearNormalizedBytes=colours.reshape(-1).tolist()))
 dump(out/'model.json',model)
 e=copy.deepcopy(old);e.update(meta,asset_dir=str(out),model_path=str(out/'model.json'),glb_path=str(target),sha256=sha(target),bytes=target.stat().st_size,
   geometry_validation=str(out/'geometry-validation.json'),material_validation=str(out/'material-validation.json'),quality_pending=True,actual_browser_review_passed=False,model_status='ready_for_browser_review',frozen=False)
 e.pop('native_renders',None);e.pop('independent_validation_file',None);assert e['bytes']<96*2**20
 maps=[]
 for im in nd['images']:
  v=nd['bufferViews'][im['bufferView']];start=v.get('byteOffset',0);content=nb[start:start+v['byteLength']]
  maps.append(dict(file=im['name'],path=str(out/im['name']),sha256=hashlib.sha256(content).hexdigest(),native_resolution=list(Image.open(io.BytesIO(content)).size)))
 dump(out/'material-validation.json',dict(valid=True,maps=maps,own_native_linear_COLOR0_primary_pigment=True,
   neutral_base_factor_preserves_own_grey_pigment=True,no_new_RGB_texture=True,no_alpha_or_hair_atlas=True,no_baked_lighting=True,
   smooth_physical_cylindrical_normals=True,physical_PBR_material=material))
 dump(out/'geometry-validation.json',dict(valid=True,source_R5_old_attributes=attrs_same,fine_independent_fibres=proof))
 pngs=[]
 for p in Path(old['asset_dir']).glob('*.png'):
  if p.name in {'on.png','yan.png','on-capraz.png','ustten.png','arka.png'}:continue
  assert sha(p)==sha(out/p.name);pngs.append(dict(name=p.name,sha256=sha(p),unchanged=True))
 proof.update(source_R5_manifest=str(B.SOURCE),source_R5_manifest_sha256=B.SOURCE_SHA,
   old_R5_complete_BIN_prefix_byte_identical=True,old_R5_BIN_prefix_sha256=hashlib.sha256(ob).hexdigest(),
   R5_original_glb_unchanged=sha(old['glb_path'])==old['sha256'],R7_original_glb_unchanged=sha(source7['glb_path'])==source7['sha256'],
   original_own_PNGs=pngs,own_JPEGs_unchanged=all(sha(i['path'])==i['sha256']for i in old['original_images']),
   actual_viewer_four_angles_close_and_aliasing_shadow_gate_required=True,ready_claim=False)
 dump(out/'R5-prefix-own-pigment-and-independent-fibre-proof.json',proof);dump(out/'entry.json',e)
 result=V.check(e);dump(out/'independent-binary-fine-fibres-check.json',result)
 return e

if __name__=='__main__':
 manifest=D/'candidate-own-grey-independent-long-laid-fibres-01-manifest.json';assert not manifest.exists()
 e=build();dump(manifest,[e]);print(manifest,sha(manifest),e['bytes'],e['sha256'],flush=True)
