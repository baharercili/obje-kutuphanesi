"""Separate revision: smooth nonradial stuffed shapes and visible fleece pile."""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
import json,math,shutil
import numpy as np
from PIL import Image,ImageDraw,ImageFilter
import build_shaped_softgoods as C
S=C.S;B=C.B;T=math.tau;BASE=S.R;V=BASE/'pile-revision-01'

def triangulate(outline):
 p=np.array(outline,float)
 p=p[::2]
 if np.sum(p[:,0]*np.roll(p[:,1],-1)-p[:,1]*np.roll(p[:,0],-1))<0:p=p[::-1]
 ids=list(range(len(p)));faces=[]
 def cross(a,b,c):
  x,y=b-a,c-a;return float(x[0]*y[1]-x[1]*y[0])
 def arraycross(x,y):return x[0]*y[:,1]-x[1]*y[:,0]
 while len(ids)>3:
  found=False
  for n,b in enumerate(ids):
   a=ids[n-1];c=ids[(n+1)%len(ids)]
   if cross(p[a],p[b],p[c])<=1e-11:continue
   others=[j for j in ids if j not in [a,b,c]];q=p[others];inside=(arraycross(p[b]-p[a],q-p[a])>1e-12)&(arraycross(p[c]-p[b],q-p[b])>1e-12)&(arraycross(p[a]-p[c],q-p[c])>1e-12)
   if inside.any():continue
   faces.append((a,b,c));ids.pop(n);found=True;break
  assert found,'Own outline must remain a simple polygon'
 faces.append(tuple(ids));boundary={tuple(sorted((j,(j+1)%len(p))))for j in range(len(p))};points=p.tolist()
 for _ in range(3):
  mids={};newboundary=set();out=[]
  def midpoint(a,b):
   key=tuple(sorted((a,b)))
   if key not in mids:
    mids[key]=len(points);points.append(((np.array(points[a])+points[b])/2).tolist())
    if key in boundary:newboundary.update([tuple(sorted((a,mids[key]))),tuple(sorted((b,mids[key])))])
   return mids[key]
  for a,b,c in faces:
   x,y,z=midpoint(a,b),midpoint(b,c),midpoint(c,a);out.extend([(a,x,z),(x,b,y),(z,y,c),(x,y,z)])
  faces=out;boundary=newboundary
 p=np.array(points);fixed={v for e in boundary for v in e};adj=[set()for _ in p]
 for a,b,c in faces:adj[a].update([b,c]);adj[b].update([a,c]);adj[c].update([a,b])
 for _ in range(18):
  q=p.copy()
  for i,links in enumerate(adj):
   if i not in fixed:q[i]=p[i]*.85+p[list(links)].mean(0)*.15
  p=q
 return p,faces,boundary

def surface(outline,w,h,d,tile):
 outline=C.smooth_outline(outline,256);size=181;mask=Image.new('L',(size,size));ImageDraw.Draw(mask).polygon([tuple(p*(size-1))for p in outline],fill=255);inside=np.asarray(mask)>0;cells=inside[:-1,:-1]&inside[1:,:-1]&inside[:-1,1:]&inside[1:,1:];vertex_ids={};xy=[];faces=[]
 def vid(row,col):
  key=(row,col)
  if key not in vertex_ids:vertex_ids[key]=len(xy);xy.append([col/(size-1),row/(size-1)])
  return vertex_ids[key]
 for row,col in zip(*np.nonzero(cells)):
  a,b,c,e=vid(row,col),vid(row,col+1),vid(row+1,col),vid(row+1,col+1);faces.extend([(a,b,c),(b,e,c)])
 edges={}
 for tri in faces:
  for a,b in zip(tri,tri[1:]+tri[:1]):key=tuple(sorted((a,b)));edges[key]=edges.get(key,0)+1
 boundary=[e for e,count in edges.items()if count==1];fixed={v for e in boundary for v in e};links={i:[]for i in fixed}
 for a,b in boundary:links[a].append(b);links[b].append(a)
 assert all(len(x)==2 for x in links.values()),'Single closed cloth contour required'
 xy=np.array(xy);original=xy.copy()
 for _ in range(4):
  q=xy.copy()
  for i,ns in links.items():q[i]=xy[i]*.5+xy[ns].mean(0)*.5
  xy=q
 faces=[(a,b,c)for a,b,c in faces if abs((xy[b,0]-xy[a,0])*(xy[c,1]-xy[a,1])-(xy[b,1]-xy[a,1])*(xy[c,0]-xy[a,0]))>1e-10]
 used=sorted({i for tri in faces for i in tri});remap={old:new for new,old in enumerate(used)};xy=xy[used];faces=[tuple(remap[i]for i in tri)for tri in faces];vertex_ids={key:remap[i]for key,i in vertex_ids.items()if i in remap};edges={}
 for tri in faces:
  for a,b in zip(tri,tri[1:]+tri[:1]):key=tuple(sorted((a,b)));edges[key]=edges.get(key,0)+1
 boundary=[e for e,count in edges.items()if count==1];fixed={i for e in boundary for i in e}
 interior=np.zeros((size,size),bool)
 for key,i in vertex_ids.items():
  if i not in fixed:interior[key]=True
 u=np.zeros((size,size),float)
 # A regular Cartesian interior avoids both radial overlap and the long,
 # poorly conditioned triangles of a contour fan near the perimeter.
 for _ in range(2800):
  q=np.zeros_like(u);q[1:-1,1:-1]=(u[2:,1:-1]+u[:-2,1:-1]+u[1:-1,2:]+u[1:-1,:-2]+1)/4;u=q*interior
 u/=u.max()
 def point(px,py,side):
  xx,yy=np.clip(np.array([px,py])*(size-1),0,size-1-1e-7);ix,iy=int(xx),int(yy);fx,fy=xx-ix,yy-iy;z0=u[iy,ix]*(1-fx)*(1-fy)+u[iy,ix+1]*fx*(1-fy)+u[iy+1,ix]*(1-fx)*fy+u[iy+1,ix+1]*fx*fy;z=.0014+(d/2-.0014)*max(0,z0)**.43;return np.array([(px-.5)*w,py*h,z*side])
 vertices=[];uv=[]
 for side in [-1,1]:
  for i,(px,py)in enumerate(xy):
   pt=point(px,py,side)
   if i in fixed:pt[2]=side*.0014
   vertices.append(pt);uv.append((pt[0]/tile,pt[1]/tile))
 n=len(xy);f=[(a,c,b)for a,b,c in faces]+[(a+n,b+n,c+n)for a,b,c in faces]
 for a,b in boundary:f.extend([(a,b,a+n),(b,b+n,a+n)])
 return [B.solid('continuous-cartesian-smooth-filled-body','fabric',vertices,f,uv)],point,outline

def visible_pile(pid,point,outline,w,h,count=8500,length=.005):
 rng=np.random.default_rng(int(pid));mask=Image.new('L',(1024,1024));ImageDraw.Draw(mask).polygon([tuple(p*1023)for p in outline],fill=255);a=np.asarray(mask);fibres=[];accepted=0
 while accepted<count:
  px,py=rng.uniform(.001,.999,2)
  if not a[int(py*1023),int(px*1023)]:continue
  accepted+=1;side=1 if accepted%2 else-1;p=point(px,py,side);eps=.0008;dx=point(min(.9999,px+eps),py,side)-point(max(.0001,px-eps),py,side);dy=point(px,min(.9999,py+eps),side)-point(px,max(.0001,py-eps),side);normal=np.cross(dx,dy)
  if normal[2]*side<0:normal=-normal
  normal/=max(np.linalg.norm(normal),1e-10);tangent=dx/max(np.linalg.norm(dx),1e-10);across=np.cross(normal,tangent);angle=rng.random()*T;tangent=tangent*math.cos(angle)+across*math.sin(angle);strand=length*rng.uniform(.65,1.35);pts=[p-normal*.00018,p+normal*strand*.55+tangent*strand*.23,p+normal*strand*.85+tangent*strand*.51,p+normal*strand*.60+tangent*strand*.75];fibres.append(B.tube('closed-soft-curled-fleece-tuft','fabric',pts,.00027,.00016,3,False,guide=tangent.tolist()))
 # Many small curled physical fibres are also placed at the actual perimeter,
 # where they remain visible as a soft outline in a full-object browser view.
 for j in range(1500):
  t=rng.uniform(0,len(outline));i=int(t);p=outline[i]*(1-(t-i))+outline[(i+1)%len(outline)]*(t-i);edge=outline[(i+1)%len(outline)]-outline[i];normal=np.array([edge[1]*h,-edge[0]*w,0]);normal/=np.linalg.norm(normal);base=np.array([(p[0]-.5)*w,p[1]*h,0]);tangent=np.array([0,0,1.]);strand=length*rng.uniform(.45,1.0);pts=[base-normal*.0002,base+normal*strand*.6+tangent*strand*.12,base+normal*strand*.85+tangent*strand*.35];fibres.append(B.tube('closed-soft-silhouette-fleece-tuft','fabric',pts,.00025,.00015,3,False,guide=tangent.tolist()))
 return S.merge(fibres,'visible-curled-fleece-and-soft-perimeter-pile','fabric')

def fleece_material(pid,donor,box,hero):
 ma=S.material(pid,'fleece-own-native',donor,box,hero,'pile',.04);out=V/'materials'/pid/'fleece-own-native';n=2048;tile=ma['extras']['atlas_tile_metres'];rng=np.random.default_rng(int(pid));height=Image.new('L',(n,n),128);draw=ImageDraw.Draw(height)
 for _ in range(round((tile/.0017)**2)):
  x,y=rng.uniform(0,n,2);radius=rng.uniform(.00045,.0009)*n/tile;angle=rng.uniform(0,T);pts=[(x+radius*math.cos(angle+t),y+radius*.7*math.sin(angle+t))for t in np.linspace(0,math.pi*1.6,9)];draw.line(pts,fill=int(rng.uniform(165,245)),width=max(1,round(.00023*n/tile)),joint='curve')
 field=np.asarray(height.filter(ImageFilter.GaussianBlur(.7)),float)/255;dy,dx=np.gradient(field*5);normal=np.stack([-dx,dy,np.ones_like(dx)],2);normal/=np.linalg.norm(normal,axis=2,keepdims=True);Image.fromarray(np.rint((normal+1)*127.5).astype(np.uint8)).save(out/'normal-2k.png');orm=np.array(Image.open(out/'orm-2k.png'));orm[:,:,1]=np.clip(240-(field-.5)*18,215,250);Image.fromarray(orm).save(out/'orm-2k.png');prov=json.loads((out/'texture-provenance.json').read_text());prov.update(procedural_fleece_relief=True,estimated_curl_diameter_mm=[.9,1.8],estimated_fibre_width_mm=.23,operations=prov['operations']+['Source-informed dense curled fleece relief at estimated0.9–1.8mm clump diameter, separate physical5mm tufts and soft silhouette; no synthetic photographic detail claimed']);C.dump(out/'texture-provenance.json',prov);ma['normalScale']=1.15;ma['extras']['physical_sheen']=dict(sheenColorFactor=[.30,.29,.27],sheenRoughnessFactor=.95);return ma

def main():
 assert not(V/'FINAL-FROZEN.json').exists();V.mkdir(exist_ok=True);shutil.copyfile(BASE/'joined-softgoods-queue.json',V/'joined-softgoods-queue.json');old={e['sku']:e for e in json.loads((BASE/'frozen-batch-04-manifest.json').read_text())};data={pid:C.own(pid)for pid in ['1271068001','1109219001','1352575001']};C.R=V;S.R=V;C.dump(V/'manifest.json',[])
 for pid,(cap,ep,refs,hero)in data.items():
  row=old[pid];w,h,d=np.array(row['dimensions_cm'])/100;outline=C.CLOUD if pid=='1109219001'else C.BEAR if pid=='1352575001'else[(.5+.5*math.copysign(abs(math.cos(t))**.25,math.cos(t)),.5+.5*math.copysign(abs(math.sin(t))**.25,math.sin(t)))for t in np.linspace(0,T,48,endpoint=False)];donor=next(r for r in refs if ('426ce6eff2d5'if pid=='1109219001'else'cc829efc45b5'if pid=='1352575001'else'f5c0572abe7e')in r['path']);box=[400,1100,912,1612]if pid=='1109219001'else[300,1300,556,1556]if pid=='1352575001'else[500,1000,1012,1512];ma=fleece_material(pid,donor,box,hero);parts,point,outline=surface(outline,w,h,d-.008,ma['extras']['atlas_tile_metres']);parts.append(visible_pile(pid,point,outline,w,h,length=.0055 if pid=='1352575001'else .0045));note=row['scale_note']+' Ayrı hav revizyonunda kesintisiz hacim alanı ve fotoğraftan tahmini0,45–0,55cm kıvrılmış lifler kullanıldı; resmî en/yükseklik dış sınırı korunur.';C.finish(pid,parts,dict(fabric=ma),cap,ep,refs,hero,[w,h,d],row['official_measurements'],row['product_form'],['filling_depth_cm','pile_length_and_distribution','fleece_relief_scale'],note,dict(id=row['id'],estimated_filling_depth_cm=d*100,quality_label='Yaklaşık hav görünümü',quality_status='preview_limited',quality_note='Yumuşak hav kendi kumaş fotoğrafı, fiziksel kıvrılmış lifler ve ince yüzey kabartısıyla yorumlandı; birebir lif yoğunluğu ve arka dikiş konumu tahmindir.',replaces_frozen_manifest=str(BASE/'frozen-batch-04-manifest.json'),body_profile='Smooth Poisson interior volume on a nonradial triangulated surface; no intersecting radial cloud lobes.'))

if __name__=='__main__':main()
