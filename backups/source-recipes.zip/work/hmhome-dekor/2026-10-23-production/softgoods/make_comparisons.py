from pathlib import Path
import json,sys,math
from PIL import Image,ImageOps,ImageDraw
R=Path(__file__).resolve().parent;es=json.loads(Path(sys.argv[1]).read_text());prefix=sys.argv[2]
for page in range(math.ceil(len(es)/4)):
 group=es[page*4:(page+1)*4];c=Image.new('RGB',(2500,len(group)*520),'white');d=ImageDraw.Draw(c)
 for j,e in enumerate(group):
  paths=[e['original_image']]+[str(Path(e['asset_dir'])/(v+'.png'))for v in['on','yan','on-capraz','arka']]
  for i,f in enumerate(paths):
   im=Image.open(f).convert('RGBA');bg=Image.new('RGBA',im.size,'white');bg.alpha_composite(im);im=ImageOps.contain(bg.convert('RGB'),(490,470));c.paste(im,(i*500+(500-im.width)//2,j*520));d.text((i*500+5,j*520+480),e['sku']+' '+['Ownsource','Front','Side','45','Reverse'][i],fill='black')
 c.save(R/(prefix+'-'+str(page+1)+'.jpg'),quality=95)
