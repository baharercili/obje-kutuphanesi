"""Own-SKU folded textiles. Official unfolded plans and estimated poses stay distinct."""
import sys
sys.dont_write_bytecode=True
import math,json,re
import numpy as np
from PIL import Image,ImageFilter
import build_shaped_softgoods as C
import build_hm_rugs as RG
S=C.S;B=C.B;R=C.R;T=math.tau
KNIT={'1333785001','1333785003'}
FUR={'1355345001','1355863001','1355863002','1357963001'}
QUILT={'1355863001','1355863002'}
FRINGE={
 '1329726004':.075,'1329726006':.075,'1333746001':.035,'1333746002':.035,
 '1338614001':.035,'1338614002':.035,'1338615001':.15,'1338616001':.025,
 '1338618002':.18,'1338618003':.18,'1338618004':.18,'1338618006':.18,
 '1338619002':.055,'1348754001':.22,'1348754003':.22,'1348754005':.22,
 '1348754007':.22,'1348907001':.04,'1348907002':.04}
STRIPES={'1333746001','1333746002','1329726004','1329726006'}
PATTERN={'1298464008','1338616001','1338618004','1338618006','1348754001','1348754003','1348907001','1348907002'}|STRIPES

def body_box(pid,hero):
 b=RG.source_box(hero);x0,y0,x1,y1=b;w=x1-x0;h=y1-y0
 # The flat front cloth is retained; outside shadows, folded underlay and all
 # photographic tassels are excluded. The tassels are separate closed yarns.
 end=.58 if pid.startswith('1348754') else .71 if pid.startswith('1338618')or pid=='1338615001' else .82 if pid.startswith('1329726') else .90 if pid in FRINGE else .97
 return [round(x0+w*.028),round(y0+h*.025),round(x1-w*.028),round(y0+h*end)]

def texture(pid,hero):
 out=R/'materials'/pid/'own-folded-throw';out.mkdir(parents=True,exist_ok=True);im=Image.open(hero['path']).convert('RGB');box=body_box(pid,hero);crop=im.crop(box);crop.save(out/'donor-crop-native.png');a=np.asarray(crop,float);lum=a.mean(2);n=2048;rng=np.random.default_rng(int(pid));yy,xx=np.mgrid[0:n,0:n].astype(float)/(n-1)
 # A clean native micro patch is kept separately, never stretched to fabricate
 # additional photo detail. Macro patterns are measured from this SKU alone.
 cx,cy=crop.width//2,crop.height//2;microbox=[cx-128,cy-128,cx+128,cy+128];micro=crop.crop(microbox);micro.save(out/'cloth-micro-native.png');m=np.asarray(micro,float);sigma=15 if pid in FUR or pid=='1338615001'else 5 if pid in KNIT else 6 if pid.startswith('1348754')else 1.25;low=np.asarray(micro.filter(ImageFilter.GaussianBlur(sigma)),float);fine=m-low;edge=12
 for ax in [0,1]:
  for j in range(edge):
   aa=[slice(None)]*3;bb=aa.copy();aa[ax]=j;bb[ax]=-1-j;aa=tuple(aa);bb=tuple(bb);wt=(1-j/edge)**2;mid=(fine[aa]+fine[bb])/2;fine[aa]=fine[aa]*(1-wt)+mid*wt;fine[bb]=fine[bb]*(1-wt)+mid*wt
 coord=np.arange(n)%256;micrograin=fine[coord[:,None],coord[None,:]]*(1. if pid in FUR else .85 if pid in KNIT else .75 if pid=='1338615001'or pid.startswith('1348754')else .35);palette=[];method='Own native256px yarn residual repeated without upscaling, with intrinsic mean from own front cloth.'
 if pid in STRIPES:
  # Row medians discard wrinkles and side-fold shadows while retaining the
  # exact observed broad and grouped stripe sequence.
  rows=np.median(a[:,round(a.shape[1]*.15):round(a.shape[1]*.85)],axis=1);profile=Image.fromarray(np.clip(rows[:,None,:],0,255).astype(np.uint8)).resize((1,n),Image.Resampling.BILINEAR).filter(ImageFilter.GaussianBlur(.6));rgb=np.repeat(np.asarray(profile,float),n,axis=1);method='Own-SKU row-median stripe colour/spacing; broad photographic folds excluded. Hidden unfolded stripe phase is interpreted.'
 elif pid=='1338616001':
  chroma=a[:,:,0]-a[:,:,2];mask=chroma>np.quantile(chroma,.60);ink=np.median(a[chroma>np.quantile(chroma,.75)],axis=0);base=np.median(a[~mask&(lum>np.quantile(lum,.55))],axis=0);weight=np.asarray(Image.fromarray((mask*255).astype(np.uint8)).resize((n,n),Image.Resampling.BILINEAR),float)/255;rgb=base*(1-weight[:,:,None])+ink*weight[:,:,None];palette=[base.tolist(),ink.tolist()];method='Own floral jacquard isolated by yarn chroma, reconstructed with two intrinsic own-source yarn colours. No photographed fold/background pixels mapped.'
 elif pid=='1298464008':
  mask=lum<100;base=np.median(a[lum>np.quantile(lum,.65)],axis=0);ink=np.median(a[mask],axis=0);weight=np.asarray(Image.fromarray((mask*255).astype(np.uint8)).resize((n,n),Image.Resampling.BILINEAR),float)/255;rgb=base*(1-weight[:,:,None])+ink*weight[:,:,None];palette=[base.tolist(),ink.tolist()];method='Own black cross/edge yarn mask with two own-source intrinsic colours; broad photographed fold shading excluded.'
 elif pid in {'1338618004','1338618006'}:
  profiles=[]
  for ax in [0,1]:
   line=np.median(lum,axis=ax);lowline=np.asarray(Image.fromarray(line[None,:].astype(np.uint8)).filter(ImageFilter.GaussianBlur(22)),float)[0];res=line-lowline;on=(res<-5)if pid.endswith('004')else(res>12)
   if pid.endswith('006'):margin=round(len(on)*.05);on[:margin]=False;on[-margin:]=False
   native=np.asarray(Image.fromarray((on[None,:]*255).astype(np.uint8)).resize((n,1),Image.Resampling.BILINEAR),float)[0]/255;profiles.append(native)
  weight=np.maximum(profiles[0][None,:],profiles[1][:,None]);base=np.median(a[(lum>np.quantile(lum,.40))&(lum<np.quantile(lum,.65))],axis=0);ink=np.median(a[lum<np.quantile(lum,.08)],axis=0)if pid.endswith('004')else np.median(a[lum>np.quantile(lum,.93)],axis=0);rgb=base*(1-weight[:,:,None])+ink*weight[:,:,None];palette=[base.tolist(),ink.tolist()];method='Own-SKU horizontal/vertical check-line profiles isolated above the fringe; two intrinsic own cloth yarn colours. All photographic fringe pixels excluded.'
 elif pid in PATTERN:
  # Colour classes preserve the artwork/stripe geometry without wrapping a
  # marketing photograph or its broad illumination over the cloth.
  rgb=np.asarray(crop.resize((n,n),Image.Resampling.BILINEAR),float);method='Own isolated flat front cloth pattern in native RGB, without palette quantization or suppression of rare yarn colours. Unseen unfolded/reverse pattern phase is interpreted.'
 else:
  base=np.median(a.reshape(-1,3),axis=0);rgb=np.broadcast_to(base,(n,n,3)).copy();palette=[base.tolist()]
 rgb=np.clip(rgb+micrograin,0,255);Image.fromarray(rgb.astype(np.uint8)).save(out/'albedo-2k.png');height=micrograin.mean(2)/255*2.7;pitch=3.2 if pid in FUR else 2.2;hgrid=.025*np.sin(T*xx*n/pitch)*np.cos(T*yy*n/(pitch*1.12));height+=hgrid
 if pid in KNIT:
  diag=np.minimum(abs(((xx*3+yy*5+.5)%1)-.5),abs(((xx*3-yy*5+.5)%1)-.5));height+=.14*np.exp(-(diag/.045)**2)
 dy,dx=np.gradient(height);normal=np.stack([-dx*3,dy*3,np.ones_like(dx)],2);normal/=np.linalg.norm(normal,axis=2,keepdims=True);Image.fromarray(np.rint((normal+1)*127.5).astype(np.uint8)).save(out/'normal-2k.png');orm=np.zeros((n,n,3),np.uint8);orm[:,:,0]=255;orm[:,:,1]=np.clip(241-height*38,213,250);Image.fromarray(orm).save(out/'orm-2k.png');C.dump(out/'texture-provenance.json',dict(source_path=hero['path'],source_sha256=hero['sha256'],source_pixels=hero['pixels'],crop_box_original_pixels=box,crop_pixels=list(crop.size),micro_crop_relative_pixels=microbox,micro_unique_pixels=[256,256],mapped_resolution=[n,n],operations=['Immutable ownSKU front-cloth integer crop; exterior backdrop and photographic fringe excluded',method,'Native micro-grain repeats;2K procedural normal/roughness do not claim2K unique photographic detail'],palette_rgb=palette,source_master_unchanged=C.sha(hero['path'])==hero['sha256'],source_upscaled=False,full_marketing_photo_wrapped=False,background_pixels_baked=False,pattern_phase_photo_interpreted=True,display_pose='Folded textile, not a filled cushion'))
 ma=dict(baseColorFactor=[1,1,1,1],metallic=1,roughness=1,baseColorTexture=str(out/'albedo-2k.png'),normalTexture=str(out/'normal-2k.png'),metallicRoughnessTexture=str(out/'orm-2k.png'),normalScale=.85 if pid in KNIT|FUR else .55,doubleSided=False,extras=dict(intrinsic_material=True,photo_pixels_baked=False,baked_reflections=False,texture_provenance=str(out/'texture-provenance.json'),atlas_tile_metres=1.,physical_sheen=dict(sheenColorFactor=[.12,.10,.08]if pid in FUR else[.055,.045,.035],sheenRoughnessFactor=.94)))
 # The yarn end/hem colour comes from the same textile; it carries no full
 # front image and cannot show a ghost pattern on narrow tubes.
 plain=R/'materials'/pid/'own-throw-yarn';plain.mkdir(parents=True,exist_ok=True);colour=np.median(a.reshape(-1,3),axis=0)
 if pid in {'1298464008','1348907001'}:colour=np.array([40,38,35])
 if pid.startswith('1348754')or pid.startswith('1329726'):
  whole=RG.source_box(hero);x0,y0,x1,y1=whole;area=np.asarray(im.crop((x0+40,round(y0+(y1-y0)*.68),x1-40,round(y0+(y1-y0)*.93))),float);al=area.mean(2);colour=np.median(area[(al>np.quantile(al,.78))&(area[:,:,0]-area[:,:,2]>5)],axis=0)
 for key,value in [('albedo',colour),('normal',[128,128,255]),('orm',[255,242,0])]:Image.new('RGB',(4,4),tuple(round(float(v))for v in value)).save(plain/(key+'.png'))
 yarn=json.loads(json.dumps(ma));yarn.update(baseColorTexture=str(plain/'albedo.png'));yarn['extras'].update(constant_colour_PBR_map_no_artificial_upscale=True);return ma,yarn,box

def folded_cloth(pid,w,h,fringe):
 parts=[];thick=.0025 if pid not in FUR else .004;outer=.018 if pid not in FUR else .025;front_end=max(.008,fringe);N=81;states=[]
 def point(u,v,front=True,r=outer,layer=0):
  y=front_end+(h-r-front_end)*v;x=(u-.5)*w;z=r+thick/2+.002*math.sin(u*9+y*3/h)*math.sin(math.pi*u)*math.sin(math.pi*y/h)
  if pid in QUILT:
   dist=min([abs(u-x)for x in[1/3,2/3]]+[abs(v-y)for y in[.2,.4,.6,.8]]);z+=.004*(1-math.exp(-(dist/.025)**2))
  return np.array([x,y,z])
 for layer,r in enumerate([outer,outer*.52]):
  H=h-layer*.010;frontbottom=front_end+layer*.006;P=[]
  for y in np.linspace(frontbottom,H-r,81):P.append((float(y),r,1.,0.))
  for ang in np.linspace(0,math.pi,33)[1:]:P.append((H-r+r*math.sin(ang),r*math.cos(ang),math.cos(ang),math.sin(ang)))
  for y in np.linspace(H-r,layer*.006,81)[1:]:P.append((float(y),-r,-1.,0.))
  verts=[];uv=[];faces=[];K=len(P)
  for side in [-1,1]:
   for j,(y,z,nz,ny)in enumerate(P):
    for u in np.linspace(0,1,N):
     wave=.002*math.sin(u*9+y*3/h)*math.sin(math.pi*u)*math.sin(math.pi*y/H);z0=z+wave;edge_shrink=.006*(math.exp(-(y-frontbottom)**2/.00012)if j<81 else math.exp(-y*y/.00012));x=(u-.5)*(w-edge_shrink)
     if pid in QUILT and j<81:
      v=(y-frontbottom)/max(.001,H-r-frontbottom);dist=min([abs(u-x)for x in[1/3,2/3]]+[abs(v-q)for q in[.2,.4,.6,.8]]);z0+=.004*(1-math.exp(-(dist/.025)**2))
     verts.append((x,y+side*ny*thick/2,z0+side*nz*thick/2));uv.append((u,(H-y)/max(.001,H-frontbottom)))
  nn=N*K
  for side in [0,1]:
   for j in range(K-1):
    for i in range(N-1):a=side*nn+j*N+i;b=a+N;faces.extend([(a,b,a+1),(a+1,b,b+1)]if side==0 else[(a,a+1,b),(a+1,b+1,b)])
  edge=list(range(N))+[j*N+N-1 for j in range(1,K)]+list(range((K-1)*N+N-2,(K-1)*N-1,-1))+[j*N for j in range(K-2,0,-1)]
  for j,a in enumerate(edge):b=edge[(j+1)%len(edge)];faces.extend([(a,b,a+nn),(b,b+nn,a+nn)])
  parts.append(B.solid('closed-thin-folded-blanket-layer-'+str(layer),'fabric',verts,faces,uv));states.append((P,verts))
 # Actual short-end fringe hangs over the lower underfold, instead of being
 # photographed into the face. Individual twists are closed solids.
 rng=np.random.default_rng(int(pid));yarns=[]
 if fringe:
  chunky=pid.startswith('1348754');spacing=.028 if chunky else .011;radius=.0025 if chunky else .00075
  for x in np.arange(-w*.485,w*.485,spacing):
   length=fringe*rng.uniform(.87,1.02)
   for phase in [0,math.pi]if chunky else[0,2.1,4.2]:
    pts=[]
    bend=rng.uniform(-.008,.008)
    for f in np.linspace(0,1,11):pts.append((x+radius*1.1*math.sin(f*T*2+phase)+bend*f*f,front_end-length*f,outer+.003+radius*math.cos(f*T*2+phase)+.004*f*math.sin(x*80)))
    yarns.append(B.tube('individual-twisted-hanging-fringe-yarn','yarn',pts,radius,radius*.75,4,False,guide=[0,0,1]))
  parts.append(S.merge(yarns,'physical-observed-short-end-fringe-over-underfold','yarn'))
 if pid=='1298464008':
  stitches=[]
  for x in np.arange(-w*.495,w*.495,.006):stitches.append(B.tube('individual-black-blanket-stitch','yarn',[(x,.004,outer+.001),(x,.010,outer+.002),(x,.012,outer-.002)],.0005,.0004,4,False,guide=[1,0,0]))
  for sign in [-1,1]:
   for y in np.arange(.01,h-.015,.006):stitches.append(B.tube('individual-black-side-blanket-stitch','yarn',[(sign*(w/2-.004),y,outer+.002),(sign*w/2,y,outer),(sign*(w/2-.002),y,outer-.003)],.0005,.0004,4,False,guide=[0,1,0]))
  parts.append(S.merge(stitches,'physical-black-blanket-stitching-on-visible-cut-edges','yarn'))
 if pid in KNIT:
  ribs=[]
  for sign in [-1,1]:
   for k in range(-5,9):
    pts=[]
    for u in np.linspace(.005,.995,160):
     v=(k-sign*3*u)/5
     if .005<v<.995:p=point(u,v);p[2]+=.0015+.00035*math.sin(u*T*70);pts.append(p.tolist())
    if len(pts)>2:ribs.append(B.tube('raised-knit-diamond-cable','fabric',pts,.0006,.0005,4,False,guide=[0,0,1]))
  parts.append(S.merge(ribs,'source-observed-three-by-five-knit-diamond-relief','fabric'))
 if pid in FUR or pid.startswith('1348754')or pid=='1338615001':
  hairs=[];count=6000 if pid in FUR else 3000;length=.012 if pid=='1357963001'else .009 if pid in FUR else .007 if pid=='1338615001'else .0035
  for i in range(count):
   u,v=rng.uniform(.003,.997,2)
   if i<700:u=.001 if i%2 else .999
   p=point(u,v);side=1 if i%3 else-1
   if side==-1:p[2]=-outer
   tang=np.array([math.cos(i),math.sin(i),0]);normal=np.array([0,0,side]);l=length*rng.uniform(.65,1.35);pts=[p-normal*.0001]+[p+normal*l*.8*math.sin(math.pi*f*.8)+tang*l*.6*f for f in[.25,.5,.75,1.]];q=B.tube('closed-soft-looped-throw-fibre','fabric',[tuple(p)for p in pts],.00038 if pid in FUR else .00025,.00024 if pid in FUR else .00018,4,False,guide=tang.tolist());local=np.asarray(q['_uvs']);local=(local-local.min(0))/np.maximum(local.max(0)-local.min(0),1e-9);q['_uvs']=[tuple(np.array([u,1-v])+xy*.0005)for xy in local];hairs.append(q)
  parts.append(S.merge(hairs,'many-physical-soft-pile-and-perimeter-fibres','fabric'))
 return parts

def build(pid):
 assert pid!='1344727001','The hooded cape requires its own draped/hood geometry, not a folded rectangle.'
 cap,ep,refs,hero=C.own(pid);cap=dict(cap);pair=re.search(r'(\d+(?:[.,]\d+)?)\s*[xX×]\s*(\d+(?:[.,]\d+)?)',cap.get('sizes',''));official={};unfolded=[130.,170.]
 if pair:
  unfolded=sorted(float(x.replace(',','.'))for x in pair.groups());official=dict(unfolded_plan_label=pair.group(0),unfolded_width_cm=unfolded[0],unfolded_length_cm=unfolded[1]);size_note=f'Resmî açık plan {unfolded[0]:g}×{unfolded[1]:g} cm korunur.'
 else:
  if pid in {'1348917001','1355345001'}:unfolded=[170.,220.]
  cap.update(_size_source_kind='photo_estimated_exact_sku',_size_scope='No physical plan published in the accessible exactSKU evidence; all axes explicitly photo-estimated.');size_note=f'Resmî plan ölçüsü okunamadı. Yaklaşık {unfolded[0]:g}×{unfolded[1]:g} cm açık plan, kendi ürün fotoğrafının oranı ve aynı ürün türünün kullanım ölçeğinden yorumlandı; resmî ölçü değildir.'
 ma,yarn,box=texture(pid,hero);w,h=unfolded[0]/200,unfolded[1]/200;fringe=FRINGE.get(pid,0);parts=folded_cloth(pid,w,h,fringe);note=size_note+' Model fotoğraftaki gibi katlanmış gösterilir; iki eksende katlama varsayımı, kat sayısı, teşhir sınırları, kumaş kalınlığı ve püskül uzunluğu fotoğraf tahminidir. Görünmeyen tam açık desen devamı ve arka desen fazı kesin kaynak sayılmaz.';estimated=['folded_display_axes_cm','fold_count_and_hidden_pattern_phase','cloth_thickness_cm','fringe_length_cm','local_stitches_and_pile']+([]if official else['unfolded_width_cm','unfolded_length_cm']);extra=dict(category='Battaniye ve örtüler',source_dimensions_hwd_cm=None,official_plan_dimensions_cm=unfolded if official else None,estimated_unfolded_plan_cm=None if official else unfolded,folded_display=True,fold_count_assumption=4,estimated_folded_nominal_plan_cm=[w*100,h*100],estimated_fringe_length_cm=fringe*100,quality_label='Katlama/desen yorumu'if official else'Tahmini ölçek/desen',quality_status='photo_interpreted',quality_note=('Açık plan ölçüsü resmî; katlanmış teşhir, kalınlık ve görünmeyen desen fazı fotoğraf yorumudur.'if official else'Resmî fiziksel plan bulunmadı. Açık/katlanmış ölçek, kalınlık ve görünmeyen desen devamı fotoğraf tahminidir.'),variant_status_verbatim='ExactSKU resmî kart kimliği ve kendi fotoğrafı bağlı. Resmî ölçü yalnız official_measurements içinde yazan eksenlerdir.');C.finish(pid,parts,dict(fabric=ma,yarn=yarn),cap,ep,refs,hero,[None,None,None],official,'folded_soft_textile_blanket',estimated,note,extra)

if __name__=='__main__':
 ids=sys.argv[1:]or[e['sku']for e in json.loads((R/'joined-softgoods-queue.json').read_text())['products']if e['category_id']=='throws'and e['sku']!='1344727001']
 for pid in ids:build(pid)
