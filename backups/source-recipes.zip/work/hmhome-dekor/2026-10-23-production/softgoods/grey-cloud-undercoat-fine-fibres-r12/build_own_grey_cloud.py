"""One own-grey cloud/undercoat candidate: independent fine closed fibres, no haircards.

Every immutable R5 byte is retained. R7's 9,000 centre curves provide only the
shared macro-flow and native linear pigment. Each carries six independent fine
strands with distinct root, length, phase and free tip. There is no shared card,
alpha atlas, or broad visible carrier surface.
"""
from pathlib import Path
import copy, hashlib, importlib.util, io, json, math, subprocess, sys
import numpy as np
from PIL import Image
sys.dont_write_bytecode=True
D=Path(__file__).resolve().parent
T=D.parent.parent/'textiles';sys.path.insert(0,str(T))
from freeze_polar_knit_review_candidates import glb,sha,dump,attr
from clean_remaining_robe_material_revision02 import write_glb
import specific_binary_native_material as V
spec=importlib.util.spec_from_file_location('cream_r8_readonly_helpers',D.parent/'cream-curved-haircards-prototype-r8/build_cream_haircards.py')
H=importlib.util.module_from_spec(spec);spec.loader.exec_module(H)
B=H.B
SKU='1355345001'
R7=D.parent/'fur-clustered-own-two-r7/frozen-own-root-tip-grey-and-coherent-cream-locks-02-manifest.json'
R7SHA='d6fc6b4268c78fa2ad5cb5ed4b205a45e25a0f1401eddfe87cffef038b1e2a8d'

def cloud_field(xz):
 """Physical coverage field; no photographed shadow/lighting is sampled."""
 x,z=xz[:,0],xz[:,1]
 a=np.sin(math.tau*x/.175+.32*np.sin(math.tau*z/.31))
 b=np.cos(math.tau*z/.195+.28*np.sin(math.tau*x/.27))
 field=np.clip(.5+.50*a*b+.10*np.sin(math.tau*(x+z)/.265),0,1)
 return field

def conformal_dark_undercoat(source7,d,b):
 """Closed, thin backing sampled on the immutable R5 upper cloth triangles."""
 p=d['meshes'][0]['primitives'][0]
 positions=B.array(d,b,p['attributes']['POSITION']).astype(float)
 normals=B.array(d,b,p['attributes']['NORMAL']).astype(float)
 faces=B.array(d,b,p['indices']).reshape(-1,3)
 triangles=positions[faces];cross=np.cross(triangles[:,1]-triangles[:,0],triangles[:,2]-triangles[:,0])
 selected=cross[:,1]>1e-10;faces=faces[selected];triangles=triangles[selected]
 lo=positions[:,[0,2]].min(0);hi=positions[:,[0,2]].max(0)
 nx,nz=np.ceil((hi-lo)/.008).astype(int)+1
 xx,zz=np.meshgrid(np.linspace(lo[0]+.003,hi[0]-.003,nx),np.linspace(lo[1]+.003,hi[1]-.003,nz),indexing='ij')
 points=np.c_[xx.ravel(),zz.ravel()];bins=64;grid=[[]for _ in range(bins*bins)]
 lower=np.clip(np.floor((triangles[:,:,[0,2]].min(1)-lo)/(hi-lo)*bins).astype(int),0,bins-1)
 upper=np.clip(np.floor((triangles[:,:,[0,2]].max(1)-lo)/(hi-lo)*bins).astype(int),0,bins-1)
 for i in range(len(triangles)):
  for ix in range(lower[i,0],upper[i,0]+1):
   for iz in range(lower[i,1],upper[i,1]+1):grid[ix*bins+iz].append(i)
 cells=np.clip(np.floor((points-lo)/(hi-lo)*bins).astype(int),0,bins-1);groups=cells[:,0]*bins+cells[:,1]
 height=np.full(len(points),-np.inf);sample_n=np.zeros((len(points),3))
 for cell in np.unique(groups):
  point_indices=np.flatnonzero(groups==cell);ids=np.asarray(grid[cell],int)
  if not len(ids):continue
  tt=triangles[ids];a=tt[:,0][:,[0,2]];ab=tt[:,1][:,[0,2]]-a;ac=tt[:,2][:,[0,2]]-a
  determinant=ab[:,0]*ac[:,1]-ab[:,1]*ac[:,0];valid=abs(determinant)>1e-12
  ids=ids[valid];tt=triangles[ids];a=a[valid];ab=ab[valid];ac=ac[valid];determinant=determinant[valid]
  delta=points[point_indices,None,:]-a[None,:,:]
  w1=(delta[:,:,0]*ac[None,:,1]-delta[:,:,1]*ac[None,:,0])/determinant[None,:]
  w2=(ab[None,:,0]*delta[:,:,1]-ab[None,:,1]*delta[:,:,0])/determinant[None,:];w0=1-w1-w2
  yy=w0*tt[None,:,0,1]+w1*tt[None,:,1,1]+w2*tt[None,:,2,1]
  yy[(w0< -1e-7)|(w1< -1e-7)|(w2< -1e-7)]=-np.inf
  best=np.argmax(yy,1);ok=np.isfinite(yy[np.arange(len(point_indices)),best]);which=point_indices[ok];chosen=best[ok]
  weights=np.stack([w0[ok,chosen],w1[ok,chosen],w2[ok,chosen]],1)
  height[which]=yy[np.flatnonzero(ok),chosen]
  sample_n[which]=(normals[faces[ids[chosen]]]*weights[:,:,None]).sum(1)
 valid=np.isfinite(height)&(sample_n[:,1]>.15)
 quads=[]
 for ix in range(nx-1):
  for iz in range(nz-1):
   a=ix*nz+iz;c=a+1;bb=a+nz;dd=bb+1
   indices=[a,c,bb,dd]
   # Highest rays can jump between folded layers. Never bridge such a jump
   # with a vertical dark wall; close only gently sloping local top patches.
   if valid[indices].all() and sample_n[indices,1].min()>.65 and np.ptp(height[indices])<.006:
    quads.extend([(a,c,bb),(bb,c,dd)])
 assert len(quads)>1000
 topfaces=np.asarray(quads,np.uint32);used=np.unique(topfaces);remap=np.full(len(points),-1,int);remap[used]=np.arange(len(used));topfaces=remap[topfaces].astype(np.uint32)
 centre=np.c_[points[used,0],height[used],points[used,1]];n=sample_n[used];n/=np.linalg.norm(n,axis=1,keepdims=True)
 top=centre+n*.00085;bottom=centre+n*.00060;count=len(used)
 xyz=np.r_[top,bottom]
 edges=np.concatenate([topfaces[:,[0,1]],topfaces[:,[1,2]],topfaces[:,[2,0]]])
 key=np.sort(edges,1);_,inverse,frequency=np.unique(key,axis=0,return_inverse=True,return_counts=True)
 boundary=edges[frequency[inverse]==1];u,v=boundary[:,0],boundary[:,1]
 side=np.concatenate([np.stack([u,v+count,v],1),np.stack([u,u+count,v+count],1)])
 allfaces=np.r_[topfaces,topfaces[:,[0,2,1]]+count,side].astype(np.uint32)
 triangles3=xyz[allfaces];face_n=np.cross(triangles3[:,1]-triangles3[:,0],triangles3[:,2]-triangles3[:,0]);nn=np.zeros_like(xyz)
 for k in range(3):np.add.at(nn,allfaces[:,k],face_n)
 nn/=np.linalg.norm(nn,axis=1,keepdims=True)
 guide=np.tile([1.,0.,0.],(len(xyz),1));guide[abs(nn[:,0])>.95]=[0.,0.,1.]
 tangent=guide-nn*(guide*nn).sum(1)[:,None];tangent/=np.linalg.norm(tangent,axis=1,keepdims=True)
 sign=np.where(np.cross(nn,tangent)[:,2]<0,-1.,1.)
 tangent=np.c_[tangent,sign]
 uv=np.r_[points[used]-lo,points[used]-lo+.00002]
 # Dark pigment comes only from this SKU's native R7 root COLOR_0 samples.
 r7d,r7b=glb(source7['glb_path']);q=r7d['meshes'][-1]['primitives'][0]
 original=H.read_colour(r7d,r7b,q['attributes']['COLOR_0'])
 root_pool=original[:9000*57].reshape(9000,57,4)[:,0,:]
 rng=np.random.default_rng(int(SKU)+121212);choice=rng.integers(len(root_pool),size=count)
 colour=np.r_[root_pool[choice],root_pool[choice]].copy();colour[:,3]=255
 proof=dict(exact_R5_mesh0_upper_triangle_ray_intersections=True,grid_spacing_max_m=.008,
  sampled_top_vertices=count,undercoat_top_offset_m=.00085,closed_thickness_m=.00025,
  own_dark_root_COLOR0_pool_sha256=hashlib.sha256(root_pool.tobytes()).hexdigest(),
  median_own_linear_dark_root=np.median(root_pool[:,:3],axis=0).tolist(),
  no_RGB_texture_no_photo_shadow_map=True,no_source_studio_lighting_baked=True,
  no_bridging_between_folded_layers=True,excluded_height_steps_over_m=.006,minimum_original_normal_y=.65,
  coverage_and_undercoat_are_explicit_physical_photo_interpretation=True)
 return xyz.astype('<f4'),nn.astype('<f4'),uv.astype('<f4'),tangent.astype('<f4'),colour,allfaces,proof

def interpolate(rows,parameters):
 """Independent parameter per fibre and station, with bounded tip extension."""
 q=parameters*(rows.shape[1]-1);index=np.minimum(np.floor(q).astype(int),rows.shape[1]-2)
 f=q-index;ids=np.arange(len(rows))[:,None]
 return rows[ids,index]*(1-f[:,:,None])+rows[ids,index+1]*f[:,:,None]

def fine_fibres(source7,od,ob):
 d,b=glb(source7['glb_path']);p=d['meshes'][-1]['primitives'][0]
 pos=B.array(d,b,p['attributes']['POSITION']).astype(float)
 colours=H.read_colour(d,b,p['attributes']['COLOR_0'])
 parents=9000;source_rings=11;source_sides=5;source_per=source_rings*source_sides+2
 assert len(pos)>parents*source_per
 macro=pos[:parents*source_per].reshape(parents,source_per,3)[:,:source_rings*source_sides].reshape(parents,source_rings,source_sides,3).mean(2)
 pigment=colours[:parents*source_per].reshape(parents,source_per,4)[:,:source_rings*source_sides].reshape(parents,source_rings,source_sides,4)[:,:,0,:].astype(float)
 # This SKU's source has a longer, laid and slowly turning pile, unlike the
 # accepted cream's short curly flow. The original grey roots and native
 # pigment remain exact; only this explicit source-photo fibre pose changes.
 original_macro_sha=hashlib.sha256(macro.astype('<f8').tobytes()).hexdigest()
 root=macro[:,0:1].copy();delta=macro-root;f=np.linspace(0,1,source_rings)
 cloud=cloud_field(root[:,0,:][:,[0,2]])
 length_factor=1.10+.35*cloud;loft_factor=.95+.20*cloud
 endpoint=delta[:,-1,:][:,[0,2]]
 lateral=delta[:,:,[0,2]]-endpoint[:,None,:]*f[None,:,None]
 laid=endpoint[:,None,:]*f[None,:,None]*length_factor[:,None,None]+lateral*.25
 yaw=.18*np.sin(root[:,0,0]*math.tau/.19+root[:,0,2]*math.tau/.23)
 c=np.cos(yaw)[:,None];ss=np.sin(yaw)[:,None]
 rotated=np.stack([laid[:,:,0]*c-laid[:,:,1]*ss,laid[:,:,0]*ss+laid[:,:,1]*c],2)
 macro[:,:,[0,2]]=root[:,:,[0,2]]+rotated
 macro[:,:,1]=root[:,:,1]+delta[:,:,1]*loft_factor[:,None]
 interpreted_macro_sha=hashlib.sha256(macro.astype('<f8').tobytes()).hexdigest()

 children_per_parent=np.clip(np.rint(3+5*cloud).astype(int),3,8);count=int(children_per_parent.sum());stations=4;sides=3
 assert 43000<=count<=54000,(count,float(cloud.mean()))
 rng=np.random.default_rng(int(SKU)+1010)
 macros=np.repeat(macro,children_per_parent,axis=0);pigments=np.repeat(pigment,children_per_parent,axis=0)
 # No parent-aligned end contour: length and tip position are independently
 # distributed for each single fibre, including siblings of the same parent.
 end=rng.uniform(.72,1.14,count)
 fraction=np.array([0.,.31,.67,1.])
 parameter=end[:,None]*fraction[None,:]
 centres=interpolate(macros,parameter)
 t0,a0,u0=H.frames(macros)
 across=interpolate(a0,parameter);up=interpolate(u0,parameter)
 across/=np.linalg.norm(across,axis=2,keepdims=True);up/=np.linalg.norm(up,axis=2,keepdims=True)
 phase=rng.uniform(0,math.tau,count);frequency=rng.uniform(.25,.60,count)
 rootx=rng.uniform(-.0008,.0008,count);rooty=rng.uniform(-.0006,.0006,count)
 amp=rng.uniform(.0006,.0018,count)
 free=centres.copy()
 wave=np.sin(fraction[None,:]*math.pi*frequency[:,None]+phase[:,None])
 wave-=np.sin(phase)[:,None]
 dx=rootx[:,None]+amp[:,None]*fraction[None,:]**1.25*wave
 dy=rooty[:,None]+amp[:,None]*fraction[None,:]**1.45*np.cos(fraction[None,:]*math.pi*frequency[:,None]+phase[:,None])*.65
 centres+=across*dx[:,:,None]+up*dy[:,:,None]
 centres[:,:,1]+=.00012
 # Keep all new roots/tips within the unchanged R5 nominal footprint.
 oldpos=np.concatenate([B.array(od,ob,q['attributes']['POSITION'])for m in od['meshes']for q in m['primitives']])
 lo,hi=oldpos.min(0),oldpos.max(0)
 widths=rng.uniform(.00020,.00060,count);tips=rng.uniform(.00003,.00008,count)
 width=widths[:,None]*np.array([1.,.85,.40,0.])[None,:];width[:,-1]=tips
 tangent,span,up=H.frames(centres)
 angle=np.arange(sides)*math.tau/sides
 radial=span[:,:,None,:]*np.cos(angle)[None,None,:,None]+up[:,:,None,:]*np.sin(angle)[None,None,:,None]
 sidepos=centres[:,:,None,:]+radial*width[:,:,None,None]*.5
 vertices=np.concatenate([sidepos.reshape(count,stations*sides,3),centres[:,0:1],centres[:,-1:]],axis=1)
 bad=((vertices[:,:,0]<lo[0])|(vertices[:,:,0]>hi[0])|(vertices[:,:,2]<lo[2])|(vertices[:,:,2]>hi[2])).any(1)
 if bad.any():
  root=macros[:,0];off=vertices[bad]-root[bad,None,:];scale=np.ones(int(bad.sum()))
  for axis in [0,2]:
   scale=np.minimum(scale,(hi[axis]-root[bad,axis])*.99/np.maximum(off[:,:,axis].max(1),1e-12))
   scale=np.minimum(scale,(root[bad,axis]-lo[axis])*.99/np.maximum(-off[:,:,axis].min(1),1e-12))
  assert scale.min()>0
  off[:,:,[0,2]]*=scale[:,None,None];vertices[bad]=root[bad,None,:]+off
 # Analytic smooth cylindrical normals/tangents; the thin solid has a closed
 # triangular section, not a flat ribbon/card. Recompute the centre frames
 # after the bounded edge adjustment to retain valid unit orthogonal vectors.
 centres=vertices[:,:stations*sides].reshape(count,stations,sides,3).mean(2)
 tangent,span,up=H.frames(centres)
 radial=span[:,:,None,:]*np.cos(angle)[None,None,:,None]+up[:,:,None,:]*np.sin(angle)[None,None,:,None]
 circle=-span[:,:,None,:]*np.sin(angle)[None,None,:,None]+up[:,:,None,:]*np.cos(angle)[None,None,:,None]
 normal=np.concatenate([radial.reshape(count,stations*sides,3),-tangent[:,0:1],tangent[:,-1:]],1)
 tang=np.concatenate([circle.reshape(count,stations*sides,3),span[:,0:1],span[:,-1:]],1)
 flow=np.concatenate([np.repeat(tangent[:,:,None,:],sides,axis=2).reshape(count,stations*sides,3),tangent[:,0:1],tangent[:,-1:]],1)
 handed=np.where((np.cross(normal,tang)*flow).sum(2)<0,-1.,1.)
 tan=np.concatenate([tang,handed[:,:,None]],2)
 local=[]
 for j in range(stations-1):
  for a in range(sides):
   b0=(a+1)%sides;x=j*sides+a;y=j*sides+b0;z=(j+1)*sides+a;w=(j+1)*sides+b0
   local.extend([(x,z,y),(y,z,w)])
 for a in range(sides):
  b0=(a+1)%sides;local.append((stations*sides,a,b0));local.append((stations*sides+1,(stations-1)*sides+b0,(stations-1)*sides+a))
 per=stations*sides+2
 faces=(np.asarray(local,np.uint32)[None,:,:]+np.arange(count,dtype=np.uint32)[:,None,None]*per)
 flat=vertices.reshape(-1,3);trip=flat[faces.reshape(-1,3)]
 volumes=np.einsum('ij,ij->i',trip[:,0],np.cross(trip[:,1],trip[:,2])).reshape(count,-1).sum(1)/6
 assert abs(volumes).min()>1e-14
 negative=volumes<0;faces[negative]=faces[negative][:,:,[0,2,1]]
 # Own native source pigment is interpolated only along its own parent flow.
 # Dense patches expose more of their pale tips above the dark undercoat.
 # Native own pigment values and the dark first station remain unchanged;
 # this interpreted phase shift contains no photographed lighting/shadow.
 local_cloud=np.repeat(cloud,children_per_parent)
 pigment_parameter=np.minimum(parameter*(1+.65*local_cloud[:,None]),1.)
 cc=np.clip(np.rint(interpolate(pigments,pigment_parameter)),0,255).astype('u1');cc[:,:,3]=255
 cc=np.concatenate([np.repeat(cc[:,:,None,:],sides,axis=2).reshape(count,stations*sides,4),cc[:,0:1],cc[:,-1:]],1)
 uv=np.empty((count,per,2));arc=np.c_[np.zeros(count),np.cumsum(np.linalg.norm(np.diff(centres,axis=1),axis=2),axis=1)]
 uv[:,:stations*sides,0]=np.tile(np.arange(sides)/sides,(count,stations))
 uv[:,:stations*sides,1]=np.repeat(arc, sides,axis=1)
 uv[:,stations*sides:,:]=np.stack([np.c_[np.zeros(count),np.zeros(count)],np.c_[np.zeros(count),arc[:,-1]]],axis=1)
 xyz=vertices.reshape(-1,3).astype('<f4');normal=normal.reshape(-1,3).astype('<f4');tan=tan.reshape(-1,4).astype('<f4');uv=uv.reshape(-1,2).astype('<f4')
 assert np.isfinite(xyz).all() and np.isfinite(normal).all() and np.isfinite(tan).all() and np.isfinite(uv).all()
 assert np.max(abs(np.linalg.norm(normal,axis=1)-1))<1e-5
 assert np.max(abs((normal*tan[:,:3]).sum(1)))<1e-5
 assert np.max(abs(np.linalg.norm(tan[:,:3],axis=1)-1))<1e-5
 proof=dict(source_R7_manifest=str(R7),source_R7_glb_sha256=source7['sha256'],
   source_macro_curves=parents,source_macro_centres_sha256=original_macro_sha,interpreted_laid_macro_centres_sha256=interpreted_macro_sha,
   own_grey_flow_interpretation=dict(planar_length_factor=[1.10,1.45],lateral_curl_factor=.25,normal_loft_factor=[.95,1.15],cloud_physical_width_m=[.05,.10],not_a_manufacturer_fibre_measurement=True),
   independent_children_per_parent=[int(children_per_parent.min()),int(children_per_parent.max())],children_count_by_cloud=True,cloud_mean=float(cloud.mean()),individual_fibres=count,stations=stations,closed_section_sides=sides,vertices_per_fibre=per,
   single_fibre_root_width_m=[.00020,.00060],single_fibre_free_tip_width_m=[.00003,.00008],
   independently_varied_length_parent_parameter=[.72,1.14],independent_root_offset_phase_tip_spread=True,
   coarse_coherent_macroflow_preserved_but_no_common_tip_boundary=True,
   no_haircards_no_alpha_no_broad_visible_carrier=True,own_source_linear_pigment_only=True,
   alpha_opaque_only=True,analytical_smooth_cylindrical_normal=True,
   tangent_orthogonal_unit_and_finite=True,positive_closed_volumes=True,edge_restrained_fibres=int(bad.sum()),
   no_photo_lighting_or_shadow_map=True,physical_fine_fur_is_photo_interpretation=True)
 return xyz,normal,uv,tan,cc.reshape(-1,4),faces.reshape(-1,3),proof

def build():
 assert sha(R7)==R7SHA and sha(B.SOURCE)==B.SOURCE_SHA
 old=next(e for e in json.loads(B.SOURCE.read_text())if e['sku']==SKU)
 source7=next(e for e in json.loads(R7.read_text())if e['sku']==SKU)
 assert sha(old['glb_path'])==old['sha256'] and sha(source7['glb_path'])==source7['sha256']
 out=D/'models-local-top-02'/old['id'];assert not out.exists();out.parent.mkdir(exist_ok=True)
 subprocess.run(['/usr/bin/ditto','--clone',old['asset_dir'],str(out)],check=True)
 od,ob=glb(old['glb_path']);d=copy.deepcopy(od);binary=bytearray(ob)
 xyz,normal,uv,tangent,colours,faces,proof=fine_fibres(source7,od,ob)
 print('FIBRES',len(xyz)//14,'VERTICES',len(xyz),'TRIANGLES',len(faces),flush=True)
 bx,bn,bu,bt,bc,bf,backproof=conformal_dark_undercoat(source7,od,ob)
 print('DARK_UNDERCOAT',len(bx),len(bf),flush=True)
 def view(content,target=None):
  binary.extend(b'\0'*(-len(binary)%4));v=dict(buffer=0,byteOffset=len(binary),byteLength=len(content));binary.extend(content)
  if target:v['target']=target
  d['bufferViews'].append(v);return len(d['bufferViews'])-1
 def acc(a,kind,component=5126,target=34962):
  a=np.asarray(a,'<u4'if component==5125 else'u1'if component==5121 else'<f4');i=len(d['accessors'])
  item=dict(bufferView=view(a.tobytes(),target),componentType=component,count=len(a),type=kind,min=a.min(0).tolist(),max=a.max(0).tolist())
  if component==5121:item['normalized']=True
  d['accessors'].append(item);return i
 attrs=dict(POSITION=acc(xyz,'VEC3'),NORMAL=acc(normal,'VEC3'),TEXCOORD_0=acc(uv,'VEC2'),TANGENT=acc(tangent,'VEC4'),COLOR_0=acc(colours,'VEC4',5121))
 indices=acc(faces.reshape(-1,1),'SCALAR',5125,34963)
 material=dict(name='own-grey-independent-fine-physical-fibres',pbrMetallicRoughness=dict(baseColorFactor=[1,1,1,1],metallicFactor=0.,roughnessFactor=.85),alphaMode='OPAQUE',doubleSided=True,
   extensions=dict(KHR_materials_sheen=dict(sheenColorFactor=[.65,.65,.65],sheenRoughnessFactor=.85)))
 mi=len(d['materials']);d['materials'].append(material);mesh=len(d['meshes']);name='cloud-density-free-individual-grey-fibres-no-carrier'
 d['meshes'].append(dict(name=name,primitives=[dict(attributes=attrs,indices=indices,material=mi,mode=4)]))
 node=len(d['nodes']);d['nodes'].append(dict(name=name,mesh=mesh));d['scenes'][0]['nodes'].append(node)
 backattrs=dict(POSITION=acc(bx,'VEC3'),NORMAL=acc(bn,'VEC3'),TEXCOORD_0=acc(bu,'VEC2'),TANGENT=acc(bt,'VEC4'),COLOR_0=acc(bc,'VEC4',5121))
 backindices=acc(bf.reshape(-1,1),'SCALAR',5125,34963)
 backmaterial=dict(name='own-grey-conformal-dark-undercoat',pbrMetallicRoughness=dict(baseColorFactor=[1,1,1,1],metallicFactor=0.,roughnessFactor=1.),alphaMode='OPAQUE',doubleSided=True,
   extensions=dict(KHR_materials_sheen=dict(sheenColorFactor=[.25,.25,.25],sheenRoughnessFactor=1.)))
 bmi=len(d['materials']);d['materials'].append(backmaterial);bmesh=len(d['meshes']);backname='close-conformal-own-dark-root-undercoat-thin-closed-shell'
 d['meshes'].append(dict(name=backname,primitives=[dict(attributes=backattrs,indices=backindices,material=bmi,mode=4)]))
 bnode=len(d['nodes']);d['nodes'].append(dict(name=backname,mesh=bmesh));d['scenes'][0]['nodes'].append(bnode)
 if 'KHR_materials_sheen'not in d.get('extensionsUsed',[]):d.setdefault('extensionsUsed',[]).append('KHR_materials_sheen')
 oldpos=np.concatenate([B.array(od,ob,p['attributes']['POSITION'])for m in od['meshes']for p in m['primitives']]);allpos=np.r_[oldpos,xyz,bx]
 meta=copy.deepcopy(od['extras']['metadata']);meta.update(dimensions_cm=((allpos.max(0)-allpos.min(0))*100).tolist(),
   model_revision='own-grey-cloud-undercoat-independent-free-fibres-candidate-R12',
   quality_label='Koyu alt katman ve bulutlu uzun ince lifler · Yumuşak dört kat · Yaklaşık ölçek')
 meta['quality_note']+=(' Tutam akışı kendi önceki merkez eğrilerinden korunarak bölgesel örtücülüklü ayrı ince kapalı life ayrıldı; '
   'her lifin boyu, fazı, kökü ve serbest ucu farklıdır. Geniş kart/atlas/alfa taşıyıcısı yoktur. '
   'Lineer COLOR_0 yalnız bu gri ürünün kendi koyu dip/açık uç pigmentinden gelir; nötr faktör1 uygulanır. '
   'Koyu ince alt katman gerçek üst kabuk üçgenlerine oturur; 5–10cm fiziksel alanda lif adedi, örtücülük, yatıklık ve yükseklik değişimi açık-koyu bulutları oluşturur. Bunlar fotoğrafa dayalı yapı yorumudur; stüdyo ışığı/gölgesi kaplamaya kopyalanmadı. '
   'Alt-piksel gerçek zamanlı görünüm ve liflerin gölge davranışı ayrıca denetlenmelidir.')
 meta['source_evidence_files']=meta['source_evidence_files']+[str(R7),str(out/'R5-prefix-own-pigment-and-independent-fibre-proof.json')]
 d['extras']['metadata']=meta
 target=out/Path(old['glb_path']).name;write_glb(target,d,bytes(binary));nd,nb=glb(target);assert nb[:len(ob)]==ob
 attrs_same=[]
 for mesh in od['meshes']:
  for prim in mesh['primitives']:
   for key,i in {**prim['attributes'],'indices':prim['indices']}.items():
    assert attr(od,ob,i)==attr(nd,nb,i);attrs_same.append(dict(mesh=mesh['name'],attribute=key,sha256=attr(nd,nb,i),byte_identical=True))
 model=json.loads((out/'model.json').read_text());model['metadata']=meta
 model['materials']['own-grey-independent-fine-physical-fibres']=dict(baseColorFactor=[1,1,1,1],metallic=0,roughness=.85,doubleSided=True,
   extras=dict(vertex_color_single_native_pigment_source=True,no_carrier_no_alpha=True,physical_sheen=dict(sheenColorFactor=[.65,.65,.65],sheenRoughnessFactor=.85)))
 model['meshes'].append(dict(name=name,material='own-grey-independent-fine-physical-fibres',positions=xyz.reshape(-1).tolist(),normals=normal.reshape(-1).tolist(),uvs=uv.reshape(-1).tolist(),indices=faces.reshape(-1).tolist(),colorsLinearNormalizedBytes=colours.reshape(-1).tolist()))
 model['materials']['own-grey-conformal-dark-undercoat']=dict(baseColorFactor=[1,1,1,1],metallic=0,roughness=1,doubleSided=True,
   extras=dict(vertex_color_single_native_pigment_source=True,own_dark_root_intrinsic_pigment=True,physical_sheen=dict(sheenColorFactor=[.25,.25,.25],sheenRoughnessFactor=1)))
 model['meshes'].append(dict(name=backname,material='own-grey-conformal-dark-undercoat',positions=bx.reshape(-1).tolist(),normals=bn.reshape(-1).tolist(),uvs=bu.reshape(-1).tolist(),indices=bf.reshape(-1).tolist(),colorsLinearNormalizedBytes=bc.reshape(-1).tolist()))
 dump(out/'model.json',model)
 e=copy.deepcopy(old);e.update(meta,asset_dir=str(out),model_path=str(out/'model.json'),glb_path=str(target),sha256=sha(target),bytes=target.stat().st_size,
   geometry_validation=str(out/'geometry-validation.json'),material_validation=str(out/'material-validation.json'),quality_pending=True,actual_browser_review_passed=False,model_status='ready_for_browser_review',frozen=False)
 e.pop('native_renders',None);e.pop('independent_validation_file',None);assert e['bytes']<96*2**20
 maps=[]
 for im in nd['images']:
  v=nd['bufferViews'][im['bufferView']];start=v.get('byteOffset',0);content=nb[start:start+v['byteLength']]
  maps.append(dict(file=im['name'],path=str(out/im['name']),sha256=hashlib.sha256(content).hexdigest(),native_resolution=list(Image.open(io.BytesIO(content)).size)))
 dump(out/'material-validation.json',dict(valid=True,maps=maps,own_native_linear_COLOR0_primary_pigment=True,
   neutral_base_factor_preserves_own_grey_pigment=True,no_new_RGB_texture=True,no_alpha_or_hair_atlas=True,no_baked_lighting=True,
   smooth_physical_cylindrical_normals=True,physical_PBR_material=material,conformal_dark_undercoat_material=backmaterial))
 dump(out/'geometry-validation.json',dict(valid=True,source_R5_old_attributes=attrs_same,fine_independent_fibres=proof,undercoat=backproof))
 pngs=[]
 for p in Path(old['asset_dir']).glob('*.png'):
  if p.name in {'on.png','yan.png','on-capraz.png','ustten.png','arka.png'}:continue
  assert sha(p)==sha(out/p.name);pngs.append(dict(name=p.name,sha256=sha(p),unchanged=True))
 proof.update(source_R5_manifest=str(B.SOURCE),source_R5_manifest_sha256=B.SOURCE_SHA,
   old_R5_complete_BIN_prefix_byte_identical=True,old_R5_BIN_prefix_sha256=hashlib.sha256(ob).hexdigest(),
   R5_original_glb_unchanged=sha(old['glb_path'])==old['sha256'],R7_original_glb_unchanged=sha(source7['glb_path'])==source7['sha256'],
   original_own_PNGs=pngs,own_JPEGs_unchanged=all(sha(i['path'])==i['sha256']for i in old['original_images']),
   physical_dark_undercoat=backproof,backing_not_a_fibre_group_card_or_petal=True,
   actual_viewer_four_angles_close_and_aliasing_shadow_gate_required=True,ready_claim=False)
 dump(out/'R5-prefix-own-pigment-and-independent-fibre-proof.json',proof);dump(out/'entry.json',e)
 result=V.check(e);dump(out/'independent-binary-fine-fibres-check.json',result)
 return e

if __name__=='__main__':
 manifest=D/'candidate-own-grey-cloud-undercoat-local-top-fibres-02-manifest.json';assert not manifest.exists()
 e=build();dump(manifest,[e]);print(manifest,sha(manifest),e['bytes'],e['sha256'],flush=True)
