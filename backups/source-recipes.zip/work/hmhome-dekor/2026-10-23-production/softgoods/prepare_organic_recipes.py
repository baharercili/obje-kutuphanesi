"""Source-specific preparation only; production still waits for actual pilot review."""
import json
from pathlib import Path
P=Path(__file__).resolve().parent
queue=json.loads((P/'organic-revision-fleet-queue-27.json').read_text())
recipes={}
for e in queue['products']:
    sku=e['sku'];family=e['surface_family']
    r=dict(sku=sku,id=e['id'],surface_family=family,source_image=e['own_source_image'],official_plan_cm=e['official_plan_cm'],photo_estimated_plan_cm=e['photo_estimated_plan_cm'],all_local_shape_metrics_photo_estimated=True,source_photo_review_panels=[str(P/f'organic-fleet-own-sources-{i}.jpg') for i in [1,2,3]],source_originals_immutable=True)
    if family=='linen_woven':
        r.update(thickness_mm=2.5,fringe_length_cm=7.5 if sku.startswith('1329726') else 3.5,visible_fringe_family='fine loose linen/cotton multiple-yarn cords',physical_meso_weave_mm=[2.8,3.1])
    elif family=='long_fringed_wool':
        r.update(thickness_mm=5.5,fringe_length_cm=15 if sku=='1338615001' else 17,visible_fringe_count=25,visible_cord_width_mm=7,fringe_family='soft oval wool cords with short loose fuzzy outline',surface_pile_length_mm=[2.2,4.1] if sku!='1338615001' else [3,7])
    elif family=='boucle':
        r.update(thickness_mm=4.5,fringe_length_cm=4,fringe_family='loose short own-colour yarn tufts',surface_pile_family='small closed-mesh boucle loops following exposed cloth only',surface_pile_length_mm=[1.5,3.0])
    elif family=='chenille':
        r.update(thickness_mm=4,fringe_length_cm=5.5,fringe_family='chunky2mm irregular twisted chenille cords with loose tips',surface_pile_length_mm=[.8,1.5])
    elif family=='knitted_cable':
        r.update(thickness_mm=4,fringe_length_cm=0,visible_diamond_grid=[3,5],cable_width_mm=2,edge_family='soft knitted hems, no tassels')
    elif family=='fur_or_quilted_pile':
        r.update(thickness_mm=4,fringe_length_cm=0,surface_pile_length_mm=[5,10] if sku!='1357963001' else [10,18],surface_pile_family='own-colour tapered open-centreline tufts with closed mesh ends; no loop/ring silhouettes',visible_quilt_grid=[3,5] if sku in ['1355863001','1355863002'] else None)
    else:
        r.update(thickness_mm=3,fringe_length_cm=18 if sku.startswith('1338618') else 2.5 if sku=='1338616001' else 0,edge_family='6mm source black blanket-stitch border' if sku=='1298464008' else 'soft wrapped hem',surface_family='short velvety pile' if sku=='1348917001' else 'soft woven')
    recipes[sku]=r
(P/'organic-revision-recipes-27.json').write_text(json.dumps(dict(total=len(recipes),status='source preparation only; pose method actual approval still pending',recipes=recipes,common_notes='All official/estimated flat-plan facts preserved separately. Every artwork remains from its exactSKU. Fine yarn, drape, fringe count and unseen phase are photo interpretations.'),ensure_ascii=False,indent=2)+'\n')
print('27source-specific recipes prepared')
