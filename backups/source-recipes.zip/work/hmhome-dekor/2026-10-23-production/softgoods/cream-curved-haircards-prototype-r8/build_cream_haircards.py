"""One cream real-time fur prototype: curved masked fibre cards, R5 base intact.

The R7 macroflow curves and linear native pigment COLOR_0 are read from its
immutable GLB. Its thick opaque tubes are not included. Only thin curved closed
card supports, a white-RGB procedural alpha atlas and intrinsic normal are new.
"""
from pathlib import Path
import copy, hashlib, importlib.util, io, json, math, struct, subprocess, sys
import numpy as np
from PIL import Image
sys.dont_write_bytecode=True
D=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('fur_R6_geometry_helpers',D.parent/'fur-projecting-own-three-r6/build_projecting_fur_three.py')
B=importlib.util.module_from_spec(spec);spec.loader.exec_module(B)
T=D.parent.parent/'textiles';sys.path.insert(0,str(T))
from freeze_polar_knit_review_candidates import glb,sha,dump,attr
from clean_remaining_robe_material_revision02 import write_glb
import specific_binary_native_material as V
SKU='1357963001'
R7=D.parent/'fur-clustered-own-two-r7/frozen-own-root-tip-grey-and-coherent-cream-locks-02-manifest.json'
R7SHA='d6fc6b4268c78fa2ad5cb5ed4b205a45e25a0f1401eddfe87cffef038b1e2a8d'

def read_colour(d,b,i):
 a=d['accessors'][i];v=d['bufferViews'][a['bufferView']];assert a['componentType']==5121 and a['normalized']is True
 return np.frombuffer(b,dtype='u1',count=a['count']*4,offset=v.get('byteOffset',0)+a.get('byteOffset',0)).reshape(-1,4).copy()

def frames(paths):
 n,k,_=paths.shape;t=np.empty_like(paths);t[:,1:-1]=paths[:,2:]-paths[:,:-2];t[:,0]=paths[:,1]-paths[:,0];t[:,-1]=paths[:,-1]-paths[:,-2];t/=np.linalg.norm(t,axis=2,keepdims=True)
 guide=np.zeros((n,3));guide[:,1]=1;guide[abs(t[:,0,1])>.95]=[0,0,1]
 across=np.empty_like(t);across[:,0]=np.cross(t[:,0],guide);across[:,0]/=np.linalg.norm(across[:,0],axis=1,keepdims=True)
 for j in range(1,k):
  q=across[:,j-1]-t[:,j]*(across[:,j-1]*t[:,j]).sum(1)[:,None];across[:,j]=q/np.linalg.norm(q,axis=1,keepdims=True)
 return t,across,np.cross(across,t)

def atlas(out):
 """Eight intrinsic fibre silhouettes; physical spans are card-local estimates."""
 width=2048;height=2048;tw=512;th=1024
 rgba=np.ones((height,width,4),np.uint8)*255;rgba[:,:,3]=0
 normal=np.tile(np.array([128,128,255],np.uint8),(height,width,1))
 rng=np.random.default_rng(1357963001+808);physical_width=.012;stats=[]
 yy,xx=np.mgrid[0:th,0:tw].astype(float);v=yy/(th-1);u=xx/(tw-1)
 for tile in range(8):
  alpha=np.zeros((th,tw));distance_best=np.full((th,tw),np.inf);nx=np.zeros((th,tw));ny=np.zeros((th,tw));strand_count=23
  for strand in range(strand_count):
   centre=(strand+.5+rng.uniform(-.28,.28))/strand_count
   amplitude=rng.uniform(.010,.043);phase=rng.uniform(-.35,.35);wave=rng.uniform(.6,1.4)
   curve=centre+amplitude*(np.sin(v*math.tau*wave+phase)-math.sin(phase))*v
   slope=amplitude*(math.tau*wave*np.cos(v*math.tau*wave+phase)*v+np.sin(v*math.tau*wave+phase)-math.sin(phase))
   end=rng.uniform(.72,.995);start=rng.uniform(0,.035);full_width=rng.uniform(.00020,.00060)
   phase_v=np.clip((v-start)/(end-start),0,1)
   taper=np.clip((1-phase_v)/.32,0,1)**.78
   radius=full_width/physical_width*.5*taper
   signed=u-curve;dist=abs(signed);coverage=np.clip(.5+(radius-dist)*tw/1.4,0,1)
   coverage*=np.clip((v-start)*th/2,0,1)*np.clip((end-v)*th/2,0,1)
   alpha=np.maximum(alpha,coverage)
   nearest=dist<distance_best;distance_best=np.minimum(distance_best,dist)
   radial=np.clip(signed/np.maximum(radius,1e-5),-.92,.92)
   nx[nearest]=radial[nearest];ny[nearest]=(-slope*radial*.12)[nearest]
  nz=np.sqrt(np.maximum(.04,1-nx*nx-ny*ny));nn=np.stack([nx,ny,nz],2);nn/=np.linalg.norm(nn,axis=2,keepdims=True);nn[alpha<.01]=[0,0,1]
  px=tile%4*tw;py=tile//4*th
  rgba[py:py+th,px:px+tw,3]=np.rint(alpha*255).astype(np.uint8)
  normal[py:py+th,px:px+tw]=np.rint((nn+1)*127.5).astype(np.uint8)
  stats.append(dict(tile=tile,strands=strand_count,physical_card_width_reference_m=physical_width,
                    individual_width_m=[.00020,.00060],tapered_tips=True,
                    antialias_transition_pixels=1.4,alpha_coverage=float((alpha>=.32).mean())))
 assert (rgba[:,:,:3]==255).all()
 Image.fromarray(rgba).save(out/'white-intrinsic-fibre-alpha-atlas.png')
 Image.fromarray(normal).save(out/'intrinsic-fibre-cylinder-normal-atlas.png')
 Image.new('RGB',(4,4),(255,250,0)).save(out/'intrinsic-hair-rough-nonmetal.png')
 dump(out/'intrinsic-alpha-atlas-proof.json',dict(procedural_intrinsic_silhouettes_only=True,
      all_RGB_channels_exact_white=True,no_pigment_or_photo_shadow_in_atlas=True,
      no_studio_reflections_or_background=True,source_photos_not_resampled_or_upscaled=True,
      tiles=stats,alpha_image_sha256=sha(out/'white-intrinsic-fibre-alpha-atlas.png'),
      normal_image_sha256=sha(out/'intrinsic-fibre-cylinder-normal-atlas.png')))

def cards_from_R7(r7,base_d,base_b):
 d,b=glb(r7['glb_path']);p=d['meshes'][-1]['primitives'][0]
 source=B.array(d,b,p['attributes']['POSITION']).astype(float)
 colour=read_colour(d,b,p['attributes']['COLOR_0'])
 count=2400*3;k=11;sides=6;per=k*sides+2;limit=count*per
 # Mean of the six rounded vertices is the exact source tube centreline.
 paths=source[:limit].reshape(count,per,3)[:,:k*sides].reshape(count,k,sides,3).mean(2)
 native=colour[:limit].reshape(count,per,4)[:,:k*sides].reshape(count,k,sides,4)[:,:,0,:]
 tangent,across,up=frames(paths);rng=np.random.default_rng(1357963001+818)
 # Three cross planes per shared 1–2cm clump, matching its original three paths.
 plane=np.repeat(np.arange(3),2400)*math.pi/3+np.tile(rng.uniform(-.12,.12,2400),3)
 span=across*np.cos(plane)[:,None,None]+up*np.sin(plane)[:,None,None]
 # Cross-cards stay a soft tuft, rather than a rigid cylinder. Their thickness
 # is only a topology support: the visible individual fibres come from alpha.
 thickdir=np.cross(tangent,span);thickdir/=np.linalg.norm(thickdir,axis=2,keepdims=True)
 widths=rng.uniform(.0095,.0135,count)
 f=np.linspace(0,1,k);envelope=np.interp(f,[0,.2,.7,1],[.45,1,1,.72])
 front=paths[:,:,None,:]+span[:,:,None,:]*np.array([-1,1])[None,None,:,None]*widths[:,None,None,None]*.5*envelope[None,:,None,None]+thickdir[:,:,None,:]*.0000125
 back=front-thickdir[:,:,None,:]*.000025
 vertices=np.concatenate([front.reshape(count,k*2,3),back.reshape(count,k*2,3)],1)
 oldpos=np.concatenate([B.array(base_d,base_b,q['attributes']['POSITION'])for m in base_d['meshes']for q in m['primitives']]);lo=oldpos.min(0);hi=oldpos.max(0)
 bad=((vertices[:,:,0]<lo[0])|(vertices[:,:,0]>hi[0])|(vertices[:,:,2]<lo[2])|(vertices[:,:,2]>hi[2])).any(1)
 if bad.any():
  roots=paths[:,0];off=vertices[bad]-roots[bad,None,:];scale=np.ones(len(off))
  for axis in [0,2]:
   scale=np.minimum(scale,(hi[axis]-roots[bad,axis])*.99/np.maximum(off[:,:,axis].max(1),1e-12))
   scale=np.minimum(scale,(roots[bad,axis]-lo[axis])*.99/np.maximum(-off[:,:,axis].min(1),1e-12))
  assert scale.min()>0;off[:,:,[0,2]]*=scale[:,None,None];vertices[bad]=roots[bad,None,:]+off
 local=[]
 for j in range(k-1):
  a=j*2;b0=a+1;c=a+2;dd=a+3
  local.extend([(a,b0,c),(b0,dd,c),(a+k*2,c+k*2,b0+k*2),(b0+k*2,c+k*2,dd+k*2)])
 for edge in [0,1]:
  for j in range(k-1):
   a=j*2+edge;b0=(j+1)*2+edge;c=a+k*2;dd=b0+k*2
   local.extend([(a,b0,c),(b0,dd,c)]if edge==0 else[(a,c,b0),(b0,c,dd)])
 for j in [0,k-1]:
  a=j*2;b0=a+1;c=a+k*2;dd=b0+k*2
  local.extend([(a,c,b0),(b0,c,dd)]if j==0 else[(a,b0,c),(b0,dd,c)])
 faces=(np.asarray(local,np.uint32)[None,:,:]+np.arange(count,dtype=np.uint32)[:,None,None]*(k*4)).reshape(-1,3)
 # Check per-card signed volume and orient independently if needed.
 flat=vertices.reshape(-1,3);trip=flat[faces];vol=np.einsum('ij,ij->i',trip[:,0],np.cross(trip[:,1],trip[:,2])).reshape(count,-1).sum(1)/6
 facegroups=faces.reshape(count,-1,3);negative=vol<0;facegroups[negative]=facegroups[negative][:,:,[0,2,1]];faces=facegroups.reshape(-1,3)
 assert abs(vol).min()>1e-14
 tile=rng.integers(0,8,count);uv=np.empty((count,k*4,2))
 arc=np.c_[np.zeros(count),np.cumsum(np.linalg.norm(np.diff(paths,axis=1),axis=2),axis=1)]
 arc/=arc[:,-1,None]
 for layer in [0,1]:
  u=np.tile(np.array([8/512,1-8/512]),(count,k))
  v=np.repeat(8/1024+arc*(1-16/1024),2,axis=1)
  uv[:,layer*k*2:(layer+1)*k*2,0]=(tile[:,None]%4+u)/4+layer*.00002
  uv[:,layer*k*2:(layer+1)*k*2,1]=(tile[:,None]//4+v)/2+layer*.00002
 rgba=np.repeat(native[:,:,None,:],2,axis=2).reshape(count,k*2,4);rgba=np.concatenate([rgba,rgba],1).reshape(-1,4)
 xyz=vertices.reshape(-1,3).astype('<f4');uv=uv.reshape(-1,2).astype('<f4');normal,_=B.normals_and_tangents(xyz,faces,uv)
 # The 25-micron topology-support walls must not dominate the tangent of the
 # actual hair surface. U follows card width, V follows the source flow curve.
 across_rows=np.repeat(span[:,:,None,:],2,axis=2).reshape(count,k*2,3)
 across_rows=np.concatenate([across_rows,across_rows],1).reshape(-1,3)
 flow_rows=np.repeat(tangent[:,:,None,:],2,axis=2).reshape(count,k*2,3)
 flow_rows=np.concatenate([flow_rows,flow_rows],1).reshape(-1,3)
 across_rows-=normal*(across_rows*normal).sum(1)[:,None];across_rows/=np.linalg.norm(across_rows,axis=1,keepdims=True)
 sign=np.where((np.cross(normal,across_rows)*flow_rows).sum(1)<0,-1,1)
 tan=np.c_[across_rows,sign].astype('<f4')
 proof=dict(source_R7_glb=r7['glb_path'],source_R7_glb_sha256=r7['sha256'],source_main_centre_curves=7200,
      source_centre_curves_sha256=hashlib.sha256(paths.astype('<f8').tobytes()).hexdigest(),
      original_2400_coherent_groups_preserved=True,three_cross_cards_per_group=True,
      opaque_R7_tubes_not_carried_forward=True,physical_support_thickness_m=.000025,
      individual_visible_fibres_m=[.00020,.00060],card_width_m=[.0095,.0135],
      old_nominal_R5_footprint_and_origin_preserved=True,edge_restrained_cards=int(bad.sum()),
      source_native_linear_COLOR0_bytes_reused_from_R7=True,no_new_pigment_texture=True,
      alpha_physical_construction_is_photo_interpretation=True)
 return xyz,normal,uv,tan,rgba,faces,proof

def build():
 assert sha(R7)==R7SHA and sha(B.SOURCE)==B.SOURCE_SHA
 old=next(e for e in json.loads(B.SOURCE.read_text())if e['sku']==SKU)
 source7=next(e for e in json.loads(R7.read_text())if e['sku']==SKU)
 assert sha(old['glb_path'])==old['sha256'] and sha(source7['glb_path'])==source7['sha256']
 out=D/'models'/old['id'];assert not out.exists();out.parent.mkdir(exist_ok=True)
 subprocess.run(['/usr/bin/ditto','--clone',old['asset_dir'],str(out)],check=True)
 od,ob=glb(old['glb_path']);d=copy.deepcopy(od);binary=bytearray(ob)
 xyz,normals,uv,tangents,colours,faces,flow=cards_from_R7(source7,od,ob)
 print('CARDS',len(xyz),len(faces),flush=True);atlas(out)
 def view(content,target=None):
  binary.extend(b'\0'*(-len(binary)%4));v=dict(buffer=0,byteOffset=len(binary),byteLength=len(content));binary.extend(content)
  if target:v['target']=target
  d['bufferViews'].append(v);return len(d['bufferViews'])-1
 def acc(a,kind,component=5126,target=34962):
  a=np.asarray(a,'<u4'if component==5125 else'u1'if component==5121 else'<f4');i=len(d['accessors']);item=dict(bufferView=view(a.tobytes(),target),componentType=component,count=len(a),type=kind,min=a.min(0).tolist(),max=a.max(0).tolist())
  if component==5121:item['normalized']=True
  d['accessors'].append(item);return i
 attrs=dict(POSITION=acc(xyz,'VEC3'),NORMAL=acc(normals,'VEC3'),TEXCOORD_0=acc(uv,'VEC2'),TANGENT=acc(tangents,'VEC4'),COLOR_0=acc(colours,'VEC4',5121))
 indices=acc(faces.reshape(-1,1),'SCALAR',5125,34963)
 sampler=len(d['samplers']);d['samplers'].append(dict(magFilter=9729,minFilter=9987,wrapS=33071,wrapT=33071))
 def texture(file):
  ii=len(d['images']);d['images'].append(dict(name=file,mimeType='image/png',bufferView=view((out/file).read_bytes())));ti=len(d['textures']);d['textures'].append(dict(source=ii,sampler=sampler));return ti
 ai=texture('white-intrinsic-fibre-alpha-atlas.png');ni=texture('intrinsic-fibre-cylinder-normal-atlas.png');oi=texture('intrinsic-hair-rough-nonmetal.png')
 material=dict(name='own-ivory-fine-curved-alpha-fibres',pbrMetallicRoughness=dict(baseColorFactor=[1,1,1,1],baseColorTexture=dict(index=ai,texCoord=0),metallicFactor=1.,roughnessFactor=1.,metallicRoughnessTexture=dict(index=oi,texCoord=0)),normalTexture=dict(index=ni,texCoord=0,scale=.55),alphaMode='MASK',alphaCutoff=.32,doubleSided=True,extensions=dict(KHR_materials_sheen=dict(sheenColorFactor=[.12,.11,.10],sheenRoughnessFactor=1.)))
 mi=len(d['materials']);d['materials'].append(material);mesh=len(d['meshes']);name='coherent-curved-cross-haircards-with-fine-tapered-alpha-fibres'
 d['meshes'].append(dict(name=name,primitives=[dict(attributes=attrs,indices=indices,material=mi,mode=4)]));node=len(d['nodes']);d['nodes'].append(dict(name=name,mesh=mesh));d['scenes'][0]['nodes'].append(node)
 allold=np.concatenate([B.array(od,ob,p['attributes']['POSITION'])for m in od['meshes']for p in m['primitives']]);positions=np.r_[allold,xyz];dims=((positions.max(0)-positions.min(0))*100).tolist()
 meta=copy.deepcopy(od['extras']['metadata']);meta.update(dimensions_cm=dims,model_revision='own-ivory-curved-fine-alpha-haircards-prototype-R8',quality_label='İnce kıvırcık lifler · Yumuşak dört kat · Yaklaşık ölçek')
 meta['quality_note']+=' İri tutam akışı R7 merkezlerinden korundu; görünür ince lifler fiziksel kıvrılan MASK haircard yapısı ve yalnız intrinsik lif alfa/normal atlası ile yorumlandı. Dip/uç pigmentleri kendi lineer COLOR_0 değerleridir; alfa atlasının RGB kanalları nötr beyazdır.'
 meta['source_evidence_files']=meta['source_evidence_files']+[str(R7),str(out/'macroflow-pigment-and-intrinsic-alpha-proof.json')];d['extras']['metadata']=meta
 target=out/Path(old['glb_path']).name;write_glb(target,d,bytes(binary));nd,nb=glb(target);assert nb[:len(ob)]==ob
 geometry=[]
 for m in od['meshes']:
  for p in m['primitives']:
   for key,i in {**p['attributes'],'indices':p['indices']}.items():
    assert attr(od,ob,i)==attr(nd,nb,i);geometry.append(dict(mesh=m['name'],attribute=key,sha256=attr(od,ob,i),byte_identical=True))
 model=json.loads((out/'model.json').read_text());model['metadata']=meta
 model['materials']['own-ivory-fine-curved-alpha-fibres']=dict(baseColorFactor=[1,1,1,1],baseColorTexture='white-intrinsic-fibre-alpha-atlas.png',normalTexture='intrinsic-fibre-cylinder-normal-atlas.png',metallicRoughnessTexture='intrinsic-hair-rough-nonmetal.png',normalScale=.55,metallic=1,roughness=1,doubleSided=True,alphaMode='MASK',alphaCutoff=.32,extras=dict(intrinsic_alpha_only=True,vertex_color_single_native_pigment_source=True,physical_sheen=dict(sheenColorFactor=[.12,.11,.10],sheenRoughnessFactor=1)))
 model['meshes'].append(dict(name=name,material='own-ivory-fine-curved-alpha-fibres',positions=xyz.reshape(-1).tolist(),normals=normals.reshape(-1).tolist(),uvs=uv.reshape(-1).tolist(),indices=faces.reshape(-1).tolist(),colorsLinearNormalizedBytes=colours.reshape(-1).tolist()))
 dump(out/'model.json',model)
 e=copy.deepcopy(old);e.update(meta,asset_dir=str(out),model_path=str(out/'model.json'),glb_path=str(target),sha256=sha(target),bytes=target.stat().st_size,geometry_validation=str(out/'geometry-validation.json'),material_validation=str(out/'material-validation.json'),model_revision=meta['model_revision'],quality_pending=True,actual_browser_review_passed=False,model_status='ready_for_browser_review',frozen=False)
 e.pop('native_renders',None);e.pop('independent_validation_file',None);assert e['bytes']<96*2**20
 maps=[]
 for im in nd['images']:
  v=nd['bufferViews'][im['bufferView']];start=v.get('byteOffset',0);content=nb[start:start+v['byteLength']];pil=Image.open(io.BytesIO(content));maps.append(dict(file=im['name'],path=str(out/im['name']),sha256=hashlib.sha256(content).hexdigest(),native_resolution=list(pil.size)))
 dump(out/'material-validation.json',dict(valid=True,maps=maps,old_own_RGB_PNGs_preserved=True,atlas_RGB_exact_white=True,own_native_pigment_COLOR0_applied_once=True,intrinsic_alpha_normal_only=True,alphaMode='MASK',doubleSided=True))
 dump(out/'geometry-validation.json',dict(valid=True,source_R5_old_attribute_checks=geometry,macroflow=flow,new_card_supports_closed_thin_solids=True))
 preserved=[]
 for p in Path(old['asset_dir']).glob('*.png'):
  if p.name in {'on.png','yan.png','on-capraz.png','ustten.png','arka.png'}:continue
  assert sha(p)==sha(out/p.name);preserved.append(dict(name=p.name,sha256=sha(p),unchanged=True))
 proof=dict(source_R5_manifest=str(B.SOURCE),source_R5_manifest_sha256=B.SOURCE_SHA,source_R7_manifest=str(R7),source_R7_manifest_sha256=R7SHA,macroflow=flow,old_R5_complete_BIN_prefix_byte_identical=True,old_R5_BIN_prefix_sha256=hashlib.sha256(ob).hexdigest(),old_R5_glb_sha256_unchanged=sha(old['glb_path'])==old['sha256'],R7_glb_sha256_unchanged=sha(source7['glb_path'])==source7['sha256'],old_PNG_files=preserved,original_JPEGs_unchanged=all(sha(o['path'])==o['sha256']for o in old['original_images']),atlas_proof=str(out/'intrinsic-alpha-atlas-proof.json'),actual_Three_MASK_doubleSide_gate_required=True,native_preview_limitation='Existing native renderer does not implement alpha-test hair silhouettes; native model JSON is supplied, but actual Three.js source comparison is the required visual gate.',ready_claim=False)
 dump(out/'macroflow-pigment-and-intrinsic-alpha-proof.json',proof);dump(out/'entry.json',e)
 check=V.check(e);dump(out/'independent-binary-alpha-haircard-check.json',check)
 return e

if __name__=='__main__':
 output=D/'frozen-own-ivory-fine-curved-alpha-haircard-prototype-01-manifest.json';assert not output.exists()
 e=build();e.update(frozen=True,quality_pending=True,actual_browser_review_passed=False)
 dump(Path(e['asset_dir'])/'entry.json',e);dump(output,[e]);print(output,sha(output),e['bytes'],e['sha256'],flush=True)
