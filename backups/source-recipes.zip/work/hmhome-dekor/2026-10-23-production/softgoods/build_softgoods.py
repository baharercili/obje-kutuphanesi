"""Exact-SKU sewn H&M textiles; all mutations remain in this production folder."""
from pathlib import Path
import sys,json,math,hashlib,importlib.util,shutil,re
sys.dont_write_bytecode=True
import numpy as np
from PIL import Image,ImageFilter,ImageDraw
R=Path(__file__).resolve().parent;H=R.parents[1];Z=H.parent/'zarahome-dekor';sys.path.insert(0,str(Z))
from export_catalog import export_assets,read_glb,write_glb
from vase_geometry import _finalize
sp=importlib.util.spec_from_file_location('hm_softgoods_readonly_helpers',H/'2026-10-21/vases/build_vases.py');G=importlib.util.module_from_spec(sp);sp.loader.exec_module(G);B=G.B;M=G.M;T=math.tau
_export_spec=importlib.util.spec_from_file_location('hm_softgoods_glb_only',R/'approved-exporter-glb-only/export_catalog.py');_export=importlib.util.module_from_spec(_export_spec);_export_spec.loader.exec_module(_export);export_assets=_export.export_assets
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def turkish_sentence_case(text):
 low=text.translate(str.maketrans({'I':'ı','İ':'i'})).lower();return ('İ'if low[:1]=='i'else low[:1].upper())+low[1:]
def solid(name,mat,v,f,uv=None):return B.solid(name,mat,v,f,uv)
def merge(parts,name,mat):
 v=[];f=[];uv=[]
 for p in parts:
  off=len(v);v+=p['_vertices'];uv+=p['_uvs'];f +=[tuple(i+off for i in face)for face in p['_faces']]
 return solid(name,mat,v,f,uv)
def source(pid):
 p=R/'source-evidence'/(pid+'.json');q=json.loads(p.read_text())if p.exists()else{};url='https://www2.hm.com/tr_tr/productpage.'+pid+'.html';valid=q.get('identity_verified')is not False and q.get('sku')==pid and q.get('url')==url and bool(re.search(r'(?:Ürün No\.|Art\. No\.)\s*:\s*'+pid,q.get('description','')))
 if not valid:
  p=R/'cached-pdp'/(pid+'.json');q=json.loads(p.read_text())if p.exists()else{};valid=q.get('identity_verified')and q.get('material_composition_verified')
 if not valid:
  row=next(x for x in json.loads((R/'joined-softgoods-queue.json').read_text())['products']if x['sku']==pid);q=dict(sku=pid,url=url,description='ExactSKU identity from the observed official category card and its linked PDP URL: '+url,productHeading=row['name'],materials='Resmî lif bileşimi okunamadı; kumaş görünümü bu SKU’nun kendi fotoğrafından yorumlanır.',sizes='',source_method='official_observed_category_exact_sku',source_market='Türkiye',source_category_evidence=str(R/'joined-softgoods-queue.json'),_material_evidence_status='unavailable_photo_interpreted')
 q=dict(q);assert q['sku']==pid and q['url']==url and pid in q['description'];q.setdefault('_material_evidence_status','verified');q['_size_source_kind']='official_tr_live_beden_selector';q['_size_source_urls']=[q['url']];q['_size_scope']='PDP visible selected size label'
 if valid and p.parent.name=='cached-pdp':q['_size_source_kind']='official_cached_pdp';q['_size_source_urls']=[q['official_pdp_url']]
 if not re.search(r'\d+(?:[.,]\d+)?\s*[xX×]\s*\d',q.get('sizes','')):
  gridfile=next((R/'source-evidence').glob('softgoods-official-grid-size-anchors-*.json'));grid=json.loads(gridfile.read_text());items=grid.get('products',grid)
  if pid in items:
   item=items[pid];anchor=item['anchors'][0];q['sizes']=anchor['verbatim_size_tag'];q['_size_source_kind']='official_tr_visible_exact_sku_card';q['_size_source_urls']=[anchor['category_url'],anchor['source_url']];q['_size_scope']=anchor['scope'];q['_grid_size_evidence']=dict(path=str(gridfile),sha256=sha(gridfile),anchor=anchor)
  else:q['_size_source_kind']='official_tr_live_description';q['_size_scope']='Physical dimensions quoted in exactSKU official description; no sibling size transfer.'
 raw=json.dumps(q,ensure_ascii=False,sort_keys=True).encode();snapshot=R/'source-evidence'/(pid+'-joined-'+hashlib.sha256(raw).hexdigest()[:12]+'.json')
 if not snapshot.exists():dump(snapshot,q)
 return q,snapshot

def material(pid,key,master,box,hero,kind='linen',physical_tile=.08):
 out=R/'materials'/pid/key;out.mkdir(parents=True,exist_ok=True);im=Image.open(master['path']);rgb=im.convert('RGB');patch=rgb.crop(box);patch.save(out/'donor-crop-native.png');a=np.asarray(patch,np.float32)/255;before=a.copy();low=np.asarray(patch.filter(ImageFilter.GaussianBlur(4 if kind=='velvet'else 25 if kind=='pile'else 7)),np.float32)/255;hm=Image.open(hero['path']).convert('RGB');ww,hh=hm.size;hp=hm.crop((int(ww*.43),int(hh*.46),int(ww*.57),int(hh*.54)));target=np.median(np.asarray(hp,np.float32).reshape(-1,3),axis=0)/255
 # High frequency dyed yarn detail comes from this SKU only. Broad photographic folds and lighting are removed.
 a=np.clip((a-low)*(.45 if kind=='velvet'else .65)+target,0,1);n=a.shape[0];edge=12
 for axis in[0,1]:
  for j in range(edge):
   w=(1-j/edge)**2;aa=[slice(None)]*3;bb=[slice(None)]*3;aa[axis]=j;bb[axis]=-1-j;aa=tuple(aa);bb=tuple(bb);mid=(a[aa]+a[bb])/2;a[aa]=a[aa]*(1-w)+mid*w;a[bb]=a[bb]*(1-w)+mid*w
 # A2K atlas repeats native512px donor detail; it does not claim2K unique photographic detail.
 N=2048;coord=np.arange(N)%n;atlas=a[coord[:,None],coord[None,:]];Image.fromarray(np.rint(atlas*255).astype(np.uint8)).save(out/'albedo-2k.png');lum=atlas.mean(2);blur=np.asarray(Image.fromarray(np.rint(lum*255).astype(np.uint8)).filter(ImageFilter.GaussianBlur(2)),np.float32)/255;height=lum-blur;dy,dx=np.gradient(height*7.0);nn=np.stack([-dx,dy,np.ones_like(dx)],2);nn/=np.linalg.norm(nn,axis=2,keepdims=True);Image.fromarray(np.rint((nn+1)*127.5).astype(np.uint8)).save(out/'normal-2k.png');orm=np.zeros((N,N,3),np.uint8);orm[:,:,0]=255;orm[:,:,1]=np.clip((.83 if kind=='velvet'else .94)*255-height*40,0,255);Image.fromarray(orm).save(out/'orm-2k.png')
 stack=dict(source_path=master['path'],source_sha256=master['sha256'],source_pixels=master['pixels'],source_format=im.format,source_mode=im.mode,icc_profile_present=bool(im.info.get('icc_profile')),exif_orientation=im.getexif().get(274),crop_box_original_pixels=box,crop_pixels=list(patch.size),crop_pixel_identical=np.array_equal(np.array(patch),np.asarray(rgb)[box[1]:box[3],box[0]:box[2]]),operations=['Integer crop from immutable ownSKU original','Remove low-frequency donor fold illumination, retaining native fine yarn/dye residual','Set intrinsic mean from sameSKU isolated front fabric','12pixel edge-only repeat seam blend','Periodic native-pixel repeat to2K; no image upscaling or generated pixels','Approximate normal/roughness from local yarn luminance'],colour_reference_path=hero['path'],colour_reference_sha256=hero['sha256'],target_rgb=(target*255).tolist(),atlas_resolution=[N,N],unique_source_detail_resolution=list(patch.size),physical_donor_tile_metres_photo_estimated=physical_tile,generation=False,source_master_unchanged=sha(master['path'])==master['sha256'],resampling=False,detail_limit=f'2K atlas repeats native donor pixels; unique photographic detail remains{patch.width}×{patch.height}px. Fibre scale/normal/roughness are photo interpretations.');dump(out/'texture-provenance.json',stack)
 sheen=dict(sheenColorFactor=[.10,.035,.035]if kind=='velvet'else[.045,.04,.03],sheenRoughnessFactor=.80 if kind=='velvet'else .95)
 return dict(baseColorFactor=[1,1,1,1],metallic=1,roughness=1,baseColorTexture=str(out/'albedo-2k.png'),normalTexture=str(out/'normal-2k.png'),metallicRoughnessTexture=str(out/'orm-2k.png'),normalScale=.16 if kind=='velvet'else .65,doubleSided=False,extras=dict(photo_pixels_baked=True,photo_donor_surface_only=True,baked_reflections=False,intrinsic_material=True,physical_sheen=sheen,texture_resolution=2048,unique_source_detail_resolution=list(patch.size),atlas_tile_metres=physical_tile*N/n,source_master_sha256=master['sha256'],texture_provenance=str(out/'texture-provenance.json')))

def cloth_point(u,v,w,h,d,kind):
 x=w*.5*u*(1-.030*(1-v*v));y=h*.5+h*.5*v*(1-.058*(1-u*u));body=max(0,1-abs(u)**2.8)**.43*max(0,1-abs(v)**2.8)**.43;bulk=.0015+.0045*max(0,1-(u*v)**2)**.5;z=bulk+(d*.5-bulk)*body;edge=min(1-abs(u),1-abs(v));env=math.exp(-edge/.085)*(1-math.exp(-max(0,edge)/.006));fold=(math.sin(v*31+u*3.1)+.42*math.sin(v*63-u*2))*math.exp(-(1-abs(u))/.13);fold+=(math.sin(u*27-v*3.3)+.38*math.sin(u*59+v*2))*math.exp(-(1-abs(v))/.13);z+=.0015*fold*env
 if kind=='linen':z+=.0006*math.sin(u*7+v*2)*math.sin(v*5)*body
 return x,y,max(.0008,z)
def cushion(w,h,d,kind,tile,mat='fabric'):
 N=81;v=[];uv=[];f=[]
 for side in[-1,1]:
  for vv in np.linspace(-1,1,N):
   for uu in np.linspace(-1,1,N):
    x,y,z=cloth_point(float(uu),float(vv),w,h,d,kind);v.append((x,y,z*side));uv.append((x/tile+.5,y/tile+.5))
 nn=N*N
 for side in[0,1]:
  for j in range(N-1):
   for i in range(N-1):a=side*nn+j*N+i;b=a+N;f.extend([(a,b,a+1),(a+1,b,b+1)]if side==0 else[(a,a+1,b),(a+1,b+1,b)])
 boundary=list(range(N))+[j*N+N-1 for j in range(1,N)]+list(range((N-1)*N+N-2,(N-1)*N-1,-1))+[j*N for j in range(N-2,0,-1)]
 distance=0.
 for j,a in enumerate(boundary):
  b=boundary[(j+1)%len(boundary)];length=float(np.linalg.norm(np.array(v[b])-np.array(v[a])));off=len(v);corners=[v[a],v[b],v[nn+a],v[nn+b]];v.extend(corners);uv.extend([(distance/tile,corners[0][2]/tile),((distance+length)/tile,corners[1][2]/tile),(distance/tile,corners[2][2]/tile),((distance+length)/tile,corners[3][2]/tile)]);f.extend([(off,off+1,off+2),(off+1,off+3,off+2)]);distance+=length
 p=[solid('soft-filled-sewn-front-and-reverse-cloth-panels',mat,v,f,uv)];seam=[(v[a][0],v[a][1],0)for a in boundary];p.append(B.tube('fine-soft-continuous-sewn-perimeter',mat,seam,.00065,.00065,8,True,guide=[0,0,1]))
 # Hidden zip and seam threads follow the actual back/front surface, rather than floating in space or sinking inside.
 zippts=[]
 for u in np.linspace(-.48,.48,81):x,y,z=cloth_point(float(u),-.966,w,h,d,kind);zippts.append((x,y,-z-.00035))
 p.append(B.tube('concealed-reverse-zipper-welt',mat,zippts,.00065,.00055,8,False,guide=[0,0,1]))
 st=[]
 if kind in['linen','canvas']:
  for side in[-1,1]:
   for axis in[0,1]:
    L=h if axis==0 else w;count=int(L/.004)
    for k in range(count):
     a=-.94+1.88*(k+.10)/count;b=-.94+1.88*(k+.56)/count;pts=[]
     for t in[a,b]:u,vv=(side*.965,t)if axis==0 else(t,side*.965);x,y,z=cloth_point(u,vv,w,h,d,kind);pts.append((x,y,z+.00035))
     st.append(B.tube('individual-visible-seam-stitch',mat,pts,.00011,.00011,5,False,guide=[0,0,1]))
 if st:p.append(merge(st,'physical-small-stitch-line-along-four-edges',mat))
 return p

def split_front_reverse(parts,backmat='reverse'):
 main=parts[0];N=81;nn=N*N;whole=main['_vertices'];boundary=list(range(N))+[j*N+N-1 for j in range(1,N)]+list(range((N-1)*N+N-2,(N-1)*N-1,-1))+[j*N for j in range(N-2,0,-1)];result=[]
 for side,mat in[(-1,backmat),(1,'fabric')]:
  outer=whole[:nn]if side==-1 else whole[nn:2*nn];v=[(x,y,0)for x,y,z in outer]+list(outer);uv=main['_uvs'][:nn]*2;f=[]
  for layer in[0,1]:
   for j in range(N-1):
    for i in range(N-1):a=layer*nn+j*N+i;b=a+N;f.extend([(a,b,a+1),(a+1,b,b+1)]if layer==0 else[(a,a+1,b),(a+1,b+1,b)])
  distance=0.
  for j,a in enumerate(boundary):
   b=boundary[(j+1)%len(boundary)];length=float(np.linalg.norm(np.array(v[b])-np.array(v[a])));off=len(v);corners=[v[a],v[b],v[nn+a],v[nn+b]];v.extend(corners);uv.extend([(distance/.1,corners[0][2]/.1),((distance+length)/.1,corners[1][2]/.1),(distance/.1,corners[2][2]/.1),((distance+length)/.1,corners[3][2]/.1)]);f.extend([(off,off+1,off+2),(off+1,off+3,off+2)]);distance+=length
  result.append(solid('closed-own-'+('reverse-ivory'if side==-1 else'front-beige')+'-filled-cloth-panel',mat,v,f,uv))
 for q in parts[1:]:
  if 'zipper'in q['name']or'perimeter'in q['name']:q['material']=backmat
  result.append(q)
 return result

INNER_PIDS={'1100263002','1100264002','1335083001','1356971001','1357013001','1357018001','1357020001'}
HERO_SCALED_PIDS={'1337147001','1337147002','1360669001','1360669003','1342819001','1342819002','1342819004','1357020001','1338587001','1338587002','1335083001','1356971001','1357013001','1357018001'}
DONORS={
 '1338587001':('',[520,950,1032,1462],'chenille'),
 '1338587002':('',[520,950,1032,1462],'chenille'),
 '1335083001':('',[520,950,1032,1462],'canvas'),
 '1356971001':('',[520,950,1032,1462],'canvas'),
 '1357013001':('',[520,950,1032,1462],'canvas'),
 '1357018001':('',[520,950,1032,1462],'canvas'),
 '1337147001':('',[520,950,1032,1462],'linen'),
 '1337147002':('',[520,950,1032,1462],'linen'),
 '1360669001':('',[520,950,1032,1462],'felt'),
 '1360669003':('',[520,950,1032,1462],'felt'),
 '1342819001':('',[520,950,1032,1462],'chenille'),
 '1342819002':('',[520,950,1032,1462],'chenille'),
 '1342819004':('',[520,950,1032,1462],'chenille'),
 '1357020001':('037d1f78f73c',[520,950,1032,1462],'canvas'),
 '1214165008':('',[0,0,512,512],'canvas'),
 '1100263002':('4ce2ebdd9c1c',[520,950,1032,1462],'canvas'),
 '1100264002':('fd4b6e623534',[520,950,1032,1462],'canvas'),
 '1275206001':('994877b11fe0',[650,1500,1162,2012],'canvas'),
 '1281327001':('',[0,0,512,512],'linen'),
 '1281327009':('',[0,0,512,512],'linen'),
 '1339055001':('',[0,0,512,512],'velvet'),
 '1304990001':('',[0,0,512,512],'canvas'),
 '0579381162':('21abbc9fa940',[400,650,912,1162],'velvet'),
 '0650691036':('eca64ea098e6',[800,1500,1312,2012],'velvet'),
 '1207164003':('c34fb99680a7',[350,1700,862,2212],'linen'),
 '1207164004':('5c8ecd78fb57',[450,1300,962,1812],'linen'),
 '1207164016':('e46a447a43f5',[350,1200,862,1712],'linen'),
 '1207264008':('38d80',[450,1250,962,1762],'linen'),
 '1207264009':('ac0f2eaa2fa3',[450,1250,962,1762],'linen'),
 '1312990005':('b91bef41d8be',[300,1400,812,1912],'canvas'),
}
def build(pid):
 frozen=[e for f in R.glob('frozen-batch-*-manifest.json')for e in json.loads(f.read_text())];assert pid not in {e['sku']for e in frozen},'Frozen SKU must be revised in a separate folder'
 from pattern_textures import SPECS as PATTERNS,make as pattern_material,plain_edge,back_stripes,plain_reverse,normalized_panel_uv,register,PHOTO_MOTIFS,RED_PIPED,GREEN_PIPED
 cap,ep=source(pid);m=re.search(r'(\d+(?:[.,]\d+)?)\s*[xX×]\s*(\d+(?:[.,]\d+)?)',cap.get('sizes',''));assert m,'No exactSKU physical cover size '+pid;short,long=sorted(float(s.replace(',','.'))for s in m.groups());w,h=long/100,short/100;d=.44*h;register(pid,w,h);refs=[r for r in json.loads((R/'original-image-masters.json').read_text())if r['sku']==pid];row=next(r for r in json.loads((R/'joined-softgoods-queue.json').read_text())['products']if r['sku']==pid);base=row['reference_images'][0]['url'].split('?')[0];hero=max((r for r in refs if r['url'].split('?')[0]==base),key=lambda r:r['pixels'][0]);suffix,box,kind=DONORS.get(pid,('',[0,0,512,512],'canvas'));assert pid in DONORS or pid in PATTERNS,'Unclassified SKU' ;donor=next(r for r in refs if suffix in r['path']);mat=pattern_material(pid,hero)if pid in PATTERNS else material(pid,'fabric',donor,box,hero,kind,(w*512/1245)if pid in HERO_SCALED_PIDS else .025);parts=cushion(w,h,d,kind,mat['extras']['atlas_tile_metres']);mats=dict(fabric=mat)
 if pid=='1312990005':
  backhero=next(r for r in refs if 'f45f680fdd9e'in r['path']);mats['reverse']=material(pid,'reverse',donor,box,backhero,kind,.025);parts=split_front_reverse(parts)
 if pid in PATTERNS:
  if pid=='1304990001':mats['reverse']=back_stripes(pid,mat);parts=split_front_reverse(parts)
  if pid=='1339055001'or pid in PHOTO_MOTIFS:mats['reverse']=plain_reverse(pid,mat);parts=split_front_reverse(parts)
  parts=normalized_panel_uv(parts);mats['edge']=plain_edge(pid,mat)
  for q in parts:
   if 'perimeter'in q['name']:
    q['material']='edge'
    if pid in RED_PIPED|GREEN_PIPED:
     ring=np.array(q['_vertices']).reshape(-1,9,3);centres=ring[:,:8].mean(1);replacement=B.tube(q['name'],'edge',centres.tolist(),.0012,.0012,8,True,guide=[0,0,1]);q.update(replacement)
 if pid in INNER_PIDS:parts=[q for q in parts if'zipper'not in q['name']]
 allv=np.concatenate([np.array(q['_vertices'])for q in parts]);lo=allv.min(0);hi=allv.max(0);scale=np.array([w/(hi[0]-lo[0]),h/(hi[1]-lo[1]),1.]);centre=np.array([(lo[0]+hi[0])/2,lo[1],(lo[2]+hi[2])/2]);meshes=[];checks=[]
 for q in parts:q['_vertices']=[tuple((np.array(v)-centre)*scale)for v in q['_vertices']];mm,cc=_finalize(G.orient(q));meshes.append(mm);checks.append(cc)
 repaired=M.ensure_uv_faces(meshes)+G.ensure_float32_uv(meshes);vv=np.concatenate([np.array(m['positions']).reshape(-1,3)for m in meshes]);dims=((vv.max(0)-vv.min(0))*100).tolist();fmt=lambda x:format(x,'g').replace('.','p');id='hm-'+pid+'-h'+fmt(short)+'-w'+fmt(long)+'-d'+fmt(round(dims[2],2));out=R/'models'/id;out.mkdir(parents=True,exist_ok=True);maps=[]
 for name,ma in mats.items():
  for slot in['baseColorTexture','normalTexture','metallicRoughnessTexture']:
   src=Path(ma[slot]);dst=out/(name+'-'+src.name);shutil.copyfile(src,dst);ma[slot]=dst.name;maps.append(dict(material=name,slot=slot,path=str(dst),pixels=list(Image.open(dst).size),sha256=sha(dst)))
 provenance=Path(mat['extras']['texture_provenance']);shutil.copyfile(provenance,out/'texture-provenance.json');shutil.copyfile(provenance.parent/'donor-crop-native.png',out/'donor-crop-native.png');refs.sort(key=lambda r:r['path']!=hero['path']);label=cap['materials'].split('BAKIM')[0].replace('ÜRÜN İÇERİĞİ','').strip();note=f'Resmî kılıf{short:g}×{long:g}cm planı korunur. Yaklaşık{dims[2]:.2f}cm dolgu derinliği ve yerel dikiş/fermuar ayrıntıları fotoğraf yorumudur; kılıf dolgu önizlemesiyle gösterilir, iç dolgu ürüne dahil olduğu iddia edilmez. Kendi512px kumaş donoru2K atlasta tekrarlanır; özgün ayrıntı artırılmadı.'
 meta=dict(id=id,sku=pid,brand='H&M Home',name=turkish_sentence_case(cap['productHeading']),category='Kırlentler',url=cap['url'],dimensions_cm=dims,official_measurements={'cover_size_label':m.group(0),'cover_short_side_cm':short,'cover_long_side_cm':long},source_dimensions_hwd_cm=[short,long,None],estimated_dimensions=True,estimated_fields=['filling_depth_cm','local_seam_zipper_geometry','fabric_weave_scale'],estimated_filling_depth_cm=dims[2],scale_note=note,material_label=label,source_market='Türkiye',source_size_pointer=str(ep)+'#sizes',source_evidence_files=[str(ep),str(R/'joined-softgoods-queue.json'),str(out/'texture-provenance.json')],source_images=[dict(url=r['url'],alt=r['alt'])for r in refs],original_image=hero['path'],original_image_url=hero['url'],original_image_sha256=hero['sha256'],original_images=[{k:r[k]for k in['path','url','sha256']}for r in refs],variant_status_verbatim='Resmî exactSKU kılıf bedeni ve kumaş içeriği doğrulandı.',units='metres',up_axis='Y',origin='bottom bounding-box centre',photo_pixels_baked=True,baked_reflections=False,filling_profile={'power':2.8,'exponent':.43,'depth_is_photo_estimate':True},texture_resolution_policy='Native512px sameSKU donor; periodic2K atlas without upscaling. PBR normal/roughness are interpretations.',geometry_limitations=['Kılıfın dolgun önizlemesi fotoğraf yorumudur; üretici CAD/tarama verisi değildir.'])
 if pid in PATTERNS:
  meta.update(texture_resolution_policy='OwnSKU intrinsic artwork mask1024px; fine woven PBR normal/roughness2K are photo estimates. One source rectification pass; no marketing photograph/background wrapped.',scale_note=f'Resmî kılıf{short:g}×{long:g}cm planı korunur; yaklaşık{dims[2]:.2f}cm dolgu derinliği fotoğraf tahminidir. Baskı/nakış veya şerit yerleşimi yalnız bu SKU’nun kendi ön kumaş fotoğrafından ayrıştırıldı. Kılıf dolgu önizlemesiyle gösterilir.')
  if pid=='1304990001':meta.update(quality_label='Desen yorumu',quality_status='photo_interpreted',quality_note='Arkası resmî açıklamada çizgili; tam arka fotoğrafı bulunmadığından şeritlerin sayısı, aralığı ve başlangıç yeri görünen yan bölümden yorumlandı.')
  if pid in PHOTO_MOTIFS:meta.update(quality_label='Desen yorumu',quality_status='photo_interpreted',quality_note='Ön motif kendi ürün fotoğrafından ayrıştırıldı. Tam arka görünüm modele bağlanmadığı için arka yüzün düz zemin rengi ve yerel dikiş/desen fazı fotoğraf yorumudur.')
  if pid=='1339055001':meta.update(back_surface_note='Resmî açıklamada kareli nakış yalnız ön yüzde tariflidir. Arka tarafta aynı renkte düz kadife gösterilir; tam arka fotoğrafı yayımlanmadığından arka dikiş yerleşimi yorumdur.')
 if pid in INNER_PIDS:
  filling='Polyester'if'POLYESTER'in cap['productHeading']else'Kuş tüyü';meta.update(product_form='filled_inner_cushion',estimated_fields=['filling_depth_cm','local_seam_geometry','fabric_weave_scale'],scale_note=f'Resmî iç kırlent{short:g}×{long:g}cm planı korunur. {filling} dolgu ürüne dahildir; yaklaşık{dims[2]:.2f}cm dolgu derinliği ve kapalı dikili kenar formu fotoğraf yorumudur. Fermuar eklenmedi.')
 meta.update(source_size_kind=cap['_size_source_kind'],official_size_scope=cap['_size_scope'],source_market=cap.get('source_market','Türkiye'),material_source_url=cap.get('official_pdp_url',cap['url']),size_source_urls=cap['_size_source_urls'])
 if cap.get('_material_evidence_status')=='unavailable_photo_interpreted':meta.update(material_evidence_status='unavailable_photo_interpreted',variant_status_verbatim='Resmî exactSKU kart kimliği/bedeni ve özgün fotoğrafı bağlı; lif bileşimi okunamadığı için kumaş görünümü fotoğraf yorumudur.');label_parts=[line.strip(' *')for line in label.splitlines()if re.search(r'\d+\s*%',line)];meta['material_label']='; '.join(label_parts[:3])if label_parts else label
 dump(out/'model.json',dict(metadata=meta,materials=mats,meshes=meshes));dump(out/'geometry-validation.json',dict(valid=True,meshes=checks,closed_material_solids=True,triangles=sum(q['triangles']for q in checks),uv_repairs=repaired,profile=meta['filling_profile']));dump(out/'material-validation.json',dict(valid=True,maps=maps,source_masters_unchanged=all(sha(r['path'])==r['sha256']for r in refs),no_source_photo_upscale=True,texture_provenance=str(out/'texture-provenance.json')));report=export_assets(out/'model.json',out,id);gp=out/(id+'.glb');doc,binary=read_glb(gp)
 for ma in doc['materials']:ma.setdefault('extensions',{})['KHR_materials_sheen']=mats[ma['name']]['extras']['physical_sheen']
 doc['extensionsUsed']=sorted(set(doc.get('extensionsUsed',[]))|{'KHR_materials_sheen'});binary=M.embed_tangents(doc,binary);write_glb(gp,doc,binary);report['deliverable_sha256']['glb']=sha(gp);report['glb_bytes']=gp.stat().st_size;dump(report['files']['validation'],report);e={k:v for k,v in meta.items()if k not in['photo_pixels_baked','baked_reflections','units','up_axis','origin','geometry_limitations']};e.update(asset_dir=str(out),model_path=str(out/'model.json'),glb_path=str(gp),sha256=sha(gp),bytes=gp.stat().st_size,geometry_validation=str(out/'geometry-validation.json'),material_validation=str(out/'material-validation.json'),size_source_kind=cap['_size_source_kind'],size_source_urls=cap['_size_source_urls'],model_revision='hmhome-exact-sku-softgoods-2026-10-23-v1');dump(out/'entry.json',e);allentries=json.loads((R/'manifest.json').read_text())if(R/'manifest.json').exists()else[];dump(R/'manifest.json',[q for q in allentries if q['id']!=id]+[e]);print('BUILT',id,e['bytes'],flush=True)
if __name__=='__main__':
 for sku in sys.argv[1:]:build(sku)
