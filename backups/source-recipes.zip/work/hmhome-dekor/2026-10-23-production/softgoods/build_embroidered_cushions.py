"""Own front textile masks: white embroidery, jacquard and stitched grids."""
import sys
sys.dont_write_bytecode=True
import math,re,json
import numpy as np
from PIL import Image,ImageFilter
import build_shaped_softgoods as C
import build_flanged_softgoods as F
import pattern_textures as P
S=C.S;R=C.R
PIDS=['1335075003','1337095001','1337154001','1337157001','1337159001','1337161001','1339053001','1339055002','1339055003','1363057003','1363057004']

def material(pid,hero,w,h):
 out=R/'materials'/pid/'own-intrinsic-embroidery';out.mkdir(parents=True,exist_ok=True);im=Image.open(hero['path']).convert('RGB');height=1245*h/w;box=[145,round(1152-height/2),1390,round(1152+height/2)];im.crop(box).save(out/'donor-crop-native.png');n=1024;ny=round(n*h/w);v,u=np.mgrid[0:ny,0:n].astype(float);u/=n-1;v/=ny-1;uu=u*2-1;vv=v*2-1;x=768+(.5*1245-10)*uu*(1-.14*(1-vv*vv));y=1152+(.5*height-10)*vv*(1-.10*(1-uu*uu));a=np.asarray(im,float);ix=x.astype(int);iy=y.astype(int);fx=x-ix;fy=y-iy;sample=a[iy,ix]*(1-fx[:,:,None])*(1-fy[:,:,None])+a[iy,ix+1]*fx[:,:,None]*(1-fy[:,:,None])+a[iy+1,ix]*(1-fx[:,:,None])*fy[:,:,None]+a[iy+1,ix+1]*fx[:,:,None]*fy[:,:,None];lum=sample.mean(2);blur=np.asarray(Image.fromarray(np.clip(lum,0,255).astype(np.uint8)).filter(ImageFilter.GaussianBlur(5)),float);bg=np.median(sample[(u>.30)&(u<.70)&(v>.30)&(v<.70)],axis=0);rgb=np.broadcast_to(bg,(ny,n,3)).copy();relief=np.zeros((ny,n));inside=(u>.035)&(u<.965)&(v>.035)&(v<.965);pal=[bg.tolist()];method='Own front artwork mask; photographic background and broad fold illumination excluded.'
 if pid in ['1335075003','1337095001','1337157001']:
  weight=np.clip((abs(lum-blur)-3.0)/11,0,1)*inside
  if pid=='1337157001':weight*=((u<.18)|(u>.82)|(v<.18)|(v>.82))
  relief=weight*.95;rgb+=weight[:,:,None]*1.5
  if pid=='1337157001':rgb-=np.clip((blur-lum-6)/12,0,1)[:,:,None]*inside[:,:,None]*40
  method='White-on-white stitch/puncture relief isolated from the sameSKU luminance high frequency; intrinsic ivory albedo stays uniform instead of baking photographic shadows.'
 elif pid=='1337154001':
  chroma=sample[:,:,0]-sample[:,:,2];lo,hi=np.quantile(chroma[inside],[.20,.75]);mask=(chroma<(lo+hi)/2)&inside;base=np.median(sample[inside&~mask],axis=0);ink=np.median(sample[mask],axis=0);rgb=np.where(mask[:,:,None],ink,base);relief=mask*.35;pal=[base.tolist(),ink.tolist()]
 elif pid in ['1363057003','1363057004']:
  vp=np.median(sample[round(ny*.43):round(ny*.57)],axis=0);hp=np.median(sample[:,440:580],axis=1)
  def measured(profile):
   grey=profile.mean(1);mask=np.zeros(len(grey),bool);margin=round(len(grey)*.055);mid=len(grey)//2
   for a,b in [(margin,mid),(mid,len(grey)-margin)]:
    threshold=(np.quantile(grey[a:b],.15)+np.quantile(grey[a:b],.85))/2;mask[a:b]=grey[a:b]>threshold
   return mask
  vertical=measured(vp);horizontal=measured(hp);mask=np.logical_xor(vertical[None,:],horizontal[:,None]);values=lum[inside];q20,q40,q80,q95=np.quantile(values,[.20,.40,.80,.95]);base=np.median(sample[inside&(lum>q20)&(lum<q40)],axis=0);ink=np.median(sample[inside&(lum>q80)&(lum<q95)],axis=0);rgb=np.where(mask[:,:,None],ink,base);relief=mask*.35;pal=[base.tolist(),ink.tolist()];method='OwnSKU central vertical/horizontal wool-yarn runs and two intrinsic palettes measured independently; separable plaid reconstruction preserves broad bands and fine internal lines without photographic lighting eroding an edge.'
 elif pid in ['1339055002','1339055003']:
  vp=np.median(sample[round(ny*.44):round(ny*.54)],axis=0);hp=np.median(sample[:,470:550],axis=1);dark=vp.max(1)<100
  def runs(mask):
   e=np.diff(np.r_[False,mask,False].astype(int));return [(a,b)for a,b in zip(np.where(e==1)[0],np.where(e==-1)[0])if b-a>=2]
  br=runs(dark);base=np.median(sample[(u>.18)&(u<.25)&(v>.2)&(v<.3)],axis=0);rgb[:]=base
  for a,b in br:rgb[:,a:b]=np.median(vp[a:b],axis=0);relief[:,a:b]=.55
  if len(br)==8:
   for j in range(0,8,2):a,b=br[j][1],br[j+1][0];rgb[:,a:b]=np.median(vp[a:b],axis=0);relief[:,a:b]=.65
  hh=hp.mean(1);baseline=np.convolve(np.pad(hh,30,mode='edge'),np.ones(61)/61,mode='valid');hr=runs((baseline-hh)>12)
  for a,b in hr:rgb[a:b,:]=np.median(hp[a:b],axis=0);relief[a:b,:]=.65
  pal=[base.tolist()];method+=' Vertical black/cream pairs and horizontal coloured runs measured in the flat central row/column of thisSKU, excluding fold shadows.'
 else:
  threshold=145 if pid in ['1337159001','1337161001']else 110;mask=(lum<threshold)&inside
  if pid in ['1339053001','1363057003','1363057004']:mask&=(u>.05)&(u<.95)&(v>.05)&(v<.95)
  ink=np.median(sample[mask],axis=0);base=np.median(sample[inside&~mask],axis=0);rgb=np.where(mask[:,:,None],ink,base);relief=mask*(.8 if pid in ['1363057003','1363057004']else .45);pal=[base.tolist(),ink.tolist()]
 edge=(u<.018)|(u>.982)|(v<.018)|(v>.982);rgb[edge]=pal[0];relief[edge]=0;rng=np.random.default_rng(int(pid));rgb=np.clip(rgb+rng.normal(0,.45,(ny,n,1)),0,255);Image.fromarray(rgb.astype(np.uint8)).save(out/'albedo-native.png');N=2048;field=np.asarray(Image.fromarray(relief.astype(np.float32),'F').resize((N,N),Image.Resampling.BILINEAR));grain=rng.normal(0,.012,(N,N));dy,dx=np.gradient(field*2.5+grain);normal=np.stack([-dx,dy,np.ones_like(dx)],2);normal/=np.linalg.norm(normal,axis=2,keepdims=True);Image.fromarray(np.rint((normal+1)*127.5).astype(np.uint8)).save(out/'normal-2k.png');orm=np.zeros((N,N,3),np.uint8);orm[:,:,0]=255;orm[:,:,1]=239;Image.fromarray(orm).save(out/'orm-2k.png');prov=dict(source_path=hero['path'],source_sha256=hero['sha256'],source_pixels=hero['pixels'],crop_box_original_pixels=box,crop_pixels=[box[2]-box[0],box[3]-box[1]],mapped_artwork_pixels=[n,ny],operations=[method,'One own-source cloth-contour rectification pass, intrinsic palette/relief only','Procedural fine fibre normal/roughness are estimates; own stitch masks are preserved without photographic backdrop'],palette_rgb=pal,background_pixels_baked=False,full_marketing_photo_wrapped=False,source_master_unchanged=C.sha(hero['path'])==hero['sha256'],source_upscaled=False,physical_relief_photo_estimated=True);C.dump(out/'texture-provenance.json',prov)
 return dict(baseColorFactor=[1,1,1,1],metallic=1,roughness=1,baseColorTexture=str(out/'albedo-native.png'),normalTexture=str(out/'normal-2k.png'),metallicRoughnessTexture=str(out/'orm-2k.png'),normalScale=.95 if pid in ['1335075003','1337095001','1337157001']else .5,doubleSided=False,extras=dict(intrinsic_material=True,photo_pixels_baked=True,photo_donor_surface_only=True,baked_reflections=False,texture_provenance=str(out/'texture-provenance.json'),atlas_tile_metres=1.,physical_sheen=dict(sheenColorFactor=[.06,.045,.035],sheenRoughnessFactor=.9)))

def build(pid):
 cap,ep,refs,hero=C.own(pid);m=re.search(r'(\d+(?:[.,]\d+)?)\s*[Xx×]\s*(\d+(?:[.,]\d+)?)',cap['sizes']);assert m;short,long=sorted(float(x.replace(',','.'))for x in m.groups());w,h=long/100,short/100;d=.44*h;ma=material(pid,hero,w,h);parts=S.cushion(w,h,d,'canvas',1.);parts=P.normalized_panel_uv(S.split_front_reverse(parts));reverse=P.plain_reverse(pid,ma);mats=dict(fabric=ma,reverse=reverse)
 if pid in ['1337159001','1337161001']:
  piping=C.plain_piping(pid,ma);out=R/'materials'/pid/'plain-piping';Image.new('RGB',(4,4),(30,30,26)).save(out/'albedo.png');mats['piping']=piping
  for q in parts:
   if 'perimeter'in q['name']:
    ring=np.array(q['_vertices']).reshape(-1,9,3);centres=ring[:,:8].mean(1);q.update(S.B.tube('distinct-black-piped-four-edge-border','piping',centres.tolist(),.0014,.0014,8,True,guide=[0,0,1]))
 if pid in ['1363057003','1363057004']:
  stitches=[]
  for axis in [0,1]:
   for side in [-1,1]:
    for t in np.arange(-.97,.97,.01/(w if axis else h)*2):
     pts=[]
     for z in [-.003,.003]:
      u0,v0=(side*.985,t)if axis==0 else(t,side*.985);x,y,_=S.cloth_point(float(u0),float(v0),w,h,d,'canvas');pts.append((x,y,z))
     stitches.append(S.B.tube('physical-blanket-edge-stitch','reverse',pts,.00030,.00030,5,False,guide=[0,1,0]if axis==0 else[1,0,0]))
  parts.append(S.merge(stitches,'four-edge-blanket-stitch-loops','reverse'))
 if pid in ['1339053001','1363057003','1363057004']:
  # Short closed wool loops provide a physical surface silhouette. Their UVs
  # follow the same ownSKU artwork rather than adding a uniform-colour overlay.
  rng=np.random.default_rng(int(pid));loops=[]
  for j in range(6000):
   u0,v0=rng.uniform(-.995,.995,2);side=1 if j%2 else-1;x,y,z=S.cloth_point(float(u0),float(v0),w,h,d,'canvas');length=.0018 if pid=='1339053001'else .0009;p0=np.array([x,y,z*side]);tangent=np.array([math.cos(j*1.618),math.sin(j*1.618),0.]);pts=[p0-[0,0,side*.0001],p0+[0,0,side*length*.7]+tangent*length*.2,p0+[0,0,side*length]+tangent*length*.6,p0+[0,0,side*length*.6]+tangent*length*.9];q=S.B.tube('short-physical-wool-boucle-loop','fabric'if side==1 else'reverse',pts,.00016,.00013,3,False,guide=tangent.tolist());q['_uvs']=[(.5+vx/w,1-vy/h)for vx,vy,vz in q['_vertices']];loops.append(q)
  for side,material_name in [(1,'fabric'),(-1,'reverse')]:parts.append(S.merge([q for q in loops if q['material']==material_name],'closed-short-wool-loop-surface-'+str(side),material_name))
 if pid=='1337157001':parts.append(F.flange(w,h,.018,1.,False));mats['flange']=json.loads(json.dumps(reverse))
 note=f'Resmî nominal kılıf planı{short:g}×{long:g}cm korunur; yaklaşık{d*100:g}cm dolgu ve yerel işleme/dikiş kabartısı fotoğraf tahminidir. Ön desen yalnız kendiSKU fotoğrafından ayrıştırıldı; düz arka yüz ve dikişte desen fazı yorumdur.';C.finish(pid,parts,mats,cap,ep,refs,hero,[None,None,d]if pid=='1337157001'else[w,h,d],dict(cover_size_label=m.group(0),nominal_cover_hwd_cm=[short,long,None]),'embroidered_or_jacquard_cover_filled_preview',['filling_depth_cm','embroidery_relief_cm','local_seam_geometry','reverse_surface_phase']+(['outer_flange_extension_cm']if pid=='1337157001'else[]),note,dict(estimated_filling_depth_cm=d*100,quality_label='Desen/işleme yorumu',quality_status='photo_interpreted',quality_note='Ön işleme kendi ürün fotoğrafından ayrıştırıldı; iplik kabartısı, tam arka yüz ve dikişte desen başlangıcı fotoğraf yorumudur.'))

if __name__=='__main__':
 for pid in sys.argv[1:]or PIDS:build(pid)
