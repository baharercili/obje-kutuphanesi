"""Two root-requested connected-hood / directional-lock fur prototypes only."""
import sys,json,math,copy,shutil
sys.dont_write_bytecode=True
from pathlib import Path
import numpy as np
from PIL import Image,ImageFilter
import build_shaped_softgoods as C
import build_hooded_throw as GH
S=C.S;B=C.B;P=C.R;V=P/'special-softgoods-revision-02';TAU=math.tau

def bridge_cloth(back=False):
 N=81;grid=[];uv=[]
 def point(u,v):
  theta=math.pi+u*math.pi if back else u*math.pi
  top=np.array([.15*math.cos(theta),.76+.04*max(0,math.sin(theta))**1.4,.005+.065*math.sin(theta)])
  if back:bottom=np.array([-.16+.32*u,.14+.008*math.sin(math.pi*u),-.012+.008*math.sin(TAU*u)])
  else:bottom=np.array([.16*math.cos(theta),.70+.08*max(0,math.sin(theta))**1.4,.040+.030*math.sin(theta)])
  p=top*(1-v)+bottom*v;p[2]+=(.018 if back else .004)*math.sin(math.pi*u)*math.sin(math.pi*v)+.003*math.sin(u*TAU*2.5)*math.sin(math.pi*v);p[0]+=.004*math.sin(v*TAU*.7)*math.sin(math.pi*u);return p
 for u in np.linspace(0,1,N):
  row=[];tex=[]
  for v in np.linspace(0,1,N):row.append(point(u,v));tex.append((u,v))
  grid.append(row);uv.append(tex)
 grid=np.array(grid);normal=np.cross(np.gradient(grid,axis=1),np.gradient(grid,axis=0));normal/=np.linalg.norm(normal,axis=2,keepdims=True)
 # Actual hood base samples are the top row of both continuous cloth pieces.
 # The back runs all the way to the hem; no floating helmet/neck air gap.
 return shell(grid,normal,np.array(uv),back),point

def shell(grid,normal,uv,back):
 import importlib.util
 spec=importlib.util.spec_from_file_location('special_cloth_shell_readonly',P.parent/'curtains/build_curtains.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
 return module.shell('continuous-hood-to-back-hem'if back else'continuous-front-neck-to-soft-shoulders','fabric',grid,normal,.003,uv)

def connected_hood(old):
 original_panel=GH.panel;original_finish=C.finish
 # A narrow cloth roll follows the opening; no broad helmet/visor-like bridge.
 rim=[]
 for a in np.linspace(0,math.pi,121):rim.append((.15*math.cos(a),.76+.04*max(0,math.sin(a))**1.4-.0005+.0007*math.sin(a*11),.005+.065*math.sin(a)+.0007*math.sin(a*7)))
 neck=B.tube('thin-soft-same-fleece-hood-opening-hem','fabric',rim,.0016,.0013,6,False,guide=[0,0,1])
 def panel(name,corners,material='fabric',N=49):
  if name=='hanging-central-back-cloth':part,point=bridge_cloth(True);return[part],point
  return original_panel(name,corners,material,N)
 def finish(pid,parts,mats,cap,ep,refs,hero,target,official,form,estimated,note,extra):
  parts.append(neck)
  # Sparse hood/panel fibre loops visible inside an open hood become needle
  # streaks. The native fleece material retains the soft grain without them.
  parts=[q for q in parts if q['name']!='physical-small-fleece-loops-on-draped-panels']
  local=V/'materials'/pid/'fine-own-fleece';local.mkdir(parents=True,exist_ok=True);im=Image.open(hero['path']).convert('RGB');crop=im.crop((600,950,856,1206));crop.save(local/'donor-crop-native.png');a=np.asarray(crop,float);fine=a-np.asarray(crop.filter(ImageFilter.GaussianBlur(1.2)),float);colour=np.median(a.reshape(-1,3),axis=0);n=2048;yy,xx=np.mgrid[0:n,0:n];coord=np.arange(n)%256;detail=fine[coord[:,None],coord[None,:]];rgb=np.clip(colour+detail*.4,0,255);Image.fromarray(rgb.astype(np.uint8)).save(local/'own-fleece-albedo.png');h=detail.mean(2)/255*.10+.012*np.sin(TAU*xx/3.2)*np.sin(TAU*yy/3.4);dy,dx=np.gradient(h);nn=np.stack([-dx,dy,np.ones_like(dx)],2);nn/=np.linalg.norm(nn,axis=2,keepdims=True);Image.fromarray(np.rint((nn+1)*127.5).astype(np.uint8)).save(local/'normal.png');Image.new('RGB',(128,128),(255,246,0)).save(local/'orm.png');proof=dict(source_path=hero['path'],source_sha256=hero['sha256'],crop_box_original_pixels=[600,950,856,1206],crop_pixels=[256,256],operations=['Own immutable fleece-only native crop','Remove broad fold and isolated elongated grain with1.2px low-frequency subtraction','Repeat native fine fleece pixels plus sub2mm estimated microfleece normal','No full donor folds or sparse loop streaks on the inside/back panels'],source_master_unchanged=C.sha(hero['path'])==hero['sha256'],full_marketing_photo_wrapped=False,source_upscaled=False);C.dump(local/'texture-provenance.json',proof)
  for key,ma in mats.items():
   if key=='fabric':ma['baseColorTexture']=str(local/'own-fleece-albedo.png');ma['extras']['texture_provenance']=str(local/'texture-provenance.json')
   ma.update(normalTexture=str(local/'normal.png'),metallicRoughnessTexture=str(local/'orm.png'),normalScale=.65)
  extra.update(id=old['id'],revision_reason='Connected back cloth retained; broad false visor removed in favour of a narrow softly irregular same-fleece hem. Needle-like free loops inside the opening removed.',quality_note='Arka kumaş başlık altından etek kumaşına kesintisiz devam eder; başlık ağzı aynı kumaştan yaklaşık3mm yumuşak kıvrımlı kenardır. Kesin açık boy, kıvrım ve ölçek fotoğraf yorumudur.')
  return original_finish(pid,parts,mats,cap,ep,refs,hero,target,official,form,estimated,note,extra)
 GH.panel=panel;C.finish=finish;GH.R=V
 try:GH.build()
 finally:GH.panel=original_panel;C.finish=original_finish

def fur_material(pid,refs):
 donor=next(x for x in refs if 'da601c5646d9'in x['path']);out=V/'materials'/pid;out.mkdir(parents=True,exist_ok=True);box=[500,600,1012,1112];im=Image.open(donor['path']).convert('RGB');crop=im.crop(box);crop.save(out/'donor-crop-native.png');raw=np.asarray(crop,float);lum=raw.mean(2);colour=np.median(raw[(lum>np.quantile(lum,.90))&(lum<np.quantile(lum,.985))],axis=0)
 n=2048;yy,xx=np.mgrid[0:n,0:n];patch=crop.crop((128,128,384,384));a=np.asarray(patch,float);low=np.asarray(patch.filter(ImageFilter.GaussianBlur(3)),float);residual=(a-low);coord=np.arange(n)%256
 # Native own fur-only grain belongs to the visible tuft material. Eliminate
 # broad shadow/fold illumination; no dark AO or background shadow is baked.
 colour=np.median(raw[lum>np.quantile(lum,.97)],axis=0);detail=residual[coord[:,None],coord[None,:]];rgb=np.clip(colour+detail*.20,0,255);Image.fromarray(rgb.astype(np.uint8)).save(out/'own-cream-albedo.png');height=.012*np.sin(TAU*xx/7)+detail.mean(2)/255*.08;dy,dx=np.gradient(height);normal=np.stack([-dx,dy,np.ones_like(dx)],2);normal/=np.linalg.norm(normal,axis=2,keepdims=True);Image.fromarray(np.rint((normal+1)*127.5).astype(np.uint8)).save(out/'fine-fur-normal-2k.png');orm=np.zeros((n,n,3),np.uint8);orm[:,:,0]=255;orm[:,:,1]=252;Image.fromarray(orm).save(out/'fur-orm-2k.png');proof=dict(source_path=donor['path'],source_sha256=donor['sha256'],source_pixels=donor['pixels'],crop_box_original_pixels=box,crop_pixels=list(crop.size),native_micro_crop_relative_pixels=[128,128,384,384],intrinsic_cream_colour_rgb=colour.tolist(),colour_reference='Bright real fur locks within this own-SKU close-up; no hero backdrop or dark shadow median.',operations=['Immutable own-SKU fur-only donor retained','Warm-white intrinsic colour from actual bright locks plus native256px high-frequency fur pixels; broad shadows removed','Native crop residual repeated on visible flattened closed tuft ribbons, without photo enlargement','AO255 everywhere, nonmetal0, roughness252; no dark occlusion texture','Fine longitudinal normal deliberately restrained; actual mass supplied by1800 downward broad tufts, not thin-wire loops'],physical_normal_tile_metres_estimated=.025,source_master_unchanged=C.sha(donor['path'])==donor['sha256'],native_pixel_repeat_not_unique_2k_detail=True,source_upscaled=False,full_marketing_photo_wrapped=False);C.dump(out/'texture-provenance.json',proof)
 return dict(baseColorFactor=[1,1,1,1],metallic=1,roughness=1,baseColorTexture=str(out/'own-cream-albedo.png'),normalTexture=str(out/'fine-fur-normal-2k.png'),metallicRoughnessTexture=str(out/'fur-orm-2k.png'),normalScale=.18,doubleSided=False,extras=dict(intrinsic_material=True,photo_pixels_baked=False,baked_reflections=False,texture_provenance=str(out/'texture-provenance.json'),physical_sheen=dict(sheenColorFactor=[.18,.17,.155],sheenRoughnessFactor=1.0)))

def capsule_body():
 radius=.041;half=.19;straight=.165;end=half-straight;N=96;verts=[];uv=[];faces=[]
 def point(x,t):
  a=max(0,(abs(x)-straight)/end);r=radius*math.sqrt(max(0,1-a*a));dr=0 if a==0 else-math.copysign(radius*a/(end*math.sqrt(max(1e-9,1-a*a))),x);normal=np.array([-dr,math.sin(t),math.cos(t)]);normal/=np.linalg.norm(normal);return np.array([x,radius+r*math.sin(t),r*math.cos(t)]),normal
 for x in np.linspace(-half+.00001,half-.00001,129):
  for j in range(N+1):t=TAU*(j%N)/N;p,_=point(x,t);verts.append(p);uv.append((x/.025,t*radius/.025))
 for i in range(128):
  for j in range(N):a=i*(N+1)+j;b=a+N+1;faces.extend([(a,a+1,b),(a+1,b+1,b)])
 for side,start in[(-1,0),(1,128*(N+1))]:
  pole=len(verts);verts.append((side*half,radius,0));uv.append((side*half/.025,0))
  for j in range(N):faces.append((pole,start+j+1,start+j)if side==-1 else(pole,start+j,start+j+1))
 return B.solid('closed-soft-rounded-end-core-no-flat-cylinder-disc','fabric',verts,faces,uv),point

def directional_fur(old,data):
 pid='1360884001';cap,ep,refs,hero=data;ma=fur_material(pid,refs);body,point=capsule_body();rng=np.random.default_rng(int(pid));locks=[]
 for k in range(1800):
  if k<1300:x=rng.uniform(-.165,.165)
  else:x=(-1 if k%2 else 1)*rng.uniform(.165,.1898)
  theta=rng.uniform(0,TAU);p,normal=point(x,theta);gravity=np.array([0.,-1.,0.]);flow=gravity-normal*np.dot(gravity,normal)
  if np.linalg.norm(flow)<.1:flow=np.array([rng.choice([-1.,1.]),0.,0.])
  flow/=np.linalg.norm(flow);across=np.cross(normal,flow);length=rng.uniform(.030,.046);phase=rng.uniform(0,TAU);pts=[]
  direction=-1 if math.cos(theta)>0 else 1
  for f in np.linspace(0,1,11):
   # Following the capsule surface keeps upper locks OUTSIDE the core.
   # Adding raw downward gravity to an upward root normal buried the first
   # half of those locks inside the solid, exposing a shaved-looking top.
   a=theta+direction*f*length*.82/.041;xx=float(np.clip(x+length*.11*math.sin(phase)*f,-.1899,.1899));surface,nn=point(xx,a);lift=.00035+length*.17*math.sin(math.pi*f*.8);pts.append(surface+nn*lift+across*length*.045*(math.sin(f*TAU*.65+phase)-math.sin(phase))*f)
  q=B.tube('closed-flat-downward-soft-fur-tuft','fabric',pts,.00018,rng.uniform(.00075,.0011),8,False,guide=normal.tolist());cum=np.r_[0,np.cumsum(np.linalg.norm(np.diff(pts,axis=0),axis=1))]
  for i,pt in enumerate(pts):
   taper=1-.75*(i/(len(pts)-1))**1.5
   for j in range(9):index=i*9+j;q['_vertices'][index]=tuple(pt+(np.asarray(q['_vertices'][index])-pt)*taper);q['_uvs'][index]=(j/8*.002/.025,cum[i]/.025)
  locks.append(q)
 parts=[body,S.merge(locks,'directional-thick-curly-locks-cover-body-and-rounded-ends','fabric')];note='Resmî seçili15×45cm beden etiketi korunur.15cm kısa eksenin silindirik çap olarak yorumlanması ve üçüncü eksen fotoğraf tahminidir. Yuvarlatılmış kapalı iç gövdenin tamamı, uçlar dahil, aşağı yönlenen yaklaşık3–4,6cm kıvrılmış tutamlarla kaplanır; tutam kalınlığı/yoğunluğu ve iç gövde oranı tahmindir. Renk kendiSKU yakın planındaki gerçek açık krem/beyaz post liflerinden türetildi.'
 return C.finish(pid,parts,dict(fabric=ma),cap,ep,refs,hero,[.45,.15,.15],old['official_measurements'],'long_fur_cylindrical_bolster',['short_axis_diameter_interpretation','third_axis_depth_cm','fur_lock_length_density_and_thickness','rounded_inner_core_geometry'],note,dict(id=old['id'],quality_label='Yaklaşık uzun post görünümü',quality_status='preview_limited',quality_note='Kendi açık krem/beyaz post donörü ve aşağı yönlenen fiziksel kıvırcık tutamlar kullanıldı.15cm çap yorumu, lif/tutam yoğunluğu ve görünmeyen iç gövde fotoğraf tahminidir.',revision_reason='Root actual review rejected gray fine-wire fog and bare flat end disc. Rounded core plus thick directional locks cover both real ends.'))

def main():
 assert not(V/'FINAL-FROZEN.json').exists();V.mkdir(exist_ok=True);shutil.copyfile(P/'joined-softgoods-queue.json',V/'joined-softgoods-queue.json');old={e['sku']:e for e in json.loads((P/'frozen-batch-19-manifest.json').read_text())};targets=sys.argv[1:]or['1344727001','1360884001'];assert set(targets)<=set(old);data={k:C.own(k)for k in targets};C.own=lambda pid:data[pid];C.R=V;S.R=V
 if not(V/'manifest.json').exists():C.dump(V/'manifest.json',[])
 for pid in targets:
  connected_hood(old[pid])if pid=='1344727001'else directional_fur(old[pid],data[pid])
if __name__=='__main__':main()
