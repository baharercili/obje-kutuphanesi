from pathlib import Path
import json,hashlib,math
import numpy as np
from PIL import Image,ImageFilter
R=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
SPECS={
'1214165008':dict(box=[145,535,1390,1770],kind='narrow_stripes'),
'1281327001':dict(box=[146,535,1390,1760],kind='beige_stripes'),
'1281327009':dict(box=[148,530,1390,1750],kind='pink_stripes'),
'1339055001':dict(box=[145,535,1390,1755],kind='embroidered_grid'),
'1304990001':dict(box=[152,545,1375,1770],kind='trex'),
}
PHOTO_MOTIFS={
 '1353945001':'printed_motif','1354428001':'printed_motif',
 '1354534001':'dark_embroidery','1354534002':'dark_embroidery',
 '1354535001':'printed_motif','1354535002':'printed_motif',
 '1354536001':'printed_motif','1354536002':'printed_motif','1354536003':'pale_print',
 '1354537001':'dark_embroidery','1354537002':'dark_embroidery','1354537003':'printed_motif',
 '1354539001':'printed_motif','1354539002':'printed_motif','1354539003':'printed_motif','1354539004':'printed_motif',
 '1356790001':'full_print','1356790002':'printed_motif',
 '1366899001':'printed_motif','1366899002':'printed_motif',
}
def register(pid,w,h):
 if pid in PHOTO_MOTIFS:
  height=1245*h/w;SPECS[pid]=dict(box=[145,round(1152-height/2),1390,round(1152+height/2)],kind=PHOTO_MOTIFS[pid],source_orientation='Own defaultSKU front is square or horizontal as pictured; official selected plan controls aspect.')
 if pid in ['1338598015','1360669010']:
  height=1245*h/w;SPECS[pid]=dict(box=[145,round(1152-height/2),1390,round(1152+height/2)],kind='narrow_stripes'if pid=='1338598015'else'white_thin_check')
RED_PIPED={'1353945001','1354428001','1354537003','1354539001','1354539003','1356790001'}
GREEN_PIPED={'1354539002','1354539004','1356790002'}
SINGLE_INK={'1353945001','1354535001','1354535002','1354536001','1354536002','1354536003','1354537003','1356790002'}
def registered_front(pid,a,box,u,v):
 h,w=a.shape[:2];x0,y0,x1,y1=box;uu=u*2-1;vv=1-v*2;x=(x0+x1)/2+.5*(x1-x0)*uu*(1-.14*(1-vv*vv));y=(y0+y1)/2-.5*(y1-y0)*vv*(1-.10*(1-uu*uu));evidence=dict(method='Own front contour estimated with14percent side pinch and10percent top/bottom pinch, checked against the ownSKU front photograph.',side_pinch=.14,top_bottom_pinch=.10)
 if pid not in RED_PIPED|GREEN_PIPED:return x,y,evidence
 r,g,b=a.transpose(2,0,1);mask=((r-g>40)&(r-b>30))if pid in RED_PIPED else((g-b>8)&(r-b>5)&(a.mean(2)<155)&(r<185));ys,xs=np.nonzero(mask)
 if len(xs)>100:
  x0,x1=int(xs.min()),int(xs.max())+1;y0,y1=int(ys.min()),int(ys.max())+1
 if pid=='1354428001':
  measured=[x0,y0,x1,y1];inset=15.;x0+=inset;x1-=inset;y0+=inset;y1-=inset;x=(x0+x1)/2+.5*(x1-x0)*uu*(1-.14*(1-vv*vv));y=(y0+y1)/2-.5*(y1-y0)*vv*(1-.10*(1-uu*uu));return x,y,dict(method='OwnSKU coloured perimeter bounding rectangle, with photographed14percent side pinch and10percent top/bottom pinch; avoids red train/text being mistaken for a missing border segment.',observed_coloured_perimeter_bounds=measured,inset_source_pixels=inset,piping_excluded_from_front_artwork=True,local_contour_photo_estimated=True)
 lx=np.full(h,np.nan);rx=lx.copy();ty=np.full(w,np.nan);by=ty.copy();marginx=int((x1-x0)*.23);marginy=int((y1-y0)*.23)
 if pid=='1354428001':mask[y0:y1,x0:x0+marginx]|=a[y0:y1,x0:x0+marginx].mean(2)<95
 for row in range(max(0,y0-15),min(h,y1+15)):
  left=np.flatnonzero(mask[row,max(0,x0-25):x0+marginx]);right=np.flatnonzero(mask[row,x1-marginx:min(w,x1+25)])
  if len(left):lx[row]=left[0]+max(0,x0-25)
  if len(right):rx[row]=right[-1]+x1-marginx
 for col in range(max(0,x0-25),min(w,x1+25)):
  top=np.flatnonzero(mask[max(0,y0-20):y0+marginy,col]);bottom=np.flatnonzero(mask[y1-marginy:min(h,y1+20),col])
  if len(top):ty[col]=top[0]+max(0,y0-20)
  if len(bottom):by[col]=bottom[-1]+y1-marginy
 limits=[(x0-5,x0+.11*(x1-x0)),(x1-.11*(x1-x0),x1+5),(y0-5,y0+.12*(y1-y0)),(y1-.12*(y1-y0),y1+5)];rawcurves=[lx,rx,ty,by]
 for curve,(low,high)in zip(rawcurves,limits):curve[(curve<low)|(curve>high)]=np.nan
 valid=[int(np.isfinite(q).sum())for q in rawcurves]
 if min(valid[:2])<.30*(y1-y0)or min(valid[2:])<.30*(x1-x0):return x,y,dict(evidence,piping_registration_unavailable_valid_counts=valid)
 curves=[]
 for number,q in enumerate(rawcurves):
  indices=np.arange(len(q));axis0,axis1=(y0,y1)if number<2 else(x0,x1);t=(indices-(axis0+axis1)/2)/((axis1-axis0)/2);good=np.isfinite(q)
  for _ in range(3):
   coefficients=np.polyfit(t[good],q[good],3);fitted=np.polyval(coefficients,t);residual=abs(q-fitted);mad=np.nanmedian(residual[good]);keep=np.isfinite(q)&(residual<max(5,3*mad))
   if keep.sum()>good.sum()*.45:good=keep
  q=np.polyval(coefficients,t);q=np.clip(q,*limits[number]);curves.append(q)
 lx,rx,ty,by=curves;x=x0+(x1-x0)*u;inset=10.
 for _ in range(3):
  top=np.interp(x,np.arange(w),ty);bottom=np.interp(x,np.arange(w),by);y=top+inset+v*(bottom-top-2*inset);left=np.interp(y,np.arange(h),lx);right=np.interp(y,np.arange(h),rx);x=left+inset+u*(right-left-2*inset)
 evidence=dict(method='OwnSKU coloured perimeter observed on four edges, with robust smooth cubic fits excluding interior artwork; alternating edge interpolation maps only cloth inside the physical piping.',observed_coloured_perimeter_bounds=[x0,y0,x1,y1],inset_source_pixels=inset,piping_valid_samples=valid,curves_sampled_every32px=[q[::32].tolist()for q in curves],piping_excluded_from_front_artwork=True);return x,y,evidence
def make(pid,hero):
 out=R/'materials'/pid/'intrinsic-pattern';out.mkdir(parents=True,exist_ok=True);spec=SPECS[pid];im=Image.open(hero['path']).convert('RGB');box=spec['box'];im.crop(box).save(out/'donor-crop-native.png');n=1024;ny=min(n,round(n*(box[3]-box[1])/(box[2]-box[0])))if pid in PHOTO_MOTIFS else n;v,u=np.mgrid[0:ny,0:n].astype(float);u/=n-1;v/=ny-1;uu=u*2-1;vv=1-v*2;cx=(box[0]+box[2])/2;cy=(box[1]+box[3])/2;x=cx+.5*(box[2]-box[0])*uu*(1-.065*(1-vv*vv));y=cy-.5*(box[3]-box[1])*vv*(1-.10*(1-uu*uu));a=np.asarray(im,float)
 if pid in PHOTO_MOTIFS:
  x,y,spec['front_contour_registration']=registered_front(pid,a,box,u,v)
  if 'observed_coloured_perimeter_bounds'in spec['front_contour_registration']:box=spec['front_contour_registration']['observed_coloured_perimeter_bounds'];im.crop(box).save(out/'donor-crop-native.png')
 x=np.clip(x,0,a.shape[1]-2);y=np.clip(y,0,a.shape[0]-2);ix=x.astype(int);iy=y.astype(int);fx=x-ix;fy=y-iy;sample=a[iy,ix]*(1-fx[:,:,None])*(1-fy[:,:,None])+a[iy,ix+1]*fx[:,:,None]*(1-fy[:,:,None])+a[iy+1,ix]*(1-fx[:,:,None])*fy[:,:,None]+a[iy+1,ix+1]*fx[:,:,None]*fy[:,:,None];Image.fromarray(np.clip(sample,0,255).astype(np.uint8)).save(out/'rectified-reference-only.png');rr,gg,bb=sample.transpose(2,0,1);kind=spec['kind'];mask=np.zeros((ny,n),np.float32)
 if kind in['beige_stripes','pink_stripes','narrow_stripes']:
  # One-dimensional registered stripe placement is measured from thisSKU's central cloth, not copied from a sibling.
  profile=np.median(sample[n//2-20:n//2+20],axis=0);r,g,b=profile.T;coloured=profile.mean(1)<130 if kind=='narrow_stripes'else((r-b)>18)&((r-g)>5);weights=np.asarray(Image.fromarray((coloured*255).astype(np.uint8)[None,:]).filter(ImageFilter.GaussianBlur(.8)),float)[0]/255;mask[:]=weights[None,:];white=np.median(profile[~coloured],axis=0)if kind=='narrow_stripes'else np.median(sample[(rr-bb)<12],axis=0);colour=np.median(profile[coloured],axis=0)if kind=='narrow_stripes'else np.median(sample[((rr-bb)>22)&((rr-gg)>7)],axis=0);rgb=white[None,None,:]*(1-mask[:,:,None])+colour[None,None,:]*mask[:,:,None];height=np.zeros((ny,n));pal=[white.tolist(),colour.tolist()]
 elif kind=='white_thin_check':
  vp=np.median(sample[470:550],axis=0);hp=np.median(sample[:,470:550],axis=1)
  def measure(profile):
   score=(profile[:,1]+profile[:,2])/(2*profile[:,0]+1e-6);baseline=np.convolve(np.pad(score,30,mode='edge'),np.ones(61)/61,mode='valid');mask=(score-baseline)>.025;mask[:25]=False;mask[-25:]=False;diff=np.diff(np.r_[False,mask,False].astype(int));result=np.zeros(len(mask),bool)
   for a,b in zip(np.where(diff==1)[0],np.where(diff==-1)[0]):
    if b-a>=3:result[a:b]=True
   return result
  vertical=measure(vp);horizontal=measure(hp);mask=np.maximum(vertical[None,:],horizontal[:,None]);bg=np.median(sample[~mask],axis=0);ink=np.median(sample[mask],axis=0);rgb=np.where(mask[:,:,None],ink,bg);height=mask*.20;pal=[bg.tolist(),ink.tolist()];spec['measured_white_threads']=dict(vertical_pixels=np.flatnonzero(vertical).tolist(),horizontal_pixels=np.flatnonzero(horizontal).tolist())
 elif kind in ['printed_motif','pale_print','dark_embroidery','full_print']:
  bg=np.median(sample.reshape(-1,3),axis=0);luma=sample.mean(2);height=np.zeros((ny,n));chroma=sample/(sample.sum(2)[:,:,None]+1e-6);basechroma=bg/bg.sum();threshold=.009 if kind=='pale_print'else .022;canvas=(abs(chroma-basechroma).max(2)<threshold)&(luma>bg.mean()*.66);isolated=sample.copy();margin=(u<.07)|(u>.93)|(v<.07)|(v>.93)
  if kind=='dark_embroidery':
   # The small cream embroidered motif belongs to this exactSKU, not a repeated icon.
   thread=(sample.min(2)>115)&(luma>bg.mean()*1.7)
   # Background slivers outside the photographed dark cloth are connected to
   # the crop boundary; actual isolated embroidery lies inside the cloth.
   from collections import deque
   outside=np.zeros_like(thread);queue=deque()
   for row,col in [(0,c)for c in range(n)]+[(ny-1,c)for c in range(n)]+[(r,0)for r in range(ny)]+[(r,n-1)for r in range(ny)]:
    if thread[row,col]and not outside[row,col]:outside[row,col]=True;queue.append((row,col))
   while queue:
    row,col=queue.popleft()
    for dr,dc in [(-1,0),(1,0),(0,-1),(0,1),(-1,-1),(-1,1),(1,-1),(1,1)]:
     r0,c0=row+dr,col+dc
     if 0<=r0<ny and 0<=c0<n and thread[r0,c0]and not outside[r0,c0]:outside[r0,c0]=True;queue.append((r0,c0))
   thread&=~outside;ink=np.median(sample[thread],axis=0);isolated[:]=bg;isolated[thread]=ink;height[thread]=.65;pal=[bg.tolist(),ink.tolist()];spec['edge_connected_background_pixels_removed']=int(outside.sum())
  else:
   if kind=='full_print':
    canvas=(bb-rr>7)&(bb-gg>4);bg=np.median(sample[canvas],axis=0)
   else:canvas|=margin&(abs(chroma-basechroma).max(2)<(.016 if pid in ['1354535002','1354536002','1356790002']else .045))&((luma<bg.mean()*.78)if kind=='pale_print'else True)
   if kind!='full_print':canvas|=(luma>238)&(sample.max(2)-sample.min(2)<12)
   if pid in ['1354539001','1354539002','1354539003','1354539004']:canvas|=(u<.22)|(u>.78)|(v<.22)|(v>.78)
   if pid in ['1366899001','1366899002']:canvas|=(u<.10)|(u>.90)|(v<.055)|(v>.975)
   if kind=='full_print':
    # Small disconnected pixels in the blank sky come from the photographed
    # cloth/fold residual, not the large letters, mountains or skis. Retain
    # every connected artwork element of at least80 mapped pixels.
    from collections import deque
    foreground=~canvas;visited=np.zeros_like(foreground)
    for start_r,start_c in zip(*np.nonzero(foreground)):
     if visited[start_r,start_c]:continue
     queue=deque([(int(start_r),int(start_c))]);visited[start_r,start_c]=True;component=[]
     while queue:
      row,col=queue.popleft();component.append((row,col))
      for dr,dc in [(-1,0),(1,0),(0,-1),(0,1),(-1,-1),(-1,1),(1,-1),(1,1)]:
       r0,c0=row+dr,col+dc
       if 0<=r0<ny and 0<=c0<n and foreground[r0,c0]and not visited[r0,c0]:visited[r0,c0]=True;queue.append((r0,c0))
     if len(component)<80:
      rows,cols=zip(*component);canvas[rows,cols]=True
   if pid in SINGLE_INK:
    inkpixels=sample[~canvas];inklum=inkpixels.mean(1);ink=np.median(inkpixels[(inklum>np.quantile(inklum,.45))&(inklum<np.quantile(inklum,.85))],axis=0);weight=np.asarray(Image.fromarray((~canvas*255).astype(np.uint8)).filter(ImageFilter.GaussianBlur(.40)),float)/255;isolated=bg[None,None,:]*(1-weight[:,:,None])+ink[None,None,:]*weight[:,:,None];pal=[bg.tolist(),ink.tolist()];height=weight*.10
   else:
    isolated[canvas]=bg;planar=Image.fromarray(np.clip(isolated,0,255).astype(np.uint8));quant=planar.quantize(colors=28,method=Image.Quantize.MEDIANCUT);isolated=np.asarray(quant.convert('RGB'),float).copy();isolated[canvas]=bg;pal=[bg.tolist()]+np.asarray(quant.getpalette()).reshape(-1,3)[:28].tolist();height[~canvas]=.10
  # Only the textile artwork is registered; real piping is a separate tube and
  # each reverse is separately plain rather than wrapping a photograph around it.
  edge=(u<.007)|(u>.993)|(v<.007)|(v>.993)
  if pid=='1354428001':
   # Preserve the sameSKU's faint small caption above the train, which neutral
   # blank-cloth classification would otherwise erase. Its own native stroke
   # contrast is isolated; no replacement lettering is generated.
   reference=Image.fromarray(np.clip(sample,0,255).astype(np.uint8));blur=np.asarray(reference.filter(ImageFilter.GaussianBlur(3)),float).mean(2);caption=(u>.27)&(u<.58)&(v>.20)&(v<.31)&(luma<blur-3.5);caption_colour=np.median(sample[caption],axis=0)if caption.any()else bg;isolated[caption]=caption_colour;height[caption]=.10;edge|=(v<.035)|(v>.975)|(u<.018)|(u>.982);spec['caption_extraction']=dict(normalized_region=[.27,.20,.58,.31],local_contrast_threshold=3.5,source_caption_pixels=int(caption.sum()),generated_replacement_text=False)
  isolated[edge]=bg;height[edge]=0;rgb=isolated
 elif kind=='embroidered_grid':
  # Measure the embroidered runs where the front is flat and in focus. A photographic
  # side/bottom shadow must never be mistaken for a broad olive embroidered patch.
  def runs(m):
   edges=np.diff(np.r_[False,m,False].astype(int));return[[int(a),int(b)]for a,b in zip(np.where(edges==1)[0],np.where(edges==-1)[0])if b-a>=3]
  vp=np.median(sample[450:550],axis=0);hp=np.median(sample[:,480:530],axis=1);br=runs(vp.max(1)<85);wr=[[br[j][1],br[j+1][0]]for j in range(0,len(br),2)];luma=hp.mean(1);baseline=np.convolve(np.pad(luma,40,mode='edge'),np.ones(81)/81,mode='valid');rawhr=runs(luma<baseline-18);hr=[]
  for a,b in rawhr:
   if hr and a-hr[-1][1]<=5:hr[-1][1]=b
   else:hr.append([a,b])
  assert len(wr)==4 and len(br)==8 and len(hr)==4,(wr,br,hr)
  white=np.zeros((n,n),bool);black=white.copy();olive=white.copy()
  for a,b in wr:white[:,a:b]=True
  for a,b in br:black[:,a:b]=True
  for a,b in hr:olive[a:b,:]=True
  bg=np.median(sample[450:530,450:530].reshape(-1,3),axis=0);rgb=np.broadcast_to(bg,(n,n,3)).copy();height=np.zeros((ny,n));pal=[bg.tolist()]
  for m,col,h in[(olive,[108,107,75],.50),(white,[233,230,208],.75),(black,[37,38,30],.60)]:rgb[m]=col;height[m]=h;pal.append(col)
  spec['measured_thread_runs_native1024']=dict(vertical_white=wr,vertical_black=br,horizontal_olive=hr,measurement_windows=dict(vertical_rows=[450,550],horizontal_columns=[480,530]))
 else:
  # Quantize only the isolated printed textile artwork into its own sampled ink palette. Studio cloth shading becomes one intrinsic canvas tone.
  r,g,b=sample.transpose(2,0,1);canvas=(r>150)&(g>145)&(b>135)&(abs(r-g)<16)&((g-b)<26)&((r-b)<28);canvas &=~((v>.76)&(g-r>2));isolated=sample.copy();isolated[canvas]=[233,229,217];planar=Image.fromarray(np.clip(isolated,0,255).astype(np.uint8));quant=planar.quantize(colors=24,method=Image.Quantize.MEDIANCUT);rgb=np.asarray(quant.convert('RGB'),float).copy();rgb[canvas]=[233,229,217];height=np.zeros((ny,n));pal=np.asarray(quant.getpalette()).reshape(-1,3)[:24].tolist()
  # The photographed green piping and silhouette are removed from the artwork. They are constructed as physical geometry.
  edge=(u<.008)|(u>.992)|(v<.008)|(v>.992);rgb[edge]=[233,229,217]
 # Fine intrinsic fibre is procedural and explicitly photo-estimated; neither photographic fold shadows nor background RGB survives.
 rng=np.random.default_rng(int(pid));fibre=rng.normal(0,.35,(ny,n,1));rgb=np.clip(rgb+fibre,0,255);Image.fromarray(np.rint(rgb).astype(np.uint8)).save(out/'albedo-pattern-native-1024.png');N=2048;yy,xx=np.mgrid[0:N,0:N].astype(float);pitch=3.2;grain=.06*np.sin(math.tau*xx/pitch)*np.cos(math.tau*yy/pitch)+rng.normal(0,.012,(N,N));relief=np.asarray(Image.fromarray(height.astype(np.float32),'F').resize((N,N),Image.Resampling.BILINEAR));z=grain+relief*.50;dy,dx=np.gradient(z);normal=np.stack([-dx,dy,np.ones_like(dx)],2);normal/=np.linalg.norm(normal,axis=2,keepdims=True);Image.fromarray(np.rint((normal+1)*127.5).astype(np.uint8)).save(out/'normal-2k.png');orm=np.zeros((N,N,3),np.uint8);orm[:,:,0]=255;orm[:,:,1]=239;Image.fromarray(orm).save(out/'orm-2k.png');prov=dict(source_path=hero['path'],source_sha256=hero['sha256'],source_pixels=hero['pixels'],crop_box_original_pixels=box,crop_pixels=[box[2]-box[0],box[3]-box[1]],mapped_artwork_pixels=[n,ny],operations=['One combined native-source contour rectification to a source-compatible albedo grid, maximum1024px on the longest edge; no source upscaling','OwnSKU stripe positions/thread classes/print ink palette isolated from its own front textile','Studio lighting and unprinted cloth replaced by intrinsic cloth palette; product silhouette/background not mapped','Own sampled motif or measured stripe placement retained; front/back geometry and sewn piping are separate','Procedural fine woven normal/roughness are photo interpretations, not newly claimed photographic detail'],palette_rgb=pal,source_master_unchanged=sha(hero['path'])==hero['sha256'],generation=False,full_marketing_photo_wrapped=False,filling_shadows_baked=False,background_pixels_baked=False,resampling_passes=1,physical_weave_scale_estimated=True);(out/'texture-provenance.json').write_text(json.dumps(prov,ensure_ascii=False,indent=2)+'\n')
 if 'measured_thread_runs_native1024'in spec:
  prov['measured_thread_runs_native1024']=spec['measured_thread_runs_native1024'];(out/'texture-provenance.json').write_text(json.dumps(prov,ensure_ascii=False,indent=2)+'\n')
 if 'front_contour_registration'in spec:
  prov['front_contour_registration']=spec['front_contour_registration'];(out/'texture-provenance.json').write_text(json.dumps(prov,ensure_ascii=False,indent=2)+'\n')
 if 'measured_white_threads'in spec:
  prov['measured_white_threads']=spec['measured_white_threads'];(out/'texture-provenance.json').write_text(json.dumps(prov,ensure_ascii=False,indent=2)+'\n')
 if 'caption_extraction'in spec:
  prov['caption_extraction']=spec['caption_extraction'];(out/'texture-provenance.json').write_text(json.dumps(prov,ensure_ascii=False,indent=2)+'\n')
 return dict(baseColorFactor=[1,1,1,1],metallic=1,roughness=1,baseColorTexture=str(out/'albedo-pattern-native-1024.png'),normalTexture=str(out/'normal-2k.png'),metallicRoughnessTexture=str(out/'orm-2k.png'),normalScale=.32,doubleSided=False,extras=dict(photo_pixels_baked=True,photo_donor_surface_only=True,baked_reflections=False,intrinsic_material=True,physical_sheen=dict(sheenColorFactor=[.05,.04,.03],sheenRoughnessFactor=.95),texture_resolution=[1024,2048,2048],unique_source_detail_resolution=[min(n,box[2]-box[0]),min(ny,box[3]-box[1])],atlas_tile_metres=1.,source_master_sha256=hero['sha256'],texture_provenance=str(out/'texture-provenance.json'),source_artwork_isolated=True,procedural_fibre_not_source_detail=True))

def plain_edge(pid,front):
 out=R/'materials'/pid/'plain-edge';out.mkdir(parents=True,exist_ok=True);prov=json.loads(Path(front['extras']['texture_provenance']).read_text());kind=SPECS[pid]['kind'];colour=prov['palette_rgb'][1]if kind in['beige_stripes','pink_stripes','narrow_stripes']else prov['palette_rgb'][0]if kind in ['embroidered_grid','white_thin_check','printed_motif','pale_print','dark_embroidery','full_print']else[137,146,106]
 if pid=='1338598015':colour=prov['palette_rgb'][0]
 if pid in PHOTO_MOTIFS:
  # Red/green piping is sampled from the sameSKU's own perimeter, not borrowed.
  source=np.asarray(Image.open(prov['source_path']).convert('RGB'),float);x0,y0,x1,y1=prov['crop_box_original_pixels'];area=source[y0:y1,x0:x1];r,g,b=area.transpose(2,0,1);red=(r-g>45)&(r-b>35);green=(g-b>8)&(r-b>5)&(area.mean(2)<155)&(r<185)
  if pid in ['1353945001','1354428001','1354537003','1354539001','1354539003','1356790001']and red.sum()>10:colour=np.median(area[red],axis=0)
  if pid in ['1354539002','1354539004','1356790002']and green.sum()>10:colour=np.median(area[green],axis=0)
 for name,col in[('albedo',colour),('normal',[128,128,255]),('orm',[255,235,0])]:Image.new('RGB',(4,4),tuple(round(c)for c in col)).save(out/(name+'.png'))
 return dict(baseColorFactor=[1,1,1,1],metallic=1,roughness=1,baseColorTexture=str(out/'albedo.png'),normalTexture=str(out/'normal.png'),metallicRoughnessTexture=str(out/'orm.png'),normalScale=.1,doubleSided=False,extras=dict(intrinsic_material=True,photo_pixels_baked=False,baked_reflections=False,physical_sheen=dict(sheenColorFactor=[.04,.04,.03],sheenRoughnessFactor=.9),constant_PBR_map_no_artificial_upscale=True))
def back_stripes(pid,front):
 out=R/'materials'/pid/'back-stripes';out.mkdir(parents=True,exist_ok=True);n=1024;x=np.arange(n)[None,:]/n;mask=(x*16%2)<1;rgb=np.broadcast_to(np.array([232,228,211],float),(n,n,3)).copy();rgb[:]=np.where(mask[:,:,None],np.array([147,157,112]),np.array([232,228,211]));Image.fromarray(rgb.astype(np.uint8)).save(out/'albedo.png');ma=dict(front);ma['baseColorTexture']=str(out/'albedo.png');ma['extras']=dict(front['extras'],back_layout_photo_interpreted=True);return ma

def plain_reverse(pid,front):
 out=R/'materials'/pid/'plain-reverse';out.mkdir(parents=True,exist_ok=True);colour=json.loads(Path(front['extras']['texture_provenance']).read_text())['palette_rgb'][0];n=2048;rng=np.random.default_rng(int(pid)+1);grain=rng.normal(0,.35,(n,n));rgb=np.clip(np.array(colour)[None,None,:]+grain[:,:,None],0,255);Image.fromarray(rgb.astype(np.uint8)).save(out/'albedo.png');dy,dx=np.gradient(grain*.002);normal=np.stack([-dx,dy,np.ones_like(dx)],2);normal/=np.linalg.norm(normal,axis=2,keepdims=True);Image.fromarray(np.rint((normal+1)*127.5).astype(np.uint8)).save(out/'normal.png');ma=dict(front);ma.update(baseColorTexture=str(out/'albedo.png'),normalTexture=str(out/'normal.png'));ma['extras']=dict(front['extras'],back_plain_cloth_from_front_only_embroidery_description=True);return ma

def normalized_panel_uv(parts):
 N=81;nn=N*N;boundary=list(range(N))+[j*N+N-1 for j in range(1,N)]+list(range((N-1)*N+N-2,(N-1)*N-1,-1))+[j*N for j in range(N-2,0,-1)]
 for p in parts:
  if len(p['_vertices'])!=nn*2+len(boundary)*4:continue
  uv=[(i/(N-1),1-j/(N-1))for j in range(N)for i in range(N)];p['_uvs']=uv*2
  for j,a in enumerate(boundary):
   b=boundary[(j+1)%len(boundary)];aa=np.array(uv[a]);bb=np.array(uv[b]);centre=np.array([.5,.5]);p['_uvs'] +=[tuple(aa),tuple(bb),tuple(aa+(centre-aa)*.002),tuple(bb+(centre-bb)*.002)]
 return parts
