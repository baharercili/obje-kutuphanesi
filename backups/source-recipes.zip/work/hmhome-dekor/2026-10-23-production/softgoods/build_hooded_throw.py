"""Own ghost hooded textile: hollow sewn hood, hanging back and two folded wings."""
import sys
sys.dont_write_bytecode=True
import math,json
import numpy as np
from PIL import Image,ImageFilter
import build_shaped_softgoods as C
S=C.S;B=C.B;R=C.R;T=math.tau

def panel(name,corners,material='fabric',N=49):
 corners=np.asarray(corners,float);verts=[];uv=[];faces=[]
 def point(u,v):
  a,b=2*u-1,2*v-1;u=.5+.5*a*math.sqrt(1-.48*b*b/2);v=.5+.5*b*math.sqrt(1-.48*a*a/2);p=(1-v)*((1-u)*corners[0]+u*corners[1])+v*((1-u)*corners[3]+u*corners[2]);p[2]+=(.045+.012*math.sin(u*7+v*2))*math.sin(math.pi*u)*math.sin(math.pi*v)+.006*math.sin(u*math.pi*3+v)*math.sin(math.pi*v);p[0]+=.009*math.sin(v*5)*math.sin(math.pi*u);p[1]+=.009*math.sin(math.pi*u)*math.sin(v*math.pi*2);return p
 for side in [-1,1]:
  for v in np.linspace(0,1,N):
   for u in np.linspace(0,1,N):p=point(u,v)+[0,0,side*.0025];verts.append(tuple(p));uv.append((u,v))
 n=N*N
 for side in [0,1]:
  for j in range(N-1):
   for i in range(N-1):a=side*n+j*N+i;b=a+N;faces.extend([(a,b,a+1),(a+1,b,b+1)]if side==0 else[(a,a+1,b),(a+1,b+1,b)])
 edge=list(range(N))+[j*N+N-1 for j in range(1,N)]+list(range((N-1)*N+N-2,(N-1)*N-1,-1))+[j*N for j in range(N-2,0,-1)]
 for j,a in enumerate(edge):b=edge[(j+1)%len(edge)];faces.extend([(a,b,a+n),(b,b+n,a+n)])
 seam=[(np.array(verts[i])+np.array(verts[i+n]))/2 for i in edge];return [B.solid(name,material,verts,faces,uv),B.tube(name+'-soft-bound-hem',material,[tuple(p)for p in seam],.0025,.0022,6,True,guide=[0,0,1])],point

def hood_half(front=True):
 N=81;K=49;verts=[];uv=[];faces=[];theta=np.linspace(0,math.pi,N)+(0 if front else math.pi)
 for inside in [False,True]:
  for j,phi in enumerate(np.linspace(0,math.pi/2-.006,K)):
   radius=math.cos(phi);rx=(.148 if inside else .15)*radius;rz=(.063 if inside else .065)*radius
   for angle in theta:
    base=.76+.04*max(0,math.sin(angle))**1.4;x=rx*math.cos(angle);y=base+(1-base)*math.sin(phi)-(.001 if inside else 0);z=.005+rz*math.sin(angle);verts.append((x,y,z));uv.append((x/.30+.5,(1-y)/.24))
  pole=len(verts);verts.append((0,1-(.001 if inside else 0),.005));uv.append((.5,(.001 if inside else 0)/.22));offset=(K*N+1)if inside else 0
  for j in range(K-1):
   for i in range(N-1):a=offset+j*N+i;b=a+N;faces.extend([(a,b,a+1),(a+1,b,b+1)]if inside else[(a,a+1,b),(a+1,b+1,b)])
  for i in range(N-1):a=offset+(K-1)*N+i;faces.append((a,pole,a+1)if inside else(a,a+1,pole))
 n=K*N+1;edge=list(range(N))+[j*N+N-1 for j in range(1,K)]+[n-1]+[j*N for j in range(K-1,0,-1)]
 for j,a in enumerate(edge):b=edge[(j+1)%len(edge)];faces.extend([(a,b,a+n),(b,b+n,a+n)])
 return B.solid('closed-thin-hollow-hood-'+('front-with-own-embroidery'if front else'plain-reverse'),'hood'if front else'fabric',verts,faces,uv)

def build():
 pid='1344727001';cap,ep,refs,hero=C.own(pid);cap=dict(cap);cap.update(_size_source_kind='photo_estimated_exact_sku',_size_scope='No official physical size observed; all display axes and hood/drape geometry are explicit photo estimates.');ma=S.material(pid,'own-ghost-fleece',hero,[600,950,856,1206],hero,'pile',.08);ma['normalScale']=1.1
 out=R/'materials'/pid/'own-hood-artwork';out.mkdir(parents=True,exist_ok=True);im=Image.open(hero['path']).convert('RGB');box=[500,240,1040,640];crop=im.crop(box);crop.save(out/'donor-crop-native.png');a=np.asarray(crop,float);mask=a.mean(2)<85;target=np.median(np.asarray(im.crop((600,950,856,1206)),float).reshape(-1,3),axis=0);ink=np.median(a[mask],axis=0);rgb=np.broadcast_to(target,a.shape).copy();rgb[mask]=ink;Image.fromarray(rgb.astype(np.uint8)).save(out/'hood-art-native.png');C.dump(out/'texture-provenance.json',dict(source_path=hero['path'],source_sha256=hero['sha256'],source_pixels=hero['pixels'],crop_box_original_pixels=box,crop_pixels=list(crop.size),operations=['Immutable ownSKU hood crop retained','Only dark embroidered eye/mouth pixels are isolated; original white eye highlights are retained as unprinted cloth','No photographed backdrop, folds, label or shading is mapped to the hood'],source_master_unchanged=C.sha(hero['path'])==hero['sha256'],source_upscaled=False,full_marketing_photo_wrapped=False,background_pixels_baked=False));hood=json.loads(json.dumps(ma));hood.update(baseColorTexture=str(out/'hood-art-native.png'));hood['extras']['texture_provenance']=str(out/'texture-provenance.json');hood['extras']['photo_pixels_baked']=False
 defs=[('hanging-central-back-cloth',[(-.14,.90,.035),(.14,.90,.035),(.16,.14,-.012),(-.16,.14,-.012)]),('left-lower-return-fold',[(-.14,.78,.005),(-.27,.11,.018),(-.065,0,.045),(0,.38,.060)]),('right-lower-return-fold',[(.14,.78,.005),(0,.38,.065),(.070,0,.045),(.275,.115,.012)]),('left-overlapping-draped-wing',[(-.14,.78,.015),(-.23,.27,.075),(0,.38,.085),(-.12,.735,.030)]),('right-overlapping-draped-wing',[(.14,.78,.015),(.125,.735,.03),(0,.38,.09),(.235,.27,.07)])];parts=[];surfaces=[]
 for name,corners in defs:
  pieces,point=panel(name,corners);parts+=pieces;surfaces.append(point)
 parts +=[hood_half(True),hood_half(False)];rng=np.random.default_rng(int(pid));hairs=[]
 for point in surfaces:
  for j in range(1000):
   u,v=rng.uniform(.005,.995,2);p=point(u,v)+[0,0,.0026];l=rng.uniform(.003,.005);tang=np.array([math.cos(j),math.sin(j),0]);pts=[p-[0,0,.0001]]+[p+[0,0,l*.8*math.sin(math.pi*f*.8)]+tang*l*.6*f for f in [.25,.5,.75,1.]];q=B.tube('closed-soft-fleece-loop','fabric',[tuple(x)for x in pts],.00028,.00020,4,False,guide=tang.tolist());local=np.asarray(q['_uvs']);local=(local-local.min(0))/np.maximum(local.max(0)-local.min(0),1e-9);q['_uvs']=[tuple(np.array([u,v])+xy*.0005)for xy in local];hairs.append(q)
 for j in range(1500):
  angle=rng.uniform(0,T);phi=rng.uniform(.04,1.50);r=math.cos(phi);base=.76+.04*max(0,math.sin(angle))**1.4;p=np.array([.15*r*math.cos(angle),base+(1-base)*math.sin(phi),.005+.065*r*math.sin(angle)]);normal=np.array([math.cos(angle)*r,math.sin(phi),math.sin(angle)*r]);normal/=np.linalg.norm(normal);tang=np.array([-math.sin(angle),0,math.cos(angle)]);l=rng.uniform(.0025,.0045);pts=[p-normal*.0001]+[p+normal*l*.8*math.sin(math.pi*f*.8)+tang*l*.6*f for f in [.25,.5,.75,1.]];q=B.tube('closed-soft-hood-fleece-loop','fabric',[tuple(x)for x in pts],.00028,.00020,4,False,guide=tang.tolist());hairs.append(q)
 parts.append(S.merge(hairs,'physical-small-fleece-loops-on-draped-panels','fabric'));note='Resmî fiziksel plan ölçüsü gözlenmedi. Fotoğraftaki kapüşonlu asılı teşhir yaklaşık100cm yükseklik ve55cm enle yorumlandı; derinlik, açık kumaş boyu, dikiş/kanat kıvrımları ve hav uzunluğu tahmindir. Kapüşon içi boş ince dikili kumaş olarak ve iki yan kanat örtüşen/sarkan katlar halinde modellendi. Yüz nakışı yalnız buSKU’nun kendi başlık fotoğrafından ayrıştırıldı.';C.finish(pid,parts,dict(fabric=ma,hood=hood),cap,ep,refs,hero,[None,1.,None],{},'hanging_hooded_fleece_blanket',['all_display_axes_cm','unfolded_plan_cm','hood_cavity_geometry','drape_and_fold_placement','cloth_thickness_and_pile'],note,dict(category='Battaniye ve örtüler',source_dimensions_hwd_cm=None,estimated_unfolded_plan_cm=[100,100],official_plan_dimensions_cm=None,all_axes_estimated=True,quality_label='Tahmini ölçek/örtü formu',quality_status='photo_interpreted',quality_note='Resmî boy yayımlanmadı. Teşhir boyutu, kapüşon boşluğu, yan kıvrımlar, açık kumaş boyu ve hav fotoğraf yorumudur. Yüz nakışı kendi üründen ayrıştırıldı.',variant_status_verbatim='ExactSKU resmî kart kimliği ve kendi fotoğrafı bağlı; fiziksel ölçü bulunmadığı için tüm ölçek tahmindir.'))

if __name__=='__main__':build()
