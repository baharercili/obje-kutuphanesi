"""Bounded three-prototype pose probe. Source material pixels/UV stay unchanged."""
from pathlib import Path
import json,sys,copy,math
sys.dont_write_bytecode=True
import numpy as np
import build_organic_source_prototypes_r5 as R
C=R.C;S=R.S;M=R.M;V=R.V;assert not(V/'FINAL-FROZEN.json').exists();read=R.read

def deform(a,lo,hi):
    w,d=hi[[0,2]]-lo[[0,2]];h=hi[1]-lo[1];x=(a[:,0]-lo[0])/w;z=(a[:,2]-lo[2])/d;y=(a[:,1]-lo[1])/h
    # Broad nonperiodic cloth buckling, not a repeated fine corrugation.
    crest=.024*np.exp(-((x-.29)/.23)**2-((z-.32)/.66)**2)
    valley=-.014*np.exp(-((x-.69)/.18)**2-((z-.60)/.52)**2)
    corner=.017*np.exp(-((x-.88)/.25)**2-((z-.88)/.24)**2)
    fall=-.012*np.exp(-np.maximum(z,0)/.11)*np.sin(np.pi*x)**2
    q=a.copy();q[:,1]+=(crest+valley+corner+fall)*(.78+.32*y)+.012*(y-.5)*np.sin(math.tau*(.70*x+.32*z)+.4)
    q[:,0]+=.007*(y-.5)*np.sin(math.pi*(1.5*z+.2))
    q[:,2]+=.008*(y-.5)*np.sin(math.pi*(1.35*x+.3))
    return q

def warp(m,lo,hi):
    a=np.round(np.asarray(m['positions']).reshape(-1,3),9);n=np.array(m['normals']).reshape(-1,3);q=deform(a,lo,hi);J=[];eps=1e-5
    for k in range(3):
        delta=np.zeros(3);delta[k]=eps;J.append((deform(a+delta,lo,hi)-deform(a-delta,lo,hi))/(2*eps))
    J=np.stack(J,2);det=np.linalg.det(J);assert det.min()>.3;nn=np.linalg.solve(np.transpose(J,(0,2,1)),n[...,None])[...,0];nn/=np.linalg.norm(nn,axis=1,keepdims=True);r=copy.deepcopy(m);r['positions']=q.reshape(-1).tolist();r['normals']=nn.reshape(-1).tolist();return r,float(det.min())
rows=[];proof=[]
for e in read(V/'manifest.json'):
    out=Path(e['asset_dir']);model=read(e['model_path']);assert model['metadata']['model_revision']=='bounded-source-specific-organic-r5','Never apply the probe twice';body=np.array(model['meshes'][0]['positions']).reshape(-1,3);lo=body.min(0);hi=body.max(0);old=copy.deepcopy(model['meshes']);oldDoc,_=S.read_glb(e['glb_path']);checks=[warp(m,lo,hi)for m in old];meshes=[m for m,_ in checks];a=np.concatenate([np.array(m['positions']).reshape(-1,3)for m in meshes]);lo=a.min(0);hi=a.max(0);origin=np.array([(lo[0]+hi[0])/2,lo[1],(lo[2]+hi[2])/2]);dims=((hi-lo)*100).tolist()
    for m in meshes:m['positions']=(np.array(m['positions']).reshape(-1,3)-origin).reshape(-1).tolist()
    for a,b in zip(old,meshes):assert a['uvs']==b['uvs']and a['indices']==b['indices']
    texture_hashes={slot:C.sha(out/ma[slot])for ma in model['materials'].values()for slot in['baseColorTexture','normalTexture','metallicRoughnessTexture']};model['meshes']=meshes;model['metadata'].update(dimensions_cm=dims,model_revision='bounded-source-specific-organic-r5b',previous_pose_probe_glb_sha256=e['sha256'],revision_reason='Native self-review found too-parallel layer edges in the first bounded R5 probe; common broad nonperiodic crest/valley/corner fall deforms the entire finite cloth and all attached stitches/tufts. Exact material bytes and UV retained.');model['metadata']['scale_note']+=' Geniş asimetrik kıvrım ve kat kaymaları yaklaşık2–3cm yerel kumaş dalgasıyla yorumlanır; katlanmış poz ölçüsü resmî ürün bedeni değildir.';C.dump(out/'model.json',model);q=read(out/'geometry-validation.json');q.update(common_broad_pose_probe=True,minimum_positive_Jacobian=min(x[1]for x in checks),all_UV_and_indices_preserved_from_first_R5_probe=True);C.dump(out/'geometry-validation.json',q);report=S.export_assets(out/'model.json',out,e['id']);glb=out/(e['id']+'.glb');doc,blob=S.read_glb(glb)
    for ma in doc['materials']:
        prev=next(x for x in oldDoc['materials']if x['name']==ma['name'])
        if 'extensions'in prev:ma['extensions']=prev['extensions']
    doc['extensionsUsed']=oldDoc.get('extensionsUsed',[]);blob=M.embed_tangents(doc,blob);S.write_glb(glb,doc,blob);entry={**e,**model['metadata'],'sha256':C.sha(glb),'bytes':glb.stat().st_size};C.dump(out/'entry.json',entry);rows.append(entry);report['deliverable_sha256']['glb']=entry['sha256'];report['glb_bytes']=entry['bytes'];C.dump(Path(report['files']['validation']),report);proof.append(dict(sku=e['sku'],previous_SHA=e['sha256'],current_SHA=entry['sha256'],all_material_bytes_unchanged=True,all_UV_and_indices_unchanged=True,common_warp_detail_attachment_preserved=True,minimum_positive_Jacobian=min(x[1]for x in checks)));print(e['sku'],entry['sha256'],entry['bytes'],dims,flush=True)
C.dump(V/'manifest.json',rows);C.dump(V/'pose-probe-preservation.json',dict(valid=True,models=proof))
