"""Bounded own-source fibre/fringe corrections; approved cloth poses untouched."""
from pathlib import Path
import sys,json,math,copy
sys.dont_write_bytecode=True
import numpy as np
from PIL import Image,ImageFilter,ImageDraw
import build_fringe_four_r5_revision as H
A=H.A;R=H.R;F=H.F;C=H.C;P=H.P;S=H.S;G=H.G;M=H.M;B=H.B;read=H.read;TAU=math.tau
SEVEN=['1338619002','1338615001','1348754001','1348754005','1348754007','1298464008','1348917001'];BROWN='1338618003';BROWN_FAMILY=['1338618002','1338618003','1338618004','1338618006'];OLD={e['sku']:e for e in read(A.V/'manifest.json')}
BOX={k:[620,520,1004,904]for k in SEVEN+BROWN_FAMILY};BOX['1338618004']=[240,650,496,906];BOX['1338618006']=[240,650,460,870];BOX['1298464008']=[300,700,684,1084];BOX['1348754001']=[620,850,1004,1234]

def reconstruct(e,body):
 recipe=F.RECIPES[e['sku']];plan=np.array(e.get('official_plan_dimensions_cm')or e['estimated_unfolded_plan_cm'])/100;fr=recipe.get('fringe_length_cm',0)/100;thick=recipe['thickness_mm']/1000;grid,normals,uv,extra=F.O.grid_for(plan[0],plan[1]-2*fr,thick,.011)
 raw=F.O.T.C.shell('reconstruction-for-root-validation','fabric',grid,normals,thick,uv);m,q=S._finalize(G.orient(raw));M.ensure_uv_faces([m]);G.ensure_float32_uv([m]);a=np.array(m['positions']).reshape(-1,3);lo1=a.min(0);hi1=a.max(0);m=R.warp(m,lo1,hi1);a=np.array(m['positions']).reshape(-1,3);lo2=a.min(0);hi2=a.max(0);m,_=A.broad(m,lo2,hi2);a=np.array(m['positions']).reshape(-1,3);translation=np.mean(np.array(body['positions']).reshape(-1,3)-a,0);err=float(abs(a+translation-np.array(body['positions']).reshape(-1,3)).max());assert err<1e-8
 def pose(m):
  m=R.warp(m,lo1,hi1);m,_=A.broad(m,lo2,hi2);m['positions']=(np.array(m['positions']).reshape(-1,3)+translation).reshape(-1).tolist();return m
 def points(p):return H.posed_points(p,lo1,hi1,lo2,hi2,translation)
 return grid,normals,uv,thick,extra,pose,points,err

def oval_tufts(paths,widths,heights,ats,name,mat='fabric'):
 # Six radial samples form a rounded closed bundle, tapering to a capped end.
 paths=np.array(paths);count,k,_=paths.shape;sides=6;tangents=np.empty_like(paths);tangents[:,1:-1]=paths[:,2:]-paths[:,:-2];tangents[:,0]=paths[:,1]-paths[:,0];tangents[:,-1]=paths[:,-1]-paths[:,-2];tangents/=np.linalg.norm(tangents,axis=2,keepdims=True);guide=np.zeros_like(paths);guide[:,:,1]=1;guide[abs(tangents[:,:,1])>.95]=[1,0,0];across=np.cross(tangents,guide);across/=np.linalg.norm(across,axis=2,keepdims=True);up=np.cross(across,tangents);ang=np.arange(sides)*TAU/sides;taper=np.array([.60,1,.77,.12]);rr=np.asarray(widths)[:,None,None,None]*.5*taper[None,:,None,None];hh=np.asarray(heights)[:,None,None,None]*.5*taper[None,:,None,None];v=paths[:,:,None,:]+across[:,:,None,:]*np.cos(ang)[None,None,:,None]*rr+up[:,:,None,:]*np.sin(ang)[None,None,:,None]*hh;v=v.reshape(count,k*sides,3);v=np.concatenate([v,paths[:,0,None,:],paths[:,-1,None,:]],1);f=[]
 for j in range(k-1):
  for i in range(sides):a=j*sides+i;b=j*sides+(i+1)%sides;c=a+sides;d=b+sides;f.extend([(a,b,c),(b,d,c)])
 for i in range(sides):f.extend([(k*sides,(i+1)%sides,i),(k*sides+1,(k-1)*sides+i,(k-1)*sides+(i+1)%sides)])
 faces=(np.array(f)[None,:,:]+np.arange(count)[:,None,None]*(k*sides+2)).reshape(-1,3);tex=[]
 for j in range(k):
  for i in range(sides):tex.append([i/sides*.0005,j/(k-1)*.0007])
 tex +=[[.00025,-.0001],[.00025,.0008]];uvs=np.array(ats)[:,None,:]+np.array(tex)[None,:,:]
 return S.solid(name,mat,v.reshape(-1,3).tolist(),faces.tolist(),uvs.reshape(-1,2).tolist())

def surface(pid,grid,normals,uv,thick):
 rng=np.random.default_rng(int(pid)+611);chen=pid=='1338619002';mohair=pid=='1338615001';wool=pid.startswith('1348754');ultra=pid=='1348917001';count=8000 if pid in BROWN_FAMILY else 7500 if chen else 9500 if mohair else 8000 if wool else 11500;paths=[];ats=[];widths=[];heights=[]
 for k in range(count):
  # True exposed outer quarter, reverse and bend; roots lie beyond the closed shell.
  if k<count*.88:u,v=rng.uniform(.60,.997),rng.uniform(.003,.42)
  elif k<count*.96:u,v=rng.uniform(.003,.42),rng.uniform(.003,.42)
  else:u,v=rng.uniform(.445,.555),rng.uniform(.003,.42)
  p,n,t=F.sample(grid,normals,uv,u,v)
  if u>.58 and n[1]<0:n=-n
  if u<.42 and n[1]>0:n=-n
  p+=n*(thick/2+.00018);tx=np.array([1.,0,0])-n*n[0];tx/=np.linalg.norm(tx);ty=np.cross(n,tx);angle=rng.uniform(0,TAU);tangent=tx*math.cos(angle)+ty*math.sin(angle);cross=np.cross(n,tangent)
  L=rng.uniform(.006,.012)if mohair else rng.uniform(.004,.008)if wool else rng.uniform(.0025,.0055)if ultra else rng.uniform(.002,.004);rise=L*(.50 if mohair else .45);wiggle=rng.uniform(-.25,.25);points=[p,p+n*rise*.80+tangent*L*.22,p+n*rise+tangent*L*.60+cross*L*wiggle,p+n*rise*.24+tangent*L+cross*L*wiggle*.5];paths.append(points);ats.append(t);widths.append(rng.uniform(.00055,.0010)if mohair or wool else rng.uniform(.00065,.0013));heights.append(widths[-1]*.55)
 raw=oval_tufts(paths,widths,heights,ats,'visible-own-'+('chenille-nub'if chen else'mohair-loose-hav'if mohair else'wool-fleece'if wool else'short-ultrasoft-fleece'if ultra else'soft-melange-wool')+'-rounded-tapered-tufts');return raw,dict(tufts=count,all_roots_clear_actual_closed_cloth=True,source_family_specific=True,interpreted_path_length_range_mm=[float(np.min(np.linalg.norm(np.diff(paths,axis=1),axis=2).sum(1))*1000),float(np.max(np.linalg.norm(np.diff(paths,axis=1),axis=2).sum(1))*1000)],body_RGB_UV_used_on_each_tuft=True)

def fringes(pid,grid,normals,uv,thick,point_pose):
 rng=np.random.default_rng(int(pid)+612);chen=pid=='1338619002';brown=pid in BROWN_FAMILY;count=45 if chen else 58 if brown else 25;fr=F.RECIPES[pid]['fringe_length_cm']/100;parts=[];spec=[]
 for k in range(count):
  u=.55+.445*(k+.5)/count;p,n,t=F.sample(grid,normals,uv,u,0)
  if n[1]<0:n=-n
  p+=n*(thick/2+.00004);i=min(round(u*(len(grid)-1)),len(grid)-1);direction=-(grid[i,1]-grid[i,0]);direction[1]=0;direction/=np.linalg.norm(direction);posed=point_pose([p,p+direction*.005]);root=posed[0];direction=posed[1]-root;direction[1]=0;direction/=np.linalg.norm(direction);cross=np.array([direction[2],0,-direction[0]]);L=fr*rng.uniform(.79,1.15);radius=rng.uniform(.00165,.0024)if chen else rng.uniform(.0025,.0034)if brown else rng.uniform(.00315,.00425);phase=rng.uniform(0,TAU);bend=rng.uniform(-.026,.026)if not chen else rng.uniform(-.008,.008);angle=rng.uniform(-.22,.22);turns=rng.uniform(3,5)if chen else rng.uniform(4,7);drop=min(root[1]-.005,L*rng.uniform(.24,.50));points=[]
  for q in np.linspace(0,1,81):
   along=L*(q-.11*q*q);side=bend*math.sin(math.pi*q*.9)+L*math.sin(angle)*q+.004*(math.sin(TAU*q*1.4+phase)-math.sin(phase))*q;y=root[1]-drop*(1-math.exp(-q*4))+.004*(math.sin(TAU*q*.9+phase)-math.sin(phase))*q;pt=root+direction*along+cross*side;pt[1]=max(radius*1.4,y);points.append(pt)
  for ply in[0,1]:parts.append(H.tapered_ply('plump-source-closed-two-ply-wool-cord-'+str(k)+'-ply-'+str(ply),points,radius,phase+ply*math.pi,turns))
  if chen:
   # Own photo shows a small terminal gathered knot and several loose cut ends.
   knot=np.array(points[-8]);kpts=[knot+cross*.002,knot+np.array([0,.0025,0]),knot-cross*.002,knot-np.array([0,.002,0]),knot+cross*.002];parts.append(B.tube('source-chenille-terminal-gathered-soft-knot','yarn',kpts,.0012,.001,6,False,guide=direction.tolist()))
   for j in range(4):
    p0=np.array(points[-7])+cross*(j-1.5)*.0007;pts=[p0,p0+direction*.004+cross*(j-1.5)*.0008,p0+direction*.008+cross*(j-1.5)*.0015+np.array([0,-.002,0])];parts.append(B.tube('source-chenille-four-loose-cut-tip-strands','yarn',pts,.0005,.00035,4,False,guide=[0,1,0]))
  spec.append(dict(index=k,length_cm=L*100,outer_diameter_mm=radius*2.06*1000,twist_turns=turns,gravity_drop_mm=drop*1000))
 return S.merge(parts,'own-'+str(count)+'-full-soft-irregular-twisted-fringe-bundles','yarn'),spec

def fuzz(m,count=2600):
 rng=np.random.default_rng(613);p=np.array(m['positions']).reshape(-1,3);n=np.array(m['normals']).reshape(-1,3);tex=np.array(m['uvs']).reshape(-1,2);ix=rng.choice(len(p),count,replace=False);parts=[]
 for i in ix:
  side=np.cross(n[i],[0,1.,0])
  if np.linalg.norm(side)<.1:side=np.cross(n[i],[1.,0,0])
  side/=np.linalg.norm(side);L=rng.uniform(.0015,.0035);q=[p[i]-n[i]*.0001,p[i]+n[i]*L*.6+side*L*.2,p[i]+n[i]*L*.5+side*L*.8];raw=B.tube('soft-short-frayed-wool-fuzz-tip','yarn',q,.00022,.00013,3,False,guide=side.tolist());parts.append(F.local_uv(raw,tex[i],.00015))
 return S.merge(parts,'actual-soft-fuzzy-outline-on-plump-twisted-fringe','yarn')

def bilinear(a,x,y):
 x=np.mod(x,a.shape[1]);y=np.mod(y,a.shape[0]);ix=np.floor(x).astype(int);iy=np.floor(y).astype(int);dx=x-ix;dy=y-iy;return a[iy,ix]*(1-dx)*(1-dy)+a[iy,(ix+1)%a.shape[1]]*dx*(1-dy)+a[(iy+1)%a.shape[0],ix]*(1-dx)*dy+a[(iy+1)%a.shape[0],(ix+1)%a.shape[1]]*dx*dy

def materials(pid,e,previous,out,span):
 mats=copy.deepcopy(previous['materials']);proof=[]
 for name,ma in mats.items():
  for slot in['baseColorTexture','normalTexture','metallicRoughnessTexture']:
   src=Path(e['asset_dir'])/ma[slot];dst=out/(name+'-'+Path(ma[slot]).name);A.copy_pixels(src,dst);ma[slot]=dst.name;proof.append(dict(material=name,slot=slot,previous_sha256=C.sha(src),copied_sha256=C.sha(dst)))
 im=Image.open(e['original_image']).convert('RGB');box=BOX[pid];patch=im.crop(box);patch.save(out/'own-melange-fibre-native.png');native=np.array(patch,float);lum=native.mean(2);low=np.array(patch.filter(ImageFilter.GaussianBlur(8)),float).mean(2);res=lum-low;N=2048;yy,xx=np.indices((N,N));pixel_m=span[0]/(im.width*.80);grain=bilinear(res,xx/N*span[0]/pixel_m,yy/N*span[1]/pixel_m);oldrgb=np.array(Image.open(out/mats['fabric']['baseColorTexture']).convert('RGB'),float);assert oldrgb.shape==(N,N,3);rgb=np.clip(oldrgb+grain[:,:,None]*.80,0,255);Image.fromarray(np.rint(rgb).astype(np.uint8)).save(out/'own-preserved-colour-with-native-melange.png');mats['fabric']['baseColorTexture']='own-preserved-colour-with-native-melange.png'
 repeat=.08;x=xx/N*repeat;y=yy/N*repeat;nativeheight=bilinear(res,x/pixel_m,y/pixel_m)*.000007
 if pid=='1338619002':
  wx=np.cos(TAU*x/.0033);wy=np.cos(TAU*y/.0036);height=.00048*np.maximum(wx,0)*(1+.35*wy)+.00043*np.maximum(wy,0)*(1-.35*wx)+nativeheight
 else:
  rng=np.random.default_rng(int(pid)+614);field=Image.new('L',(N,N),15);draw=ImageDraw.Draw(field)
  for _ in range(2500):
   px,py=rng.uniform(0,N,2);r=rng.uniform(.0004,.0014)*N/repeat;phase=rng.uniform(0,TAU);pts=[(px+r*math.cos(a),py+r*.7*math.sin(a))for a in np.linspace(phase,phase+rng.uniform(1.5,4.2),8)];draw.line(pts,fill=int(rng.integers(100,255)),width=max(2,round(.00015*N/repeat)),joint='curve')
  curl=np.array(field.filter(ImageFilter.GaussianBlur(1)),float)/255;height=curl*(.00045 if pid=='1348917001'else .00060)+nativeheight
 dy,dx=np.gradient(height,repeat/N);normal=np.stack((-dx,dy,np.ones_like(dx)),2);normal/=np.linalg.norm(normal,axis=2,keepdims=True);orm=np.zeros((N,N,3),np.uint8);orm[:,:,0]=255;orm[:,:,1]=np.clip(245+grain*.12,230,253);Image.fromarray(np.rint((normal+1)*127.5).astype(np.uint8)).save(out/'own-visible-fleece-normal-2k.png');Image.fromarray(orm).save(out/'own-visible-fleece-orm-2k.png');ma=mats['fabric'];ma.update(normalTexture='own-visible-fleece-normal-2k.png',metallicRoughnessTexture='own-visible-fleece-orm-2k.png',normalScale=1.);ma['extras']['normal_orm_uv_scale']=(np.array(span)/repeat).tolist();ma['extras']['texture_provenance']=str(out/'own-native-melange-provenance.json');proof=dict(exact_SKU=pid,source_path=e['original_image'],source_sha256=C.sha(e['original_image']),source_pixels=list(im.size),native_crop_box=box,native_pixels=list(patch.size),master_unchanged=True,existing_macro_colours_and_pattern_kept=True,only_own_neutral_luminance_fibre_residual_added=True,old_basecolor_sha256=proof[0]['copied_sha256'],native_photo_pixel_m_estimated=pixel_m,one_final_bilinear_native_sampling=True,source_grain_std=float(res.std()),surface_repeat_m_estimated=repeat,output_pixels=[N,N],no_other_SKU_pixels=True,palette_quantization=False,generation=False);C.dump(out/'own-native-melange-provenance.json',proof);return mats,proof

def build(pid,V):
 assert pid in SEVEN+BROWN_FAMILY and not(V/'FINAL-FROZEN.json').exists()
 for frozen in V.glob('frozen-family-*/manifest.json'):
  if(frozen.parent/'FINAL-FROZEN.json').exists():assert pid not in {x['sku']for x in read(frozen)}, 'Immutable family: create a new revision folder'
 e=OLD[pid];previous=read(e['model_path']);out=V/'models'/e['id'];out.mkdir(parents=True,exist_ok=True);body=copy.deepcopy(previous['meshes'][0]);grid,normals,uv,thick,extra,pose,point_pose,error=reconstruct(e,body);meshes=[body];checks=[]
 # Preserve the accepted source black blanket-stitch geometry exactly.
 if pid=='1298464008':meshes.extend(copy.deepcopy(m)for m in previous['meshes'][1:]if m['material']=='yarn')
 raw,spec=surface(pid,grid,normals,uv,thick);removed=C.clean_collapsed_fibres(raw);m,qa=S._finalize(G.orient(raw));qa['collapsed_solids_removed']=removed;M.ensure_uv_faces([m]);G.ensure_float32_uv([m]);meshes.append(pose(m));checks.append(qa)
 fringe_spec=[]
 if F.RECIPES[pid].get('fringe_length_cm',0):
  raw,fringe_spec=fringes(pid,grid,normals,uv,thick,point_pose);C.clean_collapsed_fibres(raw);m,qa=S._finalize(G.orient(raw));M.ensure_uv_faces([m]);G.ensure_float32_uv([m]);meshes.append(m);checks.append(qa);raw=fuzz(m);C.clean_collapsed_fibres(raw);m,qa=S._finalize(G.orient(raw));M.ensure_uv_faces([m]);G.ensure_float32_uv([m]);meshes.append(m);checks.append(qa)
 pos=np.concatenate([np.array(m['positions']).reshape(-1,3)for m in meshes]);lo=pos.min(0);hi=pos.max(0);origin=np.array([(lo[0]+hi[0])/2,lo[1],(lo[2]+hi[2])/2]);dims=((hi-lo)*100).tolist()
 for m in meshes:m['positions']=(np.array(m['positions']).reshape(-1,3)-origin).reshape(-1).tolist()
 body_error=float(abs(np.array(meshes[0]['positions']).reshape(-1,3)+origin-np.array(previous['meshes'][0]['positions']).reshape(-1,3)).max());assert body_error<1e-15;assert all(meshes[0][key]==previous['meshes'][0][key]for key in['normals','uvs','indices']);mats,provenance=materials(pid,e,previous,out,extra['posed_artwork_span_m']);official=bool(e.get('official_plan_dimensions_cm'));note=('Resmî açık plan ölçüsü korunur. 'if official else'Açık plan ölçüsü fotoğraftan tahmindir; resmî üretici ölçüsü değildir. ')+'Önceki yumuşak R5 kumaş gövdesi/UV/desen rengi korunur; yalnız kendi kaynak fotoğrafındaki melanj lif ayrıntısı ve fotoğrafa göre fiziksel hav eklendi. Görünen lif boyu/kalınlığı/yoğunluğu, iki iplikli burgu demetleri ve yerçekimine göre püskül pozu yaklaşık yorumdur.'
 meta=copy.deepcopy(previous['metadata']);meta.update(dimensions_cm=dims,model_revision='bounded-own-native-melange-and-visible-fibre-fringe-r6',quality_note=note,scale_note=previous['metadata']['scale_note']+' '+note,previous_glb_sha256=e['sha256'],source_evidence_files=previous['metadata']['source_evidence_files']+[str(out/'own-native-melange-provenance.json'),str(out/'body-and-pattern-preservation.json')],estimated_fields=sorted(set(previous['metadata']['estimated_fields']+['own_fibre_melange_scale','visible_physical_pile_and_fringe_bundle_dimensions'])))
 C.dump(out/'model.json',dict(metadata=meta,materials=mats,meshes=meshes));C.dump(out/'body-and-pattern-preservation.json',dict(valid=True,previous_glb_path=e['glb_path'],previous_sha256=e['sha256'],body_position_max_relative_error_m=body_error,root_reconstruction_error_m=error,body_normals_UV_indices_identical=True,common_rigid_translation_m=(-origin).tolist(),existing_own_RGB_macro_colour_and_pattern_preserved=True,only_own_neutral_native_fibre_grain_added=True,surface=spec,fringe_bundles=fringe_spec,all_original_master_SHA_unchanged=all(C.sha(x['path'])==x['sha256']for x in e['original_images'])));C.dump(out/'geometry-validation.json',dict(valid=True,meshes=checks,R5_body_unchanged=True,all_visible_tufts_beyond_cloth_shell=True));C.dump(out/'material-validation.json',dict(valid=True,own_source_only=True,master_unchanged=True,native_RGB_not_palette_quantized=True));report=S.export_assets(out/'model.json',out,e['id']);glb=out/(e['id']+'.glb');d,b=S.read_glb(glb)
 for ma in d['materials']:
  source=mats[ma['name']];scale=source['extras'].get('normal_orm_uv_scale')
  if scale:
   for tex in[ma['normalTexture'],ma['pbrMetallicRoughness']['metallicRoughnessTexture']]:tex.setdefault('extensions',{})['KHR_texture_transform']=dict(scale=scale)
  ao=copy.deepcopy(ma['pbrMetallicRoughness']['metallicRoughnessTexture']);ao['strength']=.65;ma['occlusionTexture']=ao
  sheen=source['extras'].get('physical_sheen')
  if sheen:ma.setdefault('extensions',{})['KHR_materials_sheen']=sheen
 d['extensionsUsed']=sorted(set(d.get('extensionsUsed',[]))|{'KHR_texture_transform','KHR_materials_sheen'});b=M.embed_tangents(d,b);S.write_glb(glb,d,b);report['deliverable_sha256']['glb']=C.sha(glb);report['glb_bytes']=glb.stat().st_size;C.dump(Path(report['files']['validation']),report);entry={**e,**meta,'asset_dir':str(out),'model_path':str(out/'model.json'),'glb_path':str(glb),'sha256':C.sha(glb),'bytes':glb.stat().st_size,'geometry_validation':str(out/'geometry-validation.json'),'material_validation':str(out/'material-validation.json'),'frozen':False,'quality_pending':True,'actual_browser_review_passed':False,'model_status':'ready_for_browser_review'};assert entry['bytes']<40*1024*1024,entry['bytes'];C.dump(out/'entry.json',entry);rows=read(V/'manifest.json')if(V/'manifest.json').exists()else[];C.dump(V/'manifest.json',[x for x in rows if x['sku']!=pid]+[entry]);print(pid,entry['sha256'],entry['bytes'],flush=True)
if __name__=='__main__':
 brown='--brown'in sys.argv;siblings='--siblings'in sys.argv;V=P/('fringe-brown-r6-prototype'if brown else'fringe-own-colours-r6-siblings'if siblings else'source-fibre-fringe-seven-r6');V.mkdir(exist_ok=True)
 targets=[BROWN]if brown else [x for x in BROWN_FAMILY if x!=BROWN]if siblings else sys.argv[1:]or SEVEN
 for pid in targets:build(pid,V)
