"""Exact-SKU bolsters, shaped pile pillows and paired quilted pads."""
from pathlib import Path
import sys,json,math,hashlib,shutil,re
sys.dont_write_bytecode=True
import numpy as np
from PIL import Image,ImageFilter,ImageDraw
import build_softgoods as S
import pattern_textures as P
R=S.R;T=math.tau;sha=S.sha;dump=S.dump;B=S.B;G=S.G;M=S.M

def own(pid):
 cap,ep=S.source(pid);rows=json.loads((R/'joined-softgoods-queue.json').read_text())['products'];row=next(x for x in rows if x['sku']==pid);refs=[x for x in json.loads((R/'original-image-masters.json').read_text())if x['sku']==pid];base=row['reference_images'][0]['url'].split('?')[0];hero=max((x for x in refs if x['url'].split('?')[0]==base),key=lambda x:x['pixels'][0]);return cap,ep,refs,hero

def clean_collapsed_fibres(p):
 if not any(x in p['name']for x in['pile','fibre','fringe','yarn']):return 0
 positions=np.asarray(np.round(np.asarray(p['_vertices']),9),np.float32).astype(float);vertices,mapping=np.unique(np.round(positions,9),axis=0,return_inverse=True);faces=np.asarray(p['_faces']);f=mapping[faces];edges=np.sort(np.concatenate((f[:,[0,1]],f[:,[1,2]],f[:,[2,0]])),axis=1);unique,counts=np.unique(edges,axis=0,return_counts=True);bad=unique[counts!=2]
 if not len(bad):return 0
 parent=list(range(len(vertices)))
 def root(i):
  while parent[i]!=i:parent[i]=parent[parent[i]];i=parent[i]
  return i
 for a,b in unique:
  a,b=root(int(a)),root(int(b));parent[b]=a
 invalid={root(int(i))for i in bad.reshape(-1)};keep=np.array([root(int(a))not in invalid for a in f[:,0]]);assert keep.mean()>.98,'Only rare collapsed individual fibre solids may be removed';kept=faces[keep];used=np.unique(kept);reindex=np.full(len(positions),-1,int);reindex[used]=np.arange(len(used));p['_vertices']=[p['_vertices'][i]for i in used];p['_uvs']=[p['_uvs'][i]for i in used];p['_faces']=reindex[kept].tolist();return len(invalid)

def finish(pid,parts,mats,cap,ep,refs,hero,target,official,form,estimated,note,extra=None):
 frozen={e['sku']for p in R.glob('frozen-batch-*-manifest.json')for e in json.loads(p.read_text())};assert pid not in frozen
 v=np.concatenate([np.array(p['_vertices'])for p in parts]);lo=v.min(0);hi=v.max(0);scale=np.array([value/(hi[j]-lo[j])if value is not None else 1. for j,value in enumerate(target)]);origin=np.array([(lo[0]+hi[0])/2,lo[1],(lo[2]+hi[2])/2]);meshes=[];checks=[]
 for p in parts:
  p['_vertices']=[tuple((np.array(x)-origin)*scale)for x in p['_vertices']];removed=clean_collapsed_fibres(p);mesh,qa=S._finalize(G.orient(p));qa['rare_float32_collapsed_fibre_solids_removed']=removed;meshes.append(mesh);checks.append(qa)
 repairs=M.ensure_uv_faces(meshes)+G.ensure_float32_uv(meshes);vertices=np.concatenate([np.array(m['positions']).reshape(-1,3)for m in meshes]);dims=((vertices.max(0)-vertices.min(0))*100).tolist();fmt=lambda x:format(round(x,2),'g').replace('.','p');id='hm-'+pid+'-h'+fmt(dims[1])+'-w'+fmt(dims[0])+'-d'+fmt(dims[2]);folder=R/'models'/id;folder.mkdir(parents=True,exist_ok=True);maps=[];provenances=[]
 for key,ma in mats.items():
  for slot in ['baseColorTexture','normalTexture','metallicRoughnessTexture']:
   src=Path(ma[slot]);dst=folder/(key+'-'+src.name);shutil.copyfile(src,dst);ma[slot]=dst.name;maps.append(dict(material=key,slot=slot,path=str(dst),pixels=list(Image.open(dst).size),sha256=sha(dst)))
  p=ma['extras'].get('texture_provenance')
  if p:
   dst=folder/(key+'-texture-provenance.json');shutil.copyfile(p,dst);provenances.append(str(dst));ma['extras']['texture_provenance']=str(dst)
   donor=Path(p).parent/'donor-crop-native.png'
   if donor.exists():shutil.copyfile(donor,folder/(key+'-donor-crop-native.png'))
 comp=cap['materials'].split('BAKIM')[0].replace('ÜRÜN İÇERİĞİ','').strip();label='; '.join(x.strip(' *')for x in comp.splitlines()if re.search(r'\d+\s*%',x));refs.sort(key=lambda x:x['path']!=hero['path']);meta=dict(id=id,sku=pid,brand='H&M Home',name=S.turkish_sentence_case(cap['productHeading']),category='Kırlentler',url=cap['url'],dimensions_cm=dims,official_measurements=official,source_dimensions_hwd_cm=official.get('hwd_cm'),estimated_dimensions=bool(estimated),estimated_fields=estimated,scale_note=note,material_label=label or comp,source_market=cap.get('source_market','Türkiye'),source_size_kind=cap['_size_source_kind'],official_size_scope=cap['_size_scope'],source_size_pointer=str(ep)+'#description',source_evidence_files=[str(ep),str(R/'joined-softgoods-queue.json')]+provenances,source_images=[dict(url=x['url'],alt=x['alt'])for x in refs],original_image=hero['path'],original_image_url=hero['url'],original_image_sha256=hero['sha256'],original_images=[{k:x[k]for k in ['path','url','sha256']}for x in refs],variant_status_verbatim='Resmî exactSKU beden/ürün içeriği ve özgün ürün fotoğrafı bağlandı.',units='metres',up_axis='Y',origin='bottom bounding-box centre',product_form=form,photo_pixels_baked=any(ma['extras'].get('photo_pixels_baked')for ma in mats.values()),baked_reflections=False,texture_resolution_policy='OwnSKU native cloth crops and/or source-measured intrinsic pattern;2K PBR maps. Fine fibres, local seams and pattern phase are photo estimates; no full marketing photo/background wrapped.',geometry_limitations=['Fotoğraftan yaklaşık ürün modeli; üretici CAD/tarama verisi değildir.'])
 if extra:meta.update(extra)
 dump(folder/'model.json',dict(metadata=meta,materials=mats,meshes=meshes));dump(folder/'geometry-validation.json',dict(valid=True,meshes=checks,closed_material_solids=True,triangles=sum(c['triangles']for c in checks),uv_repairs=repairs,official_target_metres=target,product_form=form));dump(folder/'material-validation.json',dict(valid=True,maps=maps,source_masters_unchanged=all(sha(x['path'])==x['sha256']for x in refs),no_source_photo_upscale=True));report=S.export_assets(folder/'model.json',folder,id);gp=folder/(id+'.glb');doc,blob=S.read_glb(gp)
 for ma in doc['materials']:ma.setdefault('extensions',{})['KHR_materials_sheen']=mats[ma['name']]['extras']['physical_sheen']
 doc['extensionsUsed']=sorted(set(doc.get('extensionsUsed',[]))|{'KHR_materials_sheen'});blob=M.embed_tangents(doc,blob);S.write_glb(gp,doc,blob);report['deliverable_sha256']['glb']=sha(gp);report['glb_bytes']=gp.stat().st_size;dump(report['files']['validation'],report);entry={k:v for k,v in meta.items()if k not in ['photo_pixels_baked','baked_reflections','units','up_axis','origin','geometry_limitations']};entry.update(asset_dir=str(folder),model_path=str(folder/'model.json'),glb_path=str(gp),sha256=sha(gp),bytes=gp.stat().st_size,geometry_validation=str(folder/'geometry-validation.json'),material_validation=str(folder/'material-validation.json'),size_source_kind=cap['_size_source_kind'],size_source_urls=cap['_size_source_urls'],model_revision='hmhome-exact-sku-shaped-softgoods-2026-10-24-v1');dump(folder/'entry.json',entry);allrows=json.loads((R/'manifest.json').read_text());dump(R/'manifest.json',[x for x in allrows if x['sku']!=pid]+[entry]);print('BUILT SHAPED',id,entry['bytes'],flush=True);return entry

def intrinsic_pattern(pid,hero,kind,donor,box,tile=.12):
 out=R/'materials'/pid/('shaped-'+kind);out.mkdir(parents=True,exist_ok=True);photo=Image.open(donor['path']).convert('RGB');crop=photo.crop(box);crop.save(out/'donor-crop-native.png');a=np.asarray(crop,float);n=2048;yy,xx=np.mgrid[0:n,0:n].astype(float)/(n-1);rng=np.random.default_rng(int(pid));lum=a.mean(2)
 if kind=='jacquard':
  colourbox=[650,1300,1100,1600];colourcrop=Image.open(hero['path']).convert('RGB').crop(colourbox);colourcrop.save(out/'colour-reference-native.png');pa=np.asarray(colourcrop,float);pl=pa.mean(2);light=np.median(pa[pl>np.quantile(pl,.77)],axis=0);colour=np.median(pa[(pl>np.quantile(pl,.15))&(pl<np.quantile(pl,.40))],axis=0);pitch=.015;u=xx*tile/pitch;v=yy*tile/pitch;diagonal=np.minimum(abs(((u+v+.5)%1)-.5),abs(((u-v+.5)%1)-.5));weight=np.asarray(Image.fromarray(np.rint((diagonal<.105)*255).astype(np.uint8)).filter(ImageFilter.GaussianBlur(.45)),float)/255;rgb=colour[None,None,:]*(1-weight[:,:,None])+light[None,None,:]*weight[:,:,None];height=weight*.16;scale_note='Approximately15mm diamond repeats estimated from the sameSKU18cm circular end and45cm side photographs; exact seam/pattern phase is interpreted. Intrinsic palette comes from the lit side cloth in the sameSKU hero, avoiding dark end-face lighting.'
 else:
  redmask=(a[:,:,0]-a[:,:,1]>40)&(a[:,:,0]>75);colour=np.median(a[redmask],axis=0);light=np.median(a[(a.min(2)>215)&~redmask],axis=0);weight=((xx+yy+.15)%1)<.50;rgb=np.where(weight[:,:,None],colour[None,None,:],light[None,None,:]);height=np.zeros((n,n));scale_note='One continuous15cm helical repeat, with integer periods around both tile axes, interpreted from thisSKU55cm-high hooked cushion; own red/white palette. No reset at intermediate shaft bands.'
 grain=rng.normal(0,.40,(n,n));rgb=np.clip(rgb+grain[:,:,None],0,255);Image.fromarray(rgb.astype(np.uint8)).save(out/'albedo-2k.png');height+=grain*.007;dy,dx=np.gradient(height);normal=np.stack([-dx*3,dy*3,np.ones_like(dx)],2);normal/=np.linalg.norm(normal,axis=2,keepdims=True);Image.fromarray(np.rint((normal+1)*127.5).astype(np.uint8)).save(out/'normal-2k.png');orm=np.zeros((n,n,3),np.uint8);orm[:,:,0]=255;orm[:,:,1]=239;Image.fromarray(orm).save(out/'orm-2k.png');prov=dict(source_path=donor['path'],source_sha256=donor['sha256'],source_pixels=donor['pixels'],crop_box_original_pixels=box,crop_pixels=list(crop.size),crop_pixel_identical=np.array_equal(np.asarray(crop),np.asarray(photo)[box[1]:box[3],box[0]:box[2]]),mapped_pixels=[n,n],operations=['Immutable sameSKU integer cloth crop retained as evidence only','Intrinsic thread/print palette measured from own crop','Regular diamond/stripe repeat reconstructed from own source spacing and form; photographic folds, backdrop and silhouette excluded','Procedural fine fibre normal/roughness are photo estimates'],palette_rgb=[light.tolist(),colour.tolist()],pattern_scale_note=scale_note,photo_estimated=True,source_master_unchanged=sha(donor['path'])==donor['sha256'],full_marketing_photo_wrapped=False,background_pixels_baked=False,source_upscaled=False,photo_pixels_baked=False);
 if kind=='jacquard':prov.update(colour_reference_path=hero['path'],colour_reference_sha256=hero['sha256'],colour_reference_box=colourbox)
 dump(out/'texture-provenance.json',prov)
 return dict(baseColorFactor=[1,1,1,1],metallic=1,roughness=1,baseColorTexture=str(out/'albedo-2k.png'),normalTexture=str(out/'normal-2k.png'),metallicRoughnessTexture=str(out/'orm-2k.png'),normalScale=.45,doubleSided=False,extras=dict(intrinsic_material=True,photo_pixels_baked=False,baked_reflections=False,texture_resolution=2048,texture_provenance=str(out/'texture-provenance.json'),atlas_tile_metres=tile,physical_sheen=dict(sheenColorFactor=[.055,.045,.03],sheenRoughnessFactor=.92)))

def plain_piping(pid,ma):
 out=R/'materials'/pid/'plain-piping';out.mkdir(parents=True,exist_ok=True);palette=json.loads(Path(ma['extras']['texture_provenance']).read_text())['palette_rgb'];colour=palette[0];result=json.loads(json.dumps(ma))
 for slot,name,values in [('baseColorTexture','albedo',colour),('normalTexture','normal',[128,128,255]),('metallicRoughnessTexture','orm',[255,239,0])]:Image.new('RGB',(4,4),tuple(round(v)for v in values)).save(out/(name+'.png'));result[slot]=str(out/(name+'.png'))
 result['extras']['constant_PBR_map_no_artificial_upscale']=True;return result

def bolster_geometry(length,diameter,tile):
 rad=diameter/2-.0015;N=128;K=65;vertices=[];uv=[];faces=[]
 for i,x in enumerate(np.linspace(-length/2+.002,length/2-.002,K)):
  rr=rad*(1+.008*math.sin(math.pi*i/(K-1)))
  for j in range(N+1):
   t=T*(j%N)/N;vertices.append((x,diameter/2+rr*math.sin(t),rr*math.cos(t)));uv.append((t*rad/tile,x/tile))
 for i in range(K-1):
  for j in range(N):a=i*(N+1)+j;b=a+N+1;faces.extend([(a,a+1,b),(a+1,b+1,b)])
 for side,outer in [(-1,0),(1,(K-1)*(N+1))]:
  ring=[]
  for k in range(17):
   r=rad*(1-k/17);ids=[];x=side*(length/2-.002-.0008*(1-(r/rad)**2))
   for j in range(N):
    t=T*j/N;ids.append(len(vertices));vertices.append((x,diameter/2+r*math.sin(t),r*math.cos(t)));uv.append((r*math.cos(t)/tile,(diameter/2+r*math.sin(t))/tile))
   ring.append(ids)
  for k in range(len(ring)-1):
   for j in range(N):a,b=ring[k][j],ring[k][(j+1)%N];c,d=ring[k+1][j],ring[k+1][(j+1)%N];faces.extend([(a,b,c),(b,d,c)]if side==-1 else[(a,c,b),(b,c,d)])
  centre=len(vertices);vertices.append((side*(length/2-.002-.0008),diameter/2,0));uv.append((0,diameter/2/tile))
  for j in range(N):a,b=ring[-1][j],ring[-1][(j+1)%N];faces.append((a,b,centre)if side==-1 else(a,centre,b))
 # Cylinder and caps share positions after welding, with separate correct cap UVs.
 parts=[B.solid('closed-stuffed-cylindrical-body-with-mapped-round-end-panels','fabric',vertices,faces,uv)]
 for side in [-1,1]:
  points=[(side*(length/2-.002),diameter/2+rad*math.sin(t),rad*math.cos(t))for t in np.linspace(0,T,128,endpoint=False)];parts.append(B.tube('soft-cream-piped-round-end-'+str(side),'piping',points,.0015,.0015,8,True,guide=[1,0,0]))
 return parts

def smooth_outline(points,count=256):
 p=np.asarray(points,float);result=[]
 for t in np.linspace(0,len(p),count,endpoint=False):
  i=int(t);u=t-i;a,b,c,d=[p[j%len(p)]for j in[i-1,i,i+1,i+2]];result.append(.5*((2*b)+(-a+c)*u+(2*a-5*b+4*c-d)*u*u+(-a+3*b-3*c+d)*u*u*u))
 p=np.array(result);p=(p-p.min(0))/(p.max(0)-p.min(0));return p

CLOUD=[(.15,.02),(.06,.10),(.01,.24),(0,.40),(.035,.52),(.09,.57),(.14,.54),(.14,.74),(.20,.92),(.33,1),(.46,.98),(.53,.84),(.55,.64),(.59,.77),(.69,.86),(.79,.82),(.84,.67),(.83,.47),(.89,.53),(.95,.51),(1,.38),(.99,.22),(.95,.12),(.84,.05),(.66,.01),(.40,0)]
BEAR=[(.50,0),(.27,.045),(.12,.20),(.065,.39),(.06,.59),(.02,.73),(0,.84),(.06,.96),(.17,1),(.28,.965),(.34,.89),(.50,.91),(.66,.89),(.73,.965),(.84,.99),(.95,.95),(1,.84),(.98,.74),(.94,.64),(.94,.43),(.89,.23),(.75,.065)]

def loft_pile_shape(pid,outline,w,h,d,pile_length=.003,tufts=2500,tile=.10):
 outline=smooth_outline(outline);centre=np.array([.5,.42]);N=len(outline);K=49;vertices=[];uv=[];faces=[];metric_outline=outline*np.array([w,h]);segments=np.roll(metric_outline,-1,axis=0)-metric_outline;segment_length=(segments*segments).sum(1)
 size=257;gy,gx=np.mgrid[0:size,0:size].astype(float)/(size-1);gridxy=np.stack([gx*w,gy*h],2);distance_grid=np.full((size,size),np.inf)
 for start,segment,length2 in zip(metric_outline,segments,segment_length):
  fraction=np.clip(((gridxy-start)*segment).sum(2)/length2,0,1);delta=gridxy-(start+fraction[:,:,None]*segment);distance_grid=np.minimum(distance_grid,np.sqrt((delta*delta).sum(2)))
 mask=Image.new('L',(size,size));ImageDraw.Draw(mask).polygon([tuple(x*(size-1))for x in outline],fill=255);field=np.sin(math.pi/2*np.minimum(1,distance_grid/(h*.32)))**.72*(np.asarray(mask)>0);axis=np.arange(-8,9);kernel=np.exp(-.5*(axis/2.4)**2);kernel/=kernel.sum()
 for axis0 in [0,1]:field=np.apply_along_axis(lambda v:np.convolve(np.pad(v,8,mode='edge'),kernel,mode='valid'),axis0,field)
 def point(t,r,side):
  index=t*N;i=int(index)%N;f=index-int(index);edge=outline[i]*(1-f)+outline[(i+1)%N]*f;p=centre+r*(edge-centre);metric=p*np.array([w,h]);fraction=np.clip(((metric-metric_outline)*segments).sum(1)/segment_length,0,1);distance=np.sqrt(((metric-(metric_outline+fraction[:,None]*segments))**2).sum(1).min());px,py=np.clip(p*(size-1),0,size-1-1e-6);ix,iy=int(px),int(py);fx,fy=px-ix,py-iy;body=field[iy,ix]*(1-fx)*(1-fy)+field[iy,ix+1]*fx*(1-fy)+field[iy+1,ix]*(1-fx)*fy+field[iy+1,ix+1]*fx*fy;z=.0015+(d/2-.0015)*body*(1-math.exp(-distance/.003));return np.array([(p[0]-.5)*w,p[1]*h,z*side])
 for side in [-1,1]:
  start=len(vertices);pole=point(0,0,side);vertices.append(pole);uv.append((pole[0]/tile,pole[1]/tile));rings=[]
  for k in range(1,K+1):
   ids=[]
   for j in range(N):
    pt=point(j/N,k/K,side);ids.append(len(vertices));vertices.append(pt);uv.append((pt[0]/tile,pt[1]/tile))
   rings.append(ids)
  for j in range(N):a,b=rings[0][j],rings[0][(j+1)%N];faces.append((start,a,b)if side==1 else(start,b,a))
  for k in range(K-1):
   for j in range(N):a,b=rings[k][j],rings[k][(j+1)%N];c,d0=rings[k+1][j],rings[k+1][(j+1)%N];faces.extend([(a,c,b),(b,c,d0)]if side==1 else[(a,b,c),(b,d0,c)])
  if side==-1:rear=rings[-1]
  else:front=rings[-1]
 for j in range(N):a,b=rear[j],rear[(j+1)%N];c,d0=front[j],front[(j+1)%N];faces.extend([(a,b,c),(b,d0,c)])
 parts=[B.solid('continuous-'+('cloud-four-lobe'if pid=='1109219001'else'bear-round-ears')+'-stuffed-body','fabric',vertices,faces,uv)];hairs=[];rng=np.random.default_rng(int(pid))
 for k in range(tufts):
  t=float(rng.random());r=float(np.sqrt(rng.random())*.998);side=1 if k%2 else-1;pt=point(t,r,side);dt=point(t+.0001,r,side)-point(t-.0001,r,side);dr=point(t,min(.99999,r+.0001),side)-point(t,max(0,r-.0001),side);normal=np.cross(dr,dt)
  if normal[2]*side<0:normal=-normal
  normal/=np.linalg.norm(normal);tangent=dt/np.linalg.norm(dt);length=pile_length*float(rng.uniform(.7,1.3));base=pt-normal*.00012;mid=pt+normal*length*.70+tangent*length*.23;tip=pt+normal*length*.90+tangent*length*.52;hairs.append(B.tube('attached-soft-curled-fibre','fabric',[base,mid,tip],.00012,.000085,4,False,guide=tangent.tolist()))
 parts.append(S.merge(hairs,'many-closed-curled-pile-fibres-attached-to-body','fabric'));seam=[point(j/N,1,1)*[1,1,0]for j in range(N)];parts.append(B.tube('soft-perimeter-pile-sewn-edge','fabric',seam,.0006,.0006,6,True,guide=[0,0,1]));return parts

def square_pile(w,h,d,pile=.003,tile=.10):
 parts=S.cushion(w,h,d,'pile',tile);main=parts[0];N=81;nn=N*N;rng=np.random.default_rng(1271068001);hairs=[]
 for k in range(2800):
  u,v=rng.uniform(-.997,.997,2);x,y,z=S.cloth_point(float(u),float(v),w,h,d,'pile');side=1 if k%2 else-1;pt=np.array([x,y,z*side]);eps=.0001;pu=np.array(S.cloth_point(float(u+eps),float(v),w,h,d,'pile'));mu=np.array(S.cloth_point(float(u-eps),float(v),w,h,d,'pile'));pv=np.array(S.cloth_point(float(u),float(v+eps),w,h,d,'pile'));mv=np.array(S.cloth_point(float(u),float(v-eps),w,h,d,'pile'));normal=np.cross(pu-mu,pv-mv);normal/=np.linalg.norm(normal);normal[2]*=side;tangent=(pu-mu)/np.linalg.norm(pu-mu);length=pile*rng.uniform(.7,1.3);pts=[pt-normal*.0001,pt+normal*length*.65+tangent*length*.25,pt+normal*length*.90+tangent*length*.55];hairs.append(B.tube('attached-curly-plush-fibre','fabric',pts,.00012,.00009,4,False,guide=tangent.tolist()))
 parts.append(S.merge(hairs,'many-closed-short-plush-fibre-loops','fabric'));return parts

def pad_point(u,v):
 x=.19*u*(1-.025*(1-v*v));y=.19+.19*v*(1-.025*(1-u*u));edge=max(0,(1-abs(u)**6)*(1-abs(v)**6));z=.0015+.0185*edge**.22
 for a in [-.34,.34]:
  for b in [-.34,.34]:z-=.014*math.exp(-((u-a)**2+(v-b)**2)/.010)
 z-=.0018*(math.exp(-((u-.34)/.07)**2)+math.exp(-((u+.34)/.07)**2)+math.exp(-((v-.34)/.07)**2)+math.exp(-((v+.34)/.07)**2))*edge
 return x,y,max(.0015,z)
def quilted_pads():
 N=81;vertices=[];uv=[];faces=[]
 for side in [-1,1]:
  for v in np.linspace(-1,1,N):
   for u in np.linspace(-1,1,N):x,y,z=pad_point(float(u),float(v));vertices.append((x,y,z*side));uv.append(((u+1)/2,(1-v)/2))
 nn=N*N
 for side in [0,1]:
  for j in range(N-1):
   for i in range(N-1):a=side*nn+j*N+i;b=a+N;faces.extend([(a,b,a+1),(a+1,b,b+1)]if side==0 else[(a,a+1,b),(a+1,b+1,b)])
 boundary=list(range(N))+[j*N+N-1 for j in range(1,N)]+list(range((N-1)*N+N-2,(N-1)*N-1,-1))+[j*N for j in range(N-2,0,-1)]
 for i,a in enumerate(boundary):b=boundary[(i+1)%len(boundary)];faces.extend([(a,b,nn+a),(b,nn+b,nn+a)])
 main=B.solid('closed-four-knot-quilted-cotton-seat-pad','fabric',vertices,faces,uv);parts=[main];seam=[(vertices[a][0],vertices[a][1],0)for a in boundary];parts.append(B.tube('thin-sewn-pad-perimeter','fabric',seam,.0005,.0005,6,True,guide=[0,0,1]));knots=[]
 for side in [-1,1]:
  for u in [-.34,.34]:
   for v in [-.34,.34]:
    x,y,z=pad_point(u,v);points=[(x+.001*math.cos(t),y+.001*math.sin(t),side*(z+.00015))for t in np.linspace(0,T,12,endpoint=False)];knots.append(B.tube('physical-quilting-thread-knot','fabric',points,.00016,.00016,4,True,guide=[0,0,1]))
 parts.append(S.merge(knots,'eight-front-reverse-quilting-knots','fabric'));a=np.concatenate([np.array(p['_vertices'])for p in parts]);lo=a.min(0);hi=a.max(0);scale=np.array([.38,.38,.04])/(hi-lo);result=[]
 for side in [-1,1]:
  for p in parts:
   q=dict(p);q['name']=p['name']+'-set-piece-'+str(side);q['_vertices']=[tuple((np.array(v)-np.array([(hi[0]+lo[0])/2,lo[1],(hi[2]+lo[2])/2]))*scale+np.array([side*.205,0,0]))for v in p['_vertices']];result.append(q)
 return result

def candy_geometry():
 main=[(-.085,y,0)for y in np.linspace(.055,.40,55)]+[(.085*math.cos(t),.40+.085*math.sin(t),0)for t in np.linspace(math.pi,0,65)[1:]]+[(.085,y,0)for y in np.linspace(.40,.31,20)[1:]];first=np.linspace(-math.pi/2+.02,0,17)[:-1];last=np.linspace(0,math.pi/2-.02,17)[1:];points=[(-.085,.055+.052*math.sin(t),0)for t in first]+main+[(.085,.31-.052*math.sin(t),0)for t in last];factors=np.r_[np.cos(first),np.ones(len(main)),np.cos(last)];q=B.tube('continuous-canvas-candy-cane-with-soft-rounded-stuffed-tips','fabric',points,.055,.052,64,False,guide=[0,0,1],uv_scale=.15)
 for i,(p,scale)in enumerate(zip(points,factors)):
  for j in range(65):k=i*65+j;q['_vertices'][k]=tuple(np.array(p)+(np.array(q['_vertices'][k])-np.array(p))*scale)
 return [q]

def build(pid):
 cap,ep,refs,hero=own(pid)
 if pid in ['1344682002','1344682003']:
  assert re.search(r'Çap:\s*18\s*cm',cap['description'])and re.search(r'Uzunluk:\s*45\s*cm',cap['description']);donor=next(x for x in refs if ('a17161b88467'if pid.endswith('2')else'095c5060d7c4')in x['path']);ma=intrinsic_pattern(pid,hero,'jacquard',donor,[400,850,1120,1570]);plain=plain_piping(pid,ma);parts=bolster_geometry(.45,.18,.12);return finish(pid,parts,dict(fabric=ma,piping=plain),cap,ep,refs,hero,[.45,.18,.18],dict(diameter_cm=18,length_cm=45,hwd_cm=[18,45,18]),'filled_cylindrical_bolster',['jacquard_repeat_spacing','local_piping_geometry','minor_end_panel_curvature'],'Resmî çap18cm ve uzunluk45cm korunur. Dairesel uçlar ve iki krem biye ayrı hacimdir. Jakar tekrar aralığı yaklaşık15mm, dikişte desen fazı ve yumuşak uç eğriliği fotoğraf yorumudur.')
 if pid in ['1109219001','1352575001','1271068001']:
  if pid=='1109219001':w,h,d=.50,.305,.15;outline=CLOUD;box=[550,1100,934,1484];length=.0027;form='cloud_shaped_stuffed_pillow';official=dict(height_cm=30.5,length_cm=50,hwd_cm=[30.5,50,None]);assert'30,5'in cap['description']and'50 cm'in cap['description']
  elif pid=='1352575001':w,h,d=.47,.38,.17;outline=BEAR;box=[520,950,1032,1462];length=.005;form='bear_shaped_stuffed_pillow';official=dict(height_cm=38,widest_width_cm=47,hwd_cm=[38,47,None]);assert'38 cm'in cap['description']and'47 cm'in cap['description']
  else:
   match=re.search(r'(\d+)\s*[Xx×]\s*(\d+)',cap['sizes']);short,long=sorted(float(x)for x in match.groups());w,h,d=long/100,short/100,short*.0044;box=[520,950,1032,1462];length=.003;form='upright_plush_cover';official=dict(cover_size_label=match.group(0),hwd_cm=[short,long,None])
  donor=next(x for x in refs if ('426ce6eff2d5'if pid=='1109219001'else'cc829efc45b5'if pid=='1352575001'else'f5c0572abe7e')in x['path']);box=[400,1100,912,1612]if pid=='1109219001'else[300,1300,556,1556]if pid=='1352575001'else[500,1000,1012,1512];ma=S.material(pid,'pile',donor,box,hero,'pile',.04);ma['normalScale']=1.0;ma['extras']['physical_sheen']=dict(sheenColorFactor=[.25,.24,.21],sheenRoughnessFactor=.90);parts=square_pile(w,h,d,length,ma['extras']['atlas_tile_metres'])if pid=='1271068001'else loft_pile_shape(pid,outline,w,h,d,length,tile=ma['extras']['atlas_tile_metres']);extra=dict(estimated_filling_depth_cm=d*100,pile_length_cm_estimated=length*100,source_outline_reference=str(R/'shaped-outline-reference.jpg'));return finish(pid,parts,dict(fabric=ma),cap,ep,refs,hero,[w,h,None],official,form,['filling_depth_cm','pile_length_and_distribution','local_seam_geometry'],f'Resmî ürün planı{w*100:g}×{h*100:g}cm korunur. Yaklaşık{d*100:g}cm gövde dolgunluğu ve{length*100:g}cm kısa hav fotoğraf tahminidir; kıvrılmış kapalı lifler gövdeye bağlıdır. Kendi ürün fotoğrafının yalnız kumaş bölümü kullanılır; arka plan kaplanmaz.',extra)
 if pid=='1359573001':
  assert'55 cm'in cap['description'];ma=intrinsic_pattern(pid,hero,'candy',hero,[450,550,1250,1500],.1);parts=candy_geometry();return finish(pid,parts,dict(fabric=ma),cap,ep,refs,hero,[None,.55,None],dict(height_cm=55,hwd_cm=[55,None,None]),'candy_cane_shaped_stuffed_pillow',['width_cm','depth_cm','stripe_phase','local_seam_geometry'],'Resmî yükseklik55cm korunur. En yaklaşık27cm, kalınlık yaklaşık11cm ve kavis oranı kendi fotoğrafından tahmindir. Kırmızı/beyaz pamuklu kumaş şeritlerinin başlangıç fazı fotoğraf yorumudur; kapalı ve hacimli, uçları yumuşak yuvarlatılmış baston biçimi kullanılır.')
 if pid in ['1232250012','1232250013']:
  assert'4 cm'in cap['description']and re.search(r'38\s*[Xx×]\s*38',cap['sizes']);P.SPECS[pid]=dict(box=[300,250,1225,1115],kind='narrow_stripes');ma=P.make(pid,hero);parts=quilted_pads();piping=plain_piping(pid,ma)
  for p in parts:
   if'perimeter'in p['name']or'knots'in p['name']:p['material']='piping'
  return finish(pid,parts,dict(fabric=ma,piping=piping),cap,ep,refs,hero,[None,None,None],dict(per_item_width_cm=38,per_item_length_cm=38,per_item_thickness_cm=4,pieces=2,hwd_cm=[4,38,38]),'two_quilted_seat_pads',['set_display_spacing_cm','local_quilting_and_seam_geometry'],'İki minderin her birinde resmî38×38×4cm korunur. Önizlemede iki gerçek parça3cm aralıkla dik gösterilir; setin79cm toplam teşhir eni ürün ölçüsü değildir. Dört kapitone düğümü ve yerel kumaş kıvrımları fotoğraf yorumudur.',dict(quantity=2,per_item_dimensions_cm=[38,38,4],display_arrangement_estimated=True))
 raise ValueError('Unsupported exactSKU '+pid)
if __name__=='__main__':
 for pid in sys.argv[1:]:build(pid)
