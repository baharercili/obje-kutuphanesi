from pathlib import Path
import json,hashlib,shutil,sys
R=Path(__file__).resolve().parent;num=sys.argv[1];src=Path(sys.argv[2]);qa=Path(sys.argv[3]);F=R/('frozen-batch-'+num);assert not(F/'FINAL-FROZEN.json').exists();F.mkdir(exist_ok=True);sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,d):Path(p).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
rows=json.loads(src.read_text());checks=json.loads(qa.read_text());assert checks['valid'];by={e['id']:e for e in checks['checks']};out=[];inputs=[]
for e in rows:
 assert e['sha256']==sha(e['glb_path'])==by[e['id']]['sha256'];old=Path(e['asset_dir']);folder=F/'models'/e['id'];assert not folder.exists();shutil.copytree(old,folder);e=dict(e)
 for k in['asset_dir','model_path','glb_path','geometry_validation','material_validation']:e[k]=str(e[k]).replace(str(old),str(folder))
 assert all((folder/(n+'.png')).exists()for n in['on','yan','on-capraz','ustten','arka']);e.update(frozen=True,quality_pending=False,model_status='ready_for_browser_review',native_renders={n:str(folder/(n+'.png'))for n in['on','yan','on-capraz','ustten','arka']},independent_validation_file=str(F/'independent-validation.json'),source_photo_masters_unchanged=True);out.append(e)
 for q in e['original_images']:assert sha(q['path'])==q['sha256'];inputs.append(dict(sku=e['sku'],path=q['path'],sha256=q['sha256'],kind='immutable_ownSKU_JPEG'))
 for f in e['source_evidence_files']:inputs.append(dict(sku=e['sku'],path=f,sha256=sha(f),kind='source_or_texture_provenance'))
shutil.copyfile(qa,F/'independent-validation.json');is_rug=all(e['category']=='Halılar'for e in rows);shutil.copyfile(R/('native-render-rugs.swift'if is_rug else'native-render-throws.swift'if all(e['category']=='Battaniye ve örtüler'for e in rows)else'native-render.swift'),F/'native-render-configuration.swift')
if len({e['category']for e in rows})>1:
 for category,config in [('Kırlentler','native-render.swift'),('Battaniye ve örtüler','native-render-throws.swift')]:
  if any(e['category']==category for e in rows):shutil.copyfile(R/config,F/config)
 dump(F/'native-render-configurations-by-model.json',{e['id']:('native-render-throws.swift'if e['category']=='Battaniye ve örtüler'else'native-render.swift')for e in rows})
for f in R.glob('first-eight-final-comparison-*.jpg')if num=='01'else[]:shutil.copyfile(f,F/f.name)
for f in R.glob('second-eight-final-comparison-*.jpg')if num=='02'else[]:shutil.copyfile(f,F/f.name)
for f in R.glob('third-eight-final-comparison-*.jpg')if num=='03'else[]:shutil.copyfile(f,F/f.name)
for f in R.glob('shaped-eight-final-comparison-*.jpg')if num=='04'else[]:shutil.copyfile(f,F/f.name)
for f in R.glob('inner-chenille-eight-final-comparison-*.jpg')if num=='05'else[]:shutil.copyfile(f,F/f.name)
for f in R.glob('holiday-first-twelve-final-comparison-*.jpg')if num=='06'else[]:shutil.copyfile(f,F/f.name)
for f in R.glob('holiday-last-eight-final-comparison-*.jpg')if num=='07'else[]:shutil.copyfile(f,F/f.name)
for f in R.glob('flange-eight-final-comparison-*.jpg')if num=='08'else[]:shutil.copyfile(f,F/f.name)
for f in R.glob('woven-embroidered-eight-final-comparison-*.jpg')if num=='09'else[]:shutil.copyfile(f,F/f.name)
for f in R.glob('last-nine-pillows-final-comparison-*.jpg')if num=='10'else[]:shutil.copyfile(f,F/f.name)
for f in R.glob('rug-first-eight-final-comparison-*.jpg')if num=='11'else[]:shutil.copyfile(f,F/f.name)

for prefix in sys.argv[4:]:
 for f in R.glob(prefix+'-*.jpg'):shutil.copyfile(f,F/f.name)
visual_scope='Source identity, selected official rug plan, own isolated artwork/contour, closed horizontal textile face/backing, bound edge/fringe, top/side/45 native views inspected. Root owns final actual browser review.'if is_rug else'Source identity, official plan or explicitly estimated axes, own photo donor isolation, form-specific cloth/pile/seam geometry and front/reverse/side/45 native views inspected. Root owns final actual browser review.'
dump(F/'immutable-inputs.json',inputs);manifest=R/('frozen-batch-'+num+'-manifest.json');dump(manifest,out);dump(F/'manifest.json',out);dump(F/'native-visual-review.json',dict(valid=True,models=len(out),scope=visual_scope,known_limitations=['Only dimensions explicitly listed in official_measurements are official; thickness, pile, local seams and hidden pattern phases are photo estimates.','Per-model material resolution and own-donor/pattern operations are recorded without artificial detail claims.','Scene lighting differs from official photography; final browser material appearance requires root review.'],material_policies={e['sku']:e['texture_resolution_policy']for e in out},actual_browser_review_pending=True))
files=[dict(path=str(f.relative_to(F)),bytes=f.stat().st_size,sha256=sha(f))for f in sorted(F.rglob('*'))if f.is_file()and f.name!='FINAL-FROZEN.json'];dump(F/'FINAL-FROZEN.json',dict(status='frozen_for_root_browser_review',models=len(out),manifest=str(manifest),manifest_sha256=sha(manifest),files=files));(manifest.with_suffix('.sha256')).write_text(sha(manifest)+'  '+manifest.name+'\n');print('FROZEN',len(out),sha(manifest),flush=True)
