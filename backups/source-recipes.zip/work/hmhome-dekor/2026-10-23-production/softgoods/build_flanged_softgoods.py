"""Own-source striped flanges and pleated velvet/striped ruffles."""
import sys
sys.dont_write_bytecode=True
import json,re,math
from pathlib import Path
import numpy as np
from PIL import Image,ImageFilter
import build_shaped_softgoods as C
S=C.S;R=C.R;B=C.B;T=math.tau
PIDS=['1331618002','1331618003','1333138002','1333139003','1361695003','1361696003','1374063001','1374063002']

def striped(pid,hero,w,h,wide):
 out=R/'materials'/pid/'own-measured-flange-stripe';out.mkdir(parents=True,exist_ok=True)
 im=Image.open(hero['path']).convert('RGB');bodywidth=1000 if wide else 1070;height=bodywidth*h/w;box=[round(768-bodywidth/2),round(1152-height/2),round(768+bodywidth/2),round(1152+height/2)];crop=im.crop(box);crop.save(out/'donor-crop-native.png');a=np.asarray(crop,float);profile=np.median(a[int(a.shape[0]*.43):int(a.shape[0]*.57)],axis=0)
 # Detect only the photographed stripe frequency and dyed-yarn palette. Broad
 # illumination is detrended; the background and whole photograph are excluded.
 lum=profile.mean(1);window=51;base=np.convolve(np.pad(lum,window//2,mode='edge'),np.ones(window)/window,mode='valid');signal=base-lum;signal-=signal.mean();frequencies=np.fft.rfftfreq(len(signal));power=abs(np.fft.rfft(signal))**2;allowed=(frequencies>9/len(signal))&(frequencies<110/len(signal));frequency=frequencies[np.where(allowed)[0][np.argmax(power[allowed])]];repeat_px=1/frequency;pitch=w*repeat_px/bodywidth;dark=lum<np.quantile(lum,.32);light=lum>np.quantile(lum,.72)
 if pid in ['1331618002','1333138002']:
  chroma=profile[:,0]-profile[:,2];dark=chroma>np.quantile(chroma,.90);light=chroma<np.quantile(chroma,.35);coverage=float(np.mean(chroma>(np.quantile(chroma,.25)+np.quantile(chroma,.95))*.5))
 elif pid in ['1331618003','1333139003']:
  dark=signal>np.quantile(signal,.94);light=signal<np.quantile(signal,.40);coverage=float(np.clip((signal>np.quantile(signal,.96)*.5).mean(),.10,.30))
 else:coverage=float(np.clip((lum<(np.quantile(lum,.2)+np.quantile(lum,.8))/2).mean(),.12,.50))
 ink=np.median(profile[dark],axis=0);ivory=np.median(profile[light],axis=0);n=2048;repeats=16;tile=pitch*repeats;yy,xx=np.mgrid[0:n,0:n];rng=np.random.default_rng(int(pid));phase=(xx/n*repeats)%1;weight=np.asarray(Image.fromarray((phase<coverage).astype(np.uint8)*255).filter(ImageFilter.GaussianBlur(.5)),float)/255;grain=rng.normal(0,.45,(n,n));rgb=ivory[None,None,:]*(1-weight[:,:,None])+ink[None,None,:]*weight[:,:,None]+grain[:,:,None];Image.fromarray(np.clip(rgb,0,255).astype(np.uint8)).save(out/'albedo-2k.png');height0=grain*.004+.10*weight;dy,dx=np.gradient(height0);normal=np.stack([-dx*2,dy*2,np.ones_like(dx)],2);normal/=np.linalg.norm(normal,axis=2,keepdims=True);Image.fromarray(np.rint((normal+1)*127.5).astype(np.uint8)).save(out/'normal-2k.png');orm=np.zeros((n,n,3),np.uint8);orm[:,:,0]=255;orm[:,:,1]=238;Image.fromarray(orm).save(out/'orm-2k.png');C.dump(out/'texture-provenance.json',dict(source_path=hero['path'],source_sha256=hero['sha256'],source_pixels=hero['pixels'],crop_box_original_pixels=box,crop_pixels=list(crop.size),crop_pixel_identical=np.array_equal(np.array(crop),np.asarray(im)[box[1]:box[3],box[0]:box[2]]),operations=['Immutable ownSKU central cloth crop retained','Stripe repeat measured by detrended central-profile frequency; intrinsic two-colour palette from thisSKU only','Regular dyed-yarn stripes reconstructed without photographic folds, background or product silhouette','Fine fibre normal and roughness are procedural photo estimates'],measured_repeat_source_pixels=repeat_px,estimated_repeat_metres=pitch,estimated_dyed_fraction=coverage,palette_rgb=[ivory.tolist(),ink.tolist()],photo_pixels_baked=False,source_master_unchanged=C.sha(hero['path'])==hero['sha256'],source_upscaled=False,full_marketing_photo_wrapped=False))
 return dict(baseColorFactor=[1,1,1,1],metallic=1,roughness=1,baseColorTexture=str(out/'albedo-2k.png'),normalTexture=str(out/'normal-2k.png'),metallicRoughnessTexture=str(out/'orm-2k.png'),normalScale=.55,doubleSided=False,extras=dict(intrinsic_material=True,photo_pixels_baked=False,baked_reflections=False,texture_provenance=str(out/'texture-provenance.json'),atlas_tile_metres=tile,physical_sheen=dict(sheenColorFactor=[.045,.04,.03],sheenRoughnessFactor=.95)))

def flange(w,h,width,tile,wide):
 # A closed thin cloth band: its inner seam attaches continuously to the body,
 # while the outer edge gathers into soft physical pleats. It has no filling.
 N=512;K=13;points=[];normals=[];lengths=[];last=None;distance=0.
 for t in np.linspace(0,4,N,endpoint=False):
  side=int(t);f=t-side
  u,v=[(-1+2*f,-1),(1,-1+2*f),(1-2*f,1),(-1,1-2*f)][side];x,y,z=S.cloth_point(u,v,w,h,.44*h,'canvas');p=np.array([x,y]);normal=np.array([(x/(w/2))**9,((y-h/2)/(h/2))**9]);normal/=np.linalg.norm(normal)
  if last is not None:distance+=float(np.linalg.norm(p-last))
  points.append(p);normals.append(normal);lengths.append(distance);last=p
 perimeter=distance+float(np.linalg.norm(points[0]-points[-1]));waves=round(perimeter/(.030 if wide else .014));vertices=[];uv=[];faces=[]
 for side in [-1,1]:
  for k in range(K):
   r=k/(K-1)
   for j,(p,normal,arc)in enumerate(zip(points,normals,lengths)):
    wave=math.sin(T*waves*arc/perimeter)+.24*math.sin(T*(waves+3)*arc/perimeter+.7);extension=width*r*(1+(.09 if wide else .025)*math.sin(T*7*arc/perimeter));xy=p+normal*extension;z=(.008 if wide else .0024)*wave*math.sin(math.pi*r*.7)+.00038*side;vertices.append((xy[0],xy[1],z));uv.append((arc/tile,r*width/tile))
 layer=N*K
 for side in [0,1]:
  for k in range(K-1):
   for j in range(N):a=side*layer+k*N+j;b=side*layer+k*N+(j+1)%N;c=a+N;d=b+N;faces.extend([(a,b,c),(b,d,c)]if side==0 else[(a,c,b),(b,c,d)])
 for k in [0,K-1]:
  for j in range(N):a=k*N+j;b=k*N+(j+1)%N;faces.extend([(a,a+layer,b),(b,a+layer,b+layer)])
 return B.solid('closed-unfilled-'+('wide-gathered-ruffle'if wide else'narrow-soft-pleated-flange')+'-band','flange',vertices,faces,uv)

def build(pid):
 cap,ep,refs,hero=C.own(pid);m=re.search(r'(\d+(?:[.,]\d+)?)\s*[xX×]\s*(\d+(?:[.,]\d+)?)',cap.get('sizes',''));assert m;short,long=sorted(float(x.replace(',','.'))for x in m.groups());w,h=long/100,short/100;wide=pid.startswith('1374063');velvet=pid.startswith('136169');width=.055 if wide else .018 if velvet else .025
 if velvet:ma=S.material(pid,'flanged-velvet',hero,[520,950,1032,1462],hero,'velvet',w*512/1100)
 else:ma=striped(pid,hero,w,h,wide)
 tile=ma['extras']['atlas_tile_metres'];parts=S.cushion(w,h,.44*h,'velvet'if velvet else'canvas',tile);parts.append(flange(w,h,width,tile,wide));mats=dict(fabric=ma,flange=json.loads(json.dumps(ma)));note=f'Resmî nominal kılıf bedeni{short:g}×{long:g}cm dolgun gövdede korunur; fırfır/bordür her kenarda yaklaşık{width*100:g}cm fotoğraf tahminidir. Gösterilen dış sınırlar bu tahmini kumaş payını içerir. Dolgu derinliği, pile sayısı ve çizgi başlangıcı yorumdur; kılıfın dolgu ile satıldığı iddia edilmez.';C.finish(pid,parts,mats,cap,ep,refs,hero,[None,None,None],dict(cover_size_label=m.group(0),nominal_cover_width_cm=long,nominal_cover_height_cm=short), 'filled_preview_cover_with_unfilled_ruffle',['filling_depth_cm','outer_ruffle_extension_cm','pleat_geometry','fabric_weave_scale','pattern_phase'],note,dict(nominal_body_dimensions_cm=[long,short,.44*short],estimated_ruffle_extension_cm=width*100,estimated_filling_depth_cm=.44*short,quality_label='Desen/kenar yorumu',quality_status='photo_interpreted',quality_note='Kendi ürününün çizgili dokuması ve ayrı ince kumaş kenarı fotoğraftan yorumlandı; resmî beden nominal kılıfa aittir, fırfır dış sınırı tahminidir.'))

if __name__=='__main__':
 for pid in sys.argv[1:]or PIDS:build(pid)
