from pathlib import Path
import json,re,hashlib,collections
R=Path(__file__).resolve().parent
rows=json.loads((R/'joined-softgoods-queue.json').read_text())['products'];models=json.loads((R/'manifest.json').read_text())if(R/'manifest.json').exists()else[];by={m['sku']:m for m in models};frozen={}
for f in R.glob('frozen-batch-*-manifest.json'):
 for m in json.loads(f.read_text()):frozen[m['sku']]=dict(m,frozen_manifest=str(f))
gridfile=next((R/'source-evidence').glob('softgoods-official-grid-size-anchors-*.json'));gridroot=json.loads(gridfile.read_text());grid=gridroot.get('products',gridroot);out=[];block=[]
for relative in ['material-uv-revision-02/manifest.json','pile-revision-01/manifest.json','rug-material-revision-01/manifest.json','surface-form-revision-01/frozen-accepted-four/manifest.json','quilt-pad-revision-03/manifest.json','special-softgoods-revision-02/accepted-hood-02/manifest.json','special-softgoods-revision-03/manifest.json']:
 f=R/relative
 if(f.parent/'FINAL-FROZEN.json').exists():
  for m in json.loads(f.read_text()):frozen[m['sku']]=dict(m,frozen_manifest=str(f))
# Never advertise the rejected original pad simply because its earlier files
# were frozen. Its separate third revision still requires root browser review.
pad=R/'quilt-pad-revision-03/manifest.json'
if pad.exists() and not(pad.parent/'FINAL-FROZEN.json').exists():
 frozen.pop('1348309001',None)
 for m in json.loads(pad.read_text()):by[m['sku']]=m
fur=R/'long-fur-study-02/manifest.json'
if fur.exists():
 for m in json.loads(fur.read_text()):by[m['sku']]=m
rejected_throws=R/'all27-folded-throws-review-manifest.json'
held_throws={e['sku']for e in json.loads(rejected_throws.read_text())}if rejected_throws.exists()else set()
for sku in held_throws:frozen.pop(sku,None)
organic=R/'organic-throws-revision-04/manifest.json'
if organic.exists():
 for m in json.loads(organic.read_text()):
  by[m['sku']]=m;frozen[m['sku']]=dict(m,frozen_manifest=str(organic));held_throws.discard(m['sku'])
fleet=R/'organic-throws-final/manifest.json'
organic_fleet={m['sku']:m for m in json.loads(fleet.read_text())}if fleet.exists()else{}
for sku,m in organic_fleet.items():by[sku]=m
# Exact-SKU acceptance receipts only; never infer acceptance from technical freeze.
accepted_R5_SKUs=set()
for relative in ['organic-r5-accepted-two/manifest.json','knit-r6-accepted-one/manifest.json','knit-gray-r6-accepted-one/manifest.json','organic-r5-family01-accepted-four/manifest.json','organic-r5-later-accepted-three/manifest.json','fringe-brown-r6-accepted-one/manifest.json','source-fibre-seven-r6-accepted/manifest.json','fringe-r6-accepted-final-four/manifest.json','peer-final-three-root-accepted-v2/manifest.json']:
 accepted_R5=R/relative
 if(accepted_R5.parent/'FINAL-FROZEN.json').exists():
  for m in json.loads(accepted_R5.read_text()):
   assert m['actual_browser_review_passed'];frozen[m['sku']]=dict(m,frozen_manifest=str(accepted_R5));accepted_R5_SKUs.add(m['sku']);held_throws.discard(m['sku'])
current_review={}
for f in sorted(list((R/'organic-remaining21-r5').glob('frozen-family-*/manifest.json'))+list((R/'source-fibre-fringe-seven-r6').glob('frozen-family-*/manifest.json'))):
 if(f.parent/'FINAL-FROZEN.json').exists():
  for m in json.loads(f.read_text()):current_review[m['sku']]=dict(m,frozen_manifest=str(f))
for relative in ['knit-gray-r6/manifest.json','fringe-four-r5-revision/manifest.json','fringe-brown-r6-prototype/manifest.json','fringe-own-colours-r6-siblings/manifest.json']:
 f=R/relative
 if(f.parent/'FINAL-FROZEN.json').exists():
  for m in json.loads(f.read_text()):current_review[m['sku']]=dict(m,frozen_manifest=str(f))

held_special=set()
for sku in held_special:frozen.pop(sku,None)
special=R/'special-softgoods-revision-02/manifest.json'
if special.exists():
 for m in json.loads(special.read_text()):by[m['sku']]=m
for e in rows:
 sku=e['sku'];name=e['name'];c=e['category_id'];t=name.upper();form='rug'if c=='rugs'else'throw_or_blanket'if c=='throws'else'bolster'if'BOLSTER'in t else'shaped_stuffed_cushion'if any(v in t for v in['BULUT','AYI ŞEKLİNDE','BASTON ŞEKER'])else'filled_insert'if'İÇ KIRLENT'in t else'seat_pad_or_set_needs_photo_classification'if'MİNDER'in t else'upright_cover_pile'if any(v in t for v in['TÜYLÜ','PELÜŞ'])else'upright_cover';p=R/'source-evidence'/(sku+'.json');cap=json.loads(p.read_text())if p.exists()else{};valid=bool(cap.get('sku')==sku and cap.get('url')==e['url']and sku in cap.get('description',''));anchor=bool(valid and(re.search(r'\d+(?:[.,]\d+)?\s*[Xx×]\s*\d',cap.get('sizes',''))or re.search(r'\d+(?:[.,]\d+)?\s*cm',cap.get('description',''))));m=frozen.get(sku)or by.get(sku);status='ready_with_interpretations'if sku in frozen else'quality_review'if m else'pending_geometry'if anchor else'pending_source_or_measurement';entry=dict(sku=sku,name=name,category_id=c,form_classification_provisional=form,form_requires_own_photo_review=True,status=status,official_source_capture_verified=valid,official_dimensions_unresolved=not anchor,photo_estimated_scale_allowed=True,physical_anchor_available=anchor,source_url=e['url'],source_evidence_file=str(p)if p.exists()else None,source_size_text=cap.get('sizes',''),model_id=m['id']if m else None,frozen_manifest=m.get('frozen_manifest')if m else None);out.append(entry)
 item=grid.get(sku);cached=R/'cached-pdp'/(sku+'.json');cache=json.loads(cached.read_text())if cached.exists()else{};material=bool(valid and cap.get('materials'))or bool(cache.get('identity_verified')and cache.get('material_composition_verified'));gridanchor=bool(item and item.get('anchors'));anchor=bool(anchor or gridanchor or(valid and re.search(r'(?:BEDEN:\s*|^)D\s*\d+(?:[.,]\d+)?',cap.get('sizes',''),re.I)));entry.update(physical_anchor_available=anchor,official_dimensions_unresolved=not anchor,material_composition_unresolved=not material,material_composition_available=material,grid_size_anchors=item['anchors']if gridanchor else[],grid_evidence_file=str(gridfile)if gridanchor else None,cached_official_pdp_evidence=str(cached)if cached.exists()else None)
 if sku in held_throws:entry.update(status='pending_organic_form_revision',root_actual_rejection='Original frozen16–18 stood like rigid books/cards; own fibre surface and loose fringe were insufficient. Only two horizontal four-layer prototypes requested before rollout.')
 if sku in organic_fleet and sku not in accepted_R5_SKUs:
  candidate=organic_fleet[sku];entry.update(status='held_for_source_quality_revision',model_id=candidate['id'],frozen_manifest=next((str(f)for f in (R/'organic-throws-final').glob('frozen-family-*/manifest.json')if(f.parent/'FINAL-FROZEN.json').exists()and sku in{x['sku']for x in json.loads(f.read_text())}),None),current_revision_manifest=str(fleet),glb_path=candidate['glb_path'],sha256=candidate['sha256'],actual_browser_approval=False,root_actual_rejection='Parent actual final25 review held all25: broad surfaces and layer edges still read rigid; source-specific linen weave, knitted diamond yarn and plush quilt channels require bounded prototypes before rollout.',root_actual_review_failed=True,root_actual_review_evidence=str(R/'organic-final25-review/browser-review'))
 if sku in current_review and sku not in accepted_R5_SKUs:
  candidate=current_review[sku];entry.update(status='ready_for_root_actual_review',model_id=candidate['id'],frozen_manifest=candidate['frozen_manifest'],current_revision_manifest=candidate['frozen_manifest'],glb_path=candidate['glb_path'],sha256=candidate['sha256'],actual_browser_approval=False,root_actual_review_failed=False)
  entry.pop('root_actual_rejection',None)
 if sku in {'1338618002','1338618003','1338618004','1338618006'} and not (R/'fringe-four-r5-revision/FINAL-FROZEN.json').exists():
  entry.update(status='pending_fringe_only_revision',root_actual_review_failed=True,root_actual_rejection='Root actual comparison held the thin parallel wire fringe; R5 body and own materials are retained for a separate 2–4mm twisted loose-bundle correction.')
 if sku in {'1338619002','1338615001','1348754001','1348754005','1348754007','1298464008','1348917001'} and sku not in accepted_R5_SKUs:
  entry.update(status='pending_own_fibre_or_fringe_revision',root_actual_review_failed=True,root_actual_rejection='Root actual close comparison requires own melange/fibre visibility and soft full twisted fringe; R5 cloth body remains approved.',root_actual_review_evidence=str(R/'remaining13-r5-close-review/browser-review'))
 if sku in {'1355345001','1357963001','1355863002'} and sku not in accepted_R5_SKUs:
  entry.update(status='pending_peer_pile_revision',root_actual_review_failed=True,root_actual_rejection='Root delegated own long/curly/short plush surface corrections to hm_scope_audit. This agent does not edit these three assets.',root_actual_review_evidence=str(R/'remaining13-r5-close-review/browser-review'))
 if sku in {'1338618002','1338618004','1338618006'} and sku not in accepted_R5_SKUs:
  entry.update(status='pending_own_sibling_fringe_review',root_actual_review_failed=True,root_actual_rejection='First 2–4mm revision still read thin in actual browser. Only brown1338618003 next5–7mm fuzzy own-melange prototype is allowed before sibling rollout.',root_actual_review_evidence=str(R/'fringe4-r5-actual-review/browser-review'))
 if sku in held_special:entry.update(status='pending_connected_hood_or_directional_fur_review',root_actual_rejection='Original frozen19 had a detached helmet-like hood, gray wire-like fur and a bare flat end. Separate connected cloth and rounded-core directional-lock prototypes await review.')
 if not m:entry['status']='pending_geometry'if anchor else'pending_geometry_photo_estimated_scale'
 if not anchor or not material:block.append(dict(sku=sku,name=name,status=entry['status'],reason='ExactSKU resmî ölçü kanıtı henüz bağlanmadı.'if not anchor else'ExactSKU resmî ölçü ve özgün fotoğraf var; malzeme bileşimi/ürün ayrıntısı henüz doğrulanmadı.',url=e['url']))
(R/'production-status.json').write_text(json.dumps(dict(scope_count=len(rows),counts=dict(collections.Counter(e['status']for e in out)),products=out),ensure_ascii=False,indent=2)+'\n');(R/'source-blockers.json').write_text(json.dumps(block,ensure_ascii=False,indent=2)+'\n');print(collections.Counter(e['status']for e in out))
