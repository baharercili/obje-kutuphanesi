"""Five root-caught surface/form defects, separate from immutable batch10."""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
import math,json,shutil
import numpy as np
from PIL import Image,ImageDraw,ImageFilter
import build_shaped_softgoods as C
S=C.S;B=C.B;BASE=C.R;V=BASE/'surface-form-revision-01';T=math.tau
IDS=['1339053001','1363057003','1363057004','1355322001','1348309001']

def raw(mesh):
 return B.solid(mesh['name'],mesh['material'],np.asarray(mesh['positions']).reshape(-1,3).tolist(),np.asarray(mesh['indices']).reshape(-1,3).tolist(),np.asarray(mesh['uvs']).reshape(-1,2).tolist())

def mapped_point(model):
 w,h,d=np.array(model['metadata']['dimensions_cm'])/100;front=next((m for m in model['meshes']if'front-beige'in m['name']),None)
 if front:
  back=next(m for m in model['meshes']if'reverse-ivory'in m['name']);grids={1:np.asarray(front['positions']).reshape(-1,3)[6561:13122].reshape(81,81,3),-1:np.asarray(back['positions']).reshape(-1,3)[6561:13122].reshape(81,81,3)}
 else:
  main=np.asarray(model['meshes'][0]['positions']).reshape(-1,3);grids={-1:main[:6561].reshape(81,81,3),1:main[6561:13122].reshape(81,81,3)}
 def point(u,v,side):
  x,y=np.clip([u*80,v*80],0,80-1e-7);i,j=int(x),int(y);a,b=x-i,y-j;q=grids[side];return q[j,i]*(1-a)*(1-b)+q[j,i+1]*a*(1-b)+q[j+1,i]*(1-a)*b+q[j+1,i+1]*a*b
 return point,w,h,d

def relief_material(pid,name,old,folder,w):
 ma=json.loads(json.dumps(old));out=V/'materials'/pid/name;out.mkdir(parents=True,exist_ok=True)
 for slot in ['baseColorTexture','normalTexture','metallicRoughnessTexture']:ma[slot]=str(folder/ma[slot])
 n=2048;rng=np.random.default_rng(int(pid));height=Image.new('L',(n,n),128);draw=ImageDraw.Draw(height);pitch=.0022 if pid=='1339053001'else .0020 if pid.startswith('1363057')else .0012;count=round((w/pitch)**2*.60)
 for _ in range(count):
  x,y=rng.uniform(0,n,2);radius=rng.uniform(.55,.95)*pitch*.5*n/w;angle=rng.uniform(0,T);points=[(x+radius*math.cos(angle+t),y+radius*.75*math.sin(angle+t))for t in np.linspace(0,math.pi*1.75,10)];draw.line(points,fill=int(rng.uniform(175,245)),width=max(1,round(.00038*n/w)),joint='curve')
 field=np.asarray(height.filter(ImageFilter.GaussianBlur(.55)),float)/255
 if pid=='1348309001':
  yy,xx=np.mgrid[0:n,0:n];field=.5+.03*np.sin(T*xx/3.2)*np.cos(T*yy/3.7)+rng.normal(0,.006,(n,n))
 dy,dx=np.gradient(field*5.0);normal=np.stack([-dx,dy,np.ones_like(dx)],2);normal/=np.linalg.norm(normal,axis=2,keepdims=True);Image.fromarray(np.rint((normal+1)*127.5).astype(np.uint8)).save(out/'normal-2k.png');orm=np.zeros((n,n,3),np.uint8);orm[:,:,0]=255;orm[:,:,1]=np.clip(244-(field-.5)*22,218,250);Image.fromarray(orm).save(out/'orm-2k.png');oldprov=Path(old['extras']['texture_provenance']);prov=json.loads(oldprov.read_text());prov.update(previous_texture_provenance=str(oldprov),operations=prov.get('operations',[])+['Separate root-caught surface revision: approved ownSKU albedo PNG copied byte-for-byte','Fine cotton/linen warp-weft normal, not fleece, on the seat pads'if pid=='1348309001'else'Dense source-informed curled loop/fibre normal at explicitly estimated physical scale; no palette quantization or invented photograph detail','Physical body-attached closed fibre loops or quilting knots and visible perimeter stitching are separate geometry'],estimated_loop_pitch_mm=pitch*1000 if pid!='1348309001'else None,approved_albedo_sha256=C.sha(ma['baseColorTexture']),source_master_unchanged=True);C.dump(out/'texture-provenance.json',prov);ma.update(normalTexture=str(out/'normal-2k.png'),metallicRoughnessTexture=str(out/'orm-2k.png'),normalScale=.65 if pid=='1348309001'else 1.1);ma['extras'].update(texture_provenance=str(out/'texture-provenance.json'),physical_sheen=dict(sheenColorFactor=[.055,.045,.035]if pid=='1348309001'else[.19,.17,.14]if pid!='1355322001'else[.28,.28,.26],sheenRoughnessFactor=.95));return ma

def physical_loops(pid,point,w,h):
 rng=np.random.default_rng(int(pid));by={1:[],-1:[]};count=6000 if pid!='1355322001'else 7200;length=.0032 if pid=='1339053001'else .0025 if pid.startswith('1363057')else .0040
 for j in range(count):
  u,v=rng.uniform(.002,.998,2);side=1 if j%2 else-1;p=point(u,v,side);dx=point(min(.9999,u+.0005),v,side)-point(max(.0001,u-.0005),v,side);dy=point(u,min(.9999,v+.0005),side)-point(u,max(.0001,v-.0005),side);normal=np.cross(dx,dy)
  if normal[2]*side<0:normal=-normal
  normal/=np.linalg.norm(normal);tang=dx/np.linalg.norm(dx);ang=rng.uniform(0,T);tang=tang*math.cos(ang)+np.cross(normal,tang)*math.sin(ang);l=length*rng.uniform(.70,1.30)
  if pid=='1339053001':pts=[p+normal*l*.5*(1-math.cos(a))+tang*l*.5*math.sin(a)for a in np.linspace(0,T,9,endpoint=False)];closed=True
  else:pts=[p-normal*.00012]+[p+normal*l*.8*math.sin(math.pi*f*.8)+tang*l*.6*f for f in[.2,.4,.6,.8,1.]];closed=False
  material='fabric'if side==1 or pid=='1355322001'else'reverse';q=B.tube('closed-visible-own-colour-fibre-loop',material,[tuple(x)for x in pts],.00034 if pid=='1339053001'else .00027,.00022 if pid=='1339053001'else .00018,4,closed,guide=tang.tolist());q['_uvs']=[(.5+x/w,1-y/h)for x,y,z in q['_vertices']];by[side].append(q)
 # Actual soft perimeter tufts prevent a mathematically sharp outer contour.
 for j in range(1000):
  side=1 if j%2 else-1;edge=j%4;f=rng.uniform(.002,.998);u,v=[(.001,f),(.999,f),(f,.001),(f,.999)][edge];p=point(u,v,side);normal=np.array([(-1 if edge==0 else 1)if edge<2 else 0,(-1 if edge==2 else 1)if edge>=2 else 0,0]);l=length*rng.uniform(.65,1.0);pts=[p-normal*.00015,p+normal*l*.7+[0,0,l*.25],p+normal*l+[0,0,l*.05]];material='fabric'if side==1 or pid=='1355322001'else'reverse';q=B.tube('closed-soft-boundary-fibre',material,[tuple(x)for x in pts],.00030,.00018,4,False,guide=[0,0,1]);q['_uvs']=[(.5+x/w,1-y/h)for x,y,z in q['_vertices']];by[side].append(q)
 return [S.merge(p,'physical-visible-loop-pile-'+str(side),'fabric'if side==1 or pid=='1355322001'else'reverse')for side,p in by.items()]

def blanket_stitches(point,w,h):
 stitches=[]
 for edge in range(4):
  for f in np.arange(.015,.99,.012):
   u,v=[(.025,f),(.975,f),(f,.025),(f,.975)][edge];a=point(u,v,1);b=point(u,v,-1);ue,ve=[(0,f),(1,f),(f,0),(f,1)][edge];outer=(point(ue,ve,1)+point(ue,ve,-1))/2;out=np.array([(-1 if edge==0 else 1)if edge<2 else 0,(-1 if edge==2 else 1)if edge>=2 else 0,0])*.0007;pts=[a+[0,0,.00055],outer+out,b-[0,0,.00055]];stitches.append(B.tube('surface-following-visible-blanket-edge-loop','reverse',[tuple(x)for x in pts],.00062,.00048,5,False,guide=[0,1,0]if edge<2 else[1,0,0]))
 return S.merge(stitches,'all-four-edges-physically-wrapped-blanket-stitches','reverse')

def puffy_pad(u,v):
 x=.19*u*(1-.020*(1-v*v));y=.19+.19*v*(1-.020*(1-u*u));env=max(0,(1-abs(u)**8)*(1-abs(v)**8))**.27;z=.0011+.0189*env
 # Continuous stuffing with shallow sewn channels, rather than sixteen
 # disconnected, flat-edged inflated tiles. The nine knots remain real dips.
 channel=min(abs(u-a)for a in[-.5,0,.5]);channel=min(channel,min(abs(v-b)for b in[-.5,0,.5]));z-=.0013*env*math.exp(-(channel/.055)**2)
 for a in[-.5,0,.5]:
  for b in[-.5,0,.5]:z-=.0105*math.exp(-((u-a)**2+(v-b)**2)/.0075)
 return x,y,max(.0012,z)

def main():
 assert not(V/'FINAL-FROZEN.json').exists();V.mkdir(exist_ok=True);shutil.copyfile(BASE/'joined-softgoods-queue.json',V/'joined-softgoods-queue.json');old={e['sku']:e for e in json.loads((BASE/'frozen-batch-10-manifest.json').read_text())};targets=sys.argv[1:]or IDS;data={pid:C.own(pid)for pid in targets};C.R=V;S.R=V
 if not(V/'manifest.json').exists():C.dump(V/'manifest.json',[])
 proof=json.loads((V/'preservation.json').read_text())['models']if(V/'preservation.json').exists()else[]
 for pid in targets:
  e=old[pid];model=json.loads(Path(e['model_path']).read_text());cap,ep,refs,hero=data[pid];oldfolder=Path(e['asset_dir']);mats={name:relief_material(pid,name,ma,oldfolder,.5 if pid!='1348309001'else .38)for name,ma in model['materials'].items()};w,h,d=np.array(e['dimensions_cm'])/100
  if pid=='1348309001':
   C.pad_point=puffy_pad;parts=[p for p in C.quilted_pads()if'knots'not in p['name']]
   for p in parts:p['name']=p['name'].replace('four-knot','nine-knot-soft-puffy')
   threads=[];maximum=max(puffy_pad(float(u),float(v))[2]for u in np.linspace(-1,1,81)for v in np.linspace(-1,1,81));zscale=.02/maximum
   for piece in[-1,1]:
    for side in[-1,1]:
     for u in[-.5,0,.5]:
      for v in[-.5,0,.5]:
       for axis in[0,1]:
        pts=[]
        for f in[-.018,0,.018]:
         x,y,z=puffy_pad(u+(f if axis==0 else 0),v+(f if axis else 0));pts.append((x+piece*.205,y,side*(z*zscale+.0003)))
        q=B.tube('fine-sewn-cross-thread-in-quilting-dimple','fabric',pts,.00020,.00017,4,False,guide=[0,0,1]);q['_uvs']=[((x-piece*.205)/.38+.5,1-y/.38)for x,y,z in q['_vertices']];threads.append(q)
   parts.append(S.merge(threads,'physical-nine-soft-sewn-knots-on-each-real-pad','fabric'))
   target=[.79,.38,.04];form=e['product_form'];extra=dict(quantity=2,per_item_dimensions_cm=[38,38,4],display_arrangement_estimated=True,official_per_item_thickness_cm=4)
  else:
   point,w,h,d=mapped_point(model);parts=[raw(m)for m in model['meshes']if not any(x in m['name']for x in['wool-loop-surface','four-edge-blanket-stitch','visible-curled-fleece'])];parts+=physical_loops(pid,point,w,h)
   if pid.startswith('1363057'):parts.append(blanket_stitches(point,w,h))
   target=[w,h,d];form=e['product_form'];extra=dict(estimated_filling_depth_cm=d*100)
  note=e['scale_note']+' Ayrı yüzey/form revizyonunda resmî plan korundu. Kendi onaylı desen/albedo pikselleri aynı; ilmek/hav ölçeği, kenarı gerçekten saran dikiş ve yerel kapitone çukuru fotoğraf tahminidir.';extra.update(id=e['id'],previous_glb_sha256=e['sha256'],replaces_frozen_manifest=str(BASE/'frozen-batch-10-manifest.json'),quality_label='Yaklaşık ilmek/hav yorumu'if pid!='1348309001'else'Kapitone dolgu yorumu',quality_status='preview_limited'if pid!='1348309001'else'photo_interpreted',quality_note='Desen kendi ürüne aittir. Fiziksel ilmek/hav yoğunluğu ve yerel dikiş kabartısı fotoğraftan yorumlandı.'if pid!='1348309001'else'Her minderin resmî38×38×4cm sınırı korunur. Yumuşak hücre şişkinliği ve düğüm çukurlarının yerel biçimi fotoğraf yorumudur.',revision_reason='Root actual Three.js09/10 caught insufficient loop/pile/stitch/quilt readability.');entry=C.finish(pid,parts,mats,cap,ep,refs,hero,target,e['official_measurements'],form,['pile_loop_scale_and_density','local_stitching_and_quilt_profile'],note,extra);newmodel=json.loads(Path(entry['model_path']).read_text());kept=[]
  for name,ma in model['materials'].items():
   a=oldfolder/ma['baseColorTexture'];b=Path(entry['asset_dir'])/newmodel['materials'][name]['baseColorTexture'];assert C.sha(a)==C.sha(b);kept.append(dict(material=name,albedo_sha256=C.sha(a),byte_identical=True))
  proof=[x for x in proof if x['sku']!=pid];proof.append(dict(sku=pid,id=e['id'],previous_glb_sha256=e['sha256'],revision_glb_sha256=entry['sha256'],official_plan_preserved=True,own_approved_albedos=kept,original_JPEGs_unchanged=all(C.sha(x['path'])==x['sha256']for x in refs)))
 C.dump(V/'preservation.json',dict(valid=True,models=proof))

if __name__=='__main__':main()
