"""A separate material revision; every geometry/accessor byte stays frozen."""
from pathlib import Path
import json,hashlib,sys,shutil,io
import numpy as np
from PIL import Image,ImageFilter
sys.dont_write_bytecode=True
import build_softgoods as B
R=Path(__file__).resolve().parent;F=R/'material-uv-revision-02'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def accessor_bytes(doc,blob):
 out=[]
 for a in doc['accessors']:
  view=doc['bufferViews'][a['bufferView']];raw=blob[view.get('byteOffset',0):view.get('byteOffset',0)+view['byteLength']]
  out.append(dict(accessor=a,view=view,sha256=hashlib.sha256(raw).hexdigest()))
 return out
def create():
 assert not(F/'FINAL-FROZEN.json').exists();F.mkdir(exist_ok=True)
 old=json.loads((R/'frozen-batch-01-manifest.json').read_text());masters=json.loads((R/'original-image-masters.json').read_text());out=[];proof=[]
 for e in old:
  sku=e['sku']
  if sku not in ['1207164004','1207264009']:continue
  folder=F/'models'/e['id'];folder.mkdir(parents=True,exist_ok=True);model=json.loads(Path(e['model_path']).read_text());doc,blob=B.read_glb(e['glb_path']);before=accessor_bytes(doc,blob);source_dir=Path(e['asset_dir'])
  for name in ['geometry-validation.json']:shutil.copyfile(source_dir/name,folder/name)
  suffix='5c8ecd78fb57'if sku=='1207164004'else'ac0f2eaa2fa3';master=next(x for x in masters if x['sku']==sku and suffix in x['path']);photo=Image.open(master['path']).convert('RGB');box=[800,1900,1056,2156];patch=photo.crop(box);patch.save(folder/'donor-crop-native.png');a=np.asarray(patch,np.float32)/255.;low=np.asarray(patch.filter(ImageFilter.GaussianBlur(5.0)),np.float32)/255.;oldprov=json.loads((source_dir/'texture-provenance.json').read_text());target=np.array(oldprov['target_rgb'])/255
  # This uniformly focused region is band-limited before sampling. Its thread pitch
  # is 18--22 native pixels: after one 2:1 downsample, the unchanged 0.1m atlas
  # gives 0.44--0.54mm yarn spacing. This is an estimate from the SKU's macro
  # and full cover photographs, not a manufacturer yarn-count specification.
  a=np.clip(target+(a-low)*.95,0,1);clean=Image.fromarray(np.rint(a*255).astype(np.uint8)).resize((128,128),Image.Resampling.LANCZOS);a=np.asarray(clean,np.float32)/255.;edge=8
  for axis in [0,1]:
   for j in range(edge):
    weight=(1-j/edge)**2;left=[slice(None)]*3;right=[slice(None)]*3;left[axis]=j;right[axis]=-1-j;left=tuple(left);right=tuple(right);mean=(a[left]+a[right])/2;a[left]=a[left]*(1-weight)+mean*weight;a[right]=a[right]*(1-weight)+mean*weight
  tile=np.rint(a*255).astype(np.uint8);Image.fromarray(tile).save(folder/'intrinsic-native128.png');indices=np.arange(2048)%128;atlas=tile[indices[:,None],indices[None,:]];Image.fromarray(atlas).save(folder/'fabric-albedo-2k.png');height=atlas.mean(2).astype(float)/255;dy,dx=np.gradient(height*10.0);normal=np.stack([-dx,dy,np.ones_like(dx)],2);normal/=np.linalg.norm(normal,axis=2,keepdims=True);Image.fromarray(np.rint((normal+1)*127.5).astype(np.uint8)).save(folder/'fabric-normal-2k.png');orm=np.zeros_like(atlas);orm[:,:,0]=255;orm[:,:,1]=np.clip(230+(height-height.mean())*160,210,252).astype(np.uint8);Image.fromarray(orm).save(folder/'fabric-orm-2k.png')
  prov=dict(source_path=master['path'],source_sha256=master['sha256'],source_pixels=master['pixels'],crop_box_original_pixels=box,crop_pixels=[256,256],crop_pixel_identical=np.array_equal(np.array(patch),np.array(photo)[1900:2156,800:1056]),operations=['Native integer crop from the same exact SKU immutable original; uniformly focused weave region','Subtract Gaussian sigma5px local illumination, retain only fine dyed yarn residual at95% contrast','One antialiased2:1 downsample256→128; no invented detail or upscale','8px edge-only repeat seam blend','Repeat native128px residual16×16 into2048 atlas; original UVs untouched','Restrained normal/constant nonmetallic roughness inferred from same fine yarn residual'],source_master_unchanged=sha(master['path'])==master['sha256'],generation=False,source_upscaled=False,unique_source_detail_resolution=[128,128],atlas_resolution=[2048,2048],atlas_metres=.1,source_thread_pitch_native_pixels_estimated=[18,22],estimated_thread_pitch_mm=[.439453125,.537109375],physical_scale_evidence='SameSKU macro shows18–22px yarn intervals in this flatter crop. SameSKU official40×60/60×60 full cover photographs show fine plain weave, without a diagonal macro-check design. Yarn spacing is photo-estimated, not an official measurement.',geometry_changed=False,uv_changed=False,previous_revision_glb_sha256=e['sha256'])
  dump(folder/'texture-provenance.json',prov);meta=model['metadata'];meta.update(texture_resolution_policy='Own256px flat donor antialiased once to128px, native periodic2K atlas. Estimated0.44–0.54mm yarn spacing; original geometry/UV preserved.',material_revision='hmhome-khaki-micro-weave-2026-10-23-r2');meta['scale_note']=meta['scale_note'].split('Kendi512px')[0]+' Kendi SKU’sunun düz256px kumaş donoru bir kez128px’e küçültülüp2K atlasta tekrarlandı; yaklaşık0,44–0,54mm iplik aralığı ve PBR normal/roughness fotoğraf yorumudur.';meta['source_evidence_files']=meta['source_evidence_files']+[str(folder/'texture-provenance.json')]
  material=model['materials']['fabric'];material['normalScale']=.75;material['extras'].update(unique_source_detail_resolution=[128,128],texture_provenance=str(folder/'texture-provenance.json'));dump(folder/'model.json',model);doc['extras']['metadata']=meta;doc['materials'][0]['normalTexture']['scale']=.75
  newblob=bytearray(blob)
  for im in doc['images']:
   data=(folder/im['name']).read_bytes();newblob.extend(b'\0'*((-len(newblob))%4));off=len(newblob);newblob.extend(data);doc['bufferViews'][im['bufferView']]=dict(buffer=0,byteOffset=off,byteLength=len(data))
  doc['buffers'][0]['byteLength']=len(newblob);gp=folder/(e['id']+'.glb');B.write_glb(gp,doc,bytes(newblob));afterdoc,afterblob=B.read_glb(gp);after=accessor_bytes(afterdoc,afterblob);assert before==after;assert model['meshes']==json.loads(Path(e['model_path']).read_text())['meshes'];assert sha(master['path'])==master['sha256']
  maps=[dict(slot=k,path=str(folder/material[k]),pixels=list(Image.open(folder/material[k]).size),sha256=sha(folder/material[k]))for k in['baseColorTexture','normalTexture','metallicRoughnessTexture']];dump(folder/'material-validation.json',dict(valid=True,maps=maps,source_masters_unchanged=True,no_source_photo_upscale=True,texture_provenance=str(folder/'texture-provenance.json')));record=dict(sku=sku,id=e['id'],previous_glb_sha256=e['sha256'],revision_glb_sha256=sha(gp),accessors_identical=before==after,all_mesh_attributes_indices_identical=True,model_meshes_identical=True,accessors=before);dump(folder/'binary-preservation.json',record);proof.append(record)
  q=dict(e);q.update(model_path=str(folder/'model.json'),asset_dir=str(folder),glb_path=str(gp),sha256=sha(gp),bytes=gp.stat().st_size,geometry_validation=str(folder/'geometry-validation.json'),material_validation=str(folder/'material-validation.json'),scale_note=meta['scale_note'],texture_resolution_policy=meta['texture_resolution_policy'],source_evidence_files=meta['source_evidence_files'],model_revision='hmhome-khaki-micro-weave-2026-10-23-r2',previous_glb_sha256=e['sha256'],native_renders={},frozen=False,model_status='ready_for_browser_review');out.append(q)
 dump(F/'manifest.json',out);dump(F/'binary-preservation.json',dict(valid=True,models=proof));print('REVISED',len(out),flush=True)
if __name__=='__main__':create()
