from pathlib import Path
import json,hashlib,urllib.request,io,concurrent.futures,shutil,re
from PIL import Image
R=Path(__file__).resolve().parent;H=R.parents[1];sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,d):Path(p).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
(R/'originals').mkdir(exist_ok=True);(R/'source-evidence').mkdir(exist_ok=True);rows=json.loads((R/'joined-softgoods-queue.json').read_text())['products'];images=[];sources=[]
for e in rows:
 cap=R/'source-evidence'/(e['sku']+'.json');q=None
 if not cap.exists():cap=H/'2026-10-21/pdp-observed'/(e['sku']+'.json')
 if cap.exists():
  c=json.loads(cap.read_text())
  if c.get('identity_verified')is not False and c.get('sku')==e['sku']and c.get('url')==e['url']and(c.get('identity_verified')is True or re.search(r'(?:Ürün No\.|Art\. No\.)\s*:\s*'+e['sku'],c.get('description',''))):
   dst=R/'source-evidence'/(e['sku']+'-'+sha(cap)[:12]+'.json')
   if not dst.exists():shutil.copyfile(cap,dst)
   q=c;sources.append(dict(sku=e['sku'],path=str(dst),sha256=sha(dst),capture=c))
 refs=((q.get('photos')or q.get('images')or[])if q else[])+e['reference_images'];seen=set()
 for im in refs:
  candidates=[(0,im['url'])]if im.get('url','').startswith('https://image.hm.com/')else[]
  for v in im.get('srcset','').split(','):
   p=v.strip().split()
   if len(p)==2 and p[0].startswith('https://image.hm.com/'):candidates.append((int(p[1].rstrip('w')),p[0]))
  if not candidates:continue
  _,url=max(candidates)
  if url in seen:continue
  seen.add(url);images.append(dict(sku=e['sku'],url=url,alt=im.get('alt',''),evidence_file=str(R/'joined-softgoods-queue.json')if not q else str(dst),kind='observed_official_pdp'if q else'observed_official_category'))
images+=json.loads((R/'extra-observed-images.json').read_text())if(R/'extra-observed-images.json').exists()else[]
masters=json.loads((R/'original-image-masters.json').read_text())if(R/'original-image-masters.json').exists()else[];old={(r['sku'],r['url']):r for r in masters};errors=[]
def fetch(r):
 p=R/'originals'/(r['sku']+'-'+hashlib.sha256(r['url'].encode()).hexdigest()[:12]+'.jpg')
 if not p.exists():
  b=urllib.request.urlopen(r['url'],timeout=40).read();Image.open(io.BytesIO(b)).verify();p.write_bytes(b)
 im=Image.open(p);return dict(r,path=str(p),sha256=sha(p),pixels=list(im.size),format=im.format,mode=im.mode,icc_profile_present=bool(im.info.get('icc_profile')),exif_orientation=im.getexif().get(274),original_bytes_unmodified=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=6)as pool:
 jobs={pool.submit(fetch,r):r for r in images}
 for f in concurrent.futures.as_completed(jobs):
  r=jobs[f]
  try:
   m=f.result();key=(m['sku'],m['url']);assert key not in old or old[key]['sha256']==m['sha256'];old[key]=m
  except Exception as e:errors.append(dict(sku=r['sku'],url=r['url'],error=str(e)))
masters=list(old.values());dump(R/'original-image-masters.json',masters);dump(R/'photo-errors.json',errors);dump(R/'pdp-source-inventory.json',sources);print('sources',len(sources),'masters',len(masters),'errors',len(errors),flush=True)
