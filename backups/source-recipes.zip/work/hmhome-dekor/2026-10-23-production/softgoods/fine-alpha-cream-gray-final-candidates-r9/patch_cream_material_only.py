"""Root-requested physical PBR-only cream patch; immutable R8 BIN untouched."""
from pathlib import Path
import copy, hashlib, json, subprocess, sys
import numpy as np
sys.dont_write_bytecode=True
D=Path(__file__).resolve().parent
T=D.parent.parent/'textiles'
sys.path.insert(0,str(T))
from freeze_polar_knit_review_candidates import glb,sha,dump
from clean_remaining_robe_material_revision02 import write_glb
import specific_binary_native_material as V

SOURCE=D.parent/'cream-curved-haircards-prototype-r8/frozen-own-ivory-fine-curved-alpha-haircard-prototype-01-manifest.json'
SOURCE_SHA='6f415625ab88ae334085c3d40bc78daa93d132cb37724f5fab8f8d6238f42dcd'
OUTPUT=D/'frozen-own-cream-material-only-alpha-haircard-candidate-01-manifest.json'

def attr(doc,binary,i):
 a=doc['accessors'][i];v=doc['bufferViews'][a['bufferView']]
 dtype={5120:'i1',5121:'u1',5122:'<i2',5123:'<u2',5125:'<u4',5126:'<f4'}[a['componentType']]
 count={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}[a['type']];size=np.dtype(dtype).itemsize
 values=np.ndarray((a['count'],count),dtype=dtype,buffer=binary,offset=v.get('byteOffset',0)+a.get('byteOffset',0),strides=(v.get('byteStride',size*count),size)).copy()
 return hashlib.sha256(values.tobytes()).hexdigest()

def build():
 assert not OUTPUT.exists() and sha(SOURCE)==SOURCE_SHA
 old=json.loads(SOURCE.read_text())[0]
 assert old['sku']=='1357963001' and sha(old['glb_path'])==old['sha256']
 asset=D/'models-validated-02'/old['id'];assert not asset.exists();asset.parent.mkdir(exist_ok=True)
 subprocess.run(['/usr/bin/ditto','--clone',old['asset_dir'],str(asset)],check=True)
 od,ob=glb(old['glb_path']);d=copy.deepcopy(od)
 candidates=[i for i,m in enumerate(d['materials']) if m.get('name')=='own-ivory-fine-curved-alpha-fibres']
 assert len(candidates)==1
 mi=candidates[0];m=d['materials'][mi];before=copy.deepcopy(m)
 m['normalTexture']['scale']=.20
 m['pbrMetallicRoughness']['baseColorFactor']=[1,.98,.94,1]
 m['extensions']['KHR_materials_sheen'].update(sheenColorFactor=[.65,.58,.48],sheenRoughnessFactor=.85)
 assert m['alphaMode']=='MASK' and m['alphaCutoff']==.32 and m['doubleSided']
 # No texture, geometry, alpha, roughness, lighting, or original body change.
 comparison=copy.deepcopy(od);comparison['materials'][mi]=copy.deepcopy(m)
 assert comparison==d
 for field in ('nodes','meshes','accessors','bufferViews','images','textures','samplers','scenes'):
  assert d[field]==od[field]
 meta=d['extras']['metadata']
 meta['model_revision']='own-cream-fine-alpha-haircards-warm-physical-PBR-R9'
 meta['quality_label']='Sıcak krem ince kıvırcık lifler · Yumuşak dört kat · Yaklaşık ölçek'
 note=(' Kaynak fotoğrafa göre lif PBR yüzeyi son kez ayarlandı: normal şiddeti 0,20; '
       'fiziksel sheen 0,65/0,58/0,48 ve roughness 0,85. Own lineer COLOR_0 ana pigmenttir; '
       '1/0,98/0,94 küçük sıcaklık faktörü fotoğrafa dayalı malzeme yorumudur. '
       'Işık, stüdyo gölgesi, emisyon veya unlit malzeme kullanılmadı.')
 meta['quality_note']+=note
 meta['source_evidence_files']=meta['source_evidence_files']+[str(SOURCE),str(asset/'R8-BIN-and-RGB-preservation-PBR-only-proof.json')]
 target=asset/Path(old['glb_path']).name
 write_glb(target,d,ob)
 nd,nb=glb(target);assert nb==ob
 # Independently prove geometry and embedded-image byte identity.
 unchanged=[]
 for mesh in od['meshes']:
  for prim in mesh['primitives']:
   for label,i in {**prim['attributes'],'indices':prim['indices']}.items():
    assert attr(od,ob,i)==attr(nd,nb,i)
    unchanged.append(dict(mesh=mesh['name'],attribute=label,sha256=attr(nd,nb,i)))
 original_images=[]
 for im in old['original_images']:
  assert sha(im['path'])==im['sha256'];original_images.append(dict(path=im['path'],sha256=im['sha256'],unchanged=True))
 textures=[]
 for image in od['images']:
  v=od['bufferViews'][image['bufferView']];a=v.get('byteOffset',0);content=ob[a:a+v['byteLength']]
  assert content==nb[a:a+v['byteLength']]
  textures.append(dict(name=image['name'],sha256=hashlib.sha256(content).hexdigest(),unchanged=True))
 model=json.loads((asset/'model.json').read_text());model['metadata']=meta
 author=model['materials']['own-ivory-fine-curved-alpha-fibres']
 author['normalScale']=.20;author['baseColorFactor']=[1,.98,.94,1]
 author['extras']['physical_sheen'].update(sheenColorFactor=[.65,.58,.48],sheenRoughnessFactor=.85)
 dump(asset/'model.json',model)
 e=copy.deepcopy(old);e.update(meta,asset_dir=str(asset),model_path=str(asset/'model.json'),glb_path=str(target),sha256=sha(target),bytes=target.stat().st_size,
    geometry_validation=str(asset/'geometry-validation.json'),material_validation=str(asset/'material-validation.json'),
    quality_pending=True,actual_browser_review_passed=False,frozen=True,model_status='ready_for_browser_review')
 geometry=dict(valid=True,material_only_patch=True,all_R8_geometry_and_UV_attributes_byte_identical=True,attribute_checks=unchanged)
 dump(asset/'geometry-validation.json',geometry)
 mv=json.loads((Path(old['asset_dir'])/'material-validation.json').read_text())
 for im in mv['maps']:im['path']=str(asset/Path(im['path']).name)
 mv.update(physical_PBR_only_adjustment=True,before=before,after=m,all_embedded_images_unchanged=True,
           no_emission_no_unlit_no_baked_lighting=True,native_COLOR0_primary_pigment_with_small_documented_warm_factor=True)
 dump(asset/'material-validation.json',mv)
 dump(asset/'R8-BIN-and-RGB-preservation-PBR-only-proof.json',dict(
   source_manifest=str(SOURCE),source_manifest_sha256=SOURCE_SHA,source_glb_sha256=old['sha256'],
   new_glb_sha256=e['sha256'],complete_BIN_byte_identical=True,BIN_sha256=hashlib.sha256(ob).hexdigest(),
   original_geometry_UV_and_images_unchanged=True,embedded_images=textures,own_JPEGs=original_images,
   old_material=before,new_material=m,only_three_PBR_controls_changed=True,
   native_preview_limitation='Existing native renderer does not implement MASK alpha-test hair silhouettes; final actual Three.js four-angle and close source comparison is required.',
   source_original_glb_unchanged=sha(old['glb_path'])==old['sha256'],
   root_approved_R8_geometry_preserved=True,ready_claim=False))
 dump(asset/'entry.json',e)
 validation=V.check(e);dump(asset/'independent-binary-material-only-check.json',validation)
 assert e['bytes']<96*2**20
 dump(OUTPUT,[e]);print(OUTPUT,sha(OUTPUT),e['bytes'],e['sha256'],flush=True)

if __name__=='__main__':build()
