"""One immutable three-SKU review handoff, with fifteen fresh native views."""
from pathlib import Path
import sys,json,hashlib,copy
from PIL import Image,ImageOps,ImageDraw
sys.dont_write_bytecode=True
D=Path(__file__).resolve().parent;T=D.parent.parent/'textiles';sys.path.insert(0,str(T))
from freeze_polar_knit_review_candidates import glb,attr,sha,dump
SOURCE=D.parent/'organic-remaining21-r5/frozen-family-03/manifest.json'
EXPECTED='d2ed8ed898ec5618e8b1e4edf091328123d95cef7c22c26b4575c167bb9a32f8'
TARGET={'1355345001','1357963001','1355863002'}
ANGLES=['on','yan','on-capraz','ustten','arka']

if __name__=='__main__':
 output=D/'frozen-own-projecting-long-curly-short-fur-03-manifest.json'
 assert not output.exists();assert sha(SOURCE)==EXPECTED
 originals={e['sku']:e for e in json.loads(SOURCE.read_text())}
 entries=json.loads((D/'candidate-three-projecting-pile-manifest.json').read_text());assert{e['sku']for e in entries}==TARGET
 checks=[];native=[];pres=[]
 for e in entries:
  old=originals[e['sku']];assert sha(old['glb_path'])==old['sha256']
  assert sha(e['glb_path'])==e['sha256'] and Path(e['glb_path']).stat().st_size==e['bytes']
  od,ob=glb(old['glb_path']);nd,nb=glb(e['glb_path']);assert nb[:len(ob)]==ob
  for key in ['meshes','images','materials','nodes','textures','accessors','bufferViews']:
   assert nd[key][:len(od[key])]==od[key],key
  proof=json.loads((Path(e['asset_dir'])/'unchanged-R5-body-own-PNG-and-projecting-pile-proof.json').read_text())
  for p in proof['existing_PNG_files_preserved']:
   assert sha(Path(old['asset_dir'])/p['name'])==p['sha256']==sha(Path(e['asset_dir'])/p['name'])
  for o in old['original_images']:assert sha(o['path'])==o['sha256']
  nativepaths={}
  for angle in ANGLES:
   p=Path(e['asset_dir'])/(angle+'.png');im=Image.open(p);assert im.size==(900,900)
   nativepaths[angle]=str(p);native.append(dict(sku=e['sku'],angle=angle,path=str(p),sha256=sha(p),pixels=list(im.size),fresh_projecting_geometry=True))
  log=D/('native-'+{'1355345001':'grey','1357963001':'cream','1355863002':'short'}[e['sku']]+'.log')
  text=log.read_text();assert 'complete: 1 models'in text
  assert all('rendered '+e['id']+'/'+angle+'.png'in text for angle in ANGLES)
  e.update(frozen=True,quality_pending=True,actual_browser_review_passed=False,model_status='ready_for_browser_review',native_renders=nativepaths,independent_validation_file=str(D/'independent-three-projecting-pile-validation.json'))
  check=json.loads((Path(e['asset_dir'])/'independent-projecting-pile-binary-check.json').read_text());assert check['valid']and check['sha256']==e['sha256'];checks.append(check)
  pres.append(dict(sku=e['sku'],old_frozen_glb=old['glb_path'],old_frozen_sha256=old['sha256'],old_frozen_unchanged=True,original_complete_BIN_prefix_preserved=True,all_old_attributes_nodes_materials_artwork_UVs_images_preserved=True,proof=str(Path(e['asset_dir'])/'unchanged-R5-body-own-PNG-and-projecting-pile-proof.json'),proof_sha256=sha(Path(e['asset_dir'])/'unchanged-R5-body-own-PNG-and-projecting-pile-proof.json')))
  dump(Path(e['asset_dir'])/'entry.json',e)
 # Diagnostic thumbnails only. Full 900px native renders and original JPEGs
 # remain unmodified and are the actual review inputs.
 width,height=240,280;sheet=Image.new('RGB',(width*6,height*3),(246,245,240));draw=ImageDraw.Draw(sheet)
 for row,e in enumerate(entries):
  paths=[Path(e['original_image'])]+[Path(e['native_renders'][a])for a in ANGLES]
  for col,p in enumerate(paths):
   im=Image.open(p).convert('RGBA');im.thumbnail((232,248),Image.Resampling.LANCZOS)
   tile=Image.new('RGBA',(232,248),(246,245,240,255));tile.alpha_composite(im,((232-im.width)//2,(248-im.height)//2));sheet.paste(tile.convert('RGB'),(col*width+4,row*height+25))
   draw.text((col*width+6,row*height+5),e['sku']+' '+('SOURCE'if col==0 else ANGLES[col-1]),fill=(30,30,30))
 sheet.save(D/'source-and-five-native-views-contact.jpg',quality=95)
 dump(D/'independent-three-projecting-pile-validation.json',dict(valid=True,models=3,ready_claim=False,root_actual_browser_review_required=True,checks=checks))
 dump(D/'R5-originals-own-JPEG-PNG-and-native15-proof.json',dict(source_manifest=str(SOURCE),source_manifest_sha256=EXPECTED,exact_three_SKUs=sorted(TARGET),source_frozen_masters_preserved=pres,native15=native,native_renderer_source=str(D/'native-support/native-render-eager-uv1.swift'),native_renderer_source_sha256=sha(D/'native-support/native-render-eager-uv1.swift'),native_renderer_binary_sha256=sha(D/'native-support/native-render-eager-uv1'),old_R5_renderer_unchanged=True,source_geometry_not_rescaled_or_reshaped=True,old_pattern_UVs_and_own_RGB_PNGs_unchanged=True,no_other_SKU_photographic_pixels=True,actual_browser_review_required=True,ready_claim=False))
 dump(output,entries);print(output,sha(output),[(e['sku'],round(e['bytes']/2**20,2))for e in entries],flush=True)
