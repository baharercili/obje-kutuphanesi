"""Append source-specific volumetric fur, preserving every original R5 GLB byte.

The original closed cloth, pose, artwork UVs, images, fine pile and quilt seams
remain in the old BIN prefix. Only new closed tapered bundle geometry and its
intrinsic normal/roughness are appended. No canonical files are touched.
"""
from pathlib import Path
import copy, hashlib, io, json, math, struct, subprocess, sys
import numpy as np
from PIL import Image
sys.dont_write_bytecode = True
D = Path(__file__).resolve().parent
P = D.parent.parent
T = P/'textiles'
sys.path.insert(0, str(T))
from freeze_polar_knit_review_candidates import glb, sha, dump, attr
from clean_remaining_robe_material_revision02 import write_glb
import specific_binary_native_material as V
SOURCE = D.parent/'organic-remaining21-r5/frozen-family-03/manifest.json'
SOURCE_SHA = 'd2ed8ed898ec5618e8b1e4edf091328123d95cef7c22c26b4575c167bb9a32f8'
CFG = {
 '1355345001': dict(kind='grey_cloud_long', count=22000, rings=6, sides=5,
                   length=[.014,.026], rise=[.007,.012], width=[.0011,.0021],
                   factor=[1,1,1,1], label='Uzun bulutlu gri hav · Organik dört kat · Ölçek yaklaşık'),
 '1357963001': dict(kind='cream_curl', count=16000, rings=8, sides=5,
                   length=[.018,.030], rise=[.008,.015], width=[.0018,.0038],
                   factor=[1,.97,.89,1], label='Kıvırcık uzun krem hav · Organik dört kat · Ölçek yaklaşık'),
 '1355863002': dict(kind='short_quilt', count=36000, rings=4, sides=3,
                   length=[.004,.007], rise=[.0025,.0045], width=[.0006,.0012],
                   factor=[1,.91,.80,1], label='Kısa yoğun kapitone hav · Organik dört kat · Ölçek yaklaşık'),
}

def array(d,b,i):
 a=d['accessors'][i];v=d['bufferViews'][a['bufferView']]
 dt={5126:'<f4',5125:'<u4',5123:'<u2'}[a['componentType']]
 n={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}[a['type']];size=np.dtype(dt).itemsize
 return np.ndarray((a['count'],n),dt,b,v.get('byteOffset',0)+a.get('byteOffset',0),
                   strides=(v.get('byteStride',n*size),size)).copy()

def sample_actual_top(d,b,sku,count):
 """Exact ray/triangle intersections through the unchanged R5 body, not a proxy."""
 prim=d['meshes'][0]['primitives'][0]
 pos=array(d,b,prim['attributes']['POSITION']).astype(float)
 nor=array(d,b,prim['attributes']['NORMAL']).astype(float)
 uv=array(d,b,prim['attributes']['TEXCOORD_0']).astype(float)
 faces=array(d,b,prim['indices']).reshape(-1,3)
 tri=pos[faces];cross=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0])
 keep=cross[:,1]>1e-10;faces=faces[keep];tri=tri[keep]
 lo=pos[:,[0,2]].min(0);hi=pos[:,[0,2]].max(0)
 bins=64;grid=[[]for _ in range(bins*bins)]
 a=np.clip(np.floor((tri[:,:,[0,2]].min(1)-lo)/(hi-lo)*bins).astype(int),0,bins-1)
 z=np.clip(np.floor((tri[:,:,[0,2]].max(1)-lo)/(hi-lo)*bins).astype(int),0,bins-1)
 for i in range(len(tri)):
  for ix in range(a[i,0],z[i,0]+1):
   for iz in range(a[i,1],z[i,1]+1):grid[ix*bins+iz].append(i)
 rng=np.random.default_rng(int(sku)+1217)
 points=rng.uniform(lo+.0025,hi-.0025,(count*3,2))
 cell=np.clip(np.floor((points-lo)/(hi-lo)*bins).astype(int),0,bins-1)
 group=cell[:,0]*bins+cell[:,1];Y=np.full(len(points),-np.inf);N=np.zeros((len(points),3));UV=np.zeros((len(points),2))
 for cellid in np.unique(group):
  ix=np.flatnonzero(group==cellid);ids=np.asarray(grid[cellid],int)
  if not len(ids):continue
  tt=tri[ids];aa=tt[:,0][:,[0,2]];ab=tt[:,1][:,[0,2]]-aa;ac=tt[:,2][:,[0,2]]-aa
  det=ab[:,0]*ac[:,1]-ab[:,1]*ac[:,0];valid=abs(det)>1e-12
  ids=ids[valid];aa=aa[valid];ab=ab[valid];ac=ac[valid];det=det[valid];tt=tri[ids]
  delta=points[ix,None,:]-aa[None,:,:]
  w1=(delta[:,:,0]*ac[None,:,1]-delta[:,:,1]*ac[None,:,0])/det[None,:]
  w2=(ab[None,:,0]*delta[:,:,1]-ab[None,:,1]*delta[:,:,0])/det[None,:];w0=1-w1-w2
  inside=(w0>=-1e-7)&(w1>=-1e-7)&(w2>=-1e-7)
  ys=w0*tt[None,:,0,1]+w1*tt[None,:,1,1]+w2*tt[None,:,2,1];ys[~inside]=-np.inf
  best=np.argmax(ys,axis=1);ok=np.isfinite(ys[np.arange(len(ix)),best]);which=ix[ok];best=best[ok]
  weights=np.stack([w0[ok,best],w1[ok,best],w2[ok,best]],1);ff=faces[ids[best]]
  Y[which]=ys[ok,best];N[which]=(nor[ff]*weights[:,:,None]).sum(1);UV[which]=(uv[ff]*weights[:,:,None]).sum(1)
 valid=np.isfinite(Y)&(N[:,1]>.15)
 points=points[valid];Y=Y[valid];N=N[valid];UV=UV[valid]
 if sku=='1355863002':
  span=np.asarray(CFG[sku].get('span',[.640197977,.854771953]));dist=np.minimum(
    abs(UV[:,0,None]-np.array([.14,.415,.69,.96])).min(1)*span[0],
    abs(UV[:,1,None]-np.array([.205,.415,.625,.835])).min(1)*span[1])
  keep=dist>.006;points=points[keep];Y=Y[keep];N=N[keep];UV=UV[keep]
 assert len(Y)>=count,(sku,len(Y),count)
 take=rng.choice(len(Y),count,replace=False)
 roots=np.c_[points[take,0],Y[take],points[take,1]];N=N[take];N/=np.linalg.norm(N,axis=1,keepdims=True)
 return roots,N,UV[take],lo,hi

def tubes(paths,widths,thickness,sides):
 count,k,_=paths.shape
 tangent=np.empty_like(paths);tangent[:,1:-1]=paths[:,2:]-paths[:,:-2];tangent[:,0]=paths[:,1]-paths[:,0];tangent[:,-1]=paths[:,-1]-paths[:,-2]
 tangent/=np.linalg.norm(tangent,axis=2,keepdims=True)
 guide=np.zeros_like(tangent);guide[:,:,1]=1;guide[abs(tangent[:,:,1])>.95]=[0,0,1]
 across=np.cross(tangent,guide);across/=np.linalg.norm(across,axis=2,keepdims=True);up=np.cross(across,tangent)
 theta=np.arange(sides)*math.tau/sides
 t=np.linspace(0,1,k);taper=np.interp(t,[0,.18,.45,.72,1],[.62,1,.91,.65,.035])
 ring=paths[:,:,None,:]+across[:,:,None,:]*np.cos(theta)[None,None,:,None]*(widths[:,None,None,None]*.5*taper[None,:,None,None])+up[:,:,None,:]*np.sin(theta)[None,None,:,None]*(thickness[:,None,None,None]*.5*taper[None,:,None,None])
 vertices=np.concatenate([ring.reshape(count,k*sides,3),paths[:,0,None,:],paths[:,-1,None,:]],1)
 faces=[]
 for j in range(k-1):
  for i in range(sides):
   a=j*sides+i;bb=j*sides+(i+1)%sides;c=a+sides;dd=bb+sides
   faces.extend([(a,c,bb),(bb,c,dd)])
 for i in range(sides):faces.extend([(k*sides,i,(i+1)%sides),(k*sides+1,(k-1)*sides+(i+1)%sides,(k-1)*sides+i)])
 faces=(np.asarray(faces,np.uint32)[None,:,:]+np.arange(count,dtype=np.uint32)[:,None,None]*(k*sides+2)).reshape(-1,3)
 radial=np.linalg.norm(np.diff(np.concatenate([ring,ring[:,:,:1]],2),axis=2),axis=3)
 circum=np.concatenate([np.zeros((count,k,1)),np.cumsum(radial,axis=2)[:,:,:-1]],2)/.04
 arc=np.c_[np.zeros(count),np.cumsum(np.linalg.norm(np.diff(paths,axis=1),axis=2),axis=1)]/.04
 uv=np.stack([circum,np.repeat(arc[:,:,None],sides,axis=2)],3).reshape(count,k*sides,2)
 uv=np.concatenate([uv,np.tile([.001,-.001],(count,1,1)),np.stack([np.full(count,.001),arc[:,-1]+.001],1)[:,None,:]],1)
 return vertices,faces,uv

def normals_and_tangents(p,faces,uv):
 xyz=p[faces].astype(float);n=np.zeros_like(p,dtype=float);fn=np.cross(xyz[:,1]-xyz[:,0],xyz[:,2]-xyz[:,0])
 for k in range(3):np.add.at(n,faces[:,k],fn)
 n/=np.linalg.norm(n,axis=1,keepdims=True)
 tuv=uv[faces];a=tuv[:,1]-tuv[:,0];b=tuv[:,2]-tuv[:,0];den=a[:,0]*b[:,1]-a[:,1]*b[:,0]
 assert abs(den).min()>1e-13
 t=((xyz[:,1]-xyz[:,0])*b[:,1,None]-(xyz[:,2]-xyz[:,0])*a[:,1,None])/den[:,None]
 bt=((xyz[:,2]-xyz[:,0])*a[:,0,None]-(xyz[:,1]-xyz[:,0])*b[:,0,None])/den[:,None]
 tan=np.zeros_like(p,dtype=float);bit=np.zeros_like(p,dtype=float)
 for k in range(3):np.add.at(tan,faces[:,k],t);np.add.at(bit,faces[:,k],bt)
 tan-=n*(n*tan).sum(1)[:,None];tan/=np.linalg.norm(tan,axis=1,keepdims=True)
 handed=np.where((np.cross(n,tan)*bit).sum(1)<0,-1,1)
 return n.astype('<f4'),np.c_[tan,handed].astype('<f4')

def new_bundle_mesh(d,b,sku,cfg):
 p,n,at,lo,hi=sample_actual_top(d,b,sku,cfg['count'])
 rng=np.random.default_rng(int(sku)+606);count=len(p);u=at[:,0];v=at[:,1]
 angle=1.1*np.sin(u*24+v*11)+.65*np.cos(v*31-u*14)+rng.normal(0,.28,count)
 if cfg['kind']=='cream_curl':angle+=2*np.sin(u*33-v*29)
 tangent=np.stack([np.cos(angle),np.zeros(count),np.sin(angle)],1)
 tangent-=n*(tangent*n).sum(1)[:,None];tangent/=np.linalg.norm(tangent,axis=1,keepdims=True)
 # Existing R5 origin and body bytes remain fixed. At an edge, the observed
 # long fur curves inward/upward rather than changing the old nominal footprint.
 edge=np.minimum(p[:,[0,2]]-lo,hi-p[:,[0,2]]).min(1)<.034
 inward=np.c_[(lo[0]+hi[0])/2-p[:,0],np.zeros(count),(lo[1]+hi[1])/2-p[:,2]]
 inward-=n*(inward*n).sum(1)[:,None];inward/=np.linalg.norm(inward,axis=1,keepdims=True)
 tangent[edge]=inward[edge]
 cross=np.cross(n,tangent);length=rng.uniform(*cfg['length'],count);rise=rng.uniform(*cfg['rise'],count)
 width=rng.uniform(*cfg['width'],count);thick=width*rng.uniform(.28,.44,count)
 phase=rng.uniform(0,math.tau,count);rows=[]
 for f in np.linspace(0,1,cfg['rings']):
  lift=np.sin(math.pi*f*.91)
  if cfg['kind']=='cream_curl':
   curl=.32*length*(np.sin(f*math.tau*.93+phase)-np.sin(phase))*np.sin(math.pi*f*.82)
   along=length*(f*.73+.10*np.sin(f*math.tau))
  else:
   curl=length*.085*np.sin(f*math.tau*.7+phase)*f;along=length*f
  rows.append(p+n*(.00045+rise*lift)[:,None]+tangent*along[:,None]+cross*curl[:,None])
 paths=np.stack(rows,1);vertices,faces,metric=tubes(paths,width,thick,cfg['sides'])
 # Tubes that still stray beyond the pre-existing pile footprint are rotated
 # inward and shortened. Never clamp/collapse their closed geometry.
 allpos=[]
 for m in d['meshes']:
  for pr in m['primitives']:allpos.append(array(d,b,pr['attributes']['POSITION']))
 oldpos=np.concatenate(allpos);boundlo=oldpos.min(0);boundhi=oldpos.max(0)
 outside=((vertices[:,:,0]<boundlo[0])|(vertices[:,:,0]>boundhi[0])|(vertices[:,:,2]<boundlo[2])|(vertices[:,:,2]>boundhi[2])).any(1)
 if outside.any():
  off=vertices[outside]-p[outside,None,:];scale=np.ones(len(off))
  for axis in [0,2]:
   positive=np.maximum(off[:,:,axis].max(1),1e-12);negative=np.maximum(-off[:,:,axis].min(1),1e-12)
   scale=np.minimum(scale,(boundhi[axis]-p[outside,axis])*.99/positive)
   scale=np.minimum(scale,(p[outside,axis]-boundlo[axis])*.99/negative)
  assert scale.min()>0
  off[:,:,[0,2]]*=scale[:,None,None];vertices[outside]=p[outside,None,:]+off
 assert vertices[:,:,0].min()>=boundlo[0] and vertices[:,:,0].max()<=boundhi[0]
 assert vertices[:,:,2].min()>=boundlo[2] and vertices[:,:,2].max()<=boundhi[2]
 xyz=vertices.reshape(-1,3).astype('<f4');uv1=metric.reshape(-1,2).astype('<f4')
 uv0=(at[:,None,:]+metric*.002).reshape(-1,2).astype('<f4')
 normals,tangents=normals_and_tangents(xyz,faces,uv1)
 cells=np.floor((p[:,[0,2]]-lo)/(hi-lo)*16).astype(int)
 proof=dict(roots_on_exact_unchanged_R5_upper_triangles=True,bundles=count,
            family=cfg['kind'],occupied_upper_cells_16x16=len({tuple(c)for c in cells}),
            normal_rise_m=cfg['rise'],tangential_fall_m=cfg['length'],bundle_width_m=cfg['width'],
            geometry_and_pile_scale_photo_interpreted=True,
            own_pigment_root_UV_reused=True,quilt_channels_clear=sku=='1355863002',
            old_R5_footprint_and_origin_unchanged=True,inward_edge_curves=int(edge.sum()),
            edge_restrained_shorter_bundles=int(outside.sum()),
            existing_body_bounds_m=[boundlo.tolist(),boundhi.tolist()],
            new_pile_bounds_m=[xyz.min(0).tolist(),xyz.max(0).tolist()])
 return xyz,normals,uv0,uv1,tangents,faces,proof

def intrinsic_maps(out):
 n=1024;repeat=.04;x=np.arange(n)[None,:]/n*repeat;y=np.arange(n)[:,None]/n*repeat
 h=.000025*np.cos(x/.00018*math.tau)**4+.000004*np.cos(y/.0006*math.tau)*np.cos(x/.00021*math.tau)
 dy,dx=np.gradient(h,repeat/n,repeat/n);normal=np.stack([-dx,dy,np.ones_like(h)],2);normal/=np.linalg.norm(normal,axis=2,keepdims=True)
 Image.fromarray(np.rint((normal+1)*127.5).astype(np.uint8)).save(out/'intrinsic-bundle-micro-normal.png')
 Image.new('RGB',(4,4),(255,246,0)).save(out/'intrinsic-bundle-nonmetal-roughness.png')

def build(old):
 sku=old['sku'];cfg=CFG[sku];assert sha(old['glb_path'])==old['sha256']
 out=D/'models'/old['id'];assert not out.exists();out.parent.mkdir(exist_ok=True)
 subprocess.run(['/usr/bin/ditto','--clone',old['asset_dir'],str(out)],check=True)
 od,ob=glb(old['glb_path']);d=copy.deepcopy(od);binary=bytearray(ob)
 print('SAMPLING',sku,flush=True)
 xyz,normals,uv0,uv1,tangents,faces,coverage=new_bundle_mesh(od,ob,sku,cfg)
 print('GEOMETRY',sku,len(xyz),len(faces),flush=True)
 def view(content,target=None):
  binary.extend(b'\0'*(-len(binary)%4));v=dict(buffer=0,byteOffset=len(binary),byteLength=len(content));binary.extend(content)
  if target:v['target']=target
  d['bufferViews'].append(v);return len(d['bufferViews'])-1
 def acc(a,kind,component=5126,target=34962):
  a=np.asarray(a,'<u4'if component==5125 else'<f4');i=len(d['accessors']);d['accessors'].append(dict(bufferView=view(a.tobytes(),target),componentType=component,count=len(a),type=kind,min=a.min(0).tolist(),max=a.max(0).tolist()));return i
 attrs=dict(POSITION=acc(xyz,'VEC3'),NORMAL=acc(normals,'VEC3'),TEXCOORD_0=acc(uv0,'VEC2'),TEXCOORD_1=acc(uv1,'VEC2'),TANGENT=acc(tangents,'VEC4'))
 indices=acc(faces.reshape(-1,1),'SCALAR',5125,34963)
 intrinsic_maps(out)
 def image_texture(name):
  ii=len(d['images']);d['images'].append(dict(bufferView=view((out/name).read_bytes()),mimeType='image/png',name=name));ti=len(d['textures']);d['textures'].append(dict(source=ii,sampler=0));return ti
 ni=image_texture('intrinsic-bundle-micro-normal.png');oi=image_texture('intrinsic-bundle-nonmetal-roughness.png')
 material=copy.deepcopy(d['materials'][0]);material['name']='projecting-own-source-pile'
 pbr=material['pbrMetallicRoughness'];pbr['baseColorFactor']=cfg['factor'];pbr['metallicRoughnessTexture']=dict(index=oi,texCoord=1)
 material['normalTexture']=dict(index=ni,texCoord=1,scale=.42);material['occlusionTexture']=dict(index=oi,texCoord=1,strength=.35)
 material.setdefault('extensions',{})['KHR_materials_sheen']=dict(sheenColorFactor=[.18,.17,.16],sheenRoughnessFactor=1.)
 mi=len(d['materials']);d['materials'].append(material);mesh=len(d['meshes'])
 d['meshes'].append(dict(name='source-specific-visible-volumetric-'+cfg['kind']+'-bundles',primitives=[dict(attributes=attrs,indices=indices,material=mi,mode=4)]))
 node=len(d['nodes']);d['nodes'].append(dict(name=d['meshes'][-1]['name'],mesh=mesh));assert len(d['scenes'])==1;d['scenes'][0]['nodes'].append(node)
 d['extensionsUsed']=sorted(set(d.get('extensionsUsed',[]))|{'KHR_materials_sheen'})
 oldpositions=np.concatenate([array(od,ob,p['attributes']['POSITION'])for m in od['meshes']for p in m['primitives']]);allpos=np.r_[oldpositions,xyz]
 dims=((allpos.max(0)-allpos.min(0))*100).tolist();meta=copy.deepcopy(od['extras']['metadata']);meta.update(dimensions_cm=dims,model_revision='own-source-projecting-volumetric-pile-R6',quality_label=cfg['label'])
 meta['estimated_fields']=sorted(set(meta['estimated_fields']+['source_specific_bundle_width_height_curl_and_loose_pile']))
 meta['quality_note']+=' Mevcut R5 gövde, açık plan ve kendi RGB doku pikselleri aynen korundu; görünür dış hav kendi fotoğrafından yaklaşık hacimli lif demetleriyle eklendi. Görünmeyen lif yapısı üretici CAD verisi değildir.'
 d['extras']['metadata']=meta;target=out/Path(old['glb_path']).name;write_glb(target,d,bytes(binary));nd,nb=glb(target)
 assert nb[:len(ob)]==ob
 assert nd['meshes'][:len(od['meshes'])]==od['meshes']
 assert nd['images'][:len(od['images'])]==od['images']
 geometry=[]
 for m in od['meshes']:
  for pr in m['primitives']:
   for key,i in {**pr['attributes'],'indices':pr['indices']}.items():
    assert attr(od,ob,i)==attr(nd,nb,i);geometry.append(dict(mesh=m['name'],attribute=key,sha256=attr(od,ob,i),byte_identical=True))
 model=json.loads((out/'model.json').read_text());model['metadata']=meta
 author=copy.deepcopy(model['materials']['fabric']);author.update(baseColorFactor=cfg['factor'],normalTexture='intrinsic-bundle-micro-normal.png',metallicRoughnessTexture='intrinsic-bundle-nonmetal-roughness.png',normalScale=.42)
 author['extras'].update(normal_orm_uv_scale=[1,1],secondary_physical_uv=True,physical_sheen=dict(sheenColorFactor=[.18,.17,.16],sheenRoughnessFactor=1.))
 model['materials']['projecting-own-source-pile']=author
 model['meshes'].append(dict(name=d['meshes'][-1]['name'],material='projecting-own-source-pile',positions=xyz.reshape(-1).tolist(),normals=normals.reshape(-1).tolist(),uvs=uv0.reshape(-1).tolist(),uvs1=uv1.reshape(-1).tolist(),indices=faces.reshape(-1).tolist()))
 dump(out/'model.json',model)
 e=copy.deepcopy(old);e.update(meta,asset_dir=str(out),model_path=str(out/'model.json'),glb_path=str(target),geometry_validation=str(out/'geometry-validation.json'),material_validation=str(out/'material-validation.json'),sha256=sha(target),bytes=target.stat().st_size,model_revision='own-source-projecting-volumetric-pile-R6',frozen=False,actual_browser_review_passed=False,quality_pending=True,model_status='ready_for_browser_review');e.pop('native_renders',None);e.pop('independent_validation_file',None)
 assert e['bytes']<=96*2**20,e['bytes'];maps=[]
 for im in nd['images']:
  v=nd['bufferViews'][im['bufferView']];offset=v.get('byteOffset',0);content=nb[offset:offset+v['byteLength']];pil=Image.open(io.BytesIO(content));maps.append(dict(file=im['name'],path=str(out/im['name']),sha256=hashlib.sha256(content).hexdigest(),native_resolution=list(pil.size)))
 dump(out/'material-validation.json',dict(valid=True,maps=maps,own_RGB_PNGs_byte_identical=True,original_JPEGs_unchanged=True,original_normal_orm_maps_preserved=True,new_maps_only_intrinsic_micro_normal_and_constant_roughness=True))
 dump(out/'geometry-validation.json',dict(valid=True,existing_R5_geometry_byte_identical=geometry,new_pile_coverage=coverage,actual_browser_review_required=True))
 pngs=[]
 for f in Path(old['asset_dir']).glob('*.png'):
  if f.name in {'on.png','yan.png','on-capraz.png','ustten.png','arka.png'}:continue
  assert sha(f)==sha(out/f.name);pngs.append(dict(name=f.name,sha256=sha(f),unchanged=True))
 proof=dict(source_manifest=str(SOURCE),source_manifest_sha256=SOURCE_SHA,source_frozen_glb=old['glb_path'],source_frozen_glb_sha256=old['sha256'],source_frozen_unchanged=sha(old['glb_path'])==old['sha256'],source_original_images=old['original_images'],all_original_JPEGs_unchanged=all(sha(o['path'])==o['sha256']for o in old['original_images']),old_complete_BIN_prefix_bytes=len(ob),old_complete_BIN_prefix_sha256=hashlib.sha256(ob).hexdigest(),new_BIN_has_exact_old_BIN_prefix=True,old_mesh_materials_nodes_and_artwork_UVs_preserved=True,single_scene_appends_only_one_new_pile_node=True,existing_mesh_attribute_proofs=geometry,existing_PNG_files_preserved=pngs,old_nominal_plan_dimensions_cm=old.get('official_plan_dimensions_cm')or old.get('estimated_unfolded_plan_cm'),nominal_plan_is_official=bool(old.get('official_plan_dimensions_cm')),body_drape_and_old_origin_unchanged=True,new_visible_pile=coverage,root_actual_review_required=True,ready_claim=False)
 dump(out/'unchanged-R5-body-own-PNG-and-projecting-pile-proof.json',proof)
 dump(out/'entry.json',e);check=V.check(e);dump(out/'independent-projecting-pile-binary-check.json',check)
 print('BUILT',sku,e['bytes'],e['sha256'],flush=True);return e

if __name__=='__main__':
 assert sha(SOURCE)==SOURCE_SHA
 rows={e['sku']:e for e in json.loads(SOURCE.read_text())}
 selected=sys.argv[1:]or list(CFG);assert set(selected)<=set(CFG)
 entries=json.loads((D/'candidate-three-projecting-pile-manifest.json').read_text())if(D/'candidate-three-projecting-pile-manifest.json').exists()else[]
 for sku in selected:
  assert sku not in {e['sku']for e in entries}
  entries.append(build(rows[sku]));dump(D/'candidate-three-projecting-pile-manifest.json',entries)
