"""Exact203 final preservation audit; approved geometry, maps and JPEGs read only."""
from pathlib import Path
import json,hashlib,struct,re,collections
P=Path(__file__).resolve().parent;V=P/'final-reviewed-scope-203';HIST=P/'frozen-scope-203-pending-peer3';PEER=P/'peer-final-three-root-accepted-v2';cache={};read=lambda p:json.loads(Path(p).read_text())
def sha(path):
 path=str(Path(path).resolve())
 if path not in cache:
  h=hashlib.sha256()
  with open(path,'rb')as f:
   for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
  cache[path]=h.hexdigest()
 return cache[path]
def dump(path,value):Path(path).write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def materials_prefix(path):
 with open(path,encoding='utf-8')as f:
  text=''
  for _ in range(16):
   text+=f.read(65536);match=re.search(r'"materials"\s*:\s*',text)
   if match:
    try:return json.JSONDecoder().raw_decode(text[match.end():])[0]
    except json.JSONDecodeError:pass
 raise ValueError('Unable to read bounded materials prefix: '+str(path))
def embedded_hashes(path):
 with open(path,'rb')as f:
  magic,version,length=struct.unpack('<4sII',f.read(12));assert magic==b'glTF'and version==2 and length==Path(path).stat().st_size;n,kind=struct.unpack('<II',f.read(8));assert kind==0x4e4f534a;doc=json.loads(f.read(n));n,kind=struct.unpack('<II',f.read(8));assert kind==0x004e4942;bin_start=f.tell();items=[]
  for image in doc.get('images',[]):
   assert'uri'not in image;view=doc['bufferViews'][image['bufferView']];f.seek(bin_start+view.get('byteOffset',0));data=f.read(view['byteLength']);assert len(data)==view['byteLength'];items.append(dict(name=image.get('name'),mimeType=image['mimeType'],bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
 return doc,items
assert not V.exists(),'Never mutate an existing final snapshot'
oldseal=read(HIST/'FROZEN-SCOPE.json');assert oldseal['ready']==200 and oldseal['pending']==3
for item in oldseal['files']:assert sha(HIST/item['path'])==item['sha256']
oldseal_sha=sha(HIST/'FROZEN-SCOPE.json');prior_masters={x['path']:x for x in read(HIST/'original-master-registry.json')};prior_master_registry_sha=sha(HIST/'original-master-registry.json');prior_snapshot_time=(HIST/'FROZEN-SCOPE.json').stat().st_mtime_ns;base=read(HIST/'ready-manifest-200.json');peer=read(PEER/'manifest.json');assert len(base)==200 and len(peer)==3
peer_expected={'1355863002':'18d217350ca3fafa4fa910cf40c1ec473077b09fadda82064d0a6973ad57486d','1357963001':'9b8830f46250d57c22d7549b7c84ec627ea9e94ce9a74306f8f99e851fffb6b7','1355345001':'27226fe250f74fc6a395cabc4e8bb31a1500d78ff18de880d3ae13257413786e'}
for e in peer:
 assert e['sha256']==peer_expected[e['sku']];binding=read(e['root_actual_ID_SHA_record']);q=next(x for x in binding if x['id']==e['id']);assert q['sha256']==e['sha256'];assert sha(e['root_actual_ID_SHA_record'])==e['root_actual_ID_SHA_record_sha256']
entries=base+peer;assert len(entries)==203 and len({e['sku']for e in entries})==203;previous_index=read(HIST/'delivery-index-203.json');idx={e['sku']:e for e in previous_index['products']};old_accepted={e['sku']:e for e in base};masters={};proof=[];map_registry={};scopeproof={};heavy=[]
for i,e in enumerate(entries):
 glb=Path(e['glb_path']);assert glb.stat().st_size==e['bytes'];assert sha(glb)==e['sha256']
 if e['bytes']>=40*1024*1024:assert e['sha256']==peer_expected[e['sku']];heavy.append(dict(sku=e['sku'],bytes=e['bytes'],sha256=e['sha256'],basis='Explicit root actual approval of this unchanged higher-detail physical-fibre master.'))
 if e['sku']in old_accepted:
  source=idx[e['sku']]['manifest_path'];assert sha(source)==idx[e['sku']]['manifest_sha256'];assert e['sha256']==idx[e['sku']]['glb_sha256']
 else:source=str(PEER/'manifest.json')
 for original in e['original_images']:
  prior=prior_masters.get(original['path']);assert prior and prior['sha256']==original['sha256'];st=Path(original['path']).stat();assert st.st_mtime_ns<=prior_snapshot_time,(e['sku'],'source modified after prior hash');masters[original['path']]=dict(original,verification_basis='Exact path/SHA bound to previous full-byte-verified immutable203 source-master registry; no later mtime change; no source edits authorized or performed.',prior_verified_master_registry=str(HIST/'original-master-registry.json'),prior_verified_master_registry_sha256=prior_master_registry_sha,source_mtime_ns=st.st_mtime_ns,prior_snapshot_mtime_ns=prior_snapshot_time,rehashed_in_this_audit=False)

 doc,embedded=embedded_hashes(glb);meta=doc['extras']['metadata'];assert meta['sku']==e['sku']and meta['brand']=='H&M Home'and meta['units']=='metres'and meta['up_axis']=='Y';e.setdefault('units',meta['units']);e.setdefault('up_axis',meta['up_axis']);used=[]
 def bindings(value,path=''):
  if isinstance(value,dict):
   for key,item in value.items():
    location=path+'.'+key if path else key
    if key.endswith('Texture')and isinstance(item,dict)and isinstance(item.get('index'),int):yield location,item
    else:yield from bindings(item,location)
  elif isinstance(value,list):
   for j,item in enumerate(value):yield from bindings(item,path+'['+str(j)+']')
 for ma in doc['materials']:
  for slot,binding in bindings(ma):
   texture=doc['textures'][binding['index']];image_index=texture['source'];image=embedded[image_index];item=dict(material=ma.get('name'),slot=slot,texture_index=binding['index'],image_index=image_index,runtime_source='self-contained GLB BIN image bufferView',mimeType=image['mimeType'],bytes=image['bytes'],sha256=image['sha256'],fresh_hash_from_used_runtime_image=True,external_staging_copy_rehashed=False);used.append(item);key=str(glb)+'#image'+str(image_index);map_registry[key]=dict(GLB_path=str(glb),image_index=image_index,bytes=image['bytes'],sha256=image['sha256'],fresh_embedded_image_hash=True)
 assert used and embedded
 # Prior200 full independent/material validation is retained through its
 # immutable scope receipt; archived staging JSON/PNG need not be recalled.
 prior_QA_paths={key:e[key]for key in['geometry_validation','material_validation']};assert all(Path(value).is_file()for value in prior_QA_paths.values())
 scopeproof[source]=dict(path=source,sha256=sha(source),kind='root_accepted_frozen_manifest')
 if e['sku']in peer_expected:
  for key in['root_approval_manifest_path','root_actual_ID_SHA_record']:
   path=Path(e[key]);scopeproof[str(path)]=dict(path=str(path),sha256=sha(path),kind=key)
 e.update(frozen=True,quality_pending=False,actual_browser_review_passed=True,root_actual_accepted=True,model_status='ready_for_integration',root_accepted_manifest=source,root_accepted_manifest_sha256=sha(source))
 row=idx[e['sku']];row.update(status='root_actual_accepted',id=e['id'],manifest_path=source,manifest_sha256=sha(source),glb_path=e['glb_path'],glb_sha256=e['sha256'])
 proof.append(dict(sku=e['sku'],id=e['id'],glb_path=e['glb_path'],glb_sha256=e['sha256'],GLB_bytes_verified=e['bytes'],root_accepted_source_manifest=source,root_accepted_source_manifest_sha256=sha(source),original_JPEG_masters_unchanged=True,JPEG_SHA_basis="Prior full-byte-verified frozen master registry; exact path+SHA and unchanged mtime; not rehashed in this audit.",used_runtime_maps=used,embedded_images=embedded,all_used_runtime_maps_fresh_hashed=True,external_staging_PNG_copies_rehashed=False,existing_independent_geometry_material_QA_receipts_retained=True,existing_QA_paths=prior_QA_paths,new_topology_or_pixel_edits=False,official_dimensions_unresolved=row['official_dimensions_unresolved'],estimated_reconstruction_notes_preserved=True))
 if(i+1)%25==0 or i==202:print('AUDIT',i+1,'/203',e['sku'],flush=True)
assert sha(HIST/'FROZEN-SCOPE.json')==oldseal_sha
for path in [HIST/'FROZEN-SCOPE.json',HIST/'preservation-validation.json',HIST/'original-master-registry.json',PEER/'root-approval-receipt.json']:
 scopeproof[str(path)]=dict(path=str(path),sha256=sha(path),kind='immutable_scope_or_source_verification_receipt')

index=dict(previous_index,counts={'root_actual_accepted':203},products=[idx[e['sku']]for e in previous_index['products']],all_root_actual_accepted=True,all_current_GLBS_match_delivery_SHA=True,all_used_runtime_maps_fresh_hashed=True,old_200ready_3pending_snapshot_unchanged=True,pending_model_SKUs=[],root_approved_larger_physical_fibre_masters=heavy)
V.mkdir();dump(V/'manifest.json',entries);dump(V/'delivery-index-203.json',index);dump(V/'preservation-validation.json',dict(valid=True,models=203,unique_exact_SKUs=203,all_root_actual_accepted=True,all_original_image_masters_unchanged=True,JPEG_SHA_basis="Prior frozen full-byte verification, exact path+SHA, unchanged mtime. No new JPEG hash claim.",prior_source_master_registry_sha256=prior_master_registry_sha,source_master_count=len(masters),used_map_count=len(map_registry),scopeproof_count=len(scopeproof),all_used_runtime_maps_fresh_hashed=True,models_rebuilt_for_this_registry=0,texture_or_geometry_mutations=0,canonical_or_Site_files_modified=False,actual_PNGs_not_downloaded_or_rehashed=True,external_staging_PNG_copies_not_recalled_or_fresh_hashed=True,prior_actual_and_independent_QA_records_retained=True,old_200ready_3pending_snapshot_sha256=oldseal_sha,old_snapshot_unchanged=True,checks=proof));dump(V/'original-master-registry.json',list(masters.values()));dump(V/'used-map-registry.json',list(map_registry.values()));dump(V/'scopeproof-registry.json',list(scopeproof.values()));dump(V/'root-approved-peer-three.json',read(PEER/'root-approval-receipt.json'));dump(V/'official-size-limitations.json',dict(official_dimensions_unresolved=index['official_dimension_gaps'],note='Resmî açık plan ölçüsü yayımlanmayan kimliklerde fotoğraf tahmini korunmuştur; resmî üretici ölçüsü değildir. Hav/lif, kalınlık, kat pozu ve görünmeyen desen fazı ürünün kendi ölçek/yorum notlarında açıklanır.'))
files=[dict(path=str(f.relative_to(V)),bytes=f.stat().st_size,sha256=sha(f))for f in sorted(V.glob('*'))if f.is_file()];dump(V/'FINAL-SCOPE-FROZEN.json',dict(status='all203_root_actual_accepted_exact_unchanged_assets',products=203,manifest_sha256=sha(V/'manifest.json'),delivery_index_sha256=sha(V/'delivery-index-203.json'),preservation_validation_sha256=sha(V/'preservation-validation.json'),files=files));print('FROZEN203',sha(V/'manifest.json'),sha(V/'delivery-index-203.json'),sha(V/'preservation-validation.json'),flush=True)
