"""Keep the complete user-authorized 736-SKU production scope and immutable baseline."""
from pathlib import Path
import json,hashlib,collections,re,shutil
R=Path(__file__).resolve().parent;SITE=R.parents[2]/'sites/zarahome-vazo-kutuphanesi-final-378'
def dump(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
p=json.loads((R/'initial-pending-736.json').read_text());assert len(p)==736 and len({x['sku']for x in p})==736
base=R/'baseline-1401';base.mkdir(exist_ok=True)
for f in ['model-manifest.json','ui/hmhome-catalog.json','ui/hmhome-preview.json','ui/hmhome-discovered.json','ui/hmhome-inventory.json']:
 dest=base/f.replace('/','__')
 if not dest.exists():shutil.copy2(SITE/f,dest)
ready=json.loads((base/'model-manifest.json').read_text())['models'];assert len(ready)==1401
def owner(x):
 if x['category']=='Perdeler':return 'curtains'
 if x['category'] in ['Kırlentler','Halılar','Battaniye ve örtüler','Önceki kaynak kayıtları']:return 'softgoods'
 if x['category'] in ['Servis tabak ve kaseleri','Kokulu mumlar','Koku difüzörleri']:return 'hardgoods'
 return 'root'
def kind(x):
 n=x['name'].casefold().replace('\u0307','')
 for keys,tag in [(['lastikli','lasti̇kli̇'],'fitted_sheet'),(['çarşaf'],'flat_sheet'),(['havlu'],'towel'),(['masa örtüsü'],'tablecloth'),(['peçete'],'napkin'),(['runner'],'runner'),(['duş perdesi'],'shower_curtain'),(['kurulama bezi','tea towels'],'tea_towel'),(['mutfak önlüğü','şef seti'],'apron'),(['sabahlık'],'robe'),(['yatak şalı','yatak örtüsü'],'bedspread'),(['bebek battaniyesi'],'baby_blanket')]:
  if any(k in n for k in keys):return tag
 return x['category_id']
rows=[dict(sku=x['sku'],name=x['name'],source_url=x['url'],category=x['category'],owner=owner(x),product_type=kind(x),stage='research_pending',ready=False,official_dimensions_verified=False,source_photos_preserved=False,geometry_reviewed=False,material_reviewed=False,browser_reviewed=False,download_verified=False)for x in p]
dump(R/'production-ledger.json',dict(scope='Every remaining H&M source product, never a sample selection',initial_pending_products=736,initial_ready_products=166,initial_ready_glb_variants=167,baseline_model_count=1401,baseline_model_manifest_sha256=sha(base/'model-manifest.json'),completion_rule='All736 exact-SKU products need source evidence, reference-specific geometry/material review, browser review and download SHA verification; exceptions stay pending and never count ready.',products=rows))
dump(R/'root/source-queue-368.json',[x for x in p if owner(x)=='root'])
dump(R/'scope-check.json',dict(valid=True,total=len(rows),owners=dict(collections.Counter(x['owner']for x in rows)),categories=dict(collections.Counter(x['category']for x in rows)),textile_types=dict(collections.Counter(x['product_type']for x in rows if x['category']=='Ev tekstili')),baseline_files=[dict(path=str(f),sha256=sha(f),bytes=f.stat().st_size)for f in base.iterdir()]))
print(json.dumps({'pending':len(rows),'owners':dict(collections.Counter(x['owner']for x in rows)),'textile_types':dict(collections.Counter(x['product_type']for x in rows if x['category']=='Ev tekstili'))},ensure_ascii=False))
