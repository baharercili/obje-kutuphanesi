"""All remaining nine diffuser identities, including honest separate refill/stone components."""
import sys,math,json,hashlib
sys.dont_write_bytecode=True
import numpy as np
from PIL import Image,ImageDraw,ImageFilter,ImageFont
import engine as E
import build_batch06 as P
B=E.B;R=E.R;T=math.tau

def frozen_bowl_ring():
 glass=E.lathe('own-frosted-diffuser-with-stepped-narrow-foot-real-interior-neck-and-closed-base','glass',[(0,0),(.023,0),(.027,.001),(.028,.005),(.028,.009),(.030,.010),(.0315,.012),(.0315,.052),(.029,.055),(.010,.055),(.009,.060),(.009,.066),(.006,.066),(.006,.058),(.027,.052),(.027,.014),(.024,.008),(0,.008)],256)
 wood=E.lathe('own-open-bowl-shaped-wood-collar-with-real-central-reed-passage','wood',[(.006,.054),(.015,.054),(.019,.058),(.024,.068),(.028,.078),(.0275,.081),(.023,.080),(.020,.071),(.014,.061),(.006,.059)],256)
 oil=E.lathe('actual-fragrance-liquid-and-meniscus','oil',[(0,.008),(.0267,.008),(.0267,.046),(.026,.0463),(0,.0463)],192)
 return[glass,wood,oil]+P.reeds(.006,.235,.044,neck_height=.081),['Own stepped-foot frosted body and characteristic wide upward-open wooden bowl collar with a true central hole','Full actual glass cavity, thick base, separate liquid, and six actual round pale reeds all passing through the opening','Official6.3cm diameter and8.1cm container anchor; collar/body height assignment and full reed envelope explicitly photo-interpreted'],dict(container_dimensions_cm=[6.3,8.1,6.3],container_height_field_assignment_photo_interpreted=True,reed_count=6)

def sphere_neck():
 body=E.lathe('own-cylindrical-diffuser-with-true-neck-full-interior-and-thick-base','glass',[(0,0),(.023,0),(.0265,.001),(.0275,.003),(.0275,.080),(.026,.083),(.012,.083),(.011,.089),(.011,.094),(.008,.094),(.008,.086),(.0238,.079),(.0238,.008),(.022,.004),(0,.004)],256)
 sphere=E.lathe('separate-frosted-white-rounded-spherical-glass-neck-with-real-open-reed-passage','sphere',[(.0055,.080),(.010,.080),(.017,.084),(.021,.093),(.021,.103),(.017,.112),(.009,.115),(.0055,.115)],256)
 oil=E.lathe('actual-liquid-volume-with-level-meniscus','oil',[(0,.005),(.0235,.005),(.0235,.069),(.023,.0693),(0,.0693)],192)
 return[body,sphere,oil]+P.reeds(.009,.24,.028,neck_height=.115),['Exact5.5cm diameter and11.5cm container height; own white spherical neck is a distinct physical open glass component','Real full cylinder cavity, solid thick floor, clear liquid and six true black reeds through the neck','Own bottom fragrance lettering is intrinsic reconstructed pigment; no marketing photo, box or original reflections applied'],dict(container_dimensions_cm=[5.5,11.5,5.5],reed_count=6)

def stoneware(pot='lava'):
 if pot=='lava':
  pr=[(0,0),(.024,0),(.031,.001),(.039,.005),(.046,.014),(.049,.028),(.050,.050),(.049,.068),(.047,.079),(.045,.080),(.042,.080),(.042,.076),(.045,.064),(.046,.049),(.045,.030),(.039,.017),(.030,.010),(0,.009)]
  lidpr=[(0,.077),(.039,.077),(.042,.078),(.050,.080),(.050,.083),(.046,.085),(.017,.087),(.015,.089),(.020,.091),(.025,.098),(.027,.103),(.026,.105),(.023,.105),(.021,.101),(.017,.095),(.010,.092),(0,.092)]
  parts=[E.lathe('own-rounded-stoneware-lava-stone-container-with-real-deep-interior','ceramic',pr,256),E.lathe('separate-removable-stoneware-lid-with-actual-concave-bowl-shaped-knob','ceramic',lidpr,256)]
 else:
  pr=[(0,0),(.022,0),(.028,.001),(.035,.006),(.040,.016),(.0425,.036),(.0425,.065),(.041,.076),(.039,.079),(.0355,.079),(.0355,.075),(.0385,.064),(.0385,.037),(.036,.020),(.028,.010),(0,.008)];lidpr=[(.005,.077),(.033,.077),(.035,.078),(.0425,.079),(.0425,.081),(.037,.083),(.015,.085),(.005,.085)];parts=[E.lathe('own-rounded-stoneware-reed-diffuser-vessel-with-real-interior','ceramic',pr,256),E.lathe('separate-removable-matching-stoneware-lid-with-actual-reed-opening','ceramic',lidpr,256)]+P.reeds(.010,.235,.045,neck_height=.085)
 return parts,['Own curved stoneware body, real full interior and separately named removable fitted lid','Lava version has a genuinely concave upward-open bowl knob; reed version has a real central passage and six pale stems','Main official container metric anchors remain separate from refill-bottle and stone components, which are fully photo-scaled'],dict(lid_default_state='closed',container_dimensions_cm=[10,10.5,10]if pot=='lava'else[8.5,8.5,8.5],source_packaging_excluded=True)

def refill(large=False):
 r=.021 if large else .012;h=.079 if large else .063;bodyh=h*.72;neck=r*.42;pr=[(0,0),(r*.78,0),(r*.95,.001),(r,.003),(r,bodyh-.006),(r*.94,bodyh),(r*.60,bodyh+.006),(neck,bodyh+.012),(neck,h-.005),(neck*.68,h-.005),(neck*.68,bodyh+.012),(r*.84,bodyh-.002),(r*.84,.005),(0,.005)];glass=E.lathe('source-refill-glass-oil-bottle-with-real-shoulder-neck-full-interior-and-thick-base','bottle',pr,192);cap=E.lathe('separate-black-screw-cap-with-fine-real-vertical-flutes','black',[(0,h-.012),(neck*.95,h-.012),(neck*1.12,h-.009),(neck*1.12,h),(0,h)],192)
 for i,(x,y,z)in enumerate(cap['_vertices']):
  rad=math.hypot(x,z)
  if rad==0:continue
  a=math.atan2(z,x);rr=rad+(.00020*(.5+.5*math.cos(a*36))if y>h-.009 else 0);cap['_vertices'][i]=(rr*math.cos(a),y,rr*math.sin(a))
 oil=E.lathe('source-refill-fragrance-liquid','oil',[(0,.005),(r*.79,.005),(r*.79,bodyh-.004),(0,bodyh-.004)],160);n=80;prof=[(r+.00012,bodyh*.17),(r+.00012,bodyh*.80),(r+.00004,bodyh*.80),(r+.00004,bodyh*.17)];verts=[];uv=[];faces=[]
 for k,(rr,y)in enumerate(prof):
  for i,a in enumerate(np.linspace(math.pi/2-.63,math.pi/2+.63,n+1)):verts.append((rr*math.cos(a),y,rr*math.sin(a)));uv.append((1-i/n,1 if k in[0,3]else 0))
 for k in range(4):
  kk=(k+1)%4
  for i in range(n):a=k*(n+1)+i;b=a+1;c=kk*(n+1)+i;d=c+1;faces.extend([(a,b,c),(b,d,c)])
 for i in[0,n]:a=i;b=(n+1)+i;c=2*(n+1)+i;d=3*(n+1)+i;faces.extend([(a,b,c),(a,c,d)])
 label=E.raw('actual-conformal-curved-refill-paper-label-with-source-tiny-HMHOMEprint','paper',verts,faces,uv);return[glass,cap,oil,label],['Actual little refill glass bottle with rounded shoulder, full interior, independently solid liquid and separate fluted screw cap','Paper label conforms physically to the cylindrical front; it is not a floating rectangular flag','Accessory component axes photo-scaled against the exact ownSKUmain container, never claimed as official refill-bottle dimensions'],dict(component='separate_refill_oil_bottle',source_packaging_excluded=True,all_component_axes_photo_interpreted=True)

def own_clear_flask():
 pr=[(0,0),(.021,0),(.027,.001),(.0288,.003),(.029,.008),(.029,.024),(.0285,.032),(.026,.040),(.021,.047),(.015,.052),(.0105,.054),(.0105,.066),(.0125,.067),(.0128,.069),(.0118,.070),(.0084,.070),(.0082,.056),(.018,.049),(.023,.042),(.0255,.033),(.026,.010),(.025,.005),(0,.004)]
 glass=E.lathe('own-clear-short-round-shouldered-flask-refill-with-visible-flared-neck-rim-and-real-complete-interior','bottle',pr,256)
 cork=E.lathe('source-visible-natural-cork-stopper-under-the-black-cap','cork',[(0,.062),(.0088,.062),(.0092,.068),(.010,.069),(.010,.072),(0,.072)],192)
 cap=E.lathe('own-plain-short-black-flat-cap-above-visible-cork','black',[(0,.0705),(.0107,.0705),(.0117,.071),(.0117,.0775),(.011,.078),(0,.078)],192)
 oil=E.lathe('separate-clear-refill-liquid-with-real-level-meniscus','oil',[(0,.005),(.025,.005),(.025,.029),(.024,.034),(0,.034)],192)
 return[glass,cork,cap,oil],['Own exact photo shows a short wide round-shouldered clear flask, prominent flared glass neck, visible natural cork, and a short plain black cap','There is no paper label on this own-SKUclear refill photograph; no invented label or logo is added','All axes explicitly photo-scaled against the official8.5cmcontainer, never claimed as official bottle metrics'],dict(component='separate_refill_oil_bottle',all_component_axes_photo_interpreted=True,source_no_paper_label=True)

def lava_rock(seed):
 rng=np.random.default_rng(seed);directions=[];verts=[];uv=[];faces=[];rings=[];n=112;m=58;pits=rng.normal(size=(110,3));pits/=np.linalg.norm(pits,axis=1,keepdims=True)
 for j in range(m+1):
  b=math.pi*j/m;row=[]
  for i in range(1 if j in[0,m]else n+1):
   a=T*(i%n)/n;d=np.array([math.sin(b)*math.cos(a),math.cos(b),math.sin(b)*math.sin(a)]);macro=1+.14*math.sin(3*a+.7)*math.sin(b)**2+.10*math.sin(4*b+1.2)+.055*math.cos(11*a+7*b)+.035*math.sin(19*a-13*b);crater=np.exp(-(np.maximum(0,1-pits@d)/.0028));radius=macro-.15*float(crater.max());p=d*radius;p[1]=max(p[1],-.73);row.append(len(verts));verts.append(tuple(p));uv.append((i/n,j/m))
  rings.append(row)
 for j in range(m):
  a,b=rings[j],rings[j+1]
  for i in range(n):
   if len(a)==1:faces.append((a[0],b[i],b[i+1]))
   elif len(b)==1:faces.append((a[i],b[0],a[i+1]))
   else:faces.extend([(a[i],b[i],a[i+1]),(a[i+1],b[i],b[i+1])])
 return[E.raw('own-source-irregular-lava-chunk-with-actual-macro-craggy-contour-and-many-recessed-pores','lava',verts,faces,uv)],['Actual craggy closed rock geometry with110distinct recessed crater fields, irregular stratified silhouette and flattened resting base','Dense micro-porosity in intrinsic dark gray material without a product photo card or background projection','Own-source accessory shape and all axes explicitly photo-interpreted against the official10cmvessel'],dict(component='separate_lava_stone',all_component_axes_photo_interpreted=True,physical_pore_fields=110)

def paper_sticks():
 parts=[]
 for i in range(6):
  x=-.031+i*.062/5;parts.append(B.tube('individual-pressed-scented-paper-stick-'+str(i+1),'paperstick',[(x,0,0),(x+.00025*math.sin(i),.16,.00025),(x,.32,0)],.0025,.0025,16,False,guide=[0,0,1]))
 return parts,['All six true independent round scented paper sticks with cut ends, each32cmhigh in a6.7cmwide parallel presentation','Official total width6.7cm and total height32cm are recorded as presentation-envelope anchors, not invented per-stick diameter measurements','Matte black intrinsic paper, with tiny local bends and thickness interpreted from the exact ownSKUphotograph; external box omitted'],dict(set_quantity=6,represented_set_piece_count=6,component='six_scented_paper_sticks',official_total_dimensions_cm=[6.7,32],stick_diameter_cm_photo_interpreted=.5)

def metal_fluted():
 pr=[(0,0),(.034,0),(.041,.001),(.044,.004),(.044,.060),(.043,.063),(.040,.063),(.040,.009),(.037,.005),(0,.005)];g=E.lathe('own-short-wide-fine-fluted-glass-reed-diffuser-holder-full-interior-thick-base','glass',pr,640)
 for i,(x,y,z)in enumerate(g['_vertices']):
  rad=math.hypot(x,z)
  if rad==0:continue
  a=math.atan2(z,x);fade=min(1,max(0,(y-.004)/.003))*min(1,max(0,(.063-y)/.003));rr=rad+.001*fade*(.5+.5*math.cos(a*80))*(1 if rad>.042 else .15);g['_vertices'][i]=(rr*math.cos(a),y,rr*math.sin(a))
 lid=E.lathe('separate-polished-zinc-alloy-lid-with-real-central-reed-passage','silver',[(.006,.062),(.042,.062),(.045,.063),(.045,.0645),(.044,.065),(.006,.065)],256);oil=E.lathe('physical-clear-fragrance-liquid','oil',[(0,.005),(.0396,.005),(.0396,.025),(.039,.0252),(0,.0252)],192)
 return[g,lid,oil]+P.reeds(.010,.215,.080,'reed',neck_height=.065),['Official9cmdiameter and6.5cmcontainerheight,80real vertical flutes, full cavity and thick base','Separate polished zinc lid with true centre opening and six independent black reeds, all passing through the opening','Refill bottle is a separate photo-scaled physical component so no official container metric is incorrectly applied to an assembled display envelope'],dict(container_dimensions_cm=[9,6.5,9],reed_count=6)

BASE=E.material
def mat(pid,key,**args):
 if key=='paper':
  out,ma=BASE(pid,key,**args);im=Image.new('RGB',(2048,2048),(236,236,230));d=ImageDraw.Draw(im);font=ImageFont.truetype('/System/Library/Fonts/Helvetica.ttc',105);text='H&M HOME';box=d.textbbox((0,0),text,font=font);d.text(((2048-box[2])//2,1670),text,font=font,fill=(32,32,30));im.save(out/ma['baseColorTexture'],optimize=True);ma['extras'].update(own_sku_text_reconstructed=True,tiny_source_refill_logo_typographically_interpreted=True);return out,ma
 if key!='lava':return BASE(pid,key,**args)
 out,ma=BASE(pid,key,color=[91,88,81],rough=.90,kind='reactive');n=2048;rng=np.random.default_rng(int(pid[-5:]));height=Image.new('L',(n,n),170);d=ImageDraw.Draw(height)
 for _ in range(3100):
  x,y=rng.integers(0,n,2);rad=int(rng.integers(2,18));d.ellipse((x-rad,y-rad,x+rad,y+rad),fill=int(rng.integers(20,85)))
 h=np.array(height.filter(ImageFilter.GaussianBlur(1.3)),dtype=float)/255;rgb=np.stack([h*48+43,h*47+41,h*43+38],2).astype('uint8');dy,dx=np.gradient(h*4);normal=np.stack([-dx,-dy,np.ones_like(dx)],2);normal/=np.linalg.norm(normal,axis=2,keepdims=True);orm=np.zeros((n,n,3),np.uint8);orm[:,:,0]=np.clip(110+h*145,0,255).astype('uint8');orm[:,:,1]=235;Image.fromarray(rgb,'RGB').save(out/ma['baseColorTexture'],optimize=True);Image.fromarray(np.clip((normal+1)*127.5,0,255).astype('uint8'),'RGB').save(out/ma['normalTexture'],optimize=True);Image.fromarray(orm,'RGB').save(out/ma['metallicRoughnessTexture'],optimize=True);ma['normalScale']=.55;ma['extras']['intrinsic_source_palette_porosity']=True;return out,ma
E.material=mat

specs=[]
def add(pid,name,geo,official,locale,market,evidence,materials,estimated,extras=None,suffix='',dims=None,note=''):
 if dims is None:
  parts,_,_=geo();p=np.concatenate([g['_vertices']for g in parts]);dims=((p.max(0)-p.min(0))*100).tolist()
 label='Kâğıt %100'if pid.startswith('133405')else'Cam kap %100 · Çinko alaşımı kapak %100 · Çubuklar'if pid=='1360454001'else'Stoneware kap %100 · Cam yağ şişesi %100 · Doğal lav taşları'if pid.startswith('1333470')else'Stoneware kap %100 · Cam yağ şişesi %100 · Kamış çubuklar'if pid=='1333471001'else'Buzlu cam kap %100 · Ahşap halka ve kamış çubuklar'if pid=='1323242004'else'Cam kap %100 · Kokulu yağ ve çubuklar'
 specs.append(dict(sku=pid,name=name,dims=dims,hwd=[None,None,None],official=official,estimated=estimated,suffix=suffix,geometry=geo,size_url='https://www2.hm.com/'+locale+'/productpage.'+pid+'.html',market=market,label=label,color=name,claim='Exact SKU'+pid+' official published source anchors: '+json.dumps(official,ensure_ascii=False)+'. Main container and separate physical accessories are distinguished; all unpublished component/envelope axes are interpreted.',evidence_files=[str(R/evidence)],note='Resmî kap ölçüleri ile çubuklar dahil toplam zarf ve ayrı dolum/taş parça ölçüleri ayrı tutulur. Yayımlanmamış bütün bileşen boyları, yerel oyuk/kalınlık ve yüzey değişimleri kendi fotoğrafından yorumdur. '+note,materials=materials,metadata_extras=extras or{}))

oil=dict(color=[255,255,255],rough=.025,trans=.97,atten=[.98,.95,.80],dist=.10);reed=dict(color=[209,184,139],rough=.66,kind='wood');wickblack=dict(color=[25,24,20],rough=.85,kind='cotton');clear=dict(color=[255,255,255],rough=.045,trans=.98,atten=[.99,.99,.98],dist=.3)
add('1323242004','Buzlu cam, çanak ahşap halkalı difüzör · Patchouli Field',frozen_bowl_ring,{'container_diameter_cm':[6.3],'container_height_cm':[8.1],'net_liquid_volume_ml':100},'tr_tr','Türkiye','source-evidence/1323242004.json',{'glass':dict(color=[209,191,145],rough=.44,kind='frosted',trans=.20,atten=[.85,.77,.51],dist=.012,text='PATCHOULI|FIELD'),'wood':dict(color=[219,181,127],rough=.55,kind='wood'),'oil':oil,'reed':reed},['assembly_width_cm','assembly_height_cm','assembly_depth_cm','container_height_assignment','reed_length_and_spread'])
for pid,title,body in[('1325253001','Patchouli Vetiver',dict(color=[255,255,255],rough=.055,trans=.98,atten=[.99,.99,.97],dist=.3,kind='frosted',text='PATCHOULI|VETIVER')),('1325253002','Rose Geranium',dict(color=[237,237,231],rough=.38,trans=.10,kind='frosted',text='ROSE|GERANIUM'))]:
 add(pid,'Küre boyunlu cam çubuklu difüzör · '+title,sphere_neck,{'container_diameter_cm':[5.5],'container_height_cm':[11.5],'net_liquid_volume_ml':100},'tr_tr','Türkiye','source-evidence/'+pid+'.json',{'glass':body,'sphere':dict(color=[239,239,232],rough=.40,trans=.10,kind='frosted'),'oil':oil,'reed':wickblack},['assembly_width_cm','assembly_height_cm','assembly_depth_cm','reed_length_and_spread'])

for pid,title,col in[('1333470001','Salted Sea',[235,232,220]),('1333470002','Papyrus Oud',[137,120,104])]:
 official={'main_container_diameter_cm':[10],'main_container_height_cm':[10.5],'net_oil_volume_ml':15};add(pid,'Lav taşlı difüzör seti · Kap ve kapak · '+title,lambda:stoneware('lava'),official,'en_us','United States','research-fragrance-04.txt',{'ceramic':dict(color=col,rough=.48,kind='reactive')},[],extras=dict(component='main_lidded_stoneware_container',other_set_components_separate_models=True),dims=[10,10.5,10])
 add(pid,'Lav taşlı difüzör · 15 ml yağ şişesi · '+title,lambda:refill(False),official,'en_us','United States','research-fragrance-04.txt',{'bottle':dict(color=[255,255,255],rough=.04,trans=.98,atten=[.04,.035,.025],dist=.003),'black':dict(color=[18,18,16],rough=.24),'oil':oil,'paper':dict(color=[236,236,230],rough=.83)},['width_cm','height_cm','depth_cm','all_accessory_axes_photo_scaled'],suffix='-yag-sisesi',dims=[2.6,6.3,2.6])
 for j,dims in enumerate([[4.3,3.8,3.1],[2.7,1.9,2.2]],1):add(pid,'Lav taşlı difüzör · Gözenekli taş '+str(j)+' · '+title,lambda j=j:lava_rock(983+j),official,'en_us','United States','research-fragrance-04.txt',{'lava':dict(color=[91,88,81],rough=.9)},['width_cm','height_cm','depth_cm','all_lava_stone_axes_photo_scaled'],suffix='-lav-tasi-'+str(j),dims=dims)

add('1333471001','Kapaklı stoneware çubuklu difüzör · Salted Sea',lambda:stoneware('reed'),{'container_diameter_cm':[8.5],'container_height_cm':[8.5]},'en_us','United States','research-fragrance-04.txt',{'ceramic':dict(color=[235,232,220],rough=.48,kind='reactive'),'reed':reed},['assembly_width_cm','assembly_height_cm','assembly_depth_cm','reed_length_and_spread'])
add('1333471001','Stoneware difüzör · Ayrı yağ dolum şişesi',own_clear_flask,{'source_main_container_diameter_cm':[8.5],'source_main_container_height_cm':[8.5]},'en_us','United States','research-fragrance-04.txt',{'bottle':clear,'black':dict(color=[18,18,16],rough=.24),'cork':dict(color=[211,184,134],rough=.78,kind='wood'),'oil':oil},['width_cm','height_cm','depth_cm','all_accessory_axes_photo_scaled'],suffix='-yag-sisesi',dims=[5.8,7.8,5.8])
for pid,title,locale,market,evidence in[('1334051002','Rose Geranium','tr_tr','Türkiye','source-evidence/1334051002.json'),('1334051003','Cedarwood Pepper','ja_jp','Japan','research-fragrance-05.txt')]:add(pid,'6’lı kokulu kâğıt çubuk · '+title,paper_sticks,{'total_width_cm':[6.7],'total_height_cm':[32],'piece_count':6,'composition':'paper100%'},locale,market,evidence,{'paperstick':dict(color=[27,26,24],rough=.9,kind='cotton')},['depth_cm','individual_stick_diameter_and_spacing'],dims=[6.7,32,.53])
add('1360454001','Oluklu cam, gümüş renk kapaklı çubuklu difüzör · Rich Amber',metal_fluted,{'container_diameter_cm':[9],'container_height_cm':[6.5]},'en_us','United States','research-fragrance-05.txt',{'glass':clear,'silver':dict(color=[205,207,204],rough=.13,metal=1),'oil':oil,'reed':wickblack},['assembly_width_cm','assembly_height_cm','assembly_depth_cm','reed_length_and_spread'])
add('1360454001','Rich Amber difüzör · Ayrı yağ dolum şişesi',lambda:refill(True),{'source_main_container_diameter_cm':[9],'source_main_container_height_cm':[6.5]},'en_us','United States','research-fragrance-05.txt',{'bottle':clear,'black':dict(color=[233,229,207],rough=.38),'oil':dict(color=[255,255,255],rough=.025,trans=.97,atten=[.95,.80,.12],dist=.04),'paper':dict(color=[236,236,230],rough=.83)},['width_cm','height_cm','depth_cm','all_accessory_axes_photo_scaled'],suffix='-yag-sisesi',dims=[4.2,7.9,4.2])

if __name__=='__main__':
 for s in specs:
  if len(sys.argv)==1 or s['sku']in sys.argv[1:]:E.build(s)
