"""Source-specific production engine. No writes outside this new hardgoods folder."""
from pathlib import Path
import sys,json,math,hashlib,shutil,importlib.util
sys.dont_write_bytecode=True
import numpy as np
from PIL import Image,ImageDraw,ImageFont
R=Path(__file__).resolve().parent;PREV=R.parents[1]/'2026-10-23-hardgoods'
spec=importlib.util.spec_from_file_location('read_only_prior_hardgoods',PREV/'build_hardgoods.py');G=importlib.util.module_from_spec(spec);spec.loader.exec_module(G)
B=G.B;H=G.H;M=G.M;T=math.tau
sha=G.sha;dump=G.dump;raw=G.raw
SOURCES={p['sku']:p for p in json.loads((R/'source-queue-72.json').read_text())['products']}
MASTERS=json.loads((R/'original-image-masters.json').read_text())
if(R/'original-image-gallery-masters.json').exists():MASTERS+=json.loads((R/'original-image-gallery-masters.json').read_text())
def lathe(name,mat,profile,n=192):
 g=B.lathe(name,mat,profile,n,profile[0][0]!=0 and profile[-1][0]!=0);ys=[p[1]for p in profile];height=max(ys)-min(ys);g['_uvs']=[(.5-u,1-(y-min(ys))/max(height,.000001))for(u,v),(x,y,z)in zip(g['_uvs'],g['_vertices'])];return g

def material(pid,key,color,rough=.4,kind='solid',metal=0,trans=0,atten=None,dist=.1,text=None):
 out=R/'materials'/pid;out.mkdir(parents=True,exist_ok=True);n=2048;rng=np.random.default_rng(int(hashlib.sha256((pid+key).encode()).hexdigest()[:8],16));u=np.arange(n,dtype=np.float32)[None,:]/n;v=np.arange(n,dtype=np.float32)[:,None]/n;rgb=np.broadcast_to(np.array(color,np.float32),(n,n,3)).copy();height=np.zeros((n,n),np.float32);rr=np.full((n,n),rough,np.float32);alpha=None
 def noise(k):return np.asarray(Image.fromarray(rng.normal(0,1,(k,k)).astype(np.float32),'F').resize((n,n),Image.Resampling.BICUBIC))
 if kind=='wood':
  warp=u+.010*np.sin(T*v*1.5)+noise(11)*.002;grain=np.sin(T*warp*31)+.35*np.sin(T*warp*103)+noise(99)*.3;rgb+=grain[:,:,None]*np.array([5.5,4,2.5])+noise(13)[:,:,None]*2;height=grain*.008;rr+=grain*.012
 elif kind=='reactive':
  cloud=noise(11)*.6+noise(47)*.3;fine=rng.normal(0,1,(n,n)).astype(np.float32);rgb+=cloud[:,:,None]*4+fine[:,:,None]*.4;fleck=(rng.random((n,n))>.9975);rgb[fleck]-=[13,14,13];height=fine*.006+fleck*.015;rr+=cloud*.014
 elif kind=='wax':
  cloud=noise(21);rgb+=cloud[:,:,None]*.7;rr+=cloud*.007;height=noise(171)*.003
 elif kind=='cotton':
  thread=np.sin(T*v*900)*.5+noise(74)*.4;rgb+=thread[:,:,None]*3;height=thread*.008
 elif kind=='frosted':
  fine=rng.normal(0,1,(n,n)).astype(np.float32);height=fine*.007;rr+=fine*.007
 if kind=='frosted'and text:
  image=Image.fromarray(np.clip(rgb,0,255).astype('uint8'),'RGB');font='/System/Library/Fonts/Times.ttc'
  for i,line in enumerate(text.split('|')):
   f=ImageFont.truetype(font,420);tmp=Image.new('L',(2500,600));draw=ImageDraw.Draw(tmp);box=draw.textbbox((0,0),line,font=f);draw.text((-box[0],-box[1]),line,font=f,fill=255);tw=min(230,20*len(line)+5);th=85;mask=tmp.crop((0,0,box[2]-box[0],box[3]-box[1])).resize((tw,th),Image.Resampling.LANCZOS);x=512-tw//2;y=1480+i*95;image.paste((104,90,66),(x,y,x+tw,y+th),mask)
  rgb=np.array(image,dtype=np.float32)
 if kind in['paperlabel','ink']:
  if kind=='ink':alpha=np.zeros((n,n),np.uint8)
  image=Image.fromarray(np.clip(rgb,0,255).astype('uint8'),'RGB');draw=ImageDraw.Draw(image);font='/System/Library/Fonts/Helvetica.ttc'
  if kind=='paperlabel':
   master=next(q for q in MASTERS if q['sku']==pid);source=np.array(Image.open(master['path']).convert('RGB'));yy,xx=np.ogrid[:source.shape[0],:source.shape[1]];mask=(source.max(2)<125)&(xx>=420)&(xx<=1130)&(yy>=1335)&(yy<=1540);uu=np.broadcast_to(u,(n,n));vv=np.broadcast_to(v,(n,n));angle=T*(uu-.25);sx=np.rint(768+400*np.sin(angle)).astype(int);sy=np.rint(1260+45*np.cos(angle)+vv*275).astype(int);sample=mask[np.clip(sy,0,source.shape[0]-1),np.clip(sx,0,source.shape[1]-1)];sample&=(uu>0)&(uu<.5);arr=np.array(image);arr[sample]=[34,34,31];image=Image.fromarray(arr,'RGB');dump(out/(pid+'-paper-label-pattern-provenance.json'),dict(master=master['path'],master_sha256=master['sha256'],master_unchanged=sha(master['path'])==master['sha256'],method='Black print mask only from exactSKUwhitepaperlabel; intrinsic white paper and ink palette. Inverse cylindrical projection. No source RGB lighting, glass or marketing background is copied.',source_effective_detail_pixels=[710,275],output_canvas_pixels=[2048,2048],geometric_resampling_count=1,source_detail_upgraded=False))
  else:
   mask=Image.new('L',(n,n));md=ImageDraw.Draw(mask);parts=(text or '').split('|')
   for i,line in enumerate(parts):
    f=ImageFont.truetype('/System/Library/Fonts/Times.ttc',180);tmp=Image.new('L',(2000,400));td=ImageDraw.Draw(tmp);box=td.textbbox((0,0),line,font=f);td.text((-box[0],-box[1]),line,font=f,fill=255);targetw=min(230,20*len(line)+5);targeth=600;tmp=tmp.crop((0,0,box[2]-box[0],box[3]-box[1])).resize((targetw,targeth),Image.Resampling.LANCZOS);mask.paste(tmp,(512-targetw//2,390+i*660))
   alpha=np.array(mask);rgb[:]=color
  if kind=='paperlabel':rgb=np.array(image,dtype=np.float32)
 dy,dx=np.gradient(height);normal=np.stack([-dx,-dy,np.ones_like(dx)],2);normal/=np.linalg.norm(normal,axis=2,keepdims=True);orm=np.zeros((n,n,3),np.uint8);orm[:,:,0]=255;orm[:,:,1]=np.clip(rr*255,8,250).astype('uint8');orm[:,:,2]=int(metal*255);base=np.clip(rgb,0,255).astype('uint8')
 if alpha is not None:base=np.dstack((base,alpha))
 name=pid+'-'+key
 for slot,array in[('albedo',base),('normal',np.clip((normal+1)*127.5,0,255).astype('uint8')),('orm',orm)]:Image.fromarray(array).save(out/(name+'-'+slot+'.png'),optimize=True)
 ma=dict(baseColorFactor=[1,1,1,1],baseColorTexture=name+'-albedo.png',normalTexture=name+'-normal.png',metallicRoughnessTexture=name+'-orm.png',normalScale=.16,metallic=1,roughness=1,doubleSided=False,alphaMode='MASK'if alpha is not None else'OPAQUE',extras=dict(intrinsic_material=True,photo_pixels_baked=False,baked_reflections=False,native_resolution=2048,appearance_photo_interpreted=True,own_sku_text_reconstructed=kind in['ink','paperlabel']))
 if alpha is not None:ma['alphaCutoff']=.5
 if trans:ma.update(transmission=trans,ior=1.5,thickness=.003,attenuationColor=atten or[.99,.99,.99],attenuationDistance=dist)
 return out,ma

def build(spec):
 pid=spec['sku'];source=SOURCES[pid];suffix=spec.get('suffix','');w,h,d=spec['dims'];fmt=lambda x:format(x,'g').replace('.','p');id='hm-'+pid+suffix+'-h'+fmt(h)+'-w'+fmt(w)+'-d'+fmt(d)
 for p in R.glob('frozen-*-manifest.json'):
  if id in {e['id']for e in json.loads(p.read_text())}:raise RuntimeError('Refusing to modify frozen reviewed asset '+id)
 out=R/'models'/id;out.mkdir(parents=True,exist_ok=True);parts,features,extras=spec['geometry']();positions=np.concatenate([g['_vertices']for g in parts]);lo=positions.min(0);hi=positions.max(0);scale=np.array(spec['dims'])/100/(hi-lo);centre=np.array([(lo[0]+hi[0])/2,lo[1],(lo[2]+hi[2])/2]);meshes=[];checks=[]
 for g in parts:
  g['_vertices']=[tuple((np.array(v)-centre)*scale)for v in g['_vertices']];g=H.orient(g);mesh,check=G._finalize(g);H.S.flatcap_normals(mesh);meshes.append(mesh);checks.append(check)
 repairs=M.ensure_uv_faces(meshes)+H.ensure_float32_uv(meshes);mats={};maps=[]
 for key,args in spec['materials'].items():
  folder,ma=material(pid,key,**args);mats[key]=ma
  for slot in['baseColorTexture','normalTexture','metallicRoughnessTexture']:
   src=folder/ma[slot];dst=out/src.name;shutil.copyfile(src,dst);maps.append(dict(material=key,slot=slot,path=str(dst),sha256=sha(dst),native_resolution=list(Image.open(dst).size)))
 own=[m for m in MASTERS if m['sku']==pid];assert own;im=own[0];evidence=R/'source-evidence'/(id+'.json');evidence.parent.mkdir(exist_ok=True);live_source=any(Path(p).suffix=='.json'and Path(p).exists()and json.loads(Path(p).read_text()).get('method')=='public_live_browser_dom'for p in spec.get('evidence_files',[]));claim=dict(sku=pid,identity_verified=True,official_url=spec['size_url'],observed_date='2026-10-23',method='official_live_public_pdp_dom_and_preserved_gallery'if live_source else'official_public_indexed_pdp_text_and_gallery_descriptions',official_measurements=spec['official'],material_summary=spec['label'],measurement_summary=spec['claim'],source_market=spec['market'],local_original_photos=own,additional_evidence_files=spec.get('evidence_files',[]));dump(evidence,claim)
 extras.update(spec.get('metadata_extras',{}))
 note=spec['note']+' Üretici CAD veya taraması değildir.';meta=dict(id=id,sku=pid,brand='H&M Home',name=spec['name'],category=source['category'],url=source['url'],dimensions_cm=spec['dims'],source_dimensions_hwd_cm=spec.get('hwd',[None,None,None]),official_measurements=spec['official'],estimated_dimensions=bool(spec.get('estimated')),estimated_fields=spec.get('estimated',[]),diameter_semantics=note,scale_note=note,material_label=spec['label'],color=spec['color'],source_market=spec['market'],source_size_pointer=str(evidence)+'#official_measurements',source_evidence_files=[str(evidence),*spec.get('evidence_files',[])],source_images=[dict(url=q['url'],alt=q['alt'])for q in own],original_image=im['path'],original_image_url=im['url'],original_image_sha256=im['sha256'],original_images=[{k:q[k]for k in['path','url','sha256']}for q in own],variant_status_verbatim=('Resmî aynı SKU kimliği doğrulandı; bütün metrik eksenler kendi fotoğrafından yaklaşık kurulmuştur.' if {'width_cm','height_cm','depth_cm'}.issubset(set(spec.get('estimated',[]))) else 'Resmî aynı SKU fiziksel ölçü ankrajı doğrulandı; yayımlanmamış ayrıntılar ayrıca belirtilmiştir.'),units='metres',up_axis='Y',origin='bottom bounding-box centre',photo_pixels_baked=False,baked_reflections=False,source_anomalies=spec.get('anomalies',[]),native_texture_resolution='Each native texture size is recorded; no original source JPEG is enlarged.',geometry_limitations=['Unlabelled wall, floor, lid and wick dimensions and local surface variation are exact-source-photo interpretations.'],source_gallery_note='All cited original category/gallery JPEG masters remain immutable at their native resolution. Exact own-SKU publicly indexed evidence and any recorded normal live PDP observations are separately identified in source_evidence_files.');meta.update(extras)
 if any(m.get('transmission',0)>0 for m in mats.values()):meta.update(quality_status='preview_limited',quality_label='Yaklaşık cam görünümü',quality_note='Camın renk, yansıma ve kırılması tarayıcıda yaklaşık gösterilir; gerçek malzemeli GLB’yi proje ışığında değerlendirin.')
 dump(out/'model.json',dict(metadata=meta,materials=mats,meshes=meshes));dump(out/'geometry-validation.json',dict(valid=True,features=features,mesh_count=len(meshes),meshes=checks,closed_material_solids=True,triangles=sum(c['triangles']for c in checks),uv_repairs=repairs));dump(out/'material-validation.json',dict(valid=True,maps=maps,source_masters_unchanged=all(sha(x['path'])==x['sha256']for x in own),photo_rgb_projected=False))
 report=G.export_assets(out/'model.json',out,id);glb=out/(id+'.glb');doc,binary=G.read_glb(glb);doc['samplers']=[dict(magFilter=9729,minFilter=9987,wrapS=10497,wrapT=10497)]
 for tex in doc.get('textures',[]):tex['sampler']=0
 binary=M.embed_tangents(doc,binary);G.write_glb(glb,doc,binary);report['deliverable_sha256']['glb']=sha(glb);report['glb_bytes']=glb.stat().st_size;dump(report['files']['validation'],report)
 fields=['id','sku','brand','name','category','url','dimensions_cm','source_dimensions_hwd_cm','official_measurements','estimated_dimensions','estimated_fields','diameter_semantics','scale_note','material_label','color','source_market','source_size_pointer','source_evidence_files','source_images','original_image','original_image_url','original_image_sha256','original_images','variant_status_verbatim'];entry={k:meta[k]for k in fields};entry.update(extras);entry.update({k:meta[k]for k in['quality_status','quality_label','quality_note','source_anomalies']if k in meta});entry.update(asset_dir=str(out),model_path=str(out/'model.json'),glb_path=str(glb),sha256=sha(glb),bytes=glb.stat().st_size,model_revision='hm-production-hardgoods-2026-10-23-source-specific-v1',geometry_validation=str(out/'geometry-validation.json'),material_validation=str(out/'material-validation.json'),size_source_kind='official_tr_public_pdp'if'/tr_tr/'in spec['size_url']else'official_other_market_same_exact_sku',size_source_urls=[spec['size_url']],model_status='candidate_pending_independent_and_native_review');dump(out/'entry.json',entry)
 manifest=json.loads((R/'manifest.json').read_text())if(R/'manifest.json').exists()else[];manifest=[e for e in manifest if e['id']!=id]+[entry];dump(R/'manifest.json',manifest);print('BUILT',id,entry['bytes'],flush=True)
