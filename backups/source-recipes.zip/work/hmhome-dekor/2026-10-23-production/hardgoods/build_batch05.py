"""Complete remaining nine serving SKUs, including all physical pieces of both three-plate sets."""
import sys,math,json
sys.dont_write_bytecode=True
import numpy as np
from PIL import Image,ImageDraw,ImageFilter
import engine as E
import build_batch02 as P
B=E.B;T=math.tau;R=E.R

def lowbowl(style):
 if style=='deep_plate':
  pr=[(0,.001),(.043,.001),(.050,0),(.055,0),(.056,.002),(.068,.005),(.083,.016),(.097,.032),(.105,.043),(.1048,.045),(.101,.045),(.096,.039),(.081,.025),(.065,.013),(.050,.007),(0,.006)]
 else:
  pr=[(0,.001),(.035,.001),(.044,0),(.049,0),(.050,.002),(.056,.009),(.060,.022),(.064,.032),(.070,.036),(.0725,.0368),(.0725,.038),(.070,.038),(.064,.034),(.060,.028),(.056,.017),(.049,.009),(.036,.006),(0,.006)]
 return[E.lathe('own-'+style+'-porcelain-or-stoneware-piece-full-interior-rounded-lip-and-low-foot','glaze',pr,256)],['Real open concave interior, finite floor/sidewall and broad classic rim or own flared deep-plate profile','Official diameter and height anchors kept, including both published unlabelled diameters for the deep plate','Local glazed rim, foot and thickness are own-source photo interpretations; retail quantity is separately recorded'],dict(local_wall_floor_and_rim_photo_interpreted=True)

def footed_glass():
 pr=[(0,0),(.060,0),(.069,.002),(.070,.004),(.068,.008),(.055,.011),(.035,.016),(.023,.025),(.021,.048),(.023,.060),(.037,.066),(.067,.068),(.105,.082),(.140,.104),(.1535,.110),(.1535,.116),(.149,.117),(.139,.109),(.103,.088),(.065,.075),(.035,.072),(0,.072)];g=E.lathe('own-mouth-blown-irregular-smoked-glass-footed-serving-bowl-with-real-cavity-and-connected-pedestal','glass',pr,384)
 for i,(x,y,z)in enumerate(g['_vertices']):
  rad=math.hypot(x,z)
  if rad==0:continue
  a=math.atan2(z,x);fade=max(0,min(1,(rad-.065)/.09));wave=fade*(.0068*math.sin(3*a+.7)+.0038*math.cos(5*a-.3));rr=rad*(1+fade*(.024*math.sin(3*a)+.011*math.cos(5*a)));g['_vertices'][i]=(rr*math.cos(a),y+wave,rr*math.sin(a))
 return[g],['Single continuous closed glass body, physical foot and connecting stem, shallow real bowl interior and naturally waved lip','ExactSKUofficial30.7cm maximum diameter and13.5cm overall height; handmade wave/local depths photo-interpreted','Intrinsic deep smoked-gray transmission and volume absorption; original scene/pears/lighting omitted'],dict(handmade_asymmetry_photo_interpreted=True,source_packaging_excluded=True)

def emboss_height():
 path=R/'materials'/'1301745003';path.mkdir(parents=True,exist_ok=True);im=Image.new('L',(1024,1024));d=ImageDraw.Draw(im)
 # Manual own-gallery tracing of head, eye, concentric gills, interlocking scales and fin striations.
 d.arc((55,180,500,875),250,105,fill=255,width=7);d.arc((115,240,480,835),270,90,fill=255,width=8);d.ellipse((207,285,265,343),outline=255,width=8);d.ellipse((225,302,246,325),fill=180);d.line([(65,500),(179,521),(195,535)],fill=255,width=7)
 for j in range(15):
  a=-1.15+j*2.3/14;x=365+100*math.cos(a);z=530+230*math.sin(a);d.line([(x-28,z),(x+10,z-2)],fill=210,width=4)
 for col in range(5):
  for row in range(6):
   cx=390+col*91;cz=190+row*107+(col%2)*52
   if((cx-512)/510)**2+((cz-512)/510)**2>.76:continue
   d.arc((cx-50,cz-55,cx+59,cz+55),265,95,fill=255,width=8)
 for i in range(93):
  a=T*i/93
  if math.cos(a)<-.55:continue
  points=[]
  for q in np.linspace(0,1,15):rr=405+87*q;aa=a+.10*(1-q);points.append((512+rr*math.cos(aa),512+rr*math.sin(aa)))
  d.line(points,fill=240,width=5)
 d.arc((715,168,1005,795),95,260,fill=230,width=7);d.arc((745,210,980,845),100,258,fill=230,width=7);im=im.filter(ImageFilter.GaussianBlur(1.6));im.save(path/'own-gallery-traced-fish-emboss-height.png');master=next(q for q in E.MASTERS if q['sku']=='1301745003'and q.get('kind')=='official_same_sku_pdp_gallery');E.dump(path/'emboss-vector-provenance.json',dict(master=master['path'],master_sha256=master['sha256'],master_unchanged=E.sha(master['path'])==master['sha256'],method='Own official gallery fish relief manually traced as vector head, eye, gill, scale and fin curves. Not a luminance or marketing RGB projection; relief depths are interpreted.',vector_canvas_pixels=[1024,1024],source_pixel_resampling_count=0,maximum_relief_m=.00055));return np.array(im,dtype=float)/255

def embossed_plate():
 image=emboss_height();pr=[(0,.001),(.043,.001),(.051,0),(.059,0),(.063,.002),(.078,.009),(.088,.017),(.0925,.020),(.0925,.022)]
 for r in np.linspace(.0920,.001,160):pr.append((float(r),.0055+.0160*(r/.0925)**4))
 pr.append((0,.0055));g=B.lathe('actual-dished-porcelain-plate-with-continuous-physical-fish-scale-eye-gill-and-fin-relief','glaze',pr,384,False)
 k=0;upper_start=sum(1 if rr==0 else 385 for rr,_ in pr[:9])
 for radius,y in pr:
  count=1 if radius==0 else 385
  for i in range(count):
   x,yy,z=g['_vertices'][k];u=x/.185+.5;v=z/.185+.5
   if y<.022 and k>upper_start:yy+=.00055*image[min(1023,max(0,round(v*1023))),min(1023,max(0,round(u*1023)))]
   g['_vertices'][k]=(x,yy,z);g['_uvs'][k]=(u,v);k+=1
 return[g],['Official18.5cm diameter and2.2cm height, real shallow serving well, rounded edge and underside foot','Actual continuous geometric relief, not a color photograph: own-gallery-traced fish eye/head/gills/scales and fine fin striations','White intrinsic porcelain glaze with no scene RGB or baked lighting;0.55mm maximum relief and tracing are declared own-photo interpretations'],dict(physical_emboss_maximum_m=.00055,fish_pattern_method='Own exact gallery manual vector tracing displaced into the continuous upper ceramic surface',emboss_profile_photo_interpreted=True)

specs=[]
def add(pid,title,dims,geo,locale,market,official,evidence,col,label='Porselen %100 · Parlak sır',estimated=None,suffix='',note=None,extras=None):
 specs.append(dict(sku=pid,name=title,dims=dims,hwd=[dims[1],None,None],official=official,estimated=estimated or[],suffix=suffix,geometry=geo,size_url='https://www2.hm.com/'+locale+'/productpage.'+pid+'.html',market=market,label=label,color=title,claim='Exact SKU'+pid+' official metrics: '+json.dumps(official,ensure_ascii=False)+'. '+label+'. Unpublished local profile/height assignments are photo-interpreted.',evidence_files=[str(R/evidence)],note=note or'AynıSKU’nun resmî ölçü ankrajları korunur. Yayımlanmamış yerel iç oyuk, taban/duvar ve kenar profili kendi fotoğraflarından yorumdur; resmî CAD ölçümü değildir.',materials={'glaze':dict(color=col,rough=.23,kind='reactive')},metadata_extras=extras or{}))

add('1297197002','2’li reaktif sırlı çukur tabak · tek parça',[21,4.5,21],lambda:lowbowl('deep_plate'),'en_ie','Ireland',{'unlabelled_diameters_cm':[11,21],'height_cm':[4.5]},'research-serving-01.txt',[220,211,189],label='Stoneware %100 · Açık bej reaktif sır',estimated=['assignment_of_unlabelled_diameter_11_to_base_and_21_to_rim'],note='ResmîaynıSKU11cm ve21cm olarak iki niteliksiz çap,4,5cm yükseklik yayımlar. Fotoğraf oranları nedeniyle21cm dışağız,11cm taban çapı olarak yorumlandı; bu alan ataması üreticinin açıkça etiketlediği anlam değildir. İki sayının ikisi de kaynakta korunur. Duvar/ayak fotoğraf yorumudur.',extras=dict(set_quantity=2,represented_set_piece_count=1,interpreted_base_diameter_cm=11,interpreted_outer_diameter_cm=21))
add('1301745003','Kabartma balık desenli porselen servis tabağı',[18.5,2.2,18.5],embossed_plate,'en_us','United States',{'diameter_cm':[18.5],'height_cm':[2.2]},'research-serving-01.txt',[235,230,213])
add('1304537007','2’li küçük toprak rengi stoneware kase · tek parça',[13,5,13],lambda:P.bowl('cylinder'),'tr_tr','Türkiye',{'diameter_cm':[13],'height_cm':[5],'set_quantity':2},'source-evidence/1304537007.json',[153,137,122],label='Stoneware %100 · Parlak toprak rengi sır',extras=dict(set_quantity=2,represented_set_piece_count=1))
add('1334632001','Düzensiz dalgalı ayaklı cam servis tabağı',[30.7,13.5,30.7],footed_glass,'tr_tr','Türkiye',{'diameter_cm':[30.7],'height_cm':[13.5]},'source-evidence/1334632001.json',[255,255,255],label='Üfleme cam %100 · Koyu gri',estimated=['irregular_depth_and_wave_profile'])
specs[-1]['materials']={'glass':dict(color=[255,255,255],rough=.045,trans=.98,atten=[.040,.047,.040],dist=.004)}
add('1334637001','Dalgalı klasik kenarlı porselen servis tabağı',[27,2.5,15.7],lambda:P.plate('cloud'),'ja_jp','Japan',{'length_cm':[27],'width_cm':[15.7]},'research-serving-03.txt',[238,237,232],estimated=['height_cm','photo_interpreted_cloud_contour'],note='Resmî27cm uzunluk ve15,7cm genişlik korunur.2,5cm yükseklik, dalgalı bulut konturu ve yerel oyuk fotoğraf yorumudur; üreticinin yayımladığı yükseklik değildir.')
for pid,col in[('1336698001',[239,237,228]),('1336698003',[220,216,204])]:add(pid,'2’li klasik kenarlı küçük porselen kase · tek parça',[14.5,3.8,14.5],lambda:lowbowl('classic_rim'),'tr_tr','Türkiye',{'diameter_cm':[14.5],'height_cm':[3.8],'set_quantity':2},'source-evidence/'+pid+'.json',col,extras=dict(set_quantity=2,represented_set_piece_count=1))
for pid,col,locale,market,evidence in[('1336700001',[239,237,228],'tr_tr','Türkiye','source-evidence/1336700001.json'),('1336700003',[220,216,204],'tr_tr','Türkiye','research-serving-04.txt')]:
 for j,(length,width,height,name)in enumerate([(14.5,13.3,1.8,'Küçük'),(19.6,18,2,'Orta'),(25.5,23.4,2.2,'Büyük')],1):
  add(pid,'3’lü porselen servis tabağı seti · '+name,[length,height,width],lambda:P.plate('oval'),locale,market,{'piece_length_cm':[length],'piece_width_cm':[width],'all_set_piece_length_width_cm':[[14.5,13.3],[19.6,18],[25.5,23.4]],'set_quantity':3},evidence,col,estimated=['height_cm','local_plate_profile'],suffix='-parca'+str(j),note='ResmîaynıSKU’nun ilgili fiziksel parçasına ait uzunluk ve genişlik korunur. '+str(height)+'cm yükseklik ve yerel içoyuk/ayak kendi fotoğraflarından yorumdur; üretici yükseklik yayımlamamıştır. Üç set boyunun tamamı ayrı fiziksel parça modeli olarak sunulur.',extras=dict(set_quantity=3,represented_set_piece_count=1,represented_piece=name))

if __name__=='__main__':
 for s in specs:
  if len(sys.argv)==1 or s['sku']in sys.argv[1:]:E.build(s)
