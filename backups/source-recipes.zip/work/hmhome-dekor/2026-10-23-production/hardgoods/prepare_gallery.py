from pathlib import Path
import json,hashlib,urllib.request,io
from PIL import Image
R=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
rows=[('1323652001','https://image.hm.com/assets/hm/40/42/4042b0e91d746e81c762331a4a4d05d54375b821.jpg?imwidth=2160','en_us','A cream-colored oval platter is laid flat, showcasing a blue fish illustration. The design outlines the fish head with an eye, scales, fins, and tail.'),('1301745003','https://image.hm.com/assets/hm/a8/96/a89605aefa47fca7feb7673e1827a0d8ca0068dd.jpg?imwidth=2160','en_us','An off-white ceramic plate showcases a raised embossed fish design, distinct scales, fins, tail, facing left.'),('1334639001','https://image.hm.com/assets/hm/9f/2f/9f2fb789f60c9fd01bde075a1b91ad079b5327c0.jpg?imwidth=2160','es_es','A white cloud-shaped plate faces forward, with scalloped edges and a smooth glossy finish.')]
out=json.loads((R/'original-image-gallery-masters.json').read_text())if(R/'original-image-gallery-masters.json').exists()else[]
for sku,url,locale,alt in rows:
 p=R/'originals'/(sku+'-'+hashlib.sha256(url.encode()).hexdigest()[:12]+'.jpg')
 if not p.exists():
  data=urllib.request.urlopen(url,timeout=40).read();Image.open(io.BytesIO(data)).verify();p.write_bytes(data)
 im=Image.open(p);row=dict(sku=sku,url=url,alt=alt,path=str(p),sha256=sha(p),pixels=list(im.size),format=im.format,mode=im.mode,icc_profile_present=bool(im.info.get('icc_profile')),exif_orientation=im.getexif().get(274),original_bytes_unmodified=True,kind='official_same_sku_pdp_gallery',source_product_url='https://www2.hm.com/'+locale+'/productpage.'+sku+'.html',source_evidence_method='Indexed official public PDP gallery image link exposed by web tool; native delivered JPEG bytes preserved without changing resolution.')
 old=next((x for x in out if x['url']==url),None)
 assert old is None or old['sha256']==row['sha256']
 if old is None:out.append(row)
 print(sku,im.size,row['sha256'])
(R/'original-image-gallery-masters.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
