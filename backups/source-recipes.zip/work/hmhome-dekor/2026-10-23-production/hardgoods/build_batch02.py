"""All faithfully interpretable serving forms with per-exact-SKU official dimensions."""
import sys,math,json
from pathlib import Path
sys.dont_write_bytecode=True
import numpy as np
from PIL import Image,ImageDraw,ImageFilter
import engine as E
B=E.B;T=math.tau;R=E.R

def bowl(style):
 if style=='cylinder':
  pr=[(0,0),(.052,0),(.058,.0008),(.062,.003),(.064,.007),(.065,.045),(.065,.049),(.064,.050),(.0615,.050),(.061,.048),(.061,.011),(.059,.007),(.054,.006),(0,.006)]
 elif style=='blue4':
  pr=[(0,.001),(.026,.001),(.033,.002),(.040,.008),(.048,.019),(.053,.034),(.056,.0495),(.0557,.053),(.053,.053),(.0525,.050),(.050,.035),(.045,.022),(.038,.012),(.031,.007),(0,.006)]
 elif style=='flared':
  pr=[(0,.001),(.026,.001),(.034,.002),(.043,.009),(.058,.022),(.077,.041),(.095,.057),(.100,.0585),(.100,.060),(.097,.060),(.093,.057),(.075,.041),(.056,.025),(.041,.014),(.030,.009),(0,.008)]
 else:
  pr=[(0,.001),(.026,.001),(.035,.002),(.045,.008),(.057,.021),(.067,.039),(.073,.057),(.075,.067),(.0748,.070),(.0718,.070),(.0715,.067),(.069,.057),(.064,.041),(.054,.025),(.043,.014),(.033,.008),(0,.007)]
 g=E.lathe('exact-source-'+style+'-stoneware-bowl-with-real-deep-well-and-rounded-rim','glaze',pr,256)
 return[g],['Every physical bowl has a full open interior, finite thick floor, curved underside and continuous rounded ceramic lip','Distinct cylindrical, small rounded, flared cone or nested rounded source silhouette; not a universal bowl primitive','Dimensions belong to this exact source SKU and specific physical set piece, with set quantity recorded separately','Intrinsic same-source palette and reactive-glaze variation without photographed scene lighting'],dict(source_profile=style,wall_floor_and_rim_photo_interpreted=True)

def outline(theta,kind):
 a=theta
 if kind=='capsule':
  # Unit long-axis extent1; short-axis.3775. Exact capsule intersections, straight sides plus round ends.
  rz=.3775;cx=1-rz;dx=math.cos(a);dz=math.sin(a)
  if abs(dz)>1e-12:
   r=rz/abs(dz)
   if abs(r*dx)<=cx:return r*dx,r*dz
  c=math.copysign(cx,dx);root=c*dx+math.sqrt(max(0,(c*dx)**2-c*c+rz*rz));return root*dx,root*dz
 if kind=='cloud':
  # Own gallery contour: ten gentle irregular shoulders, broad central lobe and rounded end caps.
  rr=1+.060*math.cos(6*a)+.022*math.cos(10*a)-.010*math.cos(2*a);return rr*math.cos(a),rr*.578*math.sin(a)
 if kind=='petal':
  # Eight actual source panels: two round end caps, four sloping side panels, two straight waist panels.
  points=[(1,0),(.99,.10),(.94,.21),(.86,.29),(.78,.31),(.75,.32),(.72,.36),(.63,.43),(.48,.52),(.34,.585),(.29,.58),(.26,.60),(.20,.623),(0,.624)]
  angles=np.array([math.atan2(z/.624,x)for x,z in points]);radii=np.array([math.hypot(x,z/.624)for x,z in points]);aa=math.atan2(abs(math.sin(a)),abs(math.cos(a)));rr=float(np.interp(aa,angles,radii));return rr*math.cos(a),rr*.624*math.sin(a)
 return math.cos(a),math.sin(a)

def plate(kind='oval',pattern=False):
 pr=[(0,.001),(.20,.001),(.34,0),(.48,0),(.53,.002),(.64,.005),(.76,.010),(.88,.018),(.97,.023),(.995,.025),(1,.027),(.99,.029),(.97,.030),(.93,.029),(.86,.024),(.75,.016),(.64,.010),(.53,.007),(.28,.006),(0,.006)]
 g=B.lathe('exact-source-'+kind+'-serving-plate-with-true-concave-well-rolled-lip-and-low-underside-foot','glaze',pr,384,False);g['_profile_v']=[v for u,v in g['_uvs']]
 for i,(x,y,z)in enumerate(g['_vertices']):
  rad=math.hypot(x,z);a=math.atan2(z,x);xx,zz=outline(a,kind);g['_vertices'][i]=(xx*rad,y,zz*rad)
 verts=np.array(g['_vertices']);lo=verts.min(0);hi=verts.max(0);g['_uvs']=[((x-lo[0])/(hi[0]-lo[0]),(z-lo[2])/(hi[2]-lo[2]))for x,y,z in g['_vertices']]
 if kind=='petal':
  # Actual recessed separator lines in the ceramic rim, not painted dividers.
  for i,(x,y,z)in enumerate(g['_vertices']):
   rad=math.hypot(x,z/.624);a=math.atan2(z/.624,x);joints=[math.radians(t)for t in[33,74,106,147,213,254,286,327]];sep=min(abs(math.atan2(math.sin(a-j),math.cos(a-j)))for j in joints)
   if rad>.76 and y>.014:g['_vertices'][i]=(x,y-.0023*math.exp(-(sep/.030)**2)*min(1,(rad-.76)/.1),z)
 return[g],['Real dished ceramic serving well with finite floor, shaped raised rim and underside foot','Own-source '+kind+' planform and local thickness/profile are declared photo interpretations anchored to exact official length and width','No pictured food, scene shadows, napkins or other objects are applied to geometry','Pattern uses only own exact-SKU pigment mask on an intrinsic porcelain/clay material'if pattern else'Intrinsic uniform or reactive ceramic glaze with no source RGB or baked reflections'],dict(local_plate_profile_photo_interpreted=True,source_planform=kind)

BASE=E.material
def mat(pid,key,**args):
 if key not in['crab','fish']:return BASE(pid,key,**args)
 out,ma=BASE(pid,key,color=args['color'],rough=args.get('rough',.22),kind='solid')
 master=next(q for q in E.MASTERS if q['sku']==pid and (key=='crab'or q.get('kind')=='official_same_sku_pdp_gallery'))
 src=np.array(Image.open(master['path']).convert('RGB'));box=[70,730,1490,1460]if key=='crab'else[115,1160,2045,2110];x0,y0,x1,y1=box;a=src[y0:y1,x0:x1].astype(np.float32);rr,gg,bb=a.transpose(2,0,1)
 mask=(rr>gg*1.45)&(rr>bb*1.4)&(gg<160)if key=='crab'else(bb>rr*1.15)&(bb>gg*1.01)&(rr<135)
 h,w=mask.shape;rgb=np.full((h,w,3),args['color'],np.uint8);rgb[mask]=[173,52,22]if key=='crab'else[43,43,67]
 if key=='fish':rgb=np.concatenate((rgb,np.full_like(rgb,[164,86,58])),axis=0)
 Image.fromarray(rgb,'RGB').save(out/ma['baseColorTexture'],optimize=True);normal=np.full_like(rgb,[127,127,255]);Image.fromarray(normal,'RGB').save(out/ma['normalTexture'],optimize=True);orm=np.full_like(rgb,[255,round(args.get('rough',.22)*255),0]);Image.fromarray(orm,'RGB').save(out/ma['metallicRoughnessTexture'],optimize=True);ma['extras'].update(native_resolution=[rgb.shape[1],rgb.shape[0]],source_pattern_effective_detail_pixels=[w,h],own_source_pattern_reconstructed=True)
 E.dump(out/(key+'-pigment-provenance.json'),dict(master=master['path'],master_sha256=master['sha256'],master_unchanged=E.sha(master['path'])==master['sha256'],source_native_crop_box=box,source_effective_detail_pixels=[w,h],output_pixels=[w,h],geometric_resampling_count=0,method='Exact own SKU red crab/rim or blue fish pigment mask only. Intrinsic base/ink palette; source RGB, lighting, food and surrounding scene discarded.'))
 return out,ma
E.material=mat

specs=[]
def add(pid,title,dims,geometry,locale,market,official,claim,label,color,materials,evidence,**kw):
 specs.append(dict(sku=pid,name=title,dims=dims,hwd=kw.pop('hwd',[dims[1],None,None]),official=official,geometry=geometry,size_url='https://www2.hm.com/'+locale+'/productpage.'+pid+'.html',market=market,label=label,color=color,claim=claim,evidence_files=[str(R/evidence)],note=kw.pop('note','AynıSKU resmî ölçüleri korunur. İç oyuk, kalınlık, ayak, profil ve sırın yerel değişimi kendi özgün fotoğrafından yorumdur; resmî CAD ölçümü değildir.'),materials=materials,**kw))

for j,(shade,col,rough)in enumerate([('Açık mavi',[126,157,168],.45),('Petrol mavisi',[33,69,86],.27),('Lacivert',[28,51,71],.23),('Mavi-gri',[83,108,121],.33)],1):
 add('1285227008','4’lü stoneware kase · '+shade,[11.2,5.3,11.2],lambda:bowl('blue4'),'en_ca','Canada',{'each_bowl_diameter_cm':[11.2],'each_bowl_height_cm':[5.3],'set_quantity':4},'Exact SKU1285227008: four stoneware bowls; diameter11.2cm and height5.3cm per bowl; four different blue glazes. Stoneware100%.','Stoneware %100 · Farklı mavi sırlar',shade,{'glaze':dict(color=col,rough=rough,kind='reactive')},'research-serving-01.txt',suffix='-parca'+str(j))

add('1304537001','2’li küçük beyaz stoneware kase · tek parça',[13,5,13],lambda:bowl('cylinder'),'en_us','United States',{'each_bowl_diameter_cm':[13],'each_bowl_height_cm':[5],'set_quantity':2},'Exact SKU1304537001: two small white stoneware bowls, diameter13cm, height5cm; stoneware100%.','Stoneware %100 · Beyaz','Beyaz',{'glaze':dict(color=[238,237,231],rough=.22,kind='reactive')},'research-serving-02.txt')

for pid,col,shade in[('1336722001',[114,122,111],'Adaçayı yeşili'),('1336722003',[216,205,185],'Açık bej')]:
 add(pid,'2’li geniş stoneware kase · '+shade,[20,6,20],lambda:bowl('flared'),'tr_tr','Türkiye',{'each_bowl_diameter_cm':[20],'each_bowl_height_cm':[6],'set_quantity':2},'Exact SKU'+pid+': two stoneware bowls; diameter20cm; height6cm; stoneware100%.','Stoneware %100 · Reaktif sır',shade,{'glaze':dict(color=col,rough=.30,kind='reactive')},'research-serving-05.txt')

for j,(diam,height,col,shade,rough)in enumerate([(15,7,[76,109,129],'Büyük mavi',.40),(10,5.3,[45,90,98],'Orta petrol mavisi',.23),(8.5,4.5,[128,151,160],'Küçük açık mavi',.33),(7,3.5,[29,47,69],'Mini lacivert',.19)],1):
 add('1339364003','İç içe stoneware kase seti · '+shade,[diam,height,diam],lambda:bowl('nested'),'fr_be','Belgium',{'specific_piece_diameter_cm':[diam],'specific_piece_height_cm':[height],'all_set_pieces_cm':[[15,7],[10,5.3],[8.5,4.5],[7,3.5]],'set_quantity':4},'Exact SKU1339364003: four nested stoneware bowls; large Ø15/H7, medium Ø10/H5.3, small Ø8.5/H4.5, mini Ø7/H3.5cm. Stoneware100%.','Stoneware %100 · Dört farklı mavi sır',shade,{'glaze':dict(color=col,rough=rough,kind='reactive')},'research-serving-05.txt',suffix='-parca'+str(j))

def colored_plate(kind,material):
 p,f,x=plate(kind,True)
 for g in p:
  g['material']=material
  if material=='fish':g['_uvs']=[(u,v*.49 if prof>=.55 else .51+v*.49)for(u,v),prof in zip(g['_uvs'],g['_profile_v'])]
 return p,f,x

add('1277912004','Turuncu yengeç desenli oval porselen servis tabağı',[32,2.3,23],lambda:colored_plate('oval','crab'),'en_ca','Canada',{'length_cm':[32],'width_cm':[23]},'Exact SKU1277912004: oval porcelain serving plate with orange crab and orange rim; length32cm, width23cm. Porcelain100%. Height not published.','Porselen %100 · Turuncu yengeç baskısı','Beyaz/Turuncu',{'crab':dict(color=[235,234,226],rough=.21)},'research-serving-01.txt',estimated=['height_cm','local_dish_and_foot_profile'],hwd=[None,23,32],note='Resmî32cm uzunlukX ve23cm genişlikZekseninde korunur.2,3cm toplam yükseklik ve yerel oyuk/ayak profili kendi fotoğrafından yorumdur; üretici yüksekliği değildir. Turuncu pigment yalnız kendi yerel JPEG’inden ayrılır.')

for pid,col,shade,locale,market in[('1336699001',[237,235,227],'Beyaz','es_es','Spain'),('1336699003',[220,216,204],'Açık gri-bej','tr_tr','Türkiye')]:
 add(pid,'Uzun oval porselen servis tabağı · '+shade,[40,2.5,15.1],lambda:plate('capsule'),locale,market,{'length_cm':[40],'width_cm':[15.1],'height_cm':[2.5]},'Exact SKU'+pid+': minimalist elongated oval capsule porcelain serving plate; length40cm, width15.1cm, height2.5cm. Porcelain100%.','Porselen %100 · Parlak sır',shade,{'glaze':dict(color=col,rough=.21,kind='solid')},'research-serving-04.txt',hwd=[2.5,15.1,40])

add('1323652001','Elle boyanmış balık desenli terrakota servis tabağı',[50,3,26],lambda:colored_plate('oval','fish'),'en_us','United States',{'length_cm':[50],'width_cm':[26],'height_cm':[3]},'Exact SKU1323652001: hand-painted terracotta serving plate, glazed top with dark blue fish motif and unglazed terracotta underside; length50cm, width26cm, height3cm. Terracotta100%.','Terrakota %100 · Üstü beyaz sır/Mavi balık','Beyaz/Mavi/Terrakota',{'fish':dict(color=[229,225,205],rough=.26)},'research-serving-02.txt',hwd=[3,26,50],note='Resmî50×26×3cm aynen korunur. Açık tam balık deseni aynıSKU resmîPDP galerisinin özgün2160×3240JPEG’inden pigment maskesi olarak çıkarılır; ışık/zemin RGB’si uygulanmaz. Gövde ovali, derinlik ve yerel kalınlık fotoğraf yorumudur.')

add('1334639001','Dalgalı kenarlı büyük porselen servis tabağı',[45,3,26],lambda:plate('cloud'),'es_es','Spain',{'length_cm':[45],'width_cm':[26]},'Exact SKU1334639001: large classic glazed porcelain serving platter with scalloped cloud contour; length45cm, width26cm. Porcelain100%. Height not published.','Porselen %100 · Parlak beyaz sır','Beyaz',{'glaze':dict(color=[238,237,232],rough=.19)},'research-serving-03.txt',estimated=['height_cm','photo_interpreted_cloud_contour','local_dish_and_foot_profile'],hwd=[None,26,45],note='Resmî45cm uzunluk ve26cm genişlik korunur.3cm yükseklik, kendi resmîPDP açık galeri fotoğrafındaki dalgalı bulut konturu, kenar ve oyuk derinliği fotoğraftan yorumlanmıştır; yayımlanmış yükseklik değildir.')

add('1336724003','Çiçek formlu büyük sırlı terrakota servis tabağı',[50,4.5,31.2],lambda:plate('petal'),'en_us','United States',{'width_cm':[50],'depth_cm':[31.2],'height_cm':[4.5]},'Exact SKU1336724003: flower-inspired terracotta platter with reactive white glaze and molded petal rim; width50cm, depth31.2cm, height4.5cm. Terracotta100%.','Terrakota %100 · Beyaz reaktif sır','Kırık beyaz',{'glaze':dict(color=[231,227,215],rough=.25,kind='reactive')},'research-serving-05.txt',hwd=[4.5,50,31.2])

for spec in specs:
 qty=spec['official'].get('set_quantity')
 if qty:spec['metadata_extras']=dict(set_quantity=qty,represented_set_piece_count=1,represented_piece=spec.get('suffix','identical_reusable_piece'),bounds_semantics='One physical reusable piece with exact official ownSKUdimensions. Retail set quantity is separately recorded; display envelope is not an official product dimension.')

if __name__=='__main__':
 for spec in specs:
  if len(sys.argv)==1 or spec['sku']in sys.argv[1:]:E.build(spec)
