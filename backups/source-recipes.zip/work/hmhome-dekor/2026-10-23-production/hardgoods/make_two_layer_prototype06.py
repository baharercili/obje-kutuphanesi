"""Two remaining source-color/nested physical glass prototypes; no frozen edits."""
import sys,json,shutil,hashlib,importlib.util
from pathlib import Path
sys.dont_write_bytecode=True
import engine as E
import validate_independent as Q
H=E.R;D=H.parent/'decor-storage';OUT=H/'optical-two-layer-prototype-06a';OUT.mkdir(exist_ok=False);rows=[];proof=[];sp=importlib.util.spec_from_file_location('decor_independent06',D/'validate_independent.py');DQ=importlib.util.module_from_spec(sp);sp.loader.exec_module(DQ)
oldgreen=next(e for e in json.loads((D/'optical-clear-final-05/frozen-clear-decor6-manifest.json').read_text())if e['sku']=='1351756003');oldrefill=next(e for e in json.loads((H/'optical-clear-final-05/frozen-clear-and-rims8-manifest.json').read_text())if e['sku']=='1360454001'and'-yag-sisesi-'in e['id'])
for old in[oldgreen,oldrefill]:
 id=old['id']+'-layerproto06a';out=OUT/'models'/id;out.mkdir(parents=True);doc,binary=E.G.read_glb(old['glb_path']);before=json.loads(json.dumps(doc));model=json.loads(Path(old['model_path']).read_text());meta=model['metadata'];green=old['sku']=='1351756003'
 if green:
  ma=next(m for m in doc['materials']if m['name']=='accent');ma['pbrMetallicRoughness']['baseColorFactor']=[.35,.30,.015,1];ma['extensions']['KHR_materials_volume']['attenuationDistance']=.002;model['materials']['green'].update(baseColorFactor=[.35,.30,.015,1],attenuationDistance=.002);changed=['accent'];note='Kendi fotoğrafındaki siyaha yakın koyu zeytin iç cam yuva, temel iç renk ve hacim emilimiyle yorumlandı. Berrak dış cidar ve clear/accent çizim sırası korunur.'
 else:
  outer=next(m for m in doc['materials']if m['name']=='bottle');outer['name']='clear';oil=next(m for m in doc['materials']if m['name']=='oil');oil.update(name='accent',alphaMode='OPAQUE',extensions={'KHR_materials_transmission':{'transmissionFactor':.98},'KHR_materials_ior':{'ior':1.46},'KHR_materials_volume':{'thicknessFactor':.025,'attenuationColor':[1,.90,.20],'attenuationDistance':.08}});oil['pbrMetallicRoughness']['baseColorFactor']=[1,.94,.42,1];model['materials']['oil'].update(alphaMode='OPAQUE',baseColorFactor=[1,.94,.42,1],transmission=.98,ior=1.46,thickness=.025,attenuationColor=[1,.90,.20],attenuationDistance=.08);changed=['bottle','oil'];note='Kendi açık sarı yağı ayrı fiziksel saydam hacim olarak yorumlandı. Berrak dış cidar önce, renkli iç hacim sonra çizilir; ince cidar ve yaklaşık optik sabitler üretici ölçümü değildir.';meta['nested_preview_material_name_mapping']={'bottle':'clear','oil':'accent'}
 for name in['KHR_materials_transmission','KHR_materials_ior','KHR_materials_volume']:
  if name not in doc['extensionsUsed']:doc['extensionsUsed'].append(name)
 for a,b in zip(doc['materials'],before['materials']):
  if b['name']not in changed:assert a==b
 meta.update(id=id,replaces_model_id=old['id'],previous_glb_sha256=old['sha256'],optical_revision='nested-physical-layer-source-color-prototype06',quality_status='preview_limited',quality_label='Cam görünümü yorumu',quality_note=note,nested_preview_note='Existing viewer clear/accent ordering required for nested transmissive objects. Root actual Three validation mandatory.');doc['extras']['metadata']=meta
 for ma in model['materials'].values():
  for slot in['baseColorTexture','normalTexture','metallicRoughnessTexture']:
   p=Path(old['asset_dir'])/ma[slot];shutil.copyfile(p,out/p.name);assert E.sha(p)==E.sha(out/p.name)
 E.dump(out/'model.json',model);path=out/(id+'.glb');E.G.write_glb(path,doc,binary);nd,nb=E.G.read_glb(path);assert nb==binary
 for k in['meshes','accessors','bufferViews','images','textures','samplers']:assert nd[k]==before[k]
 for file in['geometry-validation.json','material-validation.json']:
  q=json.loads((Path(old['asset_dir'])/file).read_text())
  if file=='material-validation.json':
   for m in q['maps']:m['path']=str(out/Path(m['path']).name);assert E.sha(m['path'])==m['sha256']
  E.dump(out/file,q)
 e=dict(old,id=id,asset_dir=str(out),model_path=str(out/'model.json'),glb_path=str(path),sha256=E.sha(path),bytes=path.stat().st_size,geometry_validation=str(out/'geometry-validation.json'),material_validation=str(out/'material-validation.json'),replaces_model_id=old['id'],previous_glb_sha256=old['sha256'],quality_label=meta['quality_label'],quality_note=note,optical_revision=meta['optical_revision'],model_status='pending_root_actual_three',frozen=False)
 for k in['native_renders','scn_path','source_comparison_path','independent_validation_file','visual_validation_file']:e.pop(k,None)
 (DQ if green else Q).check(e);E.dump(out/'entry.json',e);rows.append(e);proof.append(dict(id=id,previous_glb_sha256=old['sha256'],sha256=e['sha256'],entire_bin_unchanged=True,bin_sha256=hashlib.sha256(binary).hexdigest(),all_geometry_and_embedded_maps_identical=True,changed_material_slots=changed,independent_binary_topology_pbr_valid=True))
E.dump(OUT/'candidate-manifest.json',rows);E.dump(OUT/'identity-proof.json',proof);print(E.sha(OUT/'candidate-manifest.json'))
