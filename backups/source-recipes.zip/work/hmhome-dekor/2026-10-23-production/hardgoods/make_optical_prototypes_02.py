"""Immutable material-only prototypes; every geometry, tangent and embedded image byte retained."""
import sys,json,hashlib,shutil
from pathlib import Path
sys.dont_write_bytecode=True
import engine as E
import validate_independent as Q
R=E.R;OUT=R/'optical-revision-prototype-02';OUT.mkdir(exist_ok=False);source=json.loads((R/'frozen-full72-manifest.json').read_text());rows=[];proof=[]
for sku,dist,factor,glassfactor in [('1307202015',.0025,[.40,.20,.02,.28],[.50,.25,.08,.36]),('1249274010',.009,[1.0,.90,.46,.14],[1.0,.88,.35,.20])]:
 old=next(e for e in source if e['sku']==sku);id=old['id']+'-optrev02';out=OUT/'models'/id;out.mkdir(parents=True);doc,binary=E.G.read_glb(old['glb_path']);oldbinary=hashlib.sha256(binary).hexdigest();oldmeshes=json.dumps(doc['meshes'],sort_keys=True);oldviews=json.dumps(doc['bufferViews'],sort_keys=True);oldaccessors=json.dumps(doc['accessors'],sort_keys=True);model=json.loads(Path(old['model_path']).read_text());meta=model['metadata'];meta.update(id=id,replaces_model_id=old['id'],previous_glb_sha256=old['sha256'],optical_revision='material-only-prototype02',optical_interpretation='Both the real hollow glass shell and the internal fragrance liquid use standard alpha blending with own-source intrinsic tint factors. Physical refraction is disabled for this explicit visualization interpretation; solid shell geometry and IOR metadata remain intact. Its solid geometry remains intact. This is an explicitly approximate visualization interpretation, not measured optical data.',quality_status='preview_limited',quality_label='Cam malzeme inceleme adayı',quality_note='Cam ve sıvı görünümü gerçek tarayıcı denetimi bekliyor. İç sıvıda üst üste kırılma yerine belgelenmiş saydam renk yaklaşımı kullanıldı.');doc['extras']['metadata']=meta
 for ma in doc['materials']:
  if ma['name']=='glass':
   ma['extensions']['KHR_materials_transmission']['transmissionFactor']=0;ma['extensions']['KHR_materials_volume']['attenuationDistance']=dist;ma['alphaMode']='BLEND';ma['pbrMetallicRoughness']['baseColorFactor']=glassfactor
  elif ma['name']=='oil':ma.pop('extensions',None);ma['alphaMode']='BLEND';ma['pbrMetallicRoughness']['baseColorFactor']=factor
 model['materials']['glass'].update(attenuationDistance=dist,transmission=0,alphaMode='BLEND',baseColorFactor=glassfactor);oil=model['materials']['oil']
 for key in['transmission','ior','thickness','attenuationColor','attenuationDistance']:oil.pop(key,None)
 oil.update(alphaMode='BLEND',baseColorFactor=factor)
 for mat in model['materials'].values():
  for slot in['baseColorTexture','normalTexture','metallicRoughnessTexture']:
   src=Path(old['asset_dir'])/mat[slot];shutil.copyfile(src,out/src.name)
 E.dump(out/'model.json',model);glb=out/(id+'.glb');E.G.write_glb(glb,doc,binary);newdoc,newbinary=E.G.read_glb(glb);assert hashlib.sha256(newbinary).hexdigest()==oldbinary;assert json.dumps(newdoc['meshes'],sort_keys=True)==oldmeshes and json.dumps(newdoc['bufferViews'],sort_keys=True)==oldviews and json.dumps(newdoc['accessors'],sort_keys=True)==oldaccessors
 for file in['geometry-validation.json','material-validation.json']:
  a=json.loads((Path(old['asset_dir'])/file).read_text())
  if file=='material-validation.json':
   for q in a['maps']:q['path']=str(out/Path(q['path']).name);assert E.sha(q['path'])==q['sha256']
  E.dump(out/file,a)
 e=dict(old,id=id,asset_dir=str(out),model_path=str(out/'model.json'),glb_path=str(glb),sha256=E.sha(glb),bytes=glb.stat().st_size,geometry_validation=str(out/'geometry-validation.json'),material_validation=str(out/'material-validation.json'),replaces_model_id=old['id'],previous_glb_sha256=old['sha256'],quality_label=meta['quality_label'],quality_note=meta['quality_note'],optical_revision='material-only-prototype02',model_status='optical_candidate_pending_root_actual_three',frozen=True)
 for key in['native_renders','scn_path','source_comparison_path','independent_validation_file','visual_validation_file']:e.pop(key,None)
 E.dump(out/'entry.json',e);Q.check(e);rows.append(e);proof.append(dict(id=id,sku=sku,previous_id=old['id'],previous_glb_sha256=old['sha256'],sha256=e['sha256'],bin_sha256=oldbinary,all_geometry_and_embedded_image_bytes_identical=True,meshes_accessors_bufferviews_identical=True,changes=dict(glass_transmission_disabled=True,glass_alpha_mode='BLEND',glass_base_color_factor_linear_rgba=glassfactor,glass_attenuation_distance_metres=dist,oil_refraction_layer_removed=True,oil_alpha_mode='BLEND',oil_base_color_factor_linear_rgba=factor),independent_binary_topology_tangent_pbr_validation=True))
E.dump(OUT/'candidate-manifest.json',rows);E.dump(OUT/'material-only-identity-proof.json',proof);digest=E.sha(OUT/'candidate-manifest.json');(OUT/'candidate-manifest.sha256').write_text(digest+'  candidate-manifest.json\n');print(json.dumps(dict(manifest=str(OUT/'candidate-manifest.json'),sha256=digest,models=len(rows))))
