"""Exact three wood-lid candle sizes, own SKU prints, and actual two-wick contents."""
import sys,math
sys.dont_write_bytecode=True
import numpy as np
from PIL import Image,ImageFilter
import engine as E
B=E.B;T=math.tau;R=E.R

def candle(style):
 if style=='tall':
  rad=.0415;h=.15;body=.145;base=.007;waxh=.131;lab=(.022,.054);wicks=[-.012,.012]
 elif style=='small':
  rad=.0324;h=.062;body=.058;base=.006;waxh=.049;lab=(.020,.045);wicks=[0]
 else:
  rad=.0385;h=.090;body=.085;base=.006;waxh=.076;lab=(.021,.048);wicks=[0]
 inner=rad-.0028;pr=[(0,0),(rad*.82,0),(rad*.94,.0008),(rad,.003),(rad,body-.002),(rad*.995,body),(inner+.0003,body),(inner,body-.002),(inner,base+.002),(inner*.96,base),(0,base)]
 parts=[E.lathe('exact-'+style+'-glass-holder-with-full-hollow-interior-and-thick-clear-base','glass',pr,256)]
 lid=E.lathe('separate-removable-flat-wood-lid-rounded-edge-and-hidden-locator','wood',[(0,body-.001),(inner*.97,body-.001),(inner*.99,body+.0002),(rad+.001,body+.0002),(rad+.001,body+.001),(rad+.001,h-.0008),(rad,h),(0,h)],192);lid['_uvs']=[(x/(rad*2+.002)+.5,z/(rad*2+.002)+.5)for x,y,z in lid['_vertices']];parts.append(lid)
 parts.append(E.lathe('real-finite-thickness-paper-band-with-exact-own-SKU-source-print','label',[(rad+.00018,lab[0]),(rad+.00018,lab[1]),(rad+.00006,lab[1]),(rad+.00006,lab[0])],256))
 parts.append(E.lathe('solid-scented-wax-with-slightly-concave-meniscus','wax',[(0,base),(inner*.96,base),(inner*.99,base+.002),(inner*.99,waxh-.0004),(inner*.97,waxh),(.005,waxh-.0003),(0,waxh-.0005)],192))
 for i,x in enumerate(wicks):parts.append(B.tube('actual-unlit-cotton-wick-'+str(i+1),'wick',[(x,waxh-.0008,0),(x+.0002,waxh+.003,.0002),(x+.0003,waxh+.007,.0001)],.00065,.00065,8,False,guide=[0,1,0]))
 return parts,['Exact ownSKUofficial size, physical glass cavity, heavy transparent base and separate removable wood lid','Exactly two actual physical unlit cotton wicks in the tall 15cm candle, one in the smaller sizes','Source-specific paper print reconstructed from only its own JPEG black ink mask; white paper and intrinsic ink replace all scene RGB','Opaque contents are wax, not an opaque glass substitute; coloured glass uses actual glTFtransmission/volume with declared approximate optical interpretation'],dict(lid_default_state='closed',wick_count=len(wicks),source_packaging_excluded=True,wall_floor_and_lid_profile_photo_interpreted=True)

BASE=E.material
STYLES={}
def mat(pid,key,**args):
 if key!='label':return BASE(pid,key,**args)
 out,ma=BASE(pid,key,color=[236,235,230],rough=.84);n=2048;sty=STYLES[pid];master=next(m for m in E.MASTERS if m['sku']==pid);src=np.array(Image.open(master['path']).convert('RGB'));yy,xx=np.ogrid[:src.shape[0],:src.shape[1]]
 if sty=='tall':top=1353;drop=38;height=285;box=(410,1390,1120,1600)
 elif sty=='small':top=1175;drop=32;height=350;box=(420,1220,1120,1525)
 else:top=1260;drop=45;height=275;box=(420,1335,1130,1540)
 x0,y0,x1,y1=box;gray=np.array(Image.fromarray(src).convert('L'),dtype=float);local=np.array(Image.fromarray(src).convert('L').filter(ImageFilter.GaussianBlur(14)),dtype=float);paperink=(local-gray>32)&(src.max(2)<170);bottom={'tall':1605,'small':1532,'medium':1545}[sty]-45*((xx-768)/410)**2;mask=paperink&(xx>=x0)&(xx<x1)&(yy>=y0)&(yy<y1)&(yy<bottom-7);u=np.arange(n)[None,:]/n;v=np.arange(n)[:,None]/n;angle=T*(u-.25);sx=np.broadcast_to(np.rint(768+410*np.sin(angle)).astype(int),(n,n));sy=np.rint(top+drop*np.cos(angle)+v*height).astype(int);sample=mask[np.clip(sy,0,src.shape[0]-1),np.clip(sx,0,src.shape[1]-1)]&(u>0)&(u<.5);rgb=np.full((n,n,3),[236,235,230],np.uint8);rgb[sample]=[34,34,31];Image.fromarray(rgb,'RGB').save(out/ma['baseColorTexture'],optimize=True);ma['extras'].update(own_sku_text_reconstructed=True,source_pattern_effective_detail_pixels=[x1-x0,height]);E.dump(out/'own-paper-label-provenance.json',dict(master=master['path'],master_sha256=master['sha256'],master_unchanged=E.sha(master['path'])==master['sha256'],source_native_print_box=box,source_effective_detail_pixels=[x1-x0,height],output_canvas_pixels=[2048,2048],geometric_resampling_count=1,source_detail_upgraded=False,method='Exact ownSKUblack ink by local contrast, constrained inside its true curved paper boundary; inverse cylindrical source projection. Intrinsic paper/ink palette; source RGB, glass reflections and scene are discarded.'))
 return out,ma
E.material=mat
specs=[]
def add(pid,title,style,locale,market,evidence,col,tint,dist,woodlabel='Çam ağacı',waxlabel='Kolza mumu %51 ve diğer mum %49'):
 STYLES[pid]=style;diam,h={'tall':(8.5,15),'small':(6.7,6.2),'medium':(8,9)}[style];specs.append(dict(sku=pid,name=('İki fitilli ahşap kapaklı kokulu mum · 'if style=='tall'else'Ahşap kapaklı kokulu mum · ')+title,dims=[diam,h,diam],hwd=[h,None,None],official={'diameter_cm':[diam],'height_cm':[h],'wick_count':2 if style=='tall'else 1},geometry=lambda:candle(style),size_url='https://www2.hm.com/'+locale+'/productpage.'+pid+'.html',market=market,label='Cam %100 · '+woodlabel+' kapak · '+waxlabel,color=title,claim='Exact SKU'+pid+': '+str(diam)+'cm diameter; '+str(h)+'cm height; glass100%holder with '+woodlabel+'lid; '+('two wicks'if style=='tall'else'one wick')+'. '+waxlabel+'.',evidence_files=[str(R/evidence)],note='AynıSKU resmî çapı ve yüksekliği aynen korunur. '+('İki fitil gerçek ayrı geometri olarak içeridedir. 'if style=='tall'else'')+'Cam duvarı/tabanı, dolum seviyesi, etiket kâğıdı ve ayrı kapak kendi fotoğrafından yorumlandı. Camın optik parametreleri ölçülmüş üretici verisi değildir.',materials={'glass':dict(color=[255,255,255],rough=.045,trans=.98,atten=tint,dist=dist),'wood':dict(color=[218,184,137],rough=.54,kind='wood'),'label':dict(color=[236,235,230],rough=.84),'wax':dict(color=col,rough=.45,kind='wax'),'wick':dict(color=[219,212,188],rough=.88,kind='cotton')}))

add('1317812001','Sublime Patchouli','tall','en_us','United States','research-fragrance-06.txt',[223,209,184],[.85,.79,.68],.11,waxlabel='Mum %100')
add('1317812003','Crisp Cotton','tall','en_us','United States','research-fragrance-06.txt',[238,235,220],[.98,.99,.98],.4,waxlabel='Mum %100')
add('1317812004','Sage Serenity','tall','en_ca','Canada','research-fragrance-07.txt',[209,177,144],[.26,.065,.018],.004,woodlabel='Kontrplak')
add('1317812006','Vintage Woods','tall','tr_tr','Türkiye','source-evidence/1317812006.json',[203,163,111],[.61,.39,.16],.008)
add('1317812007',"Winter’s Eve",'tall','tr_tr','Türkiye','source-evidence/1317812007.json',[145,8,25],[.5,.012,.03],.0045)
add('1317850001','Sublime Patchouli','small','en_us','United States','research-fragrance-07.txt',[223,209,184],[.85,.79,.68],.11)
add('1317850003','Crisp Cotton','small','en_us','United States','research-fragrance-08.txt',[238,235,220],[.98,.99,.98],.4)
add('1317850007',"Winter’s Eve",'small','tr_tr','Türkiye','source-evidence/1317850007.json',[145,8,25],[.5,.012,.03],.0045,woodlabel='Kontrplak')
add('1349934002','Crisp Cotton','medium','tr_tr','Türkiye','source-evidence/1349934002.json',[238,235,220],[.98,.99,.98],.4,woodlabel='Kontrplak')
add('1349934003','Sage Serenity','medium','tr_tr','Türkiye','source-evidence/1349934003.json',[209,177,144],[.26,.065,.018],.004,woodlabel='Kontrplak')

if __name__=='__main__':
 for s in specs:
  if len(sys.argv)==1 or s['sku']in sys.argv[1:]:E.build(s)
