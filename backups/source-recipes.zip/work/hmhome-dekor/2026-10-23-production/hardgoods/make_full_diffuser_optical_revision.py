"""Root-approved alpha appearance interpretation for14of27diffuser parts. No frozen edits."""
import sys,json,hashlib,shutil
from pathlib import Path
sys.dont_write_bytecode=True
import engine as E
import validate_independent as Q
R=E.R;OUT=R/'optical-revision-final-01';OUT.mkdir(exist_ok=False);source=[e for e in json.loads((R/'frozen-full72-manifest.json').read_text())if e['category']=='Koku difüzörleri'];rows=[];proof=[]
# Linear RGBA factors are intrinsic source-color interpretations; uncolored glass remains neutral.
configs={
'1249274005':([.84,.48,.34,.25],[1,.90,.80,.12],'Pale peach/pink own bottle',None),
'1249274010':([1,.88,.35,.20],[1,.90,.46,.14],'Root accepted exact prototype02 pale yellow',.009),
'1249274011':([.86,.56,.19,.30],[1,.83,.42,.15],'Own honey amber bottle',None),
'1307202010':([1,1,1,.09],[1,.995,.98,.07],'Own clear neutral fluted glass; no added yellow tint',None),
'1307202015':([.50,.25,.08,.36],[.40,.20,.02,.28],'Root accepted exact prototype02 warm brown',.0025),
'1317827001':([.94,.94,.94,.12],[1,.995,.98,.07],'Own nearly neutral slightly smoky clear glass',None),
'1317827003':([1,1,1,.08],[1,1,1,.06],'Own colorless clear glass and fluid',None),
'1317827004':([.21,.065,.02,.60],[.80,.50,.20,.15],'Own deep amber brown glass',None),
'1317827006':([.66,.45,.22,.24],[.98,.85,.61,.10],'Own light smoky amber glass',None),
'1317827007':([.56,.007,.02,.88],[.65,.01,.02,.18],'Own strong transparent red glass',None),
'1325253001':([1,1,1,.09],[1,.995,.98,.07],'Own clear glass; white frosted spherical neck preserved',None),
'1333471001-yag-sisesi':([1,1,1,.07],[1,1,1,.06],'Own colorless clear refill flask; visible cork preserved',None),
'1360454001':([1,1,1,.09],[1,.995,.98,.07],'Own clear fluted glass; zinc lid preserved',None),
'1360454001-yag-sisesi':([1,1,1,.09],[1,.84,.22,.36],'Own colorless refill glass with pale golden internal oil',None),
}
for old in source:
 key=old['sku']+('-yag-sisesi'if'-yag-sisesi-'in old['id']else'')
 if key not in configs:rows.append(old);continue
 glassfactor,oilfactor,color_note,dist=configs[key];id=old['id']+'-optrev03';out=OUT/'models'/id;out.mkdir(parents=True);doc,binary=E.G.read_glb(old['glb_path']);binhash=hashlib.sha256(binary).hexdigest();snapshot={k:json.dumps(doc[k],sort_keys=True)for k in['meshes','accessors','bufferViews','images','textures','samplers']};oldmaterials=json.loads(json.dumps(doc['materials']));model=json.loads(Path(old['model_path']).read_text());meta=model['metadata'];glasskey='bottle'if'bottle'in model['materials']else'glass';meta.update(id=id,replaces_model_id=old['id'],previous_glb_sha256=old['sha256'],optical_revision='root-approved-alpha-method02-fullset-revision03',optical_interpretation='Real hollow glass shell and internal fragrance fluid use standard alpha blending with own-SKUintrinsic source tint. Physical refraction is disabled for this explicit appearance interpretation. Solid geometry, IOR metadata and all original source textures remain intact.',quality_status='preview_limited',quality_label='Yaklaşık cam görünümü',quality_note='Yaklaşık cam görünümü; kırılma simülasyonu yok. Cam ve sıvının saydamlık/rengi kendi ürün fotoğrafından yorumlanmıştır; üretici optik ölçümü değildir.',intrinsic_color_interpretation=color_note);doc['extras']['metadata']=meta
 for ma in doc['materials']:
  if ma['name']==glasskey:
   ma['extensions']['KHR_materials_transmission']['transmissionFactor']=0
   if dist is not None:ma['extensions']['KHR_materials_volume']['attenuationDistance']=dist
   ma['alphaMode']='BLEND';ma['pbrMetallicRoughness']['baseColorFactor']=glassfactor
  elif ma['name']=='oil':ma.pop('extensions',None);ma['alphaMode']='BLEND';ma['pbrMetallicRoughness']['baseColorFactor']=oilfactor
 for j,ma in enumerate(doc['materials']):
  if ma['name']not in[glasskey,'oil']:assert ma==oldmaterials[j]
 model['materials'][glasskey].update(transmission=0,alphaMode='BLEND',baseColorFactor=glassfactor)
 if dist is not None:model['materials'][glasskey]['attenuationDistance']=dist
 oil=model['materials']['oil']
 for k in['transmission','ior','thickness','attenuationColor','attenuationDistance']:oil.pop(k,None)
 oil.update(alphaMode='BLEND',baseColorFactor=oilfactor)
 for ma in model['materials'].values():
  for slot in['baseColorTexture','normalTexture','metallicRoughnessTexture']:
   src=Path(old['asset_dir'])/ma[slot];shutil.copyfile(src,out/src.name);assert E.sha(src)==E.sha(out/src.name)
 E.dump(out/'model.json',model);glb=out/(id+'.glb');E.G.write_glb(glb,doc,binary);newdoc,newbinary=E.G.read_glb(glb);assert hashlib.sha256(newbinary).hexdigest()==binhash
 for k,v in snapshot.items():assert json.dumps(newdoc[k],sort_keys=True)==v
 for filename in['geometry-validation.json','material-validation.json']:
  q=json.loads((Path(old['asset_dir'])/filename).read_text())
  if filename=='material-validation.json':
   for m in q['maps']:m['path']=str(out/Path(m['path']).name);assert E.sha(m['path'])==m['sha256']
  E.dump(out/filename,q)
 e=dict(old,id=id,asset_dir=str(out),model_path=str(out/'model.json'),glb_path=str(glb),sha256=E.sha(glb),bytes=glb.stat().st_size,geometry_validation=str(out/'geometry-validation.json'),material_validation=str(out/'material-validation.json'),replaces_model_id=old['id'],previous_glb_sha256=old['sha256'],quality_status=meta['quality_status'],quality_label=meta['quality_label'],quality_note=meta['quality_note'],optical_revision=meta['optical_revision'],model_status='optical_candidate_pending_fullset_root_actual_three',frozen=False)
 for k in['native_renders','scn_path','source_comparison_path','independent_validation_file','visual_validation_file']:e.pop(k,None)
 E.dump(out/'entry.json',e);Q.check(e);rows.append(e);change=dict(id=id,sku=e['sku'],previous_id=old['id'],previous_glb_sha256=old['sha256'],sha256=e['sha256'],bin_sha256=binhash,all_geometry_tangents_and_embedded_source_image_bytes_identical=True,all_non_optical_materials_identical=True,changed_material_slots=[glasskey,'oil'],glass_linear_rgba=glassfactor,oil_linear_rgba=oilfactor,source_color_interpretation=color_note,independent_binary_topology_pbr_validation=True)
 if old['sku']in['1307202015','1249274010']:
  proto=next(x for x in json.loads((R/'optical-revision-prototype-02/candidate-manifest.json').read_text())if x['sku']==old['sku']);proto_doc,proto_bin=E.G.read_glb(proto['glb_path']);assert doc['materials']==proto_doc['materials']and binary==proto_bin;change.update(root_accepted_prototype02_glb_sha256=proto['sha256'],material_and_entire_bin_identical_to_root_accepted_prototype02=True)
 proof.append(change);print('OPTICAL',id,flush=True)
assert len(rows)==27 and len(proof)==14;E.dump(OUT/'manifest.json',rows);E.dump(OUT/'changed14-native-candidates.json',[e for e in rows if e.get('optical_revision')]);E.dump(OUT/'optical-changes-14-models-28-materials.json',dict(root_approved_method='Prototype02 source-color alpha blend, explicit absence of physical refraction',changed_models=14,changed_material_slots=28,unchanged_models=13,changes=proof,all_frozen90_preserved=True))
for filename in['freeze_batch.py','validate_independent.py','original-image-masters.json']:shutil.copyfile(R/filename,OUT/filename)
print('Prepared27parts,14material-only revisions,13unchanged')
