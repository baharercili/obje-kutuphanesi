"""Assemble only independently reviewed frozen assets, preserving every prior frozen byte."""
from pathlib import Path
import sys,json,hashlib,collections
sys.dont_write_bytecode=True
import validate_independent as Q
R=Path(__file__).resolve().parent
sha=Q.sha;dump=Q.dump;target=R/'frozen-full72-manifest.json';assert not target.exists()
files=sorted(p for p in R.glob('frozen-*-manifest.json')if p.name!='frozen-full72-manifest.json');allentries={};proofs=[]
for p in files:
 digest=sha(p);assert digest==(p.with_suffix('.sha256')).read_text().split()[0]if p.with_suffix('.sha256').exists()else True
 for e in json.loads(p.read_text()):
  if e['id']in allentries:assert allentries[e['id']]['sha256']==e['sha256']
  allentries[e['id']]=e
 proof=p.with_name(p.name.replace('-manifest.json','-integrity-proof.json'));record=json.loads(proof.read_text());assert record['manifest_sha256']==digest
 for f in record['files']:assert sha(f['path'])==f['sha256'],('Previously frozen file changed',f['path'])
 proofs.append(dict(manifest=str(p),sha256=digest,previously_frozen_files_unchanged=len(record['files'])))
replaced={e['replaces_model_id']:dict(old_sha256=e['previous_glb_sha256'],replacement=e['id'])for e in allentries.values()if e.get('replaces_model_id')}
for old,replacement in replaced.items():assert allentries[old]['sha256']==replacement['old_sha256']
active=sorted([e for e in allentries.values()if e['id']not in replaced],key=lambda e:(e['category'],e['sku'],e['id']));queue=json.loads((R/'source-queue-72.json').read_text())['products'];assert{p['sku']for p in queue}=={e['sku']for e in active};assert len(active)==90
checks=[]
for e in active:checks.append(Q.check(e));print('CHECK',e['id'],flush=True)
masters=json.loads((R/'original-image-masters.json').read_text())+json.loads((R/'original-image-gallery-masters.json').read_text());assert all(sha(p['path'])==p['sha256']for p in masters)
dump(target,active);digest=sha(target);(R/'frozen-full72-manifest.sha256').write_text(digest+'  '+target.name+'\n')
dump(R/'frozen-full72-independent-validation.json',dict(valid=True,models=len(active),products=len({e['sku']for e in active}),checks=checks))
dump(R/'frozen-full72-completeness-and-integrity.json',dict(scope='Exact finite source queue of72hardgoodsSKUs; actual final Three.js browser and canonical integration are performed by parent. This is not a whole-H&M-library completion claim.',valid=True,manifest=str(target),manifest_sha256=digest,source_queue_sha256=sha(R/'source-queue-72.json'),source_products=72,represented_products=72,missing_products=[],active_physical_models=len(active),categories=[dict(category=k,products=len({e['sku']for e in active if e['category']==k}),models=sum(e['category']==k for e in active))for k in sorted({e['category']for e in active})],all_previously_frozen_files_unchanged=proofs,superseded_models_preserved_and_excluded_from_active=replaced,original_image_masters_checked=len(masters),all_original_jpeg_masters_unchanged=True,total_glb_bytes=sum(e['bytes']for e in active),largest_glb_bytes=max(e['bytes']for e in active),all_models_metre_y_up_bottom_center=True,all_material_maps_embedded=True,photographic_background_or_reflections_baked=False,browser_optics_remaining='Glass transmission/roughness and metallic foil appearance remain declared approximations for parent actual Three review.'))
print(json.dumps(dict(manifest=str(target),sha256=digest,products=72,active_models=len(active),total_glb_bytes=sum(e['bytes']for e in active))))
