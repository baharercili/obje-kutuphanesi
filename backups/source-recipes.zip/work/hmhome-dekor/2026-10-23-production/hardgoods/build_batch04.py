"""Five exact star candle SKUs and four own-reference frosted/no-lid candles."""
import sys,math
sys.dont_write_bytecode=True
import numpy as np
from PIL import Image
import engine as E
B=E.B;T=math.tau;R=E.R

def roundstar():
 p=[np.array([math.cos(math.pi/2+i*math.pi/5),math.sin(math.pi/2+i*math.pi/5)])*(1 if i%2==0 else .51)for i in range(10)];out=[]
 for i,point in enumerate(p):
  q0=point+(p[(i-1)%10]-point)*.10;q2=point+(p[(i+1)%10]-point)*.10
  for t in np.linspace(0,1,9,endpoint=False):out.append(tuple((1-t)**2*q0+2*t*(1-t)*point+t*t*q2))
 return out
STAR=roundstar();xy=np.array(STAR);STARDEPTHRATIO=np.ptp(xy[:,1])/np.ptp(xy[:,0])
def star():
 shape=lambda scale:[(x*scale,z*scale)for x,z in STAR]
 g=E.G.capped('own-five-point-rounded-star-stoneware-holder-with-full-star-shaped-cavity','ceramic',[(shape(.96),0),(shape(.99),.001),(shape(1),.003),(shape(1),.057),(shape(.99),.060),(shape(.91),.060),(shape(.90),.058),(shape(.90),.009),(shape(.88),.007)],True,2)
 wax=E.G.capped('real-solid-inset-star-shaped-scented-wax','wax',[(shape(.88),.0075),(shape(.895),.009),(shape(.895),.049),(shape(.88),.0495)],True,2)
 # Star coords are unit-scale; exporter applies official width. Wick width follows the same pre-normalized unit xz.
 wick=B.tube('single-real-unlit-central-cotton-wick','wick',[(0,.049,0),(.002,.052,.001),(.003,.056,.001)],.009,.0005,10,False,guide=[0,1,0])
 return[g,wax,wick],['Rounded five-point star form traced as a finite ceramic shell with a full star-shaped inner cavity and substantial base','Actual solid star-shaped scented wax and one central unlit wick; no source box/packaging is included','Exact official width and height; depth follows the symmetric five-point source star and is explicitly photo-interpreted','Silver/gold coatings use intrinsic polished-metal appearance over a stoneware form; white variant retains glossy ceramic glaze'],dict(wick_count=1,source_packaging_excluded=True,star_point_count=5,wall_base_and_corner_radius_photo_interpreted=True)

def curved_label(radius,y0,y1):
 n=80;amin=math.pi/2-.48;amax=math.pi/2+.48;fit=lambda y:.033+(y-.004)/.077*.002+.00012;prof=[(fit(y0),y0),(fit(y1),y1),(fit(y1)-.00008,y1),(fit(y0)-.00008,y0)];v=[];uv=[];f=[]
 for k,(r,y)in enumerate(prof):
  for i,a in enumerate(np.linspace(amin,amax,n+1)):
   v.append((r*math.cos(a),y,r*math.sin(a)));uv.append((1-i/n,1 if k in[0,3]else 0))
 for k in range(4):
  kk=(k+1)%4
  for i in range(n):a=k*(n+1)+i;b=a+1;c=kk*(n+1)+i;d=c+1;f.extend([(a,b,c),(b,d,c)])
 for i in[0,n]:a=i;b=(n+1)+i;c=2*(n+1)+i;d=3*(n+1)+i;f.extend([(a,b,c),(a,c,d)])
 return E.raw('actual-curved-square-paper-label-with-only-own-source-printed-ink','label',v,f,uv)

def frosted(style):
 if style=='gourmand':
  r=.035;h=.085;pr=[(0,0),(.027,0),(.032,.001),(.033,.004),(.035,.081),(.035,.084),(.0344,.085),(.032,.085),(.0315,.083),(.030,.011),(.028,.007),(0,.007)];waxr=.031;waxh=.074;parts=[E.lathe('own-tapered-frosted-gourmand-glass-with-heavy-closed-base-and-full-interior','glass',pr,256),curved_label(.0345,.022,.064)]
 elif style=='hinoki':
  r=.040;h=.103;pr=[(0,0),(.029,0),(.033,.001),(.034,.003),(.034,.011),(.036,.013),(.039,.016),(.040,.019),(.040,.101),(.0395,.103),(.037,.103),(.0368,.100),(.0368,.021),(.034,.013),(0,.010)];waxr=.0365;waxh=.089;parts=[E.lathe('own-large-narrow-foot-frosted-hinoki-holder-full-open-interior-and-rounded-lip','glass',pr,256)]
 else:
  r=.032;h=.078;pr=[(0,0),(.025,0),(.028,.0006),(.029,.002),(.029,.007),(.030,.008),(.0313,.009),(.032,.011),(.032,.070),(.0318,.073),(.030,.073),(.0297,.070),(.0297,.012),(.027,.006),(0,.006)];waxr=.0294;waxh=.067;parts=[E.lathe('own-lavender-frosted-glass-with-stepped-narrow-foot-full-cavity-and-thick-base','glass',pr,256)];lid=E.lathe('separate-flat-plywood-lid-with-rounded-edge','wood',[(0,.0728),(.029,.0728),(.030,.074),(.0322,.074),(.033,.0748),(.033,.077),(.0325,.078),(0,.078)],192);lid['_uvs']=[(x/.066+.5,z/.066+.5)for x,y,z in lid['_vertices']];parts.append(lid)
 parts.append(E.lathe('actual-solid-scented-wax-with-slightly-concave-top-meniscus','wax',[(0,.007),(waxr*.96,.007),(waxr,.009),(waxr,waxh-.0004),(waxr*.98,waxh),(.005,waxh-.0003),(0,waxh-.0004)],192));parts.append(B.tube('actual-single-unlit-cotton-wick','wick',[(0,waxh-.001,0),(.0002,waxh+.003,0),(.0001,waxh+.006,.0002)],.0006,.0006,8,False,guide=[0,1,0]))
 return parts,['ExactSKUofficial metric diameter and height, true heavy glass base and full open interior','Own-source frosted glass with printed fragrance or a real curved square paper label; no external source packaging','Actual solid scented wax and a single physical unlit cotton wick','Narrow-foot and stepped-foot source forms are individually built; optical parameters remain declared interpretations'],dict(wick_count=1,source_packaging_excluded=True,lid_default_state='closed'if style=='lavender'else'no_lid_in_source')

BASE=E.material
def mat(pid,key,**args):
 if key!='label':return BASE(pid,key,**args)
 out,ma=BASE(pid,key,color=args['color'],rough=.84);master=next(m for m in E.MASTERS if m['sku']==pid);src=np.array(Image.open(master['path']).convert('RGB'));box=[972,1350,1262,1694];x0,y0,x1,y1=box;crop=src[y0:y1,x0:x1];yy,xx=np.indices(crop.shape[:2]);mask=(crop.max(2)<155)&(xx>12)&(xx<280)&(yy>90)&(yy<205);logo=(crop.max(2)<205)&(xx>115)&(xx<180)&(yy>220)&(yy<295);rgb=np.full_like(crop,args['color']);rgb[logo]=[157,143,116];rgb[mask]=[32,32,29];Image.fromarray(rgb,'RGB').save(out/ma['baseColorTexture'],optimize=True);normal=np.full_like(rgb,[127,127,255]);orm=np.full_like(rgb,[255,214,0]);Image.fromarray(normal,'RGB').save(out/ma['normalTexture'],optimize=True);Image.fromarray(orm,'RGB').save(out/ma['metallicRoughnessTexture'],optimize=True);ma['extras'].update(native_resolution=[290,344],own_sku_text_reconstructed=True,source_pattern_effective_detail_pixels=[290,344]);E.dump(out/'own-label-mask-provenance.json',dict(master=master['path'],master_sha256=master['sha256'],master_unchanged=E.sha(master['path'])==master['sha256'],source_native_crop_box=box,source_effective_detail_pixels=[290,344],output_pixels=[290,344],geometric_resampling_count=0,method='Exact ownSKUdark title and faint monogram pigment masks only inside their distinct print supports. Intrinsic paper and ink replace source RGB and studio lighting.'))
 return out,ma
E.material=mat
specs=[]
def add(pid,name,dims,geometry,locale,market,official,label,color,materials,evidence,claim,estimated=None,extras=None):
 specs.append(dict(sku=pid,name=name,dims=dims,hwd=[dims[1],None,None],official=official,estimated=estimated or[],geometry=geometry,size_url='https://www2.hm.com/'+locale+'/productpage.'+pid+'.html',market=market,label=label,color=color,claim=claim,evidence_files=[str(R/evidence)],note='AynıSKU’nun resmî çap/genişlik ve yükseklik ankrajı aynen korunur. Yayımlanmamış yıldız derinliği, yerel iç oyuk, duvar/taban, fitil ve sır/baskı parametreleri kendi fotoğraflarından yorumdur. Resmî CAD/optik ölçüm değildir.',materials=materials,metadata_extras=extras or{}))

for pid,title,col,metal,locale,market in[('1337098001','Christmas Tree',[216,218,215],1,'en_us','United States'),('1337098002','Gingerbread',[237,232,216],0,'en_us','United States'),('1337098003',"Winter’s Eve",[208,177,105],1,'en_us','United States'),('1345272001','Christmas Tree',[216,218,215],1,'en_us','United States'),('1345272002','Gingerbread',[237,232,216],0,'en_us','United States')]:
 small=pid.startswith('1345272');w,h=(6,3.5)if small else(11.5,6);qty=3 if small else 1;add(pid,('3’lü yıldız kokulu mum · tek parça · 'if small else'Yıldız formlu kokulu mum · ')+title,[w,h,round(w*STARDEPTHRATIO,4)],star,locale,market,{'width_cm':[w],'height_cm':[h],'set_quantity':qty},'Stoneware kap %100 · Kolza mumu %51 ve diğer mum %49 · '+('Metalik sır'if metal else'Beyaz sır'),title,{'ceramic':dict(color=col,rough=.10 if metal else .23,metal=metal),'wax':dict(color=[239,233,215],rough=.45,kind='wax'),'wick':dict(color=[217,210,185],rough=.85,kind='cotton')},'research-fragrance-09.txt'if small else'research-fragrance-08.txt','Exact SKU'+pid+': star-shaped stoneware scented candle; width'+str(w)+'cm; height'+str(h)+'cm; '+str(qty)+' retail piece(s); container stoneware100%, contents rapeseed51%/wax49%. Depth not published.',estimated=['depth_cm','local_star_corner_radius_and_inner_well'],extras=dict(set_quantity=qty,represented_set_piece_count=1,bounds_semantics='One physical reusable star candle. Retail set quantity separately recorded.'))

for pid,title,col,locale,market,evidence in[('1295710011','Pumpkin Spice',[223,212,188],'en_ca','Canada','research-fragrance-05.txt'),('1295710012','Matcha Latte',[159,179,143],'tr_tr','Türkiye','source-evidence/1295710012.json')]:
 add(pid,'Cam kapta kokulu mum · '+title,[7,8.5,7],lambda:frosted('gourmand'),locale,market,{'diameter_cm':[7],'height_cm':[8.5]},'Cam kap %100 · Kolza mumu %51 ve diğer mum %49',title,{'glass':dict(color=col,rough=.38,trans=.20,kind='frosted',atten=[.86,.88,.79],dist=.02),'label':dict(color=[234,235,226]if pid.endswith('12')else[239,237,231],rough=.84),'wax':dict(color=[238,231,210],rough=.45,kind='wax'),'wick':dict(color=[217,210,185],rough=.85,kind='cotton')},evidence,'Exact SKU'+pid+': scented candle in a glass holder with heavy base; height8.5cm; diameter7cm; glass100%, rapeseed51%/wax49%. Gift box is excluded from the reusable decor asset.')

add('1313143002','Buzlu cam kapta kokulu mum · Hinoki Woods',[8,10.3,8],lambda:frosted('hinoki'),'tr_tr','Türkiye',{'container_diameter_cm':[8],'container_height_cm':[10.3]},'Cam kap %100 · Kolza mumu %51 ve diğer mum %49','Tozlu yeşil · Hinoki Woods',{'glass':dict(color=[151,162,140],rough=.44,kind='frosted',trans=.18,atten=[.77,.82,.63],dist=.012,text='HINOKI|WOODS'),'wax':dict(color=[235,230,212],rough=.45,kind='wax'),'wick':dict(color=[217,210,185],rough=.85,kind='cotton')},'source-evidence/1313143002.json','Exact SKU1313143002: frosted-glass scented candle with a narrower stepped foot; glass container diameter8cm, height10.3cm;225g. Glass100%; rapeseed51%/wax49%.')
add('1356442001','Buzlu cam kapta ahşap kapaklı kokulu mum · Lavender Mist',[6.6,7.8,6.6],lambda:frosted('lavender'),'tr_tr','Türkiye',{'diameter_cm':[6.6],'height_cm':[7.8]},'Cam kap %100 · Kolza mumu %51 ve diğer mum %49 · Kontrplak kapak','Tozlu mavi · Lavender Mist',{'glass':dict(color=[148,151,167],rough=.44,kind='frosted',trans=.18,atten=[.75,.77,.86],dist=.008,text='LAVENDER|MIST'),'wood':dict(color=[218,191,151],rough=.57,kind='wood'),'wax':dict(color=[235,230,212],rough=.45,kind='wax'),'wick':dict(color=[217,210,185],rough=.85,kind='cotton')},'source-evidence/1356442001.json','Exact SKU1356442001 official TRPDP: diameter6.6cm, height7.8cm;125g. Frosted glass100%, contents rapeseed51%/wax49%, plywood lid100%.')

if __name__=='__main__':
 for s in specs:
  if len(sys.argv)==1 or s['sku']in sys.argv[1:]:E.build(s)
