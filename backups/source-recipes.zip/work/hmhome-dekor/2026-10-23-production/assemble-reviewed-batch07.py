from pathlib import Path
import json,hashlib
P=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
def dump(p,d):Path(p).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
sets=[]
def add(m,b,only=None,exclude=(),ids=None):sets.append((m,b,set(only)if only else None,set(exclude),set(ids)if ids else None))
add('softgoods/rug-material-revision-01/manifest.json','softgoods/rugs-revised39-review/browser-review/dom-checks-current.json')
add('softgoods/surface-form-revision-01/frozen-accepted-four/manifest.json','softgoods/surface-form-five-review/browser-review/dom-checks-current.json')
add('softgoods/quilt-pad-revision-03/manifest.json','softgoods/quilt-pad-v3-review/browser-review/dom-checks-current.json')
for m in ['hemstitch-family-batch01/frozen-all-remaining-real-hemstitch-06-manifest.json','patterned-table-family-batch01/frozen-all-remaining-geometric-patterned-table-19-manifest.json','remaining-printed-fitted-batch01/frozen-all-remaining-native-printed-fitted-11-manifest.json']:
 add('textiles/'+m,'textiles/next36-review/browser-review/dom-checks-current.json')
for m in ['geometric-folded-families-batch01/frozen-all-geometric-folded-families-22-manifest.json','hemstitch-runners-batch01/frozen-both-real-hemstitch-runners-02-manifest.json','plain-damask-tables-batch01/frozen-all-plain-damask-07-manifest.json','remaining-geometric-tables-batch01/frozen-all-remaining-geometric-tables-04-manifest.json','round-tablecloth-organic-revision02/frozen-real-circular-organic-tablecloth-01-manifest.json']:
 add('textiles/'+m,'textiles/family36-review/browser-review/dom-checks-current.json')
add('textiles/native-botanical-linens-batch01/frozen-native-botanical-prototypes-02-manifest.json','textiles/early-new-families-review/browser-review/dom-checks-current.json')
# The Rich Amber refill and green socket use the separately approved two-layer solution.
refill='hm-1360454001-yag-sisesi-h7p9-w4p2-d4p2-optrev03-thinwall05'
a=read(P/'hardgoods/optical-clear-final-05/frozen-clear-and-rims8-manifest.json');add('hardgoods/optical-clear-final-05/frozen-clear-and-rims8-manifest.json','hardgoods/clear-final14-review/browser-review/dom-checks-current.json',ids=[e['id']for e in a if e['id']!=refill])
add('decor-storage/optical-clear-final-05/frozen-clear-decor6-manifest.json','hardgoods/clear-final14-review/browser-review/dom-checks-current.json',exclude=['1351756003'])
add('hardgoods/optical-two-layer-prototype-06a/frozen-final2-manifest.json','hardgoods/optical-two-layer06a-review/browser-review/dom-checks-current.json')
add('hardgoods/optical-clear-edge-prototype-03/frozen-vintage-woods-amber03-manifest.json','hardgoods/optical-edge03-review/browser-review/dom-checks-current.json')
add('hardgoods/optical-revision-final-01/frozen-approved-method03-manifest.json','hardgoods/optical-final27-review/browser-review/dom-checks-current.json',ids=['hm-1333471001-h23p7539-w9p16015-d8p5'])
add('decor-storage/frozen-batch02-woven8-manifest.json','decor-storage/next32-review/browser-review/dom-checks-current.json',only=['1299246001'])
add('decor-storage/frozen-batch03-decor11-manifest.json','decor-storage/next32-review/browser-review/dom-checks-current.json',exclude=['1239692007','1354951003'])
add('decor-storage/frozen-batch04-cloth7-manifest.json','decor-storage/next32-review/browser-review/dom-checks-current.json',only=['1174134011','1174134012','1337076001'])
approvals=read(P/'browser-approvals.json');rows=[];sources=[]
for manifest,evidence,only,excluded,ids in sets:
 checks={x['selected']:x for x in read(P/evidence)};source=read(P/manifest);selected=[]
 for e in source:
  if only and e['sku']not in only or e['sku']in excluded or ids and e['id']not in ids:continue
  assert not e.get('quality_pending',False),(manifest,e['id'],'frozen status')
  b=checks[e['id']];assert not b['error']and e['sha256']in b['download'];assert sha(e['glb_path'])==e['sha256'];assert(P/evidence).parent.joinpath(e['id']+'.png').exists()
  approvals['models'][e['id']]=dict(approved=True,sha256=e['sha256'],sku=e['sku'],browser_evidence=b,notes='Root actual Three/own reference contact comparison passed, independent native geometry/material checks retained. Source/photo interpretations explicit.',evidence_file=str(P/evidence));rows.append(e);selected.append(e['id'])
 sources.append(dict(manifest=str(P/manifest),sha256=sha(P/manifest),selected_ids=selected,excluded_skus=sorted(excluded)))
assert len(rows)==153 and len({e['id']for e in rows})==153,(len(rows),len({e['id']for e in rows}))
assert len({e['sku']for e in rows})==145
manifest=P/'root-reviewed-batch-07-manifest.json';assert not manifest.exists();dump(manifest,rows);dump(P/'browser-approvals.json',approvals);dump(P/'root-reviewed-batch-07-review-record.json',dict(models=153,source_products=145,manifest_sha256=sha(manifest),sources=sources,entire_736_complete=False,reviewer='root actual browser comparison'))
overrides=read(P/'display-name-overrides.json')
for sku in ['1255974015','1255974016','1255974019']:overrides[sku]="3’lü pamuklu kurulama bezi"
overrides['1339100002']='Jakarlı saten masa örtüsü';dump(P/'display-name-overrides.json',overrides)
print(sha(manifest),len(rows),len({e['sku']for e in rows}))
