from pathlib import Path
import json,hashlib,copy
P=Path(__file__).resolve().parent;S=P.parents[2]/'sites/zarahome-vazo-kutuphanesi-final-378'
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
specs=[]
# The final two are deliberately not inferred ready from file existence.
last=read(P/'root-final-two-approved-spec.json');assert last['root_actual_approved']is True and set(last['skus'])=={'1355345001','1357963001'};specs.append(last)
approvals=read(P/'browser-approvals.json');out=[];sources=[]
for spec in specs:
 manifest=P/spec['manifest'];assert sha(manifest)==spec['sha256'],str(manifest)
 checks={};paths={}
 for evidence in spec['evidence']:
  for b in read(P/evidence):checks[b['selected']]=b;paths[b['selected']]=P/evidence
 selected=[]
 for raw in read(manifest):
  if spec.get('skus')and raw['sku']not in spec['skus']:continue
  e=copy.deepcopy(raw);b=checks[e['id']];p=paths[e['id']];assert not b['error']and e['sha256']in b['download']and (p.parent/(e['id']+'.png')).is_file(),e['id']
  angles=p.parent/'four-angles.json';a={r['id']:r for r in read(angles)}[e['id']];assert a['sha256']==e['sha256']and len(a['views'])==4 and all(Path(v['path']).is_file()for v in a['views'])
  e['quality_pending']=False
  e['quality_label']='Fotoğraftan modellenmiş tüylü yüzey · Yaklaşık ölçü'
  e['quality_note']='Form, tüy uzunluğu, yoğunluğu ve renk dağılımı ürün fotoğrafından yorumlanmıştır. Katlanmış duruş ve görünmeyen yüzeyler yaklaşık olarak modellenmiştir.'
  approvals['models'][e['id']]=dict(approved=True,sha256=e['sha256'],sku=e['sku'],browser_evidence=b,evidence_file=str(p),four_angle_evidence=str(angles),notes='Root personally viewed all four actual angles beside the exact own source photo. Physical source-specific fibre, tassel or glass revision accepted. Official and estimated measurement distinctions retained.',**({'native_metal_success_claimed':False}if spec.get('native_metal_success_claimed')is False else{}))
  out.append(e);selected.append(e['id'])
 sources.append(dict(manifest=str(manifest),sha256=spec['sha256'],selected_ids=selected,evidence_files=spec['evidence']))
assert len(out)==2 and len({x['id']for x in out})==2 and len({x['sku']for x in out})==2
catalog=read(S/'ui/hmhome-catalog.json');existing={x['sku']for x in catalog};initial={x['sku']for x in read(P/'initial-pending-736.json')};assert initial<=existing|{x['sku']for x in out};assert not {x['id']for x in out}&{x['id']for x in catalog}
target=P/'root-reviewed-batch-12-manifest.json';assert not target.exists();dump(target,out);dump(P/'browser-approvals.json',approvals)
dump(P/'root-reviewed-batch-12-review-record.json',dict(models=2,source_products=2,manifest_sha256=sha(target),sources=sources,all_initial736_have_reviewed_candidates=True,canonical_and_final_checks_still_required=True,reviewer='Root actual four-angle source comparison'))
print(sha(target),2,2)
