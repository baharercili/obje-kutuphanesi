from pathlib import Path
import json,sys,hashlib,struct,io,importlib.util
sys.dont_write_bytecode=True
import numpy as np
from PIL import Image
R=Path(__file__).resolve().parent;spec=importlib.util.spec_from_file_location('special_binary_audit',R/'validate_families.py');V=importlib.util.module_from_spec(spec);spec.loader.exec_module(V)
def check(e):
    data=Path(e['glb_path']).read_bytes();assert len(data)==e['bytes'] and hashlib.sha256(data).hexdigest()==e['sha256'];assert struct.unpack_from('<III',data)==(0x46546c67,2,len(data))
    n,t=struct.unpack_from('<II',data,12);assert t==0x4e4f534a;doc=json.loads(data[20:20+n]);bl,bt=struct.unpack_from('<II',data,20+n);assert bt==0x004e4942;binary=data[28+n:28+n+bl]
    def array(i):
        a=doc['accessors'][i];v=doc['bufferViews'][a['bufferView']];dtype={5126:'<f4',5125:'<u4',5123:'<u2'}[a['componentType']];c={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}[a['type']];size=np.dtype(dtype).itemsize
        return np.ndarray((a['count'],c),dtype=dtype,buffer=binary,offset=v.get('byteOffset',0)+a.get('byteOffset',0),strides=(v.get('byteStride',size*c),size)).copy()
    bounds=[];heightproofs=[]
    for mesh in doc['meshes']:
        for p in mesh['primitives']:
            pos=array(p['attributes']['POSITION']);bounds.append((pos.min(0),pos.max(0)))
            for key in ['POSITION','NORMAL','TEXCOORD_0','TANGENT']:assert np.isfinite(array(p['attributes'][key])).all()
            assert np.allclose(np.linalg.norm(array(p['attributes']['NORMAL']),axis=1),1,atol=2e-4)
            if e['sku']=='1318248001':
                height=float(np.ptp(pos[:,1]));assert abs(height-.055)<1e-7;heightproofs.append(height)
            elif mesh['name']=='cafe-panel-body':
                count=193*113;mid=(pos[:count]+pos[count:count*2])*.5;grid=mid.reshape(113,193,3);lengths=np.linalg.norm(np.diff(grid.astype(float),axis=1),axis=2).sum(1);assert abs(lengths-2.5).max()<2e-5
    low=np.min([b[0]for b in bounds],axis=0);high=np.max([b[1]for b in bounds],axis=0);assert np.allclose((high-low)*100,e['dimensions_cm'],atol=2e-4);assert abs(low[1])<1e-7 and abs(low[0]+high[0])<1e-7 and abs(low[2]+high[2])<1e-7
    closures=[]
    for scene in doc['scenes']:
        visited=set();todo=list(scene['nodes'])
        while todo:
            node=todo.pop();assert node not in visited;visited.add(node);todo+=doc['nodes'][node].get('children',[])
        closures.append(visited)
    assert len(closures)==1 or not closures[0]&closures[1]
    images=[]
    for im in doc['images']:
        assert 'uri'not in im and'bufferView'in im;v=doc['bufferViews'][im['bufferView']];offset=v.get('byteOffset',0)
        image=Image.open(io.BytesIO(binary[offset:offset+v['byteLength']]));image.load();assert image.size==((8,8)if e['sku']=='1318248001'else(2048,2048));images.append(list(image.size))
    assert all(hashlib.sha256(Path(x['path']).read_bytes()).hexdigest()==x['sha256']for x in e['original_images'])
    topology=V.AUDIT.check(e)
    return dict(id=e['id'],valid=True,sha256=e['sha256'],bytes=e['bytes'],embedded_image_native_sizes=images,individual_hook_heights_m=heightproofs,scene_node_closures_disjoint=True,topology=topology)
if __name__=='__main__':
    entries=json.loads((R/'candidate-special-products-manifest.json').read_text());checks=[check(e)for e in entries];(R/'candidate-special-products-independent-validation.json').write_text(json.dumps(dict(valid=True,models=len(checks),checks=checks),ensure_ascii=False,indent=2)+'\n');print('Special product independent binary checks passed',len(checks))
