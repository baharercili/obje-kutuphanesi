"""Audit binary exports and unchanged source materials before freezing a final organic batch."""
from pathlib import Path
import sys,json,copy,importlib.util,hashlib
sys.dont_write_bytecode=True
R=Path(__file__).resolve().parent;OUT=R/'organic-final-revision01'
spec=importlib.util.spec_from_file_location('organic_independent_audit',R/'validate_families.py');V=importlib.util.module_from_spec(spec);spec.loader.exec_module(V)
sp=importlib.util.spec_from_file_location('cafe_independent_audit',R/'validate_special_products.py');S=importlib.util.module_from_spec(sp);sp.loader.exec_module(S)
old={}
for p in [R/'frozen-batch-01-scene-revision-02/manifest.final.json',R/'frozen-batch-02-manifest.json',R/'frozen-batch-03-manifest.json',R/'frozen-batch-04-manifest.json']:
    for x in json.loads(p.read_text()):old[x['sku']]=x
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
manifest=Path(sys.argv[1]);entries=json.loads(manifest.read_text());checks=[]
for e in entries:
    check=S.check(e)if e['sku']=='1335852001'else V.check(e)
    model=json.loads(Path(e['model_path']).read_text());height=e['official_measurements']['panel_length_cm'];assert abs(e['dimensions_cm'][1]-height)<1e-9
    preserved=False
    if e['sku']in old and e['sku']not in ['1239107002','1283754003']:
        before=json.loads(Path(old[e['sku']]['model_path']).read_text());assert model['materials']==before['materials']
        for mat in model['materials'].values():
            for slot in ['baseColorTexture','normalTexture','metallicRoughnessTexture']:
                if slot in mat:assert sha(Path(e['asset_dir'])/mat[slot])==sha(Path(old[e['sku']]['asset_dir'])/mat[slot])
        # The actual GLB material records must also remain byte-for-byte JSON equivalent.
        def doc(path):
            import struct
            data=Path(path).read_bytes();n=struct.unpack_from('<I',data,12)[0];return json.loads(data[20:20+n])
        assert doc(e['glb_path'])['materials']==doc(old[e['sku']]['glb_path'])['materials'];preserved=True
    check.update(official_hanging_height_cm=height,official_flat_width_preserved=True,existing_materials_and_map_bytes_preserved=preserved,approved_colour_texture_refinement=e['sku']in['1239107002','1283754003'],source_original_images_unchanged=all(sha(x['path'])==x['sha256']for x in e['original_images']))
    checks.append(check);print('AUDITED',e['sku'],flush=True)
report=dict(valid=True,models=len(entries),checks=checks,canonical_changed=False,old_frozen_files_changed=False,method='Parent-approved organic hanging geometry; exact source flat width/height; independent binary and unchanged-material checks.')
dest=manifest.with_name(manifest.stem+'-independent-validation.json');dest.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print('VALIDATION',dest,sha(dest))
