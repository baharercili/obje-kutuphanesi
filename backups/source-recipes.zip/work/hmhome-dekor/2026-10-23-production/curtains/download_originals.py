"""Download only observed official H&M image URLs into immutable local masters."""
from pathlib import Path
import concurrent.futures
import hashlib
import json
import urllib.request
from PIL import Image

R = Path(__file__).resolve().parent
QUEUE = json.loads((R / 'source-queue-143.json').read_text())
OUT = R / 'original-jpeg-masters'
OUT.mkdir(exist_ok=True)

def download(record):
    sku = record['sku']
    image = record['reference_images'][0]
    url = image['url']
    assert url.startswith('https://image.hm.com/')
    target = OUT / (sku + '-observed-grid-master.jpg')
    if not target.exists():
        with urllib.request.urlopen(url, timeout=40) as response:
            data = response.read()
        assert data.startswith(b'\xff\xd8'), 'Expected original JPEG bytes'
        temporary = target.with_suffix('.part')
        temporary.write_bytes(data)
        with Image.open(temporary) as check:
            check.verify()
        temporary.rename(target)
    data = target.read_bytes()
    with Image.open(target) as im:
        item = dict(sku=sku, path=str(target), url=url, alt=image.get('alt'),
                    sha256=hashlib.sha256(data).hexdigest(), bytes=len(data),
                    pixel_dimensions=list(im.size), format=im.format, mode=im.mode,
                    icc_profile_present=bool(im.info.get('icc_profile')),
                    exif_present=bool(im.info.get('exif')), orientation=im.getexif().get(274),
                    original_bytes_preserved=True, original_pixels_resampled=False,
                    source_kind='official_live_category_observed_srcset',
                    requested_resolution_url_was_observed=True,
                    source_resolution_limit='Observed category master; larger PDP gallery originals are collected separately when available.')
    return item

if __name__ == '__main__':
    rows, errors = [], []
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        tasks = {pool.submit(download, q): q for q in QUEUE}
        for future in concurrent.futures.as_completed(tasks):
            q = tasks[future]
            try:
                rows.append(future.result())
            except Exception as error:
                errors.append(dict(sku=q['sku'], url=q['url'], error=str(error)))
            if (len(rows)+len(errors)) % 20 == 0:
                print('Downloaded', len(rows), 'errors', len(errors), flush=True)
    rows.sort(key=lambda r:r['sku'])
    (R/'original-image-masters.json').write_text(json.dumps(rows, ensure_ascii=False, indent=2)+'\n')
    (R/'original-image-download-errors.json').write_text(json.dumps(errors, ensure_ascii=False, indent=2)+'\n')
    print(json.dumps(dict(downloaded=len(rows), errors=len(errors), bytes=sum(r['bytes']for r in rows))))
