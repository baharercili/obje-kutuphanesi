from pathlib import Path
import sys,json,copy,hashlib,importlib.util
sys.dont_write_bytecode=True
R=Path(__file__).resolve().parent;spec=importlib.util.spec_from_file_location('embedded_name_revision',R/'build_curtains.py');C=importlib.util.module_from_spec(spec);spec.loader.exec_module(C)
src=R/'frozen-batch-01-scene-revision-01/manifest.final.json';dst=R/'frozen-batch-01-scene-revision-02';dst.mkdir(exist_ok=False)
entries=[];checks=[]
for e in json.loads(src.read_text()):
    doc,binary=C.read_glb(e['glb_path']);before=copy.deepcopy(doc);doc['extras']['metadata']['name']=e['name']
    folder=dst/e['id'];folder.mkdir();glb=folder/(e['id']+'.glb');C.write_glb(glb,doc,binary);_,afterbinary=C.read_glb(glb);assert binary==afterbinary
    before['extras']['metadata']['name']=e['name'];assert before==doc
    n=copy.deepcopy(e);n.update(glb_path=str(glb),bytes=glb.stat().st_size,sha256=C.sha(glb),model_revision='hmhome-curtains-disjoint-scenes-and-all-names-json-only-2026-10-23-r2');C.dump(folder/'entry.json',n);entries.append(n)
    seen=[]
    for scene in doc['scenes']:
        done=set();todo=list(scene['nodes'])
        while todo:
            node=todo.pop();assert node not in done;done.add(node);todo+=doc['nodes'][node].get('children',[])
        seen.append(done)
    assert not seen[0]&seen[1]
    checks.append(dict(id=e['id'],binary_chunk_sha256=hashlib.sha256(binary).hexdigest(),binary_chunk_unchanged_from_both_prior_versions=True,all_json_except_extras_metadata_name_unchanged_from_revision01=True,model_json_and_entry_and_embedded_name=e['name'],scene_node_closures_disjoint=True,source_geometry_pbr_and_jpeg_bytes_unchanged=True))
C.dump(dst/'manifest.final.json',entries);C.dump(dst/'revision-proof.final.json',dict(source_manifest=str(src),source_manifest_sha256=C.sha(src),checks=checks,original_frozen_manifest_sha256=C.sha(R/'frozen-batch-01-manifest.json')))
C.dump(dst/'frozen-proof.final.json',dict(manifest=str(dst/'manifest.final.json'),sha256=C.sha(dst/'manifest.final.json'),revision_proof_sha256=C.sha(dst/'revision-proof.final.json'),models=len(entries),canonical_changed=False,browser_review=False))
print(C.sha(dst/'manifest.final.json'))
