from pathlib import Path
import json,importlib.util,concurrent.futures,sys
sys.dont_write_bytecode=True
R=Path(__file__).resolve().parent;spec=importlib.util.spec_from_file_location('official_jpeg_download',R/'download_gallery.py');D=importlib.util.module_from_spec(spec);spec.loader.exec_module(D)
queue=json.loads((R/'followup-gallery-link-targets.json').read_text());done=[];errors=[]
with concurrent.futures.ThreadPoolExecutor(max_workers=4)as pool:
    futures={pool.submit(D.one,x):x for x in queue}
    for f in concurrent.futures.as_completed(futures):
        try:done.append(f.result())
        except Exception as e:errors.append(dict(sku=futures[f]['sku'],url=futures[f]['url'],error=str(e)))
        if(len(done)+len(errors))%20==0:print('Additional official gallery JPEGs',len(done),'errors',len(errors),flush=True)
existing=json.loads((R/'original-gallery-masters.json').read_text());merged={(x['sku'],x['url']):x for x in existing}
for x in done:merged[(x['sku'],x['url'])]=x
(R/'followup-gallery-masters.json').write_text(json.dumps(done,ensure_ascii=False,indent=2)+'\n');(R/'followup-gallery-download-errors.json').write_text(json.dumps(errors,ensure_ascii=False,indent=2)+'\n');(R/'original-gallery-masters.json').write_text(json.dumps(sorted(merged.values(),key=lambda x:(x['sku'],x['url'])),ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(downloaded=len(done),errors=len(errors),total_gallery_images=len(merged),total_gallery_products=len({x['sku']for x in merged.values()}))))
