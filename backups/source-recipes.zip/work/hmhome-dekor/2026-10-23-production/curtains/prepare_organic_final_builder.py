"""Build the approved drape revision without changing any old frozen assets."""
from pathlib import Path
import json
R=Path(__file__).resolve().parent
s=(R/'build_curtain_families.py').read_text()
s=s.replace("R=Path(__file__).resolve().parent\nspec=", "BASE=Path(__file__).resolve().parent\nR=BASE/'organic-final-revision01';R.mkdir(exist_ok=True)\nspec=")
s=s.replace("R/'build_curtains.py'","BASE/'build_curtains.py'")
s=s.replace("ANCHORS=json.loads", "if(BASE/'live-normalized-pdp-evidence.json').exists():READERS.update({x['sku']:x for x in json.loads((BASE/'live-normalized-pdp-evidence.json').read_text())})\nANCHORS=json.loads")
s=s.replace("H=C.H;M=C.M;TAU=math.tau;sha=C.sha;dump=C.dump", "H=C.H;M=C.M;TAU=math.tau;sha=C.sha;dump=C.dump\nlight_spec=importlib.util.spec_from_file_location('bounded_cloth_glb_exporter',BASE/'approved-exporter-glb-only/export_catalog.py');LIGHT=importlib.util.module_from_spec(light_spec);light_spec.loader.exec_module(LIGHT);C.export_assets=LIGHT.export_assets")
for file in ['web-reader-research-all143.json','followup-normalized28.json','official-grid-size-anchors.json','source-queue-143.json','original-image-masters.json','original-gallery-masters.json','source-evidence','source-evidence-supplemental','family-description-followup.raw.json','special-header-evidence.raw.json','special-header-find.raw.json']:
    s=s.replace("R/'"+file+"'","BASE/'"+file+"'")
s=s.replace("if 'Vual' in rows or sku=='1072161010':family='voile'", "if sku=='1239107002':family='melange_basket'\n    elif 'Vual' in rows or 'vual' in low or sku.startswith(('1038735','1038743')) or sku=='1072161010':family='voile'")
s=s.replace("elif sku.startswith('1322891'):family='herringbone'", "elif sku.startswith(('1322891','1312150')):family='herringbone'")
s=s.replace("elif 'düğümlü' in low or sku=='1296526002':family='slub'", "elif 'düğümlü' in low or sku=='1296526002' or sku.startswith('1336717'):family='slub'")
s=s.replace("['Astar:','İç astar:','Arka:']", "['Astar:','İç astar:','İç katman:','Arka:','Arka yüz:']")
s=s.replace("'fine_polyester':.78}","'fine_polyester':.78,'melange_basket':1.}")
s=s.replace("'fine_polyester':.0004}","'fine_polyester':.0004,'melange_basket':.0008}")
s=s.replace("return dict(reader=r,source=s,quantity=qty,family=family,lined=lined,color=color,rgb=PALETTE[color]", "rgb={'1239107002':[193,184,174],'1283754003':[154,152,136]}.get(sku,PALETTE[color])\n    return dict(reader=r,source=s,quantity=qty,family=family,lined=lined,color=color,rgb=rgb")
s=s.replace("    return dict(reader=r,source=s,quantity=qty,family=family,lined=lined,color=color,rgb=rgb", "    palette_path=BASE/'per-sku-native-photo-palette-refinements.json'\n    if palette_path.exists():rgb=json.loads(palette_path.read_text()).get(sku,{}).get('rgb',rgb)\n    return dict(reader=r,source=s,quantity=qty,family=family,lined=lined,color=color,rgb=rgb")
start=s.index('def cloth_grid(');end=s.index('\ndef panel(',start)
organic='''def cloth_grid(width,height,family,seed,lined=False,nu=192,nv=112):
    rng=np.random.default_rng(seed);u=np.linspace(0,1,nu+1);vs=np.linspace(0,1,nv+1);folds=max(5,round(width/.20))
    heavy=lined or family in ['boucle','chenille','herringbone','melange_basket'];a,b,c=rng.uniform(-math.pi,math.pi,3)
    strength=rng.uniform(.94,1.07,folds+1)if heavy else rng.uniform(.90,1.09,folds+1)
    points=[];arc=[];short_drift=min(1.,height/2.)
    for t in vs:
        lower=1-t;ease=math.sin(math.pi*t)
        warped=u+np.sin(math.pi*u)*(.021*np.sin(TAU*1.15*u+a)+.008*np.sin(TAU*3.2*u+b))
        warped+=np.sin(math.pi*u)*((.006 if heavy else .010)*ease*np.sin(TAU*1.7*u+t*1.8+c)+.006*lower*np.sin(TAU*.8*u+a))
        phase=TAU*folds*warped;depth=np.interp(warped,np.linspace(0,1,folds+1),strength)
        amplitude=((1.20+.075*t-.07*lower**1.4)if heavy else(1.16+.10*t-.13*lower**1.4))*depth
        theta=np.clip(amplitude*np.sin(phase)+.105*np.sin(phase*2+.55*np.sin(TAU*u+a)+.9*lower),-1.44,1.44)
        ds=width/nu;tx=np.cos(theta);tz=np.sin(theta);x=np.r_[0,np.cumsum((tx[1:]+tx[:-1])*.5*ds)];z=np.r_[0,np.cumsum((tz[1:]+tz[:-1])*.5*ds)]
        z+=short_drift*((.004 if heavy else .007)*ease*np.sin(TAU*1.2*u+t*2.1+b)+.0025*ease*np.sin(TAU*4.4*u+t*3+a))
        length=np.hypot(np.diff(x),np.diff(z)).sum();x*=width/length;z*=width/length;x-=(x.min()+x.max())/2;z-=(z.min()+z.max())/2
        x+=short_drift*(.005 if heavy else .009)*ease*math.sin(t*3+a);z+=short_drift*(.006 if heavy else .011)*ease*math.sin(t*2.4+c)
        points.append(np.stack((x,np.full(nu+1,height*t),z),axis=1));arc.append(float(np.hypot(np.diff(x),np.diff(z)).sum()))
    p=np.array(points);normal=np.cross(np.gradient(p,axis=1),np.gradient(p,axis=0));normal/=np.linalg.norm(normal,axis=2,keepdims=True)
    return p,normal,dict(panel_flat_width_m=width,panel_length_m=height,row_arc_length_min_m=min(arc),row_arc_length_max_m=max(arc),arc_width_error_max_m=max(abs(x-width)for x in arc),nu=nu,nv=nv,seed=seed,folds=folds,material_gravity='restrained heavier drape'if heavy else'soft airy drape',pose='Approved organic hanging method; unequal smooth fold spacing/depth, relaxed lower edge and vertical drift. Independent panels.')
'''
s=s[:start]+organic+s[end:]
s=s.replace("grid,normals,proof=cloth_grid(width,height,f['family'])", "grid,normals,proof=cloth_grid(width,height,f['family'],f['panel_seed'],f['lined'])")
s=s.replace("period=16 if family in ['voile','fine_polyester'] else 23", "period=16 if family in ['voile','fine_polyester'] else 48 if family=='melange_basket' else 23")
s=s.replace("elif family=='boucle':", "elif family=='melange_basket':\n        height+=.12*np.sin(TAU*x/96)*np.sin(TAU*y/96)+rng.normal(0,.011,(N,N))\n    elif family=='boucle':")
s=s.replace("dy,dx=np.gradient(height);normal=", "if family=='melange_basket':\n        yarn=np.sin(TAU*x/48)*np.cos(TAU*y/48)+.4*np.sin(TAU*x/96)\n        rgb+=yarn[:,:,None]*19\n    dy,dx=np.gradient(height);normal=")
old="""raw,arc=panel(f);xb=[p[0]for g in raw for p in g['_vertices']];span=max(xb)-min(xb);shift=(span+.065)/2
    offsets=[-shift,shift]if qty==2 else[0.];parts=[];groups=[]
    for k,offset in enumerate(offsets):
        group=[]
        for g in raw:"""
new="""panel_parts=[];arc=[];spans=[]
    for k in range(qty):
        local=copy.deepcopy(f);local['panel_seed']=(149 if k==0 else 631)if sku=='1038735001'else(int(sku)%1000003+k*982451)
        if sku in C.SPECS:
            C.cloth_grid=lambda width,height,nu=192,nv=112,local=local:cloth_grid(width,height,local['family'],local['panel_seed'],local['lined'],nu,nv)
            raw,proof=C.panel(sku,w/100,h/100)
        else:raw,proof=panel(local)
        panel_parts.append(raw);arc.append(proof);xb=[p[0]for g in raw for p in g['_vertices']];spans.append(max(xb)-min(xb))
    offsets=[-(spans[1]+.055)/2,(spans[0]+.055)/2]if qty==2 else[0.];parts=[];groups=[]
    for k,offset in enumerate(offsets):
        group=[]
        for g in panel_parts[k]:"""
assert old in s;s=s.replace(old,new)
s=s.replace("aid=f'hm-{sku}-panel{fmt(w)}x{fmt(h)}-'+('pair'if qty==2 else'single')+'-gathered'", "aid=f'hm-{sku}-panel{fmt(w)}x{fmt(h)}-'+('pair'if qty==2 else'single')+'-organic-hanging'")
s=s.replace("dims=(hi-lo)*100", "dims=(hi-lo)*100;yscale=(h/100)/(hi[1]-lo[1]);dims[1]=h")
s=s.replace("g['_vertices']=[tuple(np.array(p)-centre)for p in g['_vertices']]", "g['_vertices']=[tuple((np.array(p)-centre)*[1,yscale,1])for p in g['_vertices']]")
s=s.replace("mats=materials(sku,f,out)", "mats=material_bank(sku,f,out)")
s=s.replace("name=r['product_title']+' · '+f['color']", "name=OLD_ENTRIES[sku]['name']if sku in OLD_ENTRIES else r['product_title']+' · '+f['color']")
s=s.replace("float(shift+centre[0])", "float(-offsets[0]+centre[0])")
s=s.replace("model_revision='hmhome-source-specific-textile-families-2026-10-23-v2'", "model_revision='hmhome-approved-organic-curtain-drape-2026-10-24-r1'")
insert='''OLD_ENTRIES={}
for p in [BASE/'frozen-batch-01-scene-revision-02/manifest.final.json',BASE/'frozen-batch-02-manifest.json',BASE/'frozen-batch-03-manifest.json',BASE/'candidate-families-manifest.json']:
    for entry in json.loads(p.read_text()):OLD_ENTRIES.setdefault(entry['sku'],entry)
def material_bank(sku,f,out):
    if sku not in OLD_ENTRIES or sku in ['1239107002','1283754003']:return materials(sku,f,out)
    old=OLD_ENTRIES[sku];model=json.loads(Path(old['model_path']).read_text())
    if model['metadata'].get('textile_recipe')and model['metadata']['textile_recipe']!=f['family']:return materials(sku,f,out)
    mats=copy.deepcopy(model['materials'])
    for mat in mats.values():
        for slot in ['baseColorTexture','normalTexture','metallicRoughnessTexture']:
            if slot in mat:
                src=Path(old['asset_dir'])/mat[slot];dst=out/mat[slot]
                if not dst.exists():__import__('shutil').copy2(src,dst)
                assert sha(src)==sha(dst)
    return mats
'''
s=s.replace("def build(sku):",insert+"\ndef build(sku):")
s=s.replace("dict(sheenColorFactor=[.16,.15,.14],sheenRoughnessFactor=.89)","(dict(sheenColorFactor=[.12,.12,.11],sheenRoughnessFactor=.83)if sku in C.SPECS else dict(sheenColorFactor=[.16,.15,.14],sheenRoughnessFactor=.89))")
s=s.replace("R/'candidate-families-manifest.json'","R/__import__('os').environ.get('CURTAIN_BATCH_MANIFEST','candidate-families-manifest.json')")
(R/'build_organic_curtains_final.py').write_text(s)
print('Prepared final builder')
