"""Save exact official gallery link targets; never alter or re-encode masters."""
from pathlib import Path
import concurrent.futures
import hashlib
import json
import urllib.request
from PIL import Image

R=Path(__file__).resolve().parent
OUT=R/'original-gallery-masters'
OUT.mkdir(exist_ok=True)
rows=json.loads((R/'official-gallery-link-targets.json').read_text())
for file in (R/'source-evidence').glob('*.json'):
    d=json.loads(file.read_text())
    if d.get('method')=='public_live_browser_dom':
        rows.extend(dict(sku=d['sku'],url=i['url'],alt=i.get('alt'),source_ref=str(file),
                         status='official_live_browser_image') for i in d.get('images',[]))
queue=list({(r['sku'],r['url']):r for r in rows if r.get('url') and r['url'].startswith(('https://image.hm.com/','https://lp2.hm.com/'))}.values())

def one(r):
    key=hashlib.sha256(r['url'].encode()).hexdigest()[:16]
    target=OUT/(r['sku']+'-'+key+'-master.jpg')
    if not target.exists():
        with urllib.request.urlopen(r['url'],timeout=45) as response: data=response.read()
        assert data.startswith(b'\xff\xd8'), 'Expected original JPEG bytes'
        tmp=target.with_suffix('.part');tmp.write_bytes(data)
        with Image.open(tmp) as im:im.verify()
        tmp.rename(target)
    data=target.read_bytes()
    with Image.open(target) as im:
        return dict(sku=r['sku'],url=r['url'],alt=r.get('alt'),path=str(target),
                    sha256=hashlib.sha256(data).hexdigest(),bytes=len(data),
                    pixel_dimensions=list(im.size),format=im.format,mode=im.mode,
                    icc_profile_present=bool(im.info.get('icc_profile')),
                    exif_present=bool(im.info.get('exif')),orientation=im.getexif().get(274),
                    original_bytes_preserved=True,original_pixels_resampled=False,
                    source_ref=r['source_ref'],source_kind='official_pdp_gallery_link_target')

if __name__=='__main__':
    done=[];errors=[]
    with concurrent.futures.ThreadPoolExecutor(max_workers=4)as pool:
        futures={pool.submit(one,r):r for r in queue}
        for f in concurrent.futures.as_completed(futures):
            try:done.append(f.result())
            except Exception as e:errors.append(dict(sku=futures[f]['sku'],url=futures[f]['url'],error=str(e)))
            if (len(done)+len(errors))%50==0:print('Gallery masters',len(done),'errors',len(errors),flush=True)
    done.sort(key=lambda r:(r['sku'],r['url']))
    (R/'original-gallery-masters.json').write_text(json.dumps(done,ensure_ascii=False,indent=2)+'\n')
    (R/'gallery-download-errors.json').write_text(json.dumps(errors,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(dict(queue=len(queue),downloaded=len(done),errors=len(errors),bytes=sum(r['bytes']for r in done))))
