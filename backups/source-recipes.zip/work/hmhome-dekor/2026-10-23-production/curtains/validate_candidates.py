"""Independent checks of the actual binary exports; no canonical library writes."""
from pathlib import Path
import sys,json,hashlib,struct,io,importlib.util
sys.dont_write_bytecode=True
import numpy as np
from PIL import Image

R=Path(__file__).resolve().parent
Z=R.parents[2]/'zarahome-dekor'
spec=importlib.util.spec_from_file_location('independent_cloth_topology',Z/'objects/audit_geometry.py')
AUDIT=importlib.util.module_from_spec(spec);spec.loader.exec_module(AUDIT)

def check(e):
    data=Path(e['glb_path']).read_bytes()
    assert len(data)==e['bytes'] and hashlib.sha256(data).hexdigest()==e['sha256']
    assert struct.unpack_from('<III',data)==(0x46546c67,2,len(data))
    n,t=struct.unpack_from('<II',data,12);assert t==0x4e4f534a
    doc=json.loads(data[20:20+n]);bl,bt=struct.unpack_from('<II',data,20+n);assert bt==0x004e4942
    binary=data[28+n:28+n+bl];assert len(binary)==bl
    def array(index):
        a=doc['accessors'][index];view=doc['bufferViews'][a['bufferView']]
        dt={5126:'<f4',5125:'<u4',5123:'<u2',5121:'u1'}[a['componentType']]
        channels={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}[a['type']];size=np.dtype(dt).itemsize
        return np.ndarray((a['count'],channels),dtype=dt,buffer=binary,
                offset=view.get('byteOffset',0)+a.get('byteOffset',0),
                strides=(view.get('byteStride',channels*size),size)).copy()
    bounds=[];arc_proofs=[]
    for mesh in doc['meshes']:
        for primitive in mesh['primitives']:
            p=array(primitive['attributes']['POSITION']);normal=array(primitive['attributes']['NORMAL'])
            uv=array(primitive['attributes']['TEXCOORD_0']);tangent=array(primitive['attributes']['TANGENT'])
            assert np.isfinite(p).all() and np.isfinite(normal).all() and np.isfinite(uv).all() and np.isfinite(tangent).all()
            assert np.allclose(np.linalg.norm(normal,axis=1),1,atol=2e-4)
            assert np.allclose(np.linalg.norm(tangent[:,:3],axis=1),1,atol=2e-4)
            bounds.append((p.min(0),p.max(0)))
            if mesh['name'].endswith('-body'):
                nu=192;nv=112;count=(nu+1)*(nv+1)
                # The shared exporter appends face-local vertices when mapping
                # thin edge UVs; the original two cloth lattices stay first.
                assert len(p)>=2*count
                mid=(p[:count].astype(float)+p[count:2*count].astype(float))*.5
                grid=mid.reshape(nv+1,nu+1,3)
                lengths=np.linalg.norm(np.diff(grid,axis=1),axis=2).sum(axis=1)
                expected=e['official_measurements']['panel_flat_width_cm']/100
                error=float(abs(lengths-expected).max());assert error<2e-5
                arc_proofs.append(dict(mesh=mesh['name'],official_flat_width_m=expected,
                    centreline_row_arc_min_m=float(lengths.min()),centreline_row_arc_max_m=float(lengths.max()),max_error_m=error))
    minimum=np.min([b[0]for b in bounds],axis=0);maximum=np.max([b[1]for b in bounds],axis=0)
    assert np.allclose((maximum-minimum)*100,e['dimensions_cm'],atol=2e-4,rtol=1e-5)
    assert abs(float(minimum[1]))<1e-6
    assert abs(float(minimum[0]+maximum[0]))<1e-6 and abs(float(minimum[2]+maximum[2]))<1e-6
    assert len(doc['scenes'])==2 and doc['scene']==0 and len(arc_proofs)==2
    image_sizes=[]
    for image in doc['images']:
        assert 'bufferView'in image and 'uri'not in image
        view=doc['bufferViews'][image['bufferView']];offset=view.get('byteOffset',0)
        with Image.open(io.BytesIO(binary[offset:offset+view['byteLength']]))as im:
            im.load();assert im.size==(2048,2048);image_sizes.append(list(im.size))
    assert 'KHR_materials_sheen'in doc['extensionsUsed']
    assert all(m.get('extras',{}).get('baked_reflections')is not True for m in doc['materials'])
    for original in e['original_images']:
        assert hashlib.sha256(Path(original['path']).read_bytes()).hexdigest()==original['sha256']
    model=json.loads(Path(e['model_path']).read_text());assert not model['metadata']['photo_pixels_baked'] and not model['metadata']['baked_reflections']
    topology=AUDIT.check(e)
    return dict(id=e['id'],sha256=e['sha256'],bytes=e['bytes'],valid=True,
        bounds_cm=[float(v)for v in (maximum-minimum)*100],units='metres',origin='bottom bounding-box centre',
        set_quantity=2,scene_count=2,embedded_image_sizes=image_sizes,
        independent_binary_cloth_width_proofs=arc_proofs,topology=topology)

if __name__=='__main__':
    path=Path(sys.argv[1])if len(sys.argv)>1 else R/'candidate-manifest.json'
    entries=json.loads(path.read_text());checks=[check(e)for e in entries]
    report=dict(valid=True,models=len(checks),checks=checks,
        canonical_site_modified=False,canonical_model_source_modified=False)
    (R/'candidate-independent-validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(dict(valid=True,models=len(checks))))
