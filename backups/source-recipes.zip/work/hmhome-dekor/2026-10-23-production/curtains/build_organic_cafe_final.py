"""The category's hardware accessory and short rod-pocket cafe curtain use distinct constructions."""
from pathlib import Path
import sys,json,copy,math,importlib.util,hashlib
sys.dont_write_bytecode=True
import numpy as np
from PIL import Image
BASE=Path(__file__).resolve().parent;R=BASE/'organic-final-revision01';R.mkdir(exist_ok=True);spec=importlib.util.spec_from_file_location('special_cloth_base',BASE/'build_organic_curtains_final.py');F=importlib.util.module_from_spec(spec);spec.loader.exec_module(F)
C=F.C;H=F.H;M=F.M;dump=C.dump;sha=C.sha

def bezier(points,n=28):
    a,b,c,d=[np.array(p,float)for p in points];return[np.array((1-t)**3*a+3*(1-t)**2*t*b+3*(1-t)*t*t*c+t**3*d)for t in np.linspace(0,1,n)]
def wire_path():
    # One continuous bent wire, with free cut tails, two fork bends and the central return hook.
    # Height is constrained to the official55mm. All other local dimensions are photo interpretations.
    left=[(-.0087,.0080,0),(-.0130,.0498,0)]
    p=[np.array(q,float)for q in left]
    p+=bezier([left[-1],(-.0136,.054,0),(-.0093,.054,0),(-.0094,.050,0)])[1:]
    p.append(np.array((-.0063,.004,0)))
    p+=bezier([tuple(p[-1]),(-.0062,-.0003,0),(-.0008,-.0003,0),(-.0008,.004,0)])[1:]
    p.append(np.array((-.0008,.052,0)))
    p+=bezier([tuple(p[-1]),(-.0008,.055,0),(-.0008,.055,.005),(-.0008,.052,.005)])[1:]
    p.append(np.array((-.0008,.039,.005)))
    p+=bezier([tuple(p[-1]),(-.0008,.0375,.005),(.0008,.0375,.005),(.0008,.039,.005)])[1:]
    p.append(np.array((.0008,.052,.005)))
    p+=bezier([tuple(p[-1]),(.0008,.055,.005),(.0008,.055,0),(.0008,.052,0)])[1:]
    p.append(np.array((.0008,.004,0)))
    p+=bezier([tuple(p[-1]),(.0008,-.0003,0),(.0062,-.0003,0),(.0063,.004,0)])[1:]
    p.append(np.array((.0094,.050,0)))
    p+=bezier([tuple(p[-1]),(.0093,.054,0),(.0136,.054,0),(.0130,.0498,0)])[1:]
    p.append(np.array((.0087,.0080,0)))
    # Subdivide straight spans without changing their physical silhouette.
    dense=[]
    for a,b in zip(p,p[1:]):
        n=max(1,math.ceil(float(np.linalg.norm(b-a))/.0006));dense += [a+(b-a)*t for t in np.linspace(0,1,n,endpoint=False)]
    return dense+[p[-1]]

def hook_parts():
    single=C.tube('continuous-steel-two-prong-and-forward-return-hook','steel',wire_path(),radius=.00045,sides=16)
    p=np.array(single['_vertices']);lo=p.min(0);hi=p.max(0);scale=.055/(hi[1]-lo[1]);centre=np.array([(lo[0]+hi[0])/2,lo[1],(lo[2]+hi[2])/2])
    single['_vertices']=[tuple((np.array(v)-centre)*scale)for v in single['_vertices']]
    parts=[]
    for k in range(10):
        g=copy.deepcopy(single);g['name']='hook-'+str(k+1)+'-continuous-two-prong-steel-wire';offset=((k%5-2)*.035,(k//5)*.065,0)
        g['_vertices']=[tuple(np.array(p)+offset)for p in g['_vertices']];parts.append(g)
    return parts,dict(individual_height_cm=5.5,set_quantity=10),dict(individual_height_exact=True,wire_path_samples=len(wire_path()),wire_diameter_photo_estimate_mm=.9*scale),None

def cafe_parts():
    f=dict(width_cm=250,height_cm=75,family='linen_blend',color='Beyaz',rgb=[239,239,232],quantity=1,opacity=.77,thickness=.00055,lined=False)
    grid,normals,proof=F.cloth_grid(2.5,.75,'linen_blend',583291,False);nu=192;nv=112;t=.00055
    uv=np.array([[(i/nu*2.5/.04,j/nv*.75/.04)for i in range(nu+1)]for j in range(nv+1)])
    parts=[C.shell('cafe-panel-body','cloth',grid,normals,t,uv)]
    parts.append(C.ribbon('official-10cm-turned-bottom-edge','double_cloth',grid,normals,0,1,0,.10/.75,t*1.4,-t*1.05))
    for side,u in [('left',0),('right',1-.014/2.5)]:parts.append(C.ribbon(side+'-turned-side-seam','double_cloth',grid,normals,u,u+.014/2.5,0,1,t*1.25,-t,steps_u=4,steps_v=112))
    # The rear cloth cover forms an actual horizontal air channel, open at both X ends.
    parts.append(C.ribbon('full-width-open-ended-rod-pocket','double_cloth',grid,normals,0,1,1-.06/.75,1,.0006,-.0006,steps_u=192,steps_v=12,bridge=-.010))
    for k,v in enumerate([.092/.75,1-.055/.75,1-.004/.75]):
        points=[C.sample(grid,normals,float(u),v)[0]+C.sample(grid,normals,float(u),v)[1]*.0004 for u in np.linspace(.004,.996,257)];parts.append(C.tube('cafe-raised-sewn-thread-'+str(k),'thread',points))
    return parts,dict(panel_flat_width_cm=250,panel_length_cm=75,set_quantity=1,folded_edge_cm=10),dict(arc_length=proof,actual_rod_pocket_air_channel=True,multiway_hook_tape=False),f

def build(sku):
    assert sku=='1335852001'
    assert not any(sku in{x['sku']for x in json.loads(p.read_text())}for p in R.glob('frozen-*-manifest.json'))
    hook=sku=='1318248001';source=F.SOURCES[sku];raw,official,extra,f=hook_parts()if hook else cafe_parts();parts=[]
    p=np.concatenate([g['_vertices']for g in raw]);lo=p.min(0);hi=p.max(0);centre=np.array([(lo[0]+hi[0])/2,lo[1],(lo[2]+hi[2])/2]);dims=(hi-lo)*100;yscale=.75/(hi[1]-lo[1]);dims[1]=75;checks=[]
    for g in raw:
        g['_vertices']=[tuple((np.array(v)-centre)*[1,yscale,1])for v in g['_vertices']];m,c=C._finalize(H.orient(g));parts.append(m);checks.append(c)
    repairs=M.ensure_uv_faces(parts)+H.ensure_float32_uv(parts);aid='hm-'+sku+('-two-prong-hook-10set-h5p5'if hook else'-cafe-panel250x75-rod-pocket-organic-hanging');out=R/'models'/aid;out.mkdir(exist_ok=True)
    if hook:
        # These are native constant material maps, not resized photographs or fake high-resolution textures.
        for key,rgb in [('albedo',[218,220,222]),('normal',[128,128,255]),('orm',[255,52,255])]:Image.new('RGB',(8,8),tuple(rgb)).save(out/(sku+'-'+key+'.png'))
        mats=dict(steel=dict(baseColorFactor=[1,1,1,1],baseColorTexture=sku+'-albedo.png',normalTexture=sku+'-normal.png',metallicRoughnessTexture=sku+'-orm.png',normalScale=0,metallic=1,roughness=1,doubleSided=False,alphaMode='OPAQUE',extras=dict(intrinsic_material=True,photo_pixels_baked=False,baked_reflections=False,native_resolution=8,constant_material_map=True)))
    else:mats=F.materials(sku,f,out)
    master=next(x for x in json.loads((BASE/'original-image-masters.json').read_text())if x['sku']==sku);gallery=[x for x in json.loads((BASE/'original-gallery-masters.json').read_text())if x['sku']==sku];allimages=gallery+[master]
    name='10’lu iki çatallı paslanmaz çelik perde kancası'if hook else'Keten karışımlı kafe perdesi · Beyaz'
    note=('Resmî tek kanca yüksekliği 5,5 cm ve paket adedi 10 korunmuştur. Genişlik, derinlik, tel kalınlığı ve yerel kıvrımlar ürünün kendi fotoğrafından yorumdur. Varsayılan görünüm 10 adet sergileme düzenidir; paket dış ölçüsü değildir.'if hook else'Resmî düz panel 250×75 cm ve 10 cm katlı kenar korunmuştur. Pileli görünüşün genişlik ve derinliği asma pozuna aittir. Üstte gerçek çubuk cebi vardır; ekstrafor kanca bandı ve çubuk bu modele dahil değildir. Cep ve yan dikiş kalınlıkları fotoğraf yorumudur.')
    variants=[dict(index=0,label='10 adet · takım') ,dict(index=1,label='Tek kanca')]if hook else[dict(index=0,label='Tek kafe perdesi · çubuk cepli')]
    anomalies=['Official article field says10pieces; hero image alt describes9visible items. Product quantity follows official field10.']if hook else[]
    evidence=[str(BASE/'source-evidence'/(sku+'.json'))]+([]if hook else[str(BASE/'special-header-find.raw.json'),str(BASE/'official-grid-size-anchors.json')])
    meta=dict(id=aid,sku=sku,brand='H&M Home',name=name,category='Perdeler',url=source['url'],dimensions_cm=[float(x)for x in dims],source_dimensions_hwd_cm=[5.5,None,None]if hook else[75,250,None],official_measurements=official,estimated_dimensions=True,estimated_fields=['display_arrangement_width_depth_and_height','individual_width_depth_wire_profile']if hook else['hanging_pose_width_cm','hanging_pose_depth_cm','rod_pocket_and_side_seam_thickness'],scale_note=note,diameter_semantics=note,material_label='Paslanmaz çelik %100 · Gümüş rengi'if hook else'Pamuk %70, keten %30 · Beyaz',color='Gümüş rengi'if hook else'Beyaz',source_market='Türkiye',source_size_pointer=evidence[0],source_evidence_files=evidence,source_images=[dict(url=x['url'],alt=x.get('alt')or name)for x in allimages],original_image=master['path'],original_image_url=master['url'],original_image_sha256=master['sha256'],original_images=[{k:x[k]for k in ['path','url','sha256']}for x in allimages],variant_status_verbatim='Exact SKU resmî fiziksel ölçü, bileşim, paket ve form bilgisi',set_quantity=10 if hook else 1,scene_variants=variants,default_scene_index=0,quality_status='preview_limited',quality_label='Fotoğraftan yorumlanan yerel ayrıntılar',quality_note='Üretici CAD taraması değildir; resmî ölçü korunur, ölçüsü verilmeyen yerel profil ve malzeme görünümü yorumdur.',source_anomalies=anomalies,units='metres',up_axis='Y',origin='bottom bounding-box centre',photo_pixels_baked=False,baked_reflections=False,native_texture_resolution='Native8px constant steel PBR maps'if hook else'Native2048px procedural cloth PBR',geometry_limitations=['Unlabelled local profile from exact product photos.'])
    meta.update(extra);dump(out/'model.json',dict(metadata=meta,materials=mats,meshes=parts));dump(out/'geometry-validation.json',dict(valid=True,closed_material_solids=True,meshes=checks,triangles=sum(x['triangles']for x in checks),mesh_count=len(parts),uv_repairs=repairs,features=extra))
    maps=[dict(path=str(out/(sku+'-'+k+'.png')),sha256=sha(out/(sku+'-'+k+'.png')),native_resolution=list(Image.open(out/(sku+'-'+k+'.png')).size))for k in ['albedo','normal','orm']];dump(out/'material-validation.json',dict(valid=True,maps=maps,no_source_photo_upscale=True,source_master_unchanged=sha(master['path'])==master['sha256'],photo_pixels_baked=False,baked_reflections=False))
    report=C.export_assets(out/'model.json',out,aid);glb=out/(aid+'.glb');doc,binary=C.read_glb(glb);binary=M.embed_tangents(doc,binary)
    if hook:
        node0=next(i for i,n in enumerate(doc['nodes'])if n.get('mesh')==0);leaf=len(doc['nodes']);doc['nodes'].append(copy.deepcopy(doc['nodes'][node0]));root=len(doc['nodes']);doc['nodes'].append(dict(name='single-hook-centred-root',children=[leaf],translation=[.070,0,0]));doc['scenes'].append(dict(name='Single steel hook',nodes=[root]));doc['scene']=0
    C.write_glb(glb,doc,binary);report['deliverable_sha256']['glb']=sha(glb);report['glb_bytes']=glb.stat().st_size;dump(report['files']['validation'],report)
    keys=['id','sku','brand','name','category','url','dimensions_cm','source_dimensions_hwd_cm','official_measurements','estimated_dimensions','estimated_fields','diameter_semantics','scale_note','material_label','color','source_market','source_size_pointer','source_evidence_files','source_images','original_image','original_image_url','original_image_sha256','original_images','variant_status_verbatim','set_quantity','scene_variants','default_scene_index','quality_status','quality_label','quality_note','source_anomalies'];entry={k:meta[k]for k in keys};entry.update(asset_dir=str(out),model_path=str(out/'model.json'),glb_path=str(glb),sha256=sha(glb),bytes=glb.stat().st_size,model_revision='hmhome-approved-organic-cafe-curtain-2026-10-24-r1',geometry_validation=str(out/'geometry-validation.json'),material_validation=str(out/'material-validation.json'),size_source_kind='official_tr_public_pdp_and_category_exact_sku',size_source_urls=[source['url']]);dump(out/'entry.json',entry)
    p=R/'candidate-special-products-manifest.json';a=json.loads(p.read_text())if p.exists()else[];dump(p,[x for x in a if x['sku']!=sku]+[entry]);print('BUILT',sku,len(parts),'meshes',entry['bytes'],'bytes',flush=True)

if __name__=='__main__':
    for sku in sys.argv[1:]:build(sku)
