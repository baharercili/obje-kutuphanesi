from pathlib import Path
import json,hashlib
P=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
def dump(p,d):Path(p).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
sets=[
('root/towels-extra/frozen-plain19-v1-manifest.json','root/towels-extra/all19-review/browser-review/dom-checks-current.json',set()),
('softgoods/frozen-batch-09-manifest.json','softgoods/batches09-10-review/browser-review/dom-checks-current.json',set()),
('softgoods/frozen-batch-10-manifest.json','softgoods/batches09-10-review/browser-review/dom-checks-current.json',{'1339053001','1363057003','1363057004','1355322001','1348309001'}),
('textiles/soft-folded-revision02/frozen-four-layer-prototype-02-manifest.json','textiles/four-layer-review/browser-review/dom-checks-current.json',set()),
('textiles/printed-fitted-prototypes01/frozen-native-printed-fitted-03-manifest.json','textiles/method-prototypes-review/browser-review/dom-checks-current.json',set()),
('textiles/hemstitch-prototypes01/frozen-real-hemstitch-prototype-01-manifest.json','textiles/method-prototypes-review/browser-review/dom-checks-current.json',set()),
('textiles/patterned-table-prototypes01/frozen-patterned-table-prototypes-03-manifest.json','textiles/method-prototypes-review/browser-review/dom-checks-current.json',set()),
('hardgoods/optical-revision-final-01/frozen-approved-method03-manifest.json','hardgoods/optical-final27-review/browser-review/dom-checks-current.json',{'1307202010','1317827001','1317827003','1317827006','1325253001','1333471001','1360454001'}),
('decor-storage/frozen-batch01-active12-manifest.json','decor-storage/active12-review/browser-review/dom-checks-current.json',{'1351751001','1351752001','1351756003','1329200001','1329201001','1338089001'})]
for s in ['soft-linen-revision01/frozen-gravity-masa-runner-05-manifest.json','plain-tables-batch01/frozen-all-remaining-plain-tables-09-manifest.json','remaining-showers-batch01/frozen-remaining-showers-04-manifest.json','small-soft-forms-prototypes01/frozen-tieback-pair-01-manifest.json','bath-mitt-official-nominal-revision01/frozen-official-nominal-mitt-revision-01-manifest.json','flat-percale-bedding-batch01/frozen-flat-percale-bedding-02-manifest.json','folded-plain-family-batch01/frozen-all-remaining-plain-folded-08-manifest.json']:
 sets.append(('textiles/'+s,'textiles/next30-review/browser-review/dom-checks-current.json',set()))
approvals=read(P/'browser-approvals.json');rows=[];sources=[]
for manifest,evidence,excluded in sets:
 checks={x['selected']:x for x in read(P/evidence)};source=read(P/manifest);selected=[]
 for e in source:
  if e['sku']in excluded:continue
  assert 'frozen' in manifest and not e.get('quality_pending',False);b=checks[e['id']];assert not b['error']and e['sha256']in b['download'];assert sha(e['glb_path'])==e['sha256'];assert(P/evidence).parent.joinpath(e['id']+'.png').exists()
  approvals['models'][e['id']]=dict(approved=True,sha256=e['sha256'],sku=e['sku'],browser_evidence=b,notes='Root actual Three/own reference comparison, contact sheet visual review and native physical geometry/material QA passed. Explicit photo interpretations retained.',evidence_file=str(P/evidence))
  rows.append(e);selected.append(e['id'])
 sources.append(dict(manifest=str(P/manifest),sha256=sha(P/manifest),selected_ids=selected,held_skus=sorted(excluded)))
assert len(rows)==94 and len({e['id']for e in rows})==94
manifest=P/'root-reviewed-batch-06-manifest.json';assert not manifest.exists();dump(manifest,rows);dump(P/'browser-approvals.json',approvals);dump(P/'root-reviewed-batch-06-review-record.json',dict(models=94,source_products=len({e['sku']for e in rows}),manifest_sha256=sha(manifest),sources=sources,entire_736_complete=False,reviewer='root actual browser comparison'))
print(sha(manifest),len(rows),len({e['sku']for e in rows}))
