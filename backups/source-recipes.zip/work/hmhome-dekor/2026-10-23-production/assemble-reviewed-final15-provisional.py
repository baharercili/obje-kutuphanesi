from pathlib import Path
import json,hashlib,copy
P=Path(__file__).resolve().parent;S=P.parents[2]/'sites/zarahome-vazo-kutuphanesi-final-378'
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
specs=[
 dict(manifest='softgoods/fringe-r6-accepted-final-four/manifest.json',sha256='370d559f45a5ae8037930c0bd3bbc99e2f6a1b7aa62348d6c024ea22bc650790',evidence=['softgoods/fringe-brown6-actual-review/browser-review/dom-checks-current.json','softgoods/fringe-colours6-actual-review/browser-review/dom-checks-current.json']),
 dict(manifest='softgoods/source-fibre-seven-r6-accepted/manifest.json',sha256='4bdd83dd4c83b022345dceff0f67326d3f6cbfacf702029a9bfe2c6c965f861c',evidence=['softgoods/soft-seven6-actual-review/browser-review/dom-checks-current.json']),
 dict(manifest='decor-storage/frozen-tree-material-only1-revision18-manifest.json',sha256='4d91528d5096237498550dd9bef5ea1ba66f303f0057d6c8e6128563b4cdca07',evidence=['decor-storage/tree18-actual-review/browser-review/dom-checks-current.json'],native_metal_success_claimed=False),
 dict(manifest='softgoods/fur-projecting-own-three-r6/frozen-own-projecting-long-curly-short-fur-03-manifest.json',sha256='ce041e679758acfe9d714224c611f4452a218c25371e8933038aa8a1a634dd1a',evidence=['softgoods/fur-three6-actual-review/browser-review/dom-checks-current.json'],skus=['1355863002']),
]
# The final two are deliberately not inferred ready from file existence.
last=read(P/'root-final-two-approved-spec.json');assert last['root_actual_approved']is True and set(last['skus'])=={'1355345001','1357963001'};specs.append(last)
approvals=read(P/'browser-approvals.json');out=[];sources=[]
for spec in specs:
 manifest=P/spec['manifest'];assert sha(manifest)==spec['sha256'],str(manifest)
 checks={};paths={}
 for evidence in spec['evidence']:
  for b in read(P/evidence):checks[b['selected']]=b;paths[b['selected']]=P/evidence
 selected=[]
 for raw in read(manifest):
  if spec.get('skus')and raw['sku']not in spec['skus']:continue
  e=copy.deepcopy(raw);b=checks[e['id']];p=paths[e['id']];assert not b['error']and e['sha256']in b['download']and (p.parent/(e['id']+'.png')).is_file(),e['id']
  angles=p.parent/'four-angles.json';a={r['id']:r for r in read(angles)}[e['id']];assert a['sha256']==e['sha256']and len(a['views'])==4 and all(Path(v['path']).is_file()for v in a['views'])
  e['quality_pending']=False
  approvals['models'][e['id']]=dict(approved=True,sha256=e['sha256'],sku=e['sku'],browser_evidence=b,evidence_file=str(p),four_angle_evidence=str(angles),notes='Root personally viewed all four actual angles beside the exact own source photo. Physical source-specific fibre, tassel or glass revision accepted. Official and estimated measurement distinctions retained.',**({'native_metal_success_claimed':False}if spec.get('native_metal_success_claimed')is False else{}))
  out.append(e);selected.append(e['id'])
 sources.append(dict(manifest=str(manifest),sha256=spec['sha256'],selected_ids=selected,evidence_files=spec['evidence']))
assert len(out)==15 and len({x['id']for x in out})==15 and len({x['sku']for x in out})==15
catalog=read(S/'ui/hmhome-catalog.json');existing={x['sku']for x in catalog};initial={x['sku']for x in read(P/'initial-pending-736.json')};assert initial<=existing|{x['sku']for x in out};assert not {x['id']for x in out}&{x['id']for x in catalog}
target=P/'root-reviewed-batch-11-manifest.json';assert not target.exists();dump(target,out);dump(P/'browser-approvals.json',approvals)
dump(P/'root-reviewed-batch-11-review-record.json',dict(models=15,source_products=15,manifest_sha256=sha(target),sources=sources,all_initial736_have_reviewed_candidates=True,canonical_and_final_checks_still_required=True,reviewer='Root actual four-angle source comparison'))
print(sha(target),15,15)
