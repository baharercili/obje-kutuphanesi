import sys,json,math
from pathlib import Path
import numpy as np
sys.dont_write_bytecode=True
import engine as E
R=E.R;e=next(x for x in json.loads((R/'last19-review-list.json').read_text())if x['sku']=='1349831001');out=Path(e['asset_dir']);m=json.loads(Path(e['model_path']).read_text());front=next(g for g in m['meshes']if g['name']=='own-soft-stockings-front-back-cloth-panel-1');v=np.array(front['positions']).reshape(-1,3);tri=v[np.array(front['indices']).reshape(-1,3)];bins={};cell=.007
for i,t in enumerate(tri):
 lo=np.floor(t[:,:2].min(0)/cell).astype(int);hi=np.floor(t[:,:2].max(0)/cell).astype(int)
 for x in range(lo[0],hi[0]+1):
  for y in range(lo[1],hi[1]+1):bins.setdefault((x,y),[]).append(i)
cache={}
def surface(x,y):
 key=(round(x,10),round(y,10))
 if key in cache:return cache[key]
 ids=bins.get((math.floor(x/cell),math.floor(y/cell)),[]);t=tri[ids];a=t[:,0,:2];b=t[:,1,:2];c=t[:,2,:2];den=(b[:,1]-c[:,1])*(a[:,0]-c[:,0])+(c[:,0]-b[:,0])*(a[:,1]-c[:,1]);ok=np.abs(den)>1e-14;den=np.where(ok,den,1);u=((b[:,1]-c[:,1])*(x-c[:,0])+(c[:,0]-b[:,0])*(y-c[:,1]))/den;w=((c[:,1]-a[:,1])*(x-c[:,0])+(a[:,0]-c[:,0])*(y-c[:,1]))/den;q=1-u-w;inside=ok&(u>=-1e-6)&(w>=-1e-6)&(q>=-1e-6);assert inside.any(),(x,y);z=float((u[inside]*t[inside,0,2]+w[inside]*t[inside,1,2]+q[inside]*t[inside,2,2]).max());cache[key]=z;return z
for mesh in m['meshes']:
 if not mesh['material'].startswith('motif_'):continue
 v=np.array(mesh['positions']).reshape(-1,3);uv=np.array(mesh['uvs']).reshape(-1,2);f=np.array(mesh['indices']).reshape(-1,3);verts=[];uvs=[];faces=[]
 for face in f:
  p=v[face];q=uv[face];tiles=[(p,q)]
  for depth in range(2):
   new=[]
   for a,b in tiles:
    ab=(a[0]+a[1])/2;bc=(a[1]+a[2])/2;ca=(a[2]+a[0])/2;u=(b[0]+b[1])/2;w=(b[1]+b[2])/2;t=(b[2]+b[0])/2
    new.extend([(np.array([a[0],ab,ca]),np.array([b[0],u,t])),(np.array([ab,a[1],bc]),np.array([u,b[1],w])),(np.array([ca,bc,a[2]]),np.array([t,w,b[2]])),(np.array([ab,bc,ca]),np.array([u,w,t]))])
   tiles=new
  for a,b in tiles:k=len(verts);verts.extend(a);uvs.extend(b);faces.append([k,k+1,k+2])
 a=np.array(verts);groups={}
 for i,(x,y,z)in enumerate(a):groups.setdefault((round(x,10),round(y,10)),[]).append(i)
 for (x,y),ids in groups.items():
  z=a[ids,2];lo=z.min();hi=z.max();layer=np.where(hi-lo>1e-9,(z-lo)/max(hi-lo,1e-9),.5);a[ids,2]=surface(x,y)+.00045+layer*.00025
 normals=[]
 for face in faces:
  t=a[face];n=np.cross(t[1]-t[0],t[2]-t[0]);n/=np.linalg.norm(n);normals.extend([n]*3)
 mesh.update(positions=np.round(a,10).reshape(-1).tolist(),normals=np.round(normals,9).reshape(-1).tolist(),uvs=np.array(uvs).reshape(-1).tolist(),indices=np.array(faces).reshape(-1).tolist())
m['metadata']['ink_revision_note']+=' Each small embroidered ink face subdivided2 levels and reprojected onto the exact piecewise front-cloth surface, so raised cloth cannot bury the print between edge vertices.';e['ink_revision_note']=m['metadata']['ink_revision_note'];E.dump(e['model_path'],m);E.G.export_assets(Path(e['model_path']),out,e['id']);d,b=E.G.read_glb(e['glb_path']);d['samplers']=[dict(magFilter=9729,minFilter=9987,wrapS=10497,wrapT=10497)]
for t in d.get('textures',[]):t['sampler']=0
b=E.M.embed_tangents(d,b);E.G.write_glb(e['glb_path'],d,b);e.update(sha256=E.sha(e['glb_path']),bytes=Path(e['glb_path']).stat().st_size);E.dump(out/'entry.json',e)
for file in ['manifest.json','last19-review-list.json','last8-current-candidates.json']:
 p=R/file;data=json.loads(p.read_text());E.dump(p,[e if x['id']==e['id']else x for x in data])
proof=json.loads((R/'preacceptance-ink10-proof.json').read_text());next(q for q in proof if q['sku']==e['sku']).update(sha256=e['sha256'],own_motif_surface_subdivisions=2,body_geometry_unchanged=True);E.dump(R/'preacceptance-ink10-proof.json',proof);print('MOTIF SURFACE',e['id'],e['sha256'],len(cache))
