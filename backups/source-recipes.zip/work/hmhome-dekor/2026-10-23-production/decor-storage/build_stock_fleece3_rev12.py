"""Own native teddy fleece and real pile on three held stockings, separate immutable candidates."""
import sys,json,math,shutil
from pathlib import Path
import numpy as np
from PIL import Image,ImageFilter
sys.dont_write_bytecode=True
import engine as E
import build_fidelity7_rev11 as F
import build_woven8 as W
R=E.R;REV=R/'revision12';REV.mkdir(exist_ok=True);T=math.tau;rows=[];proof=[]

def fleece(pid,out,ma):
 box=(730,1660,986,1916)if pid=='1350119002'else(650,1400,906,1656);master=Path(F.OLD[pid]['original_image']);crop=Image.open(master).convert('RGB').crop(box);raw=REV/(pid+'-native-own-plain-teddy.png');crop.save(raw);a=np.array(crop.convert('L').filter(ImageFilter.GaussianBlur(.55)),float)-np.array(crop.convert('L').filter(ImageFilter.GaussianBlur(3.2)),float);a-=a.mean();a=np.clip(a/max(a.std(),1e-8),-2,2);base=np.array([110,78,54]if pid=='1300232002'else[193,169,144]if pid=='1350119001'else[240,236,224]);rgb=np.clip(base+a[:,:,None]*.7,0,255).astype('uint8');dy,dx=np.gradient(a*.27);normal=np.stack((-dx,-dy,np.ones_like(dx)),2);normal/=np.linalg.norm(normal,axis=2,keepdims=True);orm=np.zeros_like(rgb);orm[:]=[255,235,0]
 for slot,q in [('baseColorTexture',rgb),('normalTexture',np.clip((normal+1)*127.5,0,255).astype('uint8')),('metallicRoughnessTexture',orm)]:Image.fromarray(q).save(out/ma[slot],optimize=True)
 pr=REV/(pid+'-own-teddy-provenance.json');E.dump(pr,dict(master=str(master),master_sha256=F.OLD[pid]['original_image_sha256'],master_unchanged=E.sha(master)==F.OLD[pid]['original_image_sha256'],native_crop_box_pixels=list(box),native_crop_path=str(raw),crop_pixel_identity=True,material_native_pixels=list(crop.size),upscaled=False,geometric_resampling_count=0,physical_texel_period_m=.00025,method='Exact own-SKU plain teddy crop; excludes gift/candy/face/outline/backdrop. Own band-pass curl/fibre microrelief only, broad photo colour/shadows rejected. Intrinsic nearly uniform albedo varies under3RGBlevels; native curled pile normal and real closed3Dcurl geometry carry relief. Metric UVs cover all body panels, cuffs, ears and paws.',intrinsic_rgb=base.tolist(),albedo_rgb_range=[rgb.reshape(-1,3).min(0).tolist(),rgb.reshape(-1,3).max(0).tolist()]));ma.update(normalScale=.9);ma['extras'].update(own_photo_material_crop=True,native_crop_provenance=str(pr),native_resolution=list(crop.size),source_effective_detail_pixels=list(crop.size),intrinsic_illumination_removed=True,grain_safe_albedo=True,physical_texel_period_m=.00025);return pr,raw,crop.size

def pile(pid,meshes,bbox):
 rng=np.random.default_rng(int(pid[-6:])+121212);parts=[];counts={};lo,hi=bbox
 for mesh in meshes:
  if mesh['material']!='fur':continue
  p=np.array(mesh['positions']).reshape(-1,3);f=np.array(mesh['indices']).reshape(-1,3);tri=p[f];cross=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]);ar=np.linalg.norm(cross,axis=1);norm=cross/np.maximum(ar[:,None],1e-20);inds=np.flatnonzero(ar>1e-13);weights=ar[inds];weights/=weights.sum();name=mesh['name'];count=2700 if'front-back-cloth-panel'in name else 750 if'cuff'in name else 450 if'ear'in name or'paw'in name else 150;counts[name]=count
  for j in range(count):
   i=int(rng.choice(inds,p=weights));a,b=rng.random(2);a=math.sqrt(a);q=(1-a)*tri[i,0]+a*(1-b)*tri[i,1]+a*b*tri[i,2];n=norm[i];guide=np.array([0,1,0])if abs(n[1])<.8 else np.array([1,0,0]);u=np.cross(n,guide);u/=np.linalg.norm(u);v=np.cross(n,u);phi=rng.uniform(0,T);u,v=u*math.cos(phi)+v*math.sin(phi),-u*math.sin(phi)+v*math.cos(phi);length=rng.uniform(.0014,.0028)if pid=='1300232002'else rng.uniform(.0011,.0022);rad=rng.uniform(.000075,.00011);pts=[]
   for t in np.linspace(0,1,5):
    x=q+n*(.00006+length*.7*math.sin(math.pi*t))+u*length*.35*math.sin(T*1.25*t)+v*length*.50*t;x=np.clip(x,lo+rad*2,hi-rad*2);pts.append(tuple(x))
   parts.append(W.tube('own-longer-teddy-closed-curled-fibre-'+str(len(parts)),'fur',pts,rad,rad,False,sides=4))
 return F.mesh_from_raw(W.merge('own-all-over-source-specific-teddy-pile','fur',parts)),counts

for pid in ['1300232002','1350119001','1350119002']:
 old=F.OLD[pid];id=old['id']+'-fleecerev12';out=R/'models'/id;assert not out.exists();out.mkdir();m=json.loads(Path(old['model_path']).read_text());oldbox=np.concatenate([np.array(g['positions']).reshape(-1,3)for g in m['meshes']]);bbox=(oldbox.min(0),oldbox.max(0))
 for p in Path(old['asset_dir']).glob('*.png'):
  if p.name not in ['on.png','yan.png','on-capraz.png','ustten.png']:shutil.copyfile(p,out/p.name)
 ma=m['materials'].pop('body');m['materials']['fur']=ma;pr,raw,size=fleece(pid,out,ma);m['meshes']=[g for g in m['meshes']if'curled-short-fleece-pile'not in g['name']]
 for g in m['meshes']:
  if g['material']=='body'or(pid=='1300232002'and g['material']=='cuff'):g['material']='fur';F.physical_uv(g,size[0]*.00025,size[1]*.00025)
 if pid=='1300232002':m['materials'].pop('cuff',None)
 hairs,counts=pile(pid,m['meshes'],bbox);m['meshes'].append(hairs);v=np.concatenate([np.array(g['positions']).reshape(-1,3)for g in m['meshes']]);lo=v.min(0);hi=v.max(0);dim=np.array(old['dimensions_cm'])/100;targetlo=np.array([-dim[0]/2,0,-dim[2]/2]);scale=dim/(hi-lo)
 for g in m['meshes']:
  p=np.array(g['positions']).reshape(-1,3);n=np.array(g['normals']).reshape(-1,3);p=(p-lo)*scale+targetlo;n/=scale;n/=np.linalg.norm(n,axis=1)[:,None];g.update(positions=np.round(p,9).reshape(-1).tolist(),normals=np.round(n,9).reshape(-1).tolist())
 note='Kendi düz teddy kumaşından doğal çözünürlükte mikro hav; yansız ince taneli albedo, gerçek kıvırcık uzun hav normali ve gövde/kulak/pençe üzerinde kapalı3Dl lifler. Desen/karakter veya tüm kahraman fotoğrafı gövdeye sarılmaz. Yayımlanmış41cm toplam korunur.';e=dict(old,id=id,asset_dir=str(out),model_path=str(out/'model.json'),glb_path=str(out/(id+'.glb')),geometry_validation=str(out/'geometry-validation.json'),material_validation=str(out/'material-validation.json'),source_evidence_files=old['source_evidence_files']+[str(pr),str(raw)],material_pattern_provenance=str(pr),model_revision='hm-source-teddy-fleece-revision12',model_status='candidate_pending_independent_native_and_root_actual',quality_pending=True,real_short_curled_fibre_count=sum(counts.values()))
 for k in['frozen','native_renders','scn_path','source_comparison_path','independent_validation_file','visual_validation_file','production_manifest','production_frozen']:e.pop(k,None)
 m['metadata'].update(id=id,material_pattern_provenance=str(pr),source_evidence_files=e['source_evidence_files'],source_fidelity_revision_note=note,real_short_curled_fibre_count=sum(counts.values()),pile_surface_coverage_counts=counts,metric_recalibration_scale=scale.tolist());E.dump(e['model_path'],m);geo=json.loads(Path(old['geometry_validation']).read_text());geo.update(mesh_count=len(m['meshes']),triangles=sum(len(g['indices'])//3 for g in m['meshes']),final_validation_pending=True);geo['features'].append(note);E.dump(e['geometry_validation'],geo);maps=[]
 for key,ma in m['materials'].items():
  for slot in['baseColorTexture','normalTexture','metallicRoughnessTexture']:
   p=out/ma[slot];maps.append(dict(material=key,slot=slot,path=str(p),sha256=E.sha(p),native_resolution=list(Image.open(p).size)))
 E.dump(e['material_validation'],dict(valid=True,maps=maps,source_masters_unchanged=True,photo_rgb_projected=False));E.G.export_assets(Path(e['model_path']),out,id);d,b=E.G.read_glb(e['glb_path']);d['samplers']=[dict(magFilter=9729,minFilter=9987,wrapS=10497,wrapT=10497)]
 for t in d.get('textures',[]):t['sampler']=0
 b=E.M.embed_tangents(d,b);E.G.write_glb(e['glb_path'],d,b);e.update(sha256=E.sha(e['glb_path']),bytes=Path(e['glb_path']).stat().st_size);E.dump(out/'entry.json',e);rows.append(e);proof.append(dict(sku=pid,previous_sha256=old['sha256'],previous_frozen_glb_unchanged=E.sha(old['glb_path'])==old['sha256'],id=id,sha256=e['sha256'],own_crop_provenance=str(pr),real_pile_count=sum(counts.values()),metric_calibration_scale=scale.tolist(),no_full_photo_bake=True));E.dump(REV/'stockings3-candidates.json',rows);E.dump(REV/'stockings3-source-proof.json',proof);current=json.loads((R/'manifest.json').read_text());E.dump(R/'manifest.json',current+[e]);print('FLEECE12',pid,e['bytes'],sum(counts.values()),flush=True)
