"""Preserve only exact image URLs already returned in the saved own-SKUsource queue."""
from pathlib import Path
import json,urllib.request,hashlib,io,concurrent.futures
from PIL import Image
R=Path(__file__).resolve().parent;out=R/'originals';out.mkdir(exist_ok=True);queue=json.loads((R/'source-queue-72.json').read_text())['products'];jobs=[(p['sku'],q)for p in queue for q in p['reference_images']];seen=set();jobs=[j for j in jobs if not(j[1]['url']in seen or seen.add(j[1]['url']))]
def get(job):
 sku,q=job;url=q['url'];key=hashlib.sha256(url.encode()).hexdigest()[:12];p=out/(sku+'-'+key+'.jpg')
 try:
  if not p.exists():
   b=urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0'}),timeout=40).read();im=Image.open(io.BytesIO(b));assert im.format=='JPEG'and min(im.size)>500;p.write_bytes(b)
  b=p.read_bytes();im=Image.open(io.BytesIO(b));return dict(sku=sku,url=url,alt=q.get('alt',''),path=str(p),sha256=hashlib.sha256(b).hexdigest(),native_pixels=list(im.size),format=im.format,icc_sha256=hashlib.sha256(im.info.get('icc_profile',b'')).hexdigest(),immutable_original=True,upscaled=False)
 except Exception as e:return dict(sku=sku,url=url,error=str(e))
with concurrent.futures.ThreadPoolExecutor(max_workers=6)as pool:results=list(pool.map(get,jobs))
good=[x for x in results if'error'not in x];errors=[x for x in results if'error'in x];(R/'original-image-gallery-masters.json').write_text(json.dumps(good,ensure_ascii=False,indent=2)+'\n');(R/'original-image-gallery-errors.json').write_text(json.dumps(errors,ensure_ascii=False,indent=2)+'\n');print('Preserved',len(good),'native JPEGs for',len({x['sku']for x in good}),'SKU; errors',len(errors),flush=True)
