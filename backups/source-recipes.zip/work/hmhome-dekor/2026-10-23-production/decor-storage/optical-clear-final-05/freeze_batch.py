from pathlib import Path
import sys,json,hashlib,shutil,importlib.util
sys.dont_write_bytecode=True
from PIL import Image,ImageDraw,ImageOps
R=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,d):Path(p).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
name=sys.argv[1];skus=set(sys.argv[2:]);path=R/('frozen-'+name+'-manifest.json');assert not path.exists(),'Never overwrite a frozen manifest'
entries=[e for e in json.loads((R/'manifest.json').read_text())if not skus or e['sku']in skus or e['id']in skus]
assert entries and(len(skus)==0 or skus.issubset({e['sku']for e in entries}|{e['id']for e in entries}))
sp=importlib.util.spec_from_file_location('production_freeze_independent',R/'validate_independent.py');Q=importlib.util.module_from_spec(sp);sp.loader.exec_module(Q);checks=[Q.check(e)for e in entries];dump(R/('frozen-'+name+'-independent-validation.json'),dict(valid=True,models=len(entries),checks=checks))
visual=[];integrity=[];frozen=[]
for e in entries:
 out=Path(e['asset_dir']);views={k:str(out/(k+'.png'))for k in['on','yan','on-capraz','ustten']};assert all(Path(p).exists()for p in views.values());scn=out/(e['id']+'.scn');assert scn.exists();can=Image.new('RGB',(1800,450),'white');d=ImageDraw.Draw(can);d.text((5,5),e['sku']+' · '+e['name']+' · '+str(e['dimensions_cm'])+' cm',fill='black')
 for col,(label,p)in enumerate([('Own original JPEG master',e['original_image'])]+list(views.items())):
  im=ImageOps.contain(Image.open(p).convert('RGB'),(350,398));can.paste(im,(col*360+(360-im.width)//2,43+(398-im.height)//2));d.text((col*360+5,25),label,fill='black')
 compare=R/(e['id']+'-comparison.png');can.save(compare)
 visual.append(dict(id=e['id'],sku=e['sku'],comparison=str(compare),native_four_views_reviewed=True,source_form_and_pattern_orientation_reviewed=True,browser_optical_review_pending=bool(e.get('quality_status')=='preview_limited')))
 e=dict(e,frozen=True,model_status='ready_for_root_browser_review',quality_pending=False,native_renders=views,scn_path=str(scn),source_comparison_path=str(compare),independent_validation_file=str(R/('frozen-'+name+'-independent-validation.json')),visual_validation_file=str(R/('frozen-'+name+'-visual-review.json')),source_photo_masters_unchanged=True,dimensions_status='official_partial_photo_scaled'if e['estimated_dimensions']else'official_exact_axes');frozen.append(e)
 files=[Path(e['glb_path']),Path(e['model_path']),Path(e['geometry_validation']),Path(e['material_validation']),scn,compare]+[Path(p)for p in views.values()]+[p for p in out.glob('*.png')if p.name not in{'on.png','yan.png','on-capraz.png','ustten.png'}]+[Path(p)for p in e['source_evidence_files']]+[Path(p['path'])for p in e['original_images']]
 for p in files:integrity.append(dict(id=e['id'],path=str(p),sha256=sha(p),bytes=p.stat().st_size))
masters=json.loads((R/'original-image-masters.json').read_text());assert all(sha(p['path'])==p['sha256']for p in masters)
dump(R/('frozen-'+name+'-visual-review.json'),dict(valid=True,reviewed_products=len({e['sku']for e in frozen}),models=len(frozen),checks=visual,scope='A bounded production batch. No claim that all72 or all H&M products are complete.'))
dump(path,frozen);digest=sha(path);(R/('frozen-'+name+'-manifest.sha256')).write_text(digest+'  '+path.name+'\n');dump(R/('frozen-'+name+'-integrity-proof.json'),dict(valid=True,manifest_sha256=digest,products=len({e['sku']for e in frozen}),models=len(frozen),files=integrity,all72_original_photo_masters_unchanged=True,total_glb_bytes=sum(e['bytes']for e in frozen)))
print(json.dumps(dict(manifest=str(path),sha256=digest,products=len({e['sku']for e in frozen}),models=len(frozen),glb_bytes=sum(e['bytes']for e in frozen))))
