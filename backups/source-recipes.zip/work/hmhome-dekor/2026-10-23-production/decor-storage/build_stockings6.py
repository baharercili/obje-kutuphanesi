"""Six own Christmas stockings: true soft open pouches, cuffs, embroideries and bear details."""
import sys,math,json
sys.dont_write_bytecode=True
import numpy as np
from PIL import Image,ImageFilter
import build_decor11 as A
import build_cloth7 as C
import build_bear_wall7 as F
import source_fibre_material as SF
E=A.E;R=E.R;P=A.P;W=A.W;B=E.B;T=math.tau

def outline(bear=False):
 # Own traced hanging silhouette, toe to the right. Every cloth panel has a real thickness.
 points=[(-.100,.395),(.095,.395),(.095,.285),(.094,.205),(.099,.157),(.116,.128),(.148,.104),(.160,.076),(.156,.047),(.139,.022),(.106,.008),(.064,.008),(.016,.021),(-.032,.047),(-.071,.082),(-.093,.123),(-.100,.181),(-.100,.295)]
 if bear:points=[(x,y*.93)for x,y in points]
 smooth=A.curve(points[1:]+[points[0]],7);poly=[points[0]]+smooth[:-1]
 for _ in range(5):
  keep=[]
  for i,b in enumerate(poly):
   a=np.array(poly[i-1]);b=np.array(b);c=np.array(poly[(i+1)%len(poly)]);u=b-a;v=c-b
   if np.linalg.norm(u)<.0001 or abs(u[0]*v[1]-u[1]*v[0])<1e-10:continue
   keep.append(tuple(b))
  if len(keep)==len(poly):break
  poly=keep
 return poly

def inside(x,y,poly):
 c=False
 for (x0,y0),(x1,y1)in zip(poly,poly[1:]+poly[:1]):
  if((y0>y)!=(y1>y))and x<(x1-x0)*(y-y0)/(y1-y0)+x0:c=not c
 return c

def distance(x,y,poly):
 # Top mouth excluded from the side-seam distance, leaving an open, rounded mouth.
 a=np.array(poly[1:]+poly[:1]);b=np.array(poly[2:]+poly[:2]);q=np.array([x,y]);ab=b-a;t=np.clip(((q-a)*ab).sum(1)/np.maximum((ab*ab).sum(1),1e-12),0,1);return np.sqrt(((a+t[:,None]*ab-q)**2).sum(1)).min()

def puff(x,y,poly):return .004+.018*min(1,distance(x,y,poly)/.040)

def subdiv(g,n=2):
 v=g['_vertices'];uv=g['_uvs'];f=g['_faces']
 for _ in range(n):
  vv=list(v);uu=list(uv);edges={};ff=[]
  def mid(a,b):
   k=tuple(sorted((a,b)))
   if k not in edges:edges[k]=len(vv);vv.append(tuple((np.array(v[a])+v[b])/2));uu.append(tuple((np.array(uv[a])+uv[b])/2))
   return edges[k]
  for a,b,c in f:d=mid(a,b);e=mid(b,c);q=mid(c,a);ff.extend([(a,d,q),(d,b,e),(q,e,c),(d,e,q)])
  v,uv,f=vv,uu,ff
 return E.raw(g['name'],g['material'],v,f,uv)

def ellipsoid(name,key,cx,cy,cz,rx,ry,rz):
 g=P.sphere(name,key,1);g['_vertices']=[(cx+x*rx,cy+y*ry,cz+z*rz)for x,y,z in g['_vertices']];return g

def body_pouch(pid,bear=False):
 poly=outline(bear);parts=[]
 for side in [-1,1]:
  g=P.extruded('own-soft-stockings-front-back-cloth-panel-'+str(side),'body',poly,[],-.00075,.00075);g=subdiv(g,2);g['_vertices']=[(x,y,side*puff(x,y,poly)+z)for x,z,y in g['_vertices']];g['_uvs']=[(x/.08+.5,1-y/.08)for x,y,z in g['_vertices']];parts.append(g)
 seam=[(x,y,0)for x,y in poly[1:]+poly[:1]];parts.append(W.tube('own-continuous-sewn-side-toe-gusset-with-open-top-mouth','body',seam,.0047,.0012,False,[0,0,1],8))
 # Genuine fabric hanging loop, not a pin or a photo shadow.
 cx=-.087;cy=.394 if not bear else .382;pts=[(cx+.008*math.sin(a),cy+.020*(1+math.cos(a)),0)for a in np.linspace(0,T,144,endpoint=False)];parts.append(W.tube('own-real-flat-fabric-hanging-loop','loop',pts,.0032,.0006,True,[0,0,1],8))
 return parts,poly

def cuff(parts,white=True):
 g=E.lathe('own-real-hollow-folded-cuff-with-open-oval-mouth','cuff',[(.96,.339),(1,.346),(1,.397),(.98,.405),(.86,.405),(.85,.397),(.85,.347),(.94,.340)],256);g['_vertices']=[(-.002+x*.103,y,z*.038)for x,y,z in g['_vertices']];parts.append(g)
 if white:
  for side in [-1,1]:
   for j in range(7):parts.append(ellipsoid('own-seven-soft-vertical-fur-cuff-ribs-'+str(side)+'-'+str(j),'cuff',-.090+j*.029,.371,side*.037,.017,.034,.010))
  for j,y in enumerate([.350,.320]):parts.append(ellipsoid('own-real-fluffy-pompon-'+str(j),'cuff',-.119,y,.014,.015,.018,.014))
  # Actual short pile makes the seven sewn ribs and pompoms visibly soft.
  rng=np.random.default_rng(7401);hair=[]
  for i in range(700):
   side=1 if i%2 else-1;j=i%7;zz=rng.uniform(.25,1);a=rng.uniform(0,T);xx=math.sqrt(1-zz*zz)*math.cos(a);yy=math.sqrt(1-zz*zz)*math.sin(a);q=np.array([-.090+j*.029+xx*.017,.371+yy*.034,side*(.037+zz*.010)]);n=np.array([xx*.6,yy*.5,side*zz]);n/=np.linalg.norm(n);pts=[tuple(q+n*(.0018*math.sin(math.pi*t))+np.array([.0003*math.sin(T*t),.001*t,0]))for t in np.linspace(0,1,5)];hair.append(W.tube('own-real-short-white-cuff-pile-'+str(i),'cuff',pts,.00014,.00014,False,sides=5))
  parts.append(W.merge('own700real-short-fur-cuff-fibres','cuff',hair))
  for y in [.350,.320]:parts.append(W.tube('own-fine-pompom-suspension-thread','loop',[(-.094,.397,.013),(-.119,y+.015,.014)],.0006,.0006,False,sides=6))

def pile(parts,poly,key,count,seed):
 rng=np.random.default_rng(seed);fibre=[];n=0
 while n<count:
  x=rng.uniform(-.102,.163);y=rng.uniform(.015,.394)
  if not inside(x,y,poly)or distance(x,y,poly)<.002:continue
  side=1 if n%2 else-1;z=side*(puff(x,y,poly)+.0007);length=rng.uniform(.001,.003);pts=[(x+length*.3*math.sin(T*t),y+length*t,z+side*length*.65*math.sin(math.pi*t))for t in np.linspace(0,1,6)];fibre.append(W.tube('own-curly-pile-fibre-'+str(n),key,pts,.00016,.00016,False,sides=5));n+=1
 parts.append(W.merge('own-real-curled-short-fleece-pile-'+key,key,fibre))

MOTIFS={'letter':((515,1080,635,1210),-.046,.273,.030,.0325),'bauble':((825,1115,965,1250),.035,.265,.036,.0347),'cane':((340,1380,460,1560),-.062,.178,.030,.045),'ginger':((640,1470,790,1650),.020,.167,.038,.0456),'tree':((700,1815,900,2010),.099,.060,.045,.0439),'star':((615,925,680,990),-.050,.325,.015,.015)}

def motifs(parts,poly):
 for key,(_,cx,cy,w,h)in MOTIFS.items():
  g=C.panel('own-exact-native-embroidered-'+key,'motif_'+key,w,h,0,cy,.0004,.001);g=P.shift(g,x=cx)
  g['_vertices']=[(x,y,puff(x,y,poly)+.0011+z)for x,y,z in g['_vertices']];g['_uvs']=[((x-cx)/w+.5,1-((y-cy)/h+.5))for x,y,z in g['_vertices']];parts.append(g)
 # Same own gold star motif, repositioned as the actual scattered gold stitches.
 for cx,cy in [(-.048,.218),(.052,.205),(-.014,.087)]:
  g=C.panel('own-repeated-exact-gold-embroidered-star','motif_star',.013,.013,0,cy,.0004,.001);g=P.shift(g,x=cx);g['_vertices']=[(x,y,puff(x,y,poly)+.0011+z)for x,y,z in g['_vertices']];g['_uvs']=[((x-cx)/.013+.5,1-((y-cy)/.013+.5))for x,y,z in g['_vertices']];parts.append(g)

def bear_details(parts,poly,white):
 for side in[-1,1]:
  parts.append(ellipsoid('own-rounded-plush-bear-ear-'+str(side),'body',side*.074,.380,-.002,.024,.026,.012));parts.append(ellipsoid('own-inner-bear-ear-embroidery-'+str(side),'muzzle',side*.074,.382,.010,.013,.015,.003));parts.append(ellipsoid('own-sewn-black-bear-eye-'+str(side),'black',side*.033,.339,.024,.0034,.0034,.0012));parts.append(ellipsoid('own-soft-bearing-paw-'+str(side),'body',side*.047,.248,.029,.023,.022,.015))
 parts.append(ellipsoid('own-cream-oval-bear-muzzle','muzzle',0,.306,.028,.023,.019,.008));parts.append(ellipsoid('own-black-sewn-bear-nose','black',0,.314,.036,.006,.005,.0016));parts.append(W.tube('own-fine-bear-mouth-stitch','black',[(0,.309,.036),(0,.300,.036)],.0006,.0006,False,sides=6))
 if white:
  pts=[(.012,.215,.041),(.012,.281,.041)]+[(.012+.015*(1-math.cos(a)),.281+.015*math.sin(a),.041)for a in np.linspace(0,math.pi,70)[1:]]+[(.042,.263,.041)];parts.append(W.tube('own-three-dimensional-red-white-candy-cane-in-paws','candy',pts,.006,.006,False,[0,0,1],12))
 else:
  gift=P.extruded('own-real-small-red-wrapped-gift-held-by-bear','red',P.rounded_rect(.054,.050,.004,20),[],-.012,.012);gift['_vertices']=[(x,y+.245,.042+z)for x,z,y in gift['_vertices']];parts.append(gift)
  for x in[-.002,.002]:parts.append(W.tube('own-cream-gift-wrapping-ribbon','muzzle',[(x,.220,.055),(x,.270,.055)],.002,.0004,False,[0,0,1],8))
  for side in[-1,1]:parts.append(W.tube('own-cream-gift-bow-loop-'+str(side),'muzzle',[(side*(.007+.007*math.cos(a)),.269+.004*math.sin(a),.055)for a in np.linspace(0,T,96,endpoint=False)],.0018,.0004,True,[0,0,1],8))

def geometry(pid):
 bear=pid.startswith('1350119');parts,poly=body_pouch(pid,bear)
 if pid in ['1348487001','1348487002']:cuff(parts,True)
 elif pid=='1300232002':cuff(parts,False);pile(parts,poly,'body',1000,int(pid[-5:]))
 elif pid=='1349831001':
  ring=E.lathe('own-red-cotton-folded-cuff-with-real-open-mouth','red',[(.98,.337),(1,.343),(1,.398),(.98,.403),(.87,.403),(.87,.341)],256);ring['_vertices']=[(-.002+x*.103,y,z*.037)for x,y,z in ring['_vertices']];parts.append(ring);motifs(parts,poly)
 elif bear:bear_details(parts,poly,pid=='1350119002');pile(parts,poly,'body',800,int(pid[-5:]))
 if pid=='1300232002':
  for g in parts:g['_vertices']=[(-x,y,z)for x,y,z in g['_vertices']]
 extras=dict(real_open_stocking_pouch=True,real_cloth_front_back_thickness=True,source_pattern_reconstructed_from_own_photo=True,official_height_assignment_note='Published41cmstocking height retained as a source fact; hanging loop and local cuff/ear allocation are estimated. Total hanging envelope is declared separately.')
 if pid in ['1348487001','1348487002']:extras['material_pattern_provenance']=str(R/(pid+'-body-own-fibre-provenance.json'))
 if pid=='1349831001':extras['material_pattern_provenance']=str(R/(pid+'-motif-letter-provenance.json'))
 return parts,['Own soft toe/heel stocking silhouette, real hollow cloth pouch and actual open top','Separate physical folded cuff, suspension loop and own source pompoms/bear paws/ears where present','Native exact embroidery print masks isolated from own master only on embroidered SKU; intrinsic cloth replaces photographed lighting','Actual short curled pile on fuzzy stockings; full depth and hanging-envelope interpretation explicitly approximate'],extras

BASE=E.material

def material(pid,key,**args):
 out,ma=BASE(pid,key,**args)
 if key=='cuff'and pid in ['1348487001','1348487002']:return SF.apply(E,pid,key,out,ma,args,box=(490,500,554,628),highpass=5)
 if key=='body'and pid in ['1348487001','1348487002']:return SF.apply(E,pid,key,out,ma,args,box=(550,1100,950,1500),highpass=7)
 if key.startswith('motif_'):
  motif=key[6:];box=MOTIFS[motif][0];master=next(m for m in E.MASTERS if m['sku']==pid);crop=Image.open(master['path']).convert('RGB').crop(box);native=R/(pid+'-motif-'+motif+'-native.png');crop.save(native);a=np.array(crop,float);r,g,b=a[:,:,0],a[:,:,1],a[:,:,2];alpha=((r-g>35)|((g-r>10)&(g>b))|(a.max(2)<130)|((r-g>15)&(b<155)))
  if motif=='letter':alpha|=((abs(r-g)<16)&(b-g>-12)&(g>170))
  rgb=np.zeros_like(a)+[233,232,222];rgb[(r-g>35)&(r>b*1.3)]=[154,23,38];rgb[(g-r>10)&(g>b)]=[54,85,48];rgb[(r-g>15)&(b<155)&~(r-g>35)]=[164,129,68];rgb[a.max(2)<130]=[32,32,29]
  if motif=='ginger':rgb[(r>g*1.12)&(g>b*1.08)&~(r>g*1.65)]=[145,92,59]
  rgba=np.dstack((rgb.astype('uint8'),alpha.astype('uint8')*255));normal=np.zeros_like(rgb,dtype='uint8');normal[:]=[128,128,255];orm=np.zeros_like(normal);orm[:]=[255,211,0]
  for slot,q in [('baseColorTexture',rgba),('normalTexture',normal),('metallicRoughnessTexture',orm)]:Image.fromarray(q).save(out/ma[slot],optimize=True)
  proof=R/(pid+'-motif-'+motif+'-provenance.json');ma.update(alphaMode='MASK',alphaCutoff=.5);ma['extras'].update(own_photo_material_crop=True,native_crop_provenance=str(proof),native_resolution=list(crop.size),source_effective_detail_pixels=list(crop.size),intrinsic_illumination_removed=True);E.dump(proof,dict(master=master['path'],master_sha256=master['sha256'],master_unchanged=E.sha(master['path'])==master['sha256'],native_crop_box_pixels=list(box),native_crop_path=str(native),crop_pixel_identity=True,material_native_pixels=list(crop.size),upscaled=False,geometric_resampling_count=0,method='Exact own native isolated embroidery motif mask; native crop preserved. Quantized intrinsic thread colours on transparent background. No photographed cloth, whole stocking, backdrop or lighting projected. Each motif map stays at exact native crop pixels.'))
 if key=='candy':
  p=out/ma['baseColorTexture'];im=np.array(Image.open(p));hh,ww=im.shape[:2];u=np.arange(ww)[None,:]/ww;v=np.arange(hh)[:,None]/hh;mask=np.sin(T*(v*5+u))>.1;im[mask]=[174,27,40];im[~mask]=[236,231,215];Image.fromarray(im).save(p,optimize=True)
 for slot in ['baseColorTexture','normalTexture','metallicRoughnessTexture']:
  im=Image.open(out/ma[slot]);ex=im.getextrema()
  if max(im.size)>256 and all(a==b for a,b in ex):Image.new(im.mode,(256,256),im.getpixel((0,0))).save(out/ma[slot],optimize=True)
 ma['extras']['native_resolution']=list(Image.open(out/ma['baseColorTexture']).size)
 return out,ma
E.material=material
red=dict(color=[155,19,39],rough=.80,kind='cotton');white=dict(color=[236,232,219],rough=.93,kind='cotton');black=dict(color=[28,25,22],rough=.85);specs=[]
for pid in ['1300232002','1348487001','1348487002','1349831001','1350119001','1350119002']:
 bear=pid.startswith('1350119');brown=pid in ['1300232002','1350119001'];cream=pid in ['1349831001','1350119002'];color=[121,85,56]if pid=='1300232002'else[172,148,120]if brown else[238,232,214]if cream else[143,20,39]if pid=='1348487001'else[31,67,42];mats={'body':dict(color=color,rough=.91 if brown or bear else .78,kind='cotton'),'loop':dict(color=color,rough=.80,kind='cotton')}
 if pid in ['1300232002','1348487001','1348487002']:mats['cuff']=dict(color=color if brown else[238,233,220],rough=.93,kind='cotton')
 if pid=='1349831001':
  mats['red']=red
  for key in MOTIFS:mats['motif_'+key]=dict(color=[240,237,222],rough=.85)
 if bear:mats.update(muzzle=white,black=black,red=red,candy=dict(color=[235,230,214],rough=.64,kind='cotton'))
 dims=[26,45,6]if bear else[22,43,5]if pid=='1349831001'else[31,43,5];official={'stocking_height_cm':[41],('upper_width_cm'if bear else'width_cm'):[21 if bear else dims[0]]};live=pid in ['1348487001','1348487002'];evidence=R/('source-evidence/'+pid+'.json')if live else R/('research-21.txt'if bear else'research-20.txt');allfiles=[str(evidence)]
 if pid in ['1348487001','1348487002']:allfiles +=[str(R/(pid+'-'+key+'-own-fibre-provenance.json'))for key in ['body','cuff']]+[str(R/(pid+'-'+key+'-native-own-fibre-crop.png'))for key in ['body','cuff']]
 if pid=='1349831001':allfiles +=[str(R/(pid+'-motif-'+key+'-provenance.json'))for key in MOTIFS]+[str(R/(pid+'-motif-'+key+'-native.png'))for key in MOTIFS]
 name={'1300232002':'Kahverengi kıvırcık tüylü yılbaşı çorabı','1348487001':'Kırmızı velur ponponlu beyaz kürk ağızlı yılbaşı çorabı','1348487002':'Koyu yeşil velur ponponlu beyaz kürk ağızlı yılbaşı çorabı','1349831001':'Kırmızı ağızlı özgün motif nakışlı krem yılbaşı çorabı','1350119001':'Hediye tutan kahverengi ayı yılbaşı çorabı','1350119002':'Şeker bastonu tutan kutup ayısı yılbaşı çorabı'}[pid]
 specs.append(dict(sku=pid,name=name,dims=dims,hwd=[dims[1],dims[0],dims[2]],official=official,estimated=['height_cm','depth_cm','hanging_loop_pose','local_cloth_depth_and_cuff_dimensions']+(['width_cm']if bear else[]),geometry=lambda pid=pid:geometry(pid),size_url='https://www2.hm.com/'+('tr_tr'if live or pid=='1349831001'else'fr_fr'if pid=='1350119002'else'en_in'if pid=='1300232002'else'tr_tr')+'/productpage.'+pid+'.html',market='Türkiye'if live or pid in ['1349831001','1350119001']else'France'if pid=='1350119002'else'India',label='Pamuk ana kumaş · Polyester dolgu'if pid=='1349831001'else'Polyester %100',color=name,claim='Exact ownSKU'+pid+' official41cmstocking height and published width retained separately. Full hanging-loop envelope and cloth depth are explicitly photo estimates.',evidence_files=allfiles,note='Resmî41cmçorap boyu kaynakta saklıdır; açık askı dahil toplam poz43/45cm, derinlik, kıvrım/dikiş/ponpon ve yerel parça ölçüleri kendi fotoğrafından açık yaklaşık yorumdur. Ayı tasarımlarında21cmüst genişlik alanı tam ayak genişliği gibi gösterilmez.',materials=mats))
if __name__=='__main__':
 for s in specs:
  if len(sys.argv)==1 or s['sku']in sys.argv[1:]:E.build(s)
