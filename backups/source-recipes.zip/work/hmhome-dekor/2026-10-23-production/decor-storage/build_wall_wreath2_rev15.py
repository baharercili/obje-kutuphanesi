"""Two remaining forms: fully sampled soft cloth pockets and truly spherical slotted bells."""
import sys,json,math,shutil
from pathlib import Path
import numpy as np
sys.dont_write_bytecode=True
import revision14_common as C
import build_fidelity3_rev13 as S
import build_woven8 as W
import build_first12 as P
E=C.E;F=C.F;R=C.R;REV=R/'revision15';REV.mkdir(exist_ok=True);C.REV=REV;T=math.tau
OLD={e['sku']:e for e in json.loads((R/'frozen-softcloth3-revision13-manifest.json').read_text())}

def start(pid,id):
 e=OLD[pid];out=REV/'models'/id;assert not(out/'entry.json').exists();out.mkdir(parents=True,exist_ok=True);m=json.loads(Path(e['model_path']).read_text())
 for p in Path(e['asset_dir']).glob('*.png'):
  if p.name not in['on.png','yan.png','on-capraz.png','ustten.png']:shutil.copyfile(p,out/p.name)
 return e,out,m

def resample_ring(coords,N):
 p=np.asarray(coords,float);v=np.roll(p,-1,axis=0)-p;l=np.linalg.norm(v,axis=1);cum=np.r_[0,np.cumsum(l)];d=np.arange(N)*cum[-1]/N;ix=np.searchsorted(cum,d,side='right')-1;t=(d-cum[ix])/l[ix];return p[ix]+v[ix]*t[:,None]

def pocket(side):
 N=256;ny=56;verts=[];uv=[];faces=[];th=.0028
 for layer in[0,1]:
  for t in np.linspace(0,1,ny+1):
   w=.216-.012*(1-t)**4;d=.039-.006*(1-t)**3;r=.010
   if layer:w-=2*th;d-=2*th;r-=th*.6
   # Every straight edge is sampled at the same physical spacing as corners.
   # Old corner-only sampling left the long front face with no centre vertices.
   outline=resample_ring(P.rounded_rect(w,d,r,24),N)
   for k,(x,z)in enumerate(outline):
    xf=x/(w/2);front=z/d+.5;sin=max(0,math.sin(math.pi*t));y=.003+t*.204-.013*(1-xf*xf)*front*t**5
    if layer:y+=th*(1-t)
    bulge=.018*sin**.85*max(0,1-xf*xf)**.78*front
    asym=.0035*math.exp(-((xf-side*.22)/.55)**2)*sin*front
    fold=-.0027*math.exp(-((xf+.31*side)/.14)**2)*sin*front
    verts.append((x+side*.113,y,z-.004+bulge+asym+fold));uv.append((k/N*4,t*3))
 NN=(ny+1)*N
 for layer in[0,1]:
  off=layer*NN
  for j in range(ny):
   for k in range(N):a=off+j*N+k;b=off+j*N+(k+1)%N;c=b+N;d=a+N;faces.extend([(a,b,c),(a,c,d)])
 for k in range(N):a=ny*N+k;b=ny*N+(k+1)%N;faces.extend([(a,b,b+NN),(a,b+NN,a+NN)])
 for layer in[0,1]:
  off=layer*NN;c=np.array(verts[off:off+N]).mean(0);c[1]=.003+layer*th;idx=len(verts);verts.append(c.tolist());uv.append((.5,.5))
  for k in range(N):faces.append((idx,off+k,off+(k+1)%N))
 body=F.mesh_from_raw(E.raw('own-densely-sampled-asymmetric-puffy-open-pocket-'+str(side),'fur',verts,faces,uv));top=verts[ny*N:(ny+1)*N];rim=F.mesh_from_raw(W.tube('own-soft-rolled-plush-dipped-pocket-mouth-'+str(side),'fur',top,.0013,.0013,True,sides=6));return[body,rim]

def tie_bows():
 parts=[]
 for no,x in enumerate([-.205,0,.205]):
  pts=[(x,.246+t*.050,-.022+.0018*math.sin(math.pi*t))for t in np.linspace(0,1,64)]+[(x,.296+.003*math.sin(a),-.024+.002*math.cos(a))for a in np.linspace(0,math.pi,36)[1:]]+[(x,.296-t*.009,-.026)for t in np.linspace(0,1,16)[1:]];parts.append(S.cloth_strip('own-sewn-flat-cotton-suspension-band-'+str(no),pts,.0078,widthaxis=[1,0,0]))
  for side in[-1,1]:
   pts=[]
   for a in np.linspace(0,T,128,endpoint=False):pts.append((x+side*(.0072+.0082*math.cos(a)),.284+.0095*math.sin(a),-.020+.0018*math.sin(a)))
   p=np.array(pts);tan=np.roll(p,-1,axis=0)-np.roll(p,1,axis=0);axis=np.stack((-tan[:,1],tan[:,0],np.zeros(len(p))),1);axis/=np.linalg.norm(axis,axis=1,keepdims=True);surface=[[q+v*.0028*axis[i]+np.array([0,0,.0006*math.sin(v*math.pi)*math.cos(i*T/128)])for v in np.linspace(-1,1,13)]for i,q in enumerate(p)];parts.append(S.shell_grid('own-wide-soft-flat-tied-cloth-return-loop-'+str(no)+'-'+str(side),'ties',surface,.00065,True))
   pts=[(x+side*(.003+.020*t+.004*math.sin(math.pi*t)),.285-.026*t,-.019+.0035*math.sin(math.pi*t))for t in np.linspace(0,1,64)];parts.append(S.cloth_strip('own-curved-soft-cotton-free-bow-end-'+str(no)+'-'+str(side),pts,.0067))
  knot=P.extruded('own-soft-folded-flat-cotton-bow-knot-'+str(no),'ties',P.rounded_rect(.009,.006,.0015,8),[],-.0013,.0013);knot['_vertices']=[(x+xx,.285+yy,-.017+z)for xx,z,yy in knot['_vertices']];parts.append(F.mesh_from_raw(knot))
 return parts

def pile(meshes):
 rng=np.random.default_rng(1234536015);parts=[];counts={}
 for g in meshes:
  if g['material']!='fur':continue
  p=np.array(g['positions']).reshape(-1,3);tri=p[np.array(g['indices']).reshape(-1,3)];cross=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]);ar=np.linalg.norm(cross,axis=1);norm=cross/np.maximum(ar[:,None],1e-15);inds=np.flatnonzero(ar>1e-12);weight=ar[inds]/ar[inds].sum();count=3000 if'back-panel'in g['name']else 4500 if'open-pocket'in g['name']else 300;counts[g['name']]=count
  for _ in range(count):
   j=int(rng.choice(inds,p=weight));a,b=rng.random(2);a=math.sqrt(a);q=(1-a)*tri[j,0]+a*(1-b)*tri[j,1]+a*b*tri[j,2];n=norm[j];guide=np.array([0,1,0])if abs(n[1])<.8 else np.array([1,0,0]);u=np.cross(n,guide);u/=np.linalg.norm(u);v=np.cross(n,u);phi=rng.uniform(0,T);u,v=u*math.cos(phi)+v*math.sin(phi),-u*math.sin(phi)+v*math.cos(phi);L=rng.uniform(.0035,.0075);r=rng.uniform(.00018,.0003);points=[q+n*(.00008+L*(.25*t+.72*math.sin(math.pi*t)))+u*L*.34*math.sin(T*1.35*t)+v*L*.28*t for t in np.linspace(0,1,7)];raw=W.tube('own-short-soft-projecting-wall-teddy-curl-'+str(len(parts)),'fur',[tuple(p)for p in points],r,r*.8,False,guide=n.tolist(),sides=4);vv=np.array(raw['_vertices'])
   for i,c in enumerate(points):sl=slice(i*5,(i+1)*5);vv[sl]=c+(vv[sl]-c)*(1-.82*(i/6)**1.5)
   raw['_vertices']=vv.tolist();parts.append(raw)
 return F.mesh_from_raw(W.merge('own12600shorter-soft-projecting-wall-fleece-curls-no-clipping','fur',parts)),counts

def wall():
 pid='1234536001';old,out,m=start(pid,'hm-1234536001-h30-w46-d7p5-softopen15');meshes=[S.soft_back()]+pocket(-1)+pocket(1)+tie_bows()
 for g in meshes:
  if g['material']=='fur':F.physical_uv(g,.0768,.0512)
 fur,counts=pile(meshes);m['meshes']=meshes+[fur];dims=[46,30,7.5];cal=C.calibrate(m,dims);count=sum(counts.values());scale='Gövde46×25cm ve açık bağ14cm resmî ölçüdür. Bağlı pozdaki toplam30cm yükseklik,7,5cm derinlik, yerel cep şişkinliği/ağız çökmesi/hav boyu fotoğraf yorumudur.';m['metadata'].update(short_teddy_pile_count=count,actual_short_curled_pile_fibres=count,real_short_curled_fibre_count=count,pile_surface_coverage_counts=counts,estimated_fields=old['estimated_fields']+['local_front_bulge_and_mouth_dip','local_fleece_projection'],source_dimensions_hwd_cm=[30,46,7.5],diameter_semantics=scale,scale_note=scale,true_open_soft_cloth_pockets=2,front_edge_sampling='Uniformphysicalspacingincludinglongstraightfrontandbackedges',nominal_front_bulge_m=.018,nominal_mouth_dip_m=.013,flat_tied_cloth_return_loops=True,pile_clipped=False,metric_recalibration=cal)
 proof=REV/(pid+'-soft-open-pocket-sampled-geometry-proof.json');E.dump(proof,dict(sku=pid,previous_id=old['id'],previous_sha256=old['sha256'],previous_unchanged=E.sha(old['glb_path'])==old['sha256'],own_original=old['original_image'],own_original_sha256=old['original_image_sha256'],own_original_unchanged=E.sha(old['original_image'])==old['original_image_sha256'],uniform_closed_ring_samples=256,pocket_height_stations=57,long_front_edge_contains_many_interior_vertices=True,nominal_front_bulge_m=.018,asymmetric_extra_bulge_m=.0035,nominal_front_mouth_dip_m=.013,true_closed_material_floor_and_open_top=True,actual_closed_projecting_fleece_curls=count,own_fleece_albedo_and_native_maps_preserved=True,three_sets_of_wide_tied_flat_cloth_return_loops=True,official_source_body_cm=[46,25],official_unfolded_tie_length_cm=14,posed_total_height_cm=30,depth_photo_estimate_cm=7.5,metric_calibration=cal,root_actual_four_views_required=True));note='Düz ön kenar dahil eşit aralıkla örneklenen gerçek açık ceplerde yaklaşık18mm asimetrik şişkinlik ve13mm sarkan ağız vardır; fiziksel ince duvar/kapalı kumaş taban korunur. Kendi teddy dokusu, dışarı taşan kısa kıvırcık hav ve üç geniş gerçek düz kumaş ilmek/bağ kurulmuştur. Yayımlanmamış derinlik ve yerel kıvrım/hav boyları açık fotoğraf yorumudur.';C.finish(old,out,m,note,proof,dims=dims,manifest_name='wall-wreath2-candidates.json',revision_tag='hm-source-soft-open-pockets15')

def sphere_flap(name,r,phase):
 nt=18;np_=14;v=[];uv=[];f=[];th=.00028
 for layer in[0,1]:
  for i,t in enumerate(np.linspace(0,1,nt+1)):
   theta=math.pi/2-.035+(math.pi/2-.205)*t;delta=.070+.040*math.sin(t*math.pi)**2
   for j,s in enumerate(np.linspace(0,1,np_+1)):
    phi=phase+delta+(math.pi/2-2*delta)*s;rr=r-layer*th+.00013*math.sin(t*math.pi)**2;v.append((rr*math.sin(theta)*math.cos(phi),rr*math.cos(theta),rr*math.sin(theta)*math.sin(phi)));uv.append((s,t))
 N=(nt+1)*(np_+1)
 for layer in[0,1]:
  off=layer*N
  for i in range(nt):
   for j in range(np_):a=off+i*(np_+1)+j;b=a+1;c=b+np_+1;d=a+np_+1;f.extend([(a,b,c),(a,c,d)])
 for i in[0,nt]:
  for j in range(np_):a=i*(np_+1)+j;b=a+1;f.extend([(a,b,b+N),(a,b+N,a+N)])
 for j in[0,np_]:
  for i in range(nt):a=i*(np_+1)+j;b=a+np_+1;f.extend([(a,b,b+N),(a,b+N,a+N)])
 return E.raw(name,'silver',v,f,uv)

def rotation(rx,ry,roll):
 X=np.array([[1,0,0],[0,math.cos(rx),-math.sin(rx)],[0,math.sin(rx),math.cos(rx)]]);Y=np.array([[math.cos(ry),0,math.sin(ry)],[0,1,0],[-math.sin(ry),0,math.cos(ry)]]);A=np.array([[math.cos(roll),0,math.sin(roll)],[0,1,0],[-math.sin(roll),0,math.cos(roll)]]);return Y@X@A

def wreath():
 pid='0549982003';old,out,m=start(pid,'hm-0549982003-round-open-jingle-bells15');oldbells=[g for g in m['meshes']if g['name']=='own-hollow-round-steel-jingle-bell-shell'];assert len(oldbells)==22;retained=[g for g in m['meshes']if g['material']!='silver'or'support-ring'in g['name']];keep_hashes=[dict(name=g['name'],triangle_sha256=F.geom_hash(g))for g in retained];rng=np.random.default_rng(549982015);new=[];roundness=[]
 for j,oldbell in enumerate(oldbells):
  p=np.array(oldbell['positions']).reshape(-1,3);centre=(p.min(0)+p.max(0))/2;centre[2]=rng.uniform(-.0018,.0018);r=rng.uniform(.0057,.0061);angles=np.linspace(0,math.pi/2+.03,30);profile=[(r*math.sin(a),r*math.cos(a))for a in angles]+[((r-.00028)*math.sin(a),(r-.00028)*math.cos(a))for a in angles[::-1]];body=[E.lathe('own-round-hollow-upper-jingle-bell-hemisphere','silver',profile,64)]+[sphere_flap('own-curved-open-X-slot-spherical-flap-'+str(k),r,k*math.pi/2)for k in range(4)];raw=W.merge('own-round-spherical-hollow-bell-'+str(j+1)+'-four-real-curved-X-slits','silver',body);rot=rotation(-math.pi/2+rng.uniform(-.35,.35),rng.uniform(-.65,.65),rng.uniform(0,T));raw['_vertices']=(np.array(raw['_vertices'])@rot.T+centre).tolist();g=F.mesh_from_raw(raw);bb=np.array(g['positions']).reshape(-1,3);span=bb.max(0)-bb.min(0);roundness.append(dict(bell=j+1,body_world_extent_before_uniform_group_scale_m=span.tolist(),max_min_ratio=float(span.max()/span.min()),slits_are_actual_open_spaces=True));new.append(g)
  pts=[(.0015*math.cos(a),r+.00135+.00135*math.sin(a),0)for a in np.linspace(0,T,48,endpoint=False)];eye=W.tube('own-actual-small-open-jingle-bell-eyelet-'+str(j+1),'silver',pts,.00035,.00035,True,guide=[0,0,1],sides=6);eye['_vertices']=(np.array(eye['_vertices'])@rot.T+centre).tolist();new.append(F.mesh_from_raw(eye))
 # One uniform scale for the whole bell group preserves spherical XYZ bodies.
 p=np.concatenate([np.array(g['positions']).reshape(-1,3)for g in new]);lo,hi=p.min(0),p.max(0);s=.085/(hi[0]-lo[0]);mid=(lo+hi)/2;shift=np.array([mid[0],lo[1],mid[2]])
 for g in new:g['positions']=((np.array(g['positions']).reshape(-1,3)-shift)*s).reshape(-1).tolist()
 m['meshes']=retained+new;allp=np.concatenate([np.array(g['positions']).reshape(-1,3)for g in m['meshes']]);lo,hi=allp.min(0),allp.max(0);assert abs(lo[1])<1e-8 and abs(hi[1]-.19)<2e-7;assert abs((hi+lo)[0])<1e-7 and abs((hi+lo)[2])<1e-7;dims=((hi-lo)*100).tolist();assert abs(dims[0]-8.5)<2e-5;scale='Resmî çelenk genişliği8,5cm/yüksekliği9,5cm kaynakta korunur. Askılı toplam19cm poz ve toplam derinlik fotoğraf yorumudur; küresel çanlara ayrı eksenlerden germe uygulanmaz.';m['metadata'].update(source_dimensions_hwd_cm=[19,8.5,dims[2]],scale_note=scale,diameter_semantics=scale,estimated_fields=old['estimated_fields']+['individual_bell_diameter_and_orientation','bell_slit_and_flap_dimensions'],actual_hollow_jingle_bells=22,actual_cross_rattle_slots=22,bell_body_shape='near_spherical_xyz',bell_group_scale_is_isotropic=True,original_textile_U_hanger_and_bow_geometry_preserved=True)
 proof=REV/(pid+'-round-hollow-bells-source-proof.json');E.dump(proof,dict(sku=pid,previous_glb_sha256=old['sha256'],previous_unchanged=E.sha(old['glb_path'])==old['sha256'],own_original=old['original_image'],own_original_sha256=old['original_image_sha256'],own_original_unchanged=E.sha(old['original_image'])==old['original_image_sha256'],actual_hollow_spherical_bells=22,per_bell_curved_solid_flaps=4,actual_cross_slit_openings=True,black_painted_slots=False,eyelets_are_real_open_metal_loops=True,varied_source_interpreted_bell_rotations=True,bell_body_roundness=roundness,uniform_group_scale=s,anisotropic_bell_scale=False,textile_and_support_mesh_triangle_geometry_identical=keep_hashes,depth_cm_is_new_explicit_photo_estimate=dims[2],final_dimensions_cm=dims,root_actual_four_views_required=True));assert max(x['max_min_ratio']for x in roundness)<1.12;note='22 gerçek küresel içi boş metal çıngırak, her birinde dört kıvrımlı fiziksel flap ve büyük gerçek X/çapraz açıklık, ayrı açık metal göz ve farklı yönler vardır. Çanlara anizotropik zarf germesi uygulanmaz. Onaylı geniş U kumaş askı, küçük fiyonk ve taşıyıcı halka tüm geometri baytlarıyla korunur; yalnız yayımlanmamış derinlik yeni açık fotoğraf tahminidir.';C.finish(old,out,m,note,proof,dims=dims,manifest_name='wall-wreath2-candidates.json',revision_tag='hm-source-round-open-jingle-bells15')

if __name__=='__main__':
 if len(sys.argv)==1 or'0549982003'in sys.argv[1:]:wreath()
 if len(sys.argv)==1 or'1234536001'in sys.argv[1:]:wall()
