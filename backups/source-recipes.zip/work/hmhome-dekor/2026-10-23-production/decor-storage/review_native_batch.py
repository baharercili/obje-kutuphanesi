"""Independent QA and native four-angle rendering, no geometry simplification."""
import sys,json,hashlib,subprocess,importlib.util
from pathlib import Path
R=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,d):Path(p).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
prepare_only='--prepare-only'in sys.argv;selected=[s for s in sys.argv[1:]if s!='--prepare-only'];entries=[e for e in json.loads((R/'manifest.json').read_text())if e['id']in selected or e['sku']in selected];assert entries
sp=importlib.util.spec_from_file_location('own_independent_review',R/'validate_independent.py');Q=importlib.util.module_from_spec(sp);sp.loader.exec_module(Q);checks=[Q.check(e)for e in entries];dump(R/('review-'+selected[0]+'-independent.json'),dict(valid=True,checks=checks))
N=R/'native-review-inputs';N.mkdir(exist_ok=True);proof=json.loads((N/'identity-proof.json').read_text())if(N/'identity-proof.json').exists()else[]
for e in entries:
 original=json.loads(Path(e['model_path']).read_text());native=dict(materials=original['materials'],meshes=[{k:v for k,v in mesh.items()if k!='tangents'}for mesh in original['meshes']]);input=N/(e['id']+'.json');input.write_text(json.dumps(native,separators=(',',':')));assert native['materials']==original['materials'];assert all(all(mesh[k]==old[k]for k in mesh)for mesh,old in zip(native['meshes'],original['meshes']));review=dict(e,model_path=str(input));manifest=N/(e['id']+'-entry.json');dump(manifest,[review]);proof=[p for p in proof if p['id']!=e['id']]+[dict(id=e['id'],canonical_model_path=e['model_path'],native_input_path=str(input),canonical_sha256=sha(e['model_path']),native_sha256=sha(input),positions_normals_uvs_materials_indices_identical=True,omitted_fields=['metadata','tangents (not read by native renderer)'],no_geometry_or_texture_decimation=True)];dump(N/'identity-proof.json',proof)
 if prepare_only:continue
 result=subprocess.run([str(R.parents[1]/'2026-10-21/decor-accessories-a/render-hm'),str(manifest),'1000'],capture_output=True,text=True)
 if result.returncode==-9:result=subprocess.run([str(R.parents[1]/'2026-10-21/decor-accessories-a/render-hm'),str(manifest),'600'],capture_output=True,text=True)
 print(e['id'],result.returncode,result.stdout[-400:],result.stderr[-400:],flush=True);assert result.returncode==0
