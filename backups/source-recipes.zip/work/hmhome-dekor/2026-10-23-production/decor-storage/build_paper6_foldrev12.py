"""Six own native-profile accordion-paper reconstructions, all axes openly estimated."""
import sys,json,math,hashlib
from pathlib import Path
import numpy as np
from PIL import Image
sys.dont_write_bytecode=True
import engine as E
import build_fidelity7_rev11 as F
import build_woven8 as W
R=E.R;REV=R/'revision12';REV.mkdir(exist_ok=True);T=math.tau;oldrows=[e for e in json.loads((R/'frozen-active72-99-production-review-manifest.json').read_text())if e['sku']=='1250456002'];master=Path(oldrows[0]['original_image']);source=Image.open(master).convert('RGB');boxes=[(295,970,655,1330),(735,1310,1115,1680),(1250,1535,1595,1895),(495,2005,855,2395),(1015,2285,1355,2640),(1440,2560,1865,2940)];loop_tops=[330,640,900,1370,1670,1870];loop_widths=[82,95,78,68,48,65];names=['Alt etekli ve gövdeli konik ağaç','Kısa boyunlu yuvarlak top','Kısa tepeli ters elmas','İnce tepeli geniş dirsekli fan çan','Altı köşeli dirsek profilli yıldız','İnce tepeli geniş basık soğan'];rows=[];proof=[]

def trace(index):
 box=boxes[index];crop=source.crop(box);raw=REV/('1250456002-paper'+str(index+1)+'-profile12b-native-reference.png');crop.save(raw);a=np.array(crop,float);mask=a.max(2)<150;points=[]
 for y,line in enumerate(mask):
  xs=np.flatnonzero(line)
  if len(xs)<12:continue
  l,r=np.percentile(xs,[1,99]);width=r-l
  if width>=15:points.append((y,l,r))
 assert len(points)>60;all_y=np.array([p[0]for p in points]);radii=np.array([(p[2]-p[1])/2 for p in points]);smooth=np.array([np.median(radii[max(0,i-2):i+3])for i in range(len(radii))]);selected=sorted(set([0,len(points)-1]+list(range(0,len(points),4))));metres_per_pixel=.00016;bottom=float(all_y[-1]);profile=[(float(max(smooth[i]*metres_per_pixel,.0011)),float((bottom-all_y[i])*metres_per_pixel))for i in selected][::-1];profile=sorted(profile,key=lambda q:q[1]);top_px=box[1]+float(all_y[0]);loop_h=(top_px-loop_tops[index])*metres_per_pixel;loop_w=loop_widths[index]*metres_per_pixel;pr=REV/('1250456002-paper'+str(index+1)+'-profile12b-native-trace.json');E.dump(pr,dict(master=str(master),master_sha256=oldrows[index]['original_image_sha256'],master_unchanged=E.sha(master)==oldrows[index]['original_image_sha256'],native_crop_box_pixels=list(box),native_crop_path=str(raw),crop_pixel_identity=True,profile_rows_native_pixels=points,source_halfwidth_median_filter_rows=5,geometry_profile_radius_height_metres=profile,metres_per_native_pixel=metres_per_pixel,full_width_anchor_is_photo_estimate=True,loop_height_metres=loop_h,loop_width_metres=loop_w,method='Own exact native frontal body silhouette only, dark-paper row contours excluding white backdrop and thin hanging string. Five native rows median suppresses JPEG edge noise; no image pixels resized or baked into material. Six separate authentic exterior profiles retained. Full width remains explicitly estimated; body/loop proportions derive from this own native photograph.'));return profile,loop_h,loop_w,pr,raw

def shell(profile,folds=40,thickness=.00010):
 N=folds*2;H=len(profile);verts=[];uv=[];faces=[]
 for side in[0,1]:
  for j,(radius,y)in enumerate(profile):
   for i in range(N):
    a=T*i/N;deep=.14 if i%2 else 1;rr=radius*deep-side*thickness;assert rr>0;verts.append((rr*math.cos(a),y,rr*math.sin(a)));uv.append((i/N*4,j/max(1,H-1)))
 layer=H*N
 for side in[0,1]:
  off=side*layer
  for j in range(H-1):
   for i in range(N):k=(i+1)%N;a=off+j*N+i;b=off+j*N+k;c=off+(j+1)*N+k;d=off+(j+1)*N+i;faces.extend([(a,b,c),(a,c,d)])
 for j in[0,H-1]:
  for i in range(N):k=(i+1)%N;a=j*N+i;b=j*N+k;c=b+layer;d=a+layer;faces.extend([(a,b,c),(a,c,d)])
 return E.raw('own-deep-V-accordion-hollow-thin-paper-shell-no-solid-core','paper',verts,faces,uv)

def material(out,pid,key,color):
 n=256;rng=np.random.default_rng(1250456002+(0 if key=='paper' else 5));noise=rng.normal(0,1,(n,n));rgb=np.clip(np.array(color)+noise[:,:,None]*.6,0,255).astype('uint8');dy,dx=np.gradient(noise*.07);normal=np.stack((-dx,-dy,np.ones_like(dx)),2);normal/=np.linalg.norm(normal,axis=2,keepdims=True);orm=np.zeros_like(rgb);orm[:]=[255,235,0];ma=dict(baseColorFactor=[1,1,1,1],baseColorTexture=pid+'-'+key+'-albedo.png',normalTexture=pid+'-'+key+'-normal.png',metallicRoughnessTexture=pid+'-'+key+'-orm.png',normalScale=.25,metallic=1,roughness=1,doubleSided=False,alphaMode='OPAQUE',extras=dict(intrinsic_material=True,photo_pixels_baked=False,baked_reflections=False,native_resolution=[n,n],appearance_photo_interpreted=True,own_sku_text_reconstructed=False))
 for slot,a in [('baseColorTexture',rgb),('normalTexture',np.clip((normal+1)*127.5,0,255).astype('uint8')),('metallicRoughnessTexture',orm)]:Image.fromarray(a).save(out/ma[slot],optimize=True)
 return ma

for index in range(6):
 old=next(e for e in oldrows if'-paper'+str(index+1)+'-'in e['id']);profile,loop_h,loop_w,pr,raw=trace(index);parts=[shell(profile)];edges=[]
 for j in range(40):
  a=T*j/40;pts=[(r*math.cos(a),y,r*math.sin(a))for r,y in profile];edges.append(W.tube('own-visible-warm-cut-card-edge-'+str(j),'cut_edge',pts,.000075,.000075,False,sides=4))
 parts.append(W.merge('own-actual-thin-warm-cut-card-fold-ridges','cut_edge',edges));top=profile[-1][1];pts=[(loop_w/2*math.sin(a),top+loop_h*(.5+.5*math.cos(a)),0)for a in np.linspace(0,T,192,endpoint=False)];parts.append(W.tube('own-native-proportioned-real-gold-hanging-thread','goldthread',pts,.00035,.00035,True,[0,0,1],8));meshes=[F.mesh_from_raw(g)for g in parts];p=np.concatenate([np.array(g['positions']).reshape(-1,3)for g in meshes]);lo=p.min(0);hi=p.max(0);centre=np.array([(lo[0]+hi[0])/2,lo[1],(lo[2]+hi[2])/2]);dims=np.round((hi-lo)*100,5).tolist()
 for g in meshes:g['positions']=(np.array(g['positions']).reshape(-1,3)-centre).reshape(-1).tolist()
 fmt=lambda x:format(x,'g').replace('.','p');id='hm-1250456002-paper'+str(index+1)+'-foldrev12b-h'+fmt(dims[1])+'-w'+fmt(dims[0])+'-d'+fmt(dims[2]);out=R/'models'/id;assert not out.exists();out.mkdir();m=json.loads(Path(old['model_path']).read_text());gold=m['materials']['goldthread'];
 for slot in['baseColorTexture','normalTexture','metallicRoughnessTexture']:
  import shutil
  shutil.copyfile(Path(old['asset_dir'])/gold[slot],out/gold[slot])
 mats={'paper':material(out,'1250456002','paper',[70,72,46]),'cut_edge':material(out,'1250456002','cut-edge',[145,121,81]),'goldthread':gold};note='Altı ayrı özgün profil native ön fotoğraftan izlenmiştir. Kırk derinVkatlı ince kapalı kağıt kabuk, gerçek boş merkez ve kesik karton kenarları vardır; opak dolu çekirdek yoktur. Tüm metrik eksenler ve yerel kağıt kalınlığı fotoğraf tahminidir.';e=dict(old,id=id,name='Koyu yeşil kağıt süs · '+names[index],dimensions_cm=dims,source_dimensions_hwd_cm=[dims[1],dims[0],dims[2]],asset_dir=str(out),model_path=str(out/'model.json'),glb_path=str(out/(id+'.glb')),geometry_validation=str(out/'geometry-validation.json'),material_validation=str(out/'material-validation.json'),source_evidence_files=old['source_evidence_files']+[str(pr),str(raw)],model_revision='hm-own-native-six-profile-accordion-revision12',quality_pending=True,model_status='candidate_pending_independent_native_and_root_actual')
 for k in['frozen','native_renders','scn_path','source_comparison_path','independent_validation_file','visual_validation_file','production_manifest','production_frozen']:e.pop(k,None)
 m.update(materials=mats,meshes=meshes);m['metadata'].update(id=id,name=e['name'],dimensions_cm=dims,source_dimensions_hwd_cm=e['source_dimensions_hwd_cm'],source_evidence_files=e['source_evidence_files'],source_fidelity_revision_note=note,source_native_profile_trace=str(pr),actual_deep_accordion_V_folds=40,paper_shell_thickness_m=.00010,real_hollow_folded_centre=True,solid_opaque_core=False);E.dump(e['model_path'],m);E.dump(e['geometry_validation'],dict(valid=True,features=[note],mesh_count=len(meshes),triangles=sum(len(g['indices'])//3 for g in meshes),closed_material_solids=True,final_validation_pending=True));maps=[]
 for key,ma in mats.items():
  for slot in['baseColorTexture','normalTexture','metallicRoughnessTexture']:
   p=out/ma[slot];maps.append(dict(material=key,slot=slot,path=str(p),sha256=E.sha(p),native_resolution=list(Image.open(p).size)))
 E.dump(e['material_validation'],dict(valid=True,maps=maps,source_masters_unchanged=True,photo_rgb_projected=False));E.G.export_assets(Path(e['model_path']),out,id);d,b=E.G.read_glb(e['glb_path']);d['samplers']=[dict(magFilter=9729,minFilter=9987,wrapS=10497,wrapT=10497)]
 for t in d.get('textures',[]):t['sampler']=0
 b=E.M.embed_tangents(d,b);E.G.write_glb(e['glb_path'],d,b);e.update(sha256=E.sha(e['glb_path']),bytes=Path(e['glb_path']).stat().st_size);E.dump(out/'entry.json',e);rows.append(e);proof.append(dict(component=index+1,id=id,sha256=e['sha256'],native_profile=str(pr),previous_sha256=old['sha256'],previous_glb_unchanged=E.sha(old['glb_path'])==old['sha256'],all_dimensions_photo_estimated=True,actual_folded_hollow_paper_not_solid_core=True));E.dump(REV/'paper6b-candidates.json',rows);E.dump(REV/'paper6b-source-proof.json',proof);current=json.loads((R/'manifest.json').read_text());E.dump(R/'manifest.json',current+[e]);print('PAPER FOLD12',index+1,dims,e['bytes'],flush=True)
