"""Twelve exact source-specific hard decor identities; no generic replacement assets."""
from pathlib import Path
import sys,math,json,hashlib
sys.dont_write_bytecode=True
sys.path.insert(0,str(Path(__file__).resolve().parent/'python-deps'))
import mapbox_earcut as earcut
import numpy as np
from PIL import Image,ImageFilter
import engine as E
R=E.R;B=E.B;T=math.tau

def shift(g,x=0,y=0,z=0):g['_vertices']=[(a+x,b+y,c+z)for a,b,c in g['_vertices']];return g

def sphere(name,mat,r,cy=0,cx=0,cz=0):return shift(E.lathe(name,mat,[((0 if i in[0,48]else r*math.sin(b)),cy+r*math.cos(b))for i,b in enumerate(np.linspace(0,math.pi,49))],96),x=cx,z=cz)
def circle(r,n=96,cx=0,cz=0):return[(cx+r*math.cos(a),cz+r*math.sin(a))for a in np.linspace(0,T,n,endpoint=False)]
def rounded_rect(w,d,r,n=20):
 p=[]
 for cx,cz,start in[(w/2-r,d/2-r,0),(-w/2+r,d/2-r,math.pi/2),(-w/2+r,-d/2+r,math.pi),(w/2-r,-d/2+r,math.pi*1.5)]:
  p.extend((cx+r*math.cos(a),cz+r*math.sin(a))for a in np.linspace(start,start+math.pi/2,n,endpoint=False))
 return p

def extruded(name,mat,outer,holes,y0,y1):
 rings=[outer]+holes;points=np.array([p for ring in rings for p in ring],dtype=np.float64);ends=np.cumsum([len(ring)for ring in rings]).astype(np.uint32);tri=earcut.triangulate_float64(points,ends).reshape(-1,3);N=len(points);verts=[(x,y,z)for y in[y0,y1]for x,z in points];uv=[(x,z)for y in[y0,y1]for x,z in points];faces=[tuple(map(int,f))for f in tri]+[tuple(int(x)+N for x in f[::-1])for f in tri];start=0
 for ring in rings:
  for i in range(len(ring)):a=start+i;b=start+(i+1)%len(ring);faces.extend([(a,b,a+N),(b,b+N,a+N)])
  start+=len(ring)
 return E.raw(name,mat,verts,faces,uv)

def ikebana(big=False):
 br=.060 if big else .025;top=.102 if big else .050;h=.100 if big else .071;floor=.006 if big else .005;neckh=h*.67;th=.0022 if big else .0018
 pr=[(0,0),(br*.88,0),(br*.98,.001),(br,.004),(br,neckh-.003)]+[(br+(top-br)*float(t),neckh+(h-.002-neckh)*(1-(1-float(t))**3))for t in np.linspace(0,1,22)]+[(top-.0002,h-.0004),(top-.0007,h),(top-.0015,h-.0004)]+[(br-th+(top-br)*float(t),neckh+(h-.002-neckh)*(1-(1-float(t))**3)-.0015)for t in np.linspace(1,0,22)]+[(br-th,floor),(0,floor)]
 parts=[E.lathe('own-flared-ikebana-glass-full-cylindrical-cavity-heavy-base-and-wide-real-open-rim','glass',pr,384)];r=br*.88;yp=floor+.001;yq=neckh-.006;holes=[]
 if big:
  sizes=[[.0048,.0034,.0030,.0037,.0048],[.0036,.0038,.0054,.0037,.0035],[.0030,.0054,.0053,.0048,.0028],[.0045,.0046,.0051,.0034,.0039],[.0053,.0038,.0028,.0036,.0050]]
  for row in range(5):
   for col in range(5):holes.append(circle(sizes[row][col],40,(col-2)*r*.29,(row-2)*r*.29))
 else:
  holes=[circle(r*.18,56)]+[circle(r*(.13 if j%2==0 else .085),40,r*.53*math.cos(T*j/8),r*.53*math.sin(T*j/8))for j in range(8)]
 for j,y in enumerate([yp,yq]):parts.append(extruded('actual-precision-perforated-stainless-insert-plate-'+str(j+1),'steel',circle(r,192),holes,y,y+.0007))
 for i in range(3):
  a=T*i/3+.3;parts.append(B.cylinder('actual-insert-support-rod-'+str(i+1),'steel',.0013,yp+.0007,yq,offset=(r*.87*math.cos(a),0,r*.87*math.sin(a)),n=32))
 return parts,['Own official flared glass silhouette, exact lower and upper diameter anchors, full open interior and real thick glass base','Two independently solid stainless plates, each with'+str(len(holes))+'genuinely open circular holes, and three physical connecting rods','Hole count/layout verified from exact own-SKUcloseup; unpublished individual hole diameters, plate heights and wall thickness are photo-interpreted'],dict(insert_holes_per_plate=len(holes),insert_plate_count=2,insert_rod_count=3,source_flowers_excluded=True)

def lantern(style):
 if style=='rattan':
  r=.052;total=.18;y0=.020;pr=[(r-.0018,y0),(r,y0),(r,.179),(r-.0002,.180),(r-.0013,.180),(r-.0018,.179)];parts=[E.lathe('own-open-ended-cylindrical-glass-hurricane-with-real-thin-rounded-rim','glass',pr,384)];base=E.lathe('closed-rattan-candle-support-disc-with-real-shallow-upper-recess','rattan',[(0,0),(.056,0),(.059,.002),(.059,.026),(.054,.030),(.052,.030),(.052,.022),(0,.022)],256);parts.append(base)
  for j in range(5):parts.append(E.lathe('own-real-horizontal-rattan-coil-'+str(j+1),'rattan',[(.058+.004*math.cos(a),.004+j*.0054+.0026*math.sin(a))for a in np.linspace(0,T,24,endpoint=False)],256))
 else:
  big=style=='large';r=.087 if big else .061;total=.271 if big else .186;outer=.1015 if big else .0755;z=.032 if big else .026;glass=E.lathe('own-independent-open-cylinder-glass-hurricane-with-actual-wall-and-rounded-rim','glass',[(r-.0018,z-.006),(r,z-.006),(r,total-.001),(r-.0004,total),(r-.0016,total),(r-.0018,total-.001)],384);dish=E.lathe('own-shallow-polished-steel-dish-and-rounded-rolled-wide-rim','gold',[(0,0),(outer*.61,0),(outer*.75,.004),(outer*.88,.013),(outer,.024),(outer,.026),(outer*.98,.027),(outer*.92,.024),(outer*.78,.012),(outer*.65,.008),(0,.008)],384);parts=[glass,dish]
 return parts,['Own glass hurricane and independently modeled supporting base with real open cylinder and visible wall thickness','Rattan version has five physical coiled bands and a closed recessed support; steel versions have the exact-source shallow rolled-rim dish','Source optional pillar candle omitted; official complete accessory height and maximum base diameter retained'],dict(source_display_candle_excluded=True,glass_open_ended=True)

def steel_bowl():
 parts=[E.lathe('own-subtly-conical-polished-steel-bowl-with-real-shallow-concave-well-and-thin-rolled-rim','steel',[(0,.015),(.018,.015),(.127,.046),(.130,.0475),(.130,.049),(.127,.049),(.017,.019),(0,.019)],384)]
 for j in range(3):a=T*j/3+math.pi/2;parts.append(sphere('actual-spherical-polished-steel-foot-'+str(j+1),'steel',.018,.018,.091*math.cos(a),.091*math.sin(a)))
 return parts,['Own conical shallow dish, rounded rolled edge and three actual spherical feet, rather than a generic pedestal bowl','Genuinely concave metal serving surface and independently closed steel solids','Official26cmdiameter and4.9cmcompleteheight; sphere diameter, radial positions and sheet thickness inferred from own closeup'],dict(spherical_foot_count=3)

def marble_holder():
 g=E.lathe('own-rounded-straight-marble-utensil-holder-with-full-deep-cavity-and-thick-closed-floor','marble',[(0,0),(.053,0),(.061,.001),(.064,.004),(.065,.008),(.065,.165),(.0645,.169),(.063,.170),(.055,.170),(.0545,.167),(.0545,.012),(.052,.009),(0,.009)],384);g['_uvs']=[(u*6,v*3)for u,v in g['_uvs']];return[g],['Exact ownSKUmarble cylinder with visibly rounded lower edge, real deep opening, rounded thick lip and full closed stone floor','Own-SKUnative marble crop becomes intrinsic shading-normalized material at its native pixel resolution; no photograph background or baked reflection','Official13cmouterdiameter and17cmheight retained'],dict(material_pattern_provenance=str(R/'1305498001-marble-provenance.json'))

def jewellery():
 base=E.lathe('own-round-marble-jewellery-tray-base-with-real-shallow-rim','marble',[(0,0),(.052,0),(.058,.001),(.060,.004),(.060,.024),(.059,.028),(.056,.029),(.052,.028),(.052,.019),(0,.019)],256);base['_uvs']=[(x/.12+.5,z/.12+.5)for x,y,z in base['_vertices']];stem=B.cylinder('slender-independent-stainless-jewellery-stem','steel',.0015,.018,.247,n=48);arc=B.tube('own-open-curved-horizontal-jewellery-hanging-bar','steel',[(.054*math.cos(a),.247,.021*math.sin(a))for a in np.linspace(math.pi/2+.55,math.pi/2+T-.55,220)],.002,.002,16,False,guide=[0,1,0]);return[base,stem,arc],['Own exact-source shallow marble tray base with real recess, thin vertical steel stem and an open curved horizontal hanging bar','Official25cmtotalheight and12cmbase diameter; local rim and bar geometry photo-interpreted','Own exactSKUstone pattern derived from native unmodified master crop without source background/reflections'],dict(material_pattern_provenance=str(R/'1311565003-marble-provenance.json'))

def soapdish():
 pr=[(0,0),(.70,0),(.84,.001),(.95,.005),(1,.020),(1,.023),(.98,.025),(.91,.024),(.87,.020),(.80,.009),(0,.008)];g=B.lathe('own-rounded-rectangular-stoneware-soap-dish-with-real-raised-rim-and-internal-well','ceramic',pr,384,False);verts=[]
 for x,y,z in g['_vertices']:
  rr=math.hypot(x,z);a=math.atan2(z,x);n=6;b=(abs(math.cos(a))**n+abs(math.sin(a))**n)**(-1/n);verts.append((x*b*.065,y,z*b*.0435))
 g['_vertices']=verts;bumps=[sphere('own-small-rounded-drainage-support-bump-'+str(i+1),'ceramic',.002,.009,x,0)for i,x in enumerate([-.040,-.020,0,.020,.040])];return[g]+bumps,['Own rounded rectangular stoneware dish, real shallow interior, thick rounded raised rim and five actual interior raised support bumps','Official13×8.7cmplan anchors;2.5cmheight and five local bump dimensions interpreted from own photographs'],dict(interior_support_bumps=5)

def green_block():
 outer=rounded_rect(.040,.040,.0017,24);floor=extruded('clear-heavy-glass-square-base-with-rounded-vertical-corners','glass',outer,[],0,.048);body=extruded('clear-square-glass-upper-body-with-real-open-round-candle-socket','glass',outer,[circle(.0142,96)],.048,.080);cup=E.lathe('distinct-olive-green-inner-glass-candle-socket-with-real-tapered-open-cavity','green',[(.0093,.048),(.0142,.048),(.0142,.080),(.0117,.080),(.0093,.050)],256);return[floor,body,cup],['Own4×4×8cmclear glass square block with a real open cylindrical socket, not a solid cube with a colored decal','Distinct olive-green glass interior cup within clear dense body; heavy closed lower glass base','Display taper candle excluded from the physical accessory'],dict(solid_dense_object=True,source_display_candle_excluded=True)

def twisted_sconce():
 verts=[];uv=[];faces=[];n=440;w=.057;h=.207;th=.0009
 for side in[-1,1]:
  for i in range(n+1):
   y=h*i/n;a=T*2.15*(i/n)+.4;rad=np.array([math.cos(a),0,math.sin(a)]);norm=np.array([-math.sin(a),0,math.cos(a)])
   for u in[-1,1]:p=u*w/2*rad+norm*(side*th/2)+np.array([0,y,0]);verts.append(tuple(p));uv.append(((u+1)/2,i/n))
 N=(n+1)*2
 for i in range(n):
  for off in[0,N]:a=off+i*2;b=a+1;c=a+2;d=a+3;faces.extend([(a,b,c),(b,d,c)])
  for u in[0,1]:a=i*2+u;b=a+2;faces.extend([(a,b,a+N),(b,b+N,a+N)])
 for i in[0,n]:a=i*2;faces.extend([(a,a+N,a+1),(a+1,a+N,a+N+1)])
 ribbon=E.raw('own-continuously-twisted-solid-stainless-ribbon-with-real-thickness-and-open-space-around-each-turn','metal',verts,faces,uv);tray=E.lathe('own-small-round-rolled-drip-tray-at-the-top','metal',[(0,.207),(.025,.207),(.0285,.209),(.0285,.210),(.026,.211),(.012,.211),(0,.211)],256);socket=E.lathe('actual-open-taper-candle-cup','metal',[(.0108,.210),(.0123,.210),(.0123,.222),(.0117,.223),(.0108,.223)],192);return[ribbon,tray,socket],['Own actual continuous broad twisted metal ribbon, closed thin solid edges and real open space between turns','Separate shallow top drip dish and genuinely open22mmcandle socket; optional display candle excluded','Official5.7cmwidth and22.3cmmetal-accessoryheight retained; unpublisheddepth interpreted from own twist gallery'],dict(source_display_candle_excluded=True)

BASE=E.material
def material(pid,key,**args):
 if key!='marble':return BASE(pid,key,**args)
 out,ma=BASE(pid,key,color=[220,207,181],rough=.27);master=(next(m for m in E.MASTERS if m['sku']==pid and m['path'].endswith('4bde84b1ae55.jpg'))if pid=='1311565003'else max((m for m in E.MASTERS if m['sku']==pid),key=lambda m:Image.open(m['path']).width));im=Image.open(master['path']).convert('RGB');unit=im.width/1536;canonical=(630,950,920,1370)if pid=='1305498001'else(450,1050,1050,1400);box=tuple(round(v*unit)for v in canonical);crop=im.crop(box);crop.save(R/(pid+'-native-marble-crop.png'));a=np.asarray(crop).astype(float);blur=np.asarray(crop.filter(ImageFilter.GaussianBlur(35))).astype(float);palette=np.median(a.reshape(-1,3),axis=0);intrinsic=np.clip(palette+(a-blur)*1.4,0,255).astype('uint8');Image.fromarray(intrinsic,'RGB').save(out/ma['baseColorTexture'],optimize=True);gray=intrinsic.mean(2)/255;dy,dx=np.gradient(gray*.10);norm=np.stack([-dx,-dy,np.ones_like(dx)],2);norm/=np.linalg.norm(norm,axis=2,keepdims=True);orm=np.zeros_like(intrinsic);orm[:,:,0]=255;orm[:,:,1]=78;Image.fromarray(np.clip((norm+1)*127.5,0,255).astype('uint8'),'RGB').save(out/ma['normalTexture'],optimize=True);Image.fromarray(orm,'RGB').save(out/ma['metallicRoughnessTexture'],optimize=True);ma['extras'].update(own_photo_material_crop=True,source_effective_detail_pixels=list(crop.size),native_resolution=list(crop.size),intrinsic_illumination_removed=True);E.dump(R/(pid+'-marble-provenance.json'),dict(master=master['path'],master_sha256=master['sha256'],master_unchanged=E.sha(master['path'])==master['sha256'],native_crop_box_pixels=box,crop_pixel_identity=True,material_native_pixels=list(crop.size),upscaled=False,method='Own native marble-only crop. Low-frequency photographic illumination removed by subtracting35pxGaussianfield, retaining own fine material variation with median intrinsic palette. No edges, object silhouette, background or reflection baked.'))
 return out,ma
E.material=material
clear=dict(color=[255,255,255],rough=.035,trans=.985,atten=[.99,.99,.99],dist=.35);steel=dict(color=[211,213,211],rough=.16,metal=1);gold=dict(color=[216,181,96],rough=.18,metal=1);specs=[]
def add(pid,name,dims,geo,official,materials,label,evidence,locale='tr_tr',market='Türkiye',estimated=None):
 specs.append(dict(sku=pid,name=name,dims=dims,hwd=[dims[1],dims[0],dims[2]],official=official,estimated=estimated or[],geometry=geo,size_url='https://www2.hm.com/'+locale+'/productpage.'+pid+'.html',market=market,label=label,color=name,claim='Exact SKU'+pid+' own official metrics and materials: '+json.dumps(official,ensure_ascii=False)+'. Local unlabelled thicknesses, component heights and surface variation remain own-photograph interpretations.',evidence_files=[str(R/evidence)],note='Kendi SKU’sunun özgün galeri biçimi ve yayımlanmış ölçüleri kullanılmıştır. Yayımlanmamış cidar, taban, delik boyu, yerel parça konumu ve yüzey değişimleri kendi fotoğrafından yorumdur. Ürünle sergilenen ilave mum/çiçek modele dahil değildir.',materials=materials))
for pid,big,dims in[('1329200001',False,[10,7.1,10]),('1329201001',True,[20.4,10,20.4])]:add(pid,('Büyük'if big else'Küçük')+' cam ikebana vazo · Gerçek delikli çelik ek',dims,lambda big=big:ikebana(big),{'height_cm':[dims[1]],'lower_diameter_cm':[12 if big else 5],'top_diameter_cm':[dims[0]]},{'glass':clear,'steel':steel},'Cam %100 · Paslanmaz çelik ek','source-evidence/'+pid+'.json')
for pid,style,dims in[('1338089001','rattan',[12.5,18,12.5]),('1351751001','small',[15.1,18.6,15.1]),('1351752001','large',[20.3,27.1,20.3])]:add(pid,'Rattan tabanlı cam fener mumluk'if style=='rattan'else'Altın renk çelik tabanlı cam fener mumluk',dims,lambda style=style:lantern(style),{'complete_height_cm':[dims[1]],'maximum_base_diameter_cm':[dims[0]]},{'glass':clear,**({'rattan':dict(color=[211,180,136],rough=.54,kind='wood')}if style=='rattan'else{'gold':gold})},'Cam üst %100 · Rattan taban %100'if style=='rattan'else'Cam üst %100 · Paslanmaz çelik taban %100','source-evidence/'+pid+'.json')
add('1334740001','Küre ayaklı paslanmaz çelik kase',[26,4.9,26],steel_bowl,{'diameter_cm':[26],'height_cm':[4.9]},{'steel':steel},'Paslanmaz çelik %100','source-evidence/1334740001.json')
add('1305498001','Mermer kaşıklık',[13,17,13],marble_holder,{'diameter_cm':[13],'height_cm':[17]},{'marble':dict(color=[220,207,181])},'Mermer %100','research-03.txt','en_us','United States')
add('1311565003','Mermer tabanlı gümüş renk takı standı',[12,25,12],jewellery,{'base_diameter_cm':[12],'height_cm':[25]},{'marble':dict(color=[220,207,181]),'steel':steel},'Mermer %100 · Paslanmaz çelik %100','research-06.txt','fr_fr','France')
add('1353962001','Yuvarlatılmış köşeli stoneware sabunluk',[13,2.5,8.7],soapdish,{'width_cm':[13],'depth_cm':[8.7]},{'ceramic':dict(color=[236,230,213],rough=.28,kind='reactive')},'Stoneware %100','source-evidence/1353962001.json',estimated=['height_cm'])
add('1351756003','Yeşil yuvalı saydam kare cam şamdan',[4,8,4],green_block,{'width_cm':[4],'height_cm':[8],'depth_cm':[4]},{'glass':clear,'green':dict(color=[255,255,255],rough=.045,trans=.98,atten=[.14,.23,.018],dist=.004)},'Cam %100','source-evidence/1351756003.json')
for pid,ma in[('1351726001',steel),('1351726002',gold)]:add(pid,'Bükümlü paslanmaz çelik duvar şamdanı',[5.7,22.3,5.7],twisted_sconce,{'width_cm':[5.7],'height_cm':[22.3]},{'metal':ma},'Paslanmaz çelik %100','source-evidence/'+pid+'.json',estimated=['depth_cm'])
for s in specs:
 if s['sku']in['1305498001','1311565003']:s['evidence_files'] +=[str(R/(s['sku']+'-marble-provenance.json')),str(R/(s['sku']+'-native-marble-crop.png'))]
 if s['sku']=='1311565003':s.update(size_url='https://www2.hm.com/tr_tr/productpage.1311565003.html',market='Türkiye');s['evidence_files'].append(str(R/'source-evidence/1311565003.json'))
if __name__=='__main__':
 for s in specs:
  if len(sys.argv)==1 or s['sku']in sys.argv[1:]:E.build(s)
