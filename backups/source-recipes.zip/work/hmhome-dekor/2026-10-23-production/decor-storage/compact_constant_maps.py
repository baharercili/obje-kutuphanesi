"""Lossless uniform-field texture residency optimization, only unfrozen new34 assets."""
import sys,json,hashlib,shutil
from pathlib import Path
sys.dont_write_bytecode=True
import numpy as np
from PIL import Image
import engine as E
R=E.R;allrows=json.loads((R/'unfrozen-new34-candidates.json').read_text());rows=[e for e in allrows if len(sys.argv)==1 or e['sku']in sys.argv[1:]];frozen={e['id']for p in R.glob('frozen-*-manifest.json')for e in json.loads(p.read_text())};outproof=[p for p in json.loads((R/'lossless-constant-map-optimization-proof.json').read_text())if p['id']not in {e['id']for e in rows}]if(R/'lossless-constant-map-optimization-proof.json').exists()else[]

def geometry_bytes(doc,bin):
 chunks=[]
 for mesh in doc['meshes']:
  for p in mesh['primitives']:
   for key,index in sorted(dict(p['attributes'],_indices=p['indices']).items()):
    a=doc['accessors'][index];v=doc['bufferViews'][a['bufferView']];width={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}[a['type']];size={5121:1,5123:2,5125:4,5126:4}[a['componentType']];off=v.get('byteOffset',0)+a.get('byteOffset',0);stride=v.get('byteStride',width*size);data=b''.join(bin[off+j*stride:off+j*stride+width*size]for j in range(a['count']));chunks.append((mesh.get('name'),key,a['type'],a['componentType'],a['count'],hashlib.sha256(data).hexdigest()))
 return chunks
for e in rows:
 assert e['id']not in frozen
 folder=Path(e['asset_dir']);model=json.loads(Path(e['model_path']).read_text());before,bb=E.G.read_glb(e['glb_path']);geo=geometry_bytes(before,bb);changes=[]
 for key,ma in model['materials'].items():
  for slot in ['baseColorTexture','normalTexture','metallicRoughnessTexture']:
   p=folder/ma[slot];image=Image.open(p);ext=image.getextrema()
   if max(image.size)<=256 or not all(a==b for a,b in ext):continue
   # Preserve exact full generated-map master. This is a crop of a proven constant
   # field, never downsampling a detailed source/photo map.
   backup=R/'constant-generated-map-masters'/e['id']/(p.stem+'-'+E.sha(p)[:12]+'.png');backup.parent.mkdir(parents=True,exist_ok=True)
   if not backup.exists():shutil.copyfile(p,backup)
   else:assert E.sha(backup)==E.sha(p)
   oldsize=list(image.size);color=image.getpixel((0,0));Image.new(image.mode,(256,256),color).save(p,optimize=True);check=Image.open(p);assert check.getextrema()==ext;changes.append(dict(material=key,slot=slot,original_native_size=oldsize,representation_size=[256,256],all_original_channel_ranges=ext,every_source_texel_exactly_same=True,constant_sample=color,immutable_generated_master=str(backup),master_sha256=E.sha(backup),output_sha256=E.sha(p),detail_lost=False,geometric_resampling_count=0))
  ma['extras']['native_resolution']=list(Image.open(folder/ma['baseColorTexture']).size)
 model['metadata']['lossless_uniform_map_optimization']='Only proven spatially uniform generated PBR fields use an exact256pxuniform representation; every UV sample and physical parameter remains exactly the same. Detailed own-source print/fibre/crop maps unchanged.';E.dump(e['model_path'],model)
 report=E.G.export_assets(Path(e['model_path']),folder,e['id']);doc,bin=E.G.read_glb(e['glb_path']);doc['samplers']=[dict(magFilter=9729,minFilter=9987,wrapS=10497,wrapT=10497)]
 for tex in doc.get('textures',[]):tex['sampler']=0
 bin=E.M.embed_tangents(doc,bin);E.G.write_glb(e['glb_path'],doc,bin);nd,nb=E.G.read_glb(e['glb_path']);assert geometry_bytes(nd,nb)==geo
 mv=json.loads(Path(e['material_validation']).read_text())
 for m in mv['maps']:m.update(sha256=E.sha(m['path']),native_resolution=list(Image.open(m['path']).size))
 E.dump(e['material_validation'],mv);e.update(sha256=E.sha(e['glb_path']),bytes=Path(e['glb_path']).stat().st_size);E.dump(folder/'entry.json',e);report['deliverable_sha256']['glb']=e['sha256'];report['glb_bytes']=e['bytes'];E.dump(report['files']['validation'],report);outproof.append(dict(id=e['id'],output_glb_sha256=e['sha256'],geometry_positions_normals_tangents_uvs_indices_byte_identical=True,geometry_accessor_proof=geo,changes=changes,photo_and_detailed_maps_untouched=True));E.dump(R/'lossless-constant-map-optimization-proof.json',outproof);print('COMPACTED',e['id'],len(changes),flush=True)
E.dump(R/'lossless-constant-map-optimization-proof.json',outproof);updated={e['id']:e for e in allrows};updated.update({e['id']:e for e in rows});E.dump(R/'unfrozen-new34-candidates.json',list(updated.values()));manifest={e['id']:e for e in json.loads((R/'manifest.json').read_text())}
for e in rows:manifest[e['id']]=e
E.dump(R/'manifest.json',list(manifest.values()));print('DONE',len(rows),flush=True)
