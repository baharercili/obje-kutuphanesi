"""Two own crushed-pulp ornaments: real irregular form and native paper microrelief."""
import sys,json,math,shutil
from pathlib import Path
import numpy as np
from PIL import Image,ImageFilter
sys.dont_write_bytecode=True
import engine as E
import build_fidelity7_rev11 as F
import build_first12 as P
R=E.R;REV=R/'revision12';REV.mkdir(exist_ok=True);rows=[];proof=[]

def subdiv_mesh(g,levels=2):
 p=np.array(g['positions']).reshape(-1,3).tolist();uv=np.array(g['uvs']).reshape(-1,2).tolist();faces=np.array(g['indices']).reshape(-1,3).tolist()
 for _ in range(levels):
  pp=list(p);uu=list(uv);edges={};ff=[]
  def mid(a,b):
   k=tuple(sorted((a,b)))
   if k not in edges:edges[k]=len(pp);pp.append(((np.array(p[a])+p[b])/2).tolist());uu.append(((np.array(uv[a])+uv[b])/2).tolist())
   return edges[k]
  for a,b,c in faces:d=mid(a,b);e=mid(b,c);f=mid(c,a);ff.extend([(a,d,f),(d,b,e),(f,e,c),(d,e,f)])
  p,uv,faces=pp,uu,ff
 return E.raw(g['name'],g['material'],p,faces,uv)

def roughen(raw,pid):
 p=np.array(raw['_vertices']);x,y,z=p.T;phase=1 if pid.endswith('2') else 2
 offset=np.stack((.00025*np.sin(y*145+z*110+phase)+.00007*np.sin(y*810-z*300),.00022*np.sin(x*173-z*120+phase)+.00007*np.sin(x*710+z*420),.00027*np.sin(y*180+x*130-phase)+.00008*np.sin(y*900+x*430)),1);raw['_vertices']=(p+offset).tolist();raw['name']+='-own-irregular-crushed-pulp-surface';return F.mesh_from_raw(raw)

def pulp_material(pid,out,ma,old):
 master=R/'originals'/('1248654002-801847fc5a39.jpg'if pid.endswith('2')else'1248654003-6477f559433f.jpg');box=(1000,1950,1400,2350)if pid.endswith('2')else(1000,2100,1400,2500);crop=Image.open(master).convert('RGB').crop(box);raw=REV/(pid+'-native-plain-pulp-crop.png');crop.save(raw);lum=crop.convert('L');h=np.array(lum.filter(ImageFilter.GaussianBlur(.5)),float)-np.array(lum.filter(ImageFilter.GaussianBlur(5)),float);h-=h.mean();h=np.clip(h/max(h.std(),1e-8),-2,2);rgb=np.clip(np.array([237,234,223])+h[:,:,None]*.9,0,255).astype('uint8');dy,dx=np.gradient(h*.35);normal=np.stack((-dx,-dy,np.ones_like(dx)),2);normal/=np.linalg.norm(normal,axis=2,keepdims=True);orm=np.zeros_like(rgb);orm[:]=[255,235,0]
 for slot,q in[('baseColorTexture',rgb),('normalTexture',np.clip((normal+1)*127.5,0,255).astype('uint8')),('metallicRoughnessTexture',orm)]:Image.fromarray(q).save(out/ma[slot],optimize=True)
 pr=REV/(pid+'-own-pulp-provenance.json');digest=E.sha(master);E.dump(pr,dict(master=str(master),master_sha256=digest,master_unchanged=True,native_crop_box_pixels=list(box),native_crop_path=str(raw),crop_pixel_identity=True,material_native_pixels=list(crop.size),upscaled=False,geometric_resampling_count=0,physical_texel_period_m=.00015,method='Exact own closeup native plain crushed-pulp patch, away from bow/body silhouette and backdrop. Native crinkle/pulp microrelief supplies normal; broad illumination rejected and intrinsic warm white albedo remains nearly uniform. Smooth globally consistent physical form warp adds real shallow irregularity without open cracks. No marketing-photo projection.'));ma.update(normalScale=.9);ma['extras'].update(own_photo_material_crop=True,native_crop_provenance=str(pr),native_resolution=list(crop.size),source_effective_detail_pixels=list(crop.size),intrinsic_illumination_removed=True);return pr,raw

for pid in['1248654002','1248654003']:
 old=F.OLD[pid];id=old['id']+'-pulprev12';out=R/'models'/id;assert not out.exists();out.mkdir();m=json.loads(Path(old['model_path']).read_text())
 for p in Path(old['asset_dir']).glob('*.png'):
  if p.name not in['on.png','yan.png','on-capraz.png','ustten.png']:shutil.copyfile(p,out/p.name)
 pr,raw=pulp_material(pid,out,m['materials']['paper'],old)
 if pid.endswith('2'):
  materials=[]
  for j,(r,cy,ry)in enumerate([(.022,.023,.023),(.0175,.057,.017),(.013,.080,.012)]):
   g=P.sphere('own-white-crushed-pulp-snowman-lobe-'+str(j),'paper',1);g['_vertices']=[(x*r,y*ry+cy,z*r)for x,y,z in g['_vertices']];materials.append(roughen(g,pid))
  for name,profile in [('rounded-white-pulp-top-hat-brim',[(0,.087),(.014,.087),(.016,.088),(.016,.090),(.014,.091),(0,.091)]),('short-white-pulp-hat-crown',[(0,.090),(.010,.090),(.011,.092),(.011,.100),(.009,.102),(0,.102)])]:materials.append(roughen(E.lathe('own-source-'+name,'paper',profile,192),pid))
  m['meshes']=[g for g in m['meshes']if g['material']!='paper']+materials
 else:m['meshes']=[roughen(subdiv_mesh(g,2),pid)if g['material']=='paper'else g for g in m['meshes']]
 for g in m['meshes']:
  if g['material']=='paper':F.physical_uv(g,.060,.060)
 p=np.concatenate([np.array(g['positions']).reshape(-1,3)for g in m['meshes']]);lo=p.min(0);hi=p.max(0);dim=np.array(old['dimensions_cm'])/100;targetlo=np.array([-dim[0]/2,0,-dim[2]/2]);scale=dim/(hi-lo)
 for g in m['meshes']:
  p=np.array(g['positions']).reshape(-1,3);n=np.array(g['normals']).reshape(-1,3);p=(p-lo)*scale+targetlo;n/=scale;n/=np.linalg.norm(n,axis=1)[:,None];g.update(positions=np.round(p,9).reshape(-1).tolist(),normals=np.round(n,9).reshape(-1).tolist())
 note='Özgün yakın plandan ezilmiş kağıt/pulp mikro kırışıklığı, hafif düzensiz gerçek heykelsi yüzey ve yansız sıcak beyaz albedo. Tüm metrik eksenler hâlâ açık fotoğraf tahminidir; açıklamadaki kağıt ve bileşimdeki pamuk çelişkisi korunur.'
 if pid.endswith('2'):note+=' Özgün üst profilindeki beyaz yuvarlatılmış şapka kenarı ve kısa tepe ayrı fiziksel parçalardır; boyalı yüz eklenmez.'
 e=dict(old,id=id,asset_dir=str(out),model_path=str(out/'model.json'),glb_path=str(out/(id+'.glb')),geometry_validation=str(out/'geometry-validation.json'),material_validation=str(out/'material-validation.json'),source_evidence_files=old['source_evidence_files']+[str(pr),str(raw)],material_pattern_provenance=str(pr),model_revision='hm-own-crushed-pulp-surface-and-form12',quality_pending=True,model_status='candidate_pending_independent_and_root_actual')
 for k in['frozen','native_renders','scn_path','source_comparison_path','independent_validation_file','visual_validation_file','production_manifest','production_frozen']:e.pop(k,None)
 m['metadata'].update(id=id,material_pattern_provenance=str(pr),source_evidence_files=e['source_evidence_files'],source_fidelity_revision_note=note,metric_recalibration_scale=scale.tolist(),source_hat_profile_confirmed=pid.endswith('2'));E.dump(e['model_path'],m);E.dump(e['geometry_validation'],dict(valid=True,features=[note],mesh_count=len(m['meshes']),triangles=sum(len(g['indices'])//3 for g in m['meshes']),closed_material_solids=True,final_validation_pending=True));maps=[]
 for key,ma in m['materials'].items():
  for slot in['baseColorTexture','normalTexture','metallicRoughnessTexture']:
   p=out/ma[slot];maps.append(dict(material=key,slot=slot,path=str(p),sha256=E.sha(p),native_resolution=list(Image.open(p).size)))
 E.dump(e['material_validation'],dict(valid=True,maps=maps,source_masters_unchanged=True,photo_rgb_projected=False));E.G.export_assets(Path(e['model_path']),out,id);d,b=E.G.read_glb(e['glb_path']);d['samplers']=[dict(magFilter=9729,minFilter=9987,wrapS=10497,wrapT=10497)]
 for t in d.get('textures',[]):t['sampler']=0
 b=E.M.embed_tangents(d,b);E.G.write_glb(e['glb_path'],d,b);e.update(sha256=E.sha(e['glb_path']),bytes=Path(e['glb_path']).stat().st_size);E.dump(out/'entry.json',e);rows.append(e);proof.append(dict(sku=pid,id=id,sha256=e['sha256'],previous_frozen_glb_unchanged=E.sha(old['glb_path'])==old['sha256'],previous_sha256=old['sha256'],source_pulp_crop=str(pr),all_axes_estimated=True));E.dump(REV/'pulp2-candidates.json',rows);E.dump(REV/'pulp2-source-proof.json',proof);current=json.loads((R/'manifest.json').read_text());E.dump(R/'manifest.json',current+[e]);print('PULP12',pid,e['bytes'],flush=True)
