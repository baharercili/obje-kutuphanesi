"""Freeze exact new three candidates after independent QA; actual acceptance pending."""
import sys,json,shutil
from pathlib import Path
sys.dont_write_bytecode=True
import engine as E
import validate_independent as Q
R=E.R;REV=R/'revision13';target=R/'frozen-softcloth3-revision13-manifest.json';assert not target.exists()
rows=json.loads((REV/'candidates3b-manifest.json').read_text());assert len(rows)==3 and len({e['sku']for e in rows})==3
final=[]
for old in rows:
 if old['sku']!='1234536001':final.append(old);continue
 # Correct the physical-period provenance in a separate immutable metadata-only
 # final clone. Preserve the entire original prototype binary chunk and PNGs.
 e=dict(old);out=REV/'final-models'/e['id'];assert not(out/'entry.json').exists();out.mkdir(parents=True,exist_ok=True);m=json.loads(Path(e['model_path']).read_text());previous_provenance=Path(m['materials']['fur']['extras']['native_crop_provenance']);pr=json.loads(previous_provenance.read_text());provenance=REV/'1234536001-own-fleece-period13-provenance.json';pr.update(previous_provenance=str(previous_provenance),previous_provenance_sha256=E.sha(previous_provenance),physical_texel_period_m=.00040,method='Exact own-SKU fleece-only192x128native crop is unchanged. Grain-safe intrinsic albedo and native band-pass normal preserve original effective detail. Revision13 maps this crop with0.40mm/nativepixel physical texel period and adds17400closed physical short curled teddy fibres. No background, silhouette, macro baked illumination, resampling, upscaling or generic other-SKU material.');E.dump(provenance,pr)
 proof=REV/'1234536001-final-provenance-bin-identity-proof.json';files=e['source_evidence_files']+[str(provenance),str(proof)];m['materials']['fur']['extras']['native_crop_provenance']=str(provenance);m['metadata'].update(material_pattern_provenance=str(provenance),source_evidence_files=files);e.update(asset_dir=str(out),model_path=str(out/'model.json'),glb_path=str(out/(e['id']+'.glb')),geometry_validation=str(out/'geometry-validation.json'),material_validation=str(out/'material-validation.json'),material_pattern_provenance=str(provenance),source_evidence_files=files)
 for p in Path(old['asset_dir']).glob('*.png'):shutil.copyfile(p,out/p.name)
 E.dump(e['model_path'],m);shutil.copyfile(old['geometry_validation'],e['geometry_validation']);ma=json.loads(Path(old['material_validation']).read_text())
 for q in ma['maps']:q['path']=str(out/Path(q['path']).name)
 E.dump(e['material_validation'],ma);doc,binary=E.G.read_glb(old['glb_path']);doc['extras']['metadata']=m['metadata']
 for ma in doc['materials']:
  if ma['name']=='fur':ma.setdefault('extras',{})['native_crop_provenance']=str(provenance)
 E.G.write_glb(e['glb_path'],doc,binary);e.update(sha256=E.sha(e['glb_path']),bytes=Path(e['glb_path']).stat().st_size);newdoc,newbinary=E.G.read_glb(e['glb_path']);assert newbinary==binary;E.dump(proof,dict(previous_glb=old['glb_path'],previous_sha256=old['sha256'],previous_unchanged=E.sha(old['glb_path'])==old['sha256'],new_glb=e['glb_path'],new_sha256=e['sha256'],entire_binary_chunk_identical=True,binary_sha256=__import__('hashlib').sha256(binary).hexdigest(),geometry_maps_and_all_accessors_byte_identical=True,changed_only='Own fleece physical-period local provenance alias; no geometry or map pixel changes. Correct period0.40mm/nativepixel agrees with revision13 UV and material extras.',root_actual_review_still_required=True));E.dump(out/'entry.json',e);final.append(e)
checks=[];integrity=[];frozen=[]
for e in final:
 q=Q.check(e);checks.append(q);print('FINAL13 QA',e['sku'],'pass',flush=True);f=dict(e,frozen=True,model_status='candidate_requires_root_actual_four_view_review',quality_pending=True,native_render_pending=True,root_actual_four_views_required=True,native_four_views_reviewed=False,native_renders={},scn_path=None,previous_native_pngs_excluded_from_final_evidence=True,native_render_policy='Root explicitly instructed no further Metal rendering. Root will render these exact GLB bytes in actual Three and compare four real angles before acceptance. CPU flat-shaded geometry diagnostics are not PBR or actual acceptance.',independent_validation_file=str(R/'frozen-softcloth3-revision13-independent-validation.json'),source_photo_masters_unchanged=True);frozen.append(f)
 paths=[Path(e[k])for k in['model_path','glb_path','geometry_validation','material_validation']]+[Path(p)for p in e['source_evidence_files']]+[Path(q['path'])for q in e['original_images']]+list(Path(e['asset_dir']).glob('*.png'))
 for p in dict.fromkeys(paths):integrity.append(dict(id=e['id'],path=str(p),sha256=E.sha(p),bytes=p.stat().st_size))
 for p in e['original_images']:assert E.sha(p['path'])==p['sha256']
preserved=[]
for filename in['frozen-active72-99-production-review-manifest.json','frozen-fidelity7-revision11-manifest.json','frozen-fidelity12-revision12-manifest.json']:
 p=R/filename;prior=json.loads(p.read_text());assert all(E.sha(e['glb_path'])==e['sha256']for e in prior);preserved.append(dict(manifest=str(p),sha256=E.sha(p),all_glbs_unchanged=True,models=len(prior)))
E.dump(REV/'final3-candidates.json',final);E.dump(R/'frozen-softcloth3-revision13-independent-validation.json',dict(valid=True,products=3,models=3,checks=checks));E.dump(target,frozen);digest=E.sha(target);target.with_suffix('.sha256').write_text(digest+'  '+target.name+'\n');E.dump(R/'frozen-softcloth3-revision13-integrity-proof.json',dict(valid=True,manifest_sha256=digest,products=3,models=3,files=integrity,preserved_previous_manifests=preserved,root_actual_acceptance_pending=True,native_not_attempted_by_root_instruction=True,source_original_jpegs_unchanged=True,previous_frozen_glbs_unchanged=True,accepted_four_revision11_skus_untouched=True,all_other24accepted_skus_untouched=True));print('FROZEN13',digest,sum(e['bytes']for e in frozen),flush=True)
