import sys,json,re,collections,hashlib
from pathlib import Path
sys.dont_write_bytecode=True
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import engine as E
D=E.R;P=D.parent;S=D.parents[3]/'sites/zarahome-vazo-kutuphanesi-final-378';base=json.loads((D/'frozen-active72-99-production-review-manifest.json').read_text());skus={e['sku']for e in base};catpath=S/'ui/hmhome-catalog.json';cat=json.loads(catpath.read_text());rows=[x for x in cat if x['sku']in skus];tree=json.loads((D/'frozen-tree-material-only1-revision18-manifest.json').read_text())[0];lookup=collections.defaultdict(list)
files=sorted(D.glob('**/frozen*-manifest.json'))+[P/'hardgoods/optical-two-layer-prototype-06a/frozen-final2-manifest.json']
for f in files:
 try:arr=json.loads(f.read_text())
 except Exception:continue
 if isinstance(arr,list):
  for e in arr:
   if isinstance(e,dict)and'id'in e and'sha256'in e:lookup[(e['id'],e['sha256'])].append((f,e))
wanted=[(x['id'],re.search(r'[?&]v=([a-f0-9]{64})',x['glb_url']).group(1))for x in rows]+[(tree['id'],tree['sha256'])];assert len(wanted)==99;chosen=[];missing=[]
for key in wanted:
 opts=lookup[key]
 if not opts:missing.append(key);continue
 # Prefer original per-batch frozen files over the older combined active-scope snapshot.
 f,e=min(opts,key=lambda q:('active72'in q[0].name,len(str(q[0]))));chosen.append(dict(entry=e,source_manifest=str(f),source_manifest_sha256=E.sha(f)))
print('WANTED',len(wanted),'MATCHED',len(chosen),'MISSING',missing)
assert not missing and len({e['entry']['sku']for e in chosen})==72
actual=collections.defaultdict(list);four=collections.defaultdict(list)
for f in P.glob('**/dom-checks*.json'):
 try:a=json.loads(f.read_text())
 except Exception:continue
 if not isinstance(a,list):continue
 for r in a:
  if not isinstance(r,dict)or not isinstance(r.get('download'),str):continue
  sha=re.search(r'[?&]v=([a-f0-9]{64})',r['download']);id=r.get('selected');
  if sha and id and (id,sha.group(1))in wanted:actual[(id,sha.group(1))].append(dict(path=str(f),error=r.get('error'),reference=r.get('reference')))
for f in P.glob('**/four-angles.json'):
 try:a=json.loads(f.read_text())
 except Exception:continue
 if not isinstance(a,list):continue
 for r in a:
  if isinstance(r,dict)and(r.get('id'),r.get('sha256'))in wanted:four[(r['id'],r['sha256'])].append(dict(path=str(f),views=r.get('views',[])))
noactual=[];nofour=[];nativeflags=collections.Counter()
for x in chosen:
 e=x['entry'];key=(e['id'],e['sha256']);x['exact_sha_actual_evidence']=actual[key];x['exact_sha_four_angle_evidence']=four[key]
 if not actual[key]:noactual.append(e['id'])
 if not four[key]:nofour.append(e['id'])
 nativeflags[(str(e.get('native_four_views_reviewed')),str(e.get('native_render_pending')),len(e.get('native_renders',{})))]+=1
print('NOACTUAL',noactual);print('NOFOURCOUNT',len(nofour),'NATIVEFLAGCOUNTS',list(nativeflags.items()))
print('SOURCES',collections.Counter(Path(x['source_manifest']).name for x in chosen));E.dump(D/'revision19/selection-dry-run.json',dict(rows=chosen,canonical_read_snapshot=dict(path=str(catpath),sha256=E.sha(catpath),selected_entries=len(rows),selected_skus=len({x['sku']for x in rows})),missing_actual_ids=noactual,four_angle_record_missing_ids=nofour));print('DRYRUN OK')
