import sys,json
from pathlib import Path
import numpy as np
sys.dont_write_bytecode=True
import engine as E
import build_fidelity7_rev11 as F
R=E.R;rev=R/'revision11';rows=json.loads((rev/'candidates7-manifest.json').read_text());proof=json.loads((rev/'source-identity-proof.json').read_text())
for e in rows:
 out=Path(e['asset_dir']);m=json.loads(Path(e['model_path']).read_text());v=np.concatenate([np.array(g['positions']).reshape(-1,3)for g in m['meshes']]);lo=v.min(0);hi=v.max(0);dim=np.array(e['dimensions_cm'])/100;targetlo=np.array([-dim[0]/2,0,-dim[2]/2]);scale=dim/(hi-lo);needs=not(np.allclose(hi-lo,dim,atol=1e-8)and np.allclose(lo,targetlo,atol=1e-8))
 if not needs:print('EXACT',e['sku'],flush=True);continue
 before=e['sha256']
 for g in m['meshes']:
  p=np.array(g['positions']).reshape(-1,3);n=np.array(g['normals']).reshape(-1,3);p=(p-lo)*scale+targetlo;n/=scale;n/=np.linalg.norm(n,axis=1)[:,None];g.update(positions=np.round(p,9).reshape(-1).tolist(),normals=np.round(n,9).reshape(-1).tolist())
 m['metadata']['fidelity_revision_metric_calibration']=dict(scale=scale.tolist(),reason='New pile removes earlier sparse-fibre bbox extremes; recalibrate complete own revised model to unchanged published/declared outer metric envelope.',old_geometry_exact_identity_after_common_metric_calibration=False);E.dump(e['model_path'],m);E.G.export_assets(Path(e['model_path']),out,e['id']);d,b=E.G.read_glb(e['glb_path']);d['samplers']=[dict(magFilter=9729,minFilter=9987,wrapS=10497,wrapT=10497)]
 for t in d.get('textures',[]):t['sampler']=0
 b=E.M.embed_tangents(d,b);E.G.write_glb(e['glb_path'],d,b);e.update(sha256=E.sha(e['glb_path']),bytes=Path(e['glb_path']).stat().st_size);E.dump(out/'entry.json',e);p=next(x for x in proof if x['sku']==e['sku']);p.update(new_sha256=e['sha256'],metric_recalibration_scale=scale.tolist(),retained_old_mesh_triangle_geometry_identical=0,all_original_geometry_identical=False,pre_metric_recalibration_unfrozen_sha256=before)
 manifest=json.loads((R/'manifest.json').read_text());E.dump(R/'manifest.json',[e if x['id']==e['id']else x for x in manifest]);print('CALIBRATED',e['sku'],scale.tolist(),flush=True)
E.dump(rev/'candidates7-manifest.json',rows);E.dump(rev/'source-identity-proof.json',proof)
