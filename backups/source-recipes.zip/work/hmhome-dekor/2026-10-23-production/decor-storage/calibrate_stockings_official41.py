"""Final source-metric calibration of six unaccepted stocking assets; old staging left intact."""
import sys,json,math,shutil
from pathlib import Path
sys.dont_write_bytecode=True
import numpy as np
import engine as E
import build_first12 as P
R=E.R;oldrows=[e for e in json.loads((R/'manifest.json').read_text())if e['sku']in ['1300232002','1348487001','1348487002','1349831001','1350119001','1350119002']];assert len(oldrows)==6;newrows=[]
for old in oldrows:
 pid=old['sku'];model=json.loads(Path(old['model_path']).read_text());meshes=model['meshes'];new=[]
 if pid=='1300232002':
  cuff=next(m for m in meshes if 'hollow-folded-cuff'in m['name']);v=np.array(cuff['positions']).reshape(-1,3);lo=v.min(0);hi=v.max(0)
  for j in range(2):
   g=P.sphere('own-source-brown-fluffy-pompom-'+str(j),'cuff',1);g['_vertices']=[(hi[0]+.016+x*.017,hi[1]-.035-j*.035+y*.019,.014+z*.015)for x,y,z in g['_vertices']];new.append(g)
 parts=[]
 for m in meshes:parts.append(E.raw(m['name'],m['material'],np.array(m['positions']).reshape(-1,3).tolist(),np.array(m['indices']).reshape(-1,3).tolist(),np.array(m['uvs']).reshape(-1,2).tolist()))
 parts+=new;v=np.concatenate([g['_vertices']for g in parts]);lo=v.min(0);hi=v.max(0);w=old['dimensions_cm'][0]
 if pid.startswith('1350119'):
  top=v[v[:,1]>=old['dimensions_cm'][1]/100*.63];upper=top[:,0].max()-top[:,0].min();w=round((hi[0]-lo[0])*.21/upper*100,4)
 dims=[w,41,old['dimensions_cm'][2]];scale=np.array(dims)/100/(hi-lo);center=np.array([(lo[0]+hi[0])/2,lo[1],(lo[2]+hi[2])/2]);result=[];checks=[]
 for g in parts:
  g['_vertices']=[tuple((np.array(p)-center)*scale)for p in g['_vertices']];g=E.H.orient(g);m,c=E.G._finalize(g);E.H.S.flatcap_normals(m);result.append(m);checks.append(c)
 repairs=E.M.ensure_uv_faces(result)+E.H.ensure_float32_uv(result);fmt=lambda x:format(x,'g').replace('.','p');id='hm-'+pid+'-h41-w'+fmt(w)+'-d'+fmt(dims[2]);out=R/'models'/id;out.mkdir(exist_ok=False)
 for ma in model['materials'].values():
  for key in ['baseColorTexture','normalTexture','metallicRoughnessTexture']:shutil.copyfile(Path(old['asset_dir'])/ma[key],out/ma[key])
 note='Resmî41cmçorap/totalyükseklik tam görünen zarfa uygulanır. Yayımlanmış31/22cmgenişlik veya ayı tasarımındaki21cmüst genişlik ankrajı korunur. Derinlik, yerel kat/sap/kulak/dikiş boyları kendi fotoğrafından yorumdur. Üretici CAD veya taraması değildir.';meta=model['metadata'];meta.update(id=id,dimensions_cm=dims,source_dimensions_hwd_cm=[41,w,dims[2]],estimated_fields=[x for x in meta['estimated_fields']if x not in ['height_cm','hanging_loop_pose']],diameter_semantics=note,scale_note=note,official_total_height_cm=41,source_metric_calibration='Published41cmheight applied to full outer bounding envelope, including hanger.',replaces_unaccepted_staging_id=old['id']);model.update(meshes=result);E.dump(out/'model.json',model);E.dump(out/'geometry-validation.json',dict(valid=True,mesh_count=len(result),meshes=checks,triangles=sum(c['triangles']for c in checks),uv_repairs=repairs,features=['Official41cmfull envelope calibrated','Source upper21cmwidth retained on bears; whole foot width remains estimated','Brown stocking own two actual pompoms included'],closed_material_solids=True));mv=json.loads(Path(old['material_validation']).read_text())
 for q in mv['maps']:q['path']=str(out/Path(q['path']).name)
 E.dump(out/'material-validation.json',mv);report=E.G.export_assets(out/'model.json',out,id);path=out/(id+'.glb');d,b=E.G.read_glb(path);d['samplers']=[dict(magFilter=9729,minFilter=9987,wrapS=10497,wrapT=10497)]
 for tx in d['textures']:tx['sampler']=0
 b=E.M.embed_tangents(d,b);E.G.write_glb(path,d,b);report['deliverable_sha256']['glb']=E.sha(path);report['glb_bytes']=path.stat().st_size;E.dump(report['files']['validation'],report)
 e=dict(old,id=id,dimensions_cm=dims,source_dimensions_hwd_cm=meta['source_dimensions_hwd_cm'],estimated_fields=meta['estimated_fields'],diameter_semantics=note,scale_note=note,asset_dir=str(out),model_path=str(out/'model.json'),glb_path=str(path),sha256=E.sha(path),bytes=path.stat().st_size,geometry_validation=str(out/'geometry-validation.json'),material_validation=str(out/'material-validation.json'),replaces_unaccepted_staging_id=old['id']);E.dump(out/'entry.json',e);newrows.append(e);print('CALIBRATED',id,flush=True)
E.dump(R/'superseded-unaccepted-stockings6.json',oldrows);E.dump(R/'official41-stockings6-candidates.json',newrows)
