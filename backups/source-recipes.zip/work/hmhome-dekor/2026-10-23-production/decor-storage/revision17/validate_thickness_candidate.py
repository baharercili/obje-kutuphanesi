"""Read back exact delivered bytes independently of the append writer."""
import sys,json,io,hashlib
from pathlib import Path
import numpy as np
from PIL import Image
sys.dont_write_bytecode=True
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import engine as E
import validate_independent as Q
R=E.R;REV=R/'revision17';e=json.loads((REV/'tree-thickness1-candidates.json').read_text())[0];general=Q.check(e);doc,b=Q.glb(Path(e['glb_path']));p=doc['meshes'][0]['primitives'][0]
def arr(index):
 a=doc['accessors'][index];v=doc['bufferViews'][a['bufferView']];dt={5126:'<f4',5125:'<u4',5123:'<u2'}[a['componentType']];ch={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}[a['type']];sz=np.dtype(dt).itemsize
 return np.ndarray((a['count'],ch),dtype=dt,buffer=b,offset=v.get('byteOffset',0)+a.get('byteOffset',0),strides=(v.get('byteStride',ch*sz),sz)).copy()
uv=arr(p['attributes']['TEXCOORD_1']);pos=arr(p['attributes']['POSITION']);faces=arr(p['indices']).reshape(-1,3);data=np.load(REV/'1354951003-geometry-derived-thickness.npz');assert np.array_equal(uv,data['uv1']);assert len(uv)==len(pos);assert np.isfinite(uv).all()and uv.min()>=0 and uv.max()<=1;du=uv[faces[:,1]]-uv[faces[:,0]];dv=uv[faces[:,2]]-uv[faces[:,0]];det=du[:,0]*dv[:,1]-du[:,1]*dv[:,0];assert np.all(abs(det)>0)
ma=doc['materials'][0];ph=ma['pbrMetallicRoughness'];vol=ma['extensions']['KHR_materials_volume'];assert ph['metallicFactor']==0;assert ma['extensions']['KHR_materials_transmission']['transmissionFactor']==1;assert vol['thicknessTexture']['texCoord']==1;assert vol['thicknessFactor']==.030 and vol['attenuationDistance']==.0045;assert vol['attenuationColor']==[.26,.40,.018]
texture=doc['textures'][vol['thicknessTexture']['index']];sampler=doc['samplers'][texture['sampler']];assert sampler['wrapS']==sampler['wrapT']==33071;im=doc['images'][texture['source']];view=doc['bufferViews'][im['bufferView']];png=b[view['byteOffset']:view['byteOffset']+view['byteLength']];source=Path(e['asset_dir'])/'1354951003-geometry-derived-local-caliper-thickness17.png';assert png==source.read_bytes();array=np.array(Image.open(io.BytesIO(png)));assert array.shape==(2048,2048,3)and array[:,:,0].max()==array[:,:,2].max()==0;green=array[:,:,1];assert green.min()<=4 and green.max()==255
# Check a large set of actual UV1 triangle interiors against metric per-vertex calipers.
N=green.shape[0];bary=np.array([.29,.33,.38]);samples=(uv[faces]*bary[None,:,None]).sum(1)*N-.5;ix=np.floor(samples[:,0]).astype(int);iy=np.floor(samples[:,1]).astype(int);dx=samples[:,0]-ix;dy=samples[:,1]-iy;assert ix.min()>=0 and ix.max()+1<N and iy.min()>=0 and iy.max()+1<N
sampled=((1-dx)*(1-dy)*green[iy,ix]+dx*(1-dy)*green[iy,ix+1]+(1-dx)*dy*green[iy+1,ix]+dx*dy*green[iy+1,ix+1])*.030/255;expected=(data['thickness_clamped_m'][faces]*bary[None,:]).sum(1);error=abs(sampled-expected);significant=np.abs(det)>2e-6
# Pixel quantisation/8-bit error is allowed; ultra-thin top triangles are documented and not used to hide gross channel/binding faults.
assert significant.sum()>5000;assert np.quantile(error[significant],.95)<.00022;assert np.quantile(error[significant],.99)<.00065
# Geometry independent optical check: fin tips have <=.45mm clamped depth while real inward valley chords exceed10mm.
slab=data['reference_thickness_m'];peaks=data['reference_fin_peaks'];assert np.max(slab[peaks])<.000001;assert np.quantile(slab,.75)>.010;assert np.max(data['thickness_clamped_m'])==.030
master_checks=[]
for q in e['original_images']:assert E.sha(q['path'])==q['sha256'];master_checks.append(dict(path=q['path'],sha256=q['sha256'],unchanged=True))
report=dict(valid=True,id=e['id'],sku=e['sku'],glb_sha256=e['sha256'],glb_bytes=e['bytes'],general_independent_QA=general,additional_uv1=dict(vertices=len(uv),triangles=len(faces),finite=True,bounds=[uv.min(0).tolist(),uv.max(0).tolist()],all_float32_triangle_areas_nondegenerate=True,not_used_for_albedo_or_normals=True),volume_texture=dict(embedded=True,channel='G',texCoord=1,metallic_factor=0,transmission=1,ior=ma['extensions']['KHR_materials_ior']['ior'],thicknessFactor_m=.030,attenuationDistance_m=.0045,attenuationColor=vol['attenuationColor'],green_byte_range=[int(green.min()),int(green.max())],metric_quantisation_step_m=.030/255,original_png_byte_identical=True),map_vs_geometry_sample_check=dict(sampled_triangles=len(faces),well_resolved_triangles=int(significant.sum()),all_triangle_error_quantiles_m=np.quantile(error,[0,.5,.95,.99,1]).tolist(),well_resolved_error_quantiles_m=np.quantile(error[significant],[0,.5,.95,.99,1]).tolist(),native_triangles_without_pixel_centres=2,subpixel_triangles_use_interpolated_gutter_not_fabricated_extra_geometry=True),optical_reference_interpretation='One homogeneous intrinsic glass with geometry-derived local thickness; neither photograph albedo nor reflection masks are used. Explicit numerical0.45–30mm optical clamps are approximate reconstruction details, not manufacturer wall gauge.',original_master_checks=master_checks,canonical_and_other71_untouched=True,root_actual_four_view_acceptance_pending=True,native_metal_not_started_per_root_policy=True)
E.dump(REV/'1354951003-thickness-extra-independent-validation.json',report);print('THICKNESS17 independent PASS',e['sha256'],'error95',np.quantile(error[significant],.95),'error99',np.quantile(error[significant],.99),flush=True)
