import sys,json
from pathlib import Path
sys.dont_write_bytecode=True
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import engine as E
R=E.R;REV=R/'revision17';p=REV/'tree-thickness1-candidates.json';e=json.loads(p.read_text())[0];extra=str(REV/'1354951003-thickness-extra-independent-validation.json');assert not(R/'frozen-tree-thickness1-revision17-manifest.json').exists();assert Path(extra).exists();assert extra not in e['source_evidence_files'];e['source_evidence_files'].append(extra);e['optical_independent_validation_file']=extra;m=json.loads(Path(e['model_path']).read_text());m['metadata']['source_evidence_files']=e['source_evidence_files'];E.dump(e['model_path'],m);doc,b=E.G.read_glb(e['glb_path']);doc['extras']['metadata']=m['metadata'];E.G.write_glb(e['glb_path'],doc,b);assert E.G.read_glb(e['glb_path'])[1]==b;e.update(sha256=E.sha(e['glb_path']),bytes=Path(e['glb_path']).stat().st_size);proofpath=REV/'1354951003-geometry-thickness-optical-provenance-proof.json';proof=json.loads(proofpath.read_text());proof['new_sha256']=e['sha256'];E.dump(proofpath,proof);E.dump(p,[e]);E.dump(Path(e['asset_dir'])/'entry.json',e);print('ATTACHED',e['sha256'],e['bytes'])
