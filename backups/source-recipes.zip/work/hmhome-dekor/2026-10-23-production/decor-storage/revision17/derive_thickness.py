import sys,json,math
from pathlib import Path
import numpy as np
sys.dont_write_bytecode=True
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import engine as E
R=E.R;REV=R/'revision17'
old=next(x for x in json.loads((R/'frozen-tree-material2-revision16-manifest.json').read_text()) if x['id'].endswith('atten0018rev16'))
doc,binary=E.G.read_glb(old['glb_path']);p=doc['meshes'][0]['primitives'][0]
def arr(index):
 a=doc['accessors'][index];v=doc['bufferViews'][a['bufferView']];dt={5126:'<f4',5125:'<u4',5123:'<u2'}[a['componentType']];n={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}[a['type']];s=np.dtype(dt).itemsize
 return np.ndarray((a['count'],n),dtype=dt,buffer=binary,offset=v.get('byteOffset',0)+a.get('byteOffset',0),strides=(v.get('byteStride',n*s),s)).copy()
pos=arr(p['attributes']['POSITION']).astype(float);uv0=arr(p['attributes']['TEXCOORD_0']).astype(float);f=arr(p['indices']).reshape(-1,3)
capmask=np.all(abs(pos[f,1])<1e-9,axis=1);cap=np.unique(f[capmask]);body=np.unique(f[~capmask]);assert not len(np.intersect1d(cap,body))
refids=np.flatnonzero(abs(pos[:,1]-.0025)<1e-8);ref=np.zeros((384,2));refused=np.zeros(384,bool)
for k in refids:
 j=round((.5-uv0[k,0])*384)%384
 if refused[j]:assert np.allclose(ref[j],pos[k,[0,2]],atol=1e-9)
 ref[j]=pos[k,[0,2]];refused[j]=True
assert refused.all();aa=np.mod(np.arctan2(ref[:,1],ref[:,0]),2*np.pi);order=np.argsort(aa);sa=aa[order]
pa=np.mod(np.arctan2(pos[:,2],pos[:,0]),2*np.pi);loc=np.searchsorted(sa,pa);left=order[(loc-1)%384];right=order[loc%384];distance=lambda a,b:np.abs(np.angle(np.exp(1j*(a-b))))
j=np.where(distance(pa,aa[left])<=distance(pa,aa[right]),left,right);ref_r=np.linalg.norm(ref,axis=1);scale=np.linalg.norm(pos[:,[0,2]],axis=1)/ref_r[j]
reconstructed=ref[j]*scale[:,None];err=np.linalg.norm(reconstructed-pos[:,[0,2]],axis=1);assert err.max()<1e-8,err.max()
# Geometry has homothetic closed cross-sections. Derive every profile ring by actual radius/height.
pairs=np.stack((np.round(pos[:,1],8),np.round(scale,6)),axis=1);profile=np.unique(pairs[body],axis=0);profile=profile[np.lexsort((profile[:,1],profile[:,0]))]
profile_index={tuple(p):i for i,p in enumerate(profile)};pi=np.array([profile_index.get(tuple(p),-1)for p in pairs]);assert np.all(pi[body]>=0)
profile_arc=np.r_[0,np.cumsum(np.hypot(np.diff(profile[:,0]),np.diff(profile[:,1])*np.mean(ref_r)))];profile_arc/=profile_arc[-1]
# Six radial lobes are peaks of the measured polygon radius, not a painted per-fin field.
peaks=[]
for k in range(384):
 if ref_r[k]>ref_r[(k-1)%384]and ref_r[k]>=ref_r[(k+1)%384]:peaks.append(k)
assert len(peaks)==6,peaks
axes=ref[peaks]/ref_r[peaks,None];axis_angles=np.arctan2(axes[:,1],axes[:,0]);fin=np.argmin(distance(aa[:,None],axis_angles[None,:]),axis=1)
slab=np.zeros(384);intervals=[]
for k,pt in enumerate(ref):
 axis=axes[fin[k]];across=np.array([-axis[1],axis[0]]);xx=ref@axis;tt=ref@across;s=pt@axis-1e-9;local=pt@across
 q=np.roll(np.arange(384),-1);hit=((xx<=s)&(xx[q]>s))|((xx>s)&(xx[q]<=s));t=tt[hit]+(s-xx[hit])/(xx[q][hit]-xx[hit])*(tt[q][hit]-tt[hit]);t=np.sort(t)
 # A tiny inward ray perturbation avoids the zero-length tangent at an exact outermost point.
 assert len(t)%2==0,(k,len(t));pairs_t=t.reshape(-1,2);near=[v for v in pairs_t if v[0]-1e-7<=local<=v[1]+1e-7]
 if not near:
  chosen=min(pairs_t,key=lambda v:min(abs(local-v[0]),abs(local-v[1])))
  assert min(abs(local-chosen[0]),abs(local-chosen[1]))<1e-6
 else:chosen=max(near,key=lambda v:v[1]-v[0])
 slab[k]=chosen[1]-chosen[0];intervals.append(chosen.tolist())
raw=slab[j]*scale
# The bottom closure is perpendicular to the glass height; use the real vertical ray exit of the radial surface.
for k in cap:
 r=np.linalg.norm(pos[k,[0,2]])
 if r<1e-12:raw[k]=pos[:,1].max();continue
 s=scale[k];eligible=[]
 for a,b in zip(profile[:-1],profile[1:]):
  if (a[1]<=s<=b[1])or(b[1]<=s<=a[1]):
   y=a[0]if abs(b[1]-a[1])<1e-10 else a[0]+(s-a[1])/(b[1]-a[1])*(b[0]-a[0]);eligible.append(y)
 raw[k]=max(eligible)if eligible else .00045
# Preserve original UV0/tangents and use a dedicated angular/arclength UV1 atlas for optical data only.
u=j/384.0
# Retain the old cylinder seam for non-planar shared vertices; flat ledge faces have unique vertices.
flat=np.ptp(pos[f,1],axis=1)<1e-9;nonflat_ids=np.unique(f[~flat]);u[nonflat_ids]=.5-uv0[nonflat_ids,0]
for tri in f[flat&~capmask]:
 vals=u[tri].copy()
 if vals.max()-vals.min()>.5:vals[vals<.5]+=1
 u[tri]=vals
uv1=np.zeros((len(pos),2));uv1[body,0]=.02+.83*u[body];uv1[body,1]=.02+.95*profile_arc[pi[body]]
lo=pos[cap][:,[0,2]].min(0);hi=pos[cap][:,[0,2]].max(0);uv1[cap]=.88+.10*(pos[cap][:,[0,2]]-lo)/(hi-lo)
uv1=uv1.astype('<f4');du=uv1[f[:,1]]-uv1[f[:,0]];dv=uv1[f[:,2]]-uv1[f[:,0]];det=du[:,0]*dv[:,1]-du[:,1]*dv[:,0];assert np.all(abs(det)>0)
# Exclude unreferenced historical source vertices from material statistics.
used=np.unique(f);clipped=np.clip(raw,.00045,.030)
np.savez(REV/'1354951003-geometry-derived-thickness.npz',uv1=uv1,thickness_raw_m=raw,thickness_clamped_m=clipped,faces=f,profile=profile,profile_arc=profile_arc,reference_polygon_m=ref,reference_fin_peaks=np.array(peaks),reference_thickness_m=slab,reference_chord_intervals_m=np.array(intervals),vertex_ring_scale=scale,vertex_reference_index=j,cap_vertices=cap,body_vertices=body,used_vertices=used)
summary=dict(valid=True,source_geometry_glb=old['glb_path'],source_geometry_sha256=old['sha256'],six_geometry_fin_peak_indices=peaks,profile_rings=profile.tolist(),cross_section_homothety_max_error_m=float(err.max()),reference_fin_peak_thickness_m=slab[peaks].tolist(),reference_valley_thickness_m=[float(slab[(k+32)%384])for k in peaks],raw_used_vertex_thickness_quantiles_m=np.quantile(raw[used],[0,.01,.1,.25,.5,.75,.9,.99,1]).tolist(),encoded_range_m=[.00045,.030],used_vertices=len(used),unreferenced_historical_vertices=len(pos)-len(used),uv1_nondegenerate_float32_triangles=True,original_geometry_bytes_preserved=True)
E.dump(REV/'1354951003-thickness-calculation-summary.json',summary);print(json.dumps(summary,indent=2))
