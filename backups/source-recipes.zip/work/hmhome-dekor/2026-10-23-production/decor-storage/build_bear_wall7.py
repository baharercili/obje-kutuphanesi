"""Seven own-source bear, acorn and wall storage objects; genuine openings and fibres."""
import sys,math,json
sys.dont_write_bytecode=True
import numpy as np
from PIL import Image,ImageFilter
import build_first12 as P
import build_woven8 as W
import build_cloth7 as C
import source_fibre_material as F
E=P.E;R=E.R;B=E.B;T=math.tau

def ellipse_face(name,mat,rx,ry,cx,cy,cz):
 g=P.sphere(name,mat,1);g['_vertices']=[(cx+x*rx,cy+y*ry,cz+z*min(rx,ry)*.35)for x,y,z in g['_vertices']];return g

def face(r,y,scale=1,circular=False):
 eyez=(math.sqrt(r*r-(.060*scale)**2)+.0004)if circular else r+.0005;parts=[ellipse_face('actual-left-embroidered-bear-eye','black',.0055*scale,.0055*scale,-.060*scale,y,eyez),ellipse_face('actual-right-embroidered-bear-eye','black',.0055*scale,.0055*scale,.060*scale,y,eyez)];nose=P.extruded('actual-rounded-triangular-black-embroidered-nose','black',[(-.013*scale,.005*scale),(-.010*scale,.009*scale),(.010*scale,.009*scale),(.013*scale,.005*scale),(.002*scale,-.009*scale),(-.002*scale,-.009*scale)],[],-.001,.001);nose['_vertices']=[(x,yy+y-.015*scale,r+.0005+t)for x,t,yy in nose['_vertices']];parts.append(nose);parts.append(W.tube('actual-short-embroidered-bear-mouth-seam','black',[(0,y-.022*scale,r+.0005),(0,y-.036*scale,r+.0005)],.0009*scale,.0009*scale,False,sides=8));return parts

def plush_bear(pid):
 r=.075;h=.108;g=E.lathe('own-short-plush-bear-basket-with-true-cotton-lined-open-cavity','fur',[(0,0),(.057,0),(.069,.005),(.074,.016),(.075,.10),(.073,.108),(.068,.108),(.067,.016),(.064,.010),(0,.010)],256);parts=[g];lining=E.lathe('own-distinct-light-cotton-bear-basket-lining-and-closed-floor','lining',[(0,.010),(.064,.010),(.067,.016),(.068,.106),(.067,.106),(.066,.017),(.063,.012),(0,.012)],256);parts.append(lining)
 for side in[-1,1]:parts.append(ellipse_face('own-sewn-soft-rounded-bear-ear-'+str(side),'fur',.014,.016,side*.035,.116,-.008))
 parts+=face(.074,.060,.55,circular=True)
 # Thousands of individually closed, short curled pile fibres keep the fleece
 # relief real. Their exact spacing is an explicitly interpreted microstructure.
 rng=np.random.default_rng(int(pid[-5:]));fibres=[]
 for j in range(1100):
  a=rng.uniform(0,T);y=rng.uniform(.012,.102);rr=.074;rise=rng.uniform(.0007,.0015);pts=[]
  for s in np.linspace(0,1,5):
   aa=a+.010*math.sin(math.pi*s);rad=rr+rise*math.sin(math.pi*s);pts.append((rad*math.cos(aa),y+.0012*s,rad*math.sin(aa)))
  fibres.append(W.tube('own-curled-plush-pile-fibre-'+str(j),'fur',pts,.00012,.00012,False,sides=5))
 parts.append(W.merge('own1100actual-short-curled-pile-fibres','fur',fibres))
 return parts,['Own short cream/beige bear basket with a truly open cotton-lined cavity and thick closed floor','Two soft rounded sewn ears and actual separate black embroidered eye/nose/mouth geometry','1100individual short curled pile-fibre solids plus intrinsic fleece microstructure; fibre spacing and local embroidery dimensions interpreted from own exact photo'],dict(actual_short_curled_pile_fibres=1100,real_open_cotton_lined_cavity=True)

def dense_body(pid,r,h,pitch=.0032):
 turns=(h-.008)/pitch;pts=[]
 for y in np.linspace(.004,h-.004,math.ceil(turns*128)+1):
  a=T*(y-.004)/pitch;rr=r*(.91+.09*min(1,y/.030));pts.append((rr*math.cos(a),y,rr*math.sin(a)))
 parts=[B.tube('own-dense-continuous-opaque-spiral-fibre-wall-no-stakes','fiber',pts,pitch*.75,pitch*.515,8,False,'radial',uv_scale=.12)]
 turns=(r*.92-.001)/pitch;pts=[]
 for t in np.linspace(0,turns,math.ceil(turns*112)):
  rr=.001+(r*.92-.001)*t/turns;a=T*t;pts.append((rr*math.cos(a),.003,rr*math.sin(a)))
 parts +=[B.tube('own-dense-closed-coiled-bottom','fiber',pts,pitch*.53,pitch*.40,8,False,'radial',uv_scale=.12),E.lathe('closed-centre-knot','fiber',[(0,.001),(.006,.001),(.006,.005),(0,.005)],96),W.tube('own-thick-open-mouth-binding','fiber',[(r*math.cos(a),h-.0015,r*math.sin(a))for a in np.linspace(0,T,256,endpoint=False)],pitch*.75,pitch*.515,True,sides=8)]
 return parts,turns

def wicker_bear(pid):
 r=.121;h=.207;parts,turns=dense_body(pid,r,h)
 for g in parts:
  out=[]
  for x,y,z in g['_vertices']:
   a=math.atan2(z,x);b=(abs(math.cos(a))**6+abs(math.sin(a))**6)**(-1/6);out.append((x*b,y,z*b))
  g['_vertices']=out
 for side in[-1,1]:
  ear=W.spiral('own-flat-coiled-woven-bear-ear-'+str(side),'fiber',.024,0,.0024)
  ear['_vertices']=[(x+side*.063,z+.215,y-.100)for x,y,z in ear['_vertices']];parts.append(ear)
 parts+=face(.123,.115)
 return parts,['Own softly rounded square dense fibre bear basket, physically opaque coil bundle rather than a wicker cage','Real hollow body, tightly coiled floor and thick bound open rim, no visible upright stakes','Two own flat coiled ears and separate black embroidered face geometry; own native microfibre crop excludes the face','Published width/height retained; depth and ear-height allocation explicitly interpreted'],dict(continuous_spiral_turns=turns,source_weave_family='dense_opaque_bound_fibre_bundles',visible_vertical_stakes=0,source_profile='rounded_square',real_open_woven_interior=True,material_pattern_provenance=str(R/(pid+'-fiber-own-fibre-provenance.json')))

def acorn():
 parts,turns=dense_body('1184879001',.094,.143,.0032)
 lid=W.spiral('own-separate-brown-coiled-acorn-lid-closed-top','brown',.101,.161,.0038,.001);parts.append(lid);
 for y in np.linspace(.144,.160,6):parts.append(W.tube('own-thick-brown-dense-coiled-acorn-cover-side','brown',[(.101*math.cos(a),y,.101*math.sin(a))for a in np.linspace(0,T,256,endpoint=False)],.0030,.0017,True,sides=8))
 parts.append(W.tube('own-brown-bound-thick-acorn-lid-edge','brown',[(.101*math.cos(a),.148,.101*math.sin(a))for a in np.linspace(0,T,256,endpoint=False)],.0035,.005,True))
 stem=W.tube('own-braided-open-loop-acorn-stem-attached-through-lid','brown',[(.008*math.cos(a),.169+.023*math.sin(a),.002*math.sin(a))for a in np.linspace(0,T,160,endpoint=False)],.003,.004,True,[0,0,1],10);parts.append(stem)
 leaf=[];theta=.6;cx=.027;cy=.173
 def xy(u,v,z=.004):return(cx+u*math.cos(theta)-v*math.sin(theta),cy+u*math.sin(theta)+v*math.cos(theta),z)
 contour=[xy(.028*math.cos(a),.011*math.sin(a))for a in np.linspace(0,T,192,endpoint=False)];leaf.append(W.tube('own-woven-acorn-leaf-bound-contour','leaf',contour,.0008,.0008,True,[0,0,1],8))
 for j,u in enumerate(np.linspace(-.026,.026,29)):
  d=.011*math.sqrt(max(0,1-(u/.028)**2));leaf.append(W.tube('actual-individual-acorn-leaf-woven-fibre-'+str(j),'leaf',[xy(u,-d),xy(u,d)],.00065,.00065,False,sides=6))
 parts.append(W.merge('own-real-thin-woven-oval-acorn-leaf','leaf',leaf))
 return parts,['Own cream woven acorn-like lidded box, brown wider closed lid, real braided loop stem and distinct pale woven leaf','Actual hollow woven interior and closed floor remain under the separate lid; true strand gaps rather than a solid textured cylinder','No exact sameSKUmetric dimensions published in checked official sources. Every envelope axis is an explicit photo scale estimate'],dict(continuous_spiral_turns=turns,source_weave_family='dense_opaque_bound_fibre_bundles',visible_vertical_stakes=0,material_pattern_provenance=str(R/'1184879001-fiber-own-fibre-provenance.json'),real_open_woven_interior=True,lid_default_state='closed',all_envelope_axes_photo_estimated=True)

def wall_basket():
 parts,rows,warp=W.weave_body('1300617001',.096,.149,pitch_override=.0068)
 # One large vertical woven suspension loop sewn into the rear mouth.
 pts=[(.023*math.sin(a),.151+.042*(1+math.cos(a)), -.086)for a in np.linspace(0,T,192,endpoint=False)];parts.append(W.tube('own-single-thick-braided-wall-hanging-loop','fiber',pts,.0045,.0045,True,[0,0,1],10))
 return parts,['Own small open seagrass wall basket with thick bound mouth, actual woven closed base and one broad real suspension loop','Actual alternating over/under weft/warp geometry and visibly open interior','Official20cmdiameter/height anchors retained; local handle/body height allocation and strand microstructure are own-photo interpretations'],dict(actual_horizontal_weft_courses=rows+1,actual_upright_warp_strands=warp,wall_hanging_loop_count=1)

def wall_organizer():
 parts=[C.panel('own-soft-plush-hanging-back-panel','fur',.46,.25,-.015,.125,.008,.012)]
 for side in[-1,1]:
  pockets=C.rect_shell('own-real-open-plush-front-pocket-'+str(side),'fur',.217,.042,.198,.004)
  for g in pockets:
   verts=g['_vertices'];uv=g['_uvs'];faces=g['_faces']
   for _ in range(2):
    vv=list(verts);uu=list(uv);edges={};ff=[]
    def midpoint(a,b):
     key=tuple(sorted((a,b)))
     if key not in edges:edges[key]=len(vv);vv.append(tuple((np.array(verts[a])+verts[b])/2));uu.append(tuple((np.array(uv[a])+uv[b])/2))
     return edges[key]
    for a,b,c in faces:d=midpoint(a,b);e=midpoint(b,c);f=midpoint(c,a);ff.extend([(a,d,f),(d,b,e),(f,e,c),(d,e,f)])
    verts,uv,faces=vv,uu,ff
   positions=[]
   for x,y,z in verts:
    t=max(0,min(1,y/.198));soft=.012*math.sin(math.pi*t)*max(0,1-(x/.1085)**2) if z>0 else 0;positions.append((x+side*.114,y,z+.010+soft))
   parts.append(E.raw(g['name']+'-softly-bowed-and-rounded-cloth','fur',positions,faces,uv))
 for x in[-.205,0,.205]:
  for side in[-1,1]:
   pts=[(x+side*(.014+.014*math.cos(a)),.271+.012*math.sin(a),-.017+.001*math.sin(a))for a in np.linspace(0,T,128,endpoint=False)];parts.append(W.tube('own-tied-cotton-bow-lobe-'+str(x)+'-'+str(side),'ties',pts,.0025,.0006,True,[0,0,1],8));parts.append(W.tube('own-free-cotton-bow-tail-'+str(x)+'-'+str(side),'ties',[(x,.265,-.015),(x+side*.018,.242,-.014)],.0025,.0006,False,[0,0,1],8))
 return parts,['Own46×25cmplush wall organizer with two genuinely open deep pockets and a continuous soft hanging back panel','Three sets of actual cotton tie loops. Front pockets have their own side walls and closed floor, not a flat printed rectangle','Published14cmtie length is retained as an unfolded source fact; tied-loop posed height and fabric thickness explicitly photo-interpreted'],dict(actual_open_front_pockets=2,source_unfolded_tie_length_cm=14,tied_pose_height_estimated=True)

BASE=E.material
def material(pid,key,**args):
 out,ma=BASE(pid,key,**args)
 if key=='fiber':return F.apply(E,pid,key,out,ma,args,box=(620,1600,1020,1780)if pid in ['1358916001','1358916002']else(600,1320,1000,1620))
 if key=='fur':return F.apply(E,pid,key,out,ma,args,box=(900,1400,1150,1700)if pid=='1234536001'else(620,1600,1020,1780),highpass=5)
 if key=='fur_unused_procedural_fallback':
  n=2048;rng=np.random.default_rng(int(pid[-6:]));noise=rng.normal(0,1,(n,n)).astype('float32');coarse=np.array(Image.fromarray(rng.normal(0,1,(190,190)).astype('float32'),'F').resize((n,n),Image.Resampling.BICUBIC));height=coarse*.22+noise*.12;dy,dx=np.gradient(height);normal=np.stack([-dx,-dy,np.ones_like(dx)],2);normal/=np.linalg.norm(normal,axis=2,keepdims=True);rgb=np.clip(np.array(args['color'])[None,None,:]+(coarse[:,:,None]*4+noise[:,:,None]),0,255).astype('uint8');orm=np.zeros_like(rgb);orm[:]=[255,230,0]
  for slot,a in[('baseColorTexture',rgb),('normalTexture',np.clip((normal+1)*127.5,0,255).astype('uint8')),('metallicRoughnessTexture',orm)]:Image.fromarray(a).save(out/ma[slot],optimize=True)
  ma['normalScale']=.55;ma['extras']['intrinsic_fleece_microstructure_photo_interpreted']=True
 return out,ma
E.material=material
specs=[]
def add(pid,name,dims,geo,official,materials,label,evidence,locale='tr_tr',market='Türkiye',estimated=None):
 specs.append(dict(sku=pid,name=name,dims=dims,hwd=[dims[1],dims[0],dims[2]],official=official,estimated=estimated or[],geometry=geo,size_url='https://www2.hm.com/'+locale+'/productpage.'+pid+'.html',market=market,label=label,color=name,claim='Exact ownSKU'+pid+' official facts:'+json.dumps(official,ensure_ascii=False)+'. Every unpublished axis explicitly listed as approximate.',evidence_files=[str(R/evidence)],note='Kendi özgün fotoğrafındaki sepet biçimi, gerçek iç boşluk, fiziksel kulaklar ve dikiş parçaları modellendi. Yayımlanmamış ayrıntılar, boy alanının kulak/kulpa dağıtımı ve belirtilen eksenler yaklaşık fotoğraf yorumudur.',materials=materials))
black=dict(color=[28,27,23],rough=.85,kind='cotton');lining=dict(color=[226,217,194],rough=.85,kind='cotton')
for pid,cream in[('1351017001',False),('1351017002',True)]:add(pid,('Krem'if cream else'Bej')+' tüylü ayı biçimli açık sepet',[15,13,15],lambda pid=pid:plush_bear(pid),{'diameter_cm':[15],'height_cm':[13]},{'fur':dict(color=[237,229,211]if cream else[213,198,175],rough=.90,kind='cotton'),'lining':lining,'black':black},'Polyester %70 · Diğer elyaf %30 · Pamuk ayrıntı','research-16.txt'if cream else'research-15.txt','en_ie'if cream else'tr_tr','Ireland'if cream else'Türkiye',estimated=['ear_height_allocation','local_pile_and_embroidery_dimensions'])
for pid,cream in[('1358916001',False),('1358916002',True)]:add(pid,('Açık bej'if cream else'Doğal kahverengi')+' örgü ayı figürlü sepet',[25,24,25],lambda pid=pid:wicker_bear(pid),{}if cream else{'width_cm':[25],'height_cm':[24]},{'fiber':dict(color=[221,204,167]if cream else[169,130,82],rough=.75,kind='wood'),'black':black},'Su çayırı %100','research-19.txt','sr_rs'if cream else'tr_tr','Serbia'if cream else'Türkiye',estimated=['width_cm','height_cm','depth_cm']if cream else['depth_cm','ear_height_allocation'])
add('1184879001','Kahverengi kapaklı yapraklı meşe palamudu kutu',[20.6,20.6,20.6],acorn,{}, {'fiber':dict(color=[223,214,177],rough=.75,kind='wood'),'brown':dict(color=[163,127,82],rough=.72,kind='wood'),'leaf':dict(color=[156,159,138],rough=.8,kind='wood')},'Su çayırı gövde · Jüt alt kısım','research-19.txt','en_us','United States',estimated=['width_cm','height_cm','depth_cm'])
add('1300617001','Tek örgü askılı duvar tipi su çayırı sepet',[20,20,20],wall_basket,{'diameter_cm':[20],'height_cm':[20]},{'fiber':dict(color=[172,133,78],rough=.74,kind='wood')},'Su çayırı %100','research-18.txt','en_us','United States',estimated=['local_handle_height_allocation'])
add('1234536001','İki açık cepli tüylü duvar düzenleyici',[46,30,6],wall_organizer,{'body_height_cm':[25],'body_width_cm':[46],'unfolded_tie_length_cm':[14]},{'fur':dict(color=[220,208,187],rough=.90,kind='cotton'),'ties':dict(color=[216,205,184],rough=.85,kind='cotton')},'Polyester gövde · Pamuk askı','research-18.txt','en_in','India',estimated=['height_cm','depth_cm','tied_pose'])
for s in specs:
 if 'fur'in s['materials']:
  s['metadata_extras']={'material_pattern_provenance':str(R/(s['sku']+'-fur-own-fibre-provenance.json'))};s['evidence_files'] +=[str(R/(s['sku']+'-fur-own-fibre-provenance.json')),str(R/(s['sku']+'-fur-native-own-fibre-crop.png'))]
 if 'fiber'in s['materials']:
  s['metadata_extras']={'material_pattern_provenance':str(R/(s['sku']+'-fiber-own-fibre-provenance.json'))};s['evidence_files'] +=[str(R/(s['sku']+'-fiber-own-fibre-provenance.json')),str(R/(s['sku']+'-fiber-native-own-fibre-crop.png'))]
 if s['sku']=='1358916002':s.update(official={'width_cm':[25],'height_cm':[24]},estimated=['depth_cm','ear_height_allocation'],size_url='https://www2.hm.com/tr_tr/productpage.1358916002.html',market='Türkiye',claim='Exact ownSKU1358916002normal official TR PDP publishes height24cmandwidth25cm. Depth and local ear-height allocation are photo-interpreted.',evidence_files=[str(R/'research-19.txt'),str(R/'source-evidence/1358916002.json')])
if __name__=='__main__':
 for s in specs:
  if len(sys.argv)==1 or s['sku']in sys.argv[1:]:E.build(s)
