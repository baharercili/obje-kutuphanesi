import json,collections,hashlib
from pathlib import Path
D=Path(__file__).resolve().parent;S=D.parents[3]/'sites/zarahome-vazo-kutuphanesi-final-378';base=json.loads((D/'frozen-active72-99-production-review-manifest.json').read_text());skus={x['sku']for x in base};cat=json.loads((S/'ui/hmhome-catalog.json').read_text());ready=[x for x in cat if x['sku']in skus];print('BASE',len(base),len(skus),'CANONICAL',len(ready),len({x['sku']for x in ready}),'MISSING',sorted(skus-{x['sku']for x in ready}));print('CATSHA',hashlib.sha256((S/'ui/hmhome-catalog.json').read_bytes()).hexdigest())
print('READYFIELDS',ready[0].keys());print('SOURCEQUEUE',json.loads((D/'source-queue-72.json').read_text()).keys())
for p in sorted(D.glob('*decision.json')):
 o=json.loads(p.read_text());print('DECISION',p.name,json.dumps(o,ensure_ascii=False)[:1700])
print('ACTUALFILES')
for p in D.glob('**/four-angles.json'):print(p.relative_to(D))
