"""Eight remaining structured laundry/storage SKUs; separate supplied wall bracket."""
import sys,math,json
sys.dont_write_bytecode=True
import numpy as np
from PIL import Image,ImageFilter
import build_first12 as P
import build_woven8 as W
import build_cloth7 as C
import source_fibre_material as F
E=P.E;R=E.R;B=E.B;T=math.tau

def contour(w,d,roundness=.025,n=192):
 p=np.array(P.rounded_rect(w,d,min(roundness,min(w,d)*.25),36));p=np.r_[p,p[:1]];s=np.r_[0,np.linalg.norm(np.diff(p,axis=0),axis=1).cumsum()];u=np.linspace(0,s[-1],n,endpoint=False);return np.c_[np.interp(u,s,p[:,0]),np.interp(u,s,p[:,1])]

def woven_shell(name,w,d,h,pitch=.005,roundness=.025,radiusfn=None):
 rows=max(10,int((h-.008)/pitch));pitch=(h-.008)/rows;rope=pitch*.45;warp=max(36,int((w+d)*40));n=192;parts=[];basepoly=contour(w,d,roundness,n)
 def at(u,y):
  if radiusfn is not None:
   a=T*u;r=radiusfn(y);return np.array([r*math.cos(a),r*math.sin(a)]),np.array([math.cos(a),math.sin(a)])
  poly=basepoly;idx=(u*n)%n;i=int(idx);f=idx-i;p=poly[i]*(1-f)+poly[(i+1)%n]*f;t=poly[(i+2)%n]-poly[(i-1)%n];normal=np.array([t[1],-t[0]]);normal/=np.linalg.norm(normal);scale=.91+.09*min(1,y/.05);return p*scale,normal
 for j in range(rows+1):
  y=.006+j*pitch;pts=[]
  for u in np.linspace(0,1,n,endpoint=False):p,normal=at(u,y);p+=normal*rope*.65*((-1)**j)*math.cos(T*u*warp/2);pts.append((p[0],y,p[1]))
  parts.append(W.tube(name+'-actual-woven-horizontal-course-'+str(j),'fiber',pts,rope,pitch*.51,True,sides=8))
 for k in range(warp):
  pts=[]
  for y in np.linspace(.004,h+.002,rows*2+1):p,normal=at(k/warp,y);p-=normal*rope*.65*((-1)**k)*math.cos(math.pi*(y-.006)/pitch);pts.append((p[0],y,p[1]))
  parts.append(W.tube(name+'-actual-alternating-upright-stake-'+str(k),'fiber',pts,rope*.45,rope*.45,False,sides=6))
 wall=W.merge(name+'-actual-interlaced-hollow-wall','fiber',parts);upper=[at(u,h)[0]for u in np.linspace(0,1,256,endpoint=False)];rim=W.tube(name+'-separate-thick-bound-open-mouth','fiber',[(x,h+.002,z)for x,z in upper],rope*1.3,rope,True,sides=8)
 if radiusfn is None:floor=P.extruded(name+'-closed-flat-woven-support-floor','fiber',P.rounded_rect(w*.91,d*.91,roundness*.91,32),[],0,.004)
 else:floor=W.spiral(name+'-actual-closed-coiled-woven-floor','fiber',radiusfn(.004),.003,.0042)
 return[wall,rim,floor],rows+1,warp

def rect_lid(w,d,h,pitch=.005):
 # Independent, actually interlaced removable cover, default closed.
 parts=[];nx=int(w/pitch);nz=int(d/pitch)
 for j,z in enumerate(np.linspace(-d/2,d/2,nz)):
  pts=[(x,h+.009+.0015*((-1)**j)*math.cos(math.pi*(x+w/2)/pitch),z)for x in np.linspace(-w/2,w/2,nx*2+1)];parts.append(W.tube('own-lid-horizontal-woven-strand-'+str(j),'fiber',pts,pitch*.46,pitch*.35,False,sides=6))
 for j,x in enumerate(np.linspace(-w/2,w/2,nx)):
  pts=[(x,h+.009-.0015*((-1)**j)*math.cos(math.pi*(z+d/2)/pitch),z)for z in np.linspace(-d/2,d/2,nz*2+1)];parts.append(W.tube('own-lid-crosswise-woven-strand-'+str(j),'fiber',pts,pitch*.36,pitch*.35,False,sides=6))
 edge=W.tube('own-separate-lid-rounded-bound-edge','fiber',[(x,h+.006,z)for x,z in contour(w,d,.018,256)],.004,.005,True,[0,1,0],8);parts.append(edge);return[W.merge('own-separate-removable-closed-woven-lid','fiber',parts)]

def dense_rect_shell(w,d,h,pitch=.0032):
 turns=(h-.008)/pitch;pts=[]
 for y in np.linspace(.004,h-.004,math.ceil(turns*160)+1):
  phase=((y-.004)/pitch)%1;poly=contour(w,d,.030,256);idx=phase*256;i=int(idx)%256;f=idx-int(idx);p=poly[i]*(1-f)+poly[(i+1)%256]*f;p*=.94+.06*min(1,y/.04);pts.append((p[0],y,p[1]))
 parts=[B.tube('own-dense-continuous-white-bound-fibre-coil-rectangular-wall-no-wicker-stakes','fiber',pts,pitch*.75,pitch*.515,8,False,'radial',uv_scale=.12),P.extruded('own-closed-white-fibre-bound-support-floor','fiber',P.rounded_rect(w*.94,d*.94,.028,32),[],0,.004),W.tube('own-thick-white-bound-open-mouth','fiber',[(x,h-.0015,z)for x,z in contour(w,d,.030,256)],pitch*.75,pitch*.515,True,[0,1,0],8)]
 return parts,turns,0

def dense_rect_lid(w,d,h,pitch=.0032):
 parts=[]
 for j in range(int((d-.015)/(2*pitch))):
  ww=w-2*j*pitch;dd=d-2*j*pitch;rad=min(.030,dd*.3);pts=[(x,h+.007,z)for x,z in contour(ww,dd,rad,192)];parts.append(W.tube('own-lid-closed-rectangular-spiral-bundle-course-'+str(j),'fiber',pts,pitch*.53,pitch*.44,True,[0,1,0],8))
 parts.append(P.extruded('own-lid-dense-closed-white-fibre-core','fiber',P.rounded_rect(w-d+.015,.018,.005,24),[],h+.004,h+.009));return[W.merge('own-separate-dense-white-fibre-bound-cover','fiber',parts)]

def rectangular_laundry(pid,kind):
 w=.46 if pid!='1199494001'else .45;d=.31 if pid!='1260969001'else .32;d=.34 if pid=='1199494001'else d;h={'1228139001':.568,'1260969001':.59,'1299250001':.58,'1199494001':.38}[pid];coarse=pid=='1260969001';pitch=.012 if coarse else .0052;parts,rows,warp=dense_rect_shell(w,d,h)if pid=='1299250001'else woven_shell('own-'+pid,w,d,h,pitch,.028);parts+=dense_rect_lid(w+.008,d+.008,h)if pid=='1299250001'else rect_lid(w+.008,d+.008,h,pitch)
 if pid in['1228139001','1260969001']:
  lining=C.rect_shell('own-removable-cotton-laundry-liner', 'cotton',w-.015,d-.015,h-.008,.008)
  for piece in lining:
   piece['_vertices']=[(x*(.91+.09*min(1,y/.05)),y+.005,z*(.91+.09*min(1,y/.05)))for x,y,z in piece['_vertices']]
  parts+=lining;band=P.extruded('own-real-folded-white-cotton-liner-over-upper-rim','cotton',P.rounded_rect(w+.009,d+.009,.027,32),[P.rounded_rect(w-.012,d-.012,.020,32)],h-.055,h+.004);band['_uvs']=[((math.atan2(z,x)/T+.5)*4,y/.08)for x,y,z in band['_vertices']];
  if pid=='1228139001':parts.append(band)
 if pid=='1228139001':
  divider=C.panel('actual-cotton-two-compartment-divider','cotton',d-.022,h-.030,0,(h-.030)/2+.008,.0025,.004);divider['_vertices']=[(z,y,x)for x,y,z in divider['_vertices']];parts.append(divider)
 # Closure hardware belongs to this source SKU, never a generic knob.
 if pid=='1299250001':
  for side in[-1,1]:pts=[(.045*math.cos(a),h-.075,side*(d/2+.002)+.014*math.sin(a))for a in np.linspace(0,T,160,endpoint=False)];parts.append(W.tube('own-brown-flat-loop-side-carry-handle-'+str(side),'leather',pts,.009,.0013,True,[0,1,0],8))
 else:
  pts=[(.014*math.sin(a),h-.015+.030*math.cos(a),d/2+.008)for a in np.linspace(0,T,128,endpoint=False)];parts.append(W.tube('own-woven-front-lid-fastening-loop','fiber',pts,.002,.002,True,[0,0,1],8));parts.append(P.sphere('own-woven-front-loop-button','fiber',.008,h-.029,0,d/2+.006))
 return parts,['Own exact-SKUrounded rectangular laundry/storage silhouette with actual woven open walls and a closed support floor','Separately movable actually woven lid, thick mouth binding and source-specific fastening/handles','Cotton lining and genuine two compartments included only on their actual source designs','Official outer metrics retained. Local course count, thread diameters, lid/lining allocation and unlabelled fastener dimensions are source-photo interpretations'],dict(actual_horizontal_weft_courses=rows,actual_upright_warp_strands=warp,lid_default_state='closed',actual_cotton_compartments=2 if pid=='1228139001'else 1 if pid=='1260969001'else 0)

def conical_basket(big=False):
 h=.545 if big else .392;r=.210 if big else .190;neck=.175 if big else .170;top=.745 if big else .555
 def rad(y):
  t=y/h;return r*(.79+.21*math.sin(math.pi*min(1,t)*.90))*(1-.13*max(0,(t-.72)/.28))
 parts,rows,warp=woven_shell('own-pear-shaped-plaited-storage-basket',r*2,r*2,h,.006 if big else.0055,radiusfn=rad);lip=rad(h);parts.append(W.spiral('own-separate-actually-coiled-conical-lid','fiber',lip+.005,h+.008,.0055,top-h-.008));parts.append(W.tube('own-cone-lid-bound-circular-lower-edge','fiber',[(lip*math.cos(a),h+.006,lip*math.sin(a))for a in np.linspace(0,T,256,endpoint=False)],.004,.005,True))
 knob=E.lathe('own-woven-elongated-lid-finial','fiber',[(0,top-.004),(.009,top-.004),(.014,top+.007),(.015,top+.026),(.011,top+.039),(0,top+.043)],128);parts.append(knob)
 for side in[-1,1]:
  ry=.009 if big else .070;pts=[(side*(lip+(.022 if big else .006)+(.030 if big else .025)*math.cos(a)),h+(-.005 if big else .020)+ry*math.sin(a),0)for a in np.linspace(0,T,128,endpoint=False)];parts.append(W.tube('own-braided-side-grab-loop-'+str(side),'fiber',pts,.0045,.0045,True,[0,0,1],8))
 return parts,['Own wide softly pear-shaped woven body, narrower mouth and independently coiled steep conical cover','Real hollow body/coiled closed floor, actual cone-lid spiral, tall woven finial and two source-specific grab loops','Published complete height and maximum diameter envelope retained; neck/body/lid allocation and course microstructure interpreted from own exact source photographs'],dict(actual_horizontal_weft_courses=rows,actual_upright_warp_strands=warp,lid_default_state='closed',source_profile='pear_body_with_conical_lid')

def rattan_laundry():
 w=.42;d=.33;h=.65;parts=[]
 for j in range(56):
  a=T*j/56;x=w/2*math.cos(a);z=d/2*math.sin(a);parts.append(W.tube('own-independent-flat-vertical-rattan-cane-slat-'+str(j+1),'rattan',[(x,.008,z),(x,h,z)],.0038,.0016,False,[math.cos(a),0,math.sin(a)],8))
 for j,y in enumerate([.010,.210,.435,.648]):parts.append(W.tube('own-horizontal-bound-rattan-frame-ring-'+str(j+1),'rattan',[(w/2*math.cos(a),y,d/2*math.sin(a))for a in np.linspace(0,T,320,endpoint=False)],.004,.0035,True,[0,1,0],10))
 g=E.lathe('own-open-cotton-laundry-liner-with-real-closed-floor','cotton',[(0,.005),(.95,.005),(.98,.012),(.98,h),(.97,h),(.97,.015),(0,.015)],320);g['_vertices']=[(x*w/2,y,z*d/2)for x,y,z in g['_vertices']];parts.append(g)
 fold=E.lathe('own-real-folded-cotton-upper-liner-band','cotton',[(.96,h-.030),(1.01,h-.030),(1.015,h+.002),(1.00,h+.009),(.96,h+.008)],320);fold['_vertices']=[(x*w/2,y,z*d/2)for x,y,z in fold['_vertices']];parts.append(fold)
 for side in[-1,1]:parts.append(W.tube('own-rattan-loop-carry-handle-'+str(side),'rattan',[(side*.204,.655+.034*(1+math.cos(a)),.017*math.sin(a))for a in np.linspace(0,T,128,endpoint=False)],.0035,.0035,True,[1,0,0],10))
 return parts,['Own oval42×33cmlaundry basket with56individually modeled flat vertical rattan slats and genuine spaces between them','Four physical bound horizontal rings, real open removable cotton lining, folded upper fabric band and two separate loop handles','Official42×33×72cmcomplete envelope retained; slat count, slat cross-section and unlabelled lining/handle allocation interpreted from own photo'],dict(actual_vertical_rattan_slats=56,actual_horizontal_frame_rings=4,real_inter_slat_spaces=True)

def laundry_bag():
 parts=[];w=.45;d=.30;h=.595
 for side in[-1,1]:
  outer=P.rounded_rect(w,h,.012,24);outer=[(x,y+h/2)for x,y in outer];hole=[(x,y+.565)for x,y in P.rounded_rect(.145,.045,.004,20)];g=P.extruded('own-jute-laundry-front-back-cloth-with-real-handle-cutout-'+str(side),'jute',outer,[hole],-.0013,.0013);g['_vertices']=[(x,y,side*d/2+t)for x,t,y in g['_vertices']];g['_uvs']=[(x/.12+.5,1-y/.12)for x,y,z in g['_vertices']];parts.append(g);rod=B.cylinder('own-smooth-real-wooden-carry-bar-'+str(side),'wood',.0088,-w/2+.008,w/2-.008,n=72);rod['_vertices']=[(y,.591+x,side*d/2+z)for x,y,z in rod['_vertices']];parts.append(rod)
 for side in[-1,1]:g=C.panel('own-jute-laundry-side-panel-'+str(side),'jute',d,h,0,h/2,.0026,.012);g['_vertices']=[(side*w/2+z,y,x)for x,y,z in g['_vertices']];g['_uvs']=[(z/.12+.5,1-y/.12)for x,y,z in g['_vertices']];parts.append(g)
 parts.append(P.extruded('own-closed-rounded-jute-laundry-bag-floor','jute',P.rounded_rect(w,d,.014,24),[],0,.004))
 return parts,['Own45×30×60cmthick jute-blend laundry bag, real open mouth, separate side panels and closed fabric floor','Two genuinely open rounded handle cut-outs and two actual horizontal wooden carry bars integrated into the hems','Own native jute-only gallery crop supplies intrinsic weave at true native crop resolution; no bag silhouette, shadows or bracket photo baked','Separate supplied painted-metal wall bracket is delivered as its own metrically anchored component'],dict(material_pattern_provenance=str(R/'1337081001-jute-provenance.json'),component='laundry_bag',set_pieces=2)

def wall_bracket():
 outer=P.rounded_rect(.115,.013,.003,24);holes=[P.circle(.0028,64,x,0)for x in[-.044,.044]];g=P.extruded('own-painted-steel-wall-backplate-with-two-real-screw-holes','paint',outer,holes,-.001,.001);g['_vertices']=[(x,y+.028,t)for x,t,y in g['_vertices']];parts=[g]
 for x in[-.047,.047]:
  pts=[(x,.028,0),(x,.028,.023)]+[(x,.014+.014*math.cos(a),.023+.014*math.sin(a))for a in np.linspace(0,math.pi/2,48)[1:]]+[(x,.002,.037)];parts.append(W.tube('own-bent-flat-metal-wooden-bar-support-arm-'+str(x),'paint',pts,.0055,.0012,False,[1,0,0],12))
 return parts,['Own supplied cream-painted steel wall bracket, actual rounded backplate and two open screw holes','Two individually bent flat steel arms support the wooden handle; actual bracket dimensions11.5×4.5×3.5cm','Screws are excluded exactly as stated by the official PDP. Local sheet thickness and bend radii follow own closeup'],dict(component='separate_supplied_wall_bracket',set_pieces=2,source_screws_excluded=True)

BASE=E.material
def material(pid,key,**args):
 out,ma=BASE(pid,key,**args)
 if key=='fiber':return F.apply(E,pid,key,out,ma,args)
 if pid=='1337081001'and key=='jute':
  m=next(m for m in E.MASTERS if m['sku']==pid and m['path'].endswith('4c2736cc1a3a.jpg'));im=Image.open(m['path']).convert('RGB');box=(720,960,1320,1610);crop=im.crop(box);native=R/(pid+'-native-jute-crop.png');crop.save(native);a=np.array(crop,float);blur=np.array(crop.filter(ImageFilter.GaussianBlur(25)),float);rgb=np.clip(np.array([224,215,193])+(a-blur)*1.1,0,255).astype('uint8');dy,dx=np.gradient(rgb.mean(2)*.0025);normal=np.stack([-dx,-dy,np.ones_like(dx)],2);normal/=np.linalg.norm(normal,axis=2,keepdims=True);orm=np.zeros_like(rgb);orm[:]=[255,214,0]
  for slot,q in[('baseColorTexture',rgb),('normalTexture',np.clip((normal+1)*127.5,0,255).astype('uint8')),('metallicRoughnessTexture',orm)]:Image.fromarray(q).save(out/ma[slot],optimize=True)
  ma['extras'].update(own_photo_material_crop=True,source_effective_detail_pixels=list(crop.size),native_resolution=list(crop.size),intrinsic_illumination_removed=True);E.dump(R/(pid+'-jute-provenance.json'),dict(master=m['path'],master_sha256=m['sha256'],master_unchanged=E.sha(m['path'])==m['sha256'],native_crop_box_pixels=box,native_crop_path=str(native),crop_pixel_identity=True,material_native_pixels=list(crop.size),upscaled=False,method='Exact native fabric-only crop, away from slot, wood, metal, silhouette and background. Subtract25pxlow-frequencyphotographicillumination, preserve own weave at native pixels against intrinsic pale jute palette. No reflections or object photo projection.'))
 return out,ma
E.material=material
specs=[]
def add(pid,name,dims,geo,official,materials,label,evidence,locale='tr_tr',market='Türkiye',estimated=None,suffix=''):
 specs.append(dict(sku=pid,name=name,dims=dims,hwd=[dims[1],dims[0],dims[2]],official=official,estimated=estimated or[],geometry=geo,size_url='https://www2.hm.com/'+locale+'/productpage.'+pid+'.html',market=market,label=label,color=name,claim='Exact ownSKU'+pid+' official dimensions:'+json.dumps(official,ensure_ascii=False)+'. Own immutable photo and gallery reference preserved.',evidence_files=[str(R/evidence)],note='Kendi SKU biçimi, gerçek örgü/astar/iç boşluk ve ayrı kapak/bağlantı parçaları kurulmuştur. Yayımlanmamış yerel cidar, örgü sıklığı, kapak ve gövde yükseklik dağılımı kendi fotoğrafından yorumdur.',materials=materials,suffix=suffix))
cotton=dict(color=[236,228,207],rough=.85,kind='cotton');natural=dict(color=[178,140,91],rough=.73,kind='wood')
for pid,dims,label,evidence,locale,market in[('1228139001',[46,60,31],'Su çayırı · Pamuk astar · Demir çerçeve','research-11.txt','en_ie','Ireland'),('1260969001',[46,61,32],'Su sümbülü · Pamuk astar · Demir çerçeve','research-11.txt','en_in','India'),('1299250001',[46,60,31],'Su çayırı · Demir bağ','research-12.txt','en_us','United States'),('1199494001',[45,40,34],'Su çayırı %100','source-evidence/1199494001.json','tr_tr','Türkiye')]:
 mats={'fiber':dict(color=[223,216,190],rough=.76,kind='wood')if pid=='1299250001'else natural}
 if pid in['1228139001','1260969001']:mats['cotton']=cotton
 if pid=='1299250001':mats['leather']=dict(color=[110,61,38],rough=.63)
 add(pid,{'1228139001':'İki bölmeli pamuk astarlı dikdörtgen su çayırı çamaşır sepeti','1260969001':'İri hasır örgülü kapaklı çamaşır sepeti','1299250001':'Beyaz örgülü kahverengi saplı dikdörtgen çamaşır sepeti','1199494001':'Kapaklı dikdörtgen doğal su çayırı saklama sepeti'}[pid],dims,lambda pid=pid:rectangular_laundry(pid,pid),{'width_cm':[dims[0]],'height_cm':[dims[1]],'depth_cm':[dims[2]]},mats,label,evidence,locale,market,estimated=['local_lid_lining_and_fastener_dimensions'])
for pid,big,dims in[('1042178004',False,[38,60,38]),('1189203001',True,[42,79.5,42])]:add(pid,('Büyük'if big else'Küçük')+' konik kapaklı armut biçimli örgü sepet',dims,lambda big=big:conical_basket(big),{'complete_height_cm':[dims[1]],'maximum_diameter_cm':[dims[0]],**({'published_diameter_range_cm':[35,42]}if big else{})},{'fiber':dict(color=[204,192,158],rough=.75,kind='wood')},'Plastik dış · Hasır iç · Jüt sap'if big else'Polipropilen dış %100 · Hasır iç %100','research-13.txt','en_ie'if big else'en_in','Ireland'if big else'India',estimated=['local_neck_lid_and_body_height_allocation'])
add('1368407001','Dikey açık rattan çıtalı pamuk astarlı çamaşır sepeti',[42,72,33],rattan_laundry,{'width_cm':[42],'height_cm':[72],'depth_cm':[33]},{'rattan':dict(color=[190,150,103],rough=.55,kind='wood'),'cotton':cotton},'Rattan çerçeve · Pamuk astar','research-13.txt','pl_pl','Poland',estimated=['local_handle_liner_and_slat_dimensions'])
add('1337081001','Ahşap saplı asılabilir jüt karışımlı çamaşır torbası',[45,60,30],laundry_bag,{'bag_width_cm':[45],'bag_height_cm':[60],'bag_depth_cm':[30]},{'jute':dict(color=[224,215,193],rough=.84,kind='cotton'),'wood':dict(color=[159,117,72],rough=.43,kind='wood')},'Jüt %50 · Polyester %50 · Ahşap sap','source-evidence/1337081001.json',estimated=['local_handle_cutout_dimensions'],suffix='-bag')
add('1337081001','Jüt çamaşır torbası · Ayrı metal duvar askısı',[11.5,3.5,4.5],wall_bracket,{'bracket_width_cm':[11.5],'bracket_height_cm':[3.5],'bracket_depth_cm':[4.5]},{'paint':dict(color=[223,214,190],rough=.37)},'Boyalı metal','source-evidence/1337081001.json',estimated=['local_screw_hole_and_sheet_thickness'],suffix='-bracket')
for s in specs:
 if 'fiber'in s['materials']:
  s['metadata_extras']={'material_pattern_provenance':str(R/(s['sku']+'-fiber-own-fibre-provenance.json'))};s['evidence_files'] +=[str(R/(s['sku']+'-fiber-own-fibre-provenance.json')),str(R/(s['sku']+'-fiber-native-own-fibre-crop.png'))]
 if s['sku']=='1337081001'and s['suffix']=='-bag':s['evidence_files']+=[str(R/'1337081001-jute-provenance.json'),str(R/'1337081001-native-jute-crop.png')]
 if s['sku']=='1199494001':s['anomalies']=['Official India indexed structured fields previously disagreed with its description. Exact TRnormalPDPdescription45width×34depth×40height is the selected declared anchor; no conflict silently resolved.'];s['evidence_files'].append(str(R/'research-13.txt'))
if __name__=='__main__':
 for s in specs:
  if len(sys.argv)==1 or s['sku']in sys.argv[1:]:E.build(s)
