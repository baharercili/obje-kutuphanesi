import sys,json,shutil,hashlib
from pathlib import Path
sys.dont_write_bytecode=True
import engine as E
R=E.R;old=next(e for e in json.loads((R/'frozen-batch05-form6-manifest.json').read_text())if e['sku']=='1354951003');id=old['id']+'-olive09';out=R/'models'/id;out.mkdir(exist_ok=False);model=json.loads(Path(old['model_path']).read_text());doc,bin=E.G.read_glb(old['glb_path']);before=json.loads(json.dumps(doc));ma=doc['materials'][0];ma.update(alphaMode='OPAQUE');ma['pbrMetallicRoughness']['baseColorFactor']=[.35,.30,.015,1];ma['extensions'].update(KHR_materials_transmission={'transmissionFactor':.98},KHR_materials_volume={'thicknessFactor':.008,'attenuationColor':[.26,.40,.018],'attenuationDistance':.0045});model['materials']['green'].update(baseColorFactor=[.35,.30,.015,1],alphaMode='OPAQUE',transmission=.98,thickness=.008,attenuationColor=[.26,.40,.018],attenuationDistance=.0045);note='Koyu zeytin cam rengi kendi fotoğrafına göre iç renk ve hacim emilimiyle yorumlandı. Optik sabitler yaklaşık; üretici ölçümü değildir. Yuvarlak dal geometrisi ve tüm gömülü haritalar aynı kaldı.';meta=model['metadata'];meta.update(id=id,replaces_model_id=old['id'],previous_glb_sha256=old['sha256'],optical_revision='source-dark-olive09',quality_note=note);doc['extras']['metadata']=meta
for m in model['materials'].values():
 for slot in ['baseColorTexture','normalTexture','metallicRoughnessTexture']:shutil.copyfile(Path(old['asset_dir'])/m[slot],out/m[slot])
E.dump(out/'model.json',model);path=out/(id+'.glb');E.G.write_glb(path,doc,bin);nd,nb=E.G.read_glb(path);assert nb==bin
for k in ['meshes','accessors','bufferViews','images','textures','samplers']:assert nd[k]==before[k]
for file in ['geometry-validation.json','material-validation.json']:
 q=json.loads((Path(old['asset_dir'])/file).read_text())
 if file=='material-validation.json':
  for m in q['maps']:m['path']=str(out/Path(m['path']).name);assert E.sha(m['path'])==m['sha256']
 E.dump(out/file,q)
e=dict(old,id=id,asset_dir=str(out),model_path=str(out/'model.json'),glb_path=str(path),sha256=E.sha(path),bytes=path.stat().st_size,geometry_validation=str(out/'geometry-validation.json'),material_validation=str(out/'material-validation.json'),replaces_model_id=old['id'],previous_glb_sha256=old['sha256'],quality_note=note,model_status='pending_root_actual_three',frozen=False)
for k in ['native_renders','scn_path','source_comparison_path','independent_validation_file','visual_validation_file']:e.pop(k,None)
E.dump(out/'entry.json',e);manifest=json.loads((R/'manifest.json').read_text());E.dump(R/'manifest.json',manifest+[e]);E.dump(R/'tree-olive09-candidate.json',[e]);E.dump(R/'tree-olive09-identity-proof.json',dict(id=id,previous_sha256=old['sha256'],sha256=e['sha256'],entire_bin_unchanged=True,bin_sha256=hashlib.sha256(bin).hexdigest(),all_geometry_and_embedded_maps_identical=True));print(E.sha(R/'tree-olive09-candidate.json'))
