from pathlib import Path
import json, hashlib, copy
P=Path(__file__).resolve().parent
def read(p): return json.loads(Path(p).read_text())
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,x): Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
specs=[
 ('towels-patterned/root-pending32-review-manifest.json','72a144009f824c772580ea4c8ad6dab88055197b9c0a21fcadb2ac2625d3653c','towels-patterned/all-pending32-review/browser-review/dom-checks-current.json','towels-patterned/root-pending32-actual-review-decision.json'),
 ('textiles/all186-final-handoff/frozen-all186-active-textiles-manifest.json','78f1ff5c0757b3d9406c7bab560f918aac492c093333686c7e743999c10095b5','textiles/all-pending31-final-review/browser-review/dom-checks-current.json','textiles/root-pending31-actual-review-decision.json'),
 ('decor-storage/root-pending38-review-manifest.json','4fc7087e3158eb56ac7977967802c649714111cbd0cc35bbdf7a1e9d26210939','decor-storage/all-pending38-review/browser-review/dom-checks-current.json','decor-storage/root-pending38-actual-review-decision.json'),
 ('softgoods/organic-throws-revision-04/manifest.json','cf1e38d32b18baae5437c3d422e9c11df25775969da7d9e0c7f27b8def55bc63','softgoods/organic-throws-v4-review/browser-review/dom-checks-current.json',None),
 ('softgoods/special-softgoods-revision-03/manifest.json','7f97100661fe214a4fa6fab04996bdfa0964daa3fa28eef7d12fa28bc4110187','softgoods/fur-r3-review/browser-review/dom-checks-current.json',None),
]
approvals=read(P/'browser-approvals.json'); rows=[];sources=[]
for manifest,pinned,evidence,decision in specs:
 assert sha(P/manifest)==pinned,(manifest,'frozen manifest changed')
 checks={x['selected']:x for x in read(P/evidence)}
 allowed=set(read(P/decision)['approved_model_ids']) if decision else None
 selected=[]
 for raw in read(P/manifest):
  if allowed is not None and raw['id'] not in allowed: continue
  e=copy.deepcopy(raw); b=checks[e['id']]
  assert not b['error'] and e['sha256'] in b['download'],e['id']
  assert (P/evidence).parent.joinpath(e['id']+'.png').exists()
  e['quality_pending']=False
  note='Root viewed actual Three model beside its own original. Official measurements and all stated photo-estimated shape/pose/material limits retained.'
  extra={}
  if e['sku']=='1349831001':
   extra={'four_angle_evidence':str(P/'decor-storage/embroidered-stocking-four-view/browser-review/four-angle-proof.json'),'native_metal_success_claimed':False}
   note+=' Native Metal render did not finish; exact final GLB independently passed geometry checks and root viewed front, both sides and back in the real Three viewer.'
  approvals['models'][e['id']]=dict(approved=True,sha256=e['sha256'],sku=e['sku'],browser_evidence=b,evidence_file=str(P/evidence),notes=note,**extra)
  rows.append(e); selected.append(e['id'])
 if allowed is not None: assert set(selected)==allowed
 sources.append(dict(manifest=str(P/manifest),sha256=pinned,selected_ids=selected,decision_file=str(P/decision) if decision else None))
assert len(rows)==95 and len({x['id']for x in rows})==95 and len({x['sku']for x in rows})==79,(len(rows),len({x['sku']for x in rows}))
target=P/'root-reviewed-batch-09-manifest.json'; assert not target.exists()
dump(target,rows);dump(P/'browser-approvals.json',approvals)
dump(P/'root-reviewed-batch-09-review-record.json',dict(models=len(rows),source_products=79,manifest_sha256=sha(target),sources=sources,entire_736_complete=False,reviewer='root actual source comparison; rejected 25 other throws, 11 other textiles and 14 other decoration products remain pending'))
print(sha(target),len(rows),79)
