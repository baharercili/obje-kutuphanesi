from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,re
P=Path(__file__).resolve().parent;ROOT=P.parents[2];S=ROOT/'sites/zarahome-vazo-kutuphanesi-final-378'
def read(p):return json.loads(p.read_text())
def write(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
def rows(d):return d if isinstance(d,list)else d['models']
catalog=read(S/'ui/hmhome-catalog.json');by={}
for e in catalog:by.setdefault(e['sku'],[]).append(e)
ledger=read(P/'production-ledger.json');originals={}
for folder in ['root','curtains','softgoods','hardgoods']:
 for e in read(P/folder/'original-image-masters.json'):
  f=Path(e['path'])
  if f.is_file()and hashlib.sha256(f.read_bytes()).hexdigest()==e['sha256']:originals.setdefault(e['sku'],[]).append(e)
anchors=read(P/'official-grid-size-anchors-all.json')['products'];candidates={}
def has_official_cm(record):
 return any('cm'in key and value is not None for key,value in record.get('official_measurements',{}).items())
for f in read(P/'review-inputs.json'):
 for e in rows(read(Path(f))):candidates.setdefault(e['sku'],[]).append(e)
for e in ledger['products']:
 sku=e['sku'];ready=by.get(sku,[]);candidate=candidates.get(sku,[])
 e['ready']=bool(ready);e['source_photos_preserved']=sku in originals
 e['official_dimensions_verified']=bool(sku in anchors or ready and any(has_official_cm(x)for x in ready))
 e['source_photo_count']=len(originals.get(sku,[]))
 e['model_ids']=[x['id']for x in ready]
 e['stage']='ready_verified_locally'if ready else 'candidate_under_quality_review'if candidate else 'research_or_model_production_pending'
 for field in ['geometry_reviewed','material_reviewed','browser_reviewed','download_verified']:e[field]=bool(ready)
 if candidate and not ready:e['quality_note']='Candidate assets do not count ready. Cloth poses and source-specific materials require final visual approval.'
 if ready:e.pop('quality_note',None)
done=sum(e['ready']for e in ledger['products']);ready_products=len(by)
ledger.update(updated_at=datetime.now(timezone.utc).isoformat(),ready_from_initial_736=done,pending_from_initial_736=736-done,ready_products_total=ready_products,ready_glb_variants_total=len(catalog),all_736_complete=done==736,source_originals_preserved_products=sum(e['source_photos_preserved']for e in ledger['products']))
write(P/'production-ledger.json',ledger)
work=ROOT/'work/zarahome-dekor/completeness-repair-2026-10-21/user-work-sequence.json';d=read(work);manifest=read(S/'model-manifest.json')
d.update(updated_date='2026-10-24',local_ready_models=len(manifest['models']),current_stage=('The original736 registered H&M products are modeled and verified locally; all registered902 H&M source products have models. Whole live website catalogue coverage is separate.'if done==736 else f'H&M all736 production in progress; {done} newly accepted, {736-done} still pending. No overall completion claim.'))
d['hmhome'].update(ready_model_variants=len(catalog),ready_products=ready_products,pending_source_cards=902-ready_products,production_ledger=str(P/'production-ledger.json'),whole_catalogue_complete=False,model_manifest_sha256=hashlib.sha256((S/'model-manifest.json').read_bytes()).hexdigest())
d['next_actions'][3]='Preserve accepted masters; integrate only individually reviewed frozen batches with work/hmhome-dekor/2026-10-23-production/integrate_reviewed_736.py.'
write(work,d)
print(json.dumps({k:ledger[k]for k in ['ready_from_initial_736','pending_from_initial_736','ready_products_total','ready_glb_variants_total','source_originals_preserved_products','all_736_complete']}))
