"""Reference-specific root production assets. Canonical accepted masters are read-only."""
from pathlib import Path
import sys,json,math,hashlib,shutil,importlib.util
import numpy as np
from PIL import Image,ImageFilter
sys.dont_write_bytecode=True
R=Path(__file__).resolve().parent;OLD=R.parents[1]/'2026-10-23-hardgoods'
sp=importlib.util.spec_from_file_location('root_production_helpers',OLD/'build_hardgoods.py');G=importlib.util.module_from_spec(sp);sp.loader.exec_module(G)
B=G.B;T=math.tau
G.R=R;G.SPECS={}
def dump(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def wood_uv(g,vertical_grain=True):
 # Separate native UV charts for horizontal and vertical boards prevent side-face stretching.
 old=g['_vertices'];vv=[];uv=[];ff=[]
 for tri in g['_faces']:
  a,b,c=[np.array(old[i])for i in tri];axis=int(np.argmax(np.abs(np.cross(b-a,c-a))));inds=[]
  for i in tri:
   x,y,z=old[i];inds.append(len(vv));vv.append((x,y,z))
   if vertical_grain:coord=(z/.15+.5,x/.30+.5)if axis==1 else((y/.15+.5,x/.30+.5)if axis==2 else(y/.15+.5,z/.30+.5))
   else:
    xx,yy=((x/.20,z/.05)if axis==1 else((x/.20,y/.05)if axis==2 else(z/.20,y/.05)));coord=(xx+.5,yy+.5)
   uv.append(coord)
  ff.append(tuple(inds))
 g['_vertices']=vv;g['_faces']=ff;g['_uvs']=uv;return g
def box(name,mat,w,h,d,center):
 # Small true edge bevels: rounded rectangular horizontal cross sections, not a zero-radius cuboid.
 b=min(.00065,w*.12,h*.12,d*.12);cx,cy,cz=center
 profiles=[(G.rounded(w-2*b,d-2*b,b,8),cy-h/2),(G.rounded(w,d,2*b,8),cy-h/2+b),(G.rounded(w,d,2*b,8),cy+h/2-b),(G.rounded(w-2*b,d-2*b,b,8),cy+h/2)]
 g=G.capped(name,mat,profiles,True,uvscale=.12);g['_vertices']=[(x+cx,y,z+cz)for x,y,z in g['_vertices']];return g
def rounded_vessel(name,mat,w,h,d,th,rad,base):
 # Closed material shell, open mouth, finite rounded rim and a separate interior floor.
 profiles=[(w-.0012,d-.0012,rad-.0006,0),(w,d,rad,.0006),(w,d,rad,h-.0006),(w-.0012,d-.0012,rad-.0006,h),(w-2*th+.0012,d-2*th+.0012,max(.0003,rad-th+.0006),h),(w-2*th,d-2*th,max(.0002,rad-th),h-.0006),(w-2*th,d-2*th,max(.0002,rad-th),base+.0006),(w-2*th-.0012,d-2*th-.0012,max(.0002,rad-th-.0006),base)]
 v=[];uv=[];f=[];n=64
 for ww,dd,rr,y in profiles:
  for x,z in G.rounded(ww,dd,max(.0001,rr),16):v.append((x,y,z));uv.append((x/.30+.5,z/.30+.5))
 for k in range(len(profiles)-1):
  for j in range(n):a=k*n+j;b=k*n+(j+1)%n;c=a+n;e=b+n;f.extend([(a,c,b),(b,c,e)])
 for k in[0,len(profiles)-1]:
  ci=len(v);v.append((0,profiles[k][3],0));uv.append((.5,.5))
  for j in range(n):f.append((ci,k*n+j,k*n+(j+1)%n))
 return G.raw(name,mat,v,f,uv)
def tray():
 g=rounded_vessel('arjuna-tray-continuous-real-rim-and-open-flat-floor','wood',.30,.02,.15,.008,.0018,.005)
 # Photograph's long grain follows the30cm axis. Planar UV keeps grain uninterrupted across the tray floor.
 return[wood_uv(g)],['Exact30×15×2cm low rectangular tray; real open recess, finite8mm wood rim and5mm floor','Gently softened actual edges, continuous long wood grain and no shadow/silhouette/marketing props copied into the material'],{'local_rim_thickness_mm_photo_interpreted':8,'local_floor_thickness_mm_photo_interpreted':5}
def organizer():
 w=.20;d=.15;p=[box('continuous-removable-base-board','wood',w,.006,d,(0,.003,0))]
 for s in[-1,1]:
  p.append(box('tall-full-depth-side-'+str(s),'wood',.006,.094,d,(s*.097,.053,0)))
 p.append(box('tall-rear-board','wood',.188,.087,.005,(0,.0495,-.0725)))
 p.append(box('lower-front-board','wood',.188,.054,.005,(0,.033,.0725)))
 # Own photographed layout: large rear bay, removable front insert with six smaller wells (3×2).
 p.append(box('removable-front-insert-rear-divider','wood',.186,.058,.004,(0,.035,.008)))
 p.append(box('removable-front-insert-middle-divider','wood',.184,.032,.0035,(0,.022,.041)))
 for s in[-1,1]:p.append(box('front-six-well-insert-divider-'+str(s),'wood',.0035,.032,.060,(s*.0315,.022,.041)))
 p=[wood_uv(g,False)for g in p]
 return p,['Official20×15×10cm stepped wooden organizer; tall end boards and back, low front','One genuinely open large rear bay plus removable front grid of six smaller wells (three columns/two rows), matching own close-up','Separate physical base, side/rear/front boards and removable divider components; small edges are actually beveled'],{'small_front_compartments':6,'large_rear_compartments':1,'removable_divider_insert':True,'local_board_thickness_mm_photo_interpreted':6}
def felt_panel(name,w,h,d,rad,sign):
 # Annular front/back wall with a true cylindrical carry opening; fully closed four-sided material edge.
 bot=.028;top=h;cy=h-.043;hole=.013 if w<.3 else .016;half=w/2-rad
 angles=sorted(set([float(a)for a in np.linspace(0,T,192,endpoint=False)]+[math.atan2(y-cy,x)%T for x in[-half,half]for y in[bot,top]]));v=[];uv=[];f=[];loops=[]
 for back in[0,1]:
  for inner in[False,True]:
   loop=[]
   for a in angles:
    dx=math.cos(a);dy=math.sin(a);rr=hole if inner else min(half/max(1e-12,abs(dx)),((top-cy)if dy>0 else(cy-bot))/max(1e-12,abs(dy)))
    x=dx*rr;y=cy+dy*rr;t=(y-bot)/(top-bot);fac=.92+.08*t;z=sign*((d/2)*fac-back*.0045)
    loop.append(len(v));v.append((x*fac,y,z));uv.append((x/.10,y/.10))
   loops.append(loop)
 n=len(angles)
 for ia,ib in[(0,1),(2,3),(0,2),(1,3)]:
  for j in range(n):a=loops[ia][j];b=loops[ia][(j+1)%n];c=loops[ib][j];e=loops[ib][(j+1)%n];f.extend([(a,c,b),(b,c,e)])
 return G.raw(name,'felt',v,f,uv)
def felt_corner(name,w,h,d,r,sx,sz):
 n=24;v=[];uv=[];f=[];rings=[]
 for y,inner in[(.028,False),(h,False),(h,True),(.028,True)]:
  t=(y-.028)/(h-.028);fac=.92+.08*t;rr=r*fac-.0045*inner;cx=(w/2-r)*fac;cz=(d/2-r)*fac;ring=[]
  for a in np.linspace(0,math.pi/2,n):ring.append(len(v));v.append((sx*(cx+rr*math.sin(a)),y,sz*(cz+rr*math.cos(a))));uv.append((a*r/.1,y/.1))
  rings.append(ring)
 for k in range(4):
  for j in range(n-1):a=rings[k][j];b=rings[k][j+1];c=rings[(k+1)%4][j];e=rings[(k+1)%4][j+1];f.extend([(a,c,b),(b,c,e)])
 for j in[0,n-1]:a,b,c,e=[r[j]for r in rings];f.extend([(a,b,c),(a,c,e)])
 return G.raw(name,'felt',v,f,uv)
def felt_basket(w,h,d):
 r=.031 if w>.3 else .028;p=[]
 for sz in[-1,1]:p.append(felt_panel('felt-long-wall-with-real-through-hole-'+str(sz),w,h,d,r,sz))
 for sx in[-1,1]:
  for sz in[-1,1]:p.append(felt_corner('felt-rounded-tapered-corner-'+str(sx)+'-'+str(sz),w,h,d,r,sx,sz))
  # End walls between four rounded corners, closed and slightly tapered with height.
  v=[];uv=[]
  for y,inside in[(.028,False),(h,False),(h,True),(.028,True)]:
   fac=.92+.08*(y-.028)/(h-.028);x=sx*(w/2*fac-.0045*inside)
   for z in[-(d/2-r)*fac,(d/2-r)*fac]:v.append((x,y,z));uv.append((z/.1,y/.1))
  f=[(0,2,1),(1,2,3),(4,6,5),(5,6,7),(0,1,7),(0,7,6),(2,4,3),(3,4,5),(0,6,2),(2,6,4),(1,3,7),(3,5,7)]
  p.append(G.raw('felt-short-tapered-wall-'+str(sx),'felt',v,f,uv))
 # Rounded bottom transition is a closed4.5mm-thick curved shell; not a solid inflated floor.
 n=80;v=[];uv=[];f=[];pr=[]
 for inner in[False,True]:
  aa=np.linspace(0,math.pi/2,21)if not inner else np.linspace(math.pi/2,0,21)
  for a in aa:
   rr=.023-.0045*inner;exp=rr*math.sin(a);ww=w*.92-.046+2*exp;dd=d*.92-.046+2*exp;yy=.028-rr*math.cos(a);pr.append((ww,dd,max(.006,r*.92-.023+exp),yy))
 for ww,dd,rr,yy in pr:
  for x,z in G.rounded(ww,dd,rr,20):v.append((x,yy,z));uv.append((x/.10,z/.10))
 for k in range(len(pr)-1):
  for j in range(n):a=k*n+j;b=k*n+(j+1)%n;c=a+n;e=b+n;f.extend([(a,c,b),(b,c,e)])
 # Closed solid bottom joins both ends; remaining edge is internal under the basin floor.
 for k in[0,len(pr)-1]:
  ci=len(v);v.append((0,pr[k][3],0));uv.append((.5,.5))
  for j in range(n):f.append((ci,k*n+j,k*n+(j+1)%n))
 p.append(G.raw('closed-softly-curved-four-and-half-mm-felt-bottom','felt',v,f,uv))
 return p,['Exact official outer dimensions, smoothly rounded lower basin, subtly tapering open felt walls','Two genuine circular through-holes in the long walls, visible physical4.5mm cut felt edges, no lid','Dense nondirectional felt fibres, warm mottled source-specific colour, actual inner cavity and finite curved floor'],{'local_wall_thickness_mm_photo_interpreted':4.5,'through_carry_holes':2}
def felt_basket(w,h,d):
 # A single continuous manifold shell eliminates artificial panel joints and coplanar seams.
 th=.0045;rad=.031 if w>.3 else .028;nx=56;nz=40;nc=12;edge=[]
 for x in np.linspace(-1,1,nx,endpoint=False):edge.append(('front',float(x)))
 for a in np.linspace(0,math.pi/2,nc,endpoint=False):edge.append(('fr',float(a)))
 for z in np.linspace(1,-1,nz,endpoint=False):edge.append(('right',float(z)))
 for a in np.linspace(0,math.pi/2,nc,endpoint=False):edge.append(('br',float(a)))
 for x in np.linspace(1,-1,nx,endpoint=False):edge.append(('back',float(x)))
 for a in np.linspace(0,math.pi/2,nc,endpoint=False):edge.append(('bl',float(a)))
 for z in np.linspace(-1,1,nz,endpoint=False):edge.append(('left',float(z)))
 for a in np.linspace(0,math.pi/2,nc,endpoint=False):edge.append(('fl',float(a)))
 def perimeter(ww,dd,r):
  out=[]
  for label,t in edge:
   if label=='front':x,z=(ww/2-r)*t,dd/2
   elif label=='back':x,z=(ww/2-r)*t,-dd/2
   elif label=='right':x,z=ww/2,(dd/2-r)*t
   elif label=='left':x,z=-ww/2,(dd/2-r)*t
   elif label=='fr':x,z=ww/2-r+r*math.sin(t),dd/2-r+r*math.cos(t)
   elif label=='br':x,z=ww/2-r+r*math.cos(t),-dd/2+r-r*math.sin(t)
   elif label=='bl':x,z=-ww/2+r-r*math.sin(t),-dd/2+r-r*math.cos(t)
   else:x,z=-ww/2+r-r*math.cos(t),dd/2-r+r*math.sin(t)
   out.append((x,z))
  return out
 profiles=[];bottom=.028
 for a in np.linspace(0,math.pi/2,21):
  profiles.append((bottom-bottom*math.cos(a),w*.92-2*bottom+2*bottom*math.sin(a),d*.92-2*bottom+2*bottom*math.sin(a),max(.003,rad*.92-bottom+bottom*math.sin(a)),a))
 for y in np.linspace(bottom,h,81)[1:]:
  fac=.92+.08*(y-bottom)/(h-bottom);profiles.append((float(y),w*fac,d*fac,rad*fac,None))
 n=len(edge);m=len(profiles);v=[];uv=[];f=[]
 for inside in[0,1]:
  for y,ww,dd,r,a in profiles:
   if a is not None and inside:
    y=bottom-(bottom-th)*math.cos(a);ww-=2*th*math.sin(a);dd-=2*th*math.sin(a);r=max(.002,r-th*math.sin(a))
   elif inside:ww-=2*th;dd-=2*th;r-=th
   for j,(x,z)in enumerate(perimeter(ww,dd,r)):
    v.append((x,y,z));uv.append((j/n*(2*w+2*d)/.10,y/.10))
 cy=h-.043;hole=.013 if w<.3 else .016;ya=min(range(m),key=lambda k:abs(profiles[k][0]-(cy-hole*1.35)));yb=min(range(m),key=lambda k:abs(profiles[k][0]-(cy+hole*1.35)))
 front_c=nx//2;back_c=nx+nc+nz+nc+nx//2;halfspan=max(3,int(math.ceil(hole*1.35/((w-2*rad)/nx))))
 windows=[(c-halfspan,c+halfspan,ya,yb,s)for c,s in[(front_c,1),(back_c,-1)]]
 def excluded(j,k):return any(a<=j<b and c<=k<e for a,b,c,e,s in windows)
 for inside in[0,1]:
  off=inside*n*m
  for k in range(m-1):
   for j in range(n):
    if excluded(j,k):continue
    a=off+k*n+j;b=off+k*n+(j+1)%n;c=a+n;e=off+(k+1)*n+(j+1)%n;f.extend([(a,c,b),(b,c,e)])
 # Rounded top edge joins the exterior and interior once; bottom caps give finite floor thickness.
 for j in range(n):a=(m-1)*n+j;b=(m-1)*n+(j+1)%n;c=a+n*m;e=b+n*m;f.extend([(a,b,c),(b,e,c)])
 for inside in[0,1]:
  ci=len(v);v.append((0,0 if not inside else th,0));uv.append((.5,.5));off=inside*n*m
  for j in range(n):f.append((ci,off+j,off+(j+1)%n))
 for xa,xb,ya,yb,sign in windows:
  # Square grid boundary -> exact circular cutout; both surfaces share the same live contour.
  boundary=[(j,ya)for j in range(xa,xb)]+[(xb,k)for k in range(ya,yb)]+[(j,yb)for j in range(xb,xa,-1)]+[(xa,k)for k in range(yb,ya,-1)];loops=[]
  for inside in[0,1]:
   ring=[];off=inside*n*m
   for j,k in boundary:
    x,y,z=v[off+k*n+j];a=math.atan2(y-cy,x);xx=hole*math.cos(a);yy=cy+hole*math.sin(a);fac=.92+.08*(yy-bottom)/(h-bottom);zz=sign*(d/2*fac-th*inside);ring.append(len(v));v.append((xx,yy,zz));uv.append((xx/.10,yy/.10))
   loops.append(ring)
   for q,(j,k)in enumerate(boundary):
    jj,kk=boundary[(q+1)%len(boundary)];a=off+k*n+j;b=off+kk*n+jj;c=ring[q];e=ring[(q+1)%len(ring)];f.extend([(a,c,b),(b,c,e)])
  for j in range(len(boundary)):a=loops[0][j];b=loops[0][(j+1)%len(boundary)];c=loops[1][j];e=loops[1][(j+1)%len(boundary)];f.extend([(a,b,c),(b,e,c)])
 used=sorted({i for tri in f for i in tri});remap={old:i for i,old in enumerate(used)};v=[v[i]for i in used];uv=[uv[i]for i in used];f=[tuple(remap[i]for i in tri)for tri in f]
 uv=[(u,vv*2)for u,vv in uv]
 g=G.raw('single-continuous-open-felt-shell-with-two-true-carry-holes-and-rounded-floor','felt',v,f,uv)
 return[g],['Single continuous closed material shell; no separate panel joints or coplanar z-fighting','Two genuine circular cutouts joined through4.5mm-thick felt; continuous softly rounded bottom and full real interior','Exact official outer dimensions, source-specific warm mottled nondirectional felt and softly tapered silhouette'],{'continuous_material_shell':True,'local_wall_thickness_mm_photo_interpreted':4.5,'through_carry_holes':2}
G.SPECS['1249811001']=dict(name='Kahverengi kısa kenarlı Arjuna ahşap tepsi',category='Tepsiler',dims=[30,2,15],hwd=[2,15,30],official={'length_cm':[30],'width_cm':[15],'height_cm':[2]},label='Arjuna ağacı %100 · Kahverengi',color='Kahverengi',build=tray,estimated=[],url='https://www2.hm.com/tr_tr/productpage.1249811001.html',claim='Kısa kenarlı ahşap tepsi. Yükseklik2cm; genişlik15cm; uzunluk30cm. Arjuna100%.',materials={'wood':('wood',[115,71,43],.42)},note='Resmî30×15×2cm aynen korunur;8mm kenar ve5mm taban kalınlığı kendi fotoğrafından yorumlandı. Kendi ahşap yüzeyinden doğal damar örneği kullanılır; gölge ve arka plan aktarılmaz.')
G.SPECS['1249815001']=dict(name='Altı küçük bölmeli ahşap düzenleyici',category='Saklama ürünleri',dims=[20,10,15],hwd=[10,20,15],official={'width_cm':[20],'depth_cm':[15],'height_cm':[10]},label='Arjuna ağacı %100 · Koyu kahverengi',color='Koyu kahverengi',build=organizer,estimated=[],url='https://www2.hm.com/tr_tr/productpage.1249815001.html',claim='Küçük ahşap düzenleyici. Altı küçük bölmeli kısmı tek büyük bölmeye dönüştürülebilir. Yükseklik10cm; derinlik15cm; genişlik20cm. Arjuna100%.',materials={'wood':('wood',[116,69,36],.46)},note='Resmî20×15×10cm kullanıldı. Ayrı çıkarılabilir ön ızgarada altı küçük bölme ve arkada bir büyük açık bölme fotoğrafla eşleştirildi. Panel kalınlıkları, alçak ön duvar ve yerel bölüm boyları fotoğraf yorumudur.')
for pid,w,h,d,color,rgb in [('1022276007',24.6,18,24.6,'Natürel beyaz kırçıllı',[227,222,208]),('1120163007',40,22,30,'Natürel beyaz kırçıllı',[227,222,208]),('1120163008',40,22,30,'Koyu kahverengi',[72,51,39])]:
 G.SPECS[pid]=dict(name=('Büyük keçe sepet'if w==40 else'Keçeli kare sepet')+' · '+color,category='Düzenleyici sepetler',dims=[w,h,d],hwd=[h,d,w],official={'height_cm':[h],'width_cm':[d],'length_cm':[w]},label='Polyester %100 · Keçe · '+color,color=color,build=lambda w=w,h=h,d=d:felt_basket(w/100,h/100,d/100),estimated=[],url='https://www2.hm.com/tr_tr/productpage.'+pid+'.html',claim=f'Keçeli kumaştan, yanları delikli sepet. Yükseklik{h}cm; genişlik{d}cm; uzunluk{w}cm. Ana kumaşPolyester100%.',materials={'felt':('felt',rgb,.94)},note=f'Resmî{w}×{d}×{h}cm dış zarf korunur. Alt köşe yuvarlatma,4,5mm keçe kalınlığı ve taşıma delikleri kendi fotoğrafından yorumlandı; gizli ölçüler resmî değildir.')
native_bank=G.bank
def bank(pid,key,kind,color,rough):
 if kind not in ['wood','felt']:return native_bank(pid,key,kind,color,rough)
 out=R/'materials'/pid;out.mkdir(parents=True,exist_ok=True)
 donor={'1249811001':('1249811001-c66d9ff35c67.jpg',[500,600,1012,1112]),'1249815001':('1249815001-baef0abb4b24.jpg',[500,1640,1012,1768]),'1022276007':('1022276007-1a07b4172799.jpg',[400,1320,912,1576]),'1120163007':('1120163007-eb334f0d999f.jpg',[450,1400,962,1656]),'1120163008':('1120163008-0405e21a37af.jpg',[150,1350,662,1606])}
 filename,crop=donor[pid];source=R/'originals'/filename
 if kind=='felt'and pid!='1120163008':color=[219,212,195]
 original=Image.open(source).convert('RGB');patch=original.crop(crop);raw=np.array(patch).astype(np.float32);blur=np.array(patch.filter(ImageFilter.GaussianBlur(48))).astype(np.float32);arr=np.clip(raw/np.maximum(blur,1)*np.array(color)[None,None,:],0,255);ny,nx=arr.shape[:2];grey=arr.mean(2);micro=grey-np.array(Image.fromarray(np.clip(grey,0,255).astype(np.uint8),'L').filter(ImageFilter.GaussianBlur(1.2)));dy,dx=np.gradient(micro*(.006 if kind=='felt'else .004));normal=np.stack([-dx,-dy,np.ones_like(dx)],2);normal/=np.linalg.norm(normal,axis=2,keepdims=True);orm=np.zeros((ny,nx,3),np.uint8);orm[:,:,0]=255;orm[:,:,1]=np.clip(rough*255+micro*.15,0,255)
 name=pid+'-'+key
 for slot,a in [('albedo',arr.astype(np.uint8)),('normal',np.clip((normal+1)*127.5,0,255).astype(np.uint8)),('orm',orm)]:Image.fromarray(a,'RGB').save(out/(name+'-'+slot+'.png'),optimize=True)
 prov=dict(master=str(source),master_sha256=G.sha(source),master_unchanged=True,source_crop_pixel_box=crop,native_crop_pixels=list(patch.size),output_pixels=[nx,ny],geometric_resampling_count=0,method='ExactSKU material-only native crop. Low-frequency illumination removed deterministically at native pixels; own fibres/grain retained; background, source silhouettes, props and directional studio highlights excluded.',source_rgb_illumination_retained=False)
 dump(out/'crop-provenance.json',prov)
 return out,dict(baseColorFactor=[1,1,1,1],baseColorTexture=name+'-albedo.png',normalTexture=name+'-normal.png',metallicRoughnessTexture=name+'-orm.png',normalScale=.2,metallic=1,roughness=1,doubleSided=False,alphaMode='OPAQUE',extras=dict(intrinsic_material=True,photo_pixels_baked=True,own_photo_material_crop=True,baked_reflections=False,native_resolution=[nx,ny],material_crop_provenance=str(out/'crop-provenance.json')))
G.bank=bank
def build(pid):
 # Browser captures are immutable separate research evidence, never replaced by generator summaries.
 live=R/'source-evidence'/(pid+'.json');dest=R/'live-evidence'/live.name;dest.parent.mkdir(exist_ok=True)
 if not dest.exists():shutil.copy2(live,dest)
 G.build(pid)
 entry=next(e for e in json.loads((R/'manifest.json').read_text())if e['sku']==pid);out=Path(entry['asset_dir']);model=json.loads((out/'model.json').read_text());model['metadata']['source_evidence_files'].append(str(dest));model['metadata']['photo_pixels_baked']=True;model['metadata']['production_scope']='Pending736 H&M source products; this asset does not imply whole-catalogue completion.'
 dump(out/'model.json',model);doc,bin=G.read_glb(Path(entry['glb_path']));doc['extras']['metadata']=model['metadata'];G.write_glb(Path(entry['glb_path']),doc,bin);entry.update(source_evidence_files=model['metadata']['source_evidence_files'],sha256=G.sha(entry['glb_path']),bytes=Path(entry['glb_path']).stat().st_size,model_revision='hmhome-reference-specific-production-2026-10-23-v1',model_status='pending_independent_and_browser_review',quality_pending=True)
 dump(out/'entry.json',entry);rows=json.loads((R/'manifest.json').read_text());dump(R/'manifest.json',[entry if e['id']==entry['id']else e for e in rows])
if __name__=='__main__':
 sources=json.loads((R/'source-queue-368.json').read_text());dump(R/'new-sources.json',[x for x in sources if x['sku']in G.SPECS])
 for pid in sys.argv[1:]or G.SPECS:build(pid)
