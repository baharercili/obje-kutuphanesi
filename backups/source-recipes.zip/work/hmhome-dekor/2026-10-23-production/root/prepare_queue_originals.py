"""Download observed exactSKU public reference JPEGs, retaining original bytes and SHA."""
from pathlib import Path
import json,hashlib,urllib.request,concurrent.futures
from PIL import Image,ImageDraw
R=Path(__file__).resolve().parent
def norm(s):return s.translate(str.maketrans({'I':'ı','İ':'i'})).lower()
queue=json.loads((R/'source-queue-368.json').read_text());old=json.loads((R/'original-image-masters.json').read_text());known={x['url']:x for x in old};errors=[]
def get(x):
 sku=x['sku'];im=x['reference_images'][0];url=im['url']
 if url in known:return known[url]
 p=R/'originals'/(sku+'-'+hashlib.sha256(url.encode()).hexdigest()[:12]+'.jpg');p.parent.mkdir(exist_ok=True)
 if not p.exists():
  with urllib.request.urlopen(url,timeout=45)as r:p.write_bytes(r.read())
 with Image.open(p)as picture:picture.load();assert picture.format=='JPEG';pixels=list(picture.size)
 return dict(sku=sku,url=url,alt=im.get('alt',x['name']),path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),pixels=pixels,original_bytes_unmodified=True)
results=[]
with concurrent.futures.ThreadPoolExecutor(max_workers=4)as pool:
 futures={pool.submit(get,x):x for x in queue}
 for fut in concurrent.futures.as_completed(futures):
  q=futures[fut]
  try:results.append(fut.result())
  except Exception as e:errors.append(dict(sku=q['sku'],url=q['reference_images'][0]['url'],error=type(e).__name__+': '+str(e)))
  if (len(results)+len(errors))%40==0:print('Source JPEG masters preserved',len(results),'errors',len(errors),flush=True)
allrefs={(x['sku'],x['url']):x for x in old+results};(R/'original-image-masters.json').write_text(json.dumps(list(allrefs.values()),ensure_ascii=False,indent=2)+'\n');(R/'original-photo-errors.json').write_text(json.dumps(errors,ensure_ascii=False,indent=2)+'\n')
by={x['sku']:x for x in results};towels=[x for x in queue if 'havlu'in norm(x['name'])and x['sku']in by]
for start in range(0,len(towels),35):
 rows=towels[start:start+35];board=Image.new('RGB',(7*220,5*340),(245,242,235));dr=ImageDraw.Draw(board)
 for i,q in enumerate(rows):
  im=Image.open(by[q['sku']]['path']).convert('RGB');im.thumbnail((210,300));x=i%7*220;y=i//7*340;board.paste(im,(x+(220-im.width)//2,y));dr.text((x+5,y+305),q['sku'],fill=(20,20,20));dr.text((x+5,y+320),q['name'][:28],fill=(20,20,20))
 board.save(R/('towels-source-'+str(start//35+1)+'.jpg'),quality=94)
print(json.dumps({'complete':len(results),'errors':len(errors),'total_source_products':len(queue),'towels':len(towels)}),flush=True)
