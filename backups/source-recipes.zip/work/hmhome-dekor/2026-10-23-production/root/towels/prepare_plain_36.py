from pathlib import Path
import json,numpy as np
from PIL import Image,ImageFilter,ImageDraw
R=Path(__file__).resolve().parent;P=R.parents[1]
queue=json.loads((P/'root/source-queue-368.json').read_text())
masters={e['sku']:e for e in json.loads((P/'root/original-image-masters.json').read_text())}
rows=[e for e in queue if e['sku'].startswith(('1097301','1097303','1097305'))]
assert len(rows)==36
donors={};board=Image.new('RGB',(9*160,4*210),'white');draw=ImageDraw.Draw(board)
for i,e in enumerate(rows):
 im=Image.open(masters[e['sku']]['path']).convert('RGB');grey=im.convert('L');low=np.asarray(grey.filter(ImageFilter.GaussianBlur(1.2)),dtype=float);a=np.asarray(grey,dtype=float);hf=abs(a-low);smooth=np.asarray(grey.filter(ImageFilter.GaussianBlur(16)),dtype=float);choices=[]
 for y in range(850,1251,64):
  for x in range(520,841,64):
   patch=hf[y:y+128,x:x+128];blocks=[float(np.mean(patch[j:j+16,k:k+16]))for j in range(0,128,16)for k in range(0,128,16)];grain=float(np.percentile(blocks,15));variation=float(smooth[y:y+128,x:x+128].std());score=grain/(1+variation/3)
   choices.append((score,[x,y,x+128,y+128],grain,variation))
 best=max(choices);donors[e['sku']]=dict(box=best[1],selection_method='Native128px interior pile patch; reject background/hem by minimum local texture and low illumination gradient. Visually reviewed as a complete36SKUcontact sheet before use.',score=best[0],texture_minimum=best[2],low_frequency_variation=best[3])
 x=i%9*160;y=i//9*210;board.paste(im.crop(best[1]),(x+16,y));draw.text((x+2,y+135),e['sku'],fill='black');draw.text((x+2,y+152),str(best[1]),fill='black')
(R/'plain-36-donor-boxes.json').write_text(json.dumps(donors,indent=2)+'\n');(R/'plain-36-source-queue.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n');board.save(R/'plain-36-selected-donors.jpg',quality=95)
print('36 native own-SKU pile patches selected; visual review pending')
