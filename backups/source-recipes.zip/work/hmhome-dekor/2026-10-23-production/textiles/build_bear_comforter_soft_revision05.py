"""Separate inextensible broad gathered-cloth revision of the held lovey.

The failed tiny-support gravity candidate is preserved and excluded. Here a
closed spherical direction curve has exactly2pi arc, so r*direction(theta)
preserves the planar square cloth metric around its tiny interpreted neck seam.
"""
from pathlib import Path
import sys,json,inspect,math
sys.dont_write_bytecode=True
import numpy as np
T=Path(__file__).resolve().parent;sys.path.insert(0,str(T))
import build_bear_comforter_prototypes as M
D=T/'bear-comforters-soft-curl-revision05';D.mkdir(exist_ok=True);M.D=D;M.A.R=D
A,C=M.A,M.C
NR=48;NT=1536;W=.37;NECK=.005
def direction_curve(seed):
    phi=np.linspace(0,math.tau,40001)
    phase=6*phi+.38*np.sin(2*phi)+.16*np.sin(5*phi)
    perturb=np.sin(phase)+.21*np.sin(3*phi+.4)+.09*np.sin(11*phi-.7)
    def curve(a):
        polar=.42+a*perturb
        d=np.stack([np.sin(polar)*np.sin(phi),-np.cos(polar),np.sin(polar)*np.cos(phi)],1)
        lengths=np.linalg.norm(np.diff(d,axis=0),axis=1);return d,np.r_[0,np.cumsum(lengths)]
    low,high=.001,.32
    for _ in range(42):
        mid=(low+high)/2;d,s=curve(mid)
        if s[-1]>math.tau:high=mid
        else:low=mid
    d,s=curve((low+high)/2);assert abs(s[-1]-math.tau)<1e-9
    sample_phi=np.arange(NT)*math.tau/NT
    # Refine where the direction curve turns most sharply, and retain the
    # material square's exact eight corner/edge directions.
    for corner_theta in np.arange(8)*math.pi/4:
        corner_phi=np.interp(corner_theta,s,phi)
        sample_phi[np.argmin(abs(sample_phi-corner_phi))]=corner_phi
    sample_phi.sort()
    theta=np.interp(sample_phi,phi,s)
    directions=np.stack([np.interp(sample_phi,phi,d[:,k])for k in range(3)],1)
    directions/=np.linalg.norm(directions,axis=1,keepdims=True)
    return theta,directions,dict(spherical_curve_arc=float(s[-1]),nonuniform_broad_gathers=True,
        polar_base_radians=.42,solved_perturbation_amplitude=float((low+high)/2))
def body(sku):
    theta,direction,curve=direction_curve(int(sku))
    outer=W/2/np.maximum(abs(np.cos(theta)),abs(np.sin(theta)))
    radii=NECK+(outer[None,:]-NECK)*np.linspace(0,1,NR+1)[:,None]
    grid=radii[:,:,None]*direction[None,:,:]
    # Soft inward curling of the free lower corners. Each radial path is
    # integrated at finite bend radius, then its true planar cloth metric is
    # relaxed. This replaces the straight ruled panels in the held cone.
    up=np.array([0,1.,0]);e=up[None,:]-direction*(direction@up)[:,None]
    e/=np.linalg.norm(e,axis=1,keepdims=True)
    curved=np.empty_like(grid);curved[0]=grid[0]
    for j in range(NR):
        r=(radii[j]+radii[j+1])*.5
        bend=.95*np.clip((r-.10)/.15,0,1)**1.7
        tangent=direction*np.cos(bend)[:,None]+e*np.sin(bend)[:,None]
        curved[j+1]=curved[j]+tangent*(radii[j+1]-radii[j])[:,None]
    grid=curved
    # A restrained vertical twist breaks the ruled cone's identical straight
    # valleys without stretching its circular rows.
    twist=.035*np.sin(np.linspace(0,math.pi,NR+1))**2
    x=grid[:,:,0].copy();z=grid[:,:,2].copy()
    grid[:,:,0]=x*np.cos(twist)[:,None]+z*np.sin(twist)[:,None]
    grid[:,:,2]=-x*np.sin(twist)[:,None]+z*np.cos(twist)[:,None]
    planar=np.stack([radii*np.cos(theta)[None,:],radii*np.sin(theta)[None,:]],2)
    rr=np.linalg.norm(np.diff(planar,axis=0),axis=2)
    aa=np.linalg.norm(np.roll(planar,-1,axis=1)-planar,axis=2)
    pin=grid[0].copy()
    cache=D/(sku+'-soft-metric-relaxed-grid.npz')
    if cache.exists():grid=np.load(cache)['grid']
    else:
        for it in range(1700):
            for parity in[0,1]:
                a=grid[parity:NR:2];b=grid[parity+1:NR+1:2];delta=b-a;dist=np.linalg.norm(delta,axis=2)
                correction=delta*((dist-rr[parity:NR:2])/np.maximum(dist,1e-12))[:,:,None]*.5
                a+=correction;b-=correction
                ids=np.arange(parity,NT,2);nxt=(ids+1)%NT;delta=grid[:,nxt]-grid[:,ids];dist=np.linalg.norm(delta,axis=2)
                correction=delta*((dist-aa[:,ids])/np.maximum(dist,1e-12))[:,:,None]*.5
                grid[:,ids]+=correction;grid[:,nxt]-=correction
            grid[0]=pin
        np.savez_compressed(cache,grid=grid)
    # Present a real square-cloth corner toward the source's front view.
    corner=np.argmin(abs(theta-math.pi/4));angle=-math.atan2(grid[-1,corner,0],grid[-1,corner,2]);cc,ss=math.cos(angle),math.sin(angle)
    x=grid[:,:,0].copy();z=grid[:,:,2].copy();grid[:,:,0]=x*cc+z*ss;grid[:,:,2]=-x*ss+z*cc
    vertices=grid.reshape(-1,3);uv=np.stack([radii*np.cos(theta)[None,:]/.04,radii*np.sin(theta)[None,:]/.04],2).reshape(-1,2)
    faces=[]
    for j in range(NR):
        for i in range(NT):
            a=j*NT+i;b=j*NT+(i+1)%NT;c=a+NT;d=b+NT;faces.extend([(a,c,b),(b,c,d)])
    # Front/back material layers share the same unstrained reference, but each
    # is its own real finite-thickness cloth solid with a small neck opening.
    normal=np.zeros_like(vertices)
    f=np.array(faces);face_normal=np.cross(vertices[f[:,1]]-vertices[f[:,0]],vertices[f[:,2]]-vertices[f[:,0]])
    for k in range(3):np.add.at(normal,f[:,k],face_normal)
    normal/=np.linalg.norm(normal,axis=1,keepdims=True)
    boundary=[list(range((NR+1)*NT-1,NR*NT-1,-1)),list(range(NT))]
    raw=[A.open_surface_shell('continuous-square-brushed-blanket-outer','plush',vertices+normal*.00055,faces,boundary,uv,.00075),
         A.open_surface_shell('separate-continuous-cotton-muslin-lining','lining',vertices-normal*.00045,faces,boundary,uv,.00045),
         A.closed_tube('soft-sewn-square-blanket-perimeter','binding',grid[-1],.00065,sides=8),
         A.closed_tube('soft-local-neck-attachment-seam','plush',grid[0],.0008,sides=8)]
    radial=np.linalg.norm(np.diff(grid,axis=0),axis=2).sum(0);reference=outer-NECK
    angular=np.linalg.norm(np.roll(grid,-1,axis=1)-grid,axis=2)
    planar=np.stack([radii*np.cos(theta)[None,:],radii*np.sin(theta)[None,:]],2)
    expected=np.linalg.norm(np.roll(planar,-1,axis=1)-planar,axis=2)
    proof=dict(display_flat_size_m=[W,W],physical_flat_scale_officially_verified=False,
        local_neck_opening_radius_m_interpreted=NECK,radial_segments=NR,angular_segments=NT,
        max_relative_radial_arc_error=float(abs(radial/reference-1).max()),
        max_relative_angular_edge_error=float(abs(angular/expected-1).max()),
        real_square_reference_boundary=True,analytical_developable_surface=True,unexported_support=False,
        curve=curve,attachment_pattern_manufacturer_verified=False,
        interpretation='Centred hanging comforter cloth; the local neck seam and display scale are photo interpretations.')
    proof.update(soft_corner_curl_and_metric_relaxation=True,radial_stretch_tolerance=.015,angular_stretch_tolerance=.015)
    assert proof['max_relative_radial_arc_error']<.015,proof
    assert proof['max_relative_angular_edge_error']<.015,proof
    C.dump(D/(sku+'-developable-cloth-proof.json'),proof)
    return raw,proof
M.body=body
source=inspect.getsource(M.build)
start=source.index('    grid,n,proof=drape(sku);')
end=source.index("    raw.append(soft_blob('soft-sewn-neck",start)
source=source[:start]+'    raw,proof=body(sku)\n'+source[end:]
source=source.replace("'-soft-bear-comforter-two-surface-gathered-cloth'","'-soft-bear-comforter-soft-curled-cloth-r5'")
source=source.replace("(0,.010,0),(.011,.014,.010)","(0,-.004,0),(.006,.006,.006)")
source=source.replace("(0,.044,0),(.032,.034,.025)","(0,.021,0),(.032,.030,.024)")
source=source.replace("(sign*.027,.071,-.001),(.010,.011,.006)","(sign*.024,.050,-.001),(.008,.0085,.0045)")
OLD_BLOB=M.soft_blob
def soft_blob(name,mat,centre,radii,seed):
    raw=OLD_BLOB(name,mat,centre,radii,seed)
    if name=='soft-padded-bear-head':
        pp=np.array(raw['_vertices']);q=(pp-np.array(centre))/np.array(radii)
        q=np.sign(q)*abs(q)**np.array([.74,.83,.90])[None,:]
        q[:,0]*=.91+.09*(q[:,1]+1)*.5
        raw['_vertices']=[tuple(x)for x in np.array(centre)+q*np.array(radii)]
    return raw
M.soft_blob=soft_blob
def lowered_face(x,y):
    y-=.023
    z=.024*max(.01,1-abs(x/.032)**(2/.74)-abs((y-.021)/.030)**(2/.83))**.45
    return np.array([x,y,z+.00065])
M.face=lowered_face
source=source.replace("'hidden_lining_pattern'","'hidden_lining_pattern_and_local_neck_opening'")
source=source.replace("'Resmî bileşenler: Shell pamuk%100; Top polyester%70, diğer lifler%30 · Görsel katman eşlemesi yorum'",
                      "'Resmî bileşenler: Dış katman pamuk%100; Üst polyester%70, diğer lifler%30 · Katman eşlemesi yorum'")
exec(compile(source,str(__file__)+':padded-bear-with-inextensible-gathered-cloth','exec'),M.__dict__)
if __name__=='__main__':
    for sku in sys.argv[1:]:M.build(sku)
