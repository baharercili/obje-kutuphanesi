"""Independent binary proof that hemstitch bands contain actual voids."""
from pathlib import Path
import json,sys,struct,hashlib,importlib.util
import numpy as np
sys.dont_write_bytecode=True
T=Path(__file__).resolve().parent;s=importlib.util.spec_from_file_location('independent_hemstitch_binary',T.parent/'curtains/validate_special_products.py');S=importlib.util.module_from_spec(s);s.loader.exec_module(S)
def validate(e):
    result=S.check(e);data=Path(e['glb_path']).read_bytes();n=struct.unpack_from('<I',data,12)[0];doc=json.loads(data[20:20+n]);bl=struct.unpack_from('<I',data,20+n)[0];binary=data[28+n:28+n+bl];meta=doc['extras']['metadata'];assert meta==json.loads(Path(e['model_path']).read_text())['metadata'];feat=meta['hemstitch_features'];w,l=[v/100 for v in feat['flat_reference_size_cm']];patches={p['name']:p for p in feat['patches']};assert len(doc['meshes'])==len(patches)+1
    def arr(i):
        a=doc['accessors'][i];v=doc['bufferViews'][a['bufferView']];dtype={5126:'<f4',5125:'<u4',5123:'<u2'}[a['componentType']];c={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}[a['type']];sz=np.dtype(dtype).itemsize;return np.ndarray((a['count'],c),dtype=dtype,buffer=binary,offset=v.get('byteOffset',0)+a.get('byteOffset',0),strides=(v.get('byteStride',c*sz),sz)).copy()
    triangles=[];ranges=[]
    for mesh in doc['meshes']:
        if mesh['name']not in patches:assert mesh['name']=='separate-bundled-hemstitch-thread-bridges';continue
        patch=patches[mesh['name']];p=mesh['primitives'][0];uv=arr(p['attributes']['TEXCOORD_0']);faces=arr(p['indices']).reshape(-1,3);count=(patch['grid_nu']+1)*(patch['grid_nv']+1);u0,u1,v0,v1=patch['uv_domain'];expected=np.array([[u0*w/.04,v0*l/.04],[u1*w/.04,v1*l/.04]]);actual=np.array([uv[:count].min(0),uv[:count].max(0)]);assert np.allclose(actual,expected,atol=1e-4);front=faces[(faces<count).all(1)];triangles.append(uv[front].astype(float));ranges.append(dict(mesh=mesh['name'],actual_reference_uv_range=actual.tolist()))
    triangles=np.concatenate(triangles);a=triangles[:,0];v0=triangles[:,1]-a;v1=triangles[:,2]-a;det=v0[:,0]*v1[:,1]-v0[:,1]*v1[:,0];valid=abs(det)>1e-14;hem=feat['hem_turn_m'];gap=feat['actual_open_band_gap_m'];voids=[]
    for side in ['near','far','left','right']:
        for fraction in [.15,.35,.55,.75,.85]:
            cross=hem+gap*.5
            if side=='near':point=np.array([fraction*w,cross])/.04
            elif side=='far':point=np.array([fraction*w,l-cross])/.04
            elif side=='left':point=np.array([cross,fraction*l])/.04
            else:point=np.array([w-cross,fraction*l])/.04
            delta=point-a;u=np.zeros(len(det));v=np.zeros(len(det));u[valid]=(delta[valid,0]*v1[valid,1]-delta[valid,1]*v1[valid,0])/det[valid];v[valid]=(v0[valid,0]*delta[valid,1]-v0[valid,1]*delta[valid,0])/det[valid];inside=valid&(u>=-1e-8)&(v>=-1e-8)&(u+v<=1+1e-8);assert not inside.any(),(side,fraction,'opaque cloth under open band');voids.append(dict(edge=side,reference_length_fraction=fraction,opaque_cloth_front_surfaces=0))
    assert sum(feat['groups_by_edge'].values())*feat['bundled_strands_per_group']>0;result.update(actual_openwork_band_uv_void_checks=voids,opaque_underlay_absent=True,physical_bundled_thread_strands=sum(feat['groups_by_edge'].values())*2,independent_patch_reference_uv_checks=ranges,source_jpegs_unchanged=True);return result
if __name__=='__main__':
    p=Path(sys.argv[1]);rows=json.loads(p.read_text());checks=[]
    for e in rows:checks.append(validate(e));print('ACTUAL OPEN HEMSTITCH CHECK',e['sku'],flush=True)
    out=p.with_name(p.stem+'-independent-validation.json');out.write_text(json.dumps(dict(valid=True,models=len(rows),checks=checks,canonical_changed=False),ensure_ascii=False,indent=2)+'\n');print(out,hashlib.sha256(out.read_bytes()).hexdigest())
