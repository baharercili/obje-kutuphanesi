"""Exact two-part baby sets: hollow15x20mitt and rounded30x30flannel.

Own cherry/elephant embroidery, separate physical roles and scene variants.
These products are not hooded towels. Nominal flat dimensions stay separate
from interpreted padding, bindings and posed bounds.
"""
from pathlib import Path
import sys,json,math,copy
import numpy as np
from PIL import Image,ImageDraw
sys.dont_write_bytecode=True
T=Path(__file__).resolve().parent;sys.path.insert(0,str(T))
import build_bear_bath_mitt as M
import build_real_hemstitch as H
A,C,B=M.A,M.C,M.B
D=T/'baby-two-piece-sets-batch01';D.mkdir(exist_ok=True);A.R=D
M.H=.20;M.N=96;M.NV=90;M.TH=.0012
def radii(y):
 v=np.clip(y/.20,0,1);top=np.clip((v-.85)/.15,0,1);top=top*top*(3-2*top)
 return .075-.009*top,.0095-.007*top
M.radii=radii
def motif(sku):
 box=[450,990,690,1175]if sku.endswith('2')else[420,910,670,1170]
 im=Image.open(A.L.EVIDENCE[sku]['original']['path']).convert('RGB').crop(box);p=np.asarray(im,float);masks={}
 if sku.endswith('2'):
  masks['red']=(p[:,:,0]/(p[:,:,1]+1)>1.45)&(p[:,:,0]>80)
  masks['green']=(p[:,:,1]>p[:,:,0]*1.02)&(p.max(2)-p.min(2)>10)
 else:
  outline=Image.new('L',im.size);ImageDraw.Draw(outline).polygon([(38,36),(48,33),(66,44),(84,45),(114,42),(142,46),(159,36),(178,37),(190,52),(194,82),(188,103),(170,119),(165,154),(163,177),(150,204),(132,215),(113,211),(99,204),(82,211),(66,211),(55,201),(45,181),(46,163),(59,150),(55,128),(46,115),(39,88)],fill=255)
  gray=(p[:,:,0]/(p[:,:,2]+1)<1.09)&(p.mean(2)<227)
  masks['gray']=(np.asarray(outline)>0)|((np.indices(gray.shape)[0]>210)&gray)
  masks['dark']=(p.mean(2)<110)&(p[:,:,0]/(p[:,:,2]+1)<1.13)
 return im,box,masks
def stitches(sku,mapper,name,size):
 im,box,masks=motif(sku);raw=[]
 for key,mask in masks.items():
  items=[];hh,ww=mask.shape
  for row in range(1,hh-1,2):
   edge=np.diff(np.r_[False,mask[row],False].astype(int));starts=np.where(edge==1)[0];ends=np.where(edge==-1)[0]
   for aa,bb in zip(starts,ends):
    if bb-aa<2:continue
    path=[mapper((x/(ww-1)-.5)*size[0],(.5-row/(hh-1))*size[1])for x in np.linspace(aa+.2,bb-.2,4)]
    items.append(C.tube(name+'-'+key+'-satin-thread',key,path,.00020,sides=5))
  if items:raw.append(H.merge_solids(items,name+'-actual-'+key+'-embroidery',key))
 return raw
def flannel():
 N=120;g=[];n=[];uv=[]
 for v in np.linspace(0,1,N+1):
  rr=[];tt=[]
  for u in np.linspace(0,1,N+1):
   x=(u-.5)*.30;z=(v-.5)*.30
   if abs(x)>.125 and abs(z)>.125:
    a=(abs(x)-.125)/.025;b=(abs(z)-.125)/.025;x=math.copysign(.125+.025*a*math.sqrt(1-b*b*.5),x);z=math.copysign(.125+.025*b*math.sqrt(1-a*a*.5),z)
   y=.004*math.sin(u*math.tau+.6)*math.cos(v*math.pi)+.002*math.sin(v*9+u*3)
   rr.append([x,y,z]);tt.append([x/.04,z/.04])
  g.append(rr);uv.append(tt)
 g=np.array(g);n=np.cross(np.gradient(g,axis=0),np.gradient(g,axis=1));n/=np.linalg.norm(n,axis=2,keepdims=True)
 body=C.shell('real-continuous-rounded30x30cm-flannel','cloth',g,n,.00125,np.array(uv))
 boundary=list(g[0])+list(g[1:,-1])+list(g[-1,-2::-1])+list(g[-2:0:-1,0]);binding=A.closed_tube('soft-rounded-woven-flannel-binding','hem',boundary,.0020,sides=8)
 return[body,binding],g,n
def material(sku,out):
 m=M.materials('1041734004',out)if False else B.material(sku,dict(recipe='cotton',rgb=[240,238,225],intrinsic_ao=True,weave_period_m=.0007),out)
 N=2048;rep=.04;x=np.arange(N)[None,:]/N*rep;pink=[238,194,188]if sku.endswith('2')else[183,165,143]
 stripe=np.broadcast_to((x%.012)<.006,(N,N));rgb=np.where(stripe[:,:,None],np.array(pink),np.array([241,239,226]));Image.fromarray(np.uint8(rgb)).save(out/(sku+'-physical-stripe-albedo.png'),optimize=True)
 for key in['cloth','hem']:m[key]['baseColorTexture']=sku+'-physical-stripe-albedo.png'
 m['hem']['baseColorTexture']=None;m['hem']['baseColorFactor']=[c/255 for c in pink]+[1]
 for name,rgb in[('red',[153,3,30]),('green',[111,141,94]),('gray',[156,155,142]),('dark',[55,47,39])]:m[name]=dict(baseColorFactor=[c/255 for c in rgb]+[1],metallic=0,roughness=.84,doubleSided=False,alphaMode='OPAQUE')
 im,box,masks=motif(sku);im.save(out/'native-motif-crop-evidence.png');C.dump(out/'own-motif-provenance.json',dict(source=A.L.EVIDENCE[sku]['original'],native_crop_box=box,native_pixels=list(im.size),
  shape_mask_photo_guided=True,elephant_silhouette_annotation_interpreted=sku.endswith('3'),no_studio_luminance_baked=True,
  motif_stitch_radius_interpreted_m=.00020,stripe_repeat_interpreted_m=.012))
 return m
def build(sku):
 raw=[];groups=[];bounds=[];grou=[]
 body=M.hollow_body();body['name']='actual-hollow15x20cm-baby-bath-mitt';items=[body,M.flat_hang_loop()]
 items+=stitches(sku,lambda x,y:M.front(x,.108+y)+np.array([0,0,.001]),'mitt-own-motif',[.044,.037])
 for q in items:
  # Flat presentation on top of the flannel, with a real accessible hand cavity.
  q['_vertices']=[(x-.045,z+.035,-y+.060)for x,y,z in q['_vertices']];grou.append(len(raw));raw.append(q)
 groups.append(grou);p=np.concatenate([raw[i]['_vertices']for i in grou]);bounds.append((p.min(0),p.max(0)))
 items,g,n=flannel()
 def corner_motif(x,y):
  p,nn=C.sample(g,n,(.10+x+.15)/.30,(-.10-y+.15)/.30)
  return p+nn*.0012
 items+=stitches(sku,corner_motif,'flannel-own-corner-motif',[.030,.027]);grou=[]
 for q in items:grou.append(len(raw));raw.append(q)
 groups.append(grou);p=np.concatenate([raw[i]['_vertices']for i in grou]);bounds.append((p.min(0),p.max(0)))
 aid='hm-'+sku+'-two-physical-baby-parts-own-'+('cherry'if sku.endswith('2')else'elephant')+'-embroidery'
 note='Exact SKU resmî iki parça set: el lifi15×20cm ve bez30×30cm; pamuk%100. Model bu iki farklı rolü ayrı fiziksel parça ve ayrı sahneler olarak içerir; kapüşonlu havlu değildir. Nominal düz kumaş boyları, iç cep kalınlığı, yuvarlak köşe/binding payı ve yatık gösterim kutusu aynı şey değildir. Motif kendi JPEG’inden kiraz veya fil ve love you yazısı olarak yorumlandı; gizli iç dikiş, küçük yerel ölçüler, pile/yüzey ve renk fotoğraf yorumudur.'
 meta=A.base_metadata(sku,aid,dict(set_quantity=2,parts=[dict(role='bath_mitt',nominal_flat_cm=[15,20]),dict(role='flannel',nominal_flat_cm=[30,30])]),note,'cotton',2)
 meta.update(source_dimensions_hwd_cm=[None,None,None],quality_status='photo_interpretation',quality_label='2 farklı fiziksel parça · Kendi özgün motifleri',scene_variants=[dict(index=0,label='2 parça set'),dict(index=1,label='15×20cm el lifi'),dict(index=2,label='30×30cm bez')],baby_set_features=dict(real_mitt_hand_cavity=True,rounded_separate_flannel=True,hood_absent=True,own_photo_motif=True))
 meta['source_evidence_files'].append(str(T/'additional-exact-role-research.json'));e=A.finish(raw,meta,lambda out:material(sku,out),features=meta['baby_set_features']);doc,binary=C.read_glb(e['glb_path']);nodes={n['mesh']:i for i,n in enumerate(doc['nodes'])if'mesh'in n};allp=np.concatenate([x['_vertices']for x in raw]);alo,ahi=allp.min(0),allp.max(0)
 for k,group in enumerate(groups):
  leaves=[]
  for mi in group:leaves.append(len(doc['nodes']));doc['nodes'].append(copy.deepcopy(doc['nodes'][nodes[mi]]))
  lo,hi=bounds[k];tr=[float((alo[0]+ahi[0]-lo[0]-hi[0])/2),float(alo[1]-lo[1]),float((alo[2]+ahi[2]-lo[2]-hi[2])/2)];root=len(doc['nodes']);doc['nodes'].append(dict(name='single-physical-part-root',children=leaves,translation=tr));doc['scenes'].append(dict(name='Mitt'if k==0 else'Flannel',nodes=[root]))
 C.write_glb(e['glb_path'],doc,binary);e['sha256']=C.sha(e['glb_path']);e['bytes']=Path(e['glb_path']).stat().st_size;out=Path(e['asset_dir']);C.dump(out/'entry.json',e);p=out/(aid+'.validation.json');r=json.loads(p.read_text());r['deliverable_sha256']['glb']=e['sha256'];r['glb_bytes']=e['bytes'];C.dump(p,r);p=D/'candidate-baby-two-piece-sets-manifest.json';rows=json.loads(p.read_text())if p.exists()else[];C.dump(p,[x for x in rows if x['sku']!=sku]+[e]);print('BABY TWO PARTS',sku,flush=True)
if __name__=='__main__':
 for sku in sys.argv[1:]:build(sku)
