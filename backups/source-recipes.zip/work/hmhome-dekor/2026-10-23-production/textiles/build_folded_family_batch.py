"""Complete folded linen families using the actual-Three-approved four layers.

No old cone or half-fold plate geometry is used. Every piece remains separate.
Material pattern coordinates refer to the full, unfolded cloth, independent
of the physical 40 mm weave repeat. Frozen earlier versions stay unchanged.
"""
from pathlib import Path
import sys, json, copy, math
sys.dont_write_bytecode = True
import numpy as np
from PIL import Image
T = Path(__file__).resolve().parent
sys.path.insert(0, str(T))
import build_folded_soft_revision as F
A, L, C, B = F.A, F.L, F.C, F.B
D = T / 'folded-plain-family-batch01'
D.mkdir(exist_ok=True)
A.R = D

CONFIG = {
    '1282416002': dict(recipe='linen_blend', rgb=[239,239,230], crop=[560,420,670,760], qty=4),
    '1282416008': dict(recipe='linen_blend', rgb=[168,181,198], crop=[1050,700,1300,1100], qty=4, estimated_size=[45,45]),
    '1282416010': dict(recipe='linen_blend', rgb=[65,45,38], crop=[1050,720,1350,1100], qty=4, estimated_size=[45,45]),
    '1282416012': dict(recipe='linen_blend', rgb=[98,24,34], crop=[1050,650,1350,1000], qty=4, estimated_size=[45,45]),
    '1310624001': dict(recipe='linen', rgb=[239,238,228], crop=[850,800,1150,1300], qty=2, estimated_size=[50,50]),
    '1336931003': dict(recipe='waffle', rgb=[49,32,28], crop=[550,1450,680,1700], qty=2),
    '1336931004': dict(recipe='waffle', rgb=[188,119,94], crop=[1030,1000,1190,1300], qty=2),
    '1336947002': dict(recipe='linen', rgb=[213,199,177], crop=[590,1000,750,1250], qty=1),
}

def material(sku, cfg, out, w, l):
    f = dict(cfg, intrinsic_ao=True)
    mats = B.material(sku, f, out)
    ev = L.EVIDENCE[sku]
    with Image.open(ev['original']['path']) as master:
        patch = master.crop(cfg['crop'])
        pixels = np.asarray(patch)
        median = np.median(pixels.reshape(-1,3),axis=0).tolist()
        patch.save(out/'native-palette-reference-crop.png')
    C.dump(out/'own-source-palette-proof.json',dict(
        source=ev['original'],native_crop_box=cfg['crop'],native_crop_pixels=list(patch.size),
        source_rgb_median=median,intrinsic_rgb_used=cfg['rgb'],colour_is_photo_interpreted=True,
        source_studio_pixels_projected=False,colour_method='Own-source yarn colour interpretation; directional fold lighting excluded.',
        original_jpeg_unmodified=True))
    return mats

def build(sku):
    cfg = copy.deepcopy(CONFIG[sku])
    ev = L.EVIDENCE[sku]
    official_size = ev['official_flat_size_cm']
    size = official_size or cfg['estimated_size']
    w, l = [v/100 for v in size]
    qty, recipe = cfg['qty'], cfg['recipe']
    raw, groups, bounds, proofs = [], [], [], []
    thickness = .0008 if recipe == 'waffle' else .00055
    for k in range(qty):
        grid,n,uv,proof = F.folded(w,l,recipe,int(sku)+k*971)
        proofs.append(proof)
        uv = uv*np.array([w/.04,l/.04])
        parts = [C.shell('continuous-four-layer-woven-cloth','cloth',grid,n,thickness,uv)]
        for label,path in [('cut-end-a',grid[0]),('cut-end-b',grid[-1]),('side-a',grid[:,0]),('side-b',grid[:,-1])]:
            parts.append(C.tube(label+'-soft-turned-edge','hem',path,radius=thickness*.75,sides=8))
        offset = np.array([(k-(qty-1)/2)*.025,k*(.021 if recipe=='waffle' else .017),.007*math.sin(k*1.7)])
        group = []
        for part in parts:
            part['name'] = 'item-'+str(k+1)+'-'+part['name']
            part['_vertices'] = [tuple(np.array(v)+offset) for v in part['_vertices']]
            group.append(len(raw)); raw.append(part)
        groups.append(group)
        p = np.concatenate([raw[i]['_vertices'] for i in group]);bounds.append((p.min(0),p.max(0)))
    aid = f'hm-{sku}-continuous-four-layer-soft-cloth-family'
    scale = (f'Resmî düz ürün ölçüsü {size[0]:g}×{size[1]:g} cm. ' if official_size else
             f'Fiziksel ölçü açık cm birimiyle doğrulanamadı; gösterim için yaklaşık {size[0]:g}×{size[1]:g} cm yorumlandı. ')
    note = (scale+f'{qty} gerçek fiziksel parça. Her parça tek sürekli kumaştan dört gerçek kat olarak gösterildi; '
            'katlanmış kutu ölçüsü düz ürün ölçüsü değildir. İnce dokumanın yerel kat yarıçapları, kalınlığı, '
            'iç içe kat payları ve kırışıklıkları fotoğraf yorumudur. Kaynak fotoğraftaki poz yerine '
            'projelerde kullanılabilir yumuşak katlı poz seçildi; üretici kalıbı veya fiziksel tarama değildir.')
    official = dict(set_quantity=qty)
    if official_size: official['flat_item_size_cm'] = official_size
    meta = A.base_metadata(sku,aid,official,note,recipe,qty)
    if not official_size:
        meta['estimated_fields'] += ['physical_flat_width_and_length_cm_unverified']
        meta['interpreted_display_flat_size_cm'] = size
    meta.update(source_dimensions_hwd_cm=[None,*official_size] if official_size else [None,None,None],
                cloth_fold_proof=proofs,scene_variants=[dict(index=0,label=f'{qty} parça · Yumuşak dört kat')]+
                ([dict(index=1,label='Tek fiziksel bez · Dört kat')] if qty>1 else []),
                quality_status='photo_interpretation',quality_label='Katlı kumaş pozu · Dokuma yorumu'+(' · Ölçü yaklaşık' if not official_size else ''))
    entry = A.finish(raw,meta,lambda out:material(sku,cfg,out,w,l),features=dict(
        physical_piece_count=qty,continuous_layers_per_piece=4,fold_proofs=proofs,
        source_photo_pose_replaced_by_explicit_folded_display_pose=True))
    doc,binary = C.read_glb(entry['glb_path'])
    if qty>1:
        nodes = {n['mesh']:i for i,n in enumerate(doc['nodes']) if 'mesh' in n}
        leaves = []
        for mi in groups[0]:
            leaves.append(len(doc['nodes']));doc['nodes'].append(copy.deepcopy(doc['nodes'][nodes[mi]]))
        p = np.concatenate([g['_vertices'] for g in raw]);alo,ahi=p.min(0),p.max(0);lo,hi=bounds[0]
        translation=[float((alo[0]+ahi[0]-lo[0]-hi[0])/2),float(alo[1]-lo[1]),float((alo[2]+ahi[2]-lo[2]-hi[2])/2)]
        root=len(doc['nodes']);doc['nodes'].append(dict(name='single-four-layer-cloth-centred-root',children=leaves,translation=translation))
        doc['scenes'].append(dict(name='Single physical folded cloth',nodes=[root]))
    for mat in doc['materials']:
        if mat['name'] in ['cloth','hem']:
            mat['occlusionTexture']={**mat['pbrMetallicRoughness']['metallicRoughnessTexture'],'strength':.8}
    C.write_glb(entry['glb_path'],doc,binary)
    entry['sha256']=C.sha(entry['glb_path']);entry['bytes']=Path(entry['glb_path']).stat().st_size
    if not official_size: entry['size_source_kind']='source_set_quantity_known_photo_estimated_physical_scale'
    out=Path(entry['asset_dir']);C.dump(out/'entry.json',entry)
    reportpath=out/(aid+'.validation.json');report=json.loads(reportpath.read_text())
    report['deliverable_sha256']['glb']=entry['sha256'];report['glb_bytes']=entry['bytes'];C.dump(reportpath,report)
    manifest=D/'candidate-folded-family-manifest.json';rows=json.loads(manifest.read_text()) if manifest.exists() else []
    C.dump(manifest,[e for e in rows if e['sku']!=sku]+[entry]);print('FOLDED FAMILY',sku,flush=True)

if __name__ == '__main__':
    for sku in (list(CONFIG) if '--all' in sys.argv else sys.argv[1:]):build(sku)
