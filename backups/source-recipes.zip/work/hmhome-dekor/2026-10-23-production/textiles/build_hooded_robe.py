"""Source-photo interpreted hollow child robe, hood, sleeve openings, pockets and tied belt."""
from pathlib import Path
import sys,math,copy,importlib.util
import numpy as np
from PIL import Image,ImageFilter
R=Path(__file__).resolve().parent;s=importlib.util.spec_from_file_location('robe_helpers',R/'asset_helpers.py');A=importlib.util.module_from_spec(s);s.loader.exec_module(A);C=A.C;TAU=math.tau
def ellipsoid(name,mat,centre,radii,nu=32,nv=18):
 v=[tuple(np.array(centre)+[0,radii[1],0])];uv=[(.5,1)];f=[]
 for j in range(1,nv):
  a=math.pi*j/nv
  for i in range(nu):b=TAU*i/nu;v.append(tuple(np.array(centre)+np.array([radii[0]*math.sin(a)*math.cos(b),radii[1]*math.cos(a),radii[2]*math.sin(a)*math.sin(b)])));uv.append((i/nu,1-j/nv))
 bottom=len(v);v.append(tuple(np.array(centre)+[0,-radii[1],0]));uv.append((.5,0))
 for i in range(nu):f.append((0,1+(i+1)%nu,1+i))
 for j in range(nv-2):
  for i in range(nu):a=1+j*nu+i;b=1+j*nu+(i+1)%nu;c=a+nu;d=b+nu;f.extend([(a,b,c),(b,d,c)])
 for i in range(nu):f.append((bottom,1+(nv-2)*nu+i,1+(nv-2)*nu+(i+1)%nu))
 return C.B.solid(name,mat,v,f,uv)
def normals(grid):
 n=np.cross(np.gradient(grid,axis=1),np.gradient(grid,axis=0));return n/np.linalg.norm(n,axis=2,keepdims=True)
def build(sku):
 assert sku=='1237612002';height=.53;nu=128;nv=80;body=[]
 for v in np.linspace(0,1,nv+1):
  gap=.035+.38*v**4;theta=np.linspace(gap,TAU-gap,nu+1);neck=np.clip((v-.80)/.20,0,1);neck=neck*neck*(3-2*neck);rx=.16-.028*math.exp(-((v-.56)/.22)**2)-.080*neck;rz=.077-.010*math.exp(-((v-.56)/.23)**2)-.025*neck;row=[]
  for a in theta:row.append([rx*math.sin(a)+.0015*math.sin(a*5+v*4),height*v+.0012*(1-v)**2*math.sin(a*3),rz*math.cos(a)+.0025*math.sin(a*4+v*2)])
  body.append(row)
 body=np.array(body);bn=normals(body);uv=np.array([[(i/nu*.85/.04,j/nv*.5/.04)for i in range(nu+1)]for j in range(nv+1)]);connected=np.load(R/'connected-coat-body-clean.npz');vertices=connected['vertices'];faces=connected['faces'];raw=[C.B.solid('connected-hollow-soft-fleece-body-and-sleeves','cloth',[tuple(v)for v in vertices],[tuple(f)for f in faces],[(float(v[0]/.04),float(v[1]/.04))for v in vertices])]
 collar=[]
 for t in np.linspace(0,1,5):
  row=[]
  for i,beta in enumerate(np.linspace(.415,TAU-.415,nu+1)):
   a=1.5*math.pi+beta;neck=np.array([.075*math.cos(a),.525,-.020-.055*math.sin(a)]);row.append(body[-1,i]*(1-t)+neck*t)
  collar.append(row)
 collar=np.array(collar);raw.append(C.shell('physical-neck-yoke-joining-body-to-hood','cloth',collar,normals(collar),.0038,np.array([[(i/nu*.4/.04,j/4*.025/.04)for i in range(nu+1)]for j in range(5)])))
 # An annular cloth hood joins the neck opening to a smaller pear-shaped face opening;
 # the upper back billows naturally instead of forming a detached spherical bowl.
 N=72;hoodv=[];hooduv=[];hoodf=[]
 for j,t in enumerate(np.linspace(0,1,30)):
  for i in range(N):
   a=TAU*i/N;nx=.075*math.cos(a);nz=-.020-.055*math.sin(a);fx=.125*math.cos(a)*(.65+.35*math.sin(a));fy=.595+.075*math.sin(a);billow=math.sin(math.pi*t);hoodv.append(((1-t)*nx+t*fx+.030*math.cos(a)*billow,(1-t)*.525+t*fy+.10*billow*max(0,math.sin(a)),(1-t)*nz+t*.075-.070*billow*max(0,math.sin(a))));hooduv.append((i/N*.50/.04,t*.22/.04))
 for j in range(29):
  for i in range(N):a=j*N+i;b=j*N+(i+1)%N;c=a+N;d=b+N;hoodf.extend([(a,b,c),(b,d,c)])
 raw.append(A.open_surface_shell('hollow-hood-real-face-and-neck-openings','cloth',hoodv,hoodf,[list(range(N-1,-1,-1)),list(range(29*N,30*N))],hooduv,.0038))
 opening=[hoodv[29*N+i]for i in range(N)];raw.append(A.closed_tube('turned-soft-hood-opening-edge','hem',opening,.0050,10))
 for sign in[-1,1]:
  sleeve=[]
  for t in np.linspace(0,1,30):
   centre=np.array([sign*(.126+.091*t),.445-.240*t,.004+.014*t]);tangent=np.array([sign*.091,-.240,.014]);tangent/=np.linalg.norm(tangent);a=np.cross(tangent,[0,0,1]);a/=np.linalg.norm(a);b=np.cross(tangent,a);radius=.055-.012*t;row=[]
   for angle in np.linspace(0,TAU,49):row.append(centre+radius*(a*math.cos(angle)+b*math.sin(angle))*(1+.035*math.sin(angle*4+t*5)))
   sleeve.append(row)
  sleeve=np.array(sleeve);sv=[tuple(v)for row in sleeve[:,:-1]for v in row];suv=[(i/48*.28/.04,j/29*.26/.04)for j in range(30)for i in range(48)];sf=[]
  for j in range(29):
   for i in range(48):a=j*48+i;b=j*48+(i+1)%48;c=a+48;d=b+48;sf.extend([(a,c,b),(b,c,d)])
  root_vertex=len(sv);sv.append(tuple(np.mean(sleeve[0,:-1],axis=0)));suv.append((.5,0))
  for i in range(48):sf.append((root_vertex,(i+1)%48,i))
  raw.append(A.closed_tube(('left'if sign<0 else'right')+'-soft-open-cuff','hem',sleeve[-1,:-1],.0045,10))
  raw.append(ellipsoid(('left'if sign<0 else'right')+'-rounded-bear-ear','cloth',(sign*.071,.688,-.030),(.025,.029,.010)))
 raw.append(C.ribbon('separate-soft-waist-belt','hem',body,bn,0,1,.51,.59,.0025,.005,steps_u=128,steps_v=8))
 raw.append(ellipsoid('soft-belt-tie-knot','hem',(0,.276,.096),(.021,.014,.014)))
 for sign in[-1,1]:
  tail=[]
  for v in np.linspace(0,1,32):tail.append([[sign*.014+.028*(u-.5)+sign*.008*math.sin(v*3),.275-.17*v,.101+.004*math.sin(v*5)+.003*math.sin(u*3+v)]for u in np.linspace(0,1,9)])
  tail=np.array(tail);raw.append(C.shell(('left'if sign<0 else'right')+'-free-hanging-fabric-belt-end','hem',tail,normals(tail),.0026,np.array([[(i/8*.028/.04,j/31*.17/.04)for i in range(9)]for j in range(32)])))
 for name,centre in[('left',.085),('right',.915)]:
  raw.append(C.ribbon(name+'-raised-open-top-patch-pocket','cloth',body,bn,centre-.04,centre+.04,.235,.445,.0028,.0065,steps_u=16,steps_v=18,bridge=.003))
  path=[C.sample(body,bn,float(u),.445)[0]+C.sample(body,bn,float(u),.445)[1]*.0065 for u in np.linspace(centre-.04,centre+.04,33)];raw.append(C.tube(name+'-pocket-open-top-soft-lip','hem',path,.0024,8))
 def materials(out):
  m=A.L.materials(sku,dict(recipe='fleece',rgb=[202,186,167]),out);N=2048;rng=np.random.default_rng(int(sku));noise=rng.uniform(0,255,(N,N)).astype(np.uint8);smooth=np.array(Image.fromarray(noise).filter(ImageFilter.GaussianBlur(.65)),dtype=float)/255;fine=rng.normal(0,.008,(N,N));h=smooth*.27+fine;dy,dx=np.gradient(h);n=np.stack((-dx*3,-dy*3,np.ones_like(h)),axis=2);n/=np.linalg.norm(n,axis=2,keepdims=True);Image.fromarray(np.clip((n+1)*127.5,0,255).astype(np.uint8),'RGB').save(out/(sku+'-normal.png'),optimize=True);orm=np.zeros((N,N,3),np.uint8);orm[:,:,0]=255;orm[:,:,1]=248;Image.fromarray(orm,'RGB').save(out/(sku+'-orm.png'),optimize=True);return m
 aid='hm-'+sku+'-hollow-hooded-bear-robe-photo-scale';note='Ürün kimliği ve kendi resmî JPEG fotoğrafı doğrulanmıştır. Ürünün santimetreyle giysi ölçüsü bulunamadığı için bu gösterim yaklaşık çocuk sabahlığı ölçeğinde kurulmuştur; hiçbir santimetre değeri resmî ölçü sayılmaz. Yaklaşık 72 cm yüksekliğindeki fiziksel yorumda içi boş gövde, yüz ve boyun açıklıkları olan kapüşon, içi boş açık manşetli kollar, ayı kulakları, ayrı kuşak uçları ve üstü açık yama cepleri bulunur. Gizli kesim kalıbı, cep/kuşak/kapüşon ölçüleri ve poların optiği fotoğraf yorumudur.';meta=A.base_metadata(sku,aid,{},note,'fleece',estimated_fields=['all_physical_centimetre_dimensions_photo_scale','garment_cut_pattern','hood_sleeve_pocket_and_belt_profiles','fleece_colour_fibre_and_optics']);meta['variant_status_verbatim']='Exact SKU kaynak fotoğrafı; giysinin fiziksel ölçeği ve gizli kalıbı doğrulanmadı';meta['quality_label']='Fotoğraf ölçeği yorumu · resmî giysi ölçüsü yok';meta['estimated_photo_scale_height_cm']=72;meta['robe_features']=dict(hollow_hood_face_opening=True,hollow_hood_neck_opening=True,hollow_open_sleeves=2,mannequin_included=False,bear_ears=2,separate_belt_ends=2,raised_open_top_pockets=2);return A.finish(raw,meta,materials,features=meta['robe_features'])
if __name__=='__main__':
 for sku in sys.argv[1:]:build(sku)
