"""Remaining six actual-open hemstitch assets; old prototype stays immutable."""
from pathlib import Path
import sys, json, inspect, copy
sys.dont_write_bytecode=True
T=Path(__file__).resolve().parent;sys.path.insert(0,str(T))
import build_real_hemstitch as H
D=T/'hemstitch-family-batch01';D.mkdir(exist_ok=True);H.D=D;H.A.R=D
COLOURS={'1307623007':[151,171,195],'1307623017':[151,5,33],
         '1307623018':[30,53,31],'1336214002':[234,232,222],
         '1336214003':[151,170,193],'1336214009':[29,51,30]}
H.CONFIG={sku:dict(rgb=rgb,recipe='cotton',hem=.025,gap=.0009,thread_spacing=.0024,
                  weave_period_m=.00022 if sku.startswith('1307623')else .00018,
                  normal_scale=.42,intrinsic_ao=True)for sku,rgb in COLOURS.items()}
RESEARCH={
 '1307623007':dict(composition=['Cotton 100%'],source_urls=['https://www2.hm.com/en_in/productpage.1307623007.html'],
                  thread_count=240,hem_turn_cm=2.5),
 '1307623017':dict(composition=['Cotton 100%'],source_urls=['https://www2.hm.com/es_mx/productpage.1307623017.html'],
                  thread_count=240,hem_turn_cm=2.5),
}
BASE=H.A.base_metadata
def base_metadata(sku,aid,ignored_official,ignored_note,recipe,**kw):
    size=H.A.L.EVIDENCE[sku]['official_flat_size_cm']
    verified=sku!='1336214003';thread=240 if sku.startswith('1307623')else 350
    official=dict(flat_item_size_cm=size)
    if verified:official.update(hem_turn_cm=2.5,thread_count=thread)
    if sku in RESEARCH:
        r=RESEARCH[sku]
        H.A.L.EVIDENCE[sku]['supplement']=dict(composition=r['composition'],exact_sku_identity_verified=True,
            source_urls=r['source_urls'],evidence_file=str(T/'source-evidence'/('public-reader-hemstitch-'+sku+'.txt')))
    note=(f'Resmî düz ürün ölçüsü {size[0]:g}×{size[1]:g} cm. '+
          (f'{thread} tel pamuk ve 2,5 cm kenar kıvrımı exact SKU ürün açıklamasından doğrulandı. 'if verified else
           'Yerel 2,5 cm kenar ve ince pamuk görünümü kendi fotoğrafından yorumlandı; bu SKU için tel sayısı ve hem genişliği resmî ölçü olarak doğrulanamadı. ')+
          'Ajur hattı gerçek boş bant ve ayrı iplik köprüleridir; altında opak kumaş yoktur. '
          '0,9 mm açıklık, yaklaşık 2,4 mm iplik grubu aralığı, yerel iplik/kalınlık, renk ve yerçekimi pozu fotoğraf yorumudur; üretici işleme deseni veya CAD değildir.')
    meta=BASE(sku,aid,official,note,recipe,**kw)
    if not verified:meta['estimated_fields']+=['hem_width_and_fine_weave_scale_no_exact_PDP_construction']
    if sku in RESEARCH:
        meta['source_evidence_files'].append(str(T/'source-evidence'/('public-reader-hemstitch-'+sku+'.txt')))
    return meta
H.A.base_metadata=base_metadata
# Reuse the reviewed geometry function, with optional own-gallery evidence.
# Other-colour gallery images are never falsely assigned to an exact SKU.
source=inspect.getsource(H.build)
old="gallery=next(e for e in json.loads((T/'gallery-originals/masters.json').read_text())if e['sku']==sku);meta['original_images'].append({k:gallery[k]for k in['path','url','sha256']});"
new="gallery=next((e for e in json.loads((T/'gallery-originals/masters.json').read_text())if e['sku']==sku),None);meta['original_images']+=([{k:gallery[k]for k in['path','url','sha256']}]if gallery else[]);"
assert old in source;source=source.replace(old,new)
source=source.replace("meta['source_evidence_files'].append(str(extra));", "meta['source_evidence_files']+=([str(extra)]if extra.exists()else[]);")
namespace=H.__dict__;exec(compile(source,str(__file__)+':approved-openwork-function','exec'),namespace)
if __name__=='__main__':
    for sku in (list(COLOURS)if '--all'in sys.argv else sys.argv[1:]):H.build(sku)
