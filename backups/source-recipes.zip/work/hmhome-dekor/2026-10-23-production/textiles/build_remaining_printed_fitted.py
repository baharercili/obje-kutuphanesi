"""Remaining eleven exact-SKU printed fitted sheets, including qualified sizes.

Every material donor is that SKU's immutable taut-mattress original. No other
colour or size product donates artwork. The crop excludes the bed silhouette,
floor and fold. Pattern repeat remains explicitly photo interpreted.
"""
from pathlib import Path
import sys, json, copy, inspect
sys.dont_write_bytecode=True
import numpy as np
from PIL import Image
T=Path(__file__).resolve().parent;sys.path.insert(0,str(T))
import build_printed_fitted_prototypes as P
import build_plain_fitted_batch as G
A,C=P.A,P.C
D=T/'remaining-printed-fitted-batch01';D.mkdir(exist_ok=True);G.D=D;A.R=D
IDS=['1028613078','1224355011','1224357010','1224357011','1224358010','1224359010',
     '1283408005','1283409005','1283409006','1283410006','1354469002']
G.ESTIMATED.update({'1224359010':[180,200],'1283410006':[180,200]})
P.MASTERS=[G.A.L.EVIDENCE[sku]['original']for sku in IDS]
P.CONFIG={}
G.PALETTE={}
for sku in IDS:
    ev=G.A.L.EVIDENCE[sku];master=ev['original']
    P.CONFIG[sku]=dict(file=Path(master['path']).name,quad=[50,950,50,1400,1450,1900,1450,1450],
                       output=[1320,400],repeat=[.5,.175])
    G.PALETTE[sku]=dict(sku=sku,own_original=master,rgb_median=[235,235,230],
                        palette_not_used_for_print=True,native_own_print_instead=True)
# Reuse the accepted hollow shell. The ID describes the final printed asset.
source=inspect.getsource(G.build).replace("'-plain-fitted-'","'-native-printed-fitted-'")
exec(compile(source,str(__file__)+':accepted-hollow-fitted-function','exec'),G.__dict__)
ORIGINAL=A.L.materials
def material(sku,f,out):
    A.L.materials=ORIGINAL
    try:mats=P.native_material(sku,out)
    finally:A.L.materials=material
    if sku.startswith('12834'):
        # The source identifies a cotton sateen weave. Give that weave a
        # restrained smoother response, rather than the coarse linen finish.
        path=out/(sku+'-orm.png')
        with Image.open(path)as im:orm=np.array(im)
        orm[:,:,1]=np.clip(orm[:,:,1].astype(float)-48,172,205).astype(np.uint8)
        Image.fromarray(orm).save(path,optimize=True)
        for key in ('cloth','hem'):
            mats[key]['normalScale']=.28
            mats[key]['extras'].update(source_weave='sateen',optical_values_photo_interpreted=True)
    return mats
def build(sku):
    A.L.materials=material
    try:e=G.build(sku)
    finally:A.L.materials=ORIGINAL
    out=Path(e['asset_dir']);model=json.loads(Path(e['model_path']).read_text());meta=model['metadata'];cfg=P.CONFIG[sku]
    meta.update(quality_status='photo_interpretation',quality_label='Kendi desen fotoğrafı · Tekrar yerleşimi yaklaşık'+
        (' · Yatak ölçüsü yaklaşık'if not G.A.L.EVIDENCE[sku]['official_flat_size_cm']else''),
        native_texture_resolution='Native1320×400 own-SKU taut-fabric print crop +2048 intrinsic textile PBR',
        photo_pixels_baked=True,baked_reflections=False,
        print_pattern_interpretation=dict(native_donor=meta['original_image'],native_donor_sha256=meta['original_image_sha256'],
            repeat_metres=cfg['repeat'],repeat_officially_verified=False,hidden_layout_unconfirmed=True,
            studio_illumination_removed=True,local_display_footprint_may_be_estimated=True))
    meta['estimated_fields']+=['print_repeat_scale_and_hidden_pattern_layout']
    meta['source_evidence_files'].append(str(out/'native-print-provenance.json'))
    meta['scale_note']+=' Desen yalnız bu SKU’nun kendi orijinal JPEG’indeki gergin düz kumaştan, tek geometrik örneklemeyle ve piksel büyütmeden alındı. Geniş fotoğraf ışığı giderildi. Desen tekrar ölçeği ve görünmeyen yerleşim fotoğraf yorumudur; üretici baskı dosyası değildir.'
    meta['diameter_semantics']=meta['scale_note']
    C.dump(Path(e['model_path']),model);doc,binary=C.read_glb(e['glb_path']);doc['extras']['metadata']=meta
    for mat in doc['materials']:
        if mat['name']in('cloth','hem'):
            mat['pbrMetallicRoughness']['baseColorTexture'].setdefault('extensions',{})['KHR_texture_transform']=dict(scale=[.04/cfg['repeat'][0],.04/cfg['repeat'][1]])
    doc['extensionsUsed']=sorted(set(doc['extensionsUsed'])|{'KHR_texture_transform'});C.write_glb(e['glb_path'],doc,binary)
    for key in ('quality_status','quality_label','source_evidence_files','scale_note','diameter_semantics','estimated_fields'):
        e[key]=meta[key]
    e['native_print_provenance']=str(out/'native-print-provenance.json');e['sha256']=C.sha(e['glb_path']);e['bytes']=Path(e['glb_path']).stat().st_size
    C.dump(out/'entry.json',e);reportpath=out/(e['id']+'.validation.json');report=json.loads(reportpath.read_text())
    report['deliverable_sha256']['glb']=e['sha256'];report['glb_bytes']=e['bytes'];C.dump(reportpath,report)
    manifest=D/'candidate-remaining-printed-fitted-manifest.json';rows=json.loads(manifest.read_text())if manifest.exists()else[]
    C.dump(manifest,[x for x in rows if x['sku']!=sku]+[e]);print('OWN NATIVE PRINTED FITTED',sku,flush=True)
    return e
if __name__=='__main__':
    for sku in(IDS if '--all'in sys.argv else sys.argv[1:]):build(sku)
