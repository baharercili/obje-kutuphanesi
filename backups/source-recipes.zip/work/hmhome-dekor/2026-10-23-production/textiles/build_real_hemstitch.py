"""Real hemstitch openings and bundled thread bridges on the approved gravity pose.

No opaque cloth is left underneath the open band. Header/perimeter width is
source-specific; microscopic gap and thread grouping remain interpretations.
"""
from pathlib import Path
import json,sys,math,copy
import numpy as np
sys.dont_write_bytecode=True
T=Path(__file__).resolve().parent;sys.path.insert(0,str(T));import build_soft_linen_revision as B
A=B.A;C=B.C;D=T/'hemstitch-prototypes01';D.mkdir(exist_ok=True);A.R=D
CONFIG={'1336214008':dict(rgb=[149,8,37],recipe='cotton',hem=.025,gap=.0009,thread_spacing=.0024,weave_period_m=.00018,normal_scale=.42,intrinsic_ao=True)}
def patch(label,grid,n,u0,u1,v0,v1,nu,nv,w,l,t):
    p=[];norm=[];uv=[]
    for v in np.linspace(v0,v1,nv+1):
        rr=[];nn=[];tt=[]
        for u in np.linspace(u0,u1,nu+1):point,normal=C.sample(grid,n,float(u),float(v));rr.append(point);nn.append(normal);tt.append([u*w/.04,v*l/.04])
        p.append(rr);norm.append(nn);uv.append(tt)
    return C.shell(label,'cloth',np.array(p),np.array(norm),t,np.array(uv))
def merge_solids(parts,name,material):
    vertices=[];faces=[];uv=[]
    for part in parts:
        offset=len(vertices);vertices+=part['_vertices'];faces +=[tuple(i+offset for i in face)for face in part['_faces']];uv+=part['_uvs']
    return C.B.solid(name,material,vertices,faces,uv)
def build(sku):
    assert sku in CONFIG;f=CONFIG[sku];ev=A.L.EVIDENCE[sku];size=ev['official_flat_size_cm'];w,l=[v/100 for v in size];cache=D/(sku+'-uncut-reference-pose.npz')
    if cache.exists():q=np.load(cache);grid=q['grid'];norm=q['normals'];proof=json.loads(cache.with_suffix('.json').read_text())
    else:grid,norm,proof=B.S.table_gravity(w,l,int(sku)%1000003);np.savez_compressed(cache,grid=grid,normals=norm);C.dump(cache.with_suffix('.json'),proof)
    hem=f['hem'];gap=f['gap'];u0=(hem+gap)/w;u1=1-u0;v0=(hem+gap)/l;v1=1-v0;domains=[('centre-woven-cloth',u0,u1,v0,v1,100,160),('near-turned-hem',0,1,0,hem/l,100,4),('far-turned-hem',0,1,1-hem/l,1,100,4),('left-turned-hem',0,hem/w,hem/l,1-hem/l,4,160),('right-turned-hem',1-hem/w,1,hem/l,1-hem/l,4,160)];raw=[];t=.00045
    for name,aa,bb,cc,dd,nu,nv in domains:raw.append(patch(name,grid,norm,aa,bb,cc,dd,nu,nv,w,l,t))
    threads=[];cell_counts={}
    # Only slender sewn bundles span the actual open band. Two nearby yarns
    # per group leave a finite, visible hole between successive groups.
    for side in ['near','far','left','right']:
        horizontal=side in ['near','far'];span=w-2*hem if horizontal else l-2*hem;count=max(1,int(span/f['thread_spacing']));cell_counts[side]=count
        for i in range(count):
            along=hem+(i+.5)*span/count
            for strand in [-1,1]:
                points=[]
                for q in np.linspace(0,1,3):
                    cross=hem-.00018+(gap+.00036)*q;aa=along+strand*.00013
                    if side=='near':u,v=aa/w,cross/l
                    elif side=='far':u,v=aa/w,1-cross/l
                    elif side=='left':u,v=cross/w,aa/l
                    else:u,v=1-cross/w,aa/l
                    p,n=C.sample(grid,norm,u,v);points.append(p+n*(.00027+.00007*math.sin(math.pi*q)))
                threads.append(C.tube('bundled-sewn-bridge','thread',points,radius=.000075,sides=5))
    raw.append(merge_solids(threads,'separate-bundled-hemstitch-thread-bridges','thread'));aid='hm-'+sku+'-gravity-real-open-hemstitch-r1';note=f'Resmî düz ürün ölçüsü {size[0]:g}×{size[1]:g} cm, 350 tel pamuk ve 2,5 cm kenar kıvrımı exact SKU ürün açıklamasından doğrulandı. Ajur hattı gerçek boş bant ve ayrı iplik köprüleridir; altında opak kumaş yoktur. 0,9 mm açıklık, 2,4 mm yaklaşık iplik grubu aralığı, yerel iplik/kalınlık ve yerçekimi pozu fotoğraf yorumudur; üretici işleme deseni veya CAD değildir.';meta=A.base_metadata(sku,aid,dict(flat_item_size_cm=size,hem_turn_cm=2.5,thread_count=350),note,'fine_cotton_hemstitch',estimated_fields=['gravity_pose_and_box_dimensions','openwork_gap_and_thread_bundle_spacing','thread_radius_and_cloth_thickness','source_colour_and_optics']);meta['source_dimensions_hwd_cm']=[None,size[0],size[1]];meta['hemstitch_features']=dict(opaque_underlay_absent=True,actual_open_band_gap_m=gap,hem_turn_m=hem,thread_group_spacing_interpreted_m=f['thread_spacing'],bundled_strands_per_group=2,groups_by_edge=cell_counts,patches=[dict(name=name,uv_domain=[aa,bb,cc,dd],grid_nu=nu,grid_nv=nv)for name,aa,bb,cc,dd,nu,nv in domains],full_reference_pose_metric=proof,flat_reference_size_cm=size);meta['quality_status']='photo_interpretation';meta['quality_label']='Gerçek ajur delikleri · Yerel dikiş ölçeği yorum'
    extra=T/'source-evidence'/(sku+'.json');meta['source_evidence_files'].append(str(extra));gallery=next(e for e in json.loads((T/'gallery-originals/masters.json').read_text())if e['sku']==sku);meta['original_images'].append({k:gallery[k]for k in['path','url','sha256']});entry=A.finish(raw,meta,lambda out:B.material(sku,f,out),features=meta['hemstitch_features']);doc,binary=C.read_glb(entry['glb_path'])
    for mat in doc['materials']:
        if mat['name']=='cloth':mat['occlusionTexture']={**mat['pbrMetallicRoughness']['metallicRoughnessTexture'],'strength':.55}
    C.write_glb(entry['glb_path'],doc,binary);entry['sha256']=C.sha(entry['glb_path']);entry['bytes']=Path(entry['glb_path']).stat().st_size;out=Path(entry['asset_dir']);C.dump(out/'entry.json',entry);reportpath=out/(aid+'.validation.json');report=json.loads(reportpath.read_text());report['deliverable_sha256']['glb']=entry['sha256'];report['glb_bytes']=entry['bytes'];C.dump(reportpath,report);manifest=D/'candidate-real-hemstitch-manifest.json';rows=json.loads(manifest.read_text())if manifest.exists()else[];C.dump(manifest,[e for e in rows if e['sku']!=sku]+[entry]);print('REAL HEMSTITCH CANDIDATE',sku,cell_counts,flush=True)
if __name__=='__main__':
    for sku in sys.argv[1:]:build(sku)
