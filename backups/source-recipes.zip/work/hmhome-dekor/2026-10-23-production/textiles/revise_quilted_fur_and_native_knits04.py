"""Separate six-product revision: real recessed fur grid and native yarn detail.

Approved seven siblings and all earlier frozen revisions remain byte-identical.
"""
from pathlib import Path
import sys,json,copy,math
import numpy as np
from PIL import Image
sys.dont_write_bytecode=True
T=Path(__file__).resolve().parent;sys.path.insert(0,str(T))
import revise_blanket_material_volume03 as R
M=R.M;A,C=M.A,M.C
D=T/'quilted-fur-native-knit-revision04';D.mkdir(exist_ok=True);R.D=D;M.D=D;A.R=D
for s,p in [('1334640004',.026),('1334640005',.026),('1344119001',.009)]:M.CFG[s]['pile']=p
OLD_FOLD=M.fold
def fold(w,l,seed,kind):
 g,n,uv,p=OLD_FOLD(w,l,seed,kind)
 if kind=='fur_grid':
  U=uv[:,:,0]*w;V=uv[:,:,1]*l;dx=abs((U+.12)%.24-.12);dy=abs((V+.11)%.22-.11)
  puff=(1-np.exp(-(dx/.021)**2))*(1-np.exp(-(dy/.021)**2))
  g=g+n*(.006*puff)[:,:,None]
  n=np.cross(np.gradient(g,axis=0),np.gradient(g,axis=1));n/=np.linalg.norm(n,axis=2,keepdims=True)
  if n[np.unravel_index(g[:,:,1].argmax(),g.shape[:2])][1]<0:n=-n
  p.update(real_sewn_recessed_fur_grid=True,interpreted_puff_to_seam_depth_m=.006,interpreted_grid_spacing_m=[.24,.22])
 return g,n,uv,p
M.fold=fold
def pile_parts(g,n,uv,w,l,sku,cfg):
 low,high,field=R.upper_height(g);N=len(field);rng=np.random.default_rng(int(sku));items=[];roots=[];attempts=0;count=12000
 while len(items)<count and attempts<count*24:
  attempts+=1;u,v=rng.uniform(.002,.998,2);p,nn=M.sample(g,n,uv,u,v)
  if nn[1]<.2:continue
  ix,iy=np.clip(np.rint((p[[0,2]]-low)/(high-low)*(N-1)).astype(int),0,N-1);top=np.max(field[max(0,iy-1):min(N,iy+2),max(0,ix-1):min(N,ix+2)])
  if p[1]<top-.0035:continue
  before,_=M.sample(g,n,uv,u,max(.001,v-.003));after,_=M.sample(g,n,uv,u,min(.999,v+.003));tangent=after-before;tangent-=nn*np.dot(tangent,nn);tangent/=np.linalg.norm(tangent);across=np.cross(nn,tangent);angle=rng.uniform(-.22,.22);tangent=tangent*math.cos(angle)+across*math.sin(angle)
  length=cfg['pile']*rng.uniform(.70,1.20);dx=abs((u*w+.12)%.24-.12);dy=abs((v*l+.11)%.22-.11)
  length*=.06+.94*(dx>.017)*(dy>.017)
  points=[p+nn*.0003,p+nn*length*.35+tangent*length*.35,p+nn*length*.40+tangent*length*.75,p+nn*length*.20+tangent*length]
  items.append(C.tube('source-flowing-pile-with-short-recessed-seams','yarn',points,.00028,sides=3));roots.append(p)
 assert len(items)==count
 roots=np.array(roots);bins=np.floor((roots[:,[0,2]]-low)/(high-low)*16).astype(int);coverage=len({tuple(x)for x in bins})
 C.dump(D/(sku+'-recessed-grid-pile-proof.json'),dict(visible_upper_tufts=count,occupied_top_grid_16x16_cells=coverage,actual_seam_pile_length_ratio=.06,
  seam_half_width_m=.017,puff_to_seam_depth_m=.006,source_flow_direction='Along actual manufactured long-thread direction with restrained local variation'))
 return M.combine('actual-flowing-pile-and-recessed-quilted-grid','yarn',items)
M.pile_parts=pile_parts
OLD_MATERIAL=M.material
def material(sku,cfg,out,w,l):
 mats=OLD_MATERIAL(sku,cfg,out,w,l);ev=M.L.EVIDENCE[sku];box=[720,1210,848,1338];im=Image.open(ev['original']['path']).convert('RGB').crop(box);raw=np.asarray(im,float);N=2048
 fy=np.fft.fftfreq(128)[:,None];fx=np.fft.rfftfreq(128)[None,:];blur=np.exp(-2*math.pi**2*13**2*(fx*fx+fy*fy));illum=np.stack([np.fft.irfft2(np.fft.rfft2(raw[:,:,k])*blur,s=raw.shape[:2])for k in range(3)],2);palette=np.median(raw.reshape(-1,3),0);native=np.clip(raw/np.maximum(1,illum)*palette,0,255);tile=np.tile(native,(16,16,1))
 Image.fromarray(np.uint8(tile)).save(out/(sku+'-own-native-yarn-albedo.png'),optimize=True);im.save(out/'own-native-yarn-crop-evidence.png')
 fine=cfg['kind']in['fine_knit','textured'];repeat=.256
 if fine:
  detail=tile.mean(2)-tile.mean();x=np.arange(N)[None,:]/N*repeat;y=np.arange(N)[:,None]/N*repeat
  a=x/.0014;b=y/.0018;cx=(a+.13*np.sin(np.floor(b)*1.7))%1-.5;cy=b%1-.5;r=np.sqrt((cx/.36)**2+(cy/.43)**2)
  loop=np.exp(-((r-1)/.25)**2);h=loop*.00034+detail*.000010
  dy,dx=np.gradient(h,repeat/N);nn=np.stack([-dx,-dy,np.ones_like(h)],2);nn/=np.linalg.norm(nn,axis=2,keepdims=True);orm=np.zeros((N,N,3),np.uint8);orm[:,:,0]=np.uint8(np.clip(192+63*loop,0,255));orm[:,:,1]=245
  for key,arr in[('normal',np.uint8((nn+1)*127.5)),('orm',orm)]:Image.fromarray(arr).save(out/(sku+'-'+key+'.png'),optimize=True)
 for key in['cloth','hem','lining']:
  mats[key]['baseColorTexture']=sku+'-own-native-yarn-albedo.png';mats[key]['normalScale']=1.1;mats[key]['extras'].update(own_native_yarn_crop=True,native_crop_pixels=[128,128],albedo_repeat_m=repeat,normal_repeat_m=repeat if fine else.04)
 mats['rib']=copy.deepcopy(mats['cloth'])
 mats['yarn']['baseColorTexture']=sku+'-own-native-yarn-albedo.png'
 if fine:
  x=np.arange(N)[None,:]/N*.04;y=np.arange(N)[:,None]/N*.04;h=.00048*np.cos(x/.0020*math.tau)**8+.00013*np.cos(y/.0012*math.tau);dy,dx=np.gradient(h,.04/N);n=np.stack([-dx,-dy,np.ones_like(h)],2);n/=np.linalg.norm(n,axis=2,keepdims=True);Image.fromarray(np.uint8((n+1)*127.5)).save(out/'own-rib-hem-normal.png',optimize=True);mats['rib']['normalTexture']='own-rib-hem-normal.png'
 C.dump(out/'native-yarn-relief-provenance.json',dict(original=ev['original'],native_crop=box,native_pixels=[128,128],own_colour_and_fibre_variation_retained=True,native_crop_tiled_without_resizing=True,
  low_frequency_light_removed=True,albedo_repeat_m=repeat,normal_repeat_m=repeat if fine else.04,source_studio_pixels_projected=False))
 return mats
M.material=material
def rib_parts(g,n,uv,w,l,sku):
 raw=[]
 if M.CFG[sku]['kind']not in['fine_knit','textured']:return raw
 edge=.018 if M.CFG[sku]['kind']=='fine_knit'else.045
 for label,u0,u1,v0,v1 in[('near',0,1,0,edge/l),('far',0,1,1-edge/l,1),('left',0,edge/w,edge/l,1-edge/l),('right',1-edge/w,1,edge/l,1-edge/l)]:
  horizontal=label in['near','far'];NU,NV=(150,5)if horizontal else(5,150);gg=[];nn=[];tt=[]
  for v in np.linspace(v0,v1,NV+1):
   rr=[];nr=[];tr=[]
   for u in np.linspace(u0,u1,NU+1):p,nor=M.sample(g,n,uv,u,v);rr.append(p+nor*.00075);nr.append(nor);tr.append([u*w/.08,v*l/.08])
   gg.append(rr);nn.append(nr);tt.append(tr)
  raw.append(C.shell(label+'-physical-soft-rib-knit-hem','rib',np.array(gg),np.array(nn),.00065,np.array(tt)))
 return raw
M.rib_parts=rib_parts
# Compile original source with the same accepted r3 physical-body corrections.
import build_distinct_blankets as Original
# Original.build has been replaced by r3 exec and inspect points to that virtual
# source; obtain the saved original file AST instead.
import ast
text=(T/'build_distinct_blankets.py').read_text();node=next(x for x in ast.parse(text).body if isinstance(x,ast.FunctionDef)and x.name=='build');source='\n'.join(text.splitlines()[node.lineno-1:node.end_lineno])
source=source.replace("g,n,t,uv*np.array([w/.08,l/.08]))]","g+n*t*.25,n,t*.5,uv*np.array([w/.08,l/.08]))]").replace("g-n*.00125,n,.00055","g-n*t*.25,n,t*.5")
start=source.index(" if kind=='cable_knit':");end=source.index(' official_data=',start);source=source[:start]+" if kind.startswith('fur'):raw.append(pile_parts(g,n,uv,w,l,sku,cfg))\n raw+=rib_parts(g,n,uv,w,l,sku)\n"+source[end:]
source=source.replace("'-source-specific-soft-folded-'","'-source-specific-soft-folded-native-quilt-r4-'")
source=source.replace('Dört fiziksel katlı sürekli örtü pozu',"'+str(proof['folded_layers'])+' fiziksel katlı sürekli örtü pozu")
exec(compile(source,str(__file__)+':quilt-grid-and-native-knit','exec'),M.__dict__)
if __name__=='__main__':
 for sku in sys.argv[1:]:M.build(sku)
