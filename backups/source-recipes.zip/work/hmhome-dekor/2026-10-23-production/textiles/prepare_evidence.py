from pathlib import Path
import json,collections,re,hashlib,unicodedata
R=Path(__file__).resolve().parent;P=R.parent
q=json.loads((R/'source-queue-186.json').read_text());research={x['sku']:x for x in json.loads((P/'root/textile-primary-research.json').read_text())['products']};anchors=json.loads((P/'official-grid-size-anchors-all.json').read_text())['products'];neighbours=json.loads((R/'exact-card-neighbour-evidence.json').read_text());masters={}
for x in json.loads((P/'root/original-image-masters.json').read_text()):masters.setdefault(x['sku'],x)
def norm(s):return ''.join(c for c in unicodedata.normalize('NFKD',s.casefold())if not unicodedata.combining(c)).replace('ı','i')
def family(x):
 n=norm(x['name'])
 for needles,label in [(['braçol'],'fabric_tieback_pair'),(['hediye seti'],'baby_gift_set'),(['uyku arkadaşı'],'animal_comforter'),(['sabahlık'],'hooded_child_robe'),(['banyo eldiveni'],'animal_bath_mitt'),(['fırın eldiveni'],'oven_mitt_and_potholder'),(['şef seti'],'child_apron_and_chef_hat'),(['önlüğü'],'apron'),(['duş perdesi'],'eyelet_shower_curtain'),(['lastikli'],'fitted_sheet'),(['alez'],'mattress_protector'),(['üst çarşaf'],'flat_sheet'),(['peçete'],'napkin_set'),(['kurulama','tea towels'],'kitchen_towel_set'),(['hand towel'],'terry_hand_towel'),(['runner'],'runner'),(['yuvarlak masa'],'round_tablecloth'),(['masa örtüsü','tablecloth'],'rect_tablecloth'),(['yatak örtüsü'],'bedspread'),(['yatak şalı','battaniye'],'throw_or_baby_blanket')]:
  if any(norm(needle)in n for needle in needles):return label
 raise ValueError(n)
supplement={
 '1282416001':dict(flat_size_cm=[45,45],market='en_in',url='https://www2.hm.com/en_in/productpage.1282416001.html',source_ref='turn1286search0',verbatim_size='45x45: Width: 45 cm, Length: 45 cm',quantity=4,composition=['Linen55%, Cotton45%']),
 '1310624001':dict(flat_size_cm=[50,50],market='en_in',url='https://www2.hm.com/en_in/productpage.1310624001.html',source_ref='turn1286search9',verbatim_size='Size: 50X50',quantity=2,composition=['Linen100%']),
 '1067094001':dict(flat_size_cm=[180,200],market='en_in',url='https://www2.hm.com/en_in/productpage.1067094001.html',source_ref='turn1286search2',verbatim_size='180x200: Width: 1.80 m, Length: 2 m',quantity=1,composition=['Shell:Polyester100%','Lining:Polyester100%']),
 '1257781002':dict(flat_size_cm=[11,60],market='tr_tr',url='https://www2.hm.com/tr_tr/productpage.1257781002.html',source_ref='root/textile-primary-research.json',verbatim_size='Genişlik 11 cm. Uzunluk 60 cm.',quantity=2),
}
if(R/'additional-exact-research.json').exists():supplement.update(json.loads((R/'additional-exact-research.json').read_text()))
records=[]
for x in q:
 sku=x['sku'];master=masters[sku];assert hashlib.sha256(Path(master['path']).read_bytes()).hexdigest()==master['sha256'];a=anchors.get(sku);r=research[sku];dims=a['unique_size_tags_cm'][0]if a else None;diameter=None;market='Türkiye';s=supplement.get(sku)
 if not dims:
  for e in neighbours.get(sku,[]):
   z=e['preceding_lines'][-1]if e['preceding_lines']else'';m=re.fullmatch(r'(?:D|Ø)\s*(\d+(?:[.,]\d+)?)\s*cm',z)
   if m:diameter=float(m[1].replace(',','.'));a=dict(anchors=[dict(**e,verbatim_size_tag=z,diameter_cm=diameter)])
 if not dims and s:dims=s.get('flat_size_cm');market=s.get('market');a=dict(exact_official_pdp_supplement=s,evidence_file=str(R/'exact-first4-search.raw.txt'))
 records.append(dict(sku=sku,source=x,family=family(x),original=master,official_flat_size_cm=dims,official_diameter_cm=diameter,size_source_market=market,size_evidence=a,primary_research=r,supplement=s,official_composition_verified=r['exact_sku_identity_verified']and bool(r['composition_lines'])or bool(s and s.get('composition')),unknown_scale=not(dims or diameter)))
(R/'production-source-evidence-186.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n');print('Families',dict(collections.Counter(x['family']for x in records)));print('Official cm',sum(not x['unknown_scale']for x in records),'composition',sum(x['official_composition_verified']for x in records))
