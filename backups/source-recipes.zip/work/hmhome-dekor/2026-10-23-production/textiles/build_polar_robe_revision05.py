"""Own-native short irregular polar, physical belt UVs and a softly collapsed hood."""
from pathlib import Path
import sys,copy,json,numpy as np
sys.dont_write_bytecode=True
T=Path(__file__).resolve().parent;sys.path.insert(0,str(T))
import build_shawl_hood_robe04 as U
import robe_soft_surface as S
import native_surface_materials as N
R=U.R;M=R.M;A=M.A;C=M.C
D=T/'robes-own-polar-hood-revision05';D.mkdir(exist_ok=True);A.R=D

def physical_ribbon_uv(q,rows,cols):
 p=np.array(q['_vertices']);count=rows*cols;assert len(p)==2*count,(q['name'],len(p));grid=((p[:count]+p[count:])*.5).reshape(rows,cols,3)
 u=np.concatenate([np.zeros((rows,1)),np.cumsum(np.linalg.norm(np.diff(grid,axis=1),axis=2),axis=1)],axis=1)/.04
 v=np.concatenate([np.zeros((1,cols)),np.cumsum(np.linalg.norm(np.diff(grid,axis=0),axis=2),axis=0)],axis=0)/.04
 uv=np.stack([u,v],2).reshape(-1,2);q['_uvs']=[tuple(x)for x in np.concatenate([uv,uv])]
 return dict(name=q['name'],physical_u_arc_m=[float(x)for x in u[:,-1]*.04],physical_v_arc_m=[float(x)for x in v[-1]*.04],collapsed_uv_removed=True)

def materials(sku,out):
 master=A.L.EVIDENCE[sku]['original']['path'];maps=N.fleece(master,[700,1500,828,1628],out,int(sku))
 cloth=dict(baseColorFactor=[1,1,1,1],baseColorTexture=maps['albedo'],normalTexture=maps['normal'],metallicRoughnessTexture=maps['orm'],normalScale=.85,metallic=1,roughness=1,doubleSided=False,alphaMode='OPAQUE',extras=dict(fabric='own-native short irregular polar fleece',normal_repeat_m=.04,albedo_repeat_m=.128,regular_knit_loops=False))
 return dict(cloth=cloth,hem=copy.deepcopy(cloth))

def finish(raw,meta,old,features=None):
 proofs=[]
 for q in raw:
  p=np.array(q['_vertices'])
  if q['name'].endswith('rounded-bear-ear'):
   centre=(p.min(0)+p.max(0))*.5;p=(p-centre)*np.array([.72,.72,.8])+centre
  p[:,0]*=.853
  if q['name']=='hollow-hood-real-face-and-neck-openings':
   # Empty soft hood: let the upper face edge settle backward and sag off-centre.
   upper=np.clip((p[:,1]-.57)/.095,0,1);front=np.clip((p[:,2]+.015)/.085,0,1)
   p[:,2]-=.033*upper**1.3*front
   p[:,1]-=.017*np.exp(-((p[:,0]-.012)/.052)**2)*upper*front
   p[:,2]+=.003*np.sin(p[:,0]*54+.7)*upper*front
  q['_vertices']=[tuple(v)for v in p];q['_uvs']=[(u*.853,v)for u,v in q['_uvs']]
  if q['name']=='separate-soft-waist-belt':proofs.append(physical_ribbon_uv(q,9,129))
  elif q['name'].endswith('raised-open-top-patch-pocket'):proofs.append(physical_ribbon_uv(q,19,17))
 raw=S.soften(raw,A,C);raw.append(S.pile(raw,A,C,A.H,int(meta['sku']),count=9000))
 meta['id']='hm-'+meta['sku']+'-own-short-polar-soft-collapsed-hood-robe-r5';meta['quality_label']='Kısa polar havı · Yumuşak boş kapüşon · Ölçek yaklaşık';meta['quality_status']='photo_interpretation'
 meta['scale_note']+=' Kendi kaynakJPEG ön silüeti yaklaşık0.636W/H olarak yorumlandı. Polar yüzey kısa düzensiz havlıdır; kapüşonun boş ve hafif çökmüş duruşu fotoğraf yorumudur.';meta['diameter_semantics']=meta['scale_note'];meta['estimated_fields']+=['source_front_photo_silhouette_proportion_fit','short_polar_pile_scale','empty_hood_soft_display_pose']
 meta['robe_features'].update(shoulder_cloth_intact_local_neck_opening=True,regular_large_knit_normal_removed=True,physical_arc_belt_and_pocket_uv=True,softly_collapsed_empty_hood=True)
 e=R.ORIGINAL_FINISH(raw,meta,lambda out:materials(meta['sku'],out),features=meta['robe_features']);doc,binary=C.read_glb(e['glb_path'])
 for mat in doc['materials']:
  base=mat['pbrMetallicRoughness'].get('baseColorTexture')
  if base:base.setdefault('extensions',{})['KHR_texture_transform']=dict(scale=[.04/.128]*2)
  mat.setdefault('extensions',{})['KHR_materials_sheen']=dict(sheenColorFactor=[.27,.25,.23],sheenRoughnessFactor=1.)
 doc['extensionsUsed']=sorted(set(doc['extensionsUsed'])|{'KHR_texture_transform'});C.write_glb(e['glb_path'],doc,binary);e['sha256']=C.sha(e['glb_path']);e['bytes']=Path(e['glb_path']).stat().st_size;out=Path(e['asset_dir']);C.dump(out/'entry.json',e);C.dump(out/'physical-ribbon-uv-proof.json',proofs)
 rp=out/(meta['id']+'.validation.json');r=json.loads(rp.read_text());r['deliverable_sha256']['glb']=e['sha256'];r['glb_bytes']=e['bytes'];C.dump(rp,r);C.dump(D/'candidate-own-polar-robe-manifest.json',[e]);return e
M.A.finish=finish
if __name__=='__main__':M.build('1237612002')
