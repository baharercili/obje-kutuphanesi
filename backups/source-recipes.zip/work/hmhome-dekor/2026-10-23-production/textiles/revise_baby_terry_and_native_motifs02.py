"""Keep native elephant facial/letter details and genuine terry microstructure.

Whole mitt/flannel albedos have separate domains; normal maps retain independent
40mm metric UVs. Original frozen flat-material candidates stay immutable.
"""
from pathlib import Path
import sys,inspect,json,copy,math
import numpy as np
from PIL import Image,ImageFilter
sys.dont_write_bytecode=True
T=Path(__file__).resolve().parent;sys.path.insert(0,str(T))
import build_two_piece_baby_sets as M
D=T/'baby-terry-native-motif-revision02';D.mkdir(exist_ok=True);M.D=D;M.A.R=D
A,C=M.A,M.C
def radii(y):
 y=float(y);top=np.clip((y-.17)/.03,0,1)
 rx=.075 if y<=.17 else.045+math.sqrt(max(0,.03**2-(y-.17)**2))
 return rx,.0095-.007*(top*top*(3-2*top))
M.M.radii=radii
src=inspect.getsource(M.M.hollow_body).replace('top=H-TH if inner else H','top=H-TH-.0002 if inner else H-.0002')
exec(compile(src,str(__file__)+':rounded-shoulder-mitt','exec'),M.M.__dict__)
ORIG_MOTIF=M.motif
def motif(sku):
 im,box,masks=ORIG_MOTIF(sku)
 if sku.endswith('3'):
  p=np.asarray(im,float);masks['gray']=(p[:,:,0]/(p[:,:,2]+1)<1.09)&(p.mean(2)<198)
 return im,box,masks
M.motif=motif
OLD_STITCHES=M.stitches
def stitches(sku,mapper,name,size):
 raw=OLD_STITCHES(sku,mapper,name,size)
 if sku.endswith('3'):
  for q in raw:
   if q['material']=='gray':
    q['material']='elephant_'+('flannel'if name.startswith('flannel')else'mitt')
    q['_uvs']=[(x/.04,(z if name.startswith('flannel')else y)/.04)for x,y,z in q['_vertices']]
 return raw
M.stitches=stitches
def intrinsic_motif(sku):
 im,box,_=ORIG_MOTIF(sku);p=np.asarray(im,float)
 if sku.endswith('2'):
  alpha=((p[:,:,0]/(p[:,:,1]+1)>1.45)&(p[:,:,0]>80))|((p[:,:,1]>p[:,:,0]*1.02)&(p.max(2)-p.min(2)>10))
  intrinsic=p/np.maximum(1,np.asarray(im.filter(ImageFilter.GaussianBlur(13)),float))
  red=(p[:,:,0]/(p[:,:,1]+1)>1.45);colour=np.where(red[:,:,None],np.array([153,3,30]),np.array([111,141,94]))
 else:
  # Own source silhouette annotation is used only as an alpha boundary. All
  # eyes, ear edges, trunk and 'love you' strokes remain native picture detail.
  _,_,oldmasks=ORIG_MOTIF(sku);yy,xx=np.indices(p.shape[:2])
  text=(yy>210)&(yy<258)&(xx>35)&(xx<205)&(p.mean(2)<190)&((p[:,:,0]-p[:,:,2])<22)
  alpha=(oldmasks['gray']&(yy<=210))|oldmasks['dark']|text
  intrinsic=p/np.maximum(1,np.asarray(im.filter(ImageFilter.GaussianBlur(13)),float));colour=np.broadcast_to(np.array([157,155,143]),p.shape)
 rgba=np.zeros((*alpha.shape,4),np.uint8);rgba[:,:,:3]=np.uint8(np.clip(colour*np.clip(intrinsic,.35,1.30),0,255));rgba[:,:,3]=np.uint8(alpha)*255
 return Image.fromarray(rgba,'RGBA'),box
def materials(sku,out):
 base=M.B.material(sku,dict(recipe='cotton',rgb=[240,238,225],intrinsic_ao=True),out);N=2048;repeat=.04
 x=np.arange(N)[None,:]/N*repeat;y=np.arange(N)[:,None]/N*repeat;px=x/.0022;py=y/.0026;cx=(px+.12*np.sin(np.floor(py)*1.7))%1-.5;cy=py%1-.5;r=np.sqrt((cx/.36)**2+(cy/.43)**2)
 loops=np.exp(-((r-1)/.24)**2)*(1-.38*np.exp(-((cy+.35)/.12)**2));h=loops*.00048;dy,dx=np.gradient(h,repeat/N);n=np.stack([-dx,-dy,np.ones_like(h)],2);n/=np.linalg.norm(n,axis=2,keepdims=True);orm=np.zeros((N,N,3),np.uint8);orm[:,:,0]=np.uint8(182+73*loops);orm[:,:,1]=244
 for key,arr in[('normal',np.uint8((n+1)*127.5)),('orm',orm)]:Image.fromarray(arr).save(out/(sku+'-'+key+'.png'),optimize=True)
 motifim,box=intrinsic_motif(sku);motifim.save(out/'native-own-embroidery-intrinsic.png')
 pink=[238,194,188]if sku.endswith('2')else[183,165,143];mats={k:v for k,v in base.items()if k!='cloth'}
 for role,W,H,NN,centre,size in [('mitt',.15,.20,(750,1000),(0,.108),(.044,.037)),('flannel',.30,.30,(1000,1000),(.10,-.10),(.030,.027))]:
  xx=np.arange(NN[0])[None,:]/NN[0]*W-W/2;stripe=np.broadcast_to((xx%.012)<.006,(NN[1],NN[0]));rgb=np.where(stripe[:,:,None],np.array(pink),np.array([241,239,226]));canvas=Image.fromarray(np.uint8(rgb),'RGB')
  target=(round(size[0]/W*NN[0]),round(size[1]/H*NN[1]));assert target[0]<=motifim.width and target[1]<=motifim.height
  patch=motifim.resize(target,Image.Resampling.LANCZOS)
  # UVv increases with physical+Y on the mitt, so its native text is flipped
  # once into that physical domain; flannel UVv follows its material+Z.
  if role=='mitt':patch=patch.transpose(Image.Transpose.FLIP_TOP_BOTTOM)
  left=round((centre[0]/W+.5)*NN[0]-target[0]/2);top=round(((centre[1]/H)if role=='mitt'else(centre[1]/H+.5))*NN[1]-target[1]/2)
  canvas.paste(patch,(left,top),patch);filename=sku+'-'+role+'-own-stripe-and-native-motif.png';canvas.save(out/filename,optimize=True)
  ma=copy.deepcopy(base['cloth']);ma['baseColorTexture']=filename;ma['normalScale']=1.05;ma['extras'].update(terry_loop_spacing_m=[.0022,.0026],normal_physical_repeat_m=.04,own_native_emblem=True,source_lighting_removed=True)
  mats[role+'_cloth']=ma;mats['elephant_'+role]=copy.deepcopy(ma)
 mats['hem']['baseColorTexture']=None;mats['hem']['baseColorFactor']=[v/255 for v in pink]+[1]
 for name,rgb in[('red',[153,3,30]),('green',[111,141,94]),('gray',[156,155,142]),('dark',[55,47,39])]:mats[name]=dict(baseColorFactor=[c/255 for c in rgb]+[1],metallic=0,roughness=.84,doubleSided=False,alphaMode='OPAQUE')
 C.dump(out/'native-terry-emblem-provenance.json',dict(original=A.L.EVIDENCE[sku]['original'],source_crop=box,native_crop_pixels=list(motifim.size),native_motif_preserved=True,
  resampling='One downsample to each physical cloth domain; no enlargement',terry_loop_spacing_height_m=[.0022,.0026,.00048],normal_repeat_separate_from_albedo=True,source_low_frequency_lighting_removed=True))
 return mats
M.material=materials
src=inspect.getsource(M.build)
src=src.replace("body['name']='actual-hollow15x20cm-baby-bath-mitt'","body['name']='actual-hollow15x20cm-baby-bath-mitt';body['material']='mitt_cloth'")
src=src.replace("items,g,n=flannel()","items,g,n=flannel();items[0]['material']='flannel_cloth'")
src=src.replace("'-two-physical-baby-parts-own-'","'-two-physical-baby-parts-terry-native-r2-'")
exec(compile(src,str(__file__)+':native-face-and-actual-terry','exec'),M.__dict__)
ORIGINAL_BUILD=M.build
def build(sku):
 ORIGINAL_BUILD(sku);p=D/'candidate-baby-two-piece-sets-manifest.json';rows=json.loads(p.read_text());e=next(x for x in rows if x['sku']==sku);doc,binary=C.read_glb(e['glb_path'])
 for mat in doc['materials']:
  if mat['name']in['mitt_cloth','elephant_mitt','flannel_cloth','elephant_flannel']:
   mitt=mat['name']in['mitt_cloth','elephant_mitt'];w,h=(.15,.20)if mitt else(.30,.30)
   mat['pbrMetallicRoughness']['baseColorTexture'].setdefault('extensions',{})['KHR_texture_transform']=dict(scale=[.04/w,.04/h],offset=[.5,0 if mitt else.5])
   mat['occlusionTexture']={**mat['pbrMetallicRoughness']['metallicRoughnessTexture'],'strength':.65}
 doc['extensionsUsed']=sorted(set(doc['extensionsUsed'])|{'KHR_texture_transform'});C.write_glb(e['glb_path'],doc,binary);e['sha256']=C.sha(e['glb_path']);e['bytes']=Path(e['glb_path']).stat().st_size;out=Path(e['asset_dir']);C.dump(out/'entry.json',e);rp=out/(e['id']+'.validation.json');r=json.loads(rp.read_text());r['deliverable_sha256']['glb']=e['sha256'];r['glb_bytes']=e['bytes'];C.dump(rp,r);C.dump(p,[x for x in rows if x['sku']!=sku]+[e]);print('BABY TERRY NATIVE R2',sku,flush=True)
if __name__=='__main__':
 for sku in sys.argv[1:]:build(sku)
