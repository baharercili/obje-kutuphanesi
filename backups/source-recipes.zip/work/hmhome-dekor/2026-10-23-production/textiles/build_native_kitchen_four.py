"""Four kitchen linens: own entire flat-photo glyphs, real cloth and open hangers.

Jacquard is woven colour; the foliage is separately raised satin embroidery.
The native photographs are immutable; only chromatic pigment is extracted.
"""
from pathlib import Path
import sys,json,math,copy
import numpy as np
from PIL import Image
sys.dont_write_bytecode=True
T=Path(__file__).resolve().parent;sys.path.insert(0,str(T))
import build_folded_soft_revision as F
import build_distinct_blankets as H
A,C,B,L=F.A,F.C,F.B,F.L
D=T/'native-kitchen-linens-four-batch01';D.mkdir(exist_ok=True);A.R=D
G=json.loads((T/'gallery-originals/masters.json').read_text())
CFG={
 '1336930001':dict(size=[50,70],rgb=[234,230,215],recipe='linen_blend',image='1336930001-04a6c4691303.jpg',box=[212,390,1307,1908],kind='navy_red',hangers=2),
 '1336930004':dict(size=[50,70],rgb=[234,230,215],recipe='linen_blend',image='1336930004-b10771fda39a.jpg',box=[212,390,1307,1908],kind='black',hangers=2),
 '1350244001':dict(size=[45,60],rgb=[144,22,47],recipe='cotton',image='1350244001-e5a8cafa1e82.jpg',box=[226,432,1315,1878],kind='cream_jacquard',hangers=1),
 '1350245001':dict(size=[45,60],rgb=[234,225,205],recipe='linen_blend',image='1350245001-f3ed44e4deb5.jpg',box=[222,422,1314,1882],kind='embroidery',hangers=2),
}
def master(sku):return next(x for x in G if Path(x['path']).name==CFG[sku]['image'])
def pigments(sku):
 cfg=CFG[sku];im=Image.open(master(sku)['path']).convert('RGB').crop(cfg['box']);p=np.asarray(im,float);rgb=np.broadcast_to(np.array(cfg['rgb'])[None,None,:],p.shape).copy().astype(float)
 if cfg['kind']=='cream_jacquard':
  mask=np.clip((2.05-(p[:,:,0]+1)/(p[:,:,1]+1))/.86,0,1);rgb=rgb*(1-mask[:,:,None])+np.array([232,226,207])*mask[:,:,None]
 elif cfg['kind']=='black':
  mask=np.clip((172-p.mean(2))/95,0,1);rgb=rgb*(1-mask[:,:,None])+np.array([38,36,34])*mask[:,:,None]
 else:
  red=np.clip(((p[:,:,0]+1)/(p[:,:,1]+1)-1.35)/.80,0,1)
  if cfg['kind']=='navy_red':
   blue=np.clip(((p[:,:,2]+1)/(p[:,:,0]+1)-1.015)/.15,0,1)*np.clip((210-p.mean(2))/100,0,1);rgb=rgb*(1-blue[:,:,None])+np.array([49,67,78])*blue[:,:,None]
  rgb=rgb*(1-red[:,:,None])+np.array([112,10,31])*red[:,:,None];mask=red
 return im,np.uint8(np.clip(rgb,0,255)),mask

def materials(sku,out):
 cfg=CFG[sku];m=B.material(sku,dict(recipe=cfg['recipe'],rgb=cfg['rgb'],intrinsic_ao=True,normal_scale=.78),out);im,rgb,mask=pigments(sku);name=sku+'-own-complete-intrinsic-glyphs.png';Image.fromarray(rgb).save(out/name,optimize=True);im.save(out/'own-complete-flat-photo-crop.png')
 for key in ['cloth','hem']:
  m[key]['baseColorTexture']=name;m[key]['extras'].update(whole_original_flat_crop_pixels=list(im.size),studio_luminance_discarded=True,own_exact_native_glyphs_no_font_replacement=True)
 m['embroidery']=dict(baseColorFactor=[112/255,10/255,31/255,1],metallic=0,roughness=.7,doubleSided=False,alphaMode='OPAQUE')
 C.dump(out/'own-complete-glyph-provenance.json',dict(source=master(sku),native_crop=cfg['box'],no_resize_or_upscale=True,only_intrinsic_colour_not_source_luminance=True,whole_visible_motif_layout_from_exact_sku_flat_reference=True,
  hidden_reverse_and_placement_interpreted=True))
 return m

def full_pose(w,l,seed):
 x,z=np.meshgrid(np.linspace(-w/2,w/2,129),np.linspace(-l/2,l/2,161),indexing='ij');phase=seed%89/89*math.tau
 y=.007+ .004*np.sin(x*31+z*15+phase)+.002*np.cos(z*43-x*9)+.004*np.exp(-((x-w*.42)/.033)**2)*(.5+.5*np.sin(z*12+1))+.006*np.exp(-((z+l*.48)/.025)**2)*(.5+.5*np.sin(x*20+.5))
 g=np.stack([x,y,z],2);n=np.cross(np.gradient(g,axis=1),np.gradient(g,axis=0));n/=np.linalg.norm(n,axis=2,keepdims=True);uv=np.stack([(x+w/2)/w,(z+l/2)/l],2);return g,n,uv

def hanger(grid,n,uv,sku,side):
 cfg=CFG[sku];u0,v0=(.5,0)if side=='short'else(1,.5);p,nn=H.sample(grid,n,uv,u0,v0);nn=nn if nn[1]>0 else-nn
 inward,_=H.sample(grid,n,uv,.5,.015)if side=='short'else H.sample(grid,n,uv,.985,.5);tangent=p-inward;tangent/=np.linalg.norm(tangent);across=np.cross(nn,tangent);N=49;strip=[]
 for a in np.linspace(0,math.tau,N):
  centre=p+tangent*(.007+.012*math.cos(a))+nn*(.0018+.003*math.sin(a));strip.append([centre+across*s*.004 for s in[-1,1]])
 strip=np.array(strip);normal=np.cross(np.gradient(strip,axis=1),np.gradient(strip,axis=0));normal/=np.linalg.norm(normal,axis=2,keepdims=True)
 # closed loop with real open hole; periodic path and width boundaries.
 verts=strip[:-1].reshape(-1,3);uvs=[(i/(N-1)*.06/.04,j*.008/.04)for i in range(N-1)for j in range(2)];faces=[]
 for i in range(N-1):a=i*2;b=((i+1)%(N-1))*2;faces +=[(a,b,a+1),(a+1,b,b+1)]
 return A.open_surface_shell('real-open-'+side+'-edge-woven-hanger','hem',verts,faces,[list(range(0,2*(N-1),2)),list(range(2*(N-1)-1,0,-2))],uvs,.0005)

def parts(sku,w,l,pose):
 cfg=CFG[sku]
 if pose=='folded':g,n,uv,proof=F.folded(w,l,cfg['recipe'],int(sku))
 else:g,n,uv=full_pose(w,l,int(sku));proof=dict(slight_full_cloth_resting_wrinkles_interpreted=True)
 raw=[C.shell('one-continuous-'+pose+'-woven-cloth','cloth',g,n,.00058,uv*np.array([w/.04,l/.04]))]
 for name,path in [('end-a',g[0]),('end-b',g[-1]),('side-a',g[:,0]),('side-b',g[:,-1])]:raw.append(C.tube(name+'-soft-turned-sewn-edge','hem',path,.00045,sides=7))
 for side in (['short','long']if cfg['hangers']==2 else['short']):raw.append(hanger(g,n,uv,sku,side))
 if cfg['kind']=='embroidery':
  im,rgb,mask=pigments(sku);hh,ww=mask.shape;stitches=[]
  for row in range(1,hh-1,4):
   line=mask[row]>.5;edges=np.diff(np.r_[False,line,False].astype(int));starts=np.where(edges==1)[0];ends=np.where(edges==-1)[0]
   for aa,bb in zip(starts,ends):
    if bb-aa<2:continue
    path=[]
    for x in np.linspace(aa+.25,bb-.25,4):
     p,nn=H.sample(g,n,uv,x/(ww-1),row/(hh-1));nn=nn if nn[1]>0 else-nn;path.append(p+nn*.0006)
    stitches.append(C.tube('own-native-leaf-satin-stitch','embroidery',path,.00018,sides=5))
  raw.append(H.combine('own-entire-leaf-motif-real-satin-threads','embroidery',stitches))
 # Reflection makes the actual upper folded face retain source glyph direction.
 if pose=='folded':
  for q in raw:q['_vertices']=[(-v[0],v[1],v[2])for v in q['_vertices']]
 allv=np.concatenate([q['_vertices']for q in raw]);lo=allv.min(0);hi=allv.max(0);off=np.array([(lo[0]+hi[0])/2,lo[1],(lo[2]+hi[2])/2])
 for q in raw:q['_vertices']=[tuple(np.array(v)-off)for v in q['_vertices']]
 return raw,proof

def build(sku):
 cfg=CFG[sku];w,l=np.array(cfg['size'])/100;raw=[];groups=[];proofs=[]
 for pose in ['folded','full']:
  p,proof=parts(sku,w,l,pose);groups.append(list(range(len(raw),len(raw)+len(p))));raw+=p;proofs.append(proof)
 official=L.EVIDENCE[sku]['official_flat_size_cm'];aid='hm-'+sku+'-own-native-kitchen-glyphs-soft-cloth';note=('Resmî exactSKU düz ölçü '+str(official)+'cm.'if official else'45X60 etiketi santimetre birimiyle doğrulanmadığından yaklaşık45×60cm gösterim planıdır, resmî boy iddiası değildir.')+' Kendi düz galeri fotoğrafındaki bütün yazı/desen renk oranından ayrıştırıldı, harfler fontla yeniden yazılmadı. Stüdyo ışığı kaplamaya alınmadı. Aynı fiziksel bez için yumuşak dört kat ve doğal kırışık açık poz sahneleri bulunur; iki ayrı ürün değildir. Yerel dikiş, kat ve askı kalıpları yorumdur. Yaprak motifi gerçek kabarık sarma dikiştir; diğer üç ürünün motifleri jakarlı dokuma renk alanıdır.'
 meta=A.base_metadata(sku,aid,dict(flat_item_size_cm=official,set_quantity=1)if official else dict(set_quantity=1),note,cfg['recipe'],1);meta.update(source_dimensions_hwd_cm=[None,*official]if official else[None,None,None],interpreted_display_flat_size_cm=cfg['size'],cloth_fold_proof=proofs,scene_variants=[dict(index=0,label='Yumuşak dört katlı bez'),dict(index=1,label='Açık bez · Bütün özgün motif')],quality_status='photo_interpretation',quality_label='Kendi özgün yazı ve nakışları · Yumuşak bez'+(' · Ölçek yaklaşık'if not official else''))
 own=master(sku);meta['original_images'].append({k:own[k]for k in['path','url','sha256']});meta['material_label']='Pamuk %100 · Jakarlı dokuma'if sku=='1350244001'else'Pamuk %90 · Keten %10'
 e=A.finish(raw,meta,lambda out:materials(sku,out),features=dict(one_physical_cloth_two_pose_scenes=True,native_glyphs=True,hanging_loop_count=cfg['hangers'],satin_embroidery=cfg['kind']=='embroidery'));doc,binary=C.read_glb(e['glb_path']);nodeby={n['mesh']:i for i,n in enumerate(doc['nodes'])if'mesh'in n};doc['scenes']=[dict(name=label,nodes=[nodeby[i]for i in group])for label,group in zip(['Folded physical cloth','Open complete native motif cloth'],groups)];doc['scene']=0
 for m in doc['materials']:
  if m['name']in['cloth','hem']:m['pbrMetallicRoughness']['baseColorTexture'].setdefault('extensions',{})['KHR_texture_transform']=dict(scale=[.04/w,.04/l])
 C.write_glb(e['glb_path'],doc,binary);e['sha256']=C.sha(e['glb_path']);e['bytes']=Path(e['glb_path']).stat().st_size;out=Path(e['asset_dir']);C.dump(out/'entry.json',e);rp=out/(aid+'.validation.json');r=json.loads(rp.read_text());r['deliverable_sha256']['glb']=e['sha256'];r['glb_bytes']=e['bytes'];C.dump(rp,r);p=D/'candidate-native-kitchen-linens-manifest.json';rows=json.loads(p.read_text())if p.exists()else[];C.dump(p,[x for x in rows if x['sku']!=sku]+[e]);print('NATIVE WHOLE KITCHEN',sku,flush=True)
if __name__=='__main__':
 for sku in sys.argv[1:]:build(sku)
