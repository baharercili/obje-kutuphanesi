"""Export own-source prepared shapes after root's actual polar method gate."""
from pathlib import Path
import sys,json,numpy as np
sys.dont_write_bytecode=True
T=Path(__file__).resolve().parent;sys.path.insert(0,str(T))
import build_remaining_source_specific_robes as M
import specific_binary_native_material as V
D=M.D;A=M.A;C=M.C;BASE_FINISH=M.Q.R.ORIGINAL_FINISH
def build(sku):
 source=D/'prepared-geometry';prepared=json.loads((source/(sku+'.json')).read_text());arrays=np.load(source/(sku+'.npz'));assert C.sha(source/(sku+'.npz'))==prepared['sha256'];raw=[]
 for q in prepared['parts']:
  k=str(q['index']);raw.append(C.B.solid(q['name'],q['material'],[tuple(v)for v in arrays[k+'_p']],[tuple(v)for v in arrays[k+'_f']],[tuple(v)for v in arrays[k+'_uv']]))
 e=BASE_FINISH(raw,prepared['metadata'],lambda out:M.material(sku,out),features=prepared['features']);doc,binary=C.read_glb(e['glb_path'])
 for mat in doc['materials']:
  if mat['name']in['cloth','hem','bear_pocket_face']:
   info=mat['pbrMetallicRoughness'].get('baseColorTexture')
   if info:info.setdefault('extensions',{})['KHR_texture_transform']=dict(scale=[.04/.128]*2)
   mat.setdefault('extensions',{})['KHR_materials_sheen']=dict(sheenColorFactor=[.27,.25,.23],sheenRoughnessFactor=1.)
  elif mat['name']=='bear_embroidery':mat.setdefault('extensions',{})['KHR_materials_sheen']=dict(sheenColorFactor=[.05,.05,.05],sheenRoughnessFactor=1.)
 doc['extensionsUsed']=sorted(set(doc['extensionsUsed'])|{'KHR_texture_transform'});C.write_glb(e['glb_path'],doc,binary);e['sha256']=C.sha(e['glb_path']);e['bytes']=Path(e['glb_path']).stat().st_size;out=Path(e['asset_dir']);C.dump(out/'entry.json',e);rp=out/(e['id']+'.validation.json');r=json.loads(rp.read_text());r['deliverable_sha256']['glb']=e['sha256'];r['glb_bytes']=e['bytes'];C.dump(rp,r);return e
if __name__=='__main__':
 entries=[build(sku)for sku in sys.argv[1:]];assert len(entries)==3;checks=[V.check(e)for e in entries];manifest=D/'frozen-own-source-specific-polar-robes-03-manifest.json';assert not manifest.exists();C.dump(D/'independent-own-source-polar-robes-validation.json',dict(valid=True,models=3,scope_counted_ready=False,actual_browser_review_pending=True,checks=checks));C.dump(manifest,entries);print('FROZEN REVIEW CANDIDATES',manifest,C.sha(manifest),flush=True)
