"""An organic water-repellent shower curtain with real pierced header holes, no display rod/rings."""
from pathlib import Path
import math,sys,copy,importlib.util
import numpy as np
R=Path(__file__).resolve().parent;s=importlib.util.spec_from_file_location('shower_helpers',R/'asset_helpers.py');A=importlib.util.module_from_spec(s);s.loader.exec_module(A);C=A.C;F=A.L.F
def build(sku):
 ev=A.L.EVIDENCE[sku];size=ev['official_flat_size_cm'];assert size and sku=='1067094001';w,h=[x/100 for x in size];grid,norm,proof=F.cloth_grid(w,h,'fine_polyester',int(sku)%1000003,False,nu=180,nv=200);headerrow=194;uv=np.array([[(i/180*w/.04,j/200*h/.04)for i in range(181)]for j in range(201)]);raw=[C.shell('main-physical-water-repellent-polyester-body','cloth',grid[:headerrow+1],norm[:headerrow+1],.00040,uv[:headerrow+1])]
 count=12;centres=np.linspace(.025/w,1-.025/w,count);edges=[0]+[(a+b)*.5 for a,b in zip(centres,centres[1:])]+[1];vc=1-.023/h;radius=.0032;vlow=headerrow/200
 for k,u in enumerate(centres):
  angles=sorted(set(list(np.linspace(0,math.tau,64,endpoint=False))+[math.atan2((vv-vc)*h,(uu-u)*w)%math.tau for uu in[edges[k],edges[k+1]]for vv in[vlow,1]]));ring_n=len(angles);points=[];tex=[];faces=[]
  for t in[0,.17,.52,1]:
   for theta in angles:
    dx,dy=math.cos(theta)/w,math.sin(theta)/h
    tx=(edges[k+1]-u)/dx if dx>1e-15 else(edges[k]-u)/dx if dx<-1e-15 else math.inf;ty=(1-vc)/dy if dy>1e-15 else(vlow-vc)/dy if dy<-1e-15 else math.inf;outer=min(tx,ty);r=radius+(outer-radius)*t;uu=u+dx*r;vv=vc+dy*r;p,n=C.sample(grid,norm,uu,vv);points.append(tuple(p));tex.append((uu*w/.04,vv*h/.04))
  for j in range(3):
   for i in range(ring_n):a=j*ring_n+i;b=j*ring_n+(i+1)%ring_n;c=a+ring_n;d=b+ring_n;faces.extend([(a,c,b),(b,c,d)])
  boundary=[list(range(3*ring_n,4*ring_n)),list(range(ring_n-1,-1,-1))];raw.append(A.open_surface_shell('header-actual-pierced-hole-'+str(k+1),'header',points,faces,boundary,tex,.00085))
  path=[]
  for theta in np.linspace(0,math.tau,48,endpoint=False):
   uu=u+(radius+.0005)/w*math.cos(theta);vv=vc+(radius+.0005)/h*math.sin(theta);p,n=C.sample(grid,norm,uu,vv);path.append(p+n*.00014)
  raw.append(A.closed_tube('small-reinforcing-grommet-'+str(k+1),'grommet',path,.00034,8))
 raw.append(C.ribbon('turned-bottom-hem','hem',grid,norm,0,1,0,.023/h,.00055,-.00035,steps_u=180))
 for name,u in[('left',0),('right',1-.012/w)]:raw.append(C.ribbon(name+'-turned-edge','hem',grid,norm,u,u+.012/w,0,1,.00050,-.00032,steps_u=3,steps_v=160))
 # Official source roles list polyester shell and lining. Keep a real second layer below the pierced header rather than blocking the holes.
 raw.append(C.shell('separate-polyester-rear-layer','lining',grid[:headerrow+1],norm[:headerrow+1],.00020,uv[:headerrow+1],offset=-.0007))
 def mats(out):
  m=A.L.materials(sku,dict(recipe='cotton',rgb=[235,235,230]),out);m['header']=copy.deepcopy(m['cloth']);m['lining']=copy.deepcopy(m['cloth']);m['grommet']=dict(baseColorFactor=[.70,.71,.70,1],metallic=.8,roughness=.31,alphaMode='OPAQUE',doubleSided=False,extras=dict(photo_pixels_baked=False,baked_reflections=False));return m
 aid='hm-'+sku+'-shower180x200-actual-pierced-header-organic';note='Resmî exact SKU 180×200 cm düz ölçüsü H&M Hindistan ürün kaydında açık metre birimiyle doğrulandı. Türkiye ürün kaydı su tutmaz polyester, üst delikler, ayrı satılan halkalar ve dış/astar bileşimini doğruluyor. 12 delikli düzen, küçük delik çapı, metal güçlendirme profili, kenar ve yerel katman kalınlığı fotoğraf yorumudur; üretici teknik çizimi değildir. Askı halkası, kanca ve çubuk modele dahil değildir.';meta=A.base_metadata(sku,aid,dict(flat_cloth_size_cm=size),note,'water_repellent_polyester',estimated_fields=['posed_width_depth','header_hole_count12_local_spacing_and_diameter','small_grommet_and_hem_profile','source_photo_colour_and_optics']);meta['source_dimensions_hwd_cm']=[size[1],size[0],None];meta['shower_features']=dict(actual_header_holes=count,header_hole_count_officially_verified=False,rings_or_rod_included=False,separate_polyester_rear_layer=True,main_cloth_flat_arc_validation=proof,header_cell_topology='closed thin annulus solids with real central opening');return A.finish(raw,meta,mats,features=meta['shower_features'])
if __name__=='__main__':
 for sku in sys.argv[1:]:build(sku)
