"""One held fur prototype: broad curved tapering bundles, not more thin hairs."""
from pathlib import Path
import sys,json,math,numpy as np
sys.dont_write_bytecode=True
T=Path(__file__).resolve().parent;sys.path.insert(0,str(T))
import build_visible_fur_fine_knit_prototypes05 as P
import native_surface_materials as N
import specific_binary_native_material as V
M=P.M;A=M.A;C=M.C;D=T/'fur-visible-volumetric-bundles-revision06';D.mkdir(exist_ok=True);P.D=D;P.Q.D=D;P.Q.R.D=D;M.D=D;A.R=D
def bundle_tubes(paths,widths,thicknesses):
 count,k,_=paths.shape;sides=6;d=np.empty_like(paths);d[:,1:-1]=paths[:,2:]-paths[:,:-2];d[:,0]=paths[:,1]-paths[:,0];d[:,-1]=paths[:,-1]-paths[:,-2];d/=np.linalg.norm(d,axis=2,keepdims=True);guide=np.zeros_like(d);guide[:,:,1]=1;bad=abs(d[:,:,1])>.95;guide[bad]=[0,0,1];across=np.cross(d,guide);across/=np.linalg.norm(across,axis=2,keepdims=True);up=np.cross(across,d);angles=np.arange(sides)*math.tau/sides;taper=np.array([.62,1.,.95,.78,.42,.025]);a=widths[:,None]*.5*taper[None,:];b=thicknesses[:,None]*.5*taper[None,:];g=paths[:,:,None,:]+across[:,:,None,:]*np.cos(angles)[None,None,:,None]*a[:,:,None,None]+up[:,:,None,:]*np.sin(angles)[None,None,:,None]*b[:,:,None,None];vertices=np.concatenate([g.reshape(count,k*sides,3),paths[:,0,None,:],paths[:,-1,None,:]],1);faces=[]
 for j in range(k-1):
  for i in range(sides):a0=j*sides+i;b0=j*sides+(i+1)%sides;c0=a0+sides;d0=b0+sides;faces +=[(a0,b0,c0),(b0,d0,c0)]
 for i in range(sides):faces +=[(k*sides,(i+1)%sides,i),(k*sides+1,(k-1)*sides+i,(k-1)*sides+(i+1)%sides)]
 faces=(np.array(faces)[None,:,:]+np.arange(count)[:,None,None]*(k*sides+2)).reshape(-1,3);radial=np.linalg.norm(np.diff(np.concatenate([g,g[:,:,:1]],2),axis=2),axis=3);crossuv=np.concatenate([np.zeros((count,k,1)),np.cumsum(radial,axis=2)[:,:,:-1]],2)/.08;arc=np.c_[np.zeros(count),np.cumsum(np.linalg.norm(np.diff(paths,axis=1),axis=2),axis=1)]/.08;uv=np.stack([crossuv,np.repeat(arc[:,:,None],sides,axis=2)],3).reshape(count,k*sides,2);cap0=np.stack([np.full(count,.001),np.full(count,-.001)],1)[:,None,:];cap1=np.stack([np.full(count,.001),arc[:,-1]+.001],1)[:,None,:];uv=np.concatenate([uv,cap0,cap1],1)
 return dict(name='visible-source-long-fur-curved-volumetric-tapered-bundles',material='yarn',_vertices=[tuple(x)for x in vertices.reshape(-1,3)],_faces=[tuple(x)for x in faces],_uvs=[tuple(x)for x in uv.reshape(-1,2)],_flat_normals=False)
def pile_parts(g,n,uv,w,l,sku,cfg):
 rng=np.random.default_rng(int(sku)+606);low,high,field=P.visibility(g);u,v=rng.uniform(.001,.999,(2,230000));p,nn=P.samples(g,n,uv,u,v);ok=P.visible(p,nn,low,high,field);u=u[ok];v=v[ok];p=p[ok];nn=nn[ok];count=12000;select=rng.choice(len(u),count,replace=False);u=u[select];v=v[select];p=p[select];nn=nn[select]
 before,_=P.samples(g,n,uv,u,np.clip(v-.001,0,1));after,_=P.samples(g,n,uv,u,np.clip(v+.001,0,1));t=after-before;t-=nn*np.einsum('ij,ij->i',t,nn)[:,None];t/=np.linalg.norm(t,axis=1,keepdims=True);side=np.cross(nn,t);angle=.38*np.sin(u*w*37+v*l*19)+rng.normal(0,.23,count);t=t*np.cos(angle)[:,None]+side*np.sin(angle)[:,None];side=np.cross(nn,t)
 normxz=(p[:,[0,2]]-(low+high)/2)/((high-low)/2);edge=(abs(normxz)>.94).any(1);out=np.zeros_like(p);axis=np.argmax(abs(normxz),axis=1);out[np.arange(count),np.where(axis==0,0,2)]=np.sign(normxz[np.arange(count),axis]);out-=nn*np.einsum('ij,ij->i',out,nn)[:,None];out/=np.maximum(1e-12,np.linalg.norm(out,axis=1,keepdims=True));t[edge]=out[edge];side=np.cross(nn,t)
 length=rng.uniform(.020,.035,count);rise=rng.uniform(.008,.015,count);width=rng.uniform(.0013,.0030,count);thick=rng.uniform(.00055,.0011,count);dx=abs((u*w+.12)%.24-.12);dy=abs((v*l+.11)%.22-.11);seam=(dx<.012)|(dy<.012);rise[seam]*=.10;length[seam]*=.18;width[seam]*=.65;phase=rng.uniform(0,math.tau,count);rows=[]
 for j,(along,lift)in enumerate([(0,0),(.14,.44),(.34,.92),(.58,1),(.80,.68),(1,.19)]):rows.append(p+nn*(.001+rise*lift)[:,None]+t*(length*along)[:,None]+side*(length*.07*math.sin(j*1.1)*np.sin(phase+j*.4))[:,None])
 paths=np.stack(rows,1);bundle=bundle_tubes(paths,width,thick);tips=paths[:,-1][:,[0,2]];overhang=((tips<low-.001)|(tips>high+.001)).any(1);bins=np.floor((p[:,[0,2]]-low)/(high-low)*16).astype(int)
 # A restrained fringe of fine real hairs softens the broad bundle silhouette.
 ix=np.flatnonzero(edge&(~seam));ix=np.resize(ix,2200);shift=side[ix]*rng.uniform(-.001,.001,(len(ix),1));micro=np.stack([paths[ix,j]+shift for j in [0,2,4,5]],1);wisps=P.tubes('fine-loose-source-hairs-around-broad-bundle-outline','yarn',micro,np.full(len(ix),.00010));v0=len(bundle['_vertices']);bundle['_vertices']+=wisps['_vertices'];bundle['_uvs']+=wisps['_uvs'];bundle['_faces'] +=[tuple(a+v0 for a in f)for f in wisps['_faces']]
 C.dump(D/(sku+'-volumetric-bundle-coverage-proof.json'),dict(broad_bundles=count,optional_outline_micro_hairs=len(ix),occupied_top_cells_16x16=len({tuple(b)for b in bins}),bundle_width_range_m=[float(width[~seam].min()),float(width.max())],normal_rise_range_m=[float(rise[~seam].min()),float(rise.max())],tangential_fall_range_m=[float(length[~seam].min()),float(length.max())],tips_outside_actual_cloth_footprint=int(overhang.sum()),bundle_roots_above_actual_outer_shell=True,all_tapered_closed_rounded_fabric_fibre_bundle_solids=True,old_thin_hair_count=59765,new_main_bundle_count=count,source_pigment_without_baked_pile_occlusion=True));return bundle
M.pile_parts=pile_parts
OLD_MAT=M.material
def material(sku,cfg,out,w,l):
 mats=OLD_MAT(sku,cfg,out,w,l);repeat=.04;x=np.arange(2048)[None,:]/2048*repeat;y=np.arange(2048)[:,None]/2048*repeat;h=.000025*np.cos(x/.00018*math.tau)**4+.000004*np.cos(y/.0006*math.tau)*np.cos(x/.00021*math.tau);N.maps(h,repeat,out,'own-fine-fibres-on-volumetric-bundles',238);mats['yarn'].update(normalTexture='own-fine-fibres-on-volumetric-bundles-normal.png',metallicRoughnessTexture='own-fine-fibres-on-volumetric-bundles-orm.png',normalScale=.42,metallic=1,roughness=1.);return mats
M.material=material
BASE_FINISH=P.BASE_FINISH
def base(raw,meta,fn,features=None):
 meta['id']='hm-'+meta['sku']+'-volumetric-long-fur-bundles-soft-quilted-fold-r6';meta['quality_label']='Hacimli uzun tüy demetleri · Oyuk kare dikiş · Ölçek yaklaşık';meta['estimated_fields']+=['1_to_3mm_visible_fur_bundle_width','8_to_15mm_normal_loft_and_gravity_fall'];return BASE_FINISH(raw,meta,fn,features)
P.BASE_FINISH=base
source=P.source.replace("aid='hm-'+sku+('-physical-fine-wool-knit-soft-fold-r5'if kind in['fine_knit','textured']else'-loose-long-tapered-fur-soft-quilted-fold-r5')", "aid='hm-'+sku+'-volumetric-long-fur-bundles-soft-quilted-fold-r6'")
assert source!=P.source;exec(compile(source,str(__file__)+':matching-volumetric-fur-id','exec'),M.__dict__)
if __name__=='__main__':
 M.build('1334640005');rows=json.loads((D/'candidate-distinct-blankets-manifest.json').read_text());assert len(rows)==1;assert rows[0]['bytes']<=80*1024*1024,rows[0]['bytes'];checks=[V.check(e)for e in rows];target=D/'frozen-volumetric-long-fur-bundles-prototype-01-manifest.json';assert not target.exists();C.dump(D/'independent-volumetric-fur-bundles-validation.json',dict(valid=True,models=1,actual_browser_review_required=True,checks=checks));C.dump(target,rows);print(target,C.sha(target),rows[0]['bytes'],flush=True)
