"""Exact190cm circular cloth over an interpreted circular support.

Radial/circumferential cloth constraints and gravity produce organic gathers;
no rectangular cloth, lathed solid skirt, photo billboard or table is exported.
"""
from pathlib import Path
import sys,json,math
sys.dont_write_bytecode=True
import numpy as np
T=Path(__file__).resolve().parent;sys.path.insert(0,str(T))
import build_soft_linen_revision as B
A,C=B.A,B.C
D=T/'round-tablecloth-prototype01';D.mkdir(exist_ok=True);A.R=D
SKU='1324650002';R=.95;SUP=.59;NR=96;NT=192
def solve():
    radial=np.linspace(R/NR,R,NR);angle=np.arange(NT)*math.tau/NT
    rr,tt=np.meshgrid(radial,angle,indexing='ij');x=rr*np.cos(tt);z=rr*np.sin(tt)
    wrinkle=.0014*np.sin(x*49+z*8+.7)+.0009*np.sin(z*39-x*6-1.1)+.00065*np.sin(x*113+z*21+.4)
    p=np.stack([x,wrinkle+.012,z],2);old=p.copy();rest=p.copy();rest[:,:,1]=wrinkle+.002
    anchor=rr<SUP-.035;dr=R/NR;dt=.013
    def constraints(diagonal=True):
        for parity in(0,1):
            a=p[parity:-1:2];b=p[parity+1::2];delta=b-a;distance=np.maximum(1e-12,np.linalg.norm(delta,axis=2,keepdims=True));corr=delta*((distance-dr)/distance)*.5;a+=corr;b-=corr
        for parity in(0,1):
            ia=np.arange(parity,NT,2);ib=(ia+1)%NT;a=p[:,ia];b=p[:,ib];delta=b-a
            target=(radial*2*math.sin(math.pi/NT))[:,None,None];distance=np.maximum(1e-12,np.linalg.norm(delta,axis=2,keepdims=True));corr=delta*((distance-target)/distance)*.5;p[:,ia]+=corr;p[:,ib]-=corr
        if diagonal:
            for parity in(0,1):
                for direction in(-1,1):
                    rows=np.arange(parity,NR-1,2);shift=np.roll(p[rows+1],direction,axis=1);a=p[rows];delta=shift-a
                    target=np.sqrt(radial[rows]**2+radial[rows+1]**2-2*radial[rows]*radial[rows+1]*math.cos(math.tau/NT))[:,None,None]
                    distance=np.maximum(1e-12,np.linalg.norm(delta,axis=2,keepdims=True));corr=delta*((distance-target)/distance)*.16
                    p[rows]+=corr;p[rows+1]-=np.roll(corr,-direction,axis=1)
    def collide():
        radius=np.hypot(p[:,:,0],p[:,:,2]);inside=(radius<SUP)&(p[:,:,1]<.001)
        radial_nearest=inside&((SUP-radius)<(.001-p[:,:,1]));factor=SUP/np.maximum(1e-10,radius)
        p[:,:,0][radial_nearest]*=factor[radial_nearest];p[:,:,2][radial_nearest]*=factor[radial_nearest]
        p[:,:,1][inside&~radial_nearest]=.001
    for frame in range(240):
        velocity=(p-old)*.965;old=p.copy();p+=velocity;p[:,:,1]-=9.81*dt*dt
        for _ in range(9):constraints();collide();p[anchor]=rest[anchor]
        if frame%50==0:print('CIRCULAR CLOTH GRAVITY',frame,flush=True)
    for _ in range(2200):constraints(False);p[rr<R*.30]=rest[rr<R*.30]
    centre=np.array([0.,.002,0.]);radial_arcs=np.linalg.norm(np.diff(np.concatenate([np.broadcast_to(centre,(1,NT,3)),p]),axis=0),axis=2).sum(0)
    arcs=np.linalg.norm(np.roll(p,-1,axis=1)-p,axis=2).sum(1);reference=NT*2*radial*math.sin(math.pi/NT)
    proof=dict(official_flat_diameter_m=R*2,radial_ring_count=NR,angular_segments=NT,
        max_radial_arc_relative_error=float(abs(radial_arcs/R-1).max()),
        max_ring_arc_relative_error=float(abs(arcs/reference-1).max()),
        interpreted_support_diameter_m=SUP*2,circular_support_exported=False,simulation_frames=240,
        gravity_m_s2=9.81,actual_cloth_boundary_circular_in_manufactured_reference=True,
        source_colour_and_material_wrinkles_photo_interpreted=True)
    return p,centre,proof
def build():
    cache=D/'circular-source-plan-gravity-grid.npz'
    if cache.exists():q=np.load(cache);grid,centre=q['grid'],q['centre'];proof=json.loads(cache.with_suffix('.json').read_text())
    else:grid,centre,proof=solve();np.savez_compressed(cache,grid=grid,centre=centre);C.dump(cache.with_suffix('.json'),proof)
    vertices=[centre.tolist()]+grid.reshape(-1,3).tolist();uv=[(0,0)];radial=np.linspace(R/NR,R,NR)
    for radius in radial:
        for theta in np.arange(NT)*math.tau/NT:uv.append((radius*math.cos(theta)/.04,radius*math.sin(theta)/.04))
    faces=[(0,1+(i+1)%NT,1+i)for i in range(NT)]
    for j in range(NR-1):
        for i in range(NT):
            a=1+j*NT+i;b=1+j*NT+(i+1)%NT;c=a+NT;d=b+NT;faces.extend([(a,b,c),(b,d,c)])
    boundary=[1+(NR-1)*NT+i for i in range(NT)]
    body=A.open_surface_shell('real-continuous-circular-cloth','cloth',vertices,faces,boundary,uv,.00055)
    raw=[body]
    # Actual outer circular edge binding is a narrow softly sewn band. Its
    # profile and millimetric width are interpreted, never official dimensions.
    path=grid[-1];raw.append(A.closed_tube('continuous-soft-circular-sewn-edge','hem',path,.00055,sides=8))
    aid='hm-'+SKU+'-real-circular190-gravity-drape'
    note=('Resmî kaynak kartında D190cm çap doğrulandı. Kumaş gerçekten daire planlıdır ve190cm düz kaynak çapı korunur; '
          'katlanmış/sarkmış model kutusu bu düz çap değildir. Dairesel118cm masa desteği, yerel kıvrım, kenar dikişi ve kalınlık fotoğraf yorumudur; '
          'destek masası ihraç edilmez. Radyal ve çevresel arklar gerçek modele ayrıca denetlenir.')
    meta=A.base_metadata(SKU,aid,dict(flat_diameter_cm=190,set_quantity=1),note,'linen_blend',1,
        estimated_fields=['circular_support_footprint_and_gravity_pose','cloth_thickness_and_local_edge_stitch','source_colour_and_optics'])
    meta.update(source_dimensions_hwd_cm=[None,None,None],circular_cloth_metric=proof,
        scene_variants=[dict(index=0,label='Gerçek daire kumaş · Doğal masa sarkması')],
        quality_status='photo_interpretation',quality_label='Resmî190cm daire plan · Poz yorum')
    entry=A.finish(raw,meta,lambda out:B.material(SKU,dict(recipe='linen_blend',rgb=[219,207,185],intrinsic_ao=True),out),features=proof)
    C.dump(D/'candidate-round-tablecloth-manifest.json',[entry]);print('ROUND CLOTH CANDIDATE',proof,flush=True)
if __name__=='__main__':build()
