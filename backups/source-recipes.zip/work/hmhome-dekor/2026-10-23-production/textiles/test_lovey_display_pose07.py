"""A real square cloth metric solve from an inextensible broad-gathered start."""
from pathlib import Path
import sys,json,math,time,numpy as np
T=Path(__file__).resolve().parent;D=T/'bear-comforters-soft-display-revision07';D.mkdir(exist_ok=True)
def curve():
 phi=np.linspace(0,math.tau,80001);phase=4*phi+.34*np.sin(phi+.8)+.13*np.sin(3*phi)
 def f(a):
  polar=.60+a*(np.sin(phase)+.17*np.sin(7*phi+.4));d=np.stack([np.sin(polar)*np.sin(phi),-np.cos(polar),np.sin(polar)*np.cos(phi)],1);arc=np.r_[0,np.cumsum(np.linalg.norm(np.diff(d,axis=0),axis=1))];return d,arc
 lo,hi=.001,.5
 for _ in range(45):
  a=(lo+hi)/2;d,s=f(a)
  if s[-1]>math.tau:hi=a
  else:lo=a
 return f((lo+hi)/2)
def solve(seed=1351309001,N=64,frames=170):
 w=.37;u=np.linspace(-w/2,w/2,N+1);U,V=np.meshgrid(u,u);r=np.hypot(U,V);theta=np.arctan2(U,V)%math.tau;d,s=curve();directions=np.stack([np.interp(theta,s,d[:,k])for k in range(3)],2);p=r[:,:,None]*directions;old=p.copy();rest=p.copy();pin=r<.008
 # Source-photo display styling holds the four free corners at different soft
 # depths while the fabric metric relaxes; these are pose constraints, not a
 # claim that the manufactured product has extra attachments.
 for row,col,target in [(0,0,(-.075,-.190,-.025)),(0,N,(0,-.252,.045)),(N,0,(0,-.205,-.045)),(N,N,(.075,-.190,-.025))]:
  pin[row,col]=True;rest[row,col]=target;p[row,col]=target
 old=p.copy();cons=[];du=w/N
 for parity in[0,1]:
  cons +=[((slice(None),slice(parity,N,2)),(slice(None),slice(parity+1,N+1,2)),du,1.),((slice(parity,N,2),slice(None)),(slice(parity+1,N+1,2),slice(None)),du,1.)]
 for parity in[0,1]:
  for direction in[0,1]:
   aa=(slice(parity,N,2),slice(0,N))if not direction else(slice(parity,N,2),slice(1,N+1));bb=(slice(parity+1,N+1,2),slice(1,N+1))if not direction else(slice(parity+1,N+1,2),slice(0,N));cons.append((aa,bb,math.sqrt(2)*du,.55))
 for parity in range(3):cons +=[((slice(None),slice(parity,N-1,3)),(slice(None),slice(parity+2,N+1,3)),du*2,.015),((slice(parity,N-1,3),slice(None)),(slice(parity+2,N+1,3),slice(None)),du*2,.015)]
 inv=(~pin).astype(float)
 def constrain(c):
  aa,bb,target,k=c;a=p[aa];b=p[bb];delta=b-a;dist=np.linalg.norm(delta,axis=2);wa=inv[aa];wb=inv[bb];scale=np.divide(k*(dist-target),dist*(wa+wb),out=np.zeros_like(dist),where=dist*(wa+wb)>1e-12);corr=delta*scale[:,:,None];a+=corr*wa[:,:,None];b-=corr*wb[:,:,None]
 for frame in range(frames):
  vel=(p-old)*.95;old=p.copy();p+=vel;p[:,:,1]-=9.81*.006**2
  for it in range(22):
   for c in cons:constrain(c)
   p[pin]=rest[pin]
  if frame%30==0:print('FRAME',frame,flush=True)
 for it in range(15000):
  for c in cons[:8]:constrain(c)
  p[pin]=rest[pin]
 a=np.linalg.norm(np.diff(p,axis=1),axis=2).sum(1);b=np.linalg.norm(np.diff(p,axis=0),axis=2).sum(0);err=[float(abs(a/w-1).max()),float(abs(b/w-1).max())];print('METRIC',err,flush=True);np.savez_compressed(D/'actual-square-relaxed-cloth.npz',grid=p,U=U,V=V);(D/'actual-square-relaxed-cloth-proof.json').write_text(json.dumps(dict(display_width_m=w,display_not_official_cm=True,actual_warp_weft_arc_relative_error_max=err,simulation_frames=frames,final_relax_iterations=15000,grid_N=N,source_pose_interpretation=True),indent=2)+'\n');return p
if __name__=='__main__':solve()
