"""Interpreted soft-cloth poses. Flat cut sizes remain the reference metric.

Table drapes use an explicit gravity and distance-constraint relaxation over an
unexported support. The single-loop cloth is a developable generalized cone,
not a uniformly corrugated curtain. No source photograph pixels are projected.
"""
import math
import numpy as np
TAU=math.tau

def normals(p):
    n=np.cross(np.gradient(p,axis=0),np.gradient(p,axis=1))
    n/=np.maximum(1e-12,np.linalg.norm(n,axis=2,keepdims=True))
    return n

def metric(p,w,l,pose,**extra):
    row=np.linalg.norm(np.diff(p,axis=1),axis=2).sum(1)
    col=np.linalg.norm(np.diff(p,axis=0),axis=2).sum(0)
    return dict(flat_width_m=w,flat_length_m=l,nu=p.shape[1]-1,nv=p.shape[0]-1,
                row_arc_error_m=float(abs(row-w).max()),column_arc_error_m=float(abs(col-l).max()),
                max_relative_row_arc_error=float(abs(row/w-1).max()),max_relative_column_arc_error=float(abs(col/l-1).max()),
                pose=pose,hidden_support_geometry_included=False,
                interpretation='Authored cloth gravity pose; flat cut dimensions are official, support and local wrinkles are interpreted.',**extra)

def table_gravity(w,l,seed,nu=100,nv=160,frames=230,runner=False):
    rng=np.random.default_rng(seed);u=np.linspace(-w/2,w/2,nu+1);v=np.linspace(-l/2,l/2,nv+1);U,V=np.meshgrid(u,v)
    # A nonuniform relaxed-crinkle resting shape, in real metres.
    phases=rng.uniform(-math.pi,math.pi,6)
    wrinkle=.0014*np.sin(U*49+V*8+phases[0])+.0009*np.sin(V*39-U*6+phases[1])
    wrinkle+=.00065*np.sin(U*113+V*21+phases[2])
    p=np.stack([U,wrinkle+.012,V],axis=-1);old=p.copy();du=w/nu;dv=l/nv
    # Support intentionally smaller than the cut cloth: the exported asset has no table.
    hw=w*(.70 if runner else .315);hl=l*.315
    anchor=(abs(U)<hw-.035)&(abs(V)<hl-.035)
    rest=p.copy();rest[:,:,1]=wrinkle+.002
    constraint=[]
    for parity in (0,1):
        constraint.append(((slice(None),slice(parity,nu,2)),(slice(None),slice(parity+1,nu+1,2)),du,1.0))
        constraint.append(((slice(parity,nv,2),slice(None)),(slice(parity+1,nv+1,2),slice(None)),dv,1.0))
    # Diagonal constraints resist shear without forcing the cloth into a rigid sheet.
    for parity in (0,1):
        for direction in (0,1):
            a=(slice(parity,nv,2),slice(0,nu)) if not direction else (slice(parity,nv,2),slice(1,nu+1))
            b=(slice(parity+1,nv+1,2),slice(1,nu+1)) if not direction else (slice(parity+1,nv+1,2),slice(0,nu))
            constraint.append((a,b,math.hypot(du,dv),.34))
    # Distance-two bending is weak: enough to retain the textile's soft edge radius.
    for parity in range(3):
        constraint.append(((slice(None),slice(parity,nu-1,3)),(slice(None),slice(parity+2,nu+1,3)),du*2,.012))
        constraint.append(((slice(parity,nv-1,3),slice(None)),(slice(parity+2,nv+1,3),slice(None)),dv*2,.012))
    dt=.013
    def collide():
        inside=(abs(p[:,:,0])<hw)&(abs(p[:,:,2])<hl)&(p[:,:,1]<.001)
        distance=np.stack([hw-abs(p[:,:,0]),.001-p[:,:,1],hl-abs(p[:,:,2])],2)
        nearest=distance.argmin(2)
        for axis,limit in [(0,hw),(2,hl)]:
            selected=inside&(nearest==axis)
            p[:,:,axis][selected]=np.where(p[:,:,axis][selected]<0,-limit,limit)
        selected=inside&(nearest==1);p[:,:,1][selected]=.001
    for frame in range(frames):
        vel=(p-old)*.965;old=p.copy();p+=vel;p[:,:,1]-=9.81*dt*dt
        for iteration in range(9):
            for aa,bb,target,stiffness in constraint:
                a=p[aa];b=p[bb];delta=b-a;dist=np.maximum(1e-12,np.linalg.norm(delta,axis=2,keepdims=True));corr=delta*((dist-target)/dist)*(.5*stiffness)
                a+=corr;b-=corr
            collide()
            p[anchor]=rest[anchor]
        if frame%50==0:print('CLOTH GRAVITY',seed,frame,flush=True)
    # Final quasi-static metric relaxation removes transient gravity stretch.
    # Warp/weft cut lengths have priority over a particular support contact.
    for _ in range(1800):
        for aa,bb,target,stiffness in constraint[:4]:
            a=p[aa];b=p[bb];delta=b-a;dist=np.maximum(1e-12,np.linalg.norm(delta,axis=2,keepdims=True));corr=delta*((dist-target)/dist)*(.5*stiffness)
            a+=corr;b-=corr
        # Keep only the central drape patch anchored during the final metric
        # solve: contact positions may slide to remove any artificial stretch.
        central=(abs(U)<w*.15)&(abs(V)<l*.15)
        p[central]=rest[central]
    # Preserve true physical simulation wrinkles; only add submillimetre cross-grain relaxation.
    p[:,:,1]+=.00035*np.sin(U*137+V*27+phases[3])
    return p,normals(p),metric(p,w,l,'gravity-relaxed-table-drape',gravity_m_s2=9.81,simulation_frames=frames,support_footprint_m=[hw*2,hl*2],support_is_interpreted=True)

def single_hook(w,l,seed,nu=140,nv=180):
    # Map a rectangle isometrically onto a generalized cone r*d(theta), with
    # d on a unit sphere parameterized by its OWN arc length. This produces
    # several nonperiodic fan folds that converge at one top-centre fabric loop.
    rng=np.random.default_rng(seed);t=np.linspace(-math.pi/2,math.pi/2,60001);phase=rng.uniform(-.2,.2)
    # A monotonic yaw sweeps the two wings around the hanging centre. Modulated
    # polar angle puts alternating softer folds toward/away from the viewer.
    # Monotone polar angle makes this a simple spherical spiral: no crossing
    # directions, hence no self-intersection of the hanging fan surface.
    polar=.255+.073*t+.008*np.sin(4*t+phase)
    dp=.073+.032*np.cos(4*t+phase)
    yaw_derivative=np.sqrt(1-dp*dp)/np.sin(polar)
    yaw=np.r_[0,np.cumsum((yaw_derivative[:-1]+yaw_derivative[1:])*.5*np.diff(t))]
    yaw-=np.interp(0,t,yaw)
    d=np.stack([np.sin(polar)*np.sin(yaw),-np.cos(polar),np.sin(polar)*np.cos(yaw)],1)
    arc=np.r_[0,np.cumsum(np.linalg.norm(np.diff(d,axis=0),axis=1))]
    mid=np.interp(0,t,arc);arc-=mid
    # The exact kitchen family hangs from its LONG edge, near the middle;
    # hanging its short edge instead makes an incorrectly long cone.
    pin=.46;u=np.linspace(.003,w+.003,nu+1);v=np.linspace(-pin*l,(1-pin)*l,nv+1);U,V=np.meshgrid(u,v)
    radius=np.hypot(U,V);theta=np.arctan2(V,U)
    # A single global rotation changes the view without stretching the cloth.
    D=np.stack([np.interp(theta,arc,d[:,k])for k in range(3)],2);D/=np.linalg.norm(D,axis=2,keepdims=True)
    p=radius[:,:,None]*D
    # Restrained millimetric relaxation of a soft woven sheet, not identical
    # cone generators on every row. Keep the apex and attached edge stable.
    envelope=np.sin(math.pi*(V/l+pin))**2
    p[:,:,2]+=.004*envelope*np.sin(TAU*U/w*1.1+V/l*2)
    p[:,:,0]+=.003*np.sin(math.pi*U/w)**2*np.sin(TAU*V/l+U/w*2)
    angle=.16+phase;c=math.cos(angle);s=math.sin(angle);xx=p[:,:,0]*c+p[:,:,2]*s;zz=-p[:,:,0]*s+p[:,:,2]*c;p[:,:,0]=xx;p[:,:,2]=zz
    return p,normals(p),metric(p,w,l,'single-long-edge-loop-fan-drape',pose_metric='Generalized developable cone. Spherical direction curve is reparameterized by arc length.',attachment_uv=[0,pin],local_attachment_neighbourhood_radius_m=.003)

def folded_soft(w,l,seed,nu=144,nv=120):
    # A broad rounded half-fold, with a genuinely separate upper layer and
    # gently displaced open edges; one continuous piece, no solid pillow.
    rng=np.random.default_rng(seed);s=np.linspace(0,w,nu+1);z=np.linspace(-l/2,l/2,nv+1);radius=.0045;turn=math.pi*radius;straight=(w-turn)/2
    x=np.where(s<straight,s,np.where(s<straight+turn,straight+radius*np.sin((s-straight)/radius),straight-(s-straight-turn)))
    y=np.where(s<straight,0,np.where(s<straight+turn,radius*(1-np.cos((s-straight)/radius)),radius*2))
    U,V=np.meshgrid(s,z);p=np.zeros((nv+1,nu+1,3));p[:,:,0]=x;p[:,:,1]=y;p[:,:,2]=V
    # Unequal soft folds at cut edges. The inner fold is already round and
    # remains continuous, while the lower layer is visibly separated.
    phase=rng.uniform(-3,3);ripples=.0017*np.sin(V*46+U*13+phase)+.0008*np.sin(V*109-U*23)
    edge=np.exp(-((abs(V)-l/2)/.045)**2)
    p[:,:,1]+=ripples*(.45+.55*edge)
    p[:,:,0]+=.0012*np.sin(V*22+phase)*np.sin(math.pi*U/w)
    # Tiny unequal diagonal relaxation makes the open end read as folded cloth.
    p[:,:,2]+=.0014*np.sin(U*34+phase)*np.sin(math.pi*(V/l+.5))
    return p,normals(p),metric(p,w,l,'soft-continuous-half-fold',rounded_fold_radius_m=radius,physically_separate_layers=True)
