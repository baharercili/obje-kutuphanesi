"""Independent GLB checks, including actual four-layer material intersections."""
from pathlib import Path
import sys,json,struct,hashlib,importlib.util
import numpy as np
sys.dont_write_bytecode=True
T=Path(__file__).resolve().parent;s=importlib.util.spec_from_file_location('independent_fold_topology',T.parent/'curtains/validate_special_products.py');S=importlib.util.module_from_spec(s);s.loader.exec_module(S)
def validate(e):
    result=S.check(e);data=Path(e['glb_path']).read_bytes();n=struct.unpack_from('<I',data,12)[0];doc=json.loads(data[20:20+n]);bl=struct.unpack_from('<I',data,20+n)[0];binary=data[28+n:28+n+bl];model=json.loads(Path(e['model_path']).read_text());assert doc['extras']['metadata']==model['metadata']
    def arr(i):
        a=doc['accessors'][i];v=doc['bufferViews'][a['bufferView']];dtype={5126:'<f4',5125:'<u4',5123:'<u2'}[a['componentType']];c={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}[a['type']];sz=np.dtype(dtype).itemsize;return np.ndarray((a['count'],c),dtype=dtype,buffer=binary,offset=v.get('byteOffset',0)+a.get('byteOffset',0),strides=(v.get('byteStride',c*sz),sz)).copy()
    checks=[]
    for mesh in doc['meshes']:
        if not mesh['name'].endswith('continuous-four-layer-woven-cloth'):continue
        p=mesh['primitives'][0];v=arr(p['attributes']['POSITION']);idx=arr(p['indices']).reshape(-1,3);tri=v[idx].astype(float);a=tri[:,0][:,[0,2]];b=tri[:,1][:,[0,2]];c=tri[:,2][:,[0,2]];v0=b-a;v1=c-a;det=v0[:,0]*v1[:,1]-v0[:,1]*v1[:,0];valid=abs(det)>1e-13;largest=0
        low=v.min(0);high=v.max(0)
        for fx in [.35,.45,.55,.65]:
            for fz in [.35,.45,.55,.65]:
                point=np.array([low[0]+fx*(high[0]-low[0]),low[2]+fz*(high[2]-low[2])]);delta=point-a;u=np.zeros(len(det));vv=np.zeros(len(det));u[valid]=(delta[valid,0]*v1[valid,1]-delta[valid,1]*v1[valid,0])/det[valid];vv[valid]=(v0[valid,0]*delta[valid,1]-v0[valid,1]*delta[valid,0])/det[valid];hit=valid&(u>=-1e-7)&(vv>=-1e-7)&(u+vv<=1+1e-7);y=tri[hit,0,1]+u[hit]*(tri[hit,1,1]-tri[hit,0,1])+vv[hit]*(tri[hit,2,1]-tri[hit,0,1]);y=np.sort(y);crossings=0 if not len(y)else 1+int((np.diff(y)>2e-6).sum());largest=max(largest,crossings)
        assert largest>=8,(mesh['name'],largest)
        checks.append(dict(mesh=mesh['name'],maximum_independent_vertical_material_surface_crossings=largest,at_least_four_finite_thickness_cloth_layers=True))
    assert len(checks)==e['set_quantity']
    for mat in doc['materials']:
        if mat['name']in ['cloth','hem']:assert mat['occlusionTexture']['strength']==.8
    result['actual_four_layer_checks']=checks;result['set_quantity']=e['set_quantity'];result['original_jpeg_unchanged']=True;return result
if __name__=='__main__':
    p=Path(sys.argv[1]);rows=json.loads(p.read_text());checks=[]
    for e in rows:checks.append(validate(e));print('INDEPENDENT FOUR-LAYER',e['sku'],flush=True)
    out=p.with_name(p.stem+'-independent-validation.json');out.write_text(json.dumps(dict(valid=True,models=len(rows),checks=checks,canonical_changed=False),ensure_ascii=False,indent=2)+'\n');print(out,hashlib.sha256(out.read_bytes()).hexdigest())
