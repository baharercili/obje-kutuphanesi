"""Soft padded-bear comforter and a genuinely two-surface gathered blanket.

37X37 has no explicit cm unit in recovered source; display scale is qualified.
No photo lighting, silhouette billboard or hidden product size is invented.
"""
from pathlib import Path
import sys,json,copy,inspect,math
sys.dont_write_bytecode=True
import numpy as np
from PIL import Image
T=Path(__file__).resolve().parent;sys.path.insert(0,str(T))
import build_soft_linen_revision as B
import build_hooded_robe as E
A,C=B.A,B.C
D=T/'bear-comforters-prototypes01';D.mkdir(exist_ok=True);A.R=D
COLOUR={'1351309001':([235,219,196],[214,199,172]),'1351309002':([244,239,220],[230,224,202])}
def material(sku,out):
    rgb,lining=COLOUR[sku];mats=B.material(sku,dict(recipe='cotton',rgb=lining,intrinsic_ao=True,weave_period_m=.00042),out)
    N=2048;repeat=.04;px=repeat/N;x=np.arange(N)[None,:]*px;y=np.arange(N)[:,None]*px
    a=x/.0016;b=y/.00185;xx=(a+.15*np.sin(np.floor(b)*1.7))%1-.5;yy=b%1-.5
    radial=np.sqrt((xx/.35)**2+(yy/.43)**2)
    tuft=np.exp(-((radial-1)/.28)**2)*(1-.30*np.exp(-((yy+.32)/.17)**2))
    rng=np.random.default_rng(int(sku));height=.00027*tuft+rng.normal(0,.000005,(N,N))
    dy,dx=np.gradient(height,px);n=np.stack([-dx,-dy,np.ones_like(height)],2);n/=np.linalg.norm(n,axis=2,keepdims=True)
    albedo=np.clip(np.array(rgb)[None,None,:]+rng.normal(0,.7,(N,N,1)),0,255).astype(np.uint8)
    orm=np.zeros((N,N,3),np.uint8);orm[:,:,0]=np.clip(205+50*tuft,195,255);orm[:,:,1]=249
    for key,arr in [('albedo',albedo),('normal',np.clip((n+1)*127.5,0,255).astype(np.uint8)),('orm',orm)]:
        Image.fromarray(arr).save(out/(sku+'-plush-'+key+'.png'),optimize=True)
    plush=dict(baseColorFactor=[1,1,1,1],baseColorTexture=sku+'-plush-albedo.png',normalTexture=sku+'-plush-normal.png',
        metallicRoughnessTexture=sku+'-plush-orm.png',normalScale=.7,metallic=1,roughness=1,doubleSided=False,alphaMode='OPAQUE',
        extras=dict(intrinsic_material=True,physical_repeat_m=repeat,brushed_knit_loop_spacing_interpreted_m=[.0016,.00185],
            source_studio_pixels_projected=False,photo_pixels_baked=False,baked_reflections=False))
    return dict(plush=plush,lining=mats['cloth'],binding=mats['hem'],
                embroidery=dict(baseColorFactor=[.105,.145,.155,1],metallic=0,roughness=1,doubleSided=False,alphaMode='OPAQUE'))
def drape(sku):
    p=D/(sku+'-gathered-body.npz')
    if p.exists():q=np.load(p);return q['grid'],q['normals'],json.loads(p.with_suffix('.json').read_text())
    source=inspect.getsource(B.S.table_gravity).replace('def table_gravity(','def comforter_gravity(')
    source=source.replace('hw=w*(.70 if runner else .315);hl=l*.315','hw=.018;hl=.018')
    source=source.replace('anchor=(abs(U)<hw-.035)&(abs(V)<hl-.035)','anchor=(abs(U)<.008)&(abs(V)<.008)')
    source=source.replace('central=(abs(U)<w*.15)&(abs(V)<l*.15)','central=(abs(U)<.008)&(abs(V)<.008)')
    namespace=dict(B.S.__dict__);exec(compile(source,str(__file__)+':centre-sewn-cloth-simulation','exec'),namespace)
    grid,n,proof=namespace['comforter_gravity'](.37,.37,int(sku)%1000003,nu=100,nv=100,frames=260)
    proof.update(physical_flat_scale_officially_verified=False,display_flat_size_m=[.37,.37],
        attachment_neighbourhood_m=.016,support_not_exported=True,cloth_placement_on_padded_head_interpreted=True)
    np.savez_compressed(p,grid=grid,normals=n);C.dump(p.with_suffix('.json'),proof);return grid,n,proof
def soft_blob(name,mat,centre,radii,seed):
    raw=E.ellipsoid(name,mat,centre,radii,nu=64,nv=40)
    centre=np.array(centre);rx,ry,rz=radii
    verts=np.array(raw['_vertices']);q=(verts-centre)/np.array(radii)
    displacement=.00045*np.sin(q[:,0]*4+q[:,1]*3+seed)*np.sin(q[:,2]*3+.7)
    verts+=q*displacement[:,None];raw['_vertices']=[tuple(v)for v in verts]
    circumference=math.pi*(3*(rx+rz)-math.sqrt((3*rx+rz)*(rx+3*rz)))
    meridian=.5*math.pi*(3*(rx+ry)-math.sqrt((3*rx+ry)*(rx+3*ry)))
    raw['_uvs']=[(u*circumference/.04,v*meridian/.04)for u,v in raw['_uvs']]
    return raw
def face(x,y):
    z=.025*math.sqrt(max(.01,1-(x/.032)**2-((y-.044)/.034)**2))
    return np.array([x,y,z+.00065])
def build(sku):
    grid,n,proof=drape(sku);nv,nu=grid.shape[0]-1,grid.shape[1]-1
    uv=np.array([[(i/nu*.37/.04,j/nv*.37/.04)for i in range(nu+1)]for j in range(nv+1)])
    raw=[C.shell('one-continuous-gathered-brushed-blanket-outer','plush',grid+n*.00065,n,.0008,uv),
         C.shell('separate-soft-cotton-muslin-lining','lining',grid-n*.0005,n,.00045,uv)]
    for label,path in [('near',grid[0]),('far',grid[-1]),('left',grid[:,0]),('right',grid[:,-1])]:
        raw.append(C.tube(label+'-soft-sewn-blanket-edge','binding',path,.00065,sides=8))
    raw.append(soft_blob('soft-sewn-neck-joining-head-and-blanket','plush',(0,.010,0),(.011,.014,.010),.1))
    raw.append(soft_blob('soft-padded-bear-head','plush',(0,.044,0),(.032,.034,.025),.7))
    for sign in(-1,1):
        raw.append(soft_blob(('left'if sign<0 else'right')+'-soft-bear-ear','plush',(sign*.027,.071,-.001),(.010,.011,.006),sign*.6))
        raw.append(E.ellipsoid(('left'if sign<0 else'right')+'-raised-stitched-eye','embroidery',face(sign*.017,.047),(.0011,.0017,.00035),nu=20,nv=12))
    shape=[(-.004,.049),(.004,.049),(.0035,.0455),(0,.043),(-.0035,.0455)];verts=[];uvs=[];faces=[]
    for zz in(-.00025,.00025):
        for x,y in shape:p=face(x,y);p[2]+=zz;verts.append(p);uvs.append((x/.04,y/.04))
    for i in range(1,4):faces.extend([(0,i,i+1),(5,5+i+1,5+i)])
    for i in range(5):a=i;b=(i+1)%5;faces.extend([(a,b,a+5),(b,b+5,a+5)])
    raw.append(C.B.solid('actual-raised-satin-stitched-bear-nose','embroidery',verts,faces,uvs))
    raw.append(C.tube('small-embroidered-nose-stem','embroidery',[face(0,y)for y in np.linspace(.044,.0375,16)],.00040,sides=8))
    aid='hm-'+sku+'-soft-bear-comforter-two-surface-gathered-cloth'
    note=('Kaynak exact SKU37X37 beden etiketi içeriyor fakat açık santimetre birimi bulunamadı. '
          'Modelde gösterim için yaklaşık37×37cm düz örtü planı kullanıldı; resmî santimetre veya üretici kalıbı değildir. '
          'Yumuşak dolgulu ayı başı, iki kumaş kulak, kabarık yüz dikişleri ve ayrı pamuk muslin astarlı gerçek örtü katları vardır. '
          'Baş/örtü birleşimi, başın yerel ölçüleri, gizli dikiş kalıbı, kumaş optiği ve37cm gösterim ölçeği fotoğraf yorumudur.')
    meta=A.base_metadata(sku,aid,dict(set_quantity=1),note,'fleece',1,
        estimated_fields=['unverified_display_flat_size_37x37cm','head_and_neck_pattern_and_filling_volume','embroidery_and_ear_profile',
            'hidden_lining_pattern','composition_roles_to_visible_surfaces','loop_texture_scale_and_colour'])
    meta.update(source_dimensions_hwd_cm=[None,None,None],interpreted_display_flat_size_cm=[37,37],
        cloth_arc_length_validation=[proof],comforter_features=dict(padded_bear_head=True,bear_not_rabbit=True,
            separate_muslin_lining=True,raised_eye_nose_stitches=True,actual_blanket_flat_scale_officially_verified=False),
        material_label='Resmî bileşenler: Shell pamuk%100; Top polyester%70, diğer lifler%30 · Görsel katman eşlemesi yorum',
        quality_status='photo_interpretation',quality_label='Ayı başı ve astarlı yumuşak örtü · Ölçek yaklaşık')
    meta['source_evidence_files'].append(str(T/'additional-exact-role-research.json'))
    entry=A.finish(raw,meta,lambda out:material(sku,out),features=meta['comforter_features'])
    path=D/'candidate-bear-comforters-manifest.json';rows=json.loads(path.read_text())if path.exists()else[]
    C.dump(path,[e for e in rows if e['sku']!=sku]+[entry]);print('BEAR COMFORTER CANDIDATE',sku,flush=True)
if __name__=='__main__':
    for sku in sys.argv[1:]:build(sku)
