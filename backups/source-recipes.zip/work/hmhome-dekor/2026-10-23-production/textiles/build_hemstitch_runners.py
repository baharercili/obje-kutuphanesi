"""Both source hemstitch runners, with a broad support and two-end drape."""
from pathlib import Path
import sys,json,inspect
sys.dont_write_bytecode=True
T=Path(__file__).resolve().parent;sys.path.insert(0,str(T))
import build_real_hemstitch as H
D=T/'hemstitch-runners-batch01';D.mkdir(exist_ok=True);H.D=D;H.A.R=D
H.CONFIG={sku:dict(rgb=rgb,recipe='cotton',hem=.025,gap=.0009,thread_spacing=.0024,
    weave_period_m=.00024,normal_scale=.42,intrinsic_ao=True)for sku,rgb in
    [('1333728008',[150,10,34]),('1333728009',[27,49,31])]}
URL={'1333728008':'https://www2.hm.com/pt_pt/productpage.1333728008.html',
     '1333728009':'https://www2.hm.com/sk_sk/productpage.1333728009.html'}
BASE=H.A.base_metadata
def metadata(sku,aid,official,note,recipe,**kw):
    e=H.A.L.EVIDENCE[sku];size=e['official_flat_size_cm'];p=T/'source-evidence'/('public-reader-runner-'+sku+'.txt')
    e['supplement']=dict(composition=['Cotton 100%'],source_urls=[URL[sku]],exact_sku_identity_verified=True,evidence_file=str(p))
    note=(f'Resmî düz runner ölçüsü {size[0]:g}×{size[1]:g} cm; exact SKU resmî açıklaması pamuk100% ve2,5cm kenar kıvrımını doğrular. '
          'Gerçek açık ajur bandı ve ayrı iplik köprüleri vardır, altında opak kumaş yoktur. '
          'Runner desteği kumaştan geniş seçildiği için yalnız kısa uçlar doğal sarkar; destek masası varlığa dahil değildir. '
          'Mikroskobik0,9mm açıklık,2,4mm iplik grubu aralığı, kumaş kalınlığı, dikiş ve yerel poz fotoğraf yorumudur; tel sayısı doğrulanmadı.')
    m=BASE(sku,aid,dict(flat_item_size_cm=size,hem_turn_cm=2.5),note,recipe,**kw)
    m['source_evidence_files'].append(str(p));return m
H.A.base_metadata=metadata
source=inspect.getsource(H.build)
source=source.replace('B.S.table_gravity(w,l,int(sku)%1000003)','B.S.table_gravity(w,l,int(sku)%1000003,runner=True)')
old="gallery=next(e for e in json.loads((T/'gallery-originals/masters.json').read_text())if e['sku']==sku);meta['original_images'].append({k:gallery[k]for k in['path','url','sha256']});"
assert old in source;source=source.replace(old,'')
source=source.replace("meta['source_evidence_files'].append(str(extra));", "meta['source_evidence_files']+=([str(extra)]if extra.exists()else[]);")
exec(compile(source,str(__file__)+':approved-openwork-runner-adaptation','exec'),H.__dict__)
if __name__=='__main__':
    for sku in(list(H.CONFIG)if '--all'in sys.argv else sys.argv[1:]):H.build(sku)
