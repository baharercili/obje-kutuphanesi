"""Material-only own clean-cloth crop revision; every geometry byte stays identical."""
from pathlib import Path
import sys,json,struct,copy,subprocess,hashlib,numpy as np
sys.dont_write_bytecode=True
T=Path(__file__).resolve().parent;sys.path.insert(0,str(T))
import native_surface_materials as N
import specific_binary_native_material as V
from freeze_polar_knit_review_candidates import attr,glb,sha,dump
D=T/'remaining-source-specific-polar-robes-revision02';D.mkdir(exist_ok=True)
def write_glb(path,doc,binary):
 doc['buffers'][0]['byteLength']=len(binary);j=json.dumps(doc,separators=(',',':'),ensure_ascii=False).encode();j+=b' '*((-len(j))%4);binary+=b'\0'*((-len(binary))%4);Path(path).write_bytes(struct.pack('<III',0x46546c67,2,28+len(j)+len(binary))+struct.pack('<II',len(j),0x4e4f534a)+j+struct.pack('<II',len(binary),0x004e4942)+binary)
def build(e):
 old=Path(e['asset_dir']);out=D/'models'/e['id'];assert not out.exists();out.parent.mkdir(exist_ok=True);subprocess.run(['/usr/bin/ditto','--clone',str(old),str(out)],check=True);N.fleece(e['original_image'],[500,1800,628,1928],out,int(e['sku']))
 doc,binary=glb(e['glb_path']);newdoc=copy.deepcopy(doc);imageviews={im['bufferView']:out/im['name']for im in doc['images']};parts=[];offset=0
 for k,view in enumerate(doc['bufferViews']):
  content=imageviews[k].read_bytes()if k in imageviews else binary[view.get('byteOffset',0):view.get('byteOffset',0)+view['byteLength']]
  newdoc['bufferViews'][k]['byteOffset']=offset;newdoc['bufferViews'][k]['byteLength']=len(content);content+=b'\0'*((-len(content))%4);parts.append(content);offset+=len(content)
 target=out/Path(e['glb_path']).name;write_glb(target,newdoc,b''.join(parts));nd,nb=glb(target);proof=[]
 for a,b in zip(doc['meshes'],nd['meshes']):
  checks=[]
  for p,q in zip(a['primitives'],b['primitives']):
   for key in ['POSITION','NORMAL','TEXCOORD_0','TANGENT']:
    before=attr(doc,binary,p['attributes'][key]);after=attr(nd,nb,q['attributes'][key]);assert before==after;checks.append(dict(attribute=key,sha256=before))
   before=attr(doc,binary,p['indices']);after=attr(nd,nb,q['indices']);assert before==after;checks.append(dict(attribute='indices',sha256=before))
  proof.append(dict(mesh=a['name'],unchanged=checks))
 new=copy.deepcopy(e)
 for k in ['asset_dir','model_path','glb_path','geometry_validation','material_validation']:new[k]=str(out)+str(e[k])[len(str(old)):]
 new['sha256']=sha(target);new['bytes']=target.stat().st_size;new['model_revision']='hmhome-own-clean-fleece-crop-2026-10-24-r2';dump(out/'entry.json',new)
 validation=json.loads((out/'material-validation.json').read_text())
 for m in validation['maps']:m['path']=str(out/m['file']);m['sha256']=sha(m['path'])
 dump(out/'material-validation.json',validation)
 reportpath=out/(e['id']+'.validation.json');report=json.loads(reportpath.read_text());report['glb_bytes']=new['bytes'];report['deliverable_sha256']['glb']=new['sha256'];report['files']={k:str(out)+v[len(str(old)):]if isinstance(v,str)and v.startswith(str(old))else v for k,v in report['files'].items()};dump(reportpath,report)
 dump(out/'material-only-geometry-preservation-proof.json',dict(old_glb=str(e['glb_path']),old_glb_sha256=e['sha256'],all_geometry_accessor_bytes_identical=True,model_json_byte_identical=sha(old/'model.json')==sha(out/'model.json'),old_frozen_preserved=True,checks=proof));return new
if __name__=='__main__':
 source=T/'remaining-source-specific-polar-robes-batch01/frozen-own-source-specific-polar-robes-03-manifest.json';entries=[build(e)for e in json.loads(source.read_text())];checks=[V.check(e)for e in entries];manifest=D/'frozen-clean-own-source-polar-robes-03-manifest.json';assert not manifest.exists();dump(D/'independent-clean-own-source-polar-robes-validation.json',dict(valid=True,scope_counted_ready=False,models=3,checks=checks));dump(manifest,entries);print(manifest,sha(manifest),flush=True)
