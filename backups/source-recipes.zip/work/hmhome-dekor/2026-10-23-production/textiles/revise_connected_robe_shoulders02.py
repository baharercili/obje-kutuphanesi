"""Hollow garment body with closed shoulder fabric and connected sleeve roots.

The earlier notched shoulders are held and unchanged. Neck is a real local
opening cut through shoulder cloth rather than the whole top left missing.
"""
from pathlib import Path
import sys,json,math,numpy as np
T=Path(__file__).resolve().parent;sys.path.insert(0,str(T));import implicit_cloth as I
D=T/'robes-soft-shoulders-revision02';D.mkdir(exist_ok=True)
def field(step=.003):
 x=np.arange(-.29,.29+step,step,dtype=np.float32);y=np.arange(-.025,.565+step,step,dtype=np.float32);z=np.arange(-.125,.135+step,step,dtype=np.float32);X=x[:,None,None];Y=y[None,:,None];Z=z[None,None,:];v=np.clip(Y/.53,0,1);rx=.16-.026*np.exp(-((v-.56)/.22)**2);rz=.077-.009*np.exp(-((v-.56)/.23)**2);angle=np.arctan2(X,Z);wrinkle=.0017*np.sin(angle*6+Y*8)*np.sin(np.pi*v)+.001*np.sin(angle*3-Y*7);top=.535-.058*(np.minimum(abs(X)/.17,1.3)**1.6)
 def body(inner):
  off=.0048 if inner else 0;radial=(np.sqrt((X/(rx-off))**2+(Z/(rz-off))**2)-1)*np.minimum(rx-off,rz-off)-wrinkle;bottom=-Y-(.025 if inner else 0);cap=Y-(top-off);return np.maximum(radial,np.maximum(bottom,cap))
 outer=body(False);inner=body(True)
 neck=np.maximum((np.sqrt((X/.070)**2+((Z+.010)/.045)**2)-1)*.045,.40-Y);inner=I.smooth_min(inner,neck,.008)
 for sign in[-1,1]:
  a=np.array([sign*.120,.460,.003],np.float32);b=np.array([sign*.220,.205,.018],np.float32);d=b-a;length=float(np.linalg.norm(d));t=((X-a[0])*d[0]+(Y-a[1])*d[1]+(Z-a[2])*d[2])/float(d@d);cx=a[0]+t*d[0];cy=a[1]+t*d[1];cz=a[2]+t*d[2];radial=np.sqrt((X-cx)**2+(Y-cy)**2+(Z-cz)**2);radius=.054-(.011)*np.clip(t,0,1)
  arm=np.maximum(radial-radius,np.maximum((-t-.13)*length,(t-1)*length));cavity=np.maximum(radial-(radius-.0048),np.maximum((-t+.01)*length,(t-1.20)*length));outer=I.smooth_min(outer,arm,.024);inner=I.smooth_min(inner,cavity,.018)
 material=np.maximum(outer,-inner);gap=.0035+.030*v**6;front_cut=np.maximum(abs(X)-gap,-Z);material=np.maximum(material,-front_cut);return material,(float(x[0]),float(y[0]),float(z[0])),step
if __name__=='__main__':
 f,origin,step=field();v,faces=I.surface(f,origin,step);print('MARCHED',len(v),len(faces),flush=True);v,faces,proof=I.collapse_slivers(v,faces,min_edge=.000015,min_area=1.05e-12,max_passes=10);np.savez_compressed(D/'connected-real-neck-shoulder-sleeves.npz',vertices=v,faces=faces);(D/'connected-real-neck-shoulder-proof.json').write_text(json.dumps(proof,indent=2)+'\n');print('CLEAN',len(v),len(faces),proof,flush=True)
