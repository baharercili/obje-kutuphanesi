"""Prepared source-specific rabbit/dog ears and bear-pocket face, no bulk exports."""
from pathlib import Path
import math,numpy as np
from PIL import Image,ImageFilter

def floppy_ear(C,sign,kind='rabbit'):
 N=40;K=64;length=.120 if kind=='rabbit'else.085;width=.017 if kind=='rabbit'else.025;thickness=.0037;v=[];uv=[];f=[]
 def centre(t):return np.array([sign*(.074+.035*math.sin(t*math.pi*.8)),.665-length*t,-.020+.015*math.sin(t*math.pi)])
 # Rounded finite cloth-solid endpoints retain real soft volume.
 v.append(centre(0));uv.append((.5,0))
 for j,t in enumerate(np.linspace(0,1,K+1)[1:-1]):
  taper=math.sin(math.pi*t)**.46
  for i,a in enumerate(np.linspace(0,math.tau,N,endpoint=False)):
   p=centre(t)+np.array([width*taper*math.cos(a),.004*math.sin(a)*math.sin(t*math.pi),thickness*taper*math.sin(a)]);v.append(p);uv.append((i/N*.06/.04,t*length/.04))
 end=len(v);v.append(centre(1));uv.append((.5,length/.04))
 for i in range(N):f.append((0,1+i,1+(i+1)%N))
 rings=K-1
 for j in range(rings-1):
  for i in range(N):a=1+j*N+i;b=1+j*N+(i+1)%N;c=a+N;d=b+N;f +=[(a,c,b),(b,c,d)]
 for i in range(N):f.append((end,1+(rings-1)*N+(i+1)%N,1+(rings-1)*N+i))
 return C.B.solid(('left'if sign<0 else'right')+'-own-source-soft-floppy-'+kind+'-ear','cloth',v,f,uv)

def own_bear_face(master,out):
 box=[435,1510,630,1635];im=Image.open(master).convert('RGB').crop(box);p=np.asarray(im,float);yy,xx=np.indices(p.shape[:2]);region=(((xx-30)/19)**2+((yy-22)/22)**2<1)|(((xx-177)/19)**2+((yy-25)/22)**2<1)|((xx>76)&(xx<122)&(yy>42)&(yy<116));ink=(p.mean(2)<165)&((p[:,:,2]+1)/(p[:,:,0]+1)>.96)&region;ink|=(p.mean(2)<85)&(xx>85)&(xx<113)&(yy>49)&(yy<91);padded=np.pad(ink,2);near=sum(padded[i:i+ink.shape[0],j:j+ink.shape[1]]for i in range(5)for j in range(5))>0;highlights=near&(p.mean(2)>180)&((p[:,:,2]+1)/(p[:,:,0]+1)>.9);mask=ink|highlights
 # Fit only the surrounding fabric's broad illumination plane. Preserve the native
 # embroidery's actual grey/black/white yarn colours rather than painting a grey icon.
 background=(~near)&(p.mean(2)>130)&(p.mean(2)<230);basis=np.stack([np.ones_like(xx),xx/195,yy/125],2);rgb=p.copy()
 for k in range(3):
  coeff=np.linalg.lstsq(basis[background],p[:,:,k][background],rcond=None)[0];plane=np.einsum('ijk,k->ij',basis,coeff);rgb[:,:,k]*=np.median(plane[background])/np.maximum(plane,1)
 rgba=np.zeros((*mask.shape,4),np.uint8);rgba[:,:,:3]=np.uint8(np.clip(rgb,0,255));rgba[:,:,3]=mask.astype('uint8')*255;im.save(out/'own-bear-pocket-native-crop.png');Image.fromarray(rgba,'RGBA').save(out/'own-bear-pocket-intrinsic-face.png');return Image.fromarray(rgba,'RGBA'),box

def bear_pocket(C,A,sign):
 W=.082;H=.092;cx=sign*.080;cy=.195;g=[];uv=[]
 def garment(x,y):
  v=np.clip(y/.53,0,1);rx=.16-.028*math.exp(-((v-.56)/.22)**2);rz=.077-.010*math.exp(-((v-.56)/.23)**2);return rz*math.sqrt(max(.01,1-(x/rx)**2))
 for v in np.linspace(0,1,57):
  row=[];tex=[]
  for u in np.linspace(0,1,49):
   x=(u-.5)*W;y=(v-.5)*H
   if abs(x)>W/2-.023 and y<-H/2+.023:
    a=(abs(x)-(W/2-.023))/.023;b=(-y-(H/2-.023))/.023;x=math.copysign(W/2-.023+.023*a*math.sqrt(1-b*b*.5),x);y=-(H/2-.023+.023*b*math.sqrt(1-a*a*.5))
   xx=cx+x;yy=cy+y;z=garment(xx,yy)+.005+.0025*math.sin(u*math.pi)*math.sin(v*math.pi)+.0006*math.sin(u*7+v*5);row.append([xx,yy,z]);tex.append((u,v))
  g.append(row);uv.append(tex)
 g=np.array(g);n=np.cross(np.gradient(g,axis=1),np.gradient(g,axis=0));n/=np.linalg.norm(n,axis=2,keepdims=True);raw=[C.shell(('left'if sign<0 else'right')+'-source-rounded-bear-open-pocket','bear_pocket_face',g,n,.0018,np.array(uv))]
 for label,path in [('left',g[:,0]),('right',g[:,-1]),('bottom',g[0])]:
  strip=np.array([[p,[p[0],p[1],garment(p[0],p[1])+.0005]]for p in path]);sn=np.cross(np.gradient(strip,axis=1),np.gradient(strip,axis=0));sn/=np.linalg.norm(sn,axis=2,keepdims=True);raw.append(C.shell(('left'if sign<0 else'right')+'-'+label+'-closed-bear-pocket-seam','cloth',strip,sn,.0012,np.array([[(0,0),(1,1)]for p in path])))
 raw.append(C.tube(('left'if sign<0 else'right')+'-real-open-bear-pocket-top-edge','hem',g[-1],.0017,sides=8))
 return raw,g,n,garment
