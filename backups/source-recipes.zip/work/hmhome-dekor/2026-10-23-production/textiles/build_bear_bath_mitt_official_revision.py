"""Hollow cotton-terry bear bath mitt, exact photo with explicitly estimated scale.

The bottom is a real hand opening. Eyes/nose/mouth are raised stitches, not a
photograph projected on a solid block. Native own-SKU pile crop is preserved.
"""
from pathlib import Path
import json,sys,math,copy
import numpy as np
from PIL import Image
sys.dont_write_bytecode=True
T=Path(__file__).resolve().parent;sys.path.insert(0,str(T));import build_soft_linen_revision as B
import build_hooded_robe as E
A=B.A;C=B.C;D=T/'bath-mitt-official-nominal-revision01';D.mkdir(exist_ok=True);A.R=D
H=.21;N=128;NV=100;TH=.0018
def radii(y):
    v=np.clip(y/H,0,1);top=np.clip((v-.84)/.16,0,1);top=top*top*(3-2*top);rx=.078+.004*math.sin(math.pi*v)-.008*top;rz=.0115+.0012*math.sin(math.pi*v)-.0095*top
    return rx,rz
def front(x,y):
    rx,rz=radii(y);return np.array([x,y,rz*math.sqrt(max(0,1-(x/rx)**2))+.00045])
def hollow_body():
    vertices=[];uv=[];faces=[]
    for inner in[False,True]:
        top=H-TH if inner else H
        for j,y in enumerate(np.linspace(0,top,NV+1)):
            rx,rz=radii(y);rx-=TH if inner else 0;rz-=TH if inner else 0
            for i,theta in enumerate(np.linspace(0,math.tau,N,endpoint=False)):
                x=rx*math.cos(theta);z=rz*math.sin(theta);z+=.0004*math.sin(theta)**3*math.sin(y/H*7);vertices.append([x,y,z]);uv.append([x/.04,y/.04])
    count=(NV+1)*N
    for inner in[False,True]:
        offset=count if inner else 0
        for j in range(NV):
            for i in range(N):
                a=offset+j*N+i;b=offset+j*N+(i+1)%N;c=a+N;d=b+N
                faces.extend([(a,c,b),(b,c,d)]if not inner else[(a,b,c),(b,d,c)])
        centre=len(vertices);vertices.append([0,H-TH if inner else H,0]);uv.append([0,(H-TH if inner else H)/.04])
        for i in range(N):
            a=offset+NV*N+i;b=offset+NV*N+(i+1)%N;faces.append((centre,a,b)if not inner else(centre,b,a))
    # Join only the bottom cloth rim, leaving the inner hand cavity open.
    for i in range(N):a=i;b=(i+1)%N;c=count+i;d=count+(i+1)%N;faces.extend([(a,b,c),(b,d,c)])
    return C.B.solid('real-hollow-cotton-bath-mitt-hand-cavity','cloth',vertices,faces,uv)
def flat_hang_loop():
    vertices=[];uv=[];faces=[];n=80
    for outer,z in[(True,-.00035),(True,.00035),(False,.00035),(False,-.00035)]:
        for i in range(n):
            a=math.tau*i/n;rx=.0045 if outer else.0018;ry=.015 if outer else.0105;vertices.append([.061+rx*math.cos(a),-.012+ry*math.sin(a),z]);uv.append([i/n,0])
    for k in range(4):
        for i in range(n):a=k*n+i;b=k*n+(i+1)%n;c=((k+1)%4)*n+i;d=((k+1)%4)*n+(i+1)%n;faces.extend([(a,b,c),(b,d,c)])
    return C.B.solid('real-flat-woven-hanging-loop','hem',vertices,faces,uv)
def materials(sku,out):
    ev=A.L.EVIDENCE[sku];master=ev['original'];assert C.sha(master['path'])==master['sha256'];box=[500,700,628,828];im=Image.open(master['path']).convert('RGB');patch=im.crop(box);raw=np.asarray(patch,dtype=float);fy=np.fft.fftfreq(128)[:,None];fx=np.fft.rfftfreq(128)[None,:];blur=np.exp(-2*math.pi**2*13**2*(fx*fx+fy*fy));illum=np.stack([np.fft.irfft2(np.fft.rfft2(raw[:,:,k])*blur,s=raw.shape[:2])for k in range(3)],2);palette=np.median(raw.reshape(-1,3),0);intrinsic=np.clip(raw/np.maximum(1,illum)*palette,0,255).astype(np.uint8);Image.fromarray(intrinsic,'RGB').save(out/(sku+'-native-pile-albedo.png'),optimize=True)
    size=2048;x=np.arange(size)[None,:]/size*.04;y=np.arange(size)[:,None]/size*.04;rng=np.random.default_rng(int(sku));px=x/.0011;py=y/.0013;cx=(px+.10*np.sin(np.floor(py)*1.7))%1-.5;cy=py%1-.5;r=np.sqrt((cx/.36)**2+(cy/.43)**2);loops=np.exp(-((r-1)/.24)**2)*(1-.38*np.exp(-((cy+.35)/.12)**2));height=loops*.00025+rng.normal(0,.000004,(size,size));dy,dx=np.gradient(height,.04/size);normal=np.stack([-dx,-dy,np.ones_like(dx)],2);normal/=np.linalg.norm(normal,axis=2,keepdims=True);orm=np.zeros((size,size,3),np.uint8);orm[:,:,0]=np.clip(190+65*loops,0,255);orm[:,:,1]=246
    Image.fromarray(np.clip((normal+1)*127.5,0,255).astype(np.uint8),'RGB').save(out/(sku+'-normal.png'),optimize=True);Image.fromarray(orm,'RGB').save(out/(sku+'-orm.png'),optimize=True)
    cloth=dict(baseColorFactor=[1,1,1,1],baseColorTexture=sku+'-native-pile-albedo.png',normalTexture=sku+'-normal.png',metallicRoughnessTexture=sku+'-orm.png',metallic=1,roughness=1,normalScale=.8,doubleSided=False,alphaMode='OPAQUE',extras=dict(intrinsic_material=True,own_photo_material_crop=True,photo_pixels_baked=True,baked_reflections=False,native_crop_size=[128,128],native_crop_physical_repeat_m=.022,normal_repeat_m=.04,pile_geometry_scale_interpreted_mm=[1.1,1.3,.25]))
    hem=dict(baseColorFactor=[float(c/255)for c in palette]+[1],metallic=0,roughness=.97,doubleSided=False,alphaMode='OPAQUE',extras=dict(photo_pixels_baked=False,baked_reflections=False));thread=dict(baseColorFactor=[.29,.25,.23,1],metallic=0,roughness=1,doubleSided=False,alphaMode='OPAQUE',extras=dict(photo_pixels_baked=False,baked_reflections=False))
    C.dump(out/'native-pile-provenance.json',dict(master=master,source_crop=box,native_output_pixels=[128,128],geometric_resampling_count=0,source_upscaled=False,method='Native exact-SKU cotton-pile-only patch, local 13-pixel Gaussian illumination removed in float64. No silhouette, face embroidery, wall or broad drape shadow included.',physical_repeat_m_photo_estimated=.022,loop_spacing_and_relief_estimated_mm=[1.1,1.3,.25]));return dict(cloth=cloth,hem=hem,embroidery=thread)
def build():
    sku='1041734004';raw=[hollow_body()]
    for sign in[-1,1]:
        raw.append(E.ellipsoid(('left'if sign<0 else'right')+'-soft-terry-bear-ear','cloth',(sign*.062,.215,0),(.024,.025,.0065),nu=48,nv=28))
        raw.append(C.tube(('left'if sign<0 else'right')+'-ear-fold-stitch','hem',[[sign*.062+.003*math.sin(q*math.pi),.202+.022*q,.0066]for q in np.linspace(0,1,25)],radius=.00035,sides=6))
    for sign in[-1,1]:
        raw.append(C.tube(('left'if sign<0 else'right')+'-raised-sleeping-eye-embroidery','embroidery',[front(sign*.025+.007*math.cos(a),.113-.0025*math.sin(a))for a in np.linspace(0,math.pi,33)],radius=.00065,sides=8))
    shape=[[-.005,.108],[.005,.108],[.003,.104],[0,.101],[-.003,.104]];v=[];uv=[];f=[]
    for sign in[-1,1]:
        for x,y in shape:p=front(x,y);p[2]+=sign*.00045;v.append(p.tolist());uv.append([x/.01,y/.01])
    for i in range(1,4):f.extend([(0,i,i+1),(5,5+i+1,5+i)])
    for i in range(5):a=i;b=(i+1)%5;f.extend([(a,b,a+5),(b,b+5,a+5)])
    raw.append(C.B.solid('raised-filled-embroidered-bear-nose','embroidery',v,f,uv));raw.append(C.tube('nose-to-mouth-stitched-stem','embroidery',[front(0,y)for y in np.linspace(.102,.096,12)],radius=.00055,sides=8))
    for sign in[-1,1]:raw.append(C.tube(('left'if sign<0 else'right')+'-raised-mouth-stitch','embroidery',[front(sign*.007*q,.096-.0015*math.sin(math.pi*q))for q in np.linspace(0,1,20)],radius=.00055,sides=8))
    # Periodic woven cuff band with its actual central hand opening.
    vv=[];tex=[];ff=[]
    for j,y in enumerate(np.linspace(0,.005,5)):
        rx,rz=radii(y)
        for i,a in enumerate(np.linspace(0,math.tau,N,endpoint=False)):vv.append([(rx+.0004)*math.cos(a),y,(rz+.0004)*math.sin(a)]);tex.append([i/N,y/.04])
    for j in range(4):
        for i in range(N):a=j*N+i;b=j*N+(i+1)%N;c=a+N;d=b+N;ff.extend([(a,c,b),(b,c,d)])
    raw.append(A.open_surface_shell('plain-woven-open-bottom-cuff-band','hem',vv,ff,[list(range(N-1,-1,-1)),list(range(4*N,5*N))],tex,.00065));raw.append(flat_hang_loop())
    # Nominal boundary allocation is interpreted: fit the visible mitt including
    # ears but excluding its small hanging loop to the newly found15x20cm label.
    nonhanger=np.concatenate([g['_vertices']for g in raw if g['name']!='real-flat-woven-hanging-loop']);lo=nonhanger.min(0);hi=nonhanger.max(0);sx=.15/(hi[0]-lo[0]);sy=.20/(hi[1]-lo[1]);scale=np.array([sx,sy,sx])
    for g in raw:
        g['_vertices']=[tuple(np.array(v)*scale)for v in g['_vertices']]
        if g['name']=='real-hollow-cotton-bath-mitt-hand-cavity':g['_uvs']=[(u*sx,v*sy)for u,v in g['_uvs']]
        elif g['name'].endswith('-soft-terry-bear-ear'):
            ax=.024*sx;az=.0065*sx;ay=.025*sy;circ=math.pi*(3*(ax+az)-math.sqrt((3*ax+az)*(ax+3*az)));meridian=.5*math.pi*(3*(ax+ay)-math.sqrt((3*ax+ay)*(ax+3*ay)));g['_uvs']=[(u*circ/.04,v*meridian/.04)for u,v in g['_uvs']]
    aid='hm-'+sku+'-hollow-terry-bear-mitt-official-nominal15x20-r2';note='H&M Hindistan exact SKU ürün kaydında15×20 cm nominal beden ve %100 pamuk doğrulandı. Kaynak, bu20cm boya kulak veya askı halkasının dahil olup olmadığını açıklamıyor. Bu modelde kulak dahil görünür eldiven, küçük asma halkası hariç15×20 cm olarak paylaştırıldı; bu ölçüm sınırı fotoğraf yorumudur, resmî kesim veya sınır tanımı değildir. Bu nedenle askı dahil toplam model kutusu nominal20cmden farklıdır. Altı gerçekten açık el cebi, iki kulak, düz dokuma ağız bandı, gerçek açık asma halkası ve kabarık yüz dikişleri vardır. İlmek aralığı, kumaş kalınlığı, gizli iç yapı ve optik doku yorumdur.';meta=A.base_metadata(sku,aid,dict(nominal_width_cm=15,nominal_length_cm=20),note,'cotton_terry',estimated_fields=['nominal_size_boundary_allocation_including_ears_excluding_hanger_photo_interpreted','hand_cavity_and_fabric_thickness','ear_and_embroidery_profiles','pile_repeat_and_optics']);meta.update(material_label='Pamuk %100 · Organik pamuk',photo_pixels_baked=True,native_texture_resolution='128 native own-SKU pile crop + 2048 intrinsic terry relief PBR',quality_status='photo_interpretation',quality_label='Resmî nominal15×20 · Ölçüm sınırı yorum',bath_mitt_features=dict(actual_open_bottom_hand_cavity=True,soft_bear_ears=2,raised_eye_nose_mouth_stitches=True,actual_open_hanging_loop=True,manufacturer_cut_pattern_unconfirmed=True))
    meta['source_market']='IN';meta['source_size_pointer']=str(T/'additional-exact-role-research.json')+'#'+sku;meta['source_evidence_files'].append(str(T/'additional-exact-role-research.json'));meta['nominal_boundary_allocation']=dict(includes_ears=True,excludes_hanging_loop=True,manufacturer_boundary_verified=False,interpreted_frame_width_cm=15,interpreted_frame_height_cm=20)
    entry=A.finish(raw,meta,lambda out:materials(sku,out),features=meta['bath_mitt_features']);doc,binary=C.read_glb(entry['glb_path'])
    for mat in doc['materials']:
        if mat['name']=='cloth':mat['pbrMetallicRoughness']['baseColorTexture'].setdefault('extensions',{})['KHR_texture_transform']=dict(scale=[.04/.022,.04/.022]);mat['occlusionTexture']={**mat['pbrMetallicRoughness']['metallicRoughnessTexture'],'strength':.65}
    doc['extensionsUsed']=sorted(set(doc['extensionsUsed'])|{'KHR_texture_transform'});C.write_glb(entry['glb_path'],doc,binary);entry['sha256']=C.sha(entry['glb_path']);entry['bytes']=Path(entry['glb_path']).stat().st_size;entry['native_pile_provenance']=str(Path(entry['asset_dir'])/'native-pile-provenance.json');out=Path(entry['asset_dir']);C.dump(out/'entry.json',entry);rp=out/(aid+'.validation.json');report=json.loads(rp.read_text());report['deliverable_sha256']['glb']=entry['sha256'];report['glb_bytes']=entry['bytes'];C.dump(rp,report);p=out/'material-validation.json';m=json.loads(p.read_text());m.update(photo_pixels_baked=True,photo_lighting_baked=False,own_native_crop=True,no_source_upscale=True);C.dump(p,m);C.dump(D/'candidate-bath-mitt-manifest.json',[entry]);print('BATH MITT REVIEW',sku,flush=True)
if __name__=='__main__':build()
