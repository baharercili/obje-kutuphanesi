"""Remaining cream exact source; run after root's actual coarse-knit method gate."""
from pathlib import Path
import sys,subprocess
sys.dont_write_bytecode=True
T=Path(__file__).resolve().parent;sys.path.insert(0,str(T))
import build_bear_clean_forehead_revision10 as R
Q=R.Q;D=T/'remaining-cream-own-knit-bear-batch01';D.mkdir(exist_ok=True)
for name in ['actual-square-relaxed-cloth.npz','actual-square-relaxed-cloth-proof.json']:
 if not(D/name).exists():subprocess.run(['/usr/bin/ditto','--clone',str(R.D/name),str(D/name)],check=True)
Q.D=D;Q.P.D=D;Q.M.D=D;Q.A.R=D
BASE_FINISH=R.OLD_FINISH
def finish(raw,meta,mf,features=None):
 meta['id']='hm-'+meta['sku']+'-own-cream-coarse-knit-soft-square-bear-comforter';return BASE_FINISH(raw,meta,mf,features)
Q.ORIGINAL_FINISH=finish
if __name__=='__main__':Q.M.build('1351309002')
