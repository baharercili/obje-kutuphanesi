"""Source-specific broad cross-striped neck strap and straight tall pleated crown."""
from pathlib import Path
import sys,copy,math,json,numpy as np
from PIL import Image
sys.dont_write_bytecode=True
T=Path(__file__).resolve().parent;sys.path.insert(0,str(T))
import revise_child_ruffle_and_chef_hat02 as Q
import specific_binary_native_material as V
M=Q.M;A=M.A;C=M.C;D=T/'chef-wide-cross-striped-strap-tall-pleated-crown-revision03';D.mkdir(exist_ok=True);M.D=D;A.R=D
OLD_POINT=M.point
def point(u,v):
 if M.CURRENT.get('kind')!='chef_set':return OLD_POINT(u,v)
 c=M.CURRENT;w,body=c['w'],c['body'];width=np.interp(v,[0,.49,.51,1],[w*.47,w*.47,w,w]);x=(u-.5)*width;y=(1-v)*body;z=.009*math.sin(u*math.tau*3.1+.25*math.sin(v*5))*(.22+.78*v)+.004*math.sin(v*11+u*3)+.024*v*v+.008*math.sin(math.pi*u)**2*math.sin(math.pi*v);return np.array([x,y,z])
M.point=point;M.M.point=point
def wide_neck_strap(path):
 p=np.array(path);t=np.gradient(p,axis=0);a=np.stack([-t[:,1],t[:,0],np.zeros(len(t))],1);a/=np.linalg.norm(a,axis=1,keepdims=True);u=np.linspace(-.5,.5,9);g=p[:,None,:]+a[:,None,:]*u[None,:,None]*.04;n=np.cross(np.gradient(g,axis=1),np.gradient(g,axis=0));n/=np.linalg.norm(n,axis=2,keepdims=True);arc=np.r_[0,np.cumsum(np.linalg.norm(np.diff(p,axis=0),axis=1))];uv=np.empty((*g.shape[:2],2));uv[:,:,0]=(u+.5)[None,:];uv[:,:,1]=arc[:,None]/.04;C.dump(D/'wide-flat-neck-strap-proof.json',dict(interpreted_width_cm=4,official_width_claimed=False,actual_cross_width_range_m=np.linalg.norm(g[:,-1]-g[:,0],axis=1)[[0,-1]].tolist(),flat_finite_thickness_cloth=True,stripes_perpendicular_to_path=True));return C.shell('own-wide-flat-cross-striped-neck-strap','neck_strap',g,n,.0007,uv)
M.wide_neck_strap=wide_neck_strap
def hat():
 N=160;rows=[];tex=[]
 for y in np.linspace(0,.188,70):
  if y<.045:base=.085
  elif y<.065:
   f=(y-.045)/.020;base=.085+.028*f*f*(3-2*f)
  else:base=.113
  envelope=np.clip((y-.044)/.021,0,1);envelope=envelope*envelope*(3-2*envelope);row=[];uv=[]
  for i in range(N):
   a=i/N*math.tau;phase=a*12+.12*math.sin(a*3)+.13*math.sin(y*12);pleat=.010*math.sin(phase)+.0014*math.sin(2*phase+.7);r=base+envelope*pleat;row.append([r*math.cos(a),y+.0008*envelope*math.sin(a*5+y*15),r*math.sin(a)]);uv.append([a*.113/.04,y/.04])
  rows.append(row);tex.append(uv)
 # Rounded upper corner to a shallow, softly gathered closed crown, not a ball.
 for s in np.linspace(0,1,13)[1:]:
  r=.113*(1-.11*s);y=.188+.007*math.sin(s*math.pi/2);row=[];uv=[]
  for i in range(N):
   a=i/N*math.tau;fold=(.010*math.sin(a*12+.12*math.sin(a*3)+.13*math.sin(y*12))+.0014*math.sin(a*24+.7))*(1-s*.4);row.append([(r+fold)*math.cos(a),y,(r+fold)*math.sin(a)]);uv.append([a*.113/.04,y/.04])
  rows.append(row);tex.append(uv)
 for s in np.linspace(0,1,20)[1:-1]:
  r=.113*.89*(1-s);y=.195+.005*(1-(1-s)**2);row=[];uv=[]
  for i in range(N):
   a=i/N*math.tau;fold=(.006*math.sin(a*12+.08)*math.sin(s*math.pi)**.6);rr=r+fold*(1-s);row.append([rr*math.cos(a),y+.00045*math.sin(a*4)*math.sin(s*math.pi),rr*math.sin(a)]);uv.append([a*.113/.04,y/.04])
  rows.append(row);tex.append(uv)
 p=np.array(rows).reshape(-1,3);tt=np.array(tex).reshape(-1,2);r=np.linalg.norm(p[:,[0,2]],axis=1);maxr=float(r.max());blend=np.clip((p[:,1]-.044)/.021,0,1);factor=1+blend*(.125/maxr-1);p[:,0]*=factor;p[:,2]*=factor;verts=[tuple(q)for q in p];uvs=[tuple(q)for q in tt];faces=[]
 for j in range(len(rows)-1):
  for i in range(N):a=j*N+i;b=j*N+(i+1)%N;c=a+N;d=b+N;faces +=[(a,c,b),(b,c,d)]
 top=len(verts);verts.append((0,.20,0));uvs.append((0,.2/.04))
 for i in range(N):faces.append(((len(rows)-1)*N+i,top,(len(rows)-1)*N+(i+1)%N))
 crown=A.open_surface_shell('source-tall-straight-pleated-chef-crown','hat',verts,faces,list(range(N-1,-1,-1)),uvs,.0007)
 vv=[];uv=[];ff=[]
 for j in range(8):
  y=j/7*.046
  for i in range(N):a=i/N*math.tau;rr=.085+.0007*math.sin(a*6)*math.sin(j/7*math.pi);vv.append([rr*math.cos(a),y,rr*math.sin(a)]);uv.append([a*.085/.04,y/.04])
 for j in range(7):
  for i in range(N):a=j*N+i;b=j*N+(i+1)%N;c=a+N;d=b+N;ff +=[(a,c,b),(b,c,d)]
 band=A.open_surface_shell('open-real-head-band-with-own-vertical-paired-stripes','hat_band',vv,ff,[list(range(N-1,-1,-1)),list(range(7*N,8*N))],uv,.0012)
 # The official dimensions refer to the outer cloth, including finite thickness.
 pp=np.array(crown['_vertices']);lo,hi=pp.min(0),pp.max(0);pp[:,1]=(pp[:,1]-lo[1])*.20/(hi[1]-lo[1]);rr=np.linalg.norm(pp[:,[0,2]],axis=1);mask=pp[:,1]>.055;scale=.125/rr[mask].max();pp[mask,0]*=scale;pp[mask,2]*=scale;crown['_vertices']=[tuple(q)for q in pp]
 C.dump(D/'official-tall-hollow-hat-dimension-proof.json',dict(official_height_m=.20,actual_crown_height_m=float(np.ptp(pp[:,1])),official_diameter_m=.25,actual_max_outer_diameter_m=float(np.linalg.norm(pp[:,[0,2]],axis=1).max()*2),straight_pleated_wall_height_m=.123,shallow_top_rounding_not_balloon=True,real_open_head_cavity=True,pleat_depth_photo_interpreted_m=.010))
 return[crown,band]
M.hat=hat
OLD_MATERIAL=M.material
def material(sku,out):
 mats=OLD_MATERIAL(sku,out);master=A.L.EVIDENCE[sku]['original']['path'];im=Image.open(master).convert('RGB').crop([280,335,400,490]);im.save(out/'own-native-chef-crown-paired-stripes-crop.png');p=np.asarray(im,float);profile=np.median(p[:,60:80],axis=1)[42:69];ratio=(profile[:,0]+1)/(profile[:,1]+1);mask=np.clip((2.2-ratio)/.8,0,1);red=np.median(p[(p[:,:,0]+1)/(p[:,:,1]+1)>2.4],axis=0);cream=np.median(p[(p[:,:,0]+1)/(p[:,:,1]+1)<1.5],axis=0);rgb=red[None,:]*(1-mask[:,None])+cream[None,:]*mask[:,None];profile=np.uint8(np.clip(rgb,0,255));horizontal=np.repeat(np.tile(profile,(72,1))[:,None,:],1024,axis=1);vertical=np.transpose(horizontal,(1,0,2));Image.fromarray(horizontal).save(out/'own-native-horizontal-paired-stripes.png',optimize=True);Image.fromarray(vertical).save(out/'own-native-vertical-paired-stripes.png',optimize=True)
 for key in['hat','hat_band','neck_strap']:
  mats[key]=copy.deepcopy(mats['cloth']);mats[key]['baseColorTexture']='own-native-vertical-paired-stripes.png'if key=='hat_band'else'own-native-horizontal-paired-stripes.png';mats[key]['baseColorFactor']=[1,1,1,1];mats[key]['extras'].update(own_native_paired_stripe_profile_rows=[42,69],source_crop=[280,335,400,490],physical_colour_repeat_m=1.152,paired_stripe_pitch_photo_interpreted_m=.016)
 C.dump(out/'own-paired-stripe-profile-provenance.json',dict(original_master=master,native_crop=[280,335,400,490],profile_rows=[42,69],native_group_pixels=27,native_profile_repeated_without_upscale=True,own_red=red.tolist(),own_cream=cream.tolist(),studio_luminance_and_folds_discarded=True,interpreted_pattern_pitch_m=.016,paired_lines_not_generic_single_bands=True,crown_and_strap_cross_stripes=True,head_band_vertical_stripes=True));return mats
M.material=material
BASE_FINISH=Q.FINISH
def finish(raw,meta,fn,features=None):
 meta['quality_label']='Geniş çapraz çizgili boyun askısı · Uzun pileli şapka';meta['estimated_fields']+=['neck_strap_width_4cm_photo_estimate','own_paired_stripe_pitch_from_photo','bib_width_and_hat_local_pleat_pattern'];e=BASE_FINISH(raw,meta,fn,features);doc,binary=C.read_glb(e['glb_path'])
 for mat in doc['materials']:
  if mat['name']in['hat','hat_band','neck_strap']:
   factor=.04/1.152;mat['pbrMetallicRoughness']['baseColorTexture'].setdefault('extensions',{})['KHR_texture_transform']=dict(scale=[factor,1]if mat['name']=='hat_band'else[1,factor])
 doc['extensionsUsed']=sorted(set(doc['extensionsUsed'])|{'KHR_texture_transform'});C.write_glb(e['glb_path'],doc,binary);e['sha256']=C.sha(e['glb_path']);e['bytes']=Path(e['glb_path']).stat().st_size;out=Path(e['asset_dir']);C.dump(out/'entry.json',e);rp=out/(meta['id']+'.validation.json');q=json.loads(rp.read_text());q['deliverable_sha256']['glb']=e['sha256'];q['glb_bytes']=e['bytes'];C.dump(rp,q);return e
A.finish=finish
source=Q.src.replace("'-own-tailored-soft-ruffle-hat-r2-'","'-wide-cross-striped-strap-tall-pleated-crown-r3-'").replace("raw.append(M.flat_strap('real-flat-open-neck-loop',path,.020 if kind=='chef_set'else .017))","raw.append(wide_neck_strap(path) if kind=='chef_set'else M.flat_strap('real-flat-open-neck-loop',path,.017))")
assert source!=Q.src;exec(compile(source,str(__file__)+':own-chef-source-form','exec'),M.__dict__)
if __name__=='__main__':
 M.build('1352449001');rows=json.loads((D/'candidate-remaining-tailored-aprons-manifest.json').read_text());checks=[V.check(e)for e in rows];target=D/'frozen-wide-cross-striped-strap-tall-chef-crown-01-manifest.json';assert not target.exists();C.dump(D/'independent-own-chef-shape-pattern-validation.json',dict(valid=True,models=1,actual_browser_review_required=True,checks=checks));C.dump(target,rows);print(target,C.sha(target),flush=True)
