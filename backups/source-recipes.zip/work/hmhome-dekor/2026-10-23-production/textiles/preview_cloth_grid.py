from pathlib import Path
import sys,numpy as np
from PIL import Image,ImageDraw
D=Path(sys.argv[1]);g=np.load(D/'actual-square-relaxed-cloth.npz')['grid'];n=g.shape[0]-1;tri=[]
for j in range(n):
 for i in range(n):tri +=[np.array([g[j,i],g[j+1,i],g[j,i+1]]),np.array([g[j+1,i],g[j+1,i+1],g[j,i+1]])]
tri=np.array(tri);cam=np.array([.3,.1,1]);cam/=np.linalg.norm(cam);right=np.cross([0,1,0],cam);right/=np.linalg.norm(right);up=np.cross(cam,right);p=np.stack([tri@right,tri@up,tri@cam],2);lo=p[:,:,:2].min((0,1));hi=p[:,:,:2].max((0,1));sc=600/(hi-lo).max();centre=(lo+hi)/2;norm=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]);norm/=np.linalg.norm(norm,axis=1,keepdims=True);light=np.array([-.5,.6,1]);light/=np.linalg.norm(light);lum=.4+.6*abs(norm@light);im=Image.new('RGB',(650,700),'#f7f7f5');draw=ImageDraw.Draw(im)
for k in np.argsort(p[:,:,2].mean(1)):
 xy=(p[k,:,:2]-centre)*sc;xy[:,0]+=325;xy[:,1]=350-xy[:,1];draw.polygon([tuple(q)for q in xy],fill=tuple(np.uint8(np.array([225,210,190])*lum[k])))
im.save(D/'actual-square-cloth-geometry-preview.jpg');print((g.max((0,1))-g.min((0,1))).tolist())
