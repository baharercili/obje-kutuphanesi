"""Own-reference palm broderie, real cut holes with separate sewn eyelet rims.

The observed palm consists of a curved perforated trunk and four eyelet fronds.
The unshown whole-cloth repeat, hole size and stitch thickness are qualified.
"""
from pathlib import Path
import sys,json,math
import numpy as np
sys.dont_write_bytecode=True
T=Path(__file__).resolve().parent;sys.path.insert(0,str(T));sys.path.insert(0,str(T.parent/'decor-storage/python-deps'))
import mapbox_earcut as E
import build_soft_linen_revision as B
import build_real_hemstitch as H
A,C=B.A,B.C;D=T/'real-palm-cutwork-prototype01';D.mkdir(exist_ok=True);A.R=D
def palm(scale=1):
 out=[]
 # Native-photo-guided curved trunk and paired arcing eyelet fronds.
 for t in np.linspace(.03,.97,12):out.append((scale*(.008*math.sin(t*math.pi)),scale*(.12*t),.00245*scale))
 for sign in[-1,1]:
  for upper in[True,False]:
   for t in np.linspace(.12,.96,8):
    x=sign*.065*t;y=.12+(.035 if upper else-.046)*math.sin(t*math.pi*.63)
    out.append((scale*x,scale*y,.00245*scale))
 return out
def holes(w,l):
 out=[];count=0
 for side in['near','far','left','right']:
  length=w if side in['near','far']else l
  for k,at in enumerate(np.arange(.19,length-.10,.29)):
   scale=1 if k%2==0 else.62;count+=1
   for x,y,r in palm(scale):
    if side=='near':u,v=at+x,.045+y
    elif side=='far':u,v=at-x,l-.045-y
    elif side=='left':u,v=.045+y,at-x
    else:u,v=w-.045-y,at+x
    out.append((u,v,r))
 return out,count
def build(sku):
 ev=A.L.EVIDENCE[sku];size=ev['official_flat_size_cm'];w,l=np.array(size)/100
 cache=D/(sku+'-gravity.npz')
 if cache.exists():q=np.load(cache);grid,norm=q['grid'],q['normals'];proof=json.loads(cache.with_suffix('.json').read_text())
 else:grid,norm,proof=B.S.table_gravity(w,l,int(sku)%1000003);np.savez_compressed(cache,grid=grid,normals=norm);C.dump(cache.with_suffix('.json'),proof)
 nx=round(w/.008);ny=round(l/.008);cellw=w/nx;cellh=l/ny;source_holes,palms=holes(w,l);cells={}
 for x,y,r in source_holes:
  i=min(nx-2,max(1,int(x/cellw)));j=min(ny-2,max(1,int(y/cellh)))
  cells.setdefault((i,j),min(r,.30*cellw,.30*cellh))
 vertices=[];uv=[];faces=[];lookup={};loops=[]
 def vertex(x,y):
  key=(round(x,10),round(y,10))
  if key not in lookup:
   lookup[key]=len(vertices);p,n=C.sample(grid,norm,x/w,y/l);vertices.append(p);uv.append([x/.04,y/.04])
  return lookup[key]
 for j in range(ny):
  for i in range(nx):
   x0=i*cellw;x1=(i+1)*cellw;y0=j*cellh;y1=(j+1)*cellh
   planar=[(x0,y0),(x1,y0),(x1,y1),(x0,y1)];r=cells.get((i,j));rings=[4]
   if r:
    cx=(x0+x1)*.5;cy=(y0+y1)*.5;ring=[(cx+r*math.cos(a),cy+r*math.sin(a))for a in np.linspace(0,math.tau,20,endpoint=False)];planar+=ring;rings.append(24)
   ids=[vertex(x,y)for x,y in planar]
   if r:
    triangles=E.triangulate_float64(np.array(planar,dtype=np.float64),np.array(rings,dtype=np.uint32)).reshape(-1,3);faces +=[tuple(ids[t]for t in tri)for tri in triangles];loops.append([ids[t]for t in range(4,24)])
   else:faces.extend([(ids[0],ids[1],ids[2]),(ids[0],ids[2],ids[3])])
 outer=[vertex(x,0)for x in np.linspace(0,w,nx+1)]+[vertex(w,y)for y in np.linspace(0,l,ny+1)[1:]]+[vertex(x,l)for x in np.linspace(w,0,nx+1)[1:]]+[vertex(0,y)for y in np.linspace(l,0,ny+1)[1:-1]]
 # Normalize planar winding before creating front/back thickness and hole rims.
 verts=np.array(vertices);f=np.array(faces);sign=np.median(np.einsum('ij,ij->i',np.cross(verts[f[:,1]]-verts[f[:,0]],verts[f[:,2]]-verts[f[:,0]]),np.array([C.sample(grid,norm,uv[a][0]*.04/w,uv[a][1]*.04/l)[1]for a in f[:,0]])))
 if sign<0:faces=[(a,c,b)for a,b,c in faces];outer=outer[::-1]
 else:loops=[loop[::-1]for loop in loops]
 raw=[A.open_surface_shell('continuous-cloth-with-actual-palm-eyelet-cutouts','cloth',vertices,faces,[outer]+loops,uv,.00048)];rims=[]
 for k,loop in enumerate(loops):
  path=[]
  for i in loop:
   u,v=np.array(uv[i])*.04/np.array([w,l]);p,n=C.sample(grid,norm,u,v);path.append(p+n*.00035)
  rims.append(A.closed_tube('one-actual-sewn-eyelet-rim','thread',path,.00058,sides=6))
 raw.append(H.merge_solids(rims,'individual-white-sewn-palm-eyelet-rims','thread'))
 aid='hm-'+sku+'-gravity-real-palm-broderie-eyelet-cutwork';note=f'Resmî düz ürün{size[0]}×{size[1]}cm. Kendi fotoğrafındaki palmiye ajuru eğri gövde ve dört delikli yaprakla yorumlandı; her göz gerçek kumaş açıklığıdır, altında opak tabaka yoktur. Görünmeyen bütün masa örtüsü tekrar aralığı, boyutları değişen palmiye yerleşimi, delik/kenar ipliği çapı ve kıvrım pozu fotoğraf yorumudur; üretici nakış CAD’i değildir.'
 meta=A.base_metadata(sku,aid,dict(flat_item_size_cm=size,set_quantity=1),note,'cotton',1);meta.update(source_dimensions_hwd_cm=[None,*size],quality_status='photo_interpretation',quality_label='Gerçek palmiye ajuru · Kabarık göz kenarları',palm_cutwork_features=dict(actual_holes=len(loops),photo_interpreted_palms=palms,opaque_underlay_absent=True,full_repeat_layout_manufacturer_verified=False,flat_pose_metric=proof))
 e=A.finish(raw,meta,lambda out:B.material(sku,dict(recipe='cotton',rgb=[240,240,232],intrinsic_ao=True,weave_period_m=.00028),out),features=meta['palm_cutwork_features']);C.dump(D/'candidate-palm-cutwork-manifest.json',[e]);C.dump(D/(sku+'-actual-cutout-proof.json'),dict(actual_holes=len(loops),triangulation='Constrained local polygon rings; real holes, finite material thickness',hole_rim_material_solids=len(rims),source_photo=A.L.EVIDENCE[sku]['original'],raw_hole_candidate_count=len(source_holes),quantized_unique_cutouts=len(cells),max_interpreted_hole_centre_shift_m=math.hypot(cellw,cellh)/2));print('REAL PALM CUTWORK',sku,len(loops),flush=True)
if __name__=='__main__':
 for sku in sys.argv[1:]:build(sku)
