"""All remaining source-specific aprons and the true two-piece chef set.

Uses the reviewed soft tailoring, with own pockets, gather/ruffle construction,
native pastry motif, flat ties, and a genuinely hollow pleated chef hat.
"""
from pathlib import Path
import sys,json,copy,math
import numpy as np
from PIL import Image
sys.dont_write_bytecode=True
T=Path(__file__).resolve().parent;sys.path.insert(0,str(T))
import build_soft_linen_apron_prototype as M
A,C,B=M.A,M.C,M.B
D=T/'remaining-tailored-aprons-batch01';D.mkdir(exist_ok=True);A.R=D
CFG={
 '1350240002':dict(w=.57,body=.72,neck=.18,kind='gathered',rgb=[130,12,32],official=[57,90],pockets=0),
 '1351035001':dict(w=.80,body=.72,neck=.18,kind='pastry',rgb=[154,41,60],official=[80,90],pockets=2),
 '1353203001':dict(w=.42,body=.60,neck=.08,kind='child_ruffle',rgb=[114,9,30],pockets=0),
 '1352449001':dict(w=.55,body=.42,neck=.14,kind='chef_set',rgb=[136,12,30],official=[55,56],pockets=1),
}
CURRENT={}
def point(u,v):
 c=CURRENT;w,body=c['w'],c['body'];kind=c['kind'];y=(1-v)*body
 if kind=='child_ruffle':waist=.35/body;width=np.interp(v,[0,1-waist,.52,1],[.18,.23,w*.93,w])
 elif kind=='gathered':width=np.interp(v,[0,.31,.32,1],[w*.38,w*.44,w,w])
 elif kind=='chef_set':width=np.interp(v,[0,.49,.51,1],[w*.72,w*.72,w,w])
 else:width=np.interp(v,[0,.16,.32,.42,1],[w*.29,w*.34,w*.49,w*.99,w])
 x=(u-.5)*width;z=.009*np.sin(u*math.tau*3.1+.25*np.sin(v*5))*(.22+.78*v)+.004*np.sin(v*11+u*3)+.024*v*v+.008*np.sin(math.pi*u)**2*np.sin(math.pi*v)
 if kind in['child_ruffle','gathered']:
  waist_v=1-.35/body if kind=='child_ruffle'else .32
  lower=np.clip((v-waist_v)/.12,0,1);z+=.012*lower*np.sin(u*math.tau*8+.15*np.sin(u*9)+v*.6);y+=.003*lower*np.sin(u*math.tau*5.3+.7)
 return np.array([x,y,z])
M.point=point
def material(sku,out):
 c=CFG[sku];rgb=c['rgb'];kind=c['kind'];m=B.material(sku,dict(recipe='cotton',rgb=rgb,intrinsic_ao=True,weave_period_m=.00028),out)
 N=800;W,H=c['w'],c['body'];X=np.arange(N)[None,:]/N*W;Y=np.arange(1000)[:,None]/1000*H;pixels=np.broadcast_to(np.array(rgb)[None,None,:],(1000,N,3)).copy().astype(float)
 if kind in['gathered','chef_set']:
  repeat=.006 if kind=='gathered'else .007;mask=np.broadcast_to((X%repeat)<repeat*.40,(1000,N));pixels[mask]=[232,222,202]
 elif kind=='pastry':
  # Original fine side bands, plus this exact SKU's genuine pastry lettering.
  stripe=((X>.019)&(X<.022))|((X>.028)&(X<.031))|((X>W-.031)&(X<W-.028))|((X>W-.022)&(X<W-.019));pixels[np.broadcast_to(stripe,(1000,N))]=[224,204,174]
  ev=A.L.EVIDENCE[sku];box=[315,1190,550,1480];im=Image.open(ev['original']['path']).convert('RGB').crop(box);p=np.asarray(im,float);mask=np.clip((2.15-(p[:,:,0]+1)/(p[:,:,1]+1))/.85,0,1)
  target=(160,190);maskim=Image.fromarray(np.uint8(mask*255)).resize(target,Image.Resampling.LANCZOS);mm=np.asarray(maskim,float)/255;x,y=103,465;patch=pixels[y:y+target[1],x:x+target[0]];patch[:]=patch*(1-mm[:,:,None])+np.array([224,204,174])*mm[:,:,None]
  im.save(out/'native-own-patisserie-motif-crop.png');C.dump(out/'native-pastry-motif-provenance.json',dict(source=ev['original'],native_crop=box,native_crop_pixels=list(im.size),output_motif_pixels=list(target),resampling='One downsample; no upscale',source_luminance_removed=True,motif='Original own-SKU cake and Patisserie lettering'))
 if kind!='child_ruffle':
  Image.fromarray(np.uint8(pixels)).save(out/'whole-tailored-body-pigment.png',optimize=True);m['cloth']['baseColorTexture']='whole-tailored-body-pigment.png'
 m['hat']=copy.deepcopy(m['cloth']);m['hem']['baseColorTexture']=None;m['hem']['baseColorFactor']=[x/255 for x in rgb]+[1]
 return m
def hat():
 N=112;NV=60;v=[];uv=[];f=[]
 for j in range(NV):
  t=j/NV;y=.20*t;radius=.085*(1-t)+.125*math.sin(math.pi*t)**.75
  for i in range(N):
   a=i/N*math.tau;r=radius*(1+.035*math.sin(a*14+.2*math.sin(a*3))*math.sin(math.pi*t));v.append([r*math.cos(a),y,r*math.sin(a)]);uv.append([a*.10/.04,y/.04])
 maxr=max(math.hypot(p[0],p[2])for p in v)
 for p in v:p[0]*=.125/maxr;p[2]*=.125/maxr
 for j in range(NV-1):
  for i in range(N):a=j*N+i;b=j*N+(i+1)%N;cc=a+N;d=b+N;f.extend([(a,cc,b),(b,cc,d)])
 top=len(v);v.append([.002,.20,.001]);uv.append([0,5])
 for i in range(N):f.append(((NV-1)*N+i,top,(NV-1)*N+(i+1)%N))
 crown=A.open_surface_shell('hollow-pleated-chef-hat-crown','hat',v,f,list(range(N-1,-1,-1)),uv,.0007)
 vv=[];tt=[];ff=[]
 for j in range(7):
  y=j/6*.046
  for i in range(N):a=i/N*math.tau;vv.append([.087*math.cos(a),y,.087*math.sin(a)]);tt.append([a*.087/.04,y/.04])
 for j in range(6):
  for i in range(N):a=j*N+i;b=j*N+(i+1)%N;cc=a+N;d=b+N;ff.extend([(a,cc,b),(b,cc,d)])
 band=A.open_surface_shell('real-open-circumference-adjustable-chef-hat-band','hat',vv,ff,[list(range(N-1,-1,-1)),list(range(6*N,7*N))],tt,.0012)
 return[crown,band]
def build(sku):
 c=CFG[sku];CURRENT.clear();CURRENT.update(c);M.SKU=sku;M.W=c['w'];M.BODY=c['body'];kind=c['kind'];raw=[];groups=[];bounds=[]
 body,g=M.patch('soft-tailored-continuous-apron-body',0,1,0,1);raw.append(body)
 for label,path in [('left',g[:,0]),('right',g[:,-1]),('top',g[0]),('bottom',g[-1])]:raw.append(C.tube(label+'-soft-bound-apron-edge','hem',path,.0012,sides=8))
 pocket_domains=[(.11,.31,.46,.72),(.67,.88,.46,.72)]if c['pockets']==2 else[(.12,.88,.54,.91)]if c['pockets']==1 else[]
 for k,(u0,u1,v0,v1)in enumerate(pocket_domains):
  pocket,pg=M.patch('open-pocket-'+str(k+1),u0,u1,v0,v1,.0005,True);raw.append(pocket)
  for name,path in [('left',pg[:,0]),('right',pg[:,-1]),('bottom',pg[-1]),('open-top',pg[0])]:raw.append(C.tube('pocket-'+str(k+1)+'-'+name+'-sewn-binding','hem',path,.00055,sides=6))
 if kind=='child_ruffle':
  for sign in[-1,1]:
   path=[np.array([sign*.083,.60+.08*t,.001+.003*math.sin(t*math.pi)])for t in np.linspace(0,1,50)]
   raw.append(M.flat_strap('front-shoulder-strap-'+str(sign),path,.032))
   # True ruffled outer shoulder cloth, with varying finite-depth gathers.
   rg=[];rn=[];ru=[]
   for i,p in enumerate(path):
    t=i/(len(path)-1);row=[]
    for a in np.linspace(0,1,12):row.append(p+np.array([sign*(.016+a*.036),-.004*a*math.sin(t*9*math.pi),a*.009*math.sin(t*9*math.pi)]))
    rg.append(row);rn.append([[0,0,1.]]*12);ru.append([[a*.036/.04,t*.08/.04]for a in np.linspace(0,1,12)])
   raw.append(C.shell('gathered-ruffled-shoulder-'+str(sign),'cloth',np.array(rg),np.array(rn),.0006,np.array(ru)))
   back=[np.array([sign*(.083-.21*t),.68-.33*t,-.035*math.sin(math.pi*t)-.01])for t in np.linspace(0,1,90)];raw.append(M.flat_strap('crossed-back-strap-'+str(sign),back,.027))
 else:
  topw=(point(1,0)-point(0,0))[0];path=[]
  for t in np.linspace(0,1,100):path.append([-topw/2+topw*t,c['body']+c['neck']*math.sin(math.pi*t)**.15,.003+.005*math.sin(t*math.tau)])
  raw.append(M.flat_strap('real-flat-open-neck-loop',path,.020 if kind=='chef_set'else .017))
 if kind in['gathered','child_ruffle','chef_set']:
  v=.32 if kind=='gathered'else 1-.35/c['body']if kind=='child_ruffle'else .51
  belt,_=M.patch('real-soft-waistband',0,1,max(0,v-.018),min(1,v+.018),.0013);raw.append(belt)
 for sign in[-1,1]:
  v=.32 if kind=='gathered'else 1-.35/c['body']if kind=='child_ruffle'else .42
  start=point(0 if sign<0 else 1,v);length=.34 if kind=='child_ruffle'else .46
  path=[start+np.array([sign*(.012+.032*math.sin(t*math.pi*.7)),-length*t,.012*math.sin(t*5+sign)])for t in np.linspace(0,1,90)]
  raw.append(M.flat_strap('separate-waist-tie-'+str(sign),path,.016))
 groups.append(list(range(len(raw))));pp=np.concatenate([q['_vertices']for q in raw]);bounds.append((pp.min(0),pp.max(0)))
 if kind=='chef_set':
  group=[]
  for q in hat():q['_vertices']=[tuple(np.array(p)+[.49,.16,0])for p in q['_vertices']];group.append(len(raw));raw.append(q)
  groups.append(group);pp=np.concatenate([raw[i]['_vertices']for i in group]);bounds.append((pp.min(0),pp.max(0)))
 official=dict(set_quantity=2 if kind=='chef_set'else 1)
 if c.get('official'):official['nominal_apron_width_height_cm']=c['official']
 if kind=='child_ruffle':official.update(upper_length_cm=33,lower_length_cm=35,total_length_cm=68)
 if kind=='chef_set':official['hat_nominal_height_diameter_cm']=[20,25]
 note='Exact SKU resmî ürün adı/rolü ve kendi JPEG’i esas alındı. '+('Önlük resmî nominal en/yükseklik '+str(c['official'])+'cm. 'if c.get('official')else'Resmî üst parça33cm+alt etek35cm=toplam68cm; genişlik yaklaşık42cm. ')
 note+='Resmî boy sınırının boyun askısı/bağ uçlarıyla ilişkisi doğrulanmadı; gövde/askı paylaştırması, görünmeyen terzi kalıbı, cep derinliği, iplik adımı, kırışıklık, renk ve kalınlık fotoğraf yorumudur. Kaplama stüdyo ışığı içermez.'
 if kind=='chef_set':note+=' Set ayrıca resmî20cm yükseklik/25cm çapta gerçekten içi açık, pileli kumaş aşçı şapkası içerir; kavis ve pile adımı yorumdur.'
 aid='hm-'+sku+'-own-tailored-'+kind+'-physical-cloth';meta=A.base_metadata(sku,aid,official,note,'cotton',official['set_quantity'])
 meta.update(source_dimensions_hwd_cm=[None,None,None],quality_status='photo_interpretation',quality_label='Özgün '+kind+' formu · Gerçek kumaş parçaları',apron_features=dict(open_pockets=c['pockets'],gathered_skirt=kind in['gathered','child_ruffle'],real_flat_ties=True,ruffled_crossed_shoulders=kind=='child_ruffle',real_hollow_chef_hat=kind=='chef_set'))
 if kind=='chef_set':meta['scene_variants']=[dict(index=0,label='2 parça aşçı seti'),dict(index=1,label='Önlük'),dict(index=2,label='İçi açık pileli şapka')]
 meta['source_evidence_files'].append(str(T/'additional-exact-role-research.json'));e=A.finish(raw,meta,lambda out:material(sku,out),features=meta['apron_features']);doc,binary=C.read_glb(e['glb_path'])
 for mat in doc['materials']:
  if mat['name']=='cloth'and kind!='child_ruffle':mat['pbrMetallicRoughness']['baseColorTexture'].setdefault('extensions',{})['KHR_texture_transform']=dict(scale=[.04/c['w'],.04/c['body']])
 if kind=='chef_set':
  nodes={n['mesh']:i for i,n in enumerate(doc['nodes'])if'mesh'in n};pp=np.concatenate([q['_vertices']for q in raw]);alo,ahi=pp.min(0),pp.max(0)
  for k,group in enumerate(groups):
   leaves=[]
   for mi in group:leaves.append(len(doc['nodes']));doc['nodes'].append(copy.deepcopy(doc['nodes'][nodes[mi]]))
   lo,hi=bounds[k];tr=[float((alo[0]+ahi[0]-lo[0]-hi[0])/2),float(alo[1]-lo[1]),float((alo[2]+ahi[2]-lo[2]-hi[2])/2)];root=len(doc['nodes']);doc['nodes'].append(dict(name='single-set-role',children=leaves,translation=tr));doc['scenes'].append(dict(name='Apron'if k==0 else'Hat',nodes=[root]))
 doc['extensionsUsed']=sorted(set(doc['extensionsUsed'])|{'KHR_texture_transform'});C.write_glb(e['glb_path'],doc,binary);e['sha256']=C.sha(e['glb_path']);e['bytes']=Path(e['glb_path']).stat().st_size;out=Path(e['asset_dir']);C.dump(out/'entry.json',e);p=out/(aid+'.validation.json');r=json.loads(p.read_text());r['deliverable_sha256']['glb']=e['sha256'];r['glb_bytes']=e['bytes'];C.dump(p,r);p=D/'candidate-remaining-tailored-aprons-manifest.json';rows=json.loads(p.read_text())if p.exists()else[];C.dump(p,[x for x in rows if x['sku']!=sku]+[e]);print('TAILORED FAMILY',sku,flush=True)
if __name__=='__main__':
 for sku in(sys.argv[1:]if '--all'not in sys.argv else list(CFG)):build(sku)
