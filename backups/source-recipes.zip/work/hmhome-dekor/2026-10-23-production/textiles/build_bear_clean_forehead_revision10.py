"""R9 surface method with clean own forehead pigment; frozen R9 is preserved."""
from pathlib import Path
import sys,subprocess
sys.dont_write_bytecode=True
T=Path(__file__).resolve().parent;sys.path.insert(0,str(T))
import build_bear_coarse_knit_revision09 as Q
D=T/'bear-comforters-clean-own-knit-revision10';D.mkdir(exist_ok=True)
for name in ['actual-square-relaxed-cloth.npz','actual-square-relaxed-cloth-proof.json']:
 if not(D/name).exists():subprocess.run(['/usr/bin/ditto','--clone',str(Q.D/name),str(D/name)],check=True)
Q.D=D;Q.P.D=D;Q.M.D=D;Q.A.R=D
OLD_KNIT=Q.N.knit
def clean_knit(master,box,out,seed):return OLD_KNIT(master,[690,425,818,553],out,seed)
Q.N.knit=clean_knit
OLD_FINISH=Q.ORIGINAL_FINISH
def renamed(raw,meta,mf,features=None):
 meta['id']='hm-'+meta['sku']+'-clean-own-coarse-knit-soft-square-bear-comforter-r10';return OLD_FINISH(raw,meta,mf,features)
Q.ORIGINAL_FINISH=renamed
if __name__=='__main__':Q.M.build('1351309001')
