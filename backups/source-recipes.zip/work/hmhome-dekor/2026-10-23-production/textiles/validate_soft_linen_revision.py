"""Independent revision binary, physical scale and topology checks. Authored pose arc tolerance 1%; original official cut plan remains separately recorded."""
from pathlib import Path
import json,sys,struct,io,hashlib,importlib.util
sys.dont_write_bytecode=True
import numpy as np
from PIL import Image
R=Path(__file__).resolve().parent;sp=importlib.util.spec_from_file_location('independent_binary_topology',R.parent/'curtains/validate_families.py');V=importlib.util.module_from_spec(sp);sp.loader.exec_module(V)
def check(e):
 data=Path(e['glb_path']).read_bytes();assert len(data)==e['bytes']and hashlib.sha256(data).hexdigest()==e['sha256'];assert struct.unpack_from('<III',data)==(0x46546c67,2,len(data));n,t=struct.unpack_from('<II',data,12);assert t==0x4e4f534a;doc=json.loads(data[20:20+n]);bl,bt=struct.unpack_from('<II',data,20+n);assert bt==0x004e4942;binary=data[28+n:28+n+bl]
 def array(i):
  a=doc['accessors'][i];v=doc['bufferViews'][a['bufferView']];dt={5126:'<f4',5125:'<u4',5123:'<u2',5121:'u1'}[a['componentType']];c={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}[a['type']];item=np.dtype(dt).itemsize;return np.ndarray((a['count'],c),dtype=dt,buffer=binary,offset=v.get('byteOffset',0)+a.get('byteOffset',0),strides=(v.get('byteStride',c*item),item)).copy()
 model=json.loads(Path(e['model_path']).read_text());meta=model['metadata'];assert doc['extras']['metadata']==meta;bounds=[];proofs=[];w,l=[v/100 for v in e['official_measurements'].get('flat_cloth_size_cm',meta.get('interpreted_body_cut_size_cm'))]
 for mesh in doc['meshes']:
  for primitive in mesh['primitives']:
   attr=primitive['attributes'];p=array(attr['POSITION']);normal=array(attr['NORMAL']);uv=array(attr['TEXCOORD_0']);tangent=array(attr['TANGENT']);assert all(np.isfinite(a).all()for a in[p,normal,uv,tangent]);assert np.allclose(np.linalg.norm(normal,axis=1),1,atol=2e-4);assert np.allclose(np.linalg.norm(tangent[:,:3],axis=1),1,atol=2e-4);bounds.append((p.min(0),p.max(0)))
   if mesh['name'].endswith('-physical-cloth-body'):
    item=int(mesh['name'].split('-')[1])-1;proof=meta['cloth_arc_length_validation'][item];nu=proof['nu'];nv=proof['nv'];count=(nu+1)*(nv+1);assert len(p)>=2*count;mid=(p[:count].astype(float)+p[count:count*2].astype(float))*.5;grid=mid.reshape(nv+1,nu+1,3);row=np.linalg.norm(np.diff(grid,axis=1),axis=2).sum(1);col=np.linalg.norm(np.diff(grid,axis=0),axis=2).sum(0);re=float(abs(row-w).max());assert re<max(2e-5,w*.01)
    ce=float(abs(col-l).max())
    assert ce<max(2e-5,l*.01)
    proofs.append(dict(mesh=mesh['name'],flat_width_m=w,flat_length_m=l,row_arc_error_m=re,column_arc_error_m=ce,vertical_gravity_drift_interpreted=e['family']=='kitchen_towel_set'))
 assert len(proofs)==e['set_quantity'];minimum=np.min([a for a,b in bounds],axis=0);maximum=np.max([b for a,b in bounds],axis=0);assert np.allclose((maximum-minimum)*100,e['dimensions_cm'],atol=2e-4);assert abs(minimum[1])<1e-6 and abs(minimum[0]+maximum[0])<1e-6 and abs(minimum[2]+maximum[2])<1e-6;closures=[]
 for scene in doc['scenes']:
  seen=set();todo=list(scene['nodes'])
  while todo:
   node=todo.pop();assert node not in seen;seen.add(node);todo+=doc['nodes'][node].get('children',[])
  closures.append(seen)
 assert len(closures)==(2 if e['set_quantity']>1 else 1);assert len(closures)==1 or not closures[0]&closures[1];assert doc.get('scene',0)==0
 sizes=[]
 for image in doc['images']:
  assert'uri'not in image;v=doc['bufferViews'][image['bufferView']];offset=v.get('byteOffset',0)
  with Image.open(io.BytesIO(binary[offset:offset+v['byteLength']]))as im:im.load();assert im.size==(2048,2048);sizes.append(list(im.size))
 assert'KHR_materials_sheen'in doc['extensionsUsed'];assert not meta['photo_pixels_baked']and not meta['baked_reflections'];assert all(hashlib.sha256(Path(im['path']).read_bytes()).hexdigest()==im['sha256']for im in e['original_images']);topology=V.AUDIT.check(e)
 return dict(id=e['id'],sku=e['sku'],valid=True,sha256=e['sha256'],bytes=e['bytes'],bounds_cm=[float(v)for v in(maximum-minimum)*100],physical_piece_count=len(proofs),set_quantity=e['set_quantity'],independent_cloth_arc_checks=proofs,scene_node_closures_disjoint=True,native_material_image_sizes=sizes,original_jpeg_bytes_unchanged=True,topology=topology)
if __name__=='__main__':
 path=Path(sys.argv[1]);entries=json.loads(path.read_text());checks=[]
 for e in entries:checks.append(check(e));print('AUDITED LINEN',e['sku'],flush=True)
 out=path.with_name(path.stem+'-independent-validation.json');out.write_text(json.dumps(dict(valid=True,models=len(checks),checks=checks,canonical_changed=False),ensure_ascii=False,indent=2)+'\n');print('VALIDATION',out,hashlib.sha256(out.read_bytes()).hexdigest())
