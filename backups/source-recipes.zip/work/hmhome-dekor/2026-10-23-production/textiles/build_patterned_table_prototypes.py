"""Three source-specific geometric textile patterns on the reviewed gravity form.

Pattern pigment colours and repeat sizes are photo interpretations. They are
not manufacturer print files, and studio shading is never an albedo source.
"""
from pathlib import Path
import sys,json,copy,math
import numpy as np
from PIL import Image
sys.dont_write_bytecode=True
T=Path(__file__).resolve().parent;sys.path.insert(0,str(T));import build_soft_linen_revision as B
C=B.C;D=T/'patterned-table-prototypes01';D.mkdir(exist_ok=True);B.D=D;B.A.R=D
CONFIG={
 '1335196002':dict(recipe='linen_blend',rgb=[235,232,221],pattern='alternate_window_grid',period_m=.13,dark=[112,91,76],faint=[217,205,181],line_m=.0013),
 '1335196011':dict(recipe='linen_blend',rgb=[239,235,224],pattern='fine_vertical_stripes',period_m=.0375,dark=[135,34,48],line_m=.0016),
 '1314774010':dict(recipe='linen_blend',rgb=[239,234,220],pattern='large_three_tone_gingham',cell_m=.125,half=[222,177,156],dark=[194,108,77]),
}
ORIGINAL_MATERIAL=B.material;ORIGINAL_RIBBON=C.ribbon;CURRENT={}
def ribbon(*args,**kwargs):
    raw=ORIGINAL_RIBBON(*args,**kwargs)
    # Hems share the cloth's manufactured reference domain. The old hanging
    # helper used posed X/Y span for ribbon UVs, unsuitable on a horizontal table.
    if args[0].endswith('-turned-hem'):
        u0,u1,v0,v1=args[4:8];nu=kwargs.get('steps_u',96);nv=kwargs.get('steps_v',5);uv=[(float(u*CURRENT['w']/.04),float(v*CURRENT['l']/.04))for v in np.linspace(v0,v1,nv+1)for u in np.linspace(u0,u1,nu+1)];assert len(raw['_uvs'])==len(uv)*2;raw['_uvs']=uv+uv
    return raw
C.ribbon=ribbon
def smooth_line(value,period,width,pixel):
    distance=np.abs((value+period*.5)%period-period*.5)
    return np.clip((width*.5+pixel*.5-distance)/pixel,0,1)
def material(sku,f,out):
    mats=ORIGINAL_MATERIAL(sku,f,out);cfg=CONFIG[sku];w,l=CURRENT['w'],CURRENT['l'];N=2048;rng=np.random.default_rng(int(sku));X=np.arange(N)[None,:]/N*w;Y=np.arange(N)[:,None]/N*l;rgb=np.broadcast_to(np.array(cfg['rgb'])[None,None,:],(N,N,3)).copy().astype(float)
    if cfg['pattern']=='fine_vertical_stripes':
        coverage=np.broadcast_to(smooth_line(X,cfg['period_m'],cfg['line_m'],w/N),(N,N));rgb=rgb*(1-coverage[:,:,None])+np.array(cfg['dark'])*coverage[:,:,None]
    elif cfg['pattern']=='alternate_window_grid':
        period=cfg['period_m'];faint=np.maximum(smooth_line(X+period*.5,period,.0012,w/N),smooth_line(Y+period*.5,period,.0012,l/N));rgb=rgb*(1-faint[:,:,None])+np.array(cfg['faint'])*faint[:,:,None];strong=np.maximum(smooth_line(X,period,cfg['line_m'],w/N),smooth_line(Y,period,cfg['line_m'],l/N));rgb=rgb*(1-strong[:,:,None])+np.array(cfg['dark'])*strong[:,:,None]
    else:
        a=(np.floor(X/cfg['cell_m']).astype(int)%2);b=(np.floor(Y/cfg['cell_m']).astype(int)%2);level=a+b;rgb=np.where((level==1)[:,:,None],np.array(cfg['half']),rgb);rgb=np.where((level==2)[:,:,None],np.array(cfg['dark']),rgb)
    rgb=np.clip(rgb+rng.normal(0,.55,(N,N,1)),0,255).astype(np.uint8);name=sku+'-whole-pattern-albedo.png';Image.fromarray(rgb,'RGB').save(out/name,optimize=True)
    for key in['cloth','hem']:mats[key]['baseColorTexture']=name;mats[key]['extras'].update(source_photo_guided_pattern=cfg['pattern'],repeat_photo_interpreted=True,whole_cloth_albedo_domain_m=[w,l])
    C.dump(out/'source-pattern-interpretation.json',dict(sku=sku,own_original=B.L.EVIDENCE[sku]['original'],source_picture_guided_pattern=cfg,pattern_repeat_officially_verified=False,source_studio_pixels_projected=False,normal_repeat_m=.04,whole_cloth_albedo_size=[N,N],hem_reference_uv_contiguous_with_body=True))
    return mats
B.material=material
def build(sku):
    cfg=CONFIG[sku];size=B.L.EVIDENCE[sku]['official_flat_size_cm'];CURRENT.update(w=size[0]/100,l=size[1]/100);B.L.OVERRIDES[sku]=dict(cfg,hem=.025);B.build(sku);manifest=D/'candidate-soft-linen-manifest.json';rows=json.loads(manifest.read_text());entry=next(e for e in rows if e['sku']==sku);out=Path(entry['asset_dir']);model=json.loads(Path(entry['model_path']).read_text());meta=model['metadata'];note=' Desenin renkleri ve tekrar aralığı yalnız kendi referans fotoğrafından yorumlandı; üretici baskı dosyası veya resmî desen adımı değildir. Düz kumaş resmi en-boyu ayrıca korunur.';meta['scale_note']+=note;meta['diameter_semantics']=meta['scale_note'];meta['quality_status']='photo_interpretation';meta['quality_label']='Kendi fotoğrafından desen yorumu';meta['estimated_fields']+=['pattern_repeat_scale_and_pigment_colours'];meta['pattern_interpretation']=cfg;meta['source_evidence_files'].append(str(out/'source-pattern-interpretation.json'));C.dump(Path(entry['model_path']),model);doc,binary=C.read_glb(entry['glb_path']);doc['extras']['metadata']=meta
    for mat in doc['materials']:
        if mat['name']in['cloth','hem']:mat['pbrMetallicRoughness']['baseColorTexture'].setdefault('extensions',{})['KHR_texture_transform']=dict(scale=[.04/CURRENT['w'],.04/CURRENT['l']])
    doc['extensionsUsed']=sorted(set(doc['extensionsUsed'])|{'KHR_texture_transform'});C.write_glb(entry['glb_path'],doc,binary)
    for key in['scale_note','diameter_semantics','quality_status','quality_label','estimated_fields','source_evidence_files']:entry[key]=meta[key]
    entry['sha256']=C.sha(entry['glb_path']);entry['bytes']=Path(entry['glb_path']).stat().st_size;C.dump(out/'entry.json',entry);reportpath=out/(entry['id']+'.validation.json');report=json.loads(reportpath.read_text());report['deliverable_sha256']['glb']=entry['sha256'];report['glb_bytes']=entry['bytes'];C.dump(reportpath,report);C.dump(manifest,[e for e in rows if e['sku']!=sku]+[entry]);print('PATTERNED TABLE REVIEW',sku,flush=True)
if __name__=='__main__':
    for sku in sys.argv[1:]:build(sku)
