"""Separate soft robe prototype with intact curved shoulders and a real local neck."""
from pathlib import Path
import sys,inspect,math,json,copy
import numpy as np
from PIL import Image
sys.dont_write_bytecode=True
T=Path(__file__).resolve().parent;sys.path.insert(0,str(T));import build_hooded_robe as M
D=T/'robes-soft-shoulders-revision02';D.mkdir(exist_ok=True);M.A.R=D;M.CONNECTED=D/'connected-real-neck-shoulder-sleeves.npz'
ORIGINAL_FINISH=M.A.finish
SKU='1237612002'
def fibre_material(sku,out):
 ev=M.A.L.EVIDENCE[sku];box=[700,1500,828,1628];im=Image.open(ev['original']['path']).convert('RGB').crop(box);p=np.asarray(im,float);fy=np.fft.fftfreq(128)[:,None];fx=np.fft.rfftfreq(128)[None,:];blur=np.exp(-2*math.pi**2*11**2*(fy*fy+fx*fx));low=np.stack([np.fft.irfft2(np.fft.rfft2(p[:,:,k])*blur,s=p.shape[:2])for k in range(3)],2);rgb=np.clip(p/np.maximum(low,1)*np.median(p.reshape(-1,3),axis=0),0,255);tile=np.tile(rgb,(16,16,1));height=(tile.mean(2)-tile.mean())*.000018
 N=2048;xx=np.arange(N)[None,:]/N*.128;yy=np.arange(N)[:,None]/N*.128;height+=.00025*np.cos(xx/.0016*math.tau)**8*np.cos(yy/.0019*math.tau)**6;dy,dx=np.gradient(height,.128/N);n=np.stack([-dx,-dy,np.ones_like(height)],2);n/=np.linalg.norm(n,axis=2,keepdims=True);orm=np.zeros((N,N,3),np.uint8);orm[:,:,0]=228;orm[:,:,1]=250
 for key,arr in [('albedo',np.uint8(tile)),('normal',np.uint8((n+1)*127.5)),('orm',orm)]:Image.fromarray(arr).save(out/(sku+'-'+key+'.png'),optimize=True)
 im.save(out/'own-native-fleece-crop.png');M.C.dump(out/'fleece-source-provenance.json',dict(source=ev['original'],crop=box,native_pixels=[128,128],source_lighting_removed=True,own_fibre_colour_grain_retained=True,physical_texture_repeat_interpreted_m=.128,native_tile_repeated_without_upscale=True))
 cloth=dict(baseColorFactor=[1,1,1,1],baseColorTexture=sku+'-albedo.png',normalTexture=sku+'-normal.png',metallicRoughnessTexture=sku+'-orm.png',normalScale=.9,metallic=1,roughness=1,doubleSided=False,alphaMode='OPAQUE');return dict(cloth=cloth,hem=copy.deepcopy(cloth))
def finish(raw,meta,old,features=None):
 import robe_soft_surface as S
 raw=S.soften(raw,M.A,M.C)
 raw.append(S.pile(raw,M.A,M.C,M.A.H,int(meta['sku'])))
 meta['id']='hm-'+meta['sku']+'-soft-hollow-shoulder-connected-robe-r2';meta['quality_label']='Yumuşak polar sabahlık · Fotoğraf ölçeği yaklaşık';meta['quality_status']='photo_interpretation';meta['robe_features']['shoulder_cloth_intact_local_neck_opening']=True
 e=ORIGINAL_FINISH(raw,meta,lambda out:fibre_material(meta['sku'],out),features=meta['robe_features']);doc,binary=M.C.read_glb(e['glb_path'])
 for mat in doc['materials']:
  for inf in [mat['pbrMetallicRoughness'].get('baseColorTexture'),mat.get('normalTexture'),mat.get('occlusionTexture'),mat['pbrMetallicRoughness'].get('metallicRoughnessTexture')]:
   if inf:inf.setdefault('extensions',{})['KHR_texture_transform']=dict(scale=[.04/.128]*2)
 doc['extensionsUsed']=sorted(set(doc['extensionsUsed'])|{'KHR_texture_transform'});M.C.write_glb(e['glb_path'],doc,binary);e['sha256']=M.C.sha(e['glb_path']);e['bytes']=Path(e['glb_path']).stat().st_size;out=Path(e['asset_dir']);M.C.dump(out/'entry.json',e);rp=out/(meta['id']+'.validation.json');r=json.loads(rp.read_text());r['deliverable_sha256']['glb']=e['sha256'];r['glb_bytes']=e['bytes'];M.C.dump(rp,r);M.C.dump(D/'candidate-soft-robes-manifest.json',[e]);return e
M.A.finish=finish
src=inspect.getsource(M.build).replace("R/'connected-coat-body-clean.npz'","CONNECTED").replace("-.080*neck",'').replace("-.025*neck",'').replace('height*v+.0012','height*v-.058*(abs(rx*math.sin(a))/.17)**1.6*v**8+.0012')
a=src.index(' collar=[]');b=src.index(' # An annular cloth hood',a);src=src[:a]+src[b:]
src=src.replace(".525",'.515').replace(".595+.075",'.590+.075').replace("+.10*billow",'+.065*billow').replace("sign*.071,.688",'sign*.071,.675').replace('N=72;hoodv=[]','N=144;hoodv=[]')
src=src.replace('.126+.091*t','.120+.100*t').replace('.445-.240*t','.460-.255*t').replace('.004+.014*t','.003+.015*t').replace('sign*.091,-.240,.014','sign*.100,-.255,.015')
exec(compile(src,str(__file__)+':soft-shoulder-and-proper-neck','exec'),M.__dict__)
if __name__=='__main__':M.build(SKU)
