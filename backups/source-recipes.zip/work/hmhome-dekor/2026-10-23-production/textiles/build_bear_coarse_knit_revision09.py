"""Keep accepted R8 base geometry, add own 3–4mm knit and real two-ply head stitches."""
from pathlib import Path
import sys,copy,json,math,subprocess,numpy as np
sys.dont_write_bytecode=True
T=Path(__file__).resolve().parent;sys.path.insert(0,str(T))
import build_bear_comforter_source_width08 as P
import native_surface_materials as N
M=P.M;A=M.A;C=M.C;H=A.H
OLD_D=P.D;D=T/'bear-comforters-own-coarse-knit-revision09';D.mkdir(exist_ok=True)
for name in ['actual-square-relaxed-cloth.npz','actual-square-relaxed-cloth-proof.json']:
 if not(D/name).exists():subprocess.run(['/usr/bin/ditto','--clone',str(OLD_D/name),str(D/name)],check=True)
P.D=D;M.D=D;A.R=D
ORIGINAL_FINISH=A.finish;OLD_MATERIAL=M.material

def material(sku,out):
 mats=OLD_MATERIAL(sku,out);master=A.L.EVIDENCE[sku]['original']['path'];maps=N.knit(master,[650,450,778,578],out,int(sku))
 plush=dict(baseColorFactor=[1,1,1,1],baseColorTexture=maps['albedo'],normalTexture=maps['normal'],metallicRoughnessTexture=maps['orm'],normalScale=1.,metallic=1,roughness=1,doubleSided=False,alphaMode='OPAQUE',extras=dict(own_native_knit_pigment=True,coarse_v_stitch_pitch_m=[.04/12,.04/11],albedo_repeat_m=.36,normal_repeat_m=.04))
 mats['plush']=plush;mats['yarn_ply']=copy.deepcopy(plush);mats['yarn_ply'].update(normalTexture=maps['micro'],metallicRoughnessTexture=maps['micro_orm'],normalScale=.8)
 mats['head_knit_bed']=copy.deepcopy(mats['yarn_ply']);return mats
M.material=material

def head_yarn(head):
 p=np.array(head['_vertices']);nu=64;nv=40;centre=np.array([0,.025,0]);assert len(p)==2+(nv-1)*nu
 def point(theta,phi):
  u=(theta/math.tau*nu)%nu;v=np.clip(phi/math.pi*nv,0,nv);i=int(u);j=int(v);a=u-i;b=v-j
  def at(jj,ii):return p[0]if jj<=0 else p[-1]if jj>=nv else p[1+(jj-1)*nu+ii%nu]
  return (1-b)*((1-a)*at(j,i)+a*at(j,i+1))+b*((1-a)*at(j+1,i)+a*at(j+1,i+1))
 def frame(theta,phi):
  q=point(theta,phi);dx=(point(theta+.001,phi)-point(theta-.001,phi))/.002;dy=(point(theta,phi+.001)-point(theta,phi-.001))/.002;n=np.cross(dx,dy);n/=np.linalg.norm(n)
  if np.dot(n,q-centre)<0:n=-n
  return q,n,dx/max(1e-10,np.linalg.norm(dx)),dy/max(1e-10,np.linalg.norm(dy)),float(np.linalg.norm(dy))
 pieces=[];rows=[];shape=[(-.31,-.43),(-.43,-.18),(-.36,.10),(-.18,.36),(0,.48),(.18,.36),(.36,.10),(.43,-.18),(.31,-.43)]
 phi=.18;row=0
 while phi<math.pi-.18:
  ring=np.array([point(t,phi)for t in np.linspace(0,math.tau,257)]);circ=np.linalg.norm(np.diff(ring,axis=0),axis=1).sum();cols=max(10,round(circ/.003333));theta_pitch=math.tau/cols;deriv=frame(0,phi)[4];phi_pitch=.003636/max(deriv,.008);count=0
  for col in range(cols):
   theta=(col+.08*math.sin(row*.71))*theta_pitch;q=point(theta,phi)
   # Keep existing visible embroidery free of covering yarn; no face replacement.
   if q[2]>.010 and ((abs(abs(q[0])-.017)<.0044 and abs(q[1]-.028)<.0048)or(abs(q[0])<.0075 and .010<q[1]<.034)):continue
   for ply in [-1,1]:
    path=[]
    for k,(sx,sy)in enumerate(shape):
     qq,nn,tt,bb,_=frame(theta+sx*theta_pitch,phi+sy*phi_pitch);twist=k/(len(shape)-1)*math.tau
     path.append(qq+nn*(.00062+ply*.00007*math.sin(twist))+tt*(ply*.000125*math.cos(twist)))
    tube=C.tube('one-own-scale-two-ply-knit-head-loop','yarn_ply',path,.00020,sides=6)
    arr=np.array(path);arcs=np.r_[0,np.cumsum(np.linalg.norm(np.diff(arr,axis=0),axis=1))]
    # Tube includes two cap-centre vertices after its rings.
    uv=[(j/6*math.tau*.00020/.04,float(arcs[k]/.04))for k in range(len(path))for j in range(6)]
    if len(tube['_vertices'])==len(uv)+2:uv.extend([(.00020/.04,0),(.00020/.04,float(arcs[-1]/.04))])
    assert len(uv)==len(tube['_vertices']);tube['_uvs']=uv;pieces.append(tube)
   count+=1
  rows.append(dict(phi=phi,columns=cols,visible_stitches=count));phi+=phi_pitch;row+=1
 vv=[];uv=[];ff=[]
 for t in pieces:
  off=len(vv);vv+=t['_vertices'];uv+=t['_uvs'];ff +=[tuple(i+off for i in f)for f in t['_faces']]
 return C.B.solid('own-3-to-4mm-real-two-ply-head-knit-stitches','yarn_ply',vv,ff,uv),dict(stitches=len(pieces)//2,plies_per_stitch=2,ply_radius_m=.00020,interpreted_pitch_m=[.003333,.003636],rows=rows,existing_eyes_nose_unchanged=True)

def finish(raw,meta,old,features=None):
 head=next(q for q in raw if q['name']=='soft-padded-bear-head');yarn,proof=head_yarn(head);head['material']='head_knit_bed';raw.append(yarn)
 meta['id']='hm-'+meta['sku']+'-own-coarse-knit-soft-square-bear-comforter-r9';meta['quality_label']='Hacimli iri örgü ilmekleri · Astarlı yumuşak örtü · Ölçek yaklaşık';meta['textile_recipe']='knit';meta['comforter_features'].update(own_native_knit_pigment=True,coarse_v_knit_pitch_photo_interpreted_m=[.003333,.003636],physical_two_ply_head_stitches=True,accepted_r8_base_geometry_unchanged=True);meta['estimated_fields']+=['coarse_3_to_4mm_knit_stitch_scale_from_own_head_photo']
 e=ORIGINAL_FINISH(raw,meta,lambda out:material(meta['sku'],out),features=meta['comforter_features']);doc,binary=C.read_glb(e['glb_path'])
 for mat in doc['materials']:
  if mat['name']in['plush','head_knit_bed','yarn_ply']:
   base=mat['pbrMetallicRoughness'].get('baseColorTexture')
   if base:base.setdefault('extensions',{})['KHR_texture_transform']=dict(scale=[.04/.36]*2)
   mat.setdefault('extensions',{})['KHR_materials_sheen']=dict(sheenColorFactor=[.25,.23,.20],sheenRoughnessFactor=1.)
 doc['extensionsUsed']=sorted(set(doc['extensionsUsed'])|{'KHR_texture_transform'});C.write_glb(e['glb_path'],doc,binary);e['sha256']=C.sha(e['glb_path']);e['bytes']=Path(e['glb_path']).stat().st_size;out=Path(e['asset_dir']);C.dump(out/'entry.json',e);C.dump(out/'physical-two-ply-knit-proof.json',proof)
 rp=out/(meta['id']+'.validation.json');r=json.loads(rp.read_text());r['deliverable_sha256']['glb']=e['sha256'];r['glb_bytes']=e['bytes'];C.dump(rp,r);return e
A.finish=finish
if __name__=='__main__':M.build('1351309001')
