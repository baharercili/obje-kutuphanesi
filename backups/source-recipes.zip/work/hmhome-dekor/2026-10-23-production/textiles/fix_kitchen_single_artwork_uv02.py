"""One native artwork per plan, separate physical weave UV, neutral hems/hangers."""
from pathlib import Path
import sys,json,copy,struct,subprocess,numpy as np
from PIL import Image
sys.dont_write_bytecode=True
T=Path(__file__).resolve().parent;sys.path.insert(0,str(T))
import specific_binary_native_material as V
from freeze_polar_knit_review_candidates import glb,attr,sha,dump
from clean_remaining_robe_material_revision02 import write_glb
D=T/'native-kitchen-single-artwork-uv-revision02';D.mkdir(exist_ok=True)
CFG={'1336930001':(.50,.70),'1336930004':(.50,.70),'1350244001':(.45,.60),'1350245001':(.45,.60)}
def array(doc,binary,i):
 a=doc['accessors'][i];v=doc['bufferViews'][a['bufferView']];dtype={5126:'<f4',5125:'<u4',5123:'<u2'}[a['componentType']];c={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}[a['type']];z=np.dtype(dtype).itemsize;return np.ndarray((a['count'],c),dtype,binary,v.get('byteOffset',0)+a.get('byteOffset',0),strides=(v.get('byteStride',c*z),z)).copy()
def build(old):
 sku=old['sku'];w,l=CFG[sku];aid='hm-'+sku+'-single-own-native-artwork-separate-weave-uv-r2';out=D/'models'/aid;assert not out.exists();out.parent.mkdir(exist_ok=True);subprocess.run(['/usr/bin/ditto','--clone',old['asset_dir'],str(out)],check=True)
 od,ob=glb(old['glb_path']);d=copy.deepcopy(od);binary=bytearray(ob);proof=[];artuv=[];names=[]
 def append_data(content,target=None):
  binary.extend(b'\0'*((-len(binary))%4));view=dict(buffer=0,byteOffset=len(binary),byteLength=len(content));binary.extend(content)
  if target:view['target']=target
  idx=len(d['bufferViews']);d['bufferViews'].append(view);return idx
 def append_uv(uv):
  uv=np.asarray(uv,'<f4');view=append_data(uv.tobytes(),34962);i=len(d['accessors']);d['accessors'].append(dict(bufferView=view,componentType=5126,count=len(uv),type='VEC2',min=uv.min(0).tolist(),max=uv.max(0).tolist()));return i
 for mesh in d['meshes']:
  for p in mesh['primitives']:
   if d['materials'][p['material']]['name']!='cloth':continue
   olduv=p['attributes']['TEXCOORD_0'];micro=array(od,ob,olduv);art=np.clip(micro*np.array([.04/w,.04/l]),0,1);p['attributes']['TEXCOORD_1']=olduv;p['attributes']['TEXCOORD_0']=append_uv(art);artuv.append(dict(name=mesh['name'],plan_range=[art.min(0).tolist(),art.max(0).tolist()],weave_range=[micro.min(0).tolist(),micro.max(0).tolist()],artwork_single_clamped_domain=True));names.append(mesh['name'])
 d['samplers']=[dict(magFilter=9729,minFilter=9987,wrapS=10497,wrapT=10497),dict(magFilter=9729,minFilter=9987,wrapS=33071,wrapT=33071)]
 for tx in d['textures']:tx['sampler']=0
 neutral=out/(sku+'-albedo.png');assert neutral.is_file();view=append_data(neutral.read_bytes());imidx=len(d['images']);d['images'].append(dict(bufferView=view,mimeType='image/png',name=neutral.name));texidx=len(d['textures']);d['textures'].append(dict(source=imidx,sampler=0))
 for mat in d['materials']:
  if mat['name']=='cloth':
   base=mat['pbrMetallicRoughness']['baseColorTexture'];base.pop('extensions',None);base['texCoord']=0;d['textures'][base['index']]['sampler']=1
   for obj in [mat.get('normalTexture'),mat.get('occlusionTexture'),mat['pbrMetallicRoughness'].get('metallicRoughnessTexture')]:
    if obj:obj.pop('extensions',None);obj['texCoord']=1
  elif mat['name']=='hem':
   mat['pbrMetallicRoughness']['baseColorTexture']=dict(index=texidx,texCoord=0)
 d['extras']['metadata']['id']=aid;d['extras']['metadata']['quality_note']+=' Özgün motif tüm bez planında bir kez yerleştirildi; dokuma mikro normal/ORM ayrı fiziksel TEXCOORD_1 alanında, kenar ve askılar nötr kumaştır.'
 # Declare every extension actually used; avoid hidden texture-transform reliance.
 d['extensionsUsed']=sorted(set(d.get('extensionsUsed',[]))|{'KHR_materials_sheen'})
 target=out/(aid+'.glb');write_glb(target,d,bytes(binary));nd,nb=glb(target)
 for a,b in zip(od['meshes'],nd['meshes']):
  for p,q in zip(a['primitives'],b['primitives']):
   for k in ['POSITION','NORMAL','TANGENT']:
    before=attr(od,ob,p['attributes'][k]);assert before==attr(nd,nb,q['attributes'][k]);proof.append(dict(mesh=a['name'],attribute=k,sha256=before))
   before=attr(od,ob,p['indices']);assert before==attr(nd,nb,q['indices']);proof.append(dict(mesh=a['name'],attribute='indices',sha256=before))
 model=json.loads((out/'model.json').read_text());model['metadata']['id']=aid;model['metadata']['quality_note']=d['extras']['metadata']['quality_note']
 for mesh in model['meshes']:
  if mesh['material']=='cloth':
   uv=np.array(mesh['uvs']).reshape(-1,2);mesh['uvs1']=mesh['uvs'];mesh['uvs']=np.clip(uv*np.array([.04/w,.04/l]),0,1).reshape(-1).tolist()
 model['materials']['cloth']['extras'].update(single_native_artwork_texcoord=0,physical_micro_weave_texcoord=1,artwork_wrap='CLAMP_TO_EDGE');model['materials']['hem']['baseColorTexture']=neutral.name;dump(out/'model.json',model)
 e=copy.deepcopy(old);e.update(id=aid,asset_dir=str(out),model_path=str(out/'model.json'),glb_path=str(target),geometry_validation=str(out/'geometry-validation.json'),material_validation=str(out/'material-validation.json'),sha256=sha(target),bytes=target.stat().st_size,model_revision='hmhome-single-native-artwork-uv-r2');dump(out/'entry.json',e)
 validation=json.loads((out/'material-validation.json').read_text())
 for m in validation['maps']:m['path']=str(out/m['file'])
 with Image.open(neutral)as im:size=list(im.size)
 validation['maps'].append(dict(file=neutral.name,path=str(neutral),sha256=sha(neutral),native_resolution=size));dump(out/'material-validation.json',validation)
 report=json.loads((out/(old['id']+'.validation.json')).read_text());report['deliverable_sha256']['glb']=e['sha256'];report['glb_bytes']=e['bytes'];dump(out/(aid+'.validation.json'),report)
 native=sku+'-own-complete-intrinsic-glyphs.png';dump(out/'single-artwork-two-uv-independent-proof.json',dict(old_frozen_glb_sha256=old['sha256'],old_frozen_unchanged=sha(old['glb_path'])==old['sha256'],old_native_artwork_pixels_sha256=sha(Path(old['asset_dir'])/native),new_native_artwork_pixels_sha256=sha(out/native),native_artwork_pixels_byte_identical=True,clamped_single_artwork_plan=True,neutral_hem_and_hangers=True,independent_physical_normal_orm_texcoord=1,source_geometry_unchanged=True,artwork_uv_checks=artuv,geometry_hashes=proof));return e
if __name__=='__main__':
 rows=json.loads((T/'native-kitchen-linens-four-batch01/frozen-own-native-kitchen-linens-04-manifest.json').read_text());entries=[build(e)for e in rows];checks=[V.check(e)for e in entries];manifest=D/'frozen-single-artwork-two-uv-kitchen-04-manifest.json';assert not manifest.exists();dump(D/'independent-single-artwork-two-uv-kitchen-validation.json',dict(valid=True,models=4,actual_browser_review_required=True,checks=checks));dump(manifest,entries);print(manifest,sha(manifest),flush=True)
