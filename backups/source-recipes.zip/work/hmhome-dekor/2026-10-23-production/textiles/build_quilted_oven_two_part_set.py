"""Exact oven set: hollow13.5x27mitt,21x21potholder with a real hand pocket.

Padding, quilt pitch, cuff, button, lace and hidden seam allowances are explicitly
photo-interpreted; the roles and nominal plan dimensions have exact TR evidence.
"""
from pathlib import Path
import sys,json,math,copy
import numpy as np
from PIL import Image
sys.dont_write_bytecode=True
T=Path(__file__).resolve().parent;sys.path.insert(0,str(T));import build_bear_bath_mitt as M
import build_hooded_robe as E
import build_real_hemstitch as H
import real_convex_cutwork as X
A,C,B=M.A,M.C,M.B;D=T/'quilted-oven-mitt-potholder-batch01';D.mkdir(exist_ok=True);A.R=D;SKU='1350249001'
M.H=.27;M.N=128;M.NV=120;M.TH=.0025

def radii(y):
 rx=.0675 if y<=.2025 else max(.003,math.sqrt(max(0,.0675**2-(y-.2025)**2)))
 return rx,.0145-.006*np.clip((y-.22)/.05,0,1)
M.radii=radii

def normal(g):
 n=np.cross(np.gradient(g,axis=0),np.gradient(g,axis=1));n/=np.linalg.norm(n,axis=2,keepdims=True);return n

def puff(x,y):
 a=abs(((x+y+.016)%.032)-.016);b=abs(((x-y+.016)%.032)-.016);return .0014*(1-math.exp(-(a/.003)**2))*(1-math.exp(-(b/.003)**2))

def flat_ring(name,centre,rx,ry,material='binding'):
 N=64;vv=[];uv=[];ff=[]
 for ring,z in[(True,-.0004),(True,.0004),(False,.0004),(False,-.0004)]:
  for i in range(N):
   a=math.tau*i/N;vv.append(np.array(centre)+[(rx if ring else rx-.003)*math.cos(a),z,(ry if ring else ry-.003)*math.sin(a)]);uv.append((i/N,0))
 for k in range(4):
  for i in range(N):a=k*N+i;b=k*N+(i+1)%N;c=((k+1)%4)*N+i;d=((k+1)%4)*N+(i+1)%N;ff +=[(a,b,c),(b,d,c)]
 return C.B.solid(name,material,vv,ff,uv)

def mitt():
 raw=[M.hollow_body()];raw[0]['name']='actual-13p5x27-hollow-quilted-oven-mitt';raw[0]['material']='stripe';count=(M.NV+1)*M.N
 vv=np.array(raw[0]['_vertices'])
 for i in range(count):
  x,y,z=vv[i]
  if y>.05:vv[i,2]+=math.copysign(puff(x,y)*min(1,abs(z)/.008),z)
 raw[0]['_vertices']=[tuple(v)for v in vv]
 # Cream folded cuff is an annulus, preserving the actual wrist aperture.
 v=[];uv=[];f=[];N=M.N
 for j,y in enumerate(np.linspace(0,.05,15)):
  rx,rz=radii(y)
  for i,a in enumerate(np.linspace(0,math.tau,N,endpoint=False)):v.append([(rx+.0008)*math.cos(a),y,(rz+.0008)*math.sin(a)]);uv.append([i/N*.29/.04,y/.04])
 for j in range(14):
  for i in range(N):a=j*N+i;b=j*N+(i+1)%N;c=a+N;d=b+N;f +=[(a,c,b),(b,c,d)]
 raw.append(A.open_surface_shell('cream-turned-cuff-real-open-wrist','cream',v,f,[list(range(N-1,-1,-1)),list(range(14*N,15*N))],uv,.0011));raw.append(E.ellipsoid('small-real-cuff-button','cream',(-.05,.026,.0164),(.004,.004,.0012),nu=24,nv=16))
 seam=[]
 for direction in[-1,1]:
  for at in np.arange(-.22,.28,.032):
   pts=[]
   for y in np.linspace(.052,.264,100):
    x=direction*y+at;rx,rz=radii(y)
    if abs(x)<rx*.975:
     p=M.front(x,y);p[2]+=puff(x,y)+.0005;pts.append(p)
    elif len(pts)>1:seam.append(C.tube('real-front-diagonal-quilt-stitch','quilt_thread',pts,.00018,sides=5));pts=[]
   if len(pts)>1:seam.append(C.tube('real-front-diagonal-quilt-stitch','quilt_thread',pts,.00018,sides=5))
 raw.append(H.merge_solids(seam,'actual-mitt-quilt-stitch-lines','quilt_thread'))
 for q in raw:q['_vertices']=[(x+.18,z+.018,.135-y)for x,y,z in q['_vertices']]
 raw.append(flat_ring('real-flat-red-mitt-hanger',(.24,.025,.149),.0055,.017))
 return raw

def holder_grid(pocket=False):
 N=80;g=[];uv=[]
 for v in np.linspace(0,1,N+1):
  rr=[];tt=[]
  for u in np.linspace(0,1,N+1):
   x=(u-.5)*(.19 if pocket else.21);z=(-.04+.14*v)if pocket else(v-.5)*.21
   if not pocket and abs(x)>.080 and abs(z)>.080:
    a=(abs(x)-.080)/.025;b=(abs(z)-.080)/.025;x=math.copysign(.080+.025*a*math.sqrt(1-b*b*.5),x);z=math.copysign(.080+.025*b*math.sqrt(1-a*a*.5),z)
   y=.002*math.sin(u*5+.6)*math.cos(v*6)+puff(x,z)+(.014 if pocket else 0)
   rr.append([x,y,z]);tt.append([x/.04,z/.04])
  g.append(rr);uv.append(tt)
 return np.array(g),np.array(uv)

def potholder():
 back,uv=holder_grid();n=normal(back);raw=[C.shell('real21x21-padded-quilted-potholder','cream',back,n,.006,uv)];pocket,puv=holder_grid(True);pn=normal(pocket);raw.append(C.shell('red-striped-front-pocket-with-real-hand-space','stripe',pocket,pn,.0013,puv))
 # Three sewn sides close the hand pocket, while the complete upper edge stays open.
 for label,path in [('left',pocket[:,0]),('right',pocket[:,-1]),('bottom',pocket[-1])]:
  strip=[]
  for p in path:
   strip.append([p,[p[0],.003+ .001*math.sin(p[0]*20+p[2]*10),p[2]]])
  strip=np.array(strip);raw.append(C.shell(label+'-closed-pocket-side-seam','binding',strip,normal(strip),.0010,np.array([[[0,0],[1,1]]for p in path])))
 raw.append(C.tube('open-pocket-entry-soft-red-lip','binding',pocket[0],.0016,sides=8));boundary=list(back[0])+list(back[1:,-1])+list(back[-1,-2::-1])+list(back[-2:0:-1,0]);raw.append(A.closed_tube('soft-red-bound-potholder-outline','binding',boundary,.0025,sides=8))
 holes=[(.011+k*.012,.0075,.0024)for k in range(15)];planar,faces,loops=X.planar(.19,.015,holes,.004);lv=[(x-.095,.0145,-.055+y)for x,y in planar];raw.append(A.open_surface_shell('real-white-lace-strip-fifteen-open-eyelets','cream',lv,faces,loops,planar/.04,.00045));rims=[]
 for x,y,r in holes:
  path=[(x-.095+r*math.sin(a),.0149,-.055+y+r*math.cos(a))for a in np.linspace(0,math.tau,24,endpoint=False)];rims.append(A.closed_tube('one-small-real-lace-eyelet-rim','cream',path,.00031,sides=5))
 raw.append(H.merge_solids(rims,'lace-open-eyelet-satin-edges','cream'));raw.append(flat_ring('real-flat-red-potholder-hanger',(-.071,.003,-.118),.007,.017))
 # A gentle diagonal laid-out presentation preserves the21x21manufactured plan.
 ca,sa=math.cos(.34),math.sin(.34)
 for q in raw:q['_vertices']=[(x*ca+z*sa-.055,y,-x*sa+z*ca)for x,y,z in q['_vertices']]
 return raw

def material(out):
 m=B.material(SKU,dict(recipe='cotton',rgb=[239,235,219],intrinsic_ao=True,weave_period_m=.00050),out);N=2048;x=np.arange(N)[None,:]/N*.04;y=np.arange(N)[:,None]/N*.04;phase=x%.006;stripe=(phase<.0036)&(phase>.00045);fine=(phase>.0045)&(phase<.00485);rgb=np.where((stripe|fine)[:,:,None],np.array([133,13,36]),np.array([239,235,219]));rgb=np.broadcast_to(rgb,(N,N,3)).copy();Image.fromarray(np.uint8(rgb)).save(out/'own-source-interpreted-yarn-dyed-stripes.png',optimize=True)
 m['stripe']=copy.deepcopy(m['cloth']);m['stripe']['baseColorTexture']='own-source-interpreted-yarn-dyed-stripes.png';m['cream']=copy.deepcopy(m['cloth']);m['binding']=copy.deepcopy(m['hem']);m['binding']['baseColorTexture']=None;m['binding']['baseColorFactor']=[133/255,13/255,36/255,1];m['quilt_thread']=dict(baseColorFactor=[.91,.86,.77,1],metallic=0,roughness=.92,doubleSided=False,alphaMode='OPAQUE');return m

def build():
 raw=[];groups=[];bounds=[]
 for items in [mitt(),potholder()]:
  groups.append(list(range(len(raw),len(raw)+len(items))));raw+=items;v=np.concatenate([q['_vertices']for q in items]);bounds.append((v.min(0),v.max(0)))
 aid='hm-'+SKU+'-two-real-quilted-oven-mitt-pocket-potholder';note='Resmî TR exactSKU2parça: fırın eldiveni nominal13.5×27cm, tutacak nominal21×21cm; pamuk%100. Açık bilekli gerçek eldiven iç boşluğu, katlı krem manşet/düğme, tutacakta üç kenarı dikili açık el cebi,15gerçek delikli dantel ve açık dokuma askılar vardır. Nominal düz rol ölçüleri, diyagonal yatık sahne kutusu ve yerel dolgu/kenar/askı payları farklıdır. Gizli başparmak/dikiş kalıbı doğrulanmadığından fotoğraftaki görünür eldiven profili yorumlandı; başparmak kanadı uydurulmadı. Yerel çizgi/kapitone/dantel aralığı, cep ve kıvrım kalıbı fotoğraf yorumudur.'
 meta=A.base_metadata(SKU,aid,dict(set_quantity=2,parts=[dict(role='oven_mitt',nominal_flat_cm=[13.5,27]),dict(role='potholder',nominal_flat_cm=[21,21])]),note,'cotton',2);meta.update(source_dimensions_hwd_cm=[None,None,None],material_label='Pamuk %100 · Dolgulu kapitone dimi',quality_status='photo_interpretation',quality_label='Gerçek açık el cepleri · Kapitone ve delikli dantel',scene_variants=[dict(index=0,label='Eldiven ve tutacak · 2 parça'),dict(index=1,label='13,5×27cm fırın eldiveni'),dict(index=2,label='21×21cm cepli tutacak')]);meta['source_evidence_files'].append(str(T/'additional-exact-role-research.json'))
 e=A.finish(raw,meta,material,features=dict(actual_open_mitt_hand_cavity=True,actual_potholder_hand_pocket=True,actual_lace_holes=15,nominal_dimensions_verified=True));doc,binary=C.read_glb(e['glb_path']);nodeby={n['mesh']:i for i,n in enumerate(doc['nodes'])if'mesh'in n};allv=np.concatenate([q['_vertices']for q in raw]);alo,ahi=allv.min(0),allv.max(0)
 for k,group in enumerate(groups):
  leaves=[]
  for mi in group:leaves.append(len(doc['nodes']));doc['nodes'].append(copy.deepcopy(doc['nodes'][nodeby[mi]]))
  lo,hi=bounds[k];translation=[float((alo[0]+ahi[0]-lo[0]-hi[0])/2),float(alo[1]-lo[1]),float((alo[2]+ahi[2]-lo[2]-hi[2])/2)];root=len(doc['nodes']);doc['nodes'].append(dict(name='single-physical-oven-part',children=leaves,translation=translation));doc['scenes'].append(dict(name='Oven mitt'if k==0 else'Pocket potholder',nodes=[root]))
 C.write_glb(e['glb_path'],doc,binary);e['sha256']=C.sha(e['glb_path']);e['bytes']=Path(e['glb_path']).stat().st_size;out=Path(e['asset_dir']);C.dump(out/'entry.json',e);rp=out/(aid+'.validation.json');r=json.loads(rp.read_text());r['deliverable_sha256']['glb']=e['sha256'];r['glb_bytes']=e['bytes'];C.dump(rp,r);C.dump(D/'candidate-two-part-oven-manifest.json',[e]);print('REAL OVEN TWO ROLE SET',flush=True)
if __name__=='__main__':build()
