"""Prepare the three own-source shapes only; no GLB and no readiness claim."""
from pathlib import Path
import sys,json,numpy as np
sys.dont_write_bytecode=True
T=Path(__file__).resolve().parent;sys.path.insert(0,str(T))
import build_remaining_source_specific_robes as M
D=M.D/'prepared-geometry';D.mkdir(exist_ok=True)
class Prepared(Exception):pass
def capture(raw,meta,mf,features=None):
 sku=meta['sku'];arrays={};parts=[]
 for k,q in enumerate(raw):
  arrays[f'{k}_p']=np.array(q['_vertices'],np.float64);arrays[f'{k}_f']=np.array(q['_faces'],np.int64);arrays[f'{k}_uv']=np.array(q['_uvs'],np.float64);parts.append(dict(index=k,name=q['name'],material=q['material']))
  assert np.isfinite(arrays[f'{k}_p']).all()and np.isfinite(arrays[f'{k}_uv']).all()
 np.savez_compressed(D/(sku+'.npz'),**arrays);M.C.dump(D/(sku+'.json'),dict(metadata=meta,parts=parts,features=features,prepared_only=True,no_glb=True,scope_counted_ready=False,material_gate_pending=True,sha256=M.C.sha(D/(sku+'.npz'))));print('PREPARED OWN SOURCE GEOMETRY',sku,len(parts),flush=True);raise Prepared()
M.Q.R.ORIGINAL_FINISH=capture
if __name__=='__main__':
 for sku in sys.argv[1:]:
  try:M.M.build(sku)
  except Prepared:pass
