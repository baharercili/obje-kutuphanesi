"""All remaining napkin sets with each own native word or holiday motif.

No replacement font or generic icon is used. Pigment masks are smaller than
their immutable native crops, with raised real threads and separate scenes.
"""
from pathlib import Path
import sys,json,copy,math
import numpy as np
from PIL import Image
sys.dont_write_bytecode=True
T=Path(__file__).resolve().parent;sys.path.insert(0,str(T))
import build_folded_soft_revision as F
import build_distinct_blankets as H
A,C,B,L=F.A,F.C,F.B,F.L
D=T/'native-embroidered-napkin-sets-batch01';D.mkdir(exist_ok=True);A.R=D
GALLERY=json.loads((T/'gallery-originals/masters.json').read_text())
CFG={
 '1350025001':dict(qty=2,size=[45,45],recipe='linen_blend',rgb=[233,226,208],names=['Kırmızı yaprak','Kırmızı yaprak']),
 '1350080001':dict(qty=4,size=[45,45],recipe='cotton',rgb=[242,242,235],names=['Geyik','Çelenk','Ökseotu','Çobanpüskülü']),
 '1354786001':dict(qty=4,size=[45,45],recipe='linen_blend',rgb=[233,226,208],names=['merry','jolly','peace','joy']),
}
def originals(sku):
 if sku=='1350080001':return next(x for x in GALLERY if x['sku']==sku)
 return L.EVIDENCE[sku]['original']
def crops(sku):
 master=originals(sku);im=Image.open(master['path']).convert('RGB')
 if sku=='1350080001':boxes=[[650,1640,890,1900],[995,1670,1215,1910],[1320,1670,1530,1910],[1630,1710,1845,1910]]
 elif sku=='1350025001':boxes=[[720,980,1380,1710]]*2
 else:
  area=im.crop([250,1300,1400,1600]);p=np.asarray(area,float);mask=(p[:,:,0]/(p[:,:,1]+1)>1.55)&(p[:,:,0]>65);xs=np.where(mask.any(0))[0];groups=np.split(xs,np.where(np.diff(xs)>40)[0]+1);assert len(groups)==4,[(x.min(),x.max())for x in groups];boxes=[]
  for x in groups:
   yy=np.where(mask[:,x.min():x.max()+1].any(1))[0];boxes.append([250+int(x.min())-4,1300+int(yy.min())-4,250+int(x.max())+5,1300+int(yy.max())+5])
 return master,[(im.crop(box),box)for box in boxes]
def pigment(im,sku):
 p=np.asarray(im,float);red=np.clip(((p[:,:,0]+1)/(p[:,:,1]+1)-1.28)/.9,0,1);labels=np.where(red>.55,1,0)
 if sku=='1350080001':
  green=(p[:,:,1]>p[:,:,0]*1.025)|((p[:,:,1]-p[:,:,2]>10)&(p[:,:,1]>p[:,:,0]*.94));brown=(p[:,:,0]>p[:,:,2]*1.15)&(p[:,:,0]>p[:,:,1]*1.10)&(red<.5);dark=p.mean(2)<90
  labels=np.where(green,2,labels);labels=np.where(brown,3,labels);labels=np.where(dark,4,labels)
 return labels
COLOURS={1:[116,9,30],2:[67,84,48],3:[137,100,72],4:[43,36,29]}
def material(sku,out):
 cfg=CFG[sku];m0=B.material(sku,dict(recipe=cfg['recipe'],rgb=cfg['rgb'],intrinsic_ao=True,normal_scale=.48 if sku=='1350080001'else.68),out);master,items=crops(sku);m={}
 for k,(im,box)in enumerate(items):
  labels=pigment(im,sku);alpha=labels>0;rgba=np.zeros((*alpha.shape,4),np.uint8)
  for c,rgb in COLOURS.items():rgba[:,:,:3][labels==c]=rgb
  rgba[:,:,3]=np.uint8(alpha)*255;patch=Image.fromarray(rgba,'RGBA');target=(116,116)if sku=='1350025001'else(90,100)if sku=='1350080001'else(125,45)
  # Fit inside the requested physical motif box without enlarging native art.
  factor=min(target[0]/patch.width,target[1]/patch.height,1);target=(max(1,round(patch.width*factor)),max(1,round(patch.height*factor)));patch=patch.resize(target,Image.Resampling.LANCZOS)
  canvas=Image.new('RGB',(800,800),tuple(cfg['rgb']));centre=(.82,.16);at=(round(centre[0]*800-target[0]/2),round(centre[1]*800-target[1]/2));canvas.paste(patch,at,patch);filename=f'{sku}-piece{k+1}-own-native-motif.png';canvas.save(out/filename,optimize=True);im.save(out/f'piece{k+1}-native-crop-evidence.png')
  cloth=copy.deepcopy(m0['cloth']);cloth['baseColorTexture']=filename;m['cloth-'+str(k)]=cloth;m['hem-'+str(k)]=copy.deepcopy(cloth)
  for key,rgb in COLOURS.items():m[f'embroider-{k}-{key}']=dict(baseColorFactor=[v/255 for v in rgb]+[1],metallic=0,roughness=.78,doubleSided=False,alphaMode='OPAQUE')
 C.dump(out/'native-motifs-provenance.json',dict(master=master,native_boxes=[box for im,box in items],piece_names=cfg['names'],
  own_words_or_symbols_preserved=True,no_replacement_font_or_icon=True,one_downsample_no_enlargement=True,source_studio_luminance_discarded=True,
  unseen_whole_napkin_motif_position_interpreted=True,interpreted_full_plan_cm=cfg['size']))
 return m
def build(sku):
 cfg=CFG[sku];master,items=crops(sku);w,l=np.array(cfg['size'])/100;raw=[];groups=[];bounds=[];proofs=[]
 for k,(im,box)in enumerate(items):
  g,n,uv,proof=F.folded(w,l,cfg['recipe'],int(sku)+k*971);proofs.append(proof);parts=[C.shell('continuous-soft-four-layer-napkin','cloth-'+str(k),g,n,.00055,uv*np.array([w/.04,l/.04]))]
  for name,path in [('end-a',g[0]),('end-b',g[-1]),('side-a',g[:,0]),('side-b',g[:,-1])]:parts.append(C.tube(name+'-soft-sewn-edge','hem-'+str(k),path,.00045,sides=7))
  labels=pigment(im,sku);hh,ww=labels.shape;requested=(116,116)if sku=='1350025001'else(90,100)if sku=='1350080001'else(125,45)
  factor=min(requested[0]/im.width,requested[1]/im.height,1)
  target=(max(1,round(im.width*factor)),max(1,round(im.height*factor)))
  physical=(target[0]/800*w,target[1]/800*l)
  # Physical motif positions correspond to the same whole-napkin UV domain.
  for key in COLOURS:
   stitches=[]
   for row in range(1,hh-1,3):
    line=labels[row]==key;ed=np.diff(np.r_[False,line,False].astype(int));starts=np.where(ed==1)[0];ends=np.where(ed==-1)[0]
    for aa,bb in zip(starts,ends):
     if bb-aa<2:continue
     path=[]
     for x in np.linspace(aa+.25,bb-.25,4):
      u=.82+(x/(ww-1)-.5)*physical[0]/w;v=.16+(row/(hh-1)-.5)*physical[1]/l;p,nn=H.sample(g,n,uv,u,v)
      if nn[1]<0:nn=-nn
      path.append(p+nn*.00065)
     stitches.append(C.tube('native-symbol-raised-stitch',f'embroider-{k}-{key}',path,.00016,sides=5))
   if stitches:parts.append(H.combine('own-piece-'+str(k+1)+'-native-colour-'+str(key)+'-stitches',f'embroider-{k}-{key}',stitches))
  # Two-by-two layout leaves every distinct source motif inspectable.
  offset=np.array([(k%2-.5)*.25,0,(k//2-.5)*.25])if cfg['qty']==4 else np.array([(k-.5)*.25,0,0]);group=[]
  for q in parts:q['name']='piece-'+str(k+1)+'-'+q['name'];q['_vertices']=[tuple(np.array([-v[0],v[1],v[2]])+offset)for v in q['_vertices']];group.append(len(raw));raw.append(q)
  groups.append(group);p=np.concatenate([raw[i]['_vertices']for i in group]);bounds.append((p.min(0),p.max(0)))
 aid='hm-'+sku+'-all-distinct-native-embroidered-soft-napkins';qty=cfg['qty'];note=f'Exact SKU{qty}parça seti, her parçanın kendi fotoğrafındaki ayrı motif/yazısı korunur. Açık santimetre ölçüsü doğrulanmadığından yaklaşık45×45cm düz peçete planı gösterim yorumudur, resmî ürün bedeni değildir. Gerçek dört katlı sürekli kumaş, kabarık kapalı dikişler ve set/tekli sahneler vardır. Motifin görünmeyen tam peçete yerleşimi, fiziksel boyu, iplik/renk ve kat pozu yorumdur; stüdyo ışığı kaplamaya alınmadı.'
 meta=A.base_metadata(sku,aid,dict(set_quantity=qty),note,cfg['recipe'],qty);meta.update(source_dimensions_hwd_cm=[None,None,None],interpreted_display_flat_size_cm=cfg['size'],cloth_fold_proof=proofs,quality_status='photo_interpretation',quality_label='Kendi özgün nakışları · Yumuşak dört kat · Ölçek yaklaşık',scene_variants=[dict(index=0,label=f'{qty}farklı fiziksel peçete')]+[dict(index=k+1,label=name)for k,name in enumerate(cfg['names'])])
 if sku=='1350080001':meta['original_images'].append({k:master[k]for k in['path','url','sha256']})
 meta['material_label']='Pamuk %100 · Saten dokuma'if sku=='1350080001'else'Pamuk %90 · Keten %10'
 e=A.finish(raw,meta,lambda out:material(sku,out),features=dict(physical_piece_count=qty,own_distinct_motifs=cfg['names'],no_replacement_font=True));doc,binary=C.read_glb(e['glb_path'])
 for mat in doc['materials']:
  if mat['name'].startswith(('cloth-','hem-')):mat['pbrMetallicRoughness']['baseColorTexture'].setdefault('extensions',{})['KHR_texture_transform']=dict(scale=[.04/w,.04/l])
 nodes={n['mesh']:i for i,n in enumerate(doc['nodes'])if'mesh'in n};pp=np.concatenate([q['_vertices']for q in raw]);alo,ahi=pp.min(0),pp.max(0)
 for k,group in enumerate(groups):
  leaves=[]
  for mi in group:leaves.append(len(doc['nodes']));doc['nodes'].append(copy.deepcopy(doc['nodes'][nodes[mi]]))
  lo,hi=bounds[k];tr=[float((alo[0]+ahi[0]-lo[0]-hi[0])/2),float(alo[1]-lo[1]),float((alo[2]+ahi[2]-lo[2]-hi[2])/2)];root=len(doc['nodes']);doc['nodes'].append(dict(name='single-source-motif-napkin',children=leaves,translation=tr));doc['scenes'].append(dict(name=cfg['names'][k],nodes=[root]))
 doc['extensionsUsed']=sorted(set(doc['extensionsUsed'])|{'KHR_texture_transform'});C.write_glb(e['glb_path'],doc,binary);e['sha256']=C.sha(e['glb_path']);e['bytes']=Path(e['glb_path']).stat().st_size;out=Path(e['asset_dir']);C.dump(out/'entry.json',e);rp=out/(aid+'.validation.json');r=json.loads(rp.read_text());r['deliverable_sha256']['glb']=e['sha256'];r['glb_bytes']=e['bytes'];C.dump(rp,r);p=D/'candidate-native-napkin-sets-manifest.json';rows=json.loads(p.read_text())if p.exists()else[];C.dump(p,[x for x in rows if x['sku']!=sku]+[e]);print('NATIVE NAPKIN SET',sku,flush=True)
if __name__=='__main__':
 for sku in sys.argv[1:]:build(sku)
