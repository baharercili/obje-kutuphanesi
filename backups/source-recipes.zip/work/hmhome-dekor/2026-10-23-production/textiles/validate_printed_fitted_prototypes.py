from pathlib import Path
import json,sys,struct,hashlib,importlib.util
sys.dont_write_bytecode=True
import numpy as np
R=Path(__file__).resolve().parent;s=importlib.util.spec_from_file_location('independent_soft_form_binary',R/'specific_binary_native_material.py');S=importlib.util.module_from_spec(s);s.loader.exec_module(S)
def validate(e):
 check=S.check(e);model=json.loads(Path(e['model_path']).read_text());meta=model['metadata'];data=Path(e['glb_path']).read_bytes();n=struct.unpack_from('<I',data,12)[0];doc=json.loads(data[20:20+n]);bl=struct.unpack_from('<I',data,20+n)[0];binary=data[28+n:28+n+bl];assert doc['extras']['metadata']==meta
 def array(i):
  a=doc['accessors'][i];v=doc['bufferViews'][a['bufferView']];dt={5126:'<f4',5125:'<u4',5123:'<u2'}[a['componentType']];c={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}[a['type']];d=np.dtype(dt).itemsize;return np.ndarray((a['count'],c),dtype=dt,buffer=binary,offset=v.get('byteOffset',0)+a.get('byteOffset',0),strides=(v.get('byteStride',c*d),d)).copy()
 if e['family']=='fitted_sheet':
  official=e['official_measurements'];assert abs(e['dimensions_cm'][0]-official['mattress_width_cm'])<.1;assert abs(e['dimensions_cm'][2]-official['mattress_length_cm'])<.1;assert not meta['fitted_sheet_features']['mattress_mesh_included'];body=next(m for m in doc['meshes']if m['name']=='continuous-top-sides-and-elastic-tuck-cloth');p=body['primitives'][0];v=array(p['attributes']['POSITION']);faces=array(p['indices']).reshape(-1,3);tri=v[faces];bottom=tri[(tri[:,:,1]<.02).all(1)];assert len(bottom)>0;centroids=bottom.mean(1);w=official['mattress_width_cm']/100;l=official['mattress_length_cm']/100;assert np.all((abs(centroids[:,0])>w*.40)|(abs(centroids[:,2])>l*.40));check['hollow_underneath_verified']=True;check['mattress_mesh_absent']=True
 elif e['family']=='eyelet_shower_curtain':
  holes=[]
  for mesh in doc['meshes']:
   if not mesh['name'].startswith('header-actual-pierced-hole-'):continue
   p=mesh['primitives'][0];verts=array(p['attributes']['POSITION']);indices=array(p['indices']).reshape(-1,3);mapping={};weld=[]
   for v in verts:
    key=tuple(np.round(v.astype(float),7));mapping.setdefault(key,len(mapping));weld.append(mapping[key])
   ff=np.array(weld)[indices];edges=set()
   for a,b,c in ff:edges.update([tuple(sorted((int(a),int(b)))),tuple(sorted((int(b),int(c)))),tuple(sorted((int(c),int(a))))])
   chi=len(set(ff.ravel()))-len(edges)+len(ff);assert chi==0,(mesh['name'],chi);holes.append(dict(mesh=mesh['name'],closed_annular_solid_euler_characteristic=chi,actual_geometric_opening=True))
  assert len(holes)==12 and not meta['shower_features']['header_hole_count_officially_verified'];assert any(m['name']=='separate-polyester-rear-layer'for m in doc['meshes']);check['actual_header_hole_checks']=holes
 proof=json.loads(Path(e['native_print_provenance']).read_text());assert not proof['source_upscaled'];
 if proof.get('source_quad'):
  quad=np.array(proof['source_quad']).reshape(4,2);ow,oh=proof['native_output_pixels'];assert ow<=min(np.linalg.norm(quad[3]-quad[0]),np.linalg.norm(quad[2]-quad[1]));assert oh<=min(np.linalg.norm(quad[1]-quad[0]),np.linalg.norm(quad[2]-quad[3]));assert proof['geometric_resampling_count']==1
 else:assert proof['native_output_pixels']==[proof['source_crop'][2]-proof['source_crop'][0],proof['source_crop'][3]-proof['source_crop'][1]] and proof['geometric_resampling_count']==0
 assert hashlib.sha256(Path(proof['master']['path']).read_bytes()).hexdigest()==proof['master']['sha256'];assert'KHR_texture_transform'in doc['extensionsUsed'];repeat=proof['estimated_print_repeat_m']
 for mat in doc['materials']:
  if mat['name']in['cloth','hem']:assert np.allclose(mat['pbrMetallicRoughness']['baseColorTexture']['extensions']['KHR_texture_transform']['scale'],[.04/repeat[0],.04/repeat[1]])
 check['source_original_bytes_unchanged']=True;check['metadata_truthful']=True;check['native_print_crop_no_upscale']=True;check['pattern_repeat_unconfirmed_and_disclosed']=True;return check
if __name__=='__main__':
 p=Path(sys.argv[1]);rows=json.loads(p.read_text());checks=[]
 for e in rows:checks.append(validate(e));print('AUDITED DISTINCT',e['sku'],flush=True)
 out=p.with_name(p.stem+'-independent-validation.json');out.write_text(json.dumps(dict(valid=True,models=len(rows),checks=checks,canonical_changed=False),ensure_ascii=False,indent=2)+'\n');print(out,hashlib.sha256(out.read_bytes()).hexdigest())
