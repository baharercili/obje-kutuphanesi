from pathlib import Path
import json,struct,collections,sys
P=Path(__file__).resolve().parent
S=P.parents[2]/'sites/zarahome-vazo-kutuphanesi-final-378'
catalog=json.loads((S/'ui/hmhome-catalog.json').read_text())
rows=[dict(id=x['id'],sku=x['sku'],sha256=x['glb_url'].split('?v=')[-1],glb_path=str(S/'model-source'/(x['id']+'.glb')),stage='canonical')for x in catalog]
for argument in sys.argv[1:]:
 candidate=Path(argument)
 rows.extend(dict(x,stage='reviewed_candidate')for x in json.loads(candidate.read_text()))
rows=list({(x['id'],x.get('sha256')):x for x in rows}.values())
def scan(obj,path=''):
 out=[]
 if isinstance(obj,dict):
  for k,v in obj.items():
   if k=='extensions' and isinstance(v,dict):out.extend((e,path)for e in v)
   out.extend(scan(v,path+'/'+k))
 elif isinstance(obj,list):
  for i,v in enumerate(obj):out.extend(scan(v,path+'/'+str(i)))
 return out
checks=[]
for x in rows:
 with Path(x['glb_path']).open('rb')as f:
  head=f.read(20);n,kind=struct.unpack_from('<II',head,12);assert kind==0x4e4f534a;d=json.loads(f.read(n))
 used=set(d.get('extensionsUsed',[]));actual=scan(d);missing=[dict(extension=e,path=p)for e,p in actual if e not in used]
 if missing:
  transforms=[]
  for m in d.get('materials',[]):
   albedo=m.get('pbrMetallicRoughness',{}).get('baseColorTexture',{})
   if albedo.get('extensions',{}).get('KHR_texture_transform'):transforms.append(dict(material=m.get('name'),transform=albedo['extensions']['KHR_texture_transform']))
  checks.append(dict(id=x['id'],sku=x['sku'],stage=x['stage'],extensionsUsed=sorted(used),missing=missing,albedo_transforms=transforms))
report=dict(checked_models=len(rows),affected_models=len(checks),affected_by_stage=dict(collections.Counter(x['stage']for x in checks)),checks=checks,read_only=True)
(P/'material-extension-declaration-audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items()if k!='checks'}))
print([(x['sku'],len(x['albedo_transforms']))for x in checks])
