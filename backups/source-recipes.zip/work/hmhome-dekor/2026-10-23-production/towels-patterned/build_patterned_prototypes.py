"""Three source-specific prototypes using the approved finite folded towel family."""
from pathlib import Path
import sys,json,math,copy,hashlib,importlib.util
sys.dont_write_bytecode=True
import numpy as np
from PIL import Image,ImageFilter
R=Path(__file__).resolve().parent;P=R.parent;PR=P/'root';TAU=math.tau
spec=importlib.util.spec_from_file_location('patterned_towel_approved_geometry',PR/'towels/build_towels.py');T=importlib.util.module_from_spec(spec);spec.loader.exec_module(T)
C=T.C;B=T.B;M=T.M;H=T.H;Exporter=T.Exporter
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,d):Path(p).parent.mkdir(parents=True,exist_ok=True);Path(p).write_text(json.dumps(d,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
ROWS={e['sku']:e for e in read(R/'source-queue-50.json')};MASTERS={e['sku']:e for e in read(R/'original-image-masters.json')};PRIMARY=read(R/'primary-image-masters.json');ANCHORS=read(P/'official-grid-size-anchors-all.json')['products'];RESEARCH={e['sku']:e for e in read(PR/'textile-primary-research.json')['products']}
SPECS={
 '1323308001':dict(image_code='15a54132',crop=[700,200,828,328],family='fringed_terry',fringe=.06),
 '1336978002':dict(image_code='b428e8dd',crop=[650,350,778,478],family='own_blue_white_grid',grid_pitch_m=.235,grid_line_m=.0045),
 '1338733001':dict(image_code='8d535148',crop=[650,850,778,978],family='own_cream_braided_chevron',chevron_pitch_m=[.022,.028])}

def materials(pid,out,w,l):
 recipe=SPECS[pid];master=next(e for e in PRIMARY if e['sku']==pid and recipe['image_code']in e['url']);im=Image.open(master['path']).convert('RGB');box=recipe['crop'];patch=im.crop(box);patch.save(out/'donor-crop-native.png');a=np.asarray(patch,float);palette=np.median(a.reshape(-1,3),axis=0);illum=np.asarray(patch.filter(ImageFilter.GaussianBlur(5)),float);detail=np.clip(a/np.maximum(illum,1)*palette,0,255);native=Image.fromarray(detail.astype(np.uint8)).resize((84,84),Image.Resampling.LANCZOS);native.save(out/'intrinsic-native84.png');n,m=2048,4096;yy,xx=np.indices((m,n));u=xx/(n-1);v=yy/(m-1);tile=np.asarray(native,float)[yy%84,xx%84];rgb=palette+(tile-palette)*.5;micro=tile.mean(2)-tile.mean();edge_end=np.minimum(v,1-v)*l;edge_long=np.minimum(u,1-u)*w;band=(edge_end<.042)|(edge_long<.008);macro_height=np.zeros((m,n));phase_note='Plain own-SKU cloth; visible yarn colour/texture from its immutable donor.';colours=[palette.tolist()]
 if pid=='1336978002':
  full=np.asarray(im,float);lum=full.mean(2);mask=(lum>180)&(full[:,:,0]>full[:,:,2]*.90);white=np.median(full[mask],axis=0);pitch=recipe['grid_pitch_m'];du=np.abs(((u*w+.021+pitch/2)%pitch)-pitch/2);dv=np.abs(((v*l+.036+pitch/2)%pitch)-pitch/2);weight=np.clip((recipe['grid_line_m']/2-np.minimum(du,dv))*n/w+.5,0,1);rgb=rgb*(1-weight[:,:,None])+(white+(tile-palette)*.35)*weight[:,:,None];colours.append(white.tolist());macro_height+=weight*.00012;phase_note='Own blue/white yarn colours and observed orthogonal grid;235mm repeat and4.5mm line are photo estimates. Unseen flat phase is interpreted.'
 if pid=='1338733001':
  px,py=recipe['chevron_pitch_m'];sx=((u*w/px)%1);path=(v*l/py-np.abs(sx-.5)*1.8)%1;distance=np.minimum(path,1-path);ridge=np.exp(-(distance/.14)**2);macro_height+=ridge*.00075;phase_note='Own cream yarn pixels and cable-inspired interlocking chevron relief;22x28mm pitch and0.75mm elevation are source-informed estimates, not manufacturer measurements.'
 if pid=='1323308001':
  band=edge_end<.060;raised=np.minimum.reduce([abs(edge_end-z)for z in[.012,.030,.048]]);macro_height+=.00020*np.exp(-(raised/.0018)**2);phase_note='Own cream terry donor, three short-end woven bands and separate physical twisted tassels. Band/fringe dimensions are photo estimates.'
 px=u*w/.0022;py=v*l/.0026;cx=(px+.12*np.sin(np.floor(py)*1.7))%1-.5;cy=py%1-.5;radius=np.sqrt((cx/.36)**2+(cy/.43)**2);loop=np.exp(-((radius-1)/.24)**2)*(1-.38*np.exp(-((cy+.35)/.12)**2));height=loop*.00048+micro*.000007+macro_height;fineweave=.7*np.sin(TAU*xx/3)*np.sin(TAU*yy/2);rgb[band]=np.clip(palette+fineweave[band,None],0,255);height[band]=fineweave[band]*.000012+macro_height[band];dy,dx=np.gradient(height,l/(m-1),w/(n-1));normal=np.stack([-dx,-dy,np.ones_like(dx)],2);normal/=np.linalg.norm(normal,axis=2,keepdims=True);orm=np.zeros((m,n,3),np.uint8);orm[:,:,0]=np.clip(182+73*loop,0,255);orm[:,:,0][band]=250;orm[:,:,1]=np.clip(241+micro*.15,225,250);orm[:,:,1][band]=236
 for name,data in [('albedo',np.clip(rgb,0,255).astype(np.uint8)),('normal',np.clip((normal+1)*127.5,0,255).astype(np.uint8)),('orm',orm)]:Image.fromarray(data,'RGB').save(out/(name+'.png'),optimize=True)
 proof=dict(source_path=master['path'],source_sha256=master['sha256'],source_pixels=master['pixels'],crop_box_original_pixels=box,crop_pixels=list(patch.size),native_crop_pixel_identical=np.array_equal(np.asarray(patch),np.asarray(im)[box[1]:box[3],box[0]:box[2]]),native_detail_pixels=[84,84],output_pixels=[n,m],geometric_resampling_count=1,source_master_unchanged=sha(master['path'])==master['sha256'],full_marketing_photo_wrapped=False,background_pixels_baked=False,palette_rgb=colours,operations=['Integer own-SKU fabric-only crop from immutable official JPEG','Separate broad fold illumination; one128-to84 antialiased reduction of the intrinsic micro-donor','Repeat native pixels rather than enlarge them','Own-family pattern/yarn normal generated at explicit metre scale; no palette quantization'],family_interpretation=phase_note,unique_photographic_detail_not_2k=True);dump(out/'crop-provenance.json',proof)
 cloth=dict(baseColorFactor=[1,1,1,1],baseColorTexture='albedo.png',normalTexture='normal.png',metallicRoughnessTexture='orm.png',normalScale=1.,metallic=1,roughness=1,doubleSided=False,alphaMode='OPAQUE',extras=dict(intrinsic_material=True,photo_pixels_baked=True,own_photo_material_crop=True,baked_reflections=False,source_crop_provenance=str(out/'crop-provenance.json'),terry_loop_relief_scale_mm=[2.2,2.6,.48],loop_relief_photo_interpretation=True))
 for name,rgb in [('loop-albedo',palette),('loop-normal',[128,128,255]),('loop-orm',[255,240,0])]:Image.new('RGB',(128,128),tuple(np.rint(rgb).astype(int))).save(out/(name+'.png'))
 yarn=copy.deepcopy(cloth);yarn.update(baseColorTexture='loop-albedo.png',normalTexture='loop-normal.png',metallicRoughnessTexture='loop-orm.png',normalScale=.2);yarn['extras'].update(photo_pixels_baked=False,constant_intrinsic_maps_no_artificial_upscale=True)
 return dict(cloth=cloth,loop=yarn),proof

def twisted_fringe(grid,width):
 rng=np.random.default_rng(1323308001);parts=[];count=round(width/.014)
 for end in[0,-1]:
  for k in range(count):
   at=(k+.5)/count*(grid.shape[0]-1);i=min(int(at),grid.shape[0]-2);f=at-i;p=grid[i,end]*(1-f)+grid[i+1,end]*f;inward=grid[i,1]-grid[i,0]if end==0 else grid[i,-2]-grid[i,-1];direction=-inward;direction[1]=0;direction/=np.linalg.norm(direction);across=np.array([direction[2],0,-direction[0]]);length=.06*rng.uniform(.84,1.12);phase=rng.uniform(0,TAU)
   for strand in[0,1]:
    pts=[]
    for q in np.linspace(0,1,25):angle=q*TAU*4+phase+strand*math.pi;pts.append(p+direction*length*q+across*(.0010*math.cos(angle)+.004*math.sin(q*math.pi*.8+phase)*q)+np.array([0,.0010*math.sin(angle)-.004*math.sin(math.pi*q),0]))
    parts.append(B.tube('physical-two-strand-twisted-fringe','loop',pts,.00055,.00055,5,False,guide=[0,1,0]))
   tip=np.asarray(pts[-1])
   for strand in range(4):
    spread=(strand-1.5)*.0007;root=tip+across*spread*.25+np.array([0,(strand-1.5)*.00007,0]);pts2=[root,root+direction*.004+across*spread,root+direction*.008+across*spread*1.6+np.array([0,-.001,0])];parts.append(B.tube('loose-small-fringe-tip-fibre','loop',pts2,.00017,.00014,3,False,guide=[0,1,0]))
 # A genuine twisted cord and small loose fan end; no photographic tassel halo.
 verts=[];faces=[];uv=[]
 for p in parts:
  off=len(verts);verts+=p['_vertices'];uv+=p['_uvs'];faces +=[tuple(j+off for j in tri)for tri in p['_faces']]
 return B.solid('physical-twisted-short-edge-fringes-with-loose-ends','loop',verts,faces,uv)

def build(pid):
 assert pid in SPECS;assert not(R/'FINAL-FROZEN.json').exists();assert not any(pid in {e['sku']for e in read(f)}for f in R.glob('frozen-*/manifest.json')),'Prototype snapshot is immutable';q=ROWS[pid];anchor=ANCHORS[pid]['anchors'][0];w,l=np.array(anchor['size_tag_cm'])/100;id='hm-'+pid+'-'+('x'.join(format(x,'g')for x in anchor['size_tag_cm']))+'-patterned-folded-1piece';out=R/'models'/id;out.mkdir(parents=True,exist_ok=True);master=MASTERS[pid];grid,normals,uv,extra=T.folded_drape(w,l);parts=[C.shell('continuous-approved-soft-folded-terry','cloth',grid,normals,.0038,uv),T.folded_loop(grid,uv)]
 if pid=='1323308001':parts.append(twisted_fringe(grid,w))
 if pid=='1336978002':
  loop=copy.deepcopy(parts[1]);j=int(np.argmin(abs(uv[0,:,1]-.46)));oldpin=grid[0,j];i=int(np.argmin(abs(uv[:,0,0]-.5)));newpin=grid[i,0];loop['_vertices']=[tuple(np.asarray(v)+newpin-oldpin)for v in loop['_vertices']];loop['name']='own-PDP-second-short-edge-hanging-loop';parts.append(loop)
 pos=np.concatenate([p['_vertices']for p in parts]);lo=pos.min(0);hi=pos.max(0);origin=np.array([(lo[0]+hi[0])/2,lo[1],(lo[2]+hi[2])/2]);meshes=[];checks=[]
 for p in parts:
  p['_vertices']=[tuple(np.asarray(v)-origin)for v in p['_vertices']];mesh,check=T._finalize(H.orient(p));meshes.append(mesh);checks.append(check)
 repairs=M.ensure_uv_faces(meshes)+H.ensure_float32_uv(meshes);allpos=np.concatenate([np.asarray(m['positions']).reshape(-1,3)for m in meshes]);dims=((allpos.max(0)-allpos.min(0))*100).tolist();mats,provenance=materials(pid,out,w,l);primary=read(PR/'towels-patterned/source-evidence'/(pid+'.json'));assert primary['sku']==pid and pid in primary['description'];cotton='Pamuk 100%'in primary['materials'];title=q['name'].translate(str.maketrans({'I':'ı','İ':'i'})).lower();title=title[:1].upper()+title[1:];note='Resmî seçili düz beden '+anchor['verbatim_size_tag']+'; görünen en/yükseklik/derinlik seçilmiş yumuşak katlı poza aittir.3,8mm kumaş kalınlığı, ilmek/örgü ölçeği, dokuma bordürler, kat yarıçapları ve görünmeyen desen fazı fotoğraf yorumudur.'
 if pid=='1323308001':note+=' İki kısa kenarda yaklaşık6cm burgulu püskül ve gevşek lif uçları ayrı fiziksel geometridir; kaynak beden etiketinin püskül kapsamı açıklanmamıştır.'
 photos=[e for e in PRIMARY if e['sku']==pid];originals=[{k:x[k]for k in['path','url','sha256']}for x in photos];sources=[dict(url=e['url'],alt=e['alt'])for e in photos];meta=dict(id=id,sku=pid,brand='H&M Home',name=title+' · '+anchor['verbatim_size_tag'],category='Havlular',url=q['url'],dimensions_cm=dims,official_measurements=dict(towel_flat_width_cm=w*100,towel_flat_length_cm=l*100,size_label=anchor['verbatim_size_tag'],set_quantity=1),source_dimensions_hwd_cm=None,estimated_dimensions=True,estimated_fields=['folded_pose_dimensions','cloth_thickness','pile_and_pattern_relief_scale','hem_width','hidden_pattern_phase']+(['fringe_length_and_tassel_distribution']if pid=='1323308001'else[]),size_source_kind='official_textile_plan_estimated_folded_pose',source_market='Türkiye',size_source_urls=[q['url'],anchor['category_url']],material_label='Pamuk %100 · KendiSKU kumaşı'if cotton else'KendiSKU kumaş fotoğrafı; lif yüzdesi doğrulanmadı',set_quantity=1,scene_variants=[],default_scene_index=0,scale_note=note,diameter_semantics=note,source_notes=[note],quality_status='photo_interpretation',quality_label='Katlanmış poz / Kumaş yorumu',quality_note=provenance['family_interpretation'],source_images=sources,original_image=master['path'],original_image_sha256=master['sha256'],original_images=originals,source_evidence_files=RESEARCH[pid]['evidence_files']+[anchor['evidence_file'],str(PR/'towels-patterned/source-evidence'/(pid+'.json')),str(out/'crop-provenance.json')],units='metres',up_axis='Y',origin='bottom bounding-box centre',baked_reflections=False,geometry_only_qa=False,**extra);dump(out/'model.json',dict(metadata=meta,materials=mats,meshes=meshes));dump(out/'geometry-validation.json',dict(valid=True,closed_material_solids=True,meshes=checks,uv_repairs=repairs));dump(out/'material-validation.json',dict(valid=True,source_masters_unchanged=all(sha(x['path'])==x['sha256']for x in originals),native_provenance=provenance));dump(out/'source-evidence.json',dict(own_primary=primary,official_grid_anchor=anchor,exact_cached_research=RESEARCH[pid],original_master=master))
 report=Exporter.export_assets(out/'model.json',out,id);glb=out/(id+'.glb');doc,binary=C.read_glb(glb);doc['samplers']=[dict(magFilter=9729,minFilter=9987,wrapS=10497,wrapT=10497)]
 for tex in doc['textures']:tex['sampler']=0
 for ma in doc['materials']:
  if ma['name']=='cloth':ma['occlusionTexture']={**ma['pbrMetallicRoughness']['metallicRoughnessTexture'],'strength':.65}
 binary=M.embed_tangents(doc,binary);C.write_glb(glb,doc,binary);report['deliverable_sha256']['glb']=sha(glb);report['glb_bytes']=glb.stat().st_size;dump(Path(report['files']['validation']),report);entry={**meta,'asset_dir':str(out),'model_path':str(out/'model.json'),'glb_path':str(glb),'sha256':sha(glb),'bytes':glb.stat().st_size,'geometry_validation':str(out/'geometry-validation.json'),'material_validation':str(out/'material-validation.json'),'model_revision':'own-pattern-approved-soft-towel-prototype-2026-10-24-v1','quality_pending':True};dump(out/'entry.json',entry);rows=read(R/'manifest.json')if(R/'manifest.json').exists()else[];dump(R/'manifest.json',[e for e in rows if e['sku']!=pid]+[entry]);print('BUILT TOWEL PROTOTYPE',pid,entry['bytes'],flush=True)
if __name__=='__main__':
 for pid in sys.argv[1:]or SPECS:build(pid)
