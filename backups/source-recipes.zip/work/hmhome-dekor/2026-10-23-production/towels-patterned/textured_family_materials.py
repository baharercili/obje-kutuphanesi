"""Same weave geometry family; every dye and fibre pixel comes from its own SKU."""
from pathlib import Path
import json,math,hashlib
import numpy as np
from PIL import Image,ImageFilter
import herringbone_mask as F
B=Path(__file__).resolve().parent;TAU=math.tau;read=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();BOXES=read(B/'native-donor-boxes.json')
IDS={'1338733002','1338733003','1338733006','1338733007','1338735001','1338735002','1338735003','1339545003','1339741001','1339741002','1339741003','1339741006','1339741007'}
def ridge(pid,x,y):
 if pid!='1339545003':return F.relief(x,y)
 # Own small stepped-V weave visibly differs from the broad puffed family.
 # Photo-derived12mm V period and1.1mm elevation remain explicit estimates.
 px=np.asarray(x)/.012;py=np.asarray(y)/.012;step=np.round(abs((px%1)-.5)*4)/4;phase=(py-step)%1;distance=np.minimum(phase,1-phase);return np.exp(-(distance/.20)**4)

def textures(pid,out,w,l,master,illum_radius=4):
 assert pid in IDS;box=[830,620,958,748]if pid=='1338735003'else BOXES[pid]['crop'];im=Image.open(master['path']).convert('RGB');patch=im.crop(box);patch.save(out/'donor-crop-native.png');a=np.asarray(patch,float);smooth=np.asarray(patch.filter(ImageFilter.GaussianBlur(3)),float);lum=smooth.mean(2);base=np.median(a[(lum>np.quantile(lum,.55))&(lum<np.quantile(lum,.90))],0)
 # Only a native small yarn square; macro V/fold shadow must never repeat in albedo.
 choices=[]
 for y in range(0,97,4):
  for x in range(0,97,4):
   field=smooth[y:y+32,x:x+32].mean(2);choices.append((-float(field.std())+.01*float(field.mean()),x,y))
 _,x,y=max(choices);micro=patch.crop((x,y,x+32,y+32));micro.save(out/'own-base-yarn-native32.png');raw=np.asarray(micro,float);detail=raw-np.asarray(micro.filter(ImageFilter.GaussianBlur(.75)),float);n=m=2048;yy,xx=np.indices((m,n));u=xx/(n-1);v=yy/(m-1);grain=detail[yy%32,xx%32];rgb=np.clip(base+grain*.45,0,255);de=np.minimum(v,1-v)*l;dl=np.minimum(u,1-u)*w;band=(de<.035)|(dl<.006);puff=ridge(pid,u*w,v*l);px=u*w/.0022;py=v*l/.0026;cx=(px+.12*np.sin(np.floor(py)*1.7))%1-.5;cy=py%1-.5;radius=np.sqrt((cx/.36)**2+(cy/.43)**2);loop=np.exp(-((radius-1)/.24)**2)*(1-.38*np.exp(-((cy+.35)/.12)**2));height=loop*.00048*(.25+.75*puff)+grain.mean(2)*.000005;height+=(.00075*puff if pid=='1339545003'else 0);height[band]=grain.mean(2)[band]*.000003;dy,dx=np.gradient(height,l/(m-1),w/(n-1));normal=np.stack((-dx,-dy,np.ones_like(dx)),2);normal/=np.linalg.norm(normal,axis=2,keepdims=True);orm=np.zeros((m,n,3),np.uint8);orm[:,:,0]=np.clip((196+59*loop)*(.72+.28*puff)if pid=='1339545003'else 196+59*loop,0,255);orm[:,:,0][band]=250;orm[:,:,1]=245
 for name,pixels in [('albedo',rgb.astype(np.uint8)),('normal',np.clip((normal+1)*127.5,0,255).astype(np.uint8)),('orm',orm)]:Image.fromarray(pixels).save(out/(name+'.png'),optimize=True)
 proof=dict(source_path=master['path'],source_sha256=master['sha256'],source_pixels=master['pixels'],native_crop_pixels=[128,128],native_crop_box=box,native_micro_relative_crop=[x,y,x+32,y+32],unique_own_detail_pixels=[32,32],source_master_unchanged=sha(master['path'])==master['sha256'],no_other_SKU_colour_or_photo_pixels=True,geometry_family_reference=str(B/'herringbone-revision-03/manifest.json')if pid!='1339545003'else'Own small stepped-V morphologic interpretation',own_source_photo_review_file=str(B/'remaining-herringbone-own-photos-and-crops.jpg'),physical_raised_band_height_mm_estimated=1.1 if pid=='1339545003'else 1.7,output_pixels=[n,m],source_upscaled=False,geometric_resampling_count=0,palette_quantization=False,method='Own native yarn residual and dye only. Small stepped V includes0.75mm meso normal to resolve the photographed fine grooves between finite mesh samples. Same physical V-weave geometry family after independent own-photo comparison; no otherSKU photo pixels or donor hue reused. Small burgundy stepped-V is a separate photo-estimated relief.',family_interpretation='HerSKU kendi renk/lif pikselleriyle yorumlandı; ortak V örgü geometrisi, yükselti, kaba ilmek ölçeği ve görünmeyen faz fotoğraf tahminidir.')
 (out/'crop-provenance.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n');cloth=dict(baseColorFactor=[1,1,1,1],baseColorTexture='albedo.png',normalTexture='normal.png',metallicRoughnessTexture='orm.png',normalScale=1.,metallic=1,roughness=1,doubleSided=False,extras=dict(intrinsic_material=True,own_photo_material_crop=True,photo_pixels_baked=True,baked_reflections=False,source_crop_provenance=str(out/'crop-provenance.json'),macro_height_in_geometry=True,terry_loop_relief_scale_mm=[2.2,2.6,.48],loop_relief_photo_interpretation=True))
 for name,value in [('loop-albedo',base),('loop-normal',[128,128,255]),('loop-orm',[255,242,0])]:Image.new('RGB',(128,128),tuple(np.rint(value).astype(int))).save(out/(name+'.png'))
 ribbon={**cloth,'extras':{**cloth['extras'],'photo_pixels_baked':False,'constant_intrinsic_maps_no_artificial_upscale':True},'baseColorTexture':'loop-albedo.png','normalTexture':'loop-normal.png','metallicRoughnessTexture':'loop-orm.png','normalScale':.2};return dict(cloth=cloth,loop=ribbon),proof
