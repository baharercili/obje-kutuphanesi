"""Native own-SKU motifs, masked before a single atlas transform. No hero/background wrap."""
from pathlib import Path
import json,math,hashlib
import numpy as np
from PIL import Image,ImageFilter,ImageDraw,ImageOps
B=Path(__file__).resolve().parent;TAU=math.tau
read=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
PRIMARY=read(B/'primary-image-masters.json');BOXES=read(B/'native-donor-boxes.json')
ART={
 '1339550002':dict(file='1339550002-cb1461a916c2.jpg',box=[320,600,930,1490],family='own printed pine tree with original banner lettering; not embroidery',size=[.78,.75],location=[.50,.54],embroidery=False),
 '1339748001':dict(file='1339748001-c998c3e7bff4.jpg',box=[180,200,1210,1880],family='own black embroidered botanical stems and flowers',size=[.80,.80],location=[.50,.50],embroidery=True),
 '1335587001':dict(file='1335587001-f36090521cd0.jpg',box=[565,1270,1020,1820],family='own embroidered airplane and two white clouds',size=[.38,.28],location=[.68,.77],embroidery=True)}
BORDER={'1339543001','1339543002'};SMALL={'1336965004'}

def motif(pid,out):
 spec=ART[pid];entry=next(e for e in PRIMARY if e['sku']==pid and Path(e['path']).name==spec['file']);im=Image.open(entry['path']).convert('RGB');crop=im.crop(spec['box']);a=np.asarray(crop,float);lum=a.mean(2)
 if pid=='1335587001':
  mask=Image.new('L',crop.size,0);d=ImageDraw.Draw(mask)
  for polygon in [[(32,88),(55,79),(160,102),(244,12),(278,7),(299,22),(294,54),(259,112),(335,151),(359,139),(378,139),(380,164),(404,181),(404,201),(385,213),(275,198),(274,293),(251,333),(231,344),(203,324),(143,185),(31,146),(28,126)],[(40,369),(62,325),(87,328),(108,345),(137,348),(152,369),(145,389),(45,386)],[(162,474),(175,408),(195,388),(192,366),(209,349),(227,343),(254,347),(275,368),(307,375),(333,386),(352,409),(382,430),(411,462),(422,489),(414,511),(377,520),(186,497)]]:d.polygon(polygon,fill=255)
  mask=mask.filter(ImageFilter.GaussianBlur(.55));operations='Own airplane/cloud outlines traced in native pixels, retaining every interior photographic stitch pixel; no reconstructed text or generic artwork.'
 else:
  # All crop pixels are textile, never a wall or staging object. Separate
  # dark dye/stitch from the cream carrier; banner letters remain original pixels.
  alpha=np.clip((190-lum)/45,0,1) if pid=='1339550002' else np.clip((180-lum)/70,0,1)
  mask=Image.fromarray(np.rint(alpha*255).astype(np.uint8));operations='Native luminance ink/stitch mask on an interior fabric-only crop; original branch edges and printed lettering retained.'
 rgba=crop.convert('RGBA');rgba.putalpha(mask);crop.save(out/'motif-crop-native.png');mask.save(out/'motif-native-mask.png');rgba.save(out/'motif-native-rgba.png')
 return rgba,dict(source_path=entry['path'],source_sha256=entry['sha256'],source_pixels=entry['pixels'],crop_box_original_pixels=spec['box'],crop_pixels=list(crop.size),native_crop_pixel_identical=np.array_equal(np.asarray(crop),np.asarray(im)[spec['box'][1]:spec['box'][3],spec['box'][0]:spec['box'][2]]),mask_operations=operations,source_master_unchanged=sha(entry['path'])==entry['sha256'])

def textures(pid,out,w,l,master,illum_radius=4):
 art=pid in ART;box=BOXES[pid]['crop'];native=Image.open(master['path']).convert('RGB').crop(box);native.save(out/'donor-crop-native.png');a=np.asarray(native,float);lum=a.mean(2)
 if pid in BORDER:
  base=np.median(a[(lum>np.quantile(lum,.55))&(lum<np.quantile(lum,.9))],0);ink=np.median(a[lum<np.quantile(lum,.04)],0)
  if pid=='1339543001':
   # Original black frame is outside the clean yarn crop; sample the actual dark line.
   own=np.asarray(Image.open(master['path']).convert('RGB').crop((400,1100,1200,1900)),float);dark=own.mean(2)<85;assert dark.sum()>100;ink=np.median(own[dark],0)
 elif pid in SMALL:
  base=np.median(a[lum>np.quantile(lum,.65)],0);ink=np.median(a[lum<np.quantile(lum,.20)],0)
 else:
  primary=next(e for e in PRIMARY if e['sku']==pid and Path(e['path']).name==ART[pid]['file']);im=Image.open(primary['path']).convert('RGB');clean=[50,100,178,228]if pid=='1339748001'else[250,400,378,528]if pid=='1339550002'else[350,500,478,628];native=im.crop(clean);a=np.asarray(native,float);lum=a.mean(2);base=np.median(a.reshape(-1,3),0);ink=np.median(a[lum<np.quantile(lum,.2)],0);box=clean;master=primary
 # A clean native32px textile residual, repeated at fine physical yarn scale.
 patch=native.crop((48,48,80,80));raw=np.asarray(patch,float);detail=raw-np.asarray(patch.filter(ImageFilter.GaussianBlur(.65)),float);n=1024 if art else 2048;m=2048 if art else 4096;yy,xx=np.indices((m,n));u=xx/(n-1);v=yy/(m-1);micro=detail[yy%32,xx%32];rgb=np.clip(base+micro*.35,0,255);pattern=np.zeros((m,n));mask_art=np.zeros((m,n));proof={}
 if pid in BORDER:
  # Own three short-edge bars and one long-edge frame line; not an all-over repeat.
  de=np.minimum(v,1-v)*l;dl=np.minimum(u,1-u)*w;pattern=np.maximum(np.exp(-((de-.030)/.0013)**4),np.maximum(np.exp(-((de-.042)/.0013)**4),np.exp(-((de-.054)/.0013)**4)));pattern=np.maximum(pattern,np.exp(-((dl-.035)/.0013)**4));rgb=rgb*(1-pattern[:,:,None])+(ink+micro*.25)*pattern[:,:,None]
 if pid in SMALL:
  # Own white/mustard narrow stripes, actual set count3 is geometry, not bow packaging.
  period=.025;stripe=.0042;dist=np.abs(((u*w+.007+period/2)%period)-period/2);pattern=np.clip((stripe/2-dist)*n/w+.5,0,1);rgb=rgb*(1-pattern[:,:,None])+(ink+micro*.30)*pattern[:,:,None]
 if pid=='1335587001':
  blue=np.median(a[lum<np.quantile(lum,.15)],0);white=np.median(a[lum>np.quantile(lum,.80)],0);stripe=((u*w/.015)%1)<.45;rgb=white+micro*.25;rgb[stripe]=blue+micro[stripe]*.25
 if art:
  rgba,proof=motif(pid,out);spec=ART[pid];scaled=ImageOps.contain(rgba,(round(n*spec['size'][0]),round(m*spec['size'][1])),Image.Resampling.LANCZOS);layer=Image.new('RGBA',(n,m),(0,0,0,0));left=round(n*spec['location'][0]-scaled.width/2);top=round(m*spec['location'][1]-scaled.height/2);layer.alpha_composite(scaled,(left,top));arr=np.asarray(layer,float);mask_art=arr[:,:,3]/255;rgb=rgb*(1-mask_art[:,:,None])+arr[:,:,:3]*mask_art[:,:,None];proof.update(final_motif_pixels=list(scaled.size),single_final_geometric_resample=True,linear_magnification=scaled.width/rgba.width,unavoidable_atlas_resampling_disclosed=True,original_banner_letters_not_retyped=True,full_marketing_photo_wrapped=False,background_pixels_baked=False)
 # The same accepted physical terry-loop model; raised embroidery follows its own mask.
 px=u*w/.0022;py=v*l/.0026;cx=(px+.12*np.sin(np.floor(py)*1.7))%1-.5;cy=py%1-.5;radius=np.sqrt((cx/.36)**2+(cy/.43)**2);loop=np.exp(-((radius-1)/.24)**2)*(1-.38*np.exp(-((cy+.35)/.12)**2));grain=micro.mean(2);height=loop*.00048+grain*.000005;emb=art and ART[pid]['embroidery']
 if emb:height=height*(1-mask_art*.8)+mask_art*(.0009+.00006*np.sin(TAU*(xx+yy)/3.2))
 band=(np.minimum(u,1-u)*w<.008)|(np.minimum(v,1-v)*l<.025);height[band]=grain[band]*.000002;dy,dx=np.gradient(height,l/(m-1),w/(n-1));normal=np.stack((-dx,-dy,np.ones_like(dx)),2);normal/=np.linalg.norm(normal,axis=2,keepdims=True);orm=np.zeros((m,n,3),np.uint8);orm[:,:,0]=np.clip(182+73*loop,0,255);orm[:,:,1]=np.clip(242+grain*.10,230,252);orm[:,:,0][band]=250
 if art:
  # One closed cloth mesh: front and plain reverse use separate atlas halves.
  back=np.clip(base+micro*.35,0,255)
  if pid=='1335587001':back=white+micro*.25;back[stripe]=blue+micro[stripe]*.25
  rgb=np.concatenate((rgb,back),axis=1);normal=np.concatenate((normal,normal),axis=1);orm=np.concatenate((orm,orm),axis=1)
 for name,pixels in [('albedo',np.clip(rgb,0,255).astype(np.uint8)),('normal',np.clip((normal+1)*127.5,0,255).astype(np.uint8)),('orm',orm)]:Image.fromarray(pixels).save(out/(name+'.png'),optimize=True)
 proof.update(base_donor_source=master['path'],base_donor_sha256=master['sha256'],base_donor_crop=box,unique_yarn_detail_pixels=[32,32],output_pixels=list(Image.open(out/'albedo.png').size),native_crop_tiled_not_enlarged=True,palette_quantization=False,own_photo_pixels=True,method='Own artwork isolated from textile-only master, one final motif mapping; separate native yarn residual and physical terry-loop normal; no hero/studio background wrapped.',pattern_interpretation='Observed artwork proportions placed on a selected visible folded panel. Unseen full-flat placement/reverse stitch structure and hidden phase are interpreted.'if art else'Own source frame/stripe colours and family; spacing/hidden pattern phase are photo interpretations.')
 (out/'crop-provenance.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n');cloth=dict(baseColorFactor=[1,1,1,1],baseColorTexture='albedo.png',normalTexture='normal.png',metallicRoughnessTexture='orm.png',normalScale=1.,metallic=1,roughness=1,doubleSided=False,extras=dict(intrinsic_material=True,own_photo_material_crop=True,photo_pixels_baked=True,baked_reflections=False,source_crop_provenance=str(out/'crop-provenance.json'),terry_loop_relief_scale_mm=[2.2,2.6,.48],loop_relief_photo_interpretation=True))
 for name,value in [('loop-albedo',base),('loop-normal',[128,128,255]),('loop-orm',[255,242,0])]:Image.new('RGB',(128,128),tuple(np.rint(value).astype(int))).save(out/(name+'.png'))
 ribbon={**cloth,'extras':{**cloth['extras'],'photo_pixels_baked':False,'constant_intrinsic_maps_no_artificial_upscale':True},'baseColorTexture':'loop-albedo.png','normalTexture':'loop-normal.png','metallicRoughnessTexture':'loop-orm.png','normalScale':.2};return dict(cloth=cloth,loop=ribbon),proof
