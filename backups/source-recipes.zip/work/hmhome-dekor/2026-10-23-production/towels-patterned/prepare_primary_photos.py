"""Download only already-observed own-product public CDN URLs, unchanged."""
from pathlib import Path
import json,hashlib,urllib.request,sys
from PIL import Image
P=Path(__file__).resolve().parents[1];R=Path(__file__).resolve().parent
SKUS=sys.argv[1:] or ['1323308001','1336978002','1339550002','1338733001']
def dump(p,d):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
manifest=R/'primary-image-masters.json'
allrows=json.loads(manifest.read_text()) if manifest.exists() else []
for sku in SKUS:
 evidence=P/'root/towels-patterned/source-evidence'/(sku+'.json')
 row=json.loads(evidence.read_text())
 assert row['sku']==sku and row['url']=='https://www2.hm.com/tr_tr/productpage.'+sku+'.html'
 assert sku in row['description']
 seen=set()
 for im in row['images']:
  url=im['url']
  if url in seen:continue
  seen.add(url)
  # This visible primary DOM record contains a styling stool from an overlay.
  # Its own alt and pixels identify it as a different product, never the towel.
  if sku=='1323308001' and '/3a229affe3fadd37666a7224c62826567e267ba2.jpg' in url:continue
  assert url.startswith('https://image.hm.com/assets/hm/') and '.jpg?' in url
  path=R/'originals'/(sku+'-'+hashlib.sha256(url.encode()).hexdigest()[:12]+'.jpg')
  path.parent.mkdir(exist_ok=True)
  if not path.exists():
   with urllib.request.urlopen(url,timeout=45) as response:raw=response.read()
   assert raw[:2]==b'\xff\xd8'
   path.write_bytes(raw)
  with Image.open(path) as image:
   pixels=list(image.size);mode=image.mode;icc=bool(image.info.get('icc_profile'));fmt=image.format
  entry=dict(sku=sku,url=url,alt=im['alt'],path=str(path),sha256=sha(path),pixels=pixels,mode=mode,format=fmt,icc_profile_present=icc,original_bytes_unmodified=True,observed_source_evidence=str(evidence),observed_source_evidence_sha256=sha(evidence))
  allrows=[x for x in allrows if not(x['sku']==sku and x['url']==url)]+[entry]
  dump(manifest,allrows)
 print('OWN PRIMARY PHOTOS',sku,len(seen),flush=True)
