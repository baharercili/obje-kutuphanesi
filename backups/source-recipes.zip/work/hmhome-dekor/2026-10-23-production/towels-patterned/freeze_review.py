"""Own immutable review batch; native/technical QA never implies browser acceptance."""
from pathlib import Path
import json,sys,hashlib,shutil
BASE=Path(__file__).resolve().parent;R=Path(sys.argv[1]).resolve();assert R.is_relative_to(BASE)and R!=BASE and not(R/'FINAL-FROZEN.json').exists();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();es=json.loads((R/'manifest.json').read_text());qa=json.loads((R/'independent-validation.json').read_text());assert qa['valid'];checks={x['sku']:x for x in qa['checks']}
for e in es:
 assert sha(e['glb_path'])==e['sha256']==checks[e['sku']]['sha256'];assert all(sha(q['path'])==q['sha256']for q in e['original_images']);assert e['bytes']<40*1024*1024
 assert all((Path(e['asset_dir'])/(x+'.png')).exists()for x in['on','yan','on-capraz','ustten','arka']);e.update(frozen=True,quality_pending=True,actual_browser_review_passed=False,model_status='ready_for_browser_review',native_renders={x:str(Path(e['asset_dir'])/(x+'.png'))for x in['on','yan','on-capraz','ustten','arka']},independent_validation_file=str(R/'independent-validation.json'))
(R/'manifest.json').write_text(json.dumps(es,ensure_ascii=False,indent=2)+'\n')
for f in BASE.parent.joinpath('softgoods').glob(sys.argv[2]+'-*.jpg'):shutil.copyfile(f,R/f.name)
(R/'FINAL-FROZEN.json').write_text(json.dumps(dict(status='immutable_for_actual_review',models=len(es),manifest_sha256=sha(R/'manifest.json'),immutable_model_GLBS=[dict(path=e['glb_path'],sha256=e['sha256'])for e in es],technical_qa_does_not_imply_browser_acceptance=True),indent=2)+'\n');print('FROZEN',R/'manifest.json',sha(R/'manifest.json'))
