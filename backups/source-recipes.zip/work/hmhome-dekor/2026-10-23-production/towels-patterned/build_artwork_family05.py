"""Exact-SKU folded terry goods; selected flat plans and physical set pieces."""
from pathlib import Path
import copy,hashlib,importlib.util,json,re,sys
import numpy as np
BASE=Path(__file__).resolve().parent;R=BASE/'artwork-family-05';P=BASE.parent;PR=P/'root'
spec=importlib.util.spec_from_file_location('reviewed_terry_family',PR/'towels/build_towels.py');T=importlib.util.module_from_spec(spec);spec.loader.exec_module(T);T.R=R
C=T.C;M=T.M;Exporter=T.Exporter
def read(p):return json.loads(Path(p).read_text())
def dump(p,d):Path(p).parent.mkdir(parents=True,exist_ok=True);Path(p).write_text(json.dumps(d,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
rows=read(BASE/'source-queue-50.json');masters={e['sku']:e for e in read(BASE/'original-image-masters.json')};anchors=read(P/'official-grid-size-anchors-all.json')['products'];research={e['sku']:e for e in read(PR/'textile-primary-research.json')['products']}
from artwork_materials import textures,ART,BORDER,SMALL
TARGETS=set(ART)|BORDER|SMALL
T.textures=textures

def build(sku):
 assert sku in TARGETS
 assert not(R/'FINAL-FROZEN.json').exists(), 'Immutable reviewed batch'

 q=next(e for e in rows if e['sku']==sku);master=masters[sku];anchor=anchors[sku]['anchors'][0];w,l=[v/100 for v in anchor['size_tag_cm']];qty=3 if q['name'].startswith("3'")else 2 if q['name'].startswith("2'")else 1
 size='x'.join(format(v,'g')for v in anchor['size_tag_cm']);id='hm-'+sku+'-'+size+'-folded-'+str(qty)+'piece'
 for f in R.glob('frozen-*-manifest.json'):assert id not in {e['id']for e in read(f)},'Never rebuild frozen masters'
 out=R/'models'/id;out.mkdir(parents=True,exist_ok=True)
 basic,base_checks,repairs,single_dims,extra=T.geometry_for(w,l)
 basic=copy.deepcopy(basic)
 if sku=='1335587001':
  # Own TR PDP specifies two short-end loops, unlike the generic long-edge loop.
  grid,nn,flatUV,_=T.folded_drape(w,l);j=int(np.argmin(abs(flatUV[0,:,1]-.46)));i=int(np.argmin(abs(flatUV[:,0,0]-.5)));oldpin=grid[0,j];source=copy.deepcopy(basic[1]);basic=basic[:1]
  for end in [0,-1]:
   loop=copy.deepcopy(source);loop['positions']=(np.asarray(loop['positions']).reshape(-1,3)+grid[i,end]-oldpin).reshape(-1).tolist();loop['name']='own-PDP-short-end-loop-'+str(end);basic.append(loop)
  pp=np.concatenate([np.asarray(m['positions']).reshape(-1,3)for m in basic]);minimum=pp.min(0);maximum=pp.max(0);centre=np.array([(minimum[0]+maximum[0])/2,minimum[1],(minimum[2]+maximum[2])/2]);single_dims=((maximum-minimum)*100).tolist()
  for m in basic:m['positions']=(np.asarray(m['positions']).reshape(-1,3)-centre).reshape(-1).tolist()
  extra.update(long_edge_hanging_loop=False,short_edge_hanging_loops=2)
 if sku in ART:
  body=basic[0];a=np.asarray(body['positions']).reshape(-1,3);normal=np.asarray(body['normals']).reshape(-1,3);lo=a.min(0);hi=a.max(0);u=(a[:,0]-lo[0])/(hi[0]-lo[0]);v=(a[:,2]-lo[2])/(hi[2]-lo[2]);front=normal[:,1]>=0;atlasu=np.where(front,u*.48+.01,u*.48+.51);body['uvs']=np.stack((atlasu,v),1).reshape(-1).tolist();repairs=repairs+M.ensure_uv_faces(basic)+T.H.ensure_float32_uv(basic);extra.update(artwork_mapping='Own isolated artwork on the selected visible folded panel; plain reverse is a separate UV atlas half. Unseen full-flat placement and reverse stitch phase are interpreted.',front_back_atlas=True)
 step=single_dims[0]/100*1.10;shift=step*(qty-1)/2;meshes=[];groups=[]
 for j in range(qty):
  indices=[]
  for base in basic:
   mesh=copy.deepcopy(base);a=np.asarray(mesh['positions']).reshape(-1,3);a[:,0]+=(j-(qty-1)/2)*step;mesh['positions']=a.reshape(-1).tolist();mesh['name']='piece-'+str(j+1)+'-'+mesh['name'];indices.append(len(meshes));meshes.append(mesh)
  groups.append(indices)
 allpos=np.concatenate([np.asarray(e['positions']).reshape(-1,3)for e in meshes]);dims=((allpos.max(0)-allpos.min(0))*100).tolist()
 materials,provenance=T.textures(sku,out,w,l,master,illum_radius=5);provenance['illumination_separation_radius_native_pixels']=5;dump(out/'crop-provenance.json',provenance)
 r=research[sku];cotton=r['exact_sku_identity_verified']and any(re.search(r'Pamuk\s+100\s*%',s)for s in r['composition_lines']);primary_path=PR/'towels-patterned/source-evidence'/(sku+'.json');primary=read(primary_path)if primary_path.exists()else{};cotton=cotton or ('Pamuk 100%'in primary.get('materials',''));composition='Pamuk %100'if cotton else'Pamuklu havlu kumaşı; lif yüzdeleri teyit edilmedi'
 title=q['name'].translate(str.maketrans({'I':'ı','İ':'i'})).lower();title=('İ'if title[:1]=='i'else title[:1].upper())+title[1:]
 note='Resmî düz kumaş planı her parça için '+size.replace('x','×')+' cm; görünen dış ölçü '+str(qty)+' gerçek parçanın seçilmiş katlanmış pozuna aittir. Kat yarıçapları, 3,8 mm kumaş kalınlığı, ilmek ölçeği ve yerel bordürler kendi fotoğrafından yaklaşık yorumdur; üretici CAD veya taraması değildir.'
 if qty>1:note+=' Tek parça sahnesi dosyada ayrıca bulunur; duvar askısı ve ahşap çubuk ürüne eklenmez.'
 variants=[dict(index=0,label=str(qty)+' gerçek havlu · katlı'),dict(index=1,label='Tek havlu · katlı')]if qty>1 else[]
 photos=[x for x in read(BASE/'primary-image-masters.json')if x['sku']==sku]or[master]
 meta=dict(id=id,sku=sku,brand='H&M Home',name=title+' · '+size.replace('x','×')+' cm',category='Havlular',url=q['url'],dimensions_cm=dims,material_label=composition+' · Kendi motif/dokuma fotoğrafı',estimated_dimensions=True,estimated_fields=['folded_pose_dimensions','cloth_thickness','pile_scale','hem_width'],size_source_kind='official_textile_plan_estimated_folded_pose',source_market='Türkiye',size_source_urls=[q['url'],anchor['category_url']],official_measurements=dict(towel_flat_width_cm=w*100,towel_flat_length_cm=l*100,set_quantity=qty,size_label=anchor['verbatim_size_tag']),set_quantity=qty,single_scene_dimensions_cm=single_dims,scene_variants=variants,default_scene_index=0,scale_note=note,diameter_semantics=note,source_notes=[note]+([ART[sku]['family']]if sku in ART else[]),quality_status='photo_interpretation',quality_label='Katlanmış poz · Kumaş yüzeyi yorumu',quality_note='Kendi SKU’sunun native motif pikselleri, havlu donörü ve metre ölçekli ilmek normali kullanıldı; görünür kat üzerine motif yerleşimi ve görünmeyen düz desen fazı yorumdur. Baskı/nakış sınıfı kendi resmî açıklamasından korunur.',source_images=[dict(url=x['url'],alt=x.get('alt',q['name']))for x in photos],original_image=master['path'],original_image_sha256=master['sha256'],original_images=[{k:x[k]for k in ['path','url','sha256']}for x in photos],source_evidence_files=r['evidence_files']+[anchor['evidence_file']]+([str(primary_path)]if primary_path.exists()else[]),units='metres',up_axis='Y',origin='bottom bounding-box centre',baked_reflections=False,geometry_only_qa=False,**extra)
 dump(out/'model.json',dict(metadata=meta,materials=materials,meshes=meshes));dump(out/'geometry-validation.json',dict(valid=True,closed_material_solids=True,mesh_count=len(meshes),meshes=base_checks*qty,uv_repairs=repairs,actual_set_pieces=qty,single_scene_dimensions_cm=single_dims,flat_plan_separate_from_folded_bounds=True));dump(out/'material-validation.json',dict(valid=True,source_master_unchanged=sha(master['path'])==master['sha256'],no_upscaling=True,provenance=provenance));dump(out/'source-evidence.json',dict(official_grid_size_anchor=anchor,exact_sku_research=r,original_master=master))
 report=Exporter.export_assets(out/'model.json',out,id);glb=out/(id+'.glb');doc,binary=C.read_glb(glb);doc['samplers']=[dict(magFilter=9729,minFilter=9987,wrapS=10497,wrapT=10497)]
 for tex in doc['textures']:tex['sampler']=0
 for material in doc['materials']:
  if material.get('name')=='cloth':material['occlusionTexture']={**material['pbrMetallicRoughness']['metallicRoughnessTexture'],'strength':.65}
 binary=M.embed_tangents(doc,binary)
 if qty>1:
  leaves={n['mesh']:i for i,n in enumerate(doc['nodes'])if 'mesh'in n};default=[leaves[i]for i in range(len(meshes))];single=[]
  for index in groups[0]:
   n=copy.deepcopy(doc['nodes'][leaves[index]]);n['translation']=[shift,0,0];single.append(len(doc['nodes']));doc['nodes'].append(n)
  doc['scenes']=[dict(name=str(qty)+' actual folded guest towels',nodes=default),dict(name='One folded guest towel',nodes=single)];doc['scene']=0
 C.write_glb(glb,doc,binary);report['deliverable_sha256']['glb']=sha(glb);report['glb_bytes']=glb.stat().st_size;dump(Path(report['files']['validation']),report)
 e={**meta,'asset_dir':str(out),'model_path':str(out/'model.json'),'glb_path':str(glb),'sha256':sha(glb),'bytes':glb.stat().st_size,'geometry_validation':str(out/'geometry-validation.json'),'material_validation':str(out/'material-validation.json'),'model_revision':'own-artwork-border-terry-2026-10-24-v1','quality_pending':True};dump(out/'entry.json',e);current=read(R/'manifest.json')if(R/'manifest.json').exists()else[];dump(R/'manifest.json',[x for x in current if x['sku']!=sku]+[e]);print(json.dumps(dict(id=id,bytes=e['bytes'],dimensions_cm=dims)),flush=True)
if __name__=='__main__':
 for sku in ([r['sku']for r in rows]if'--all'in sys.argv else sys.argv[1:]or['1336978003']):build(sku)
