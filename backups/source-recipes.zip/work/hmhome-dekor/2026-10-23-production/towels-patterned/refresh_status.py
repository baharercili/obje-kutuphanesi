from pathlib import Path
import json,hashlib
R=Path(__file__).resolve().parent
read=lambda p:json.loads(Path(p).read_text())
rows=read(R/'source-queue-50.json');masters={x['sku']:x for x in read(R/'original-image-masters.json')};models={}
for p in [R/'frozen-prototypes-01/manifest.json',R/'families-01/manifest.json',R/'families-02/manifest.json',R/'prototype-revision-02/accepted-fringe-01/manifest.json',R/'families-04/manifest.json',R/'artwork-family-05/manifest.json',R/'fringe-colours-material-01/manifest.json',R/'herringbone-revision-03/manifest.json',R/'textured-family-06/manifest.json',R/'textured-family-07/manifest.json']:
 if p.exists():
  for e in read(p):models[e['sku']]={**e,'manifest_path':str(p)}
ACCEPTED={row['sku']for row in rows} # Parent actual review approved all50, 2026-10-24
products=[]
for row in rows:
 pid=row['sku'];e=models.get(pid);master=masters[pid];verified=hashlib.sha256(Path(master['path']).read_bytes()).hexdigest()==master['sha256'];assert verified
 status='root_actual_accepted'if pid in ACCEPTED else'ready_for_actual_review'if e else'queued_own_pattern_geometry'
 products.append(dict(sku=pid,name=row['name'],url=row['url'],status=status,official_card_identity=True,official_flat_anchor_file=str(R.parent/'official-grid-size-anchors-all.json'),immutable_own_photo=master['path'],immutable_own_photo_sha256=master['sha256'],source_master_unchanged=verified,model_manifest=e['manifest_path']if e else None,glb_path=e['glb_path']if e else None,sha256=e['sha256']if e else None,actual_visual_approval=pid in ACCEPTED))
counts={s:sum(x['status']==s for x in products)for s in sorted({x['status']for x in products})};(R/'production-status-50.json').write_text(json.dumps(dict(total_source_SKUs=len(products),counts=counts,products=products,source_identity_limit='Card/PDP exact-SKU identities distinguished; an observed default card size is not an exhaustive selectable size inventory.',technical_QA_does_not_imply_actual_visual_acceptance=True),ensure_ascii=False,indent=2)+'\n');print(counts)
