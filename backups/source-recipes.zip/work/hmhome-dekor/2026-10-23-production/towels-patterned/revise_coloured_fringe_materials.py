from pathlib import Path
import sys,json,copy,hashlib,importlib.util,shutil,math
sys.dont_write_bytecode=True
import numpy as np
from PIL import Image,ImageFilter
BASE=Path(__file__).resolve().parent;R=BASE/'fringe-colours-material-01';P=BASE.parent
s=importlib.util.spec_from_file_location('approved_towel_readonly_colourfix',P/'root/towels/build_towels.py');T=importlib.util.module_from_spec(s);s.loader.exec_module(T)
read=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
assert not(R/'FINAL-FROZEN.json').exists();R.mkdir(exist_ok=True);rows=[]
for e in read(BASE/'fringe-family-03/manifest.json'):
 model=read(e['model_path']);out=R/'models'/e['id'];out.mkdir(parents=True,exist_ok=True)
 for f in Path(e['asset_dir']).glob('*.png'):shutil.copyfile(f,out/f.name)
 cloth=model['materials']['cloth'];prov=read(Path(e['asset_dir'])/'crop-provenance.json');master=Image.open(prov['source_path']).convert('RGB');box=prov['crop_box_original_pixels'];patch=master.crop(box);raw=np.asarray(patch,float);colour=np.median(raw.reshape(-1,3),0);native=patch.crop((48,48,80,80));native.save(out/'own-yarn-only-native32.png');a=np.asarray(native,float);detail=a-np.asarray(native.filter(ImageFilter.GaussianBlur(.7)),float);n,m=2048,4096;yy,xx=np.indices((m,n));tile=detail[yy%32,xx%32];rgb=np.clip(colour+tile*.45,0,255);u=xx/(n-1);v=yy/(m-1);micro=tile.mean(2);ed=np.minimum(v,1-v)*1.4;band=ed<.06;px=u*.7/.0022;py=v*1.4/.0026;cx=(px+.12*np.sin(np.floor(py)*1.7))%1-.5;cy=py%1-.5;rad=np.sqrt((cx/.36)**2+(cy/.43)**2);loop=np.exp(-((rad-1)/.24)**2)*(1-.38*np.exp(-((cy+.35)/.12)**2));h=loop*.00080+micro*.000004;h[band]=micro[band]*.000004;dy,dx=np.gradient(h,1.4/(m-1),.7/(n-1));nn=np.stack([-dx,-dy,np.ones_like(dx)],2);nn/=np.linalg.norm(nn,axis=2,keepdims=True);orm=np.zeros((m,n,3),np.uint8);orm[:,:,0]=np.clip(182+73*loop,0,255);orm[:,:,0][band]=250;orm[:,:,1]=245
 for slot,name,array in [('baseColorTexture','own-clean-albedo.png',rgb.astype(np.uint8)),('normalTexture','own-terry-normal.png',np.clip((nn+1)*127.5,0,255).astype(np.uint8)),('metallicRoughnessTexture','own-terry-orm.png',orm)]:Image.fromarray(array).save(out/name,optimize=True);cloth[slot]=name
 proof={**prov,'native_yarn_crop_relative_pixels':[48,48,80,80],'unique_yarn_detail_pixels':[32,32],'geometric_resampling_count':0,'source_master_unchanged':sha(prov['source_path'])==prov['source_sha256'],'operations':['Own native32px yarn-only crop;0.7px illumination subtraction excludes centimetre-scale donor slubs','Same accepted0.8mm terry-loop normal, no donor fold/scratch repetition','Original approved fringe/body geometry and UV unchanged'],'revision_reason':'Own native comparison caught vertical macro-grain in the pink crop; remove donor macro residual before root actual review.'};dump(out/'crop-provenance.json',proof);cloth['extras']['source_crop_provenance']=str(out/'crop-provenance.json');model['metadata']['material_revision']='own-coloured-terry-native-yarn-cleanup-01';dump(out/'model.json',model);dump(out/'geometry-validation.json',read(e['geometry_validation']));dump(out/'material-validation.json',dict(valid=True,source_master_unchanged=True,provenance=proof,geometry_unchanged=True,uv_unchanged=True));report=T.Exporter.export_assets(out/'model.json',out,e['id']);glb=out/(e['id']+'.glb');d,b=T.C.read_glb(glb)
 for ma in d['materials']:
  if ma['name']=='cloth':ma['occlusionTexture']={**ma['pbrMetallicRoughness']['metallicRoughnessTexture'],'strength':.65}
 b=T.M.embed_tangents(d,b);T.C.write_glb(glb,d,b);new={**e,**model['metadata'],'asset_dir':str(out),'model_path':str(out/'model.json'),'glb_path':str(glb),'sha256':sha(glb),'bytes':glb.stat().st_size,'geometry_validation':str(out/'geometry-validation.json'),'material_validation':str(out/'material-validation.json'),'frozen':False,'quality_pending':True,'actual_browser_review_passed':False};dump(out/'entry.json',new);rows.append(new)
 assert model['meshes']==read(e['model_path'])['meshes'];print('COLOUR MATERIAL FIX',e['sku'],new['bytes'],flush=True)
dump(R/'manifest.json',rows)
