"""Bind official visible grid size tags to exact observed SKU by card order AND name."""
from pathlib import Path
import json,re,unicodedata,collections
R=Path(__file__).resolve().parent;A=R.parent/'2026-10-23-scope-audit'
def norm(s):return re.sub(r'\s+',' ',unicodedata.normalize('NFC',s).casefold().replace('\u0307','').replace('’',"'")).strip()
pending={x['sku']:x for x in json.loads((R/'initial-pending-736.json').read_text())};out={};rejected=[];pages=[]
for f in sorted(A.glob('*-observed.json')):
 d=json.loads(f.read_text());text=d.get('visible_text','')
 if not d.get('grid_exposed')or not text:continue
 cards={}
 for p in d.get('products',[]):
  m=re.search(r'productpage\.(\d{10})\.html',p.get('url',''))
  if not m:continue
  sku=m[1];q=cards.setdefault(sku,dict(url=p['url'],labels=[]))
  q['labels']+=([p['label']]if p.get('label')else[])+[i['alt']for i in p.get('images',[])if i.get('alt')]
 markers=list(re.finditer(r'^FAVORİLERE KAYDET (.+)$',text,re.M))
 if len(cards)!=len(markers):
  rejected.append(dict(file=str(f),reason='Visible marker count and unique ordered exactSKU links differ',unique_skus=len(cards),markers=len(markers)));continue
 page_matches=0
 for i,((sku,q),marker)in enumerate(zip(cards.items(),markers)):
  if norm(marker[1])not in {norm(n)for n in q['labels']}:
   rejected.append(dict(file=str(f),sku=sku,reason='Card order name not identical; binding rejected',marker_name=marker[1],link_names=q['labels']));continue
  prefix=text[markers[i-1].end()if i else 0:marker.start()].rstrip();last=prefix.splitlines()[-1]if prefix else''
  mm=re.fullmatch(r'(\d+(?:[.,]\d+)?)\s*[x×X]\s*(\d+(?:[.,]\d+)?)\s*cm',last.strip())
  if not mm:continue
  dims=[float(v.replace(',','.'))for v in mm.groups()];page_matches+=1
  row=dict(sku=sku,source_url=q['url'],category_url=d['url'],evidence_file=str(f.resolve()),visible_card_order=i,card_name=marker[1],verbatim_size_tag=last.strip(),size_tag_cm=dims,binding='ExactSKU ordered observed card links and identical visible favourite/card name; immediate preceding size label',observed_date=d.get('observed_date'),scope='Official visible default card size; does not enumerate all selectable sizes')
  if sku in pending:out.setdefault(sku,[]).append(row)
 pages.append(dict(file=str(f.resolve()),cards=len(cards),size_tags=page_matches))
bound={sku:dict(sku=sku,name=pending[sku]['name'],category=pending[sku]['category'],anchors=rows,unique_size_tags_cm=[list(a)for a in sorted(set(tuple(x['size_tag_cm'])for x in rows))],conflicting_sizes=len(set(tuple(x['size_tag_cm'])for x in rows))>1)for sku,rows in out.items()}
result=dict(scope_pending_products=736,anchored_pending_products=len(bound),categories=dict(collections.Counter(x['category']for x in bound.values())),conflicting_products=[sku for sku,x in bound.items()if x['conflicting_sizes']],products=bound,pages=pages,rejected_bindings=rejected)
(R/'official-grid-size-anchors-all.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k not in ['products','pages','rejected_bindings']},ensure_ascii=False));print('Rejected bindings:',len(rejected))
