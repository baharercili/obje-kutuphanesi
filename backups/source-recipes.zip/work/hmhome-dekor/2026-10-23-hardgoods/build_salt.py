"""Exact-SKU open porcelain salt cellar with notch, black edge and separate97mm spoon."""
import sys,json,math
from pathlib import Path
sys.dont_write_bytecode=True
import numpy as np
from PIL import Image,ImageDraw,ImageFont
import build_hardgoods as G
R=G.R;B=G.B;T=math.tau;BASE=G.bank

def salt_set():
 pr=[(0,0),(.030,0),(.034,.0005),(.036,.002),(.037,.005),(.037,.041),(.0378,.044),(.0390,.046),(.0392,.0475),(.0385,.048),(.0365,.048),(.0352,.046),(.0346,.043),(.0346,.007),(.032,.004),(0,.004)]
 body=G.lathe('own-open-porcelain-salt-pot-with-real-cavity-floor-and-spoon-notch','ceramic',pr,.048,256)
 for k,(x,y,z)in enumerate(body['_vertices']):
  a=math.atan2(z,x);drop=.011*(.5+.5*math.cos(math.pi*a/.20))if abs(a)<.20 else 0;y-=drop*max(0,(y-.032)/.016);body['_vertices'][k]=(x,y,z)
 body['_uvs']=[(.5-u,1-y/.048)for(u,v),(x,y,z)in zip(body['_uvs'],body['_vertices'])]
 p=[body]
 angles=sorted(set([float(a)for a in np.linspace(.20,T-.20,280)]+[math.pi/2,math.pi,3*math.pi/2]));points=[(.03925*math.cos(a),.0476,.03925*math.sin(a))for a in angles]
 p.append(B.tube('real-black-contrast-porcelain-rim-ending-at-notched-spoon-rest','black',points,.00075,.00075,12,False,guide=[0,1,0]))
 # A real concave spoon bowl, finite wall and solid floor. Its long axis isX.
 bowl=B.lathe('separate-porcelain-spoon-with-real-concave-bowl','plain',[(0,0),(.007,0),(.011,.001),(.013,.003),(.0128,.004),(.0117,.0043),(.0105,.003),(.006,.0016),(0,.0012)],128,False,ellipse=.70)
 handle=B.tube('separate-porcelain-spoon-flat-handle-with-rounded-end','plain',[(.008,.002,0),(.021,.0022,0),(.044,.0024,0),(.066,.0026,0),(.0835,.0027,0)],.0013,.0035,12,False,guide=[0,1,0])
 spoon=[bowl,handle];pos=np.concatenate([g['_vertices']for g in spoon]);xmin,xmax=pos[:,0].min(),pos[:,0].max();scale=.097/(xmax-xmin)
 a=math.radians(12)
 for g in spoon:
  g['_vertices']=[(-.015+x*scale*math.cos(a)-y*math.sin(a),.033+x*scale*math.sin(a)+y*math.cos(a),z)for x,y,z in g['_vertices']];p.append(g)
 return p,['Official explicit size-field cellar height4.8cm and diameter8cm; description rounds the height to5cm and is recorded as a source discrepancy','Real open hollow porcelain pot,4mm base, rounded foot/shoulder and a deep actual spoon-rest cutout','Black contrast rim is a physical open arc with finite end caps, ending at the real notch','Matching separate porcelain spoon has a genuine concave bowl and a flattened rounded handle; complete spoon axial length9.7cm','OwnARTISAN/SALT/QUALITYlettering reconstructed as intrinsic ink; set display envelope and unlabelled spoon width/depth are interpreted'],dict(set_quantity=2,piece_dimensions_cm={'salt_cellar_diameter':8,'salt_cellar_height':4.8,'spoon_axial_length':9.7},source_anomalies=['TRdescription rounds pot height to5cm; explicit Beden field says4.8cm. Model uses the explicit4.8cm field.'],bounds_semantics='Overall bounds describe one pot plus its spoon resting across the notch, not official combined product dimensions.')

def material(pid,key,kind,rgb,rough):
 folder,ma=BASE(pid,key,kind,rgb,rough)
 if kind=='ceramicstamp':
  n=2048;im=Image.new('RGB',(n,n),tuple(rgb));d=ImageDraw.Draw(im)
  font='/System/Library/Fonts/Helvetica.ttc';centre=512
  # Own source shows three simple uppercase lines. Typography is reconstructed, not scanned artwork.
  for text,y,width,height in[('ARTISAN',820,170,95),('SALT',1020,285,290),('QUALITY',1380,190,95)]:
   f=ImageFont.truetype(font,420,index=1 if text=='SALT'else 0);mask=Image.new('L',(2400,700),0);md=ImageDraw.Draw(mask);box=md.textbbox((0,0),text,font=f);md.text((-box[0],-box[1]),text,font=f,fill=255);mask=mask.crop((0,0,box[2]-box[0],box[3]-box[1])).resize((width,height),Image.Resampling.LANCZOS);im.paste((42,40,35),(centre-width//2,y,centre-width//2+width,y+height),mask)
  im.save(folder/ma['baseColorTexture'],optimize=True);ma.update(clearcoat=.33,clearcoatRoughness=.12);ma['extras'].update(own_source_lettering_reconstructed=True,letter_shapes_interpreted=True)
 elif kind=='plain':ma.update(clearcoat=.33,clearcoatRoughness=.12)
 return folder,ma
G.bank=material
parts,_,_=salt_set();pos=np.concatenate([g['_vertices']for g in parts]);dims=[round(float(x),5)for x in(pos.max(0)-pos.min(0))*100]
G.SPECS['1335323001']=dict(name='Kaşıklı ve siyah kenarlı porselen tuzluk',category='Kavanozlar',dims=dims,hwd=[4.8,8,8],official={'salt_cellar_height_cm':[4.8],'salt_cellar_diameter_cm':[8],'spoon_length_cm':[9.7],'description_rounded_height_cm':[5]},label='Porselen %100 · Krem/Siyah',color='Krem/Siyah',build=salt_set,estimated=['overall_set_display_width_cm','overall_set_display_height_cm','spoon_bowl_width_and_depth_cm','local_notch_and_thickness'],url='https://www2.hm.com/tr_tr/productpage.1335323001.html',claim='ExactSKU1335323001: classicporcelainsaltpotwithtextmotif,contrastedgeandmatchingspoon. ExplicitBeden:height4.8cm;diameter8cm;spoonlength9.7cm. Descriptionroundsheightto5cm. Porcelain100%.',materials={'ceramic':('ceramicstamp',[232,224,206],.20),'plain':('plain',[232,224,206],.20),'black':('plain',[32,29,25],.19)},note='Porselen tuzluğun açıkBeden alanındaki4,8cm yüksekliği ve8cm çapı, kaşığın9,7cm eksen boyu korunur. Açıklamadaki5cm yuvarlatılmış ölçü ayrı kaynak farklılığı olarak kaydedildi. Kaşık çentik üzerinde sergilenir; toplam dış zarf ölçüsü resmî set ölçüsü değildir. Kaşık eni/kalınlığı, iç duvar/çentik ve harf biçimleri kendi fotoğrafından yorumlandı.')
if __name__=='__main__':G.build('1335323001')
