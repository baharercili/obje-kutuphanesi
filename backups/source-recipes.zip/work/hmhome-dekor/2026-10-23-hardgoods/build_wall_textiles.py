"""Own-SKU embroidered calendar and printed envelope: real cloth, rings, ribbons and pockets."""
from pathlib import Path
import sys,math,json,hashlib
sys.dont_write_bytecode=True
import numpy as np
from PIL import Image,ImageDraw,ImageFilter
import build_hardgoods as G
R=G.R;B=G.B;T=math.tau;BASE=G.bank

def cloth(name,mat,w,h,zcentre,thick,nx=24,ny=36,front=True):
 v=[];uv=[];f=[]
 for side in[-1,1]:
  for j in range(ny+1):
   y=h*j/ny
   for i in range(nx+1):
    x=w*(i/nx-.5);zz=zcentre+.0007*math.sin(x/w*13+y/h*7)+.00035*math.cos(y/h*17+x/w*8)+side*thick/2;v.append((x,y,zz));u=i/nx;vv=1-j/ny;uv.append((u,vv)if side==1 and front else(.001+.001*u,.001+.001*vv))
 layer=(nx+1)*(ny+1)
 for side in[0,1]:
  for j in range(ny):
   for i in range(nx):a=side*layer+j*(nx+1)+i;b=a+nx+1;f.extend([(a,a+1,b),(a+1,b+1,b)])
 for j in[0,ny]:
  for i in range(nx):a=j*(nx+1)+i;f.extend([(a,a+layer,a+1),(a+1,a+layer,a+layer+1)])
 for i in[0,nx]:
  for j in range(ny):a=j*(nx+1)+i;b=a+nx+1;f.extend([(a,b,a+layer),(b,b+layer,a+layer)])
 return G.raw(name,mat,v,f,uv)

def calendar():
 bodyh=.666;w=.45;parts=[cloth('true-hemmed-wavy-cotton-canvas-with-own24-number-embroidery','front',w,bodyh,0,.0014,36,72)]
 # Edge seams are finite textile ridges, not a white billboard border.
 for sx in[-1,1]:parts.append(B.tube('fine-sewn-side-hem-'+str(sx),'canvas',[(sx*(w/2-.0022),y,.0006+.0007*math.sin(sx*6.5+y/bodyh*7))for y in np.linspace(.001,bodyh-.001,80)],.0011,.0011,7,False,guide=[0,0,1]))
 for yy in[.002,bodyh-.003]:parts.append(B.tube('fine-sewn-horizontal-hem-'+str(yy),'canvas',[(x,yy,.0009+.0007*math.sin(x/w*13+yy/bodyh*7))for x in np.linspace(-w/2+.002,w/2-.002,100)],.0011,.0011,7,False,guide=[0,0,1]))
 for sx in[-1,1]:
  loop=[(sx*.201+.0030*math.sin(a),bodyh+.0155+.0175*math.cos(a),.0003+.0011*math.sin(a))for a in np.linspace(0,T,81,endpoint=False)]
  parts.append(B.tube('real-upper-cotton-hanging-loop-'+str(sx),'canvas',loop,.0029,.0007,8,True,guide=[0,0,1]))
 rings=json.loads((R/'calendar-ring-positions.json').read_text());left,top,right,bottom=236,342,1288,2063
 for number,px,py in rings:
  x=(px-left)/(right-left)*w-w/2;y=bodyh*(1-(py-top)/(bottom-top));r=.0078
  parts.append(B.tube('real-gold-hanging-ring-for-day-'+str(number),'gold',[(x+r*math.cos(a),y+r*math.sin(a),.0033)for a in np.linspace(0,T,65,endpoint=False)],.00055,.00055,8,True,guide=[0,0,1]))
  # Folded finite-width cloth tab passes through the upper part of each metal ring.
  tab=[(x+.0006*math.sin(a),y+.012+.008*math.cos(a),.0015+.0016*math.sin(a))for a in np.linspace(0,T,65,endpoint=False)];parts.append(B.tube('actual-folded-cotton-tab-for-day-'+str(number),'canvas',tab,.0020,.00045,7,True,guide=[0,0,1]))
 return parts,['Official45cm width and70cm total height, including two real upper hanging loops','Own24numbered positions, holiday motifs and embroidery masks reconstructed from exactSKUmaster into intrinsic flat thread colours on woven canvas','Twenty-four separate real gold rings with open centres and actual folded textile attachment tabs; no ring photo baked onto the cloth','Thin physically closed lightly wavy cotton sheet, fine edge hems, blank reverse and interpreted hidden thickness'],dict(actual_metal_ring_count=24,source_pattern_method='Own source masks only; colour replaced by flat thread palette and generated cotton weave. Rings and their shadows removed from albedo and rebuilt physically.',source_pattern_effective_detail_pixels=[1052,1721])

def envelope():
 w=.30;h=.185;parts=[cloth('printed-envelope-front-cotton-panel-with-real-cloth-thickness','front',w,h,.0030,.0008,36,24,True),cloth('plain-cotton-back-panel-leaving-a-real-top-pocket-opening','canvas',w,h,-.0030,.0008,36,24,False)]
 for sx in[-1,1]:parts.append(B.tube('finite-stitched-pocket-side-'+str(sx),'canvas',[(sx*(w/2-.001),y,0)for y in np.linspace(.001,h-.001,70)],.0017,.0037,8,False,guide=[0,0,1]))
 parts.append(B.tube('finite-stitched-pocket-bottom','canvas',[(x,.001,0)for x in np.linspace(-w/2+.001,w/2-.001,100)],.0017,.0037,8,False,guide=[0,0,1]))
 # Closed triangular rear flap, folded against the back; fastener is an interpreted hidden detail.
 vv=[(-.145,h,-.004),(.145,h,-.004),(0,.087,-.0047),(-.145,h,-.0048),(.145,h,-.0048),(0,.087,-.0055)];ff=[(0,1,2),(3,5,4),(0,3,4),(0,4,1),(1,4,5),(1,5,2),(2,5,3),(2,3,0)];parts.append(G.raw('separate-finite-triangular-envelope-fold-over-flap','canvas',vv,ff,[(.001+x,.001+y)for x,y in[(0,0),(.001,0),(.0005,.001),(0,0),(.001,0),(.0005,.001)]]))
 parts.append(B.box('small-rear-hook-and-loop-fastener-photo-interpreted','fastener',.016,.009,.0006,(0,.095,-.0056)))
 # Two genuine hanging ties leave the side seam, matching the source’s left-side placement.
 for k in[0,1]:
  points=[(-.149,.163-k*.008,.0004),(-.165,.161-k*.01,.0002),(-.196,.118-k*.013,.0005),(-.230+k*.034,.067-k*.018,0)]
  parts.append(B.tube('actual-left-hanging-cotton-tie-tail-'+str(k),'canvas',points,.0040,.00045,8,False,guide=[0,0,1]))
 return parts,['Official30×18.5cm pouch body retained; lateral ribbon extension is explicitly an estimated display width','Source-specific festive envelope motif and lettering traced from exactSKUfront onto intrinsic red woven cotton; no marketing background projected','Two separate thin physical textile panels with a real top pocket gap and finite stitched side/bottom seams','Two genuine side ribbons, rear triangular folding flap and a small hook-and-loop fastener; hidden fastener size and depth interpreted'],dict(piece_dimensions_cm={'official_pouch_width':30,'official_pouch_height':18.5},source_pattern_method='Own source print masks re-rendered intrinsically; source RGB lighting/background not copied.',source_pattern_effective_detail_pixels=[1020,620],bounds_semantics='30×18.5cm describes pouch body; side ties project beyond body. Combined display envelope width38.5cm and thickness1cm are estimates.')

def pattern_material(pid,key,kind,color,rough):
 if kind not in['calendar','envelope','canvas','gold','fastener']:return BASE(pid,key,kind,color,rough)
 out=R/'materials'/pid;out.mkdir(parents=True,exist_ok=True);master=next(x for x in json.loads((R/'original-image-masters.json').read_text())if x['sku']==pid);im=Image.open(master['path']).convert('RGB');crop=[236,342,1288,2063]if kind=='calendar'else[280,840,1300,1460]
 if kind in['calendar','envelope']:
  a=np.array(im.crop(crop),dtype=np.float32);hh,ww=a.shape[:2];rr,gg,bb=a.transpose(2,0,1);u=np.arange(ww,dtype=np.float32)[None,:]/ww;v=np.arange(hh,dtype=np.float32)[:,None]/hh;rng=np.random.default_rng(int(pid));weave=np.sin(T*u*ww*.43)*.85+np.sin(T*v*hh*.46)*.85+rng.normal(0,.35,(hh,ww));base=np.array([226,218,198]if kind=='calendar'else[188,0,38],np.float32);rgb=np.broadcast_to(base,(hh,ww,3)).copy();height=weave*.018;rrmap=np.full((hh,ww),rough,np.float32)
  if kind=='calendar':
   red=(rr>gg*1.22)&(rr>bb*1.15)&(gg<195);green=(gg>rr*1.06)&(gg>bb*1.08)&(rr<170);black=(np.maximum.reduce([rr,gg,bb])<130);white=(np.minimum.reduce([rr,gg,bb])>232);pink=(rr>gg*1.10)&(bb>gg*.94)&(rr>185)&(gg<220)
   for num,x,y in json.loads((R/'calendar-ring-positions.json').read_text()):
    yy,xx=np.ogrid[:hh,:ww];disk=(xx-(x-crop[0]))**2+(yy-(y-crop[1]))**2<25**2
    for mask in[red,green,black,white,pink]:mask[disk]=False
   gold=np.zeros((hh,ww),bool)
   # Intrinsic gold embroidery stars confined to their own isolated source patches.
   for x,y in[(586,433),(994,418),(1225,621),(450,737),(966,753),(724,892),(1060,961),(455,1218),(920,1225),(1202,1236),(323,1388),(506,1630),(813,1646),(1142,1696),(317,1811),(791,1977)]:
    x-=crop[0];y-=crop[1];x0=max(0,x-28);x1=min(ww,x+28);y0=max(0,y-28);y1=min(hh,y+28);patch=(rr[y0:y1,x0:x1]>gg[y0:y1,x0:x1]*1.08)&(gg[y0:y1,x0:x1]>bb[y0:y1,x0:x1]*1.16)&(gg[y0:y1,x0:x1]<210);gold[y0:y1,x0:x1]=patch
   # Retain gingerbread’s dark brown thread and the pale cap/letter only in exact motif regions.
   brown=(rr>gg*1.18)&(gg>bb*1.12)&(rr<185)&(gg<145)
   for mask,col in[(red,[126,15,34]),(green,[66,82,49]),(black,[38,43,39]),(white,[239,239,235]),(pink,[223,175,179]),(gold,[167,133,61]),(brown,[142,89,54])]:rgb[mask]=col;height[mask]+=.12
  else:
   white=(gg>100)&(bb>90)&(rr<gg*1.7);green=(gg>rr*.90)&(gg>bb*1.1)&(rr<180)&(gg<190);dark=(rr<130)&(gg<100)&(bb<115)
   # Exact print mask; red base/canvas lighting is replaced with one flat red palette.
   for mask,col in[(white,[232,220,187]),(green,[62,101,70]),(dark,[87,42,42])]:rgb[mask]=col;height[mask]+=.06
  rgb+=weave[:,:,None]*.65
  prov=dict(master=master['path'],master_sha256=master['sha256'],master_unchanged=G.sha(master['path'])==master['sha256'],source_native_crop_box=crop,source_effective_detail_pixels=[ww,hh],output_pixels=[ww,hh],geometric_resampling_count=0,method='Source colour classes isolated as design masks; flat intrinsic thread/print palette on generated cotton weave. Source RGB illumination and background are not copied. Physical metal rings excluded from pattern.',photo_rgb_copied=False);G.dump(out/(key+'-pattern-provenance.json'),prov)
 elif kind in['gold','fastener']:
  hh=ww=512;rgb=np.broadcast_to(np.array(color,np.float32),(hh,ww,3)).copy();height=np.zeros((hh,ww),np.float32);rrmap=np.full((hh,ww),rough,np.float32)
 else:
  hh=ww=512;rng=np.random.default_rng(int(pid));u=np.arange(ww,dtype=np.float32)[None,:]/ww;v=np.arange(hh,dtype=np.float32)[:,None]/hh;weave=np.sin(T*u*219)*.8+np.sin(T*v*231)*.8+rng.normal(0,.3,(hh,ww));rgb=np.broadcast_to(np.array(color,np.float32),(hh,ww,3)).copy()+weave[:,:,None]*.8;height=weave*.025;rrmap=np.full((hh,ww),rough,np.float32)
 dy,dx=np.gradient(height);normal=np.stack([-dx,-dy,np.ones_like(dx)],2);normal/=np.linalg.norm(normal,axis=2,keepdims=True);orm=np.zeros((hh,ww,3),np.uint8);orm[:,:,0]=255;orm[:,:,1]=np.clip(rrmap*255,8,250).astype(np.uint8);orm[:,:,2]=255 if kind=='gold'else 0;name=pid+'-'+key
 # Flip maps once to match y-upUVs; no geometric interpolation or invented photo detail.
 for slot,arr in[('albedo',np.clip(rgb,0,255).astype(np.uint8)),('normal',np.clip((normal+1)*127.5,0,255).astype(np.uint8)),('orm',orm)]:Image.fromarray(arr,'RGB').save(out/(name+'-'+slot+'.png'),optimize=True)
 return out,dict(baseColorFactor=[1,1,1,1],baseColorTexture=name+'-albedo.png',normalTexture=name+'-normal.png',metallicRoughnessTexture=name+'-orm.png',normalScale=.40 if kind=='calendar'else .20,metallic=1,roughness=1,doubleSided=False,alphaMode='OPAQUE',extras=dict(intrinsic_material=True,photo_pixels_baked=False,baked_reflections=False,own_source_pattern_reconstructed=kind in['calendar','envelope'],source_pattern_effective_detail_pixels=[ww,hh],native_resolution=[ww,hh],no_source_photo_upscale=True))
G.bank=pattern_material
G.SPECS['1349905001']=dict(name='24 halkalı işlemeli pamuk yılbaşı takvimi',category='Duvar dekorasyonu',dims=[45,70,.8],hwd=[70,45,None],official={'height_cm':[70],'width_cm':[45]},label='Pamuk %100 · Metal halkalar · Açık bej/Çok renkli',color='Açık bej/Çok renkli',build=calendar,estimated=['depth_cm','canvas_and_hanging_loop_proportions','metal_ring_diameter_cm','canvas_thickness_mm'],url='https://www2.hm.com/fr_fr/productpage.1349905001.html',claim='ExactSKU1349905001: reusable embroidered cotton canvas adventcalendar with24numberedmetalrings andupperhangingloops. Width45cm; height70cm; cotton100%.',materials={'front':('calendar',[226,218,198],.86),'canvas':('canvas',[226,218,198],.88),'gold':('gold',[178,139,64],.23)},note='AynıSKU’nun resmî45×70cm ölçüsü korunur.70cm toplam dış yükseklik olarak yorumlanıp kumaş gövde ve iki üst askıya paylaştırıldı.0,8cm toplam derinlik, yerel halka/askı/kumaş kalınlığı ve gizli arka ayrıntılar fotoğraf yorumudur; resmî derinlik değildir.')
G.SPECS['1350122001']=dict(name='Kırmızı zarf biçimli pamuk saklama kesesi',category='Duvar dekorasyonu',dims=[38.5,18.5,1],hwd=[18.5,30,None],official={'pouch_height_cm':[18.5],'pouch_width_cm':[30]},label='Pamuk %100 · Kırmızı/Çok renkli',color='Kırmızı/Çok renkli',build=envelope,estimated=['overall_width_including_side_ties_cm','depth_cm','tie_length_cm','hidden_rear_flap_fastener_size'],url='https://www2.hm.com/en_ie/productpage.1350122001.html',claim='ExactSKU1350122001: cottoncanvas envelope-shaped storagepouch withprintmotifs, tiesatoneside for hanging andhook-and-loopfastenerattheback. Height18.5cm; width30cm; cotton100%.',materials={'front':('envelope',[188,0,38],.84),'canvas':('canvas',[188,0,38],.86),'fastener':('fastener',[221,212,184],.94)},note='Resmî30×18,5cm ölçüsü yalnız zarf kesesinin gövdesinde korunur. Yan bağcıklar dahil toplam38,5cm genişlik ve1cm derinlik fotoğraf yorumudur; resmî ürün genişliği veya derinliği olarak sunulmaz. Gizli arka kapak/cırt cırt boyutları yorumdur.')
if __name__=='__main__':
 for sku in sys.argv[1:]or['1349905001','1350122001']:G.build(sku)
