"""Compile exact live identities and primary PDP facts without canonical edits."""
from pathlib import Path
import copy,hashlib,json,re,sys
sys.dont_write_bytecode=True
D=Path(__file__).resolve().parent
sys.path.insert(0,str(D))
import parse_pdp_evidence as P

def good(url,alt=''):
 return bool(url)and url.startswith('https://image.hm.com/assets/hm/')and'.jpg'in url and'43382530'not in url and not re.search(r'energy\s*label|energielabel|compliance|household waste',alt or'',re.I)

def own_images(doc):
 result=[]
 for image in doc.get('images',[]):
  for field in ['src','data_src','url']:
   url=image.get(field)
   if good(url,image.get('alt'))and not any(i['url'].split('?')[0]==url.split('?')[0]for i in result):
    result.append(dict(url=url,alt=image.get('alt'),source='normal_live_official_PDP_gallery_DOM',market='DE'if'/de_de/'in doc['url']else'GB',downloaded=False))
 return result

def apply_fact(e,record):
 if record['pdp_identity_verified']:e['pdp_identity_verified']=True
 if record['official_measurements']:
  e.setdefault('official_measurements',{}).update(record['official_measurements']);e['dimensions_source_market']=record['market']
 if record['official_dimension_facts']:e['official_dimension_facts']=list(dict.fromkeys(e.get('official_dimension_facts',[])+record['official_dimension_facts']))
 if record['composition_facts']:e['composition_facts']=record['composition_facts'];e['material_source_market']=record['market']
 if record['colour_verbatim']:e['colour_verbatim']=record['colour_verbatim']
 e.setdefault('pdp_detail_records',[]).append(record)
 e['source_evidence_files']=list(dict.fromkeys(e.get('source_evidence_files',[])+[record['source_evidence_file']]))

def live_record(doc,path):
 market='DE'if'/de_de/'in doc['url']else'GB'
 description=doc.get('description_text','');materials=doc.get('materials_text','')
 normal=[]
 for line in materials.splitlines():
  if line.strip()in ['COMPOSITION','ZUSAMMENSETZUNG']:line='### Composition'if market=='GB'else'### Zusammensetzung'
  elif line.strip().startswith(('MATERIALS IN','ERLÄUTERUNGEN')):line='### Materials explained'
  normal.append(line)
 lines=['Description'if market=='GB'else'Beschreibung']+description.splitlines()+['Materials']+normal
 section=doc['title']+' ('+doc['url']+')\n'+'\n'.join('L%d: %s'%(i,s)for i,s in enumerate(lines))
 record=P.parse(section,path)
 # Materials/care-only captures have no article marker; a prior exact-SKU
 # description capture and the normal live URL retain identity provenance.
 return record

def compile_queue():
 base=json.loads((D/'confirmed-queue.pdp-research-progress-02.json').read_text());rows={e['sku']:copy.deepcopy(e)for e in base}
 # Re-parse targeted size/description windows with the improved unit parser.
 for path in sorted((D/'web-evidence').glob('size-target-*.txt'))+sorted((D/'web-evidence').glob('description-size-target-*.txt')):
  for section in path.read_text().split('--------------------------------------------------------------------------------'):
   record=P.parse(section,path)
   if record:apply_fact(rows[record['sku']],record)
 # The root explicitly selected accordion-v2 as authoritative; old toggled
 # captures are retained as history but do not replace these visible panels.
 for path in sorted(D.glob('root-pdp-*-accordion-v2.json')):
  doc=json.loads(path.read_text());record=live_record(doc,path)
  assert record['sku']==doc['sku']and record['pdp_identity_verified'],(path,record)
  apply_fact(rows[doc['sku']],record)
 for path in sorted(D.glob('root-pdp-*-material-care.json')):
  doc=json.loads(path.read_text());record=live_record(doc,path)
  assert record['composition_facts'],path
  apply_fact(rows[doc['sku']],record)
 # Additional root size captures use independently visible normal UI panels.
 for path in sorted(D.glob('root-pdp-*-size*.json')):
  doc=json.loads(path.read_text());record=live_record(doc,path)
  if record:apply_fact(rows[doc.get('sku',record['sku'])],record)
 # Successful initial six facts were parsed and checked manually from exact
 # official titles/article markers, including component-only dimensions.
 for initial in json.loads((D/'confirmed-queue.batch-01.gallery-update.json').read_text()):
  rows[initial['sku']]['pdp_identity_verified']=True
 galleries={};gallery_proofs={}
 for initial in json.loads((D/'confirmed-queue.batch-01.gallery-update.json').read_text()):
  sku=initial['sku'];galleries[sku]=initial['reference_images'];gallery_proofs[sku]=dict(method='official reader full gallery to product heading',files=initial['source_evidence_files'])
 resolved=json.loads((D/'web-evidence/gallery-resolved-867.json').read_text())+json.loads((D/'web-evidence/gallery-1225622009-resolved.json').read_text())
 for image in resolved:
  sku=image['sku'];url=image['image_url'];assert good(url,image.get('alt')),(sku,url)
  gallery=galleries.setdefault(sku,[])
  if not any(i['url'].split('?')[0]==url.split('?')[0]for i in gallery):gallery.append(dict(url=url,alt=image.get('alt'),source='official_PDP_gallery_anchor',downloaded=False))
  proof=gallery_proofs.setdefault(sku,dict(method='official reader full gallery to product heading',files=[]))
  for field in ['anchor_file','resolution_evidence','resolution_retry_evidence']:
   if image.get(field):proof['files'].append(str(D/'web-evidence'/image[field]))
 # Four cropped windows were explicitly extended to the heading boundary.
 for sku in ['1344530001','1277543002','1235174002']:
  gallery_proofs[sku]['files'].append(str(D/'web-evidence/gallery-extent-repair.txt'))
 for path in sorted(D.glob('root-pdp-*-accordion-v2.json')):
  doc=json.loads(path.read_text());sku=doc['sku']
  if sku not in galleries:
   galleries[sku]=own_images(doc);gallery_proofs[sku]=dict(method='normal UI gallery; responsive duplicate slots deduplicated',files=[str(path)],expected=len(doc['images'])//2)
 for path in sorted(D.glob('root-pdp-*-gallery-hydrated.json')):
  doc=json.loads(path.read_text());sku=doc['sku'];images=own_images(doc)
  assert doc.get('gallery_state',{}).get('expectedVisible')==doc.get('gallery_state',{}).get('actualUnique'),path
  galleries[sku]=images;gallery_proofs[sku]=dict(method=doc.get('method'),files=[str(path)],gallery_state=doc['gallery_state'])
 assert len(galleries)==223,(len(galleries),set(rows)-set(galleries))
 for sku,e in rows.items():
  # A reader error may have serialized the request JSON after its URL. Keep
  # exact official product URLs and mark historical errors only as attempts.
  for record in e.get('pdp_detail_records',[]):
   match=re.search(r'https://www2\.hm\.com/[^"\s)]+?productpage\.\d+\.html',record.get('url',''))
   if match:record['url']=match.group(0)
  gallery=galleries[sku];assert gallery and all(good(i['url'],i.get('alt'))for i in gallery),sku
  e['gallery_images']=gallery;e['gallery_source_proof']=gallery_proofs[sku]
  proof=gallery_proofs[sku]
  e['all_PDP_gallery_complete']=proof.get('expected',len(gallery))==len(gallery)
  assert e['all_PDP_gallery_complete'],(sku,len(gallery),proof)
  e['source_evidence_files']=list(dict.fromkeys(e['source_evidence_files']+proof['files']))
  refs=[i for i in e['reference_images']if good(i['url'],i.get('alt'))]
  for image in gallery:
   if not any(i['url'].split('?')[0]==image['url'].split('?')[0]for i in refs):refs.append(image)
  e['reference_images']=refs
  e['source_research_complete']=True;e['source_research_class']='live official category identities + official exact-SKU PDP descriptions/materials and full visible galleries'
  e['model_status']='pending_model';e['ready_model_variants']=0;e['source_photo_only']=True
  e['model_research_status_note']='Source research is complete; physical modelling, interpretation of unpublished geometry, and model QA are separate stages.'
  e['measurements_research_status']='official dimensional facts recovered'if e.get('official_measurements')or e.get('official_dimension_facts')else'No dimensions found in accessible official text; explicit photo estimation required unless a later primary record supplies them.'
  if sku in ['1316391001','1235174002']:
   path=D/f'root-pdp-{sku}-accordion-v2.json';assert path.exists()
   live=json.loads(path.read_text());assert not re.search(r'\b\d+(?:[.,]\d+)?\s*(?:cm|mm)\b',live['description_text'])
   e['measurements_research_status']='Normal live official PDP publishes no dimensional/Size entry; photo estimation must remain explicit.'
   e['measurement_absence_live_evidence']=str(path)
  if sku in ['1225622002','1225620014']:
   path=D/f'root-pdp-{sku}-accordion-v2.json';assert path.exists()
   e['source_dimension_conflict']=dict(published_total_height_cm=18,published_shade_diameter_cm=22,
    note='Published total height18cm conflicts with photographed proportions. Source figures stay unchanged; a differently proportioned model must label any inferred physical axis as photo interpretation.',evidence=str(path))
  e['material_source_complete']=bool(e.get('composition')or e.get('composition_facts'))
 assert all(e.get('pdp_identity_verified')and e['material_source_complete']for e in rows.values())
 return list(rows.values())

if __name__=='__main__':
 data=compile_queue()
 out=D/(sys.argv[1]if len(sys.argv)>1 else'compiled-research-candidate-223.json');assert not out.exists();out.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
 missing=[e['sku']for e in data if not(e.get('official_measurements')or e.get('official_dimension_facts'))]
 print(json.dumps(dict(path=str(out),sha256=hashlib.sha256(out.read_bytes()).hexdigest(),records=len(data),PDP_identity_verified=223,materials_verified=223,full_visible_galleries=223,gallery_images=sum(len(e['gallery_images'])for e in data),dimension_facts=223-len(missing),missing_dimension_facts=missing)))
