"""Nine remaining exact-source portable/umbrella products, isolated output."""
from pathlib import Path
import sys,json,copy,math,ast
import numpy as np
from PIL import Image,ImageFilter
P=Path(__file__).resolve().parent.parent;sys.path.insert(0,str(P/'lighting-models'))
import build_lighting as L
R=Path('/private/tmp/hm-lighting-20261028/portable-009');S=Path('/private/tmp/hm-lighting-20261028/rechargeable-source-review');R.mkdir(parents=True,exist_ok=True)
if list(R.glob('frozen*manifest*.json')):raise RuntimeError('Frozen output; create another revision.')
IDS=['1304449001','1304449003','1337561001','1337566003','1344517001','1344518001','1344521001','1355495001','1355495002'];T=math.tau
qs={q['sku']:q for q in json.loads((S/'source-facts.json').read_text())};L.sources=lambda:qs;L.R=R;bank0=L.material_bank
qs['1344518001']['official_measurements']=dict(base_diameter_cm=13.5,base_height_cm=23.2,shade_width_cm=34.8,height_cm=36.8,cord_length_cm=160)
qs['1344521001']['official_measurements']=dict(base_height_cm=23.2,shade_width_cm=34.8,height_cm=36.8,cord_length_cm=160)
for s in ['1355495001','1355495002']:qs[s]['official_measurements']=dict(base_diameter_cm=8,shade_diameter_cm=12.8,height_cm=15.4)
registry=[x for s,xx in json.loads((S/'available-masters.json').read_text()).items()if s in IDS for x in xx]
for x in registry:assert L.sha(x['path'])==x['sha256']
L.dump(R/'original-image-masters.json',registry)
# Only pure helpers are reused, so frozen producer top-level code never executes.
for path,names in [(P/'lighting-portable-batch-008/build_portable.py',['closed_lathe','ring','cylinder','rotate','button','rounded_loop','prism_loops','rounded_box','usb_port','stored_usb','info','bank']),(P/'lighting-glass-batch-007/build_glass.py',['natural_profile']),(P/'lighting-geometric-batch-006/build_geometric.py',['eholder'])]:
 tree=ast.parse(path.read_text());exec(compile(ast.Module(body=[x for x in tree.body if isinstance(x,ast.FunctionDef)and x.name in names],type_ignores=[]),'readonly-pure-source-helpers','exec'),globals())
common_bank=bank;RX=np.array([[1,0,0],[0,0,-1],[0,1,0]])
CROPS={'1344517001':dict(code='f8fb90502aec',box=[950,1840,1206,2096],material='stone',repeat=.16),'1344518001':dict(code='a9ed3f965172',box=[350,700,862,1212],material='nonwoven',repeat=.085),'1344521001':dict(code='d8095a0ac630',box=[350,700,862,1212],material='nonwoven',repeat=.085)}

def finite_dome(name,mat,r,yb,hh,wall=.002,n=224):
 a=np.linspace(0,math.pi/2,100);out=[(r*math.cos(t),yb+hh*math.sin(t))for t in a[:-1]]+[(0,yb+hh)];inside=[((r-wall)*math.cos(t),yb+(hh-wall)*math.sin(t))for t in a[:-1]]+[(0,yb+hh-wall)]
 return L.B.lathe(name,mat,out+inside[::-1],n,True)
def fluted_shell(name,mat,profile,count,amplitude,n=256,thickness=.0023):
 # Explicit closed finite shell with smooth fluted outer and matching inner wall.
 p=np.array(profile);inside=p.copy();inside[:,0]=np.maximum(0,p[:,0]-thickness);inside[:,1]-=thickness*.4
 closed=np.vstack([p,inside[::-1]]);verts=[];rings=[];uv=[]
 for k,(r,y)in enumerate(closed):
  if r<1e-8:rings.append([len(verts)]);verts.append((0,y,0));uv.append((0,y/.1));continue
  rr=[]
  for j in range(n):
   a=T*j/n;rad=r-amplitude*(1-math.cos(count*a))*.5*min(1,r/.02);rr.append(len(verts));verts.append((rad*math.cos(a),y,rad*math.sin(a)));uv.append((j/n,y/.1))
  rings.append(rr)
 faces=[]
 for k in range(len(rings)):
  a=rings[k];b=rings[(k+1)%len(rings)]
  if len(a)==len(b)==1:continue
  for j in range(n):
   jj=(j+1)%n
   if len(a)==1:faces.append((a[0],b[jj],b[j]))
   elif len(b)==1:faces.append((a[j],a[jj],b[0]))
   else:faces.extend([(a[j],a[jj],b[j]),(a[jj],b[jj],b[j])])
 used=sorted({i for f in faces for i in f});remap={old:new for new,old in enumerate(used)}
 return L.B.solid(name,mat,[verts[i]for i in used],[tuple(remap[i]for i in f)for f in faces],[uv[i]for i in used],flat=False)

def cap_lamp(q):
 sku=q['sku'];mat='brushed'if sku.endswith('001')else'paint';baseR=.0362;yb=.119
 parts=[closed_lathe('separate-cylindrical-battery-base-with-upper-service-cup',mat,[(0,0),(.0355,0),(baseR,.001),(baseR,.125),(.0347,.125),(.0347,.117),(0,.117)]),cylinder('separate-white-integrated-LED-diffuser-board','diffuser',.0337,.118,.0014),button('separate-front-round-switch','chrome',.0027,0,.025,baseR-.0003)]
 outer=natural_profile([(.0465,.120),(.055,.123),(.060,.130),(.061,.135),(.061,.151),(.0605,.158),(.055,.162),(.048,.168),(.046,.178),(.044,.181),(.036,.183),(0,.183)],150)
 outer[:,0]*=.061/outer[:,0].max();outer[:,1]=.120+(outer[:,1]-.120)*(.183-.120)/(outer[:,1].max()-.120)
 parts.append(fluted_shell('separate-removable-closed-top-fluted-glass-cap','glass',outer,32,.0027,n=320,thickness=.0025))
 for j,a in enumerate([0,T/3,2*T/3]):parts.append(L.move(L.RO.box('separate-interpreted-glass-retaining-tab-'+str(j),'steel',.005,.004,.0015,(0,.122,0)),(.0345*math.cos(a),0,.0345*math.sin(a))))
 parts+=usb_port(0,.020,-baseR);c,le=stored_usb(.6,.042,.058);parts+=c
 note='Kendi resmî toplam yükseklik 18,3 cm ve üst çap 12,2 cm korunmuştur. Çıkarılmış başlığı gösteren kendi fotoğrafı kapalı cam üstü, alt ağız ve metal iç cup/yayıcı diski doğrular. Fotoğrafın oluk ritmine göre yaklaşık 32 oluk fiziksel geometridir; tam arka oluk sayısı, kalınlık, iç tutucu ve bileşen boyları tahmindir. Cam saydamlığı ve rengi fotoğraftan yorumlanmıştır, yansıma fotoğrafı kullanılmaz. Kaynak 2 W, USB-C kablosu dahil; yayımlanmayan kablo boyu 60 cm tahminidir. Kablo, katı kaidenin dışındaki boş alanda bağlantısız sarılıdır.'
 out=info(q,['Own low fluted removable clear/smoky glass cap over a metal cylindrical battery base','Finite closed top, real open lower glass mouth, source white LED plate and upper cup','Separate switch, USB socket and estimated retaining tabs'],['base_diameter_cm','base_height_cm','cap_profile','approximate_32_flutes_from_own_photo','glass_thickness_and_tabs','USB_cable_length_60cm_estimate','detached_stored_cord_pose'],note,official_USB_C_cable_included=True,modelled_USB_cord_length_m=le)
 out['material_overrides']['paint']=('paint',[204,193,170],.22,0);return parts,out

def chrome_pod(q):
 r=.08;yb=.062
 base=[(0,0),(.046,0),(.048,.001),(.048,.012),(.050,.017)]+natural_profile([(.050,.017),(.059,.024),(.073,.031),(.078,.042),(.08,.052),(.08,.0605)],100)[1:].tolist()+[(.0785,.0605),(.0785,.051),(.076,.041),(.071,.033),(.054,.024),(0,.024)]
 base=np.array(base);base[:,0]*=.08/base[:,0].max()
 parts=[closed_lathe('separate-polished-metal-bowl-and-foot','chrome',base,224),finite_dome('separate-chrome-coated-glass-outer-film','chrome',r,yb,.053,.00018),finite_dome('separate-finite-glass-substrate-beneath-chrome-coating','glass',r-.0002,yb,.0528,.0021),cylinder('separate-white-upper-bowl-LED-diffuser','diffuser',.076,.059,.0015),button('separate-front-foot-on-off-switch','chrome',.0025,0,.009,.0479)]
 parts+=usb_port(0,.0085,-.048);c,le=stored_usb(.6,.054,.076);parts+=c
 note='Resmî toplam yükseklik 11,5 cm ve çap 16 cm korunmuştur. Kendi kaynak açıklaması krom kaplı cam başlık ve metal kaide der; ana bileşim cam %50, demir %50’dir. Kendi sökülmüş fotoğrafında beyaz yayıcı ve ayrı üst kubbe görülür. Model krom yüzeyini metal kaplama olarak, altında ayrı sonlu cam duvarla kurar; oda veya fotoğraf yansıması içermez. Orta ek yeri, alt hazne ve kaide fotoğraftan yorumlanmıştır. Kaynak 2 W, USB-C dahil; yayımlanmayan kablo boyu 60 cm ve katı ayak dışındaki sarılı duruşu tahmindir.'
 return parts,info(q,['Own flattened chrome-coated glass cap above a separate polished metal bowl','Own removable cap seam and real white diffuser, finite glass substrate under metallic coating','Separate lower foot, switch and rear USB-C socket'],['component_heights_and_radii','chromium_coating_and_glass_wall_thickness','hidden_glass_retention','USB_cable_length_60cm_estimate','detached_stored_cord_pose'],note,official_USB_C_cable_included=True,modelled_USB_cord_length_m=le)

def amber_rings(q):
 # Four distinct soft volumes and three deep necks measured from own off-state packshot.
 points=[(.052,.006),(.067,.009),(.077,.019),(.080,.029),(.078,.039),(.070,.046),(.059,.050),(.058,.054),(.068,.059),(.077,.068),(.078,.077),(.073,.085),(.063,.090),(.058,.094),(.062,.099),(.073,.106),(.080,.115),(.077,.124),(.067,.130),(.055,.133),(.053,.137),(.057,.141),(.064,.147),(.066,.153),(.064,.159),(.057,.163),(.052,.165)]
 outer=natural_profile(points,240);outer[:,0]*=.08/outer[:,0].max();outer[:,1]=.006+(outer[:,1]-.006)*(.165-.006)/(outer[:,1].max()-.006);inside=outer.copy();inside[:,0]-=.0025;inside[:,1]-=.001
 profile=outer.tolist()+[(0,.165),(0,.1625)]+inside[::-1].tolist()
 parts=[L.B.lathe('separate-amber-glass-four-soft-rings-and-three-necks','glass',profile,224,True),cylinder('separate-thin-metal-battery-foot','chrome',.052,0,.0065),cylinder('separate-internal-off-state-white-LED-board','diffuser',.046,.005,.0015),button('separate-small-foot-on-off-switch','chrome',.0018,0,.0035,.052)];parts+=usb_port(0,.0035,-.052);c,le=stored_usb(.6,.058,.077);parts+=c
 note='Resmî 16 cm çap ve 16,5 cm yükseklik korunmuştur. Kendi kapalı ışık fotoğrafında dört ayrı şişkin cam hacmi ve aralarında üç dar boğaz görülür; kontur kendi renk maskesiyle ayrıca kaydedilmiştir. Sürekli eğri profil bu resmî ankrajlara oturtulmuştur; fotoğraf perspektifi ortografik ölçü değildir. Cam duvarı, küçük metal ayağın boyu, arka USB konumu ve iç LED bağlantısı görünmeyen fotoğraf yorumudur. Kaynak 5 W, USB-C dahil; kablonun yayımlanmayan boyu 60 cm tahminidir. Sarılı kablo katı ayağın dışında, bağlantısız durur.'
 return parts,info(q,['Own amber four-volume sculptural glass form with three deep continuous necks','Soft C2 curved glass profile and separate thin metal foot','Intrinsic amber glass with no lit-photo highlights or source reflection wrap'],['photo_contour_to_official_anchors_mapping','glass_wall_thickness','unseen_rear_USB_location','hidden_LED_board_position','USB_cable_length_60cm_estimate','detached_stored_cord_pose'],note,official_LED_w=5,official_USB_C_cable_included=True,modelled_USB_cord_length_m=le)

def stone(q):
 p=[(.033,.03),(.038,.032),(.038,.037),(.044,.037),(.045,.040),(.045,.046),(.049,.046),(.05,.049),(.05,.055),(.0475,.058),(.0475,.064),(.044,.064),(.044,.071),(.0405,.071),(.0405,.079),(.036,.079),(.036,.088),(.0345,.09),(0,.09),(0,.086),(.031,.086),(.031,.079),(.0355,.075),(.039,.069),(.042,.062),(.045,.054),(.043,.045),(.035,.038),(.031,.034)]
 parts=[L.B.lathe('separate-finite-natural-stone-stepped-upper-shade','stone',p,224,True),cylinder('separate-dark-metal-battery-base','paint',.0328,0,.031),cylinder('separate-hidden-LED-diffuser-disc','diffuser',.0295,.030,.0018),button('separate-gold-front-on-off-button','brass',.0028,0,.014,.0327)];parts+=usb_port(0,.014,-.0328,cap='rubber_white');c,le=stored_usb(.6,.037,.047);parts+=c
 for g in parts:
  if g.get('material')=='stone':g['_uvs']=[((math.atan2(z,x)/T+.5)*T*.05/.32,y/.32)for x,y,z in g['_vertices']]
 note='Kendi resmî en geniş çap 10 cm ve toplam yükseklik 9 cm korunmuştur. Açıklama ve ürün başlığı alabaster derken bileşim üst parçayı marble %100, alt parçayı demir %100 olarak adlandırır. Bu malzeme adı çelişkisi çözülmüş kabul edilmez. Kendi doğal taş yakın planındaki damarlar yerel doğal yüzey kırpımından alınmıştır; tam çevre damar eşleşmesi veya her ürünün aynı olması ileri sürülmez. Basamakların yerel yüksekliği, taş duvarı ve gizli LED bağlantısı fotoğraf yorumudur. Kaynak 2 W ve USB-C dahil; yayımlanmayan kablo boyu 60 cm ve sarılı duruşu tahmindir.'
 out=info(q,['Own stepped white natural-stone upper volume over a dark battery cylinder','Native own veining crop without product edge or cast shadow; explicit alabaster/marble wording discrepancy','Separate gold button, own open translucent USB cap and LED diffuser'],['step_component_dimensions','stone_wall_thickness','alabaster_vs_marble_source_wording_conflict','stone_veining_native_crop_repeat_not_exact_wrap','USB_cable_length_60cm_estimate','detached_stored_cord_pose'],note,official_USB_C_cable_included=True,modelled_USB_cord_length_m=le,quality_label='Malzeme adı kaynakta farklıdır',quality_note='Açıklama alabaster, bileşim marble der; doğal taş türü kesinleştirilememiştir.')
 out['material_overrides'].update(stone=('metal',[234,230,219],.35,0),paint=('paint',[39,34,31],.4,0),brass=('metal',[211,180,111],.22,1));return parts,out

def umbrella(q):
 r=.1736;yb=.232;hh=.1357;t=np.linspace(0,math.pi/2,112);outer=[(r*math.cos(a),yb+hh*math.sin(a))for a in t[:-1]]+[(0,yb+hh)];inner=[((r-.0012)*math.cos(a),yb+(hh-.0012)*math.sin(a))for a in t[:-1]]+[(0,yb+hh-.0012)]
 parts=[cylinder('separate-polyethylene-fabric-covered-cylindrical-base','nonwoven',.0675,0,.232),L.B.lathe('separate-finite-eight-panel-nonwoven-umbrella-shade','nonwoven',outer+inner[::-1],224,True),finite_dome('separate-thin-polystyrene-open-lower-liner','lining',r-.0015,yb,.1345,.0005,192),cylinder('separate-estimated-hidden-central-metal-shade-spine','white',.0025,.230,.137)]
 for j,a in enumerate(np.linspace(0,T,8,endpoint=False)):
  pts=[((r+.0001)*math.cos(t)*math.cos(a),yb+hh*math.sin(t),(r+.0001)*math.cos(t)*math.sin(a))for t in np.linspace(0,math.pi/2,100)]
  parts.append(L.tube('separate-subtle-source-radial-panel-seam-'+str(j),'nonwoven',pts,.0003,8))
 parts+=eholder('E14',.236)
 rr=r*math.sqrt(1-(.017/hh)**2)-.002
 for j,a in enumerate(np.linspace(0,T,3,endpoint=False)):parts.append(L.tube('separate-estimated-inside-shade-spider-'+str(j),'white',[(0,.249,0),(rr*math.cos(a),.249,rr*math.sin(a))],.0008,8))
 # Full official cord stored loosely outside the cylindrical base, avoiding intersections.
 def path(turns):
  a=np.linspace(0,T*turns,1250);rr=np.linspace(.074,.158,len(a));return np.vstack([np.linspace([0,.009,-.0675],[0,.0022,.074],90,endpoint=False),np.c_[rr*np.sin(a),np.full(len(a),.0022),rr*np.cos(a)]])
 # Entry routes around the foot, not through its solid interior.
 def path(turns):
  a=np.linspace(math.pi,math.pi+T*turns,1250);rr=np.linspace(.074,.158,len(a));spiral=np.c_[rr*np.sin(a),np.full(len(a),.0022),rr*np.cos(a)];lead=np.linspace([0,.009,-.0673],spiral[0],50,endpoint=False);return np.vstack([lead,spiral])
 lo,hi=.05,8
 for _ in range(35):
  mid=(lo+hi)/2;pp=path(mid);le=np.linalg.norm(np.diff(pp,axis=0),axis=1).sum()
  if le<1.6:lo=mid
  else:hi=mid
 pp=path((lo+hi)/2);parts.append(L.tube('separate-official-160cm-fabric-cord-in-loose-stored-pose','white_cable',pp.tolist(),.0015,10));pt=pp[700];sw=rounded_box('separate-white-inline-switch-body','white',.032,.010,.016,.001,.004);L.move(sw,(pt[0],0,pt[2]));parts.append(sw);parts.append(L.move(cylinder('separate-raised-white-switch-button','white',.004,.010,.002),(pt[0],0,pt[2])))
 spec=CROPS[q['sku']]
 for g in parts:
  if g.get('material')=='nonwoven' or g.get('_material')=='nonwoven':g['_uvs']=[((math.atan2(z,x)/T+.5)*T*r/(2*spec['repeat']),y/(2*spec['repeat']))for x,y,z in g['_vertices']]
 note='Kendi resmî kaide yüksekliği 23,2 cm, başlık genişliği 34,8 cm, toplam yükseklik 36,8 cm ve kablo boyu 160 cm korunmuştur. '+('Kaide çapı 13,5 cm kendi resmî kaynağında yayımlanır.'if q['sku']=='1344518001'else'Kaide çapı kendi GB kaynağında yayımlanmadığından fotoğraf oranından yaklaşık 13,5 cm tahmindir; başka SKU ölçüsü resmî diye aktarılmamıştır.')+' Kendi yakın plan beyaz buruşuk yüzeyi gösterir; resmî ana bileşim polietilen %60, demir %20, polistiren %20’dir, keten diye yorumlanmaz. Yerel doğal lif/buruşukluk kırpımı, yaklaşık sekiz panel, altı açık sonlu başlık ve ayrı astar kullanılmıştır. Gizli merkez/spider bağlantısı ve panel sayısının arka devamı fotoğraf yorumudur. E14, azami 6 W LED, ampul dahil değildir. Tam kablo katı kaidenin dışına gevşek sarılı pozda konmuştur; bu yerleşim tahmindir.'
 result=info(q,['Own white nonwoven polyethylene umbrella cover with source radial panel seams','Finite open lower shade, separate polystyrene liner, real E14 cup/thread and estimated inner supports','Own cylindrical nonwoven covered base, official160cm cord and separate white inline switch'],['base_diameter_cm_from_own_photo'if q['sku']=='1344521001'else'local_base_wall','shade_depth_rotational_photo_interpretation','eight_panel_count_and_hidden_continuation','hidden_shade_spine_and_spider','nonwoven_native_crop_repeat_scale','detached_stored_160cm_cord_pose'],note,official_integrated_LED_nonreplaceable=False,official_LED_w=None,official_USB_C_cable_included=False,official_socket_type='E14',official_socket_count=1,official_source_max_led_w=6,bulbs_included=False,modelled_mains_cord_length_m=float(np.linalg.norm(np.diff(pp,axis=0),axis=1).sum()))
 result['scale_note_override']=note+' Üretici CAD dosyası değildir; fotoğrafın oda ışığı ve gölgesi malzemeye aktarılmaz.';result['material_overrides'].update(nonwoven=('plastic',[235,233,224],.89,0),lining=('plastic',[231,229,219],.72,0),white_cable=('plastic',[228,227,219],.80,0));return parts,result

def fine_bell(q):
 aa=np.linspace(0,math.pi/2,100);outer=[(.064,.042),(.064,.065),(.064,.089)]+[(.064*math.cos(t),.089+.062*math.sin(t))for t in aa[1:-1]]+[(0,.151)]
 parts=[closed_lathe('separate-low-round-brushed-metal-foot','brushed',[(0,0),(.039,0),(.040,.001),(.040,.0035),(.039,.0045),(0,.0045)]),cylinder('separate-short-metal-post','brushed',.0184,.004,.042),fluted_shell('separate-finite-finely-fluted-domed-glass-bell','glass',outer,120,.00042,n=720,thickness=.0022),cylinder('separate-small-metal-top-finial','chrome',.0052,.1498,.0042),ring('separate-under-shade-white-LED-diffuser','diffuser',.019,.060,.0425,.0017),button('separate-small-foot-front-on-off-switch','chrome',.0016,0,.0024,.04)];parts+=usb_port(0,.0024,-.04);c,le=stored_usb(.6,.045,.060);parts+=c
 note='Kendi resmî alt çap 8 cm, üst çap 12,8 cm ve toplam yükseklik 15,4 cm korunmuştur. Alt çap bütün ürün genişliği olarak kullanılmamıştır. Kendi iki nötr fotoğrafındaki dik yüzey ritmi ön silindir izdüşümüyle ölçüldü: Fourier tepe yaklaşık 120–122 oluk çevresine karşılık gelir; model yaklaşık 120 gerçek ince olukla kurulmuştur. Bu fotoğraf yorumu olup arka yüz oluk sayısı ve kalınlığı üreticiden doğrulanmış değildir. Kısa metal ayak, ince disk ve küçük üst somun ayrı geometridir. Kaynak 2 W, USB-C dahil; yayımlanmayan kablo boyu 60 cm ve katı ayak dışındaki sarılı pozu tahmindir. Arka USB yerleşimi ve iç yayıcı görünmeyen donanım yorumudur.'
 return parts,info(q,['Own finely fluted frosted/coloured glass bell over a short brushed-metal post and foot','Approximate120 physical narrow vertical grooves supported by own native photograph period measurement','Finite glass with open lower mouth, own top finial and separate LED diffuser'],['glass_bell_component_profile','approximate120_flutes_from_own_photo_Fourier','glass_wall_and_groove_relief','hidden_USB_and_LED_board_location','USB_cable_length_60cm_estimate','detached_stored_cord_pose'],note,official_USB_C_cable_included=True,modelled_USB_cord_length_m=le)

def bank(pid,keys,ims,out,overrides=None):
 mats,maps=common_bank(pid,keys,ims,out,overrides)
 if 'glass'in mats:
  clear=pid.startswith('1304449');coated=pid=='1337561001';amber=pid=='1337566003';taupe=pid=='1355495002';col=[239,240,234]if pid=='1304449001'else[173,183,190]if pid=='1304449003'else[188,115,40]if amber else[141,122,99]if taupe else[235,232,216]
  rgb=np.full((8,8,3),col,dtype=np.uint8);path=out/'glass-albedo.png';Image.fromarray(rgb).save(path,optimize=True)
  for rec in maps:
   if rec['material']=='glass'and rec['slot']=='albedo':rec.update(sha256=L.sha(path),native_resolution=[8,8])
  trans=.86 if pid=='1304449001'else .68 if pid=='1304449003'else .10 if amber else .04 if taupe else .02;diff=.04 if clear else .32 if amber else .46
  mats['glass'].update(ior=1.48,thickness=.0023,transmission=trans,attenuationColor=[1,1,1],attenuationDistance=.04,normalScale=0);mats['glass']['extras'].update(diffuse_transmission_factor=diff,no_source_reflection_pixels=True,photo_pixels_baked=False)
 if pid in CROPS:
  spec=CROPS[pid];key=spec['material'];master=next(x for x in ims if spec['code']in x['path']);patch=Image.open(master['path']).convert('RGB').crop(spec['box']);raw=np.array(patch,float);n=raw.shape[0];yy,xx=np.mgrid[-1:1:complex(n),-1:1:complex(n)]
  if key=='stone':
   design=np.c_[np.ones(n*n),xx.ravel(),yy.ravel()];coef=np.linalg.lstsq(design,raw.reshape(-1,3),rcond=None)[0];illum=(design@coef).reshape(n,n,3);rgb=np.clip(raw/np.maximum(illum,1)*np.array([234,230,219]),0,255);height=np.zeros((n,n));rough=np.full((n,n),.35)
  else:
   low=np.array(patch.filter(ImageFilter.GaussianBlur(64)),float);ratio=raw/np.maximum(low,1);rgb=np.clip((1+.75*(ratio-1))*np.array([235,233,224]),0,255);grey=raw.mean(2);blur=np.array(patch.filter(ImageFilter.GaussianBlur(12)),float).mean(2);height=(grey/np.maximum(blur,1)-1)*.00035;rough=np.clip(.89-(ratio.mean(2)-1)*.12,.82,.97)
  def mirror(a):return np.concatenate([np.concatenate([a,a[:,::-1]],1),np.concatenate([a[::-1],a[::-1,::-1]],1)],0)
  rgb=mirror(rgb);height=mirror(height);rough=mirror(rough);dy=(np.roll(height,-1,0)-np.roll(height,1,0))/(2*spec['repeat']/n);dx=(np.roll(height,-1,1)-np.roll(height,1,1))/(2*spec['repeat']/n);normal=np.stack([-dx,-dy,np.ones_like(dx)],2);normal/=np.linalg.norm(normal,axis=2,keepdims=True);orm=np.zeros((2*n,2*n,3),np.uint8);orm[:,:,0]=255;orm[:,:,1]=np.rint(rough*255)
  for slot,a in [('albedo',rgb.astype('uint8')),('normal',np.rint((normal+1)*127.5).astype('uint8')),('orm',orm)]:
   path=out/(key+'-'+slot+'.png');Image.fromarray(a).save(path,optimize=True)
   for rec in maps:
    if rec['material']==key and rec['slot']==slot:rec.update(sha256=L.sha(path),native_resolution=[2*n,2*n])
  patch.save(out/'own-native-material-crop.png');mats[key]['normalScale']=.55 if key=='nonwoven'else 0;mats[key]['extras'].update(photo_pixels_baked=True,native_resolution=[2*n,2*n],source_native_material_crop=True,physical_repeat_m_estimated=spec['repeat']*2,diffuse_transmission_factor=.24 if key=='nonwoven'else .16)
  if key=='stone':mats[key].update(ior=1.52,thickness=.004,transmission=.015)
  L.dump(out/'own-native-material-provenance.json',dict(master=master['path'],master_sha256=master['sha256'],native_crop_box=spec['box'],native_crop_size=[n,n],geometric_resampling_count=0,mirrored_tiling_without_resizing=True,background_or_product_edge=False,colour_and_repeat_scale_estimated=True,material_identity='Own natural stone with alabaster/marble source wording conflict'if key=='stone'else'Own wrinkled polyethylene nonwoven, not cotton/linen weave',illumination_removed='Per-channel least-squares plane; native broad veins retained'if key=='stone'else'Native sigma64 normalization; microfibrils and local wrinkles retained',no_generated_image_pixels=True,full_surface_pattern_match_not_claimed=True))
 return mats,maps
L.BUILD={s:cap_lamp if s.startswith('1304449')else chrome_pod if s=='1337561001'else amber_rings if s=='1337566003'else stone if s=='1344517001'else umbrella if s in['1344518001','1344521001']else fine_bell for s in IDS};L.material_bank=bank
if __name__=='__main__':
 for sku in sys.argv[1:]or IDS:L.build(sku)
