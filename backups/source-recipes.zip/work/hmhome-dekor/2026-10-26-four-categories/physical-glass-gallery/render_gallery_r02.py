"""Read-only actual-GLB Mitsuba3 scalar_rgb glass/absorption diagnostic.
Asset positions/normals/UV/indices and embedded PNGs are copied byte-for-byte;
all render intermediates and scenery live only in this diagnostic directory.
"""
from pathlib import Path
import sys,json,struct,hashlib,io,math,time,argparse,traceback,os
sys.dont_write_bytecode=True
import numpy as np
from PIL import Image,ImageDraw
R=Path(__file__).resolve().parent;P=R.parent;sys.path.insert(0,'/Users/USER/Documents/ChatGPT/Studio/work/bruna-render/runtime')
import mitsuba as mi
mi.set_variant('scalar_rgb');T=mi.ScalarTransform4f
class SampleCounter(mi.Appender):
 def __init__(self):super().__init__();self.bad=0;self.examples=[]
 def append(self,level,text):
  if 'Invalid sample' in text:
   self.bad+=1
   if len(self.examples)<3:self.examples.append(text)
 def log_progress(self,*args,**kwargs):pass
sample_counter=SampleCounter();mi.logger().clear_appenders();mi.logger().add_appender(sample_counter)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def read_glb(path):
 raw=Path(path).read_bytes();magic,version,total=struct.unpack_from('<III',raw);assert magic==0x46546c67 and version==2 and total==len(raw);jl=struct.unpack_from('<I',raw,12)[0];d=json.loads(raw[20:20+jl]);binary=raw[28+jl:]
 def attr(i):
  a=d['accessors'][i];b=d['bufferViews'][a['bufferView']];dt=np.dtype({5126:'<f4',5125:'<u4',5123:'<u2',5121:'u1'}[a['componentType']]);n={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}[a['type']];return np.ndarray((a['count'],n),dtype=dt,buffer=binary,offset=b.get('byteOffset',0)+a.get('byteOffset',0),strides=(b.get('byteStride',dt.itemsize*n),dt.itemsize)).copy()
 return d,binary,attr

def ply(path,p,n,uv,f):
 fields=[('x','<f4'),('y','<f4'),('z','<f4'),('nx','<f4'),('ny','<f4'),('nz','<f4'),('s','<f4'),('t','<f4')];v=np.empty(len(p),dtype=fields);data=np.c_[p,n,uv]
 for i,key in enumerate(v.dtype.names):v[key]=data[:,i]
 faces=np.empty(len(f),dtype=[('n','u1'),('i','<u4',(3,))]);faces['n']=3;faces['i']=f
 head='ply\nformat binary_little_endian 1.0\nelement vertex '+str(len(p))+'\n'+''.join('property float '+key+'\n'for key in v.dtype.names)+'element face '+str(len(f))+'\nproperty list uchar uint vertex_indices\nend_header\n';path.write_bytes(head.encode()+v.tobytes()+faces.tobytes());assert np.array_equal(v['x'],p[:,0])and np.array_equal(v['ny'],n[:,1])and np.array_equal(faces['i'],f)

def srgb_linear(a):return np.where(a<=.04045,a/12.92,((a+.055)/1.055)**2.4)
def bitmap(arr,raw=True):return {'type':'bitmap','bitmap':mi.Bitmap(np.asarray(arr,dtype=np.float32)),'raw':raw,'filter_type':'bilinear','wrap_mode':'repeat'}
def run(e,size,spp):
 import shutil
 assert shutil.disk_usage(R).free>5*1024**3,'Keep5GiBreserve'
 out=R/e['sku'];out.mkdir(exist_ok=False);before=sha(e['glb_path']);assert before==e['sha256'];d,binary,attr=read_glb(e['glb_path']);images=[];maps=[]
 for i,img in enumerate(d['images']):
  assert 'uri'not in img;v=d['bufferViews'][img['bufferView']];b=binary[v.get('byteOffset',0):v.get('byteOffset',0)+v['byteLength']];p=out/('embedded-'+str(i)+'.png');p.write_bytes(b);assert sha(p)==hashlib.sha256(b).hexdigest();images.append(np.asarray(Image.open(io.BytesIO(b)).convert('RGB'))/255.);maps.append(dict(index=i,path=str(p),sha256=sha(p),bytes=len(b),asset_bytes_identical=True))
 def texture(slot):return images[d['textures'][slot['index']]['source']]
 reachable=[];seen=set()
 def visit(i):
  if i in seen:return
  seen.add(i);n=d['nodes'][i];assert not any(k in n for k in ['matrix','translation','rotation','scale']), 'Nonidentity node requires explicit transform mapping'
  if 'mesh' in n:reachable.append(n['mesh'])
  for child in n.get('children',[]):visit(child)
 for node in d['scenes'][0].get('nodes',[]):visit(node)
 assert len(reachable)==len(set(reachable)), 'Instanced node requires explicit instance handling'
 positions=np.concatenate([attr(prim['attributes']['POSITION']) for i in reachable for prim in d['meshes'][i]['primitives']]);lo=positions.min(0);hi=positions.max(0);centre=(lo+hi)/2;span=float((hi-lo).max());stage_scale=span/.45
 scene={'type':'scene','integrator':{'type':'volpath','max_depth':64,'rr_depth':16,'hide_emitters':True},'environment':{'type':'constant','radiance':{'type':'rgb','value':[.65,.65,.65]}}}
 # Neutral clean studio; actual geometry source below is not changed.
 target=centre.tolist();dist=span*2.55;angle=math.radians(ANGLE);rotation=np.array([[math.cos(angle),0,math.sin(angle)],[0,1,0],[-math.sin(angle),0,math.cos(angle)]]);origin=(centre+np.array([math.sin(angle),.09,math.cos(angle)])*dist).tolist()
 scene['sensor']={'type':'perspective','fov':30,'to_world':T.look_at(origin=origin,target=target,up=[0,1,0]),'film':{'type':'hdrfilm','width':size,'height':size,'pixel_format':'rgb','rfilter':{'type':'tent'}},'sampler':{'type':'independent','sample_count':spp}}
 scene['floor']={'type':'rectangle','to_world':T.translate([float(centre[0]),float(lo[1]-.006*stage_scale),float(centre[2])])@T.rotate([1,0,0],-90)@T.scale([1.8*stage_scale,1.8*stage_scale,1]),'bsdf':{'type':'diffuse','reflectance':{'type':'rgb','value':[.86,.86,.86]}}}
 backpos=(centre-np.array([math.sin(angle),0,math.cos(angle)])*.85*stage_scale).tolist();scene['backdrop']={'type':'rectangle','to_world':T.look_at(origin=backpos,target=target,up=[0,1,0])@T.scale([1.5*stage_scale,1.2*stage_scale,1]),'bsdf':{'type':'diffuse','reflectance':{'type':'rgb','value':[.93,.93,.93]}}}
 for i,(pos,scale,power)in enumerate([([-.65,.85,.60],[.40,.55,1],3.0),([.80,.55,.12],[.30,.50,1],1.8),([0,.90,-.30],[.45,.20,1],2.2)]):scene['light'+str(i)]={'type':'rectangle','to_world':T.look_at(origin=(centre+(rotation@np.array(pos))*stage_scale).tolist(),target=target,up=[0,1,0])@T.scale([scale[0]*stage_scale,scale[1]*stage_scale,1]),'emitter':{'type':'area','radiance':{'type':'rgb','value':[power]*3}}}
 for i,(pos,scale,rgb)in enumerate([([-.70,.27,0],[.14,.38,1],[.018]*3),([.72,.28,-.12],[.14,.4,1],[.9]*3),([.8,.28,-.30],[.035,.32,1],[.035]*3),([-.5,0,1.65],[.12,.60,1],[.015]*3),([.15,0,1.65],[.06,.60,1],[.02]*3),([.5,0,1.65],[.15,.60,1],[.015]*3)]):scene['reflection_card'+str(i)]={'type':'rectangle','to_world':T.look_at(origin=(centre+(rotation@np.array(pos))*stage_scale).tolist(),target=target,up=[0,1,0])@T.scale([scale[0]*stage_scale,scale[1]*stage_scale,1]),'bsdf':{'type':'diffuse','reflectance':{'type':'rgb','value':rgb}}}
 bsdfs=[];media=[];material_log=[]
 for i,m in enumerate(d['materials']):
  pbr=m['pbrMetallicRoughness'];factor=np.array(pbr.get('baseColorFactor',[1,1,1,1]));albedo=srgb_linear(texture(pbr['baseColorTexture']))*factor[:3];orm=texture(pbr['metallicRoughnessTexture']);roughfield=orm[:,:,1]*pbr.get('roughnessFactor',1);metalfield=orm[:,:,2]*pbr.get('metallicFactor',1);assert np.ptp(roughfield)<1e-7 and np.ptp(metalfield)<1e-7;rough=float(roughfield.mean());metal=float(metalfield.mean());ext=m.get('extensions',{});medium=None;log=dict(name=m.get('name'),glTF_material_index=i,roughness_from_actual_G_channel=rough,metallic_from_actual_B_channel=metal,vertex_normals_unchanged=True)
  if'KHR_materials_transmission'in ext:
   trans=float(ext['KHR_materials_transmission'].get('transmissionFactor',0));ior=float(ext.get('KHR_materials_ior',{}).get('ior',1.5));vol=ext.get('KHR_materials_volume',{});atten=np.array(vol.get('attenuationColor',[1,1,1]),float);distance=float(vol.get('attenuationDistance',1e30));sigma=-np.log(np.clip(atten,1e-15,1))/distance;render_sigma=np.maximum(sigma,1e-9)
   bs={'type':'roughdielectric','distribution':'ggx','alpha':max(rough*rough,1e-5),'int_ior':ior,'ext_ior':1.,'specular_transmittance':bitmap(albedo*trans)}
   # ConstVolume permits physical unbounded extinction coefficients. Albedo0
   # means pure absorption: sigma_t=sigma_a, sigma_s=0.
   medium=mi.load_dict({'type':'homogeneous','sigma_t':{'type':'constvolume','value':mi.ScalarColor3f(render_sigma.tolist())},'albedo':0.})
   log.update(renderer_BSDF='roughdielectric GGX',alpha=rough*rough,int_ior=ior,ext_ior=1.,specular_transmittance=trans,actual_geometry_wall_m='actual immutable mesh; not normalized to assumed thickness',homogeneous_absorption_sigma_a_per_m=sigma.tolist(),renderer_sigma_a_per_m=render_sigma.tolist(),zero_channel_numerical_floor_per_m=1e-9,numerical_floor_note='Zero extinction triggers NaN in Mitsuba pure absorption; 1e-9/m floor verified by seven bounded controls. Relative transmittance perturbation below 1e-9 per metre; asset unchanged.',sigma_s=[0,0,0],attenuationColor_linear=atten.tolist(),attenuationDistance_m=distance,source_volume_thicknessFactor_not_used_to_replace_actual_mesh_walls=vol.get('thicknessFactor'),true_multiple_refractive_mesh_boundaries=True,actual_baseColor_evaluated_linear=True,BSDF_mapping_limit='roughdielectric interface transmittance uses source transmission times linear baseColor; not a bit-identical glTF BSDF implementation, no approval claim')
  else:bs={'type':'principled','base_color':bitmap(albedo),'roughness':rough,'metallic':metal};log['renderer_BSDF']='principled actual albedo/ORM'
  if'normalTexture'in m:
   raw=texture(m['normalTexture']);nn=raw*2-1;scale=float(m['normalTexture'].get('scale',1));nn=nn.copy();nn[:,:,:2]*=scale;nn/=np.maximum(np.linalg.norm(nn,axis=2,keepdims=True),1e-20);encoded=(nn+1)/2
   # Evaluate glTF normalScale exactly as a shader in memory; the original
   # embedded PNG and vertex-normal arrays remain byte-identical on disk.
   bs={'type':'normalmap','normalmap':bitmap(encoded),'bsdf':bs};log.update(normalScale_evaluated_in_memory=scale,asset_normal_texture_bytes_unchanged=True)
  bsdfs.append(mi.load_dict(bs));media.append(medium);material_log.append(log)
 shapes=[]
 # Generated assets have baked metre-space vertices and identity glTF nodes.
 for n in d.get('nodes',[]):assert not any(k in n for k in['matrix','translation','rotation','scale'])
 for i in reachable:
  m=d['meshes'][i]
  assert len(m['primitives'])==1;p=m['primitives'][0];pos=attr(p['attributes']['POSITION']);norm=attr(p['attributes']['NORMAL']);uv=attr(p['attributes']['TEXCOORD_0']);faces=attr(p['indices']).reshape(-1,3);path=out/('actual-glb-part-'+str(i)+'.ply');ply(path,pos,norm,uv,faces);j=p['material'];shape={'type':'ply','filename':str(path),'face_normals':False,'bsdf':bsdfs[j]}
  if media[j]is not None:shape['interior']=media[j]
  scene['asset_part'+str(i)]=shape;shapes.append(dict(index=i,name=m['name'],material=d['materials'][j].get('name'),PLY_path=str(path),PLY_SHA256=sha(path),positions_SHA256=hashlib.sha256(pos.tobytes()).hexdigest(),normals_SHA256=hashlib.sha256(norm.tobytes()).hexdigest(),UV_SHA256=hashlib.sha256(uv.tobytes()).hexdigest(),indices_SHA256=hashlib.sha256(faces.tobytes()).hexdigest(),copied_actual_accessor_bits=True,vertices=len(pos),triangles=len(faces),glass_medium_attached=media[j]is not None))
 dump(out/'pre-render-mapping-proof.json',dict(sku=e['sku'],GLB_SHA_before=before,actual_GLBarrrays_unchanged=True,selected_scene_index=0,selected_scene_name=d['scenes'][0].get('name'),reachable_node_indices=sorted(seen),reachable_mesh_indices=reachable,excluded_other_scene_mesh_indices=sorted(set(range(len(d['meshes'])))-set(reachable)),scene0_bbox_min=lo.tolist(),scene0_bbox_max=hi.tolist(),embedded_maps=maps,materials=material_log,shapes=shapes,renderer='Mitsuba3.8 scalar_rgb',integrator='volpath max_depth64 rr_depth16',resolution=[size,size],spp=spp,lighting='Neutral studio area emitters, white/black reflection cards, clean diffuse backdrop; all separate from asset',geometry_units='metres, Y up',camera=dict(origin=origin,target=target,fov=30),source_image=e['original_image'],original_source_SHA=e['original_image_sha256'],no_asset_files_written=True))
 sample_counter.bad=0;sample_counter.examples=[]
 print('BUILD_SCENE',e['sku'],len(shapes),'meshes',flush=True);start=time.time();native=mi.load_dict(scene);sensor=native.sensors()[0];film=sensor.film();typeinfo=dict(variant=mi.variant(),variants=mi.variants(),scene_type=str(type(native)),integrator_type=str(type(native.integrator())),sensor_type=str(type(sensor)),film_type=str(type(film)),mi_Float=str(mi.Float),mi_UInt32=str(mi.UInt32),mi_TensorXf=str(mi.TensorXf),result_type=None);print('RUNTIME_TYPES',json.dumps(typeinfo),flush=True)
 attempts=[];render=None
 for mode in ['actual_sensor_object','index0_control']:
  try:
   print('DIRECT_ATTEMPT',mode,flush=True);ret=native.integrator().render(scene=native,sensor=sensor if mode=='actual_sensor_object'else 0,spp=spp,seed=39,develop=False,evaluate=True);print('DIRECT_RETURN_TYPE',str(type(ret)),flush=True);record=dict(mode=mode,render_succeeded=True,result_type=str(type(ret)));typeinfo['result_type']=str(type(ret));attempts.append(record)
   try:
    bm=film.bitmap(raw=False);print('FILM_BITMAP_TYPE',str(type(bm)),flush=True);render=np.asarray(bm);record.update(bitmap_type=str(type(bm)),bitmap_shape=list(render.shape));break
   except Exception as exc:record.update(bitmap_error=str(exc),full_bitmap_trace=traceback.format_exc());print(record['full_bitmap_trace'],flush=True)
  except Exception as exc:
   record=dict(mode=mode,render_succeeded=False,error=str(exc),full_trace=traceback.format_exc());attempts.append(record);print(record['full_trace'],flush=True)
 dump(out/'bounded-direct-sensor-runtime-attempt.json',dict(types=typeinfo,attempts=attempts,resolution=[size,size],spp=spp,no_geometry_normals_or_maps_changes=True,GLB_SHA_before=before,GLB_SHA_after=sha(e['glb_path'])))
 if render is None:raise RuntimeError('Bounded sensor-object and index0 direct render attempts failed; full traces preserved. No further attempts/no install.')
 linear=np.asarray(render);numeric=dict(invalid_sample_warnings=sample_counter.bad,examples=sample_counter.examples,all_pixels_finite=bool(np.isfinite(linear).all()),minimum=float(np.nanmin(linear)),maximum=float(np.nanmax(linear)),mean=float(np.nanmean(linear)));dump(out/'numeric-validity.json',numeric)
 if sample_counter.bad or not numeric['all_pixels_finite']:raise RuntimeError('Numerically invalid render: see numeric-validity.json; no optical verdict')
 mi.util.write_bitmap(str(out/'physical-volume-linear.exr'),linear);mi.util.write_bitmap(str(out/'physical-volume.png'),linear*1.05);assert sha(e['glb_path'])==before;assert sha(e['original_image'])==e['original_image_sha256']
 source=Image.open(e['original_image']).convert('RGB');source.save(out/'source-fixture-native-crop.png');result=dict(sku=e['sku'],GLB_SHA_before=before,GLB_SHA_after=sha(e['glb_path']),asset_unchanged=True,source_original_unchanged=True,renderer='Mitsuba3.8 scalar_rgb volpath',samples_per_pixel=spp,resolution=[size,size],max_depth=64,rr_depth=16,render_seconds=time.time()-start,HDR_path=str(out/'physical-volume-linear.exr'),PNG_path=str(out/'physical-volume.png'),display_linear_exposure_factor=1.05,display_sRGB=True,normalScale_in_memory_shader_equivalent_only=True,no_geometry_normals_UV_maps_or_GLBartefact_modified=True,scattering=False,absorption_from_GLTF_exact_except_documented_1e9_inverse_m_floor=True,numeric_validity=numeric,render_script_SHA256=sha(__file__),root_optical_approval_pending=True,render_camera_yaw_degrees=ANGLE,UI_render_image_not_a_baked_GLTF_texture=True);dump(out/'render-readonly-proof.json',result);print('RENDERED',e['sku'],result['render_seconds'],flush=True);return result
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--size',type=int,default=320);p.add_argument('--spp',type=int,default=32);p.add_argument('--run-dir');p.add_argument('--angle',type=float,default=0);p.add_argument('--manifest',required=True);p.add_argument('skus',nargs='*');args=p.parse_args();ANGLE=args.angle;
 if args.run_dir:R=Path(args.run_dir).resolve();R.mkdir(parents=True,exist_ok=False)
 print('TEMP_LLVM_RUNTIME',os.environ.get('DRJIT_LIBLLVM_PATH'),flush=True);entries=json.loads(Path(args.manifest).read_text());results=[]
 for e in entries:
  if not args.skus or e['sku']in args.skus:results.append(run(e,args.size,args.spp));dump(R/'render-report.json',results)
 # A side-by-side diagnostic sheet; source is only a native crop for display.
 c=Image.new('RGB',(960,560*len(results)),(238,238,238));dr=ImageDraw.Draw(c)
 for k,x in enumerate(results):
  for j,p in enumerate([Path(x['PNG_path']).parent/'source-fixture-native-crop.png',Path(x['PNG_path'])]):
   im=Image.open(p).convert('RGB');im.thumbnail((470,510));c.paste(im,(j*480+(480-im.width)//2,k*560+30));dr.text((j*480+8,k*560+8),x['sku']+(' own source crop'if j==0 else' actual GLB physical volume'),fill='black')
 c.save(R/'own-source-vs-physical-volume.jpg');print('CONTACT',R/'own-source-vs-physical-volume.jpg',flush=True)
