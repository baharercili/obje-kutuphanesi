"""Non-destructive HDR denoise and one JPEG export; original model/render masters stay immutable."""
from pathlib import Path
import argparse,json,sys,hashlib,subprocess,base64
import numpy as np
from PIL import Image,ImageCms
sys.path.insert(0,'/Users/USER/Documents/ChatGPT/Studio/work/bruna-render/runtime')
import mitsuba as mi
mi.set_variant('scalar_rgb')

root=Path(__file__).resolve().parent
site=Path('/Users/USER/Documents/ChatGPT/Studio/sites/zarahome-vazo-kutuphanesi-final-378/ui')
parser=argparse.ArgumentParser();parser.add_argument('--aux-index',required=True);parser.add_argument('--partial',action='store_true');args=parser.parse_args()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def pfm_write(p,a):
    assert a.dtype==np.float32 and a.ndim==3 and a.shape[2]==3 and np.isfinite(a).all()
    p.write_bytes(f'PF\n{a.shape[1]} {a.shape[0]}\n-1.0\n'.encode()+np.flipud(a).astype('<f4').tobytes())
def pfm_read(p):
    with p.open('rb')as f:
        assert f.readline().strip()==b'PF';w,h=map(int,f.readline().split());scale=float(f.readline());assert scale<0
        a=np.flipud(np.frombuffer(f.read(),dtype='<f4').reshape(h,w,3)).copy()
    assert np.isfinite(a).all();return a

sources=json.loads((root/'immutable-six-manifest.json').read_text())
guide_data=json.loads(Path(args.aux_index).read_text())
guides={(g['sku'],g['angle_degrees']):g for g in guide_data['guides']}
derived=root/'derived-r02';derived.mkdir(exist_ok=True)
payload={'schema_version':1,'models':[]};proofs=[]
icc=ImageCms.ImageCmsProfile(ImageCms.createProfile('sRGB')).tobytes()
for e in sources:
    frames=[]
    for angle in [0,90,180,270]:
        input_dir=root/f'gallery-r02-angle-{angle}'/e['sku'];report_file=input_dir/'render-readonly-proof.json'
        guide=guides.get((e['sku'],angle))
        if not report_file.exists()or not guide:
            if args.partial:continue
            raise RuntimeError(f'Missing completed render or guide: {e["sku"]}/{angle}')
        report=json.loads(report_file.read_text())
        assert report['GLB_SHA_before']==report['GLB_SHA_after']==e['sha256']==guide['glb_sha256']
        assert report['numeric_validity']['all_pixels_finite']and report['numeric_validity']['invalid_sample_warnings']==0
        assert guide['finite']and guide['width']==guide['height']==640
        master=Path(report['HDR_path']);master_sha=sha(master)
        base=derived/f'{e["sku"]}-{angle}';proof_path=base.with_suffix('.json');jpeg=base.with_suffix('.jpg')
        alb=Path(guide['albedo_pfm']);nrm=Path(guide['normal_pfm']);guide_shas={'albedo':sha(alb),'normal':sha(nrm)}
        if proof_path.exists():
            proof=json.loads(proof_path.read_text());assert proof['input_master_sha256']==master_sha and proof['guide_shas']==guide_shas and sha(jpeg)==proof['JPEG_sha256']
        else:
            linear=np.asarray(mi.Bitmap(str(master)),dtype=np.float32);assert linear.shape==(640,640,3)and np.isfinite(linear).all()
            color=base.with_suffix('.input.pfm');filtered=base.with_suffix('.denoised.pfm');pfm_write(color,linear)
            command=['/private/tmp/hm-oidn-runtime/oidn-2.5.1.arm64.macos/bin/oidnDenoise','-d','cpu','--hdr',str(color),'--alb',str(alb),'--nrm',str(nrm),'-o',str(filtered),'-q','high','--threads','4','--affinity','0','--maxmem','512','-v','0']
            result=subprocess.run(command,check=True,capture_output=True,text=True,timeout=60)
            base.with_suffix('.denoise.log').write_text(result.stdout+result.stderr)
            clean=pfm_read(filtered);assert clean.shape==linear.shape
            png=base.with_suffix('.png');mi.util.write_bitmap(str(png),clean*report['display_linear_exposure_factor'],write_async=False)
            with Image.open(png)as im:
                assert im.size==(640,640);im.convert('RGB').save(jpeg,quality=93,subsampling=0,optimize=True,progressive=True,icc_profile=icc)
            assert sha(master)==master_sha
            proof={'sku':e['sku'],'angle_degrees':angle,'GLB_sha256':e['sha256'],'scene_index':0,'input_master':str(master),'input_master_sha256':master_sha,'input_master_preserved':True,'guide_shas':guide_shas,'normal_guide':str(nrm),'albedo_guide':str(alb),'operation':'OIDN2.5.1 CPU HDR RT high with same-pose first-hit albedo and shading-normal guides; display exposure from immutable render receipt; one final JPEG export','no_model_geometry_or_PBR_changes':True,'no_image_resizing':True,'dimensions':[640,640],'original_bit_depth':'float32 linear HDR master retained','display_colour_space':'sRGB JPEG with embedded profile','render_receipt':str(report_file),'render_receipt_sha256':sha(report_file),'display_PNG_sha256':sha(png),'JPEG_sha256':sha(jpeg),'HDR_denoise_mean_absolute_change':float(np.abs(clean-linear).mean())}
            dump(proof_path,proof)
        frames.append({'angle_degrees':angle,'image':'data:image/jpeg;base64,'+base64.b64encode(jpeg.read_bytes()).decode(),'image_sha256':sha(jpeg)})
        proofs.append(str(proof_path));print('DISPLAY_READY',e['sku'],angle,flush=True)
    if len(frames)==4:payload['models'].append({'id':e['id'],'sku':e['sku'],'name':e['name'],'glb_sha256':e['sha256'],'scene_index':0,'views':frames})
dump(root/'gallery-display-proof-index.json',{'models':len(payload['models']),'derived_frames':len(proofs),'proofs':proofs,'all_master_GLTFs_unchanged':True,'status':'pending_root_visual_review'})
if not args.partial:
    assert len(payload['models'])==6 and len(proofs)==24
    encoded=json.dumps(payload,ensure_ascii=False,separators=(',',':'))+'\n';assert len(encoded.encode())<12*1024*1024
    target=site/'physical-glass-renders.json';temporary=target.with_suffix('.json.tmp');temporary.write_text(encoded);temporary.replace(target)
    print('GALLERY_PAYLOAD',len(payload['models']),len(encoded.encode()),sha(target),flush=True)
