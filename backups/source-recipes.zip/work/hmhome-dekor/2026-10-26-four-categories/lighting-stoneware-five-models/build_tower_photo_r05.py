"""Separate photo-proportioned tower; official width conflict stays explicit."""
from pathlib import Path
import json,sys,hashlib
sys.dont_write_bytecode=True
import build_stoneware_five as M
R=Path(__file__).resolve().parent;L=M.L
M.REV='r05'
M.S['1360551003'].update(w=.055,d=.049)
original_house=M.house
def geometry(s):
 if s['kind']!='tower':return original_house(s)
 p=[];bw=.050;bd=.044;bh=.096;th=s['th'];rows=[0,.032,.064,bh];centres=[.0175,.0495,.0815]
 for axis,z in [('front',bd/2),('left',-bw/2),('right',bw/2),('back',-bd/2)]:
  ww=bw if axis in['front','back']else bd;wins={(j,0):('arch',.0125,.0205,0,y)for j,y in enumerate(centres)}
  p+=M.wall_tiles(axis+'-photo-tower',ww,bh,z,th,[-ww/2,ww/2],rows,wins,axis)
  for j,y in enumerate(centres):p+=M.mullions(axis+'-'+str(j),0,y,.0125,.0205,z,axis)
 p+=M.house_corners('photo-tower-lower',bw,bd,0,bh,th)
 p.append(M.rounded_block('source-photo-proportioned-projecting-cornice',.055,.0084,.049,(0,.1002,0),radius=.0018))
 uw,ud,uy,uh=.037,.035,.1044,.0236
 for axis,z in [('front',ud/2),('left',-uw/2),('right',uw/2),('back',-ud/2)]:
  ww=uw if axis in['front','back']else ud;p+=M.wall_tiles(axis+'-photo-belfry',ww,uh,z,th,[-ww/2,ww/2],[uy,uy+uh],{(0,0):('arch',.0118,.018,0,.116)},axis)
 p+=M.house_corners('photo-upper-belfry',uw,ud,uy,uy+uh,th)
 p.append(M.roof_shell('own-source-steep-tower-roof',.041,.041,.128,.042));p.append(M.rounded_block('closed-source-tower-tip',.0015,.001,.0015,(0,.1695,0),radius=.00025))
 for x,z in[(-.020,-.020),(.020,-.020),(-.020,.020),(.020,.020)]:p.append(L.tube('source-soft-pyramid-ridge-'+str(x)+'-'+str(z),'ceramic',[(x,.128,z),(0,.169,0)],.00055,10))
 p.append(M.rounded_block('separate-ABS-bottom-battery-housing',.040,.0018,.035,(0,.001,0),mat='plastic',radius=.001));p+=M.hidden_light(.012,.004)
 return p
M.house=geometry
if __name__=='__main__':
 M.build('1360551003');out=R/'candidate-r05/1360551003';e=json.loads((out/'entry.json').read_text());model=json.loads((out/'model.json').read_text());meta=model['metadata'];meta['scale_note']+=' Ölçü çatışması: resmî Height17cm ve Width7,5cm aynen kayıtlıdır. Ürünün kendi önden fotoğrafında tepe-taban1115px, azami saçak eni360px, gövde eni335px yaklaşık oranları görülür. Fotoğraf silüeti için H17cm ankrajı korunup ön azami en5,5cm ve derinlik4,9cm tahmin uygulanmıştır; bunlar resmî genişliğin karşılığı olarak sunulmaz.7,5cm etiketinin hangi eksen/bileşeni anlattığı doğrulanmamıştır. Resmî genişliği uygulayan r04 ayrı korunur.'
 meta.update(source_dimension_conflict=True,official_width_not_applied_to_photo_front=True,source_front_pixel_anchors=dict(top_y=405,bottom_y=1520,cornice_width=360,body_width=335,display_image_width=1280,source_master='1360551003-b03c23e817eb.jpg'),estimated_front_width_cm=5.5,estimated_depth_cm=4.9)
 meta['estimated_fields']+=['front_width_conflicts_with_official_width','source_pixel_ratio_measurements']
 M.dump(out/'model.json',model);doc,binary=L.read_glb(e['glb_path']);doc['extras']['metadata']=meta;L.write_glb(e['glb_path'],doc,binary);e.update(meta,sha256=M.sha(e['glb_path']),bytes=Path(e['glb_path']).stat().st_size);M.dump(out/'entry.json',e);M.dump(R/'native-tower-photo-r05.json',[e]);rows=json.loads((R/'manifest.json').read_text());M.dump(R/'manifest.json',[x for x in rows if x['sku']!=e['sku']]+[e]);report=out/(e['id']+'.validation.json');r=json.loads(report.read_text());r['source_sha256']=M.sha(out/'model.json');r['deliverable_sha256']['glb']=e['sha256'];r['glb_bytes']=e['bytes'];M.dump(report,r);print('TOWER_PHOTO',e['sha256'],flush=True)
