"""Five exact-source light-up ceramics; own output only, no catalogue writes.

Openings are real analytic finite-wall geometry, never dark texture decals.
Dimensions not published by the exact PDP remain labelled interpretations.
"""
from pathlib import Path
import sys,json,math,hashlib,datetime
sys.dont_write_bytecode=True
import numpy as np
from PIL import Image,ImageFilter
R=Path(__file__).resolve().parent;P=R.parent
sys.path.insert(0,str(P/'lighting-models'))
import build_lighting as L
B,G=L.B,L.G;T=math.tau;REV='r04'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,x):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
Q={x['sku']:x for x in json.loads((R/'source-records.json').read_text())}
MASTERS=json.loads((R/'original-image-masters.json').read_text())
S={
 '1357623001':dict(kind='cone',h=.13,w=.073,d=.073,rows=[.13,.30,.455,.61,.765],counts=[20,16,12,8,4],large=.0035,small=.00165,th=.0022,token='7c0a56fc87a3',crop=[760,1730,824,1794],rgb=[236,233,220],name='Küçük delikli stoneware ışıklı ağaç · 13 cm'),
 '1357624001':dict(kind='cone',h=.195,w=.11,d=.11,rows=[.105,.265,.425,.585,.74,.85],counts=[24,20,16,12,8,6],large=.0046,small=.0020,th=.0025,token='533a948ed896',crop=[760,1730,824,1794],rgb=[237,233,220],name='Büyük delikli stoneware ışıklı ağaç · 19,5 cm'),
 '1360551001':dict(kind='mansard',h=.17,w=.075,d=.065,th=.0022,token='a0bb8ff3de0c',crop=[730,2480,794,2544],rgb=[237,233,220],name='Üç katlı çatılı stoneware ışıklı ev · 17 cm'),
 '1360551003':dict(kind='tower',h=.17,w=.075,d=.065,th=.0022,token='b03c23e817eb',crop=[1230,2430,1294,2494],rgb=[238,234,221],name='Kule çatılı stoneware ışıklı ev · 17 cm'),
 '1360552001':dict(kind='wide',h=.12,w=.17,d=.070,th=.0025,token='8140d12a6d49',crop=[1670,2470,1734,2534],rgb=[237,233,220],name='İki bacalı geniş stoneware ışıklı ev · 17 cm'),
}
def triangulate_loops(name,mat,loops,flat=False):
 n=len(loops[0]);assert all(len(x)==n for x in loops);v=[p for ring in loops for p in ring];f=[]
 for k in range(len(loops)):
  for j in range(n):
   a=k*n+j;b=k*n+(j+1)%n;c=((k+1)%len(loops))*n+j;d=((k+1)%len(loops))*n+(j+1)%n
   f.extend([(a,b,c),(b,d,c)])
 return B.solid(name,mat,v,f,[(x/.025,y/.025)for x,y,z in v],flat=flat)
def rect_bound(a,x0,x1,y0,y1):
 c,s=math.cos(a),math.sin(a)
 t=min((x1 if c>=0 else -x0)/max(abs(c),1e-14),(y1 if s>=0 else -y0)/max(abs(s),1e-14))
 return(t*c,t*s)
def arch_contains(x,y,w,h):
 # Lower rectangle with a true semicircular upper arch.
 r=w/2;cy=h/2-r
 return abs(x)<=r and y>=-h/2 and (y<=cy or x*x+(y-cy)**2<=r*r)
def rounded_contains(x,y,w,h,r):
 return max(abs(x)-(w/2-r),0)**2+max(abs(y)-(h/2-r),0)**2<=r*r
def hole_loop(shape,w,h,n=64):
 aa=list(np.linspace(0,T,n,endpoint=False))
 # Cardinal and rectangle-corner directions preserve straight opening sides.
 aa +=[math.atan2(y,x)%T for x in[-w/2,w/2]for y in[-h/2,h/2]]
 aa=sorted(set(round(float(a),12)for a in aa));out=[]
 for a in aa:
  c,s=math.cos(a),math.sin(a)
  if shape=='circle':rad=w/2
  else:
   lo,hi=0.,max(w,h)
   for _ in range(42):
    m=(lo+hi)/2;inside=arch_contains(m*c,m*s,w,h)if shape=='arch'else rounded_contains(m*c,m*s,w,h,min(w,h)*.19)
    if inside:lo=m
    else:hi=m
   rad=(lo+hi)/2
  out.append((a,rad*c,rad*s))
 return out
def frame_cell(name,bounds,centre,hole,mapper,mat='ceramic',bevel=.00045):
 """Closed finite wall tile with one real rounded aperture and bore bevel."""
 x0,x1,y0,y1=bounds;cx,cy=centre;shape,w,h=hole
 hh=hole_loop(shape,w,h);aa=sorted(set([a for a,x,y in hh]+[math.atan2(y-cy,x-cx)%T for x in[x0,x1]for y in[y0,y1]]))
 aa=[a for i,a in enumerate(aa)if i==0 or a-aa[i-1]>1e-9]
 inner=[];outer=[]
 for a in aa:
  c,s=math.cos(a),math.sin(a);lo,hi=0.,max(w,h)
  for _ in range(42):
   m=(lo+hi)/2
   ok=(m<=w/2)if shape=='circle'else(arch_contains(m*c,m*s,w,h)if shape=='arch'else rounded_contains(m*c,m*s,w,h,min(w,h)*.19))
   if ok:lo=m
   else:hi=m
  rad=(lo+hi)/2;inner.append((cx+rad*c,cy+rad*s));ox,oy=rect_bound(a,x0-cx,x1-cx,y0-cy,y1-cy);outer.append((cx+ox,cy+oy))
 loops=[]
 for which,depth,expand in [('outer',0,0),('inner',0,bevel),('inner',.20,0),('inner',.80,0),('inner',1,bevel),('outer',1,0)]:
  pts=outer if which=='outer'else[(x+expand*math.cos(a),y+expand*math.sin(a))for(x,y),a in zip(inner,aa)]
  loops.append([tuple(mapper(x,y,depth))for x,y in pts])
 return triangulate_loops(name,mat,loops)
def shaped_aperture(name,contains,centre,hole,mapper,maxrad=.2):
 cx,cy=centre;shape,w,h=hole;inner=[];outer=[];angles=[]
 for a,xx,yy in hole_loop(shape,w,h,128):
  c,s=math.cos(a),math.sin(a);lo,hi=0.,maxrad
  for _ in range(48):
   r=(lo+hi)/2
   if contains(cx+r*c,cy+r*s):lo=r
   else:hi=r
  angles.append(a);outer.append((cx+lo*c,cy+lo*s));inner.append((cx+xx,cy+yy))
 loops=[]
 for which,t,ex in [('outer',0,0),('inner',0,.0004),('inner',.2,0),('inner',.8,0),('inner',1,.0004),('outer',1,0)]:
  pts=outer if which=='outer'else[(x+ex*math.cos(a),y+ex*math.sin(a))for(x,y),a in zip(inner,angles)]
  loops.append([mapper(x,y,t)for x,y in pts])
 return triangulate_loops(name,'ceramic',loops)
def cone_radius(y,s):return max(0,s['w']/2*(1-y/s['h'])+.00045*math.sin(math.pi*y/s['h']))
def cones(s):
 parts=[];h=s['h'];rb=s['w']/2;ys=[v*h for v in s['rows']];edges=[.0015]+[(a+b)/2 for a,b in zip(ys,ys[1:])]+[h-.010]
 for row,(yc,n)in enumerate(zip(ys,s['counts'])):
  rc=cone_radius(yc,s);pitch=T/n;phase=(row%2)*pitch*.5
  big=min(s['large'],rc*.32);small=min(s['small'],big*.55);delta=(big-small)/2
  for j in range(n):
   a=phase+j*pitch;rr=big if j%2==0 else small;left=(-pitch/2-(delta/rc if j%2==0 else -delta/rc))*rc;right=-left
   def mapper(x,y,depth,a=a,rc=rc):
    theta=a+x/rc;r=cone_radius(y,s)-s['th']*depth;return(r*math.sin(theta),y,r*math.cos(theta))
   parts.append(frame_cell('row-%d-real-round-perforation-%02d'%(row+1,j+1),(left,right,edges[row],edges[row+1]),(0,yc),('circle',rr*2,rr*2),mapper,bevel=min(.0005,rr*.16)))
 # Rounded finite tip and turned lower rim are separate ceramic solids.
 y=edges[-1];rt=cone_radius(y,s)
 parts.append(L.lathe('rounded-closed-ceramic-cone-tip','ceramic',[(0,y),(rt,y),(cone_radius(h-.004,s),h-.004),(.0009,h-.001),(.00035,h),(0,h)],160))
 parts.append(B.lathe('finite-rounded-bottom-ceramic-rim','ceramic',[(rb-.001,0),(rb-.0002,.0006),(cone_radius(.0015,s),.0015),(cone_radius(.0015,s)-s['th'],.0015),(rb-s['th'],.0004),(rb-s['th']-.0003,0)],192,True))
 parts.append(L.lathe('separate-ABS-battery-base','plastic',[(0,.0001),(rb-.0032,.0001),(rb-.0032,.0017),(0,.0017)],160))
 parts +=hidden_light(rb*.65,.005)
 return parts
def hidden_light(r,y):
 return[L.lathe('interpreted-hidden-ABS-battery-cover-no-cell-claim','plastic',[(0,y),(r,y),(r,y+.002),(0,y+.002)],96),L.lathe('interpreted-unpowered-integral-LED-diffuser','diffuser',[(0,y+.002),(.003,y+.002),(.0032,y+.005),(.001,y+.006),(0,y+.006)],64)]
def transform_panel(g,axis,offset):
 if axis=='front':g['_vertices']=[(x,y,z+offset)for x,y,z in g['_vertices']]
 elif axis=='back':g['_vertices']=[(-x,y,-z+offset)for x,y,z in g['_vertices']]
 elif axis=='left':g['_vertices']=[(-z+offset,y,x)for x,y,z in g['_vertices']]
 else:g['_vertices']=[(z+offset,y,-x)for x,y,z in g['_vertices']]
 return g
def wall_tiles(prefix,w,h,z,th,columns,rows,windows,axis='front'):
 parts=[]
 for j,(y0,y1)in enumerate(zip(rows,rows[1:])):
  for i,(x0,x1)in enumerate(zip(columns,columns[1:])):
   if i==0:x0+=.002
   if i==len(columns)-2:x1-=.002
   if(j,i)in windows:
    shape,hw,hh,cx,cy=windows[(j,i)];g=frame_cell(prefix+'-real-'+shape+'-opening-%d-%d'%(j,i),(x0,x1,y0,y1),(cx,cy),(shape,hw,hh),lambda x,y,t:(x,y,-t*th))
    parts.append(transform_panel(g,axis,z))
    # Source ceramic moulding is visibly raised and softly rounded around
    # each opening; this physical lip is separate from the true wall bore.
    path=[]
    for a,xx,yy in hole_loop(shape,hw+.0016,hh+.0016,80):path.append((cx+xx,cy+yy,.00025))
    trim=L.tube(prefix+'-rounded-raised-opening-lip-%d-%d'%(j,i),'ceramic',path,.00065,10,True)
    parts.append(transform_panel(trim,axis,z))
   else:parts.append(transform_panel(L.RO.box(prefix+'-solid-wall-tile-%d-%d'%(j,i),'ceramic',x1-x0,y1-y0,th,((x0+x1)/2,(y0+y1)/2,-th/2)),axis,z))
 return parts
def mullions(prefix,x,y,w,h,z,axis,arch=True):
 parts=[];bar=.0016
 # Only the lower pane is split vertically; the arch remains open above transom.
 cy=y+h/2-w/2;bottom=y-h/2
 if arch:
  bars=[(x,cy,w+.0008,bar),(x,(bottom+cy)/2,bar,cy-bottom+.0005)]
 else:bars=[(x,y,w+.0008,bar),(x,y,bar,h+.0008)]
 for j,(xx,yy,ww,hh)in enumerate(bars):parts.append(transform_panel(rounded_block(prefix+'-separate-rounded-physical-mullion-'+str(j),ww,hh,.0021,(xx,yy,.0002),radius=.0003),axis,z))
 return parts
def house_corners(prefix,w,d,y0,y1,th):
 parts=[];r=.002;ri=max(.0005,r-th);segments=20
 for sx,sz,a0 in[(1,1,0),(-1,1,math.pi/2),(-1,-1,math.pi),(1,-1,math.pi*1.5)]:
  cx=sx*(w/2-r);cz=sz*(d/2-r);arc=np.linspace(a0,a0+math.pi/2,segments+1);poly=[(cx+r*math.cos(a),cz+r*math.sin(a))for a in arc]+[(cx+ri*math.cos(a),cz+ri*math.sin(a))for a in arc[::-1]];n=len(poly);v=[(x,y,z)for y in[y0,y1]for x,z in poly];f=[]
  for j in range(n):a=j;b=(j+1)%n;f.extend([(a,b,a+n),(b,b+n,a+n)])
  # Polygon is a thin curved strip; end caps triangulate through paired arcs.
  m=segments+1
  for k in[0,1]:
   off=k*n
   for j in range(segments):a=off+j;b=off+j+1;c=off+n-1-j;dd=off+n-2-j;f.extend([(a,b,c),(b,dd,c)])
  parts.append(B.solid(prefix+'-rounded-exterior-corner-'+str(sx)+'-'+str(sz),'ceramic',v,f,[(x/.025,y/.025)for x,y,z in v]))
 return parts
def rounded_block(name,w,h,d,centre,mat='ceramic',radius=.0015):
 n=64;v=[];f=[];uv=[];cx,cy,cz=centre
 for yy,inset in [(-h/2,radius*.45),(-h/2+radius,0),(h/2-radius,0),(h/2,radius*.45)]:
  for j in range(n):
   a=T*j/n;r=radius;hw=w/2-inset;hd=d/2-inset;x=math.copysign(hw-r,math.cos(a))+r*math.cos(a);z=math.copysign(hd-r,math.sin(a))+r*math.sin(a);v.append((cx+x,cy+yy,cz+z));uv.append((x/.025,z/.025))
 for k in range(3):
  for j in range(n):a=k*n+j;b=k*n+(j+1)%n;c=(k+1)*n+j;dd=(k+1)*n+(j+1)%n;f.extend([(a,b,c),(b,dd,c)])
 for k,yy in[(0,-h/2),(3,h/2)]:
  c=len(v);v.append((cx,cy+yy,cz));uv.append((.5,.5))
  for j in range(n):f.append((c,k*n+j,k*n+(j+1)%n))
 return B.solid(name,mat,v,f,uv)
def roof_shell(name,w,d,y,h,kind='pyramid'):
 # Hollow finite ceramic roof. Hip slopes are physical surfaces, no painted roof.
 rings=[];n=4
 if kind=='pyramid':spec=[(w,d,y),(max(.001,w*.02),max(.001,d*.02),y+h),(max(.0005,w*.02-.0004),max(.0005,d*.02-.0004),y+h-.0015),(w-.004,d-.004,y+.001)]
 else:spec=[(w,d,y),(w*.78,d*.30,y+h),(w*.78-.003,d*.30-.003,y+h-.002),(w-.004,d-.004,y+.001)]
 for ww,dd,yy in spec:rings.append([(-ww/2,yy,-dd/2),(ww/2,yy,-dd/2),(ww/2,yy,dd/2),(-ww/2,yy,dd/2)])
 return triangulate_loops(name,'ceramic',rings,flat=True)
def wide_eave(x):return .079+.018*math.exp(-(x/.024)**2)
def wide_curved_roof():
 rings=[];n=256
 for w,d,y,inner in[(.167,.068,.079,False),(.167*.78,.068*.30,.109,False),(.167*.78-.003,.068*.30-.003,.107,True),(.163,.064,.080,True)]:
  ring=[]
  for j in range(n):
   a=T*j/n;x,z=rect_bound(a,-w/2,w/2,-d/2,d/2);yy=y
   if abs(z-d/2)<1e-9 and y<.09:yy=wide_eave(x)+(0 if not inner else .0006)
   ring.append((x,yy,z))
  rings.append(ring)
 return triangulate_loops('own-continuous-wavy-front-hipped-roof','ceramic',rings)
def house(s):
 kind=s['kind'];parts=[];w,d,h,th=s['w'],s['d'],s['h'],s['th']
 if kind=='tower':
  bw=.066;bh=.108;bd=.058;row=[0,.036,.071,bh];cols=[-bw/2,bw/2]
  for axis,z in [('front',bd/2),('left',-bw/2),('right',bw/2),('back',-bd/2)]:
   ww=bw if axis in['front','back']else bd;wins={};cc=[-ww/2,ww/2]
   for j,yy in enumerate([.020,.054,.088]):wins[(j,0)]=('arch',.0175,.026,0,yy)
   parts+=wall_tiles(axis+'-tower',ww,bh,z,th,cc,row,wins,axis)
   for j,yy in enumerate([.020,.054,.088]):parts+=mullions(axis+'-'+str(j),0,yy,.0175,.026,z,axis)
  parts.append(rounded_block('source-projecting-cornice',w,.010,d,(0,.112,0),radius=.002))
  uw,ud,uy,uh=.050,.047,.117,.025
  parts+=house_corners('lower-tower',bw,bd,0,bh,th)+house_corners('upper-belfry',uw,ud,uy,uy+uh,th)
  for axis,z in [('front',ud/2),('left',-uw/2),('right',uw/2),('back',-ud/2)]:
   ww=uw if axis in['front','back']else ud
   parts+=wall_tiles(axis+'-belfry',ww,uh,z,th,[-ww/2,ww/2],[uy,uy+uh],{(0,0):('arch',.0175,.019,0,uy+.012)},axis)
  parts.append(roof_shell('own-tower-pointed-four-sided-roof',.061,.057,.141,.029));parts.append(rounded_block('closed-finite-tower-roof-tip',.0015,.001,.0015,(0,.1695,0),radius=.00025))
 elif kind=='mansard':
  bw=.069;bd=.058;bh=.122;cols=[-bw/2,-.0115,.0115,bw/2];rows=[0,.041,.080,bh]
  parts+=house_corners('three-story-house',bw,bd,0,bh,th)
  wins={}
  for j,yy in enumerate([.021,.061,.101]):
   for i,xx in enumerate([-.023,0,.023]):wins[(j,i)]=('rect'if i==0 or(j==0 and i==1)else'arch',.016,.028 if(j,i)!=(0,2)else .035,xx,yy)
  for axis,z in [('front',bd/2),('back',-bd/2)]:
   parts+=wall_tiles(axis+'-three-story',bw,bh,z,th,cols,rows,wins,axis)
   for(j,i),(shape,ww,hh,xx,yy)in wins.items():
    if(j,i)!=(0,2):parts+=mullions(axis+'-'+str(j)+'-'+str(i),xx,yy,ww,hh,z,axis,shape=='arch')
  for axis,z in [('left',-bw/2),('right',bw/2)]:
   wins2={(j,0):('arch',.017,.028,0,yy)for j,yy in enumerate([.021,.061,.101])}
   parts+=wall_tiles(axis+'-side',bd,bh,z,th,[-bd/2,bd/2],rows,wins2,axis)
   for j,yy in enumerate([.021,.061,.101]):parts+=mullions(axis+'-'+str(j),0,yy,.017,.028,z,axis)
  parts.append(rounded_block('source-eaves-projecting-cornice',w,.005,d,(0,.123,0),radius=.0015));parts.append(roof_shell('own-hipped-mansard-roof',.073,.062,.125,.034,'hip'))
  parts.append(rounded_block('closed-finite-hipped-roof-ridge',.073*.78,.001,.062*.30,(0,.1585,0),radius=.0004))
  parts.append(rounded_block('own-right-chimney-shaft',.010,.012,.011,(.021,.162,0),radius=.0012));parts.append(rounded_block('own-right-chimney-rounded-cap',.012,.004,.013,(.021,.168,0),radius=.0012))
  # Separate triangular front dormer with a real rounded opening and roof lips.
  dg=shaped_aperture('own-triangular-front-dormer-real-rounded-window',lambda x,y:abs(x)<=.014 and y>=.128 and y<=.164-.036*abs(x)/.014,(0,.140),('rect',.006,.011),lambda x,y,t:(x-.018,y,.0305-t*th));parts.append(dg)
  for xsign in[-1,1]:parts.append(L.tube('own-dormer-sloped-rounded-roof-lip-'+str(xsign),'ceramic',[(-.018+xsign*.014,.128,.032),(-.018,.164,.032)],.0017,12))
 else:
  bw=.158;bd=.061;bh=.075;cols=list(np.linspace(-bw/2,bw/2,6));rows=[0,.038,.075];wins={}
  parts+=house_corners('wide-house',bw,bd,0,bh,th)
  xs=[-.060,-.030,0,.030,.060]
  for j,yy in enumerate([.020,.057]):
   for i,xx in enumerate(xs):wins[(j,i)]=('arch',.016 if(j,i)!=(0,2)else .018,.024 if(j,i)!=(0,2)else .026,xx,yy)
  for axis,z in [('front',bd/2),('back',-bd/2)]:
   parts+=wall_tiles(axis+'-wide-house',bw,bh,z,th,cols,rows,wins,axis)
   for(j,i),(shape,ww,hh,xx,yy)in wins.items():
    if(j,i)!=(0,2):parts+=mullions(axis+'-'+str(j)+'-'+str(i),xx,yy,ww,hh,z,axis)
  for axis,z in [('left',-bw/2),('right',bw/2)]:
   sidewins={(j,0):('arch',.016,.024,0,yy)for j,yy in enumerate([.020,.057])};parts+=wall_tiles(axis+'-wide-side',bd,bh,z,th,[-bd/2,bd/2],rows,sidewins,axis)
   for j,yy in enumerate([.020,.057]):parts+=mullions(axis+'-'+str(j),0,yy,.016,.024,z,axis)
  parts.append(wide_curved_roof())
  parts.append(L.tube('own-continuous-soft-curved-front-eave','ceramic',[(x,wide_eave(x),.034)for x in np.linspace(-.082,.082,150)],.0018,12))
  for sign in[-1,1]:parts.append(L.tube('own-soft-side-eave-'+str(sign),'ceramic',[(sign*.083,.079,-.033),(sign*.083,.079,.032)],.0018,12))
  parts.append(L.tube('own-soft-rear-eave','ceramic',[(-.082,.079,-.034),(.082,.079,-.034)],.0018,12))
  parts.append(rounded_block('closed-finite-wide-roof-ridge',.167*.78,.001,.068*.30,(0,.1085,0),radius=.0004))
  # Central raised front gable is an extruded curved profile with a real round vent.
  parts.append(shaped_aperture('continuous-curved-front-gable-real-round-vent',lambda x,y:abs(x)<=.079 and y>=.075 and y<=wide_eave(x),(0,.0845),('circle',.0054,.0054),lambda x,y,t:(x,y,.0308-t*.0022)))
  for sign in[-1,1]:
   parts.append(rounded_block('own-roof-chimney-'+str(sign),.011,.012,.011,(sign*.043,.112,0),radius=.0012));parts.append(rounded_block('own-chimney-rounded-cap-'+str(sign),.013,.003,.013,(sign*.043,.1185,0),radius=.0012))
  for j in range(3):parts.append(rounded_block('own-centre-doorstep-'+str(j),.020-j*.001,.0026,.010-j*.002,(0,.0013+j*.0026,.034+j*.001),radius=.0008))
 # The inside is truly hollow; only unseen base/LED position is interpreted.
 parts.append(rounded_block('separate-ABS-bottom-battery-housing',w*.78,.0018,d*.78,(0,.001,0),mat='plastic',radius=.001));parts+=hidden_light(min(w,d)*.23,.004)
 return parts
def materials(pid,s,ims,out):
 m=next(x for x in ims if s['token']in x['path']);image=Image.open(m['path']).convert('RGB');patch=image.crop(s['crop']);raw=np.asarray(patch,float);low=np.asarray(patch.filter(ImageFilter.GaussianBlur(7)),float);intrinsic=np.clip(raw/np.maximum(low,1)*np.array(s['rgb']),0,255)
 grain=raw.mean(2)-low.mean(2);dy,dx=np.gradient(grain*.0007);nn=np.stack([-dx,-dy,np.ones_like(dx)],2);nn/=np.linalg.norm(nn,axis=2,keepdims=True)
 mats={};maps=[]
 for key,rgb,rough in [('ceramic',intrinsic,.29),('plastic',np.full((8,8,3),226.),.52),('diffuser',np.broadcast_to([244.,238.,218.],(8,8,3)),.41)]:
  nrm=nn if key=='ceramic'else np.broadcast_to([0,0,1],rgb.shape);orm=np.zeros_like(rgb,dtype=np.uint8);orm[:,:,0]=255;orm[:,:,1]=int(rough*255)
  for slot,arr in [('albedo',rgb),('normal',(nrm+1)*127.5),('orm',orm)]:
   p=out/(key+'-'+slot+'.png');Image.fromarray(np.clip(arr,0,255).astype('uint8'),'RGB').save(p);maps.append(dict(path=str(p),sha256=sha(p),material=key,slot=slot))
  mats[key]=dict(baseColorFactor=[1,1,1,1],baseColorTexture=key+'-albedo.png',normalTexture=key+'-normal.png',metallicRoughnessTexture=key+'-orm.png',normalScale=.18,metallic=1,roughness=1,alphaMode='OPAQUE',doubleSided=False)
  if key=='ceramic':mats[key].update(clearcoat=.27,clearcoatRoughness=.25)
 dump(out/'native-crop-provenance.json',dict(master=m['path'],master_sha256=m['sha256'],native_crop_box=s['crop'],native_pixels=list(patch.size),upscale=False,geometric_resampling_count=0,intrinsic_illumination_normalization='Per-channel low frequency native crop normalization, no object edges/background/reflections',pigment_interpretation_srgb=s['rgb']))
 return mats,maps
def normalize_outer_normals(m,s):
 p=np.array(m['positions']).reshape(-1,3);n=np.array(m['normals']).reshape(-1,3)
 if s['kind']=='cone':
  rr=np.linalg.norm(p[:,[0,2]],axis=1);ro=np.array([cone_radius(y,s)for y in p[:,1]]);slope=s['w']/2/s['h']
  for dep,sign in[(0,1),(s['th'],-1)]:
   mask=np.abs(rr-(ro-dep))<1e-8
   norm=np.c_[p[:,0]/np.maximum(rr,1e-12),np.full(len(p),slope),p[:,2]/np.maximum(rr,1e-12)];norm/=np.linalg.norm(norm,axis=1,keepdims=True);n[mask]=norm[mask]*sign
 else:
  # Large plane tiles share exact analytic normals, suppressing false facet seams.
  if 'wall' in m['name'] or 'opening' in m['name'] or 'belfry' in m['name'] or 'dormer' in m['name'] or 'vent' in m['name']:
   ranges=np.ptp(p,axis=0);axis=0 if ranges[0]<ranges[2] else 2;lo,hi=p[:,axis].min(),p[:,axis].max()
   for val,sgn in [(lo,-1),(hi,1)]:
    mask=np.abs(p[:,axis]-val)<1e-9;normal=np.zeros(3);normal[axis]=sgn;n[mask]=normal
 m['normals']=n.reshape(-1).tolist()
def build(pid):
 s=S[pid];q=Q[pid];ims=[m for m in MASTERS if m['sku']==pid]
 for m in ims:assert sha(m['path'])==m['sha256']
 out=R/('candidate-'+REV)/pid;out.mkdir(parents=True,exist_ok=False);parts=cones(s)if s['kind']=='cone'else house(s)
 vv=np.concatenate([x['_vertices']for x in parts]);lo=vv.min(0);hi=vv.max(0);centre=np.array([(lo[0]+hi[0])/2,lo[1],(lo[2]+hi[2])/2]);meshes=[];checks=[]
 for g in parts:
  g['_vertices']=[tuple(np.array(p)-centre)for p in g['_vertices']];m,c=L._finalize(G.H.orient(g));normalize_outer_normals(m,s);meshes.append(m);checks.append(c)
 repairs=G.M.ensure_uv_faces(meshes)+G.H.ensure_float32_uv(meshes);mats,maps=materials(pid,s,ims,out);dims=((hi-lo)*100).tolist();ident='hm-'+pid+'-perforated-ceramic-'+REV
 note='Resmî yükseklik/genişlik/çap etiketleri aynen korundu. Delik ve pencere yerleri, çatı/profil oranları kendi fotoğrafından yorumlandı; duvar kalınlığı, derinliği yayımlanmayan evlerin derinliği, görünmeyen arka/yan açıklıklar, iç LED/batarya kapağı yerleşimi ve sırın optik değerleri fotoğrafa dayalı tahmindir. Üretici CAD veya taraması değildir. Entegre LED kapalı sunulur, fotoğraf ışığı kaplamaya aktarılmadı. Pil hücreleri modellenmedi.'
 ef=R/'source-evidence'/(pid+'-'+REV+'.json');dump(ef,dict(source_record=q,exact_sku_spec=s,electrical_facts=json.loads((R/'electrical-source-facts.verified.json').read_text()),source_image_masters=ims,note=note))
 meta=dict(id=ident,sku=pid,name=s['name'],brand='H&M Home',category='Aydınlatma',category_id='lighting',category_slug='aydinlatma',url=q['url'],source_market=q['source_market'],markets=q['markets'],colour=q.get('colour'),material_label='Sırlı stoneware / ABS',official_materials=q['composition'],official_measurements=q['official_measurements'],official_dimension_facts=q['official_dimension_facts'],dimensions_cm=dims,source_dimensions_hwd_cm=[dims[1],dims[0],dims[2]],source_size_pointer=str(ef)+'#source_record/official_measurements',source_evidence_files=[str(ef)]+q['source_evidence_files'],source_images=q['reference_images'],original_image=ims[0]['path'],original_image_url=ims[0]['url'],original_image_sha256=ims[0]['sha256'],original_images=[{k:m[k]for k in['path','url','sha256']}for m in ims],units='metres',up_axis='Y',origin='bottom bounding-box centre',estimated_dimensions=True,estimated_fields=['unpublished_depth','hole_count_backside','wall_thickness','hidden_internal_layout','photo_profile_interpretation','glaze_optics'],scale_note=note,quality_label='Gerçek açıklıklı sırlı seramik · Fotoğrafa dayalı ayrıntılar',model_status='pending_root_visual_review',quality_pending=True,ready_model_variants=0,unlit=False,display_state_unpowered=True,baked_reflections=False,photo_pixels_baked=False,photographed_features=['Real finite-wall open perforations/windows, hollow interior','Separate own-source roof/tip, actual architectural window mullions','Own native ceramic grain; no light or reflection bake'],geometry_limitations=['Unseen internal/base/backside form interpreted; cells not supplied'],complete_category_claim=False)
 dump(out/'model.json',dict(metadata=meta,materials=mats,meshes=meshes));dump(out/'geometry-validation.json',dict(valid=True,mesh_count=len(meshes),triangles=sum(c['triangles']for c in checks),closed_material_solids=True,meshes=checks,uv_repairs=repairs));dump(out/'material-validation.json',dict(valid=True,embedded_maps=maps,source_master_sha_unchanged=True))
 report=L.export_assets(out/'model.json',out,ident);glb=out/(ident+'.glb');doc,binary=L.read_glb(glb);binary=G.M.embed_tangents(doc,binary);L.write_glb(glb,doc,binary);report['deliverable_sha256']['glb']=sha(glb);report['glb_bytes']=glb.stat().st_size;dump(report['files']['validation'],report)
 e=dict(meta,asset_dir=str(out),model_path=str(out/'model.json'),glb_path=str(glb),sha256=sha(glb),bytes=glb.stat().st_size,geometry_validation=str(out/'geometry-validation.json'),material_validation=str(out/'material-validation.json'),model_revision='source-specific-perforated-ceramic-'+REV,size_source_kind='official_same_exact_sku_with_photo_interpretations',size_source_urls=[q['url']]);dump(out/'entry.json',e)
 rows=json.loads((R/'manifest.json').read_text())if(R/'manifest.json').exists()else[];rows=[x for x in rows if x['sku']!=pid]+[e];dump(R/'manifest.json',rows);print('CERAMIC',pid,len(meshes),glb.stat().st_size,e['sha256'],flush=True)
if __name__=='__main__':
 for pid in sys.argv[1:]or S:build(pid)
