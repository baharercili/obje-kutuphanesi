"""Thirteen own-photo textile shades; immutable source masters stay read-only."""
from pathlib import Path
import sys, math, json, hashlib, importlib.util, os
sys.dont_write_bytecode=True
import numpy as np
from PIL import Image, ImageFilter

BASE=Path(__file__).resolve().parent;P=BASE.parent
R=Path(os.environ.get('HM_ROOT_SHADE_OUTPUT',str(BASE)))
sys.path.insert(0,str(P/'lighting-models'))
spec=importlib.util.spec_from_file_location('root_shade_helpers',P/'lighting-models/build_lighting.py')
L=importlib.util.module_from_spec(spec);sys.modules[spec.name]=L;spec.loader.exec_module(L)
L.R=R;B=L.B;T=math.tau
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
sources={q['sku']:q for q in read(BASE/'frozen-source-13-normalized.json')}
crop_specs={q['sku']:q for q in read(BASE/'native-crop-selections.json')}
names={'1260977001':'Beyaz keten karışımlı dalgalı abajur başlığı','1260977003':'Bej keten karışımlı dalgalı abajur başlığı','1260977005':'Mavi kumaş dalgalı abajur başlığı','1253600001':'Oval pileli keten abajur başlığı','1297134001':'Zebra desenli silindir abajur başlığı','1297134002':'Ağaç desenli silindir abajur başlığı','1293949001':'Koyu kahverengi kadife silindir başlık','1293949002':'Karamel kadife silindir başlık','1287267001':'Beyaz kumaş silindir abajur başlığı','1257788001':'Beyaz keten karışımlı dalgalı sarkıt','1257788003':'Bej keten karışımlı dalgalı sarkıt','1287265001':'Uzun loblu keten karışımlı sarkıt','1277538001':'Kademeli kumaş sarkıt'}
for sku,q in sources.items():q['name_tr']=names[sku]
L.sources=lambda:sources

colours={'1260977001':[230,226,213],'1260977003':[188,168,139],'1260977005':[111,140,160],'1253600001':[225,214,190],'1293949001':[66,49,38],'1293949002':[157,116,72],'1287267001':[231,229,218],'1257788001':[231,227,213],'1257788003':[198,177,151],'1287265001':[224,216,197],'1277538001':[218,207,186]}
patch_metres={'1260977001':.045,'1260977003':.04,'1260977005':.075,'1253600001':.04,'1293949001':.06,'1293949002':.06,'1287267001':.06,'1257788001':.045,'1257788003':.075,'1287265001':.10,'1277538001':.10}
printed={'1297134001','1297134002'}
pendants={'1257788001','1257788003','1287265001','1277538001'}

def cloth_patch(sku):
    rec=crop_specs[sku];assert sha(rec['master'])==rec['master_sha256']
    patch=Image.open(rec['master']).convert('RGB').crop(rec['box'])
    raw=np.array(patch,dtype=float);low=np.array(patch.filter(ImageFilter.GaussianBlur(28)),dtype=float)
    rgb=np.clip(raw/np.maximum(low,1)*np.array(colours[sku]),0,255)
    # Reflect the same native pixels at the tile edge. No source is enlarged.
    rgb=np.concatenate([rgb,rgb[:,::-1]],axis=1);rgb=np.concatenate([rgb,rgb[::-1]],axis=0)
    return rgb,dict(**rec,derived_pixels=[rgb.shape[1],rgb.shape[0]],geometric_resampling_count=0,tiling='Native crop reflected once at each edge; hidden full-wrap cloth is an interpretation',illumination='Low-frequency channel gradient divided out at original pixel scale',physical_unmirrored_patch_metres=patch_metres[sku])

def print_patch(sku,ims):
    master=next(i for i in ims if i['sku']==sku);im=Image.open(master['path']).convert('RGB');a=np.array(im,dtype=float)
    # Interior material only, excluding the rim, silhouette and cast shadow.
    x0,x1,y0,y1=(148,1380,430,1785)if sku=='1297134001'else(193,1330,580,1765)
    phi=np.linspace(-math.radians(80),math.radians(80),768)
    xx=(x0+x1)/2+(x1-x0)/2*np.sin(phi)
    yy=np.linspace(y0,y1,1024)
    xi=np.floor(xx).astype(int);yi=np.floor(yy).astype(int);fx=(xx-xi)[None,:,None];fy=(yy-yi)[:,None,None]
    upper=a[yi[:,None],xi[None,:]]*(1-fx)+a[yi[:,None],xi[None,:]+1]*fx
    lower=a[yi[:,None]+1,xi[None,:]]*(1-fx)+a[yi[:,None]+1,xi[None,:]+1]*fx
    pixels=upper*(1-fy)+lower*fy
    # Correct only the slowly varying lateral illumination; preserve print hues.
    light=np.quantile(pixels.mean(2),.9,axis=0);gain=np.clip(np.median(light)/np.maximum(light,1),.85,1.15)
    pixels=np.clip(pixels*gain[None,:,None],0,255)
    return pixels,dict(master=master['path'],master_sha256=master['sha256'],native_master_pixels=list(im.size),source_interior_box=[x0,y0,x1,y1],cylinder_sector_degrees=160,derived_pixels=[768,1024],geometric_resampling_count=1,operation='One bilinear inverse cylindrical projection; source sector repeats only to interpret unseen wrap',background_and_cast_shadow_excluded=True,back_pattern_estimated=True)

def material_bank(sku,keys,ims,out,overrides=None):
    if sku in printed:rgb,provenance=print_patch(sku,ims)
    else:rgb,provenance=cloth_patch(sku)
    maps=[];mats={};velvet=sku.startswith('1293949')
    for key in sorted(keys):
        if key in ['cloth','trim']:
            col=rgb.copy();grey=col.mean(2);smooth=np.array(Image.fromarray(np.uint8(np.clip(grey,0,255))).filter(ImageFilter.GaussianBlur(1.2)),dtype=float)
            detail=np.clip(grey-smooth,-18,18);dy,dx=np.gradient(detail*.012)
            norm=np.stack([-dx,-dy,np.ones_like(dx)],axis=-1);norm/=np.linalg.norm(norm,axis=-1,keepdims=True)
            rough=np.clip((.84 if velvet else .89)+detail*.0013,.7,.97);metal=0
        else:
            colour={'lining':[237,234,222],'steel':[167,165,155],'cable':[231,228,218],'canopy':[230,228,218],'socket':[230,228,218]}[key]
            col=np.broadcast_to(np.array(colour),(8,8,3)).copy();norm=np.zeros((8,8,3));norm[:,:,2]=1;rough=np.full((8,8),.7 if key!='steel'else .32);metal=1 if key=='steel'else 0
        h,w=col.shape[:2];orm=np.zeros((h,w,3),np.uint8);orm[:,:,0]=255;orm[:,:,1]=np.uint8(np.clip(rough*255,0,255));orm[:,:,2]=metal*255
        for slot,arr in [('albedo',np.uint8(np.clip(col,0,255))),('normal',np.uint8(np.clip((norm+1)*127.5,0,255))),('orm',orm)]:
            path=out/(key+'-'+slot+'.png');Image.fromarray(arr).save(path,optimize=True);maps.append(dict(material=key,slot=slot,path=str(path),sha256=sha(path),native_resolution=[w,h]))
        mats[key]=dict(baseColorFactor=[1,1,1,1],baseColorTexture=key+'-albedo.png',normalTexture=key+'-normal.png',metallicRoughnessTexture=key+'-orm.png',normalScale=.30 if key in['cloth','trim']else .05,metallic=1,roughness=1,alphaMode='OPAQUE',doubleSided=False,extras=dict(intrinsic_material=True,baked_reflections=False,photo_pixels_baked=key in['cloth','trim'],native_resolution=[w,h],optical_parameters_estimated=True))
        if key in ['cloth','lining']:mats[key]['extras']['diffuse_transmission_factor']=.11 if velvet else .18
    L.dump(out/'native-crop-provenance.json',provenance)
    return mats,maps
L.material_bank=material_bank

def shell(name,material,shape,h,sku,inner_offset=0,thickness=.00065,N=256,M=96):
    vertices=[];uv=[];faces=[]
    for side in [0,1]:
        for k in range(M+1):
            t=k/M
            for j in range(N+1):
                a=T*(j%N)/N;x,z,dy=shape(a,t)
                r=math.hypot(x,z);off=inner_offset+side*thickness;x*=1-off/r;z*=1-off/r
                y=.002+t*h+dy;vertices.append((x,y,z))
                if sku in printed:u=(T*j/N-math.pi/2)/math.radians(160)+.5;v=1-t
                else:
                    scale=2*patch_metres[sku];u=a*shape(0,.5)[0]/scale;v=(1-t)*h/scale
                uv.append((u,v))
    stride=N+1;size=(M+1)*stride
    for side in [0,1]:
        off=side*size
        for k in range(M):
            for j in range(N):
                a=off+k*stride+j;b=a+1;c=a+stride;d=c+1;faces.extend([(a,b,c),(b,d,c)])
    for k in [0,M]:
        for j in range(N):a=k*stride+j;b=a+1;c=a+size;d=b+size;faces.extend([(a,c,b),(b,c,d)])
    return B.solid(name,material,vertices,faces,uv)

def rim(name,material,shape,t,h,offset=.0009):
    points=[]
    for a in np.linspace(0,T,256,endpoint=False):
        x,z,dy=shape(a,t);r=math.hypot(x,z);points.append((x*(1-offset/r),.002+t*h+dy,z*(1-offset/r)))
    return L.tube(name,material,points,.00065,8,True)

def shade_builder(q):
    sku=q['sku'];m=q['official_measurements'];h=m['height_cm']/100
    w=m.get('diameter_cm',m.get('width_cm',0))/100;d=m.get('diameter_cm',m.get('depth_cm',0))/100
    lobed=sku.startswith('1260977')or sku.startswith('1257788')
    oval=sku=='1253600001';long=sku=='1287265001';stepped=sku=='1277538001'
    if lobed:
        amp=.065;top_r=w*.155
        def shape(a,t):
            r=(w/2*(1-t)+top_r*t)/(1+amp)*(1+amp*math.cos(8*a));dy=.0035*(1-t)**3*(1-math.cos(8*a))
            return r*math.cos(a),r*math.sin(a),dy
        shape_note='Eight broad, continuous soft flutes and softly scalloped lower edge, interpreted from exact-SKU front and detail photographs'
    elif oval:
        def shape(a,t):
            wave=.0085*math.tanh(2.2*math.cos(12*a))/math.tanh(2.2);return(w/2+wave)*math.cos(a),(d/2+wave)*math.sin(a),0
        shape_note='Elliptical open shade with twelve broad vertical folds; official38×19×18cm bounding axes retained'
    elif long:
        ts=np.array([0,.05,.25,.55,.82,1.]);rs=np.array([.088,.104,.144,.196,.22,.171]);delta=np.diff(rs)/np.diff(ts);slopes=np.zeros(len(ts));slopes[0]=delta[0];slopes[-1]=delta[-1]
        for i in range(1,len(ts)-1):
            if delta[i-1]*delta[i]>0:slopes[i]=2/(1/delta[i-1]+1/delta[i])
        def shape(a,t):
            i=min(len(ts)-2,max(0,np.searchsorted(ts,t)-1));dt=ts[i+1]-ts[i];s=(t-ts[i])/dt
            r=(2*s**3-3*s*s+1)*rs[i]+(s**3-2*s*s+s)*dt*slopes[i]+(-2*s**3+3*s*s)*rs[i+1]+(s**3-s*s)*dt*slopes[i+1]
            r*=1+.065*math.cos(8*a);return r*math.cos(a),r*math.sin(a),.007*math.cos(8*a)*(t**4+(1-t)**4)
        shape_note='Long tapering eight-lobed open fabric lantern with curved upper shoulders and narrower lower opening'
    else:
        def shape(a,t):return w/2*math.cos(a),d/2*math.sin(a),0
        shape_note='True open cylindrical fabric drum, separate inner backing, fine folded upper/lower binding'
    parts=[]
    if stepped:
        # Four real, open, coaxial fabric cylinders. The broad centre band is51%H.
        for n,(lo,hi,ratio)in enumerate([(0,.17,.36),(.17,.36,.60),(.36,.82,1),(.82,1,.60)]):
            def ring_shape(a,t,r=w*.5*ratio):return r*math.cos(a),r*math.sin(a),0
            g=shell('separate-fabric-stepped-cylinder-'+str(n),'cloth',ring_shape,(hi-lo)*h,sku);L.move(g,(0,lo*h,0));parts.append(g)
            for t in[0,1]:
                g=rim('separate-bound-rim-'+str(n)+'-'+str(t),'trim',ring_shape,t,(hi-lo)*h);L.move(g,(0,lo*h,0));parts.append(g)
        shape_note='Four stepped coaxial textile-covered open cylinders, with the wide central band and narrow lowest tier from the exact own front photograph'
    else:
        parts.append(shell('separate-continuous-woven-textile-shell','cloth',shape,h,sku))
        if not oval:parts.append(shell('separate-inner-structural-shade-lining','lining',shape,h,sku,.00065,.00040))
        for t in[0,1]:parts.append(rim('separate-fabric-edge-binding-'+str(t),'trim',shape,t,h))
    y=h*.78
    parts.append(L.tube('separate-metal-mounting-ring','steel',[(.021*math.cos(a),y,.021*math.sin(a))for a in np.linspace(0,T,96,endpoint=False)],.0011,8,True))
    for j in range(3):
        a=T*j/3;x,z,_=shape(a,.78);parts.append(L.tube('separate-inner-mount-spoke-'+str(j),'steel',[(.021*math.cos(a),y,.021*math.sin(a)),(x*.96,y,z*.96)],.0009,8))
    estimated=['unseen_rear_details','cloth_thickness','fold_count_and_local_profile','inner_mount_dimensions','intrinsic_colour_and_fibre_optics']
    note='Resmî gövde ölçüleri korunur. Kumaş, ürünün kendi fotoğrafından alınan doğal yüzey ayrıntılarıyla hazırlanmıştır. Görünmeyen arka yüz, kıvrımlar ve iç montaj ayrıntıları fotoğraflardan yorumlanmıştır.'
    if sku in printed:estimated.append('unseen_full_wrap_print');note+=' Ön fotoğrafta görünen desen, silindir izdüşümü düzeltilerek kullanıldı; görünmeyen arka desen aynı görünür bölümün tekrarıyla yorumlandı.'
    if sku in pendants:
        parts+=L.holder(h*.71,'E27')
        length=m.get('cord_length_cm',160)/100
        coil,actual_length=L.cord(length,(0,.009,-.035),.065,mat='cable',switch=False)
        for g in coil:L.move(g,(0,h*.48,0));parts.append(g)
        cup=B.lathe('separate-detached-ceiling-canopy-stored-inside-shade','canopy',[(.048,h*.36),(.048,h*.42),(.047,h*.425),(0,h*.425),(0,h*.423),(.046,h*.423),(.046,h*.36)],128,True);parts.append(cup)
        estimated+=['stored_cord_and_detached_canopy_pose','socket_dimensions','ceiling_canopy_dimensions']
        if 'cord_length_cm'not in m:estimated.append('cord_length_cm');note+=' Kablo uzunluğu yayımlanmadığı için 160 cm olarak tahmin edildi.'
        note+=' Kablo ayrı parça olarak başlığın içinde sarılı, tavan rozeti ise sökülmüş konumda sunulur. Bu saklama pozu temsilidir; model ışığı kapalı halde gösterilir.'
    else:note+=' Başlık tek başına sunulur; lamba kaidesi ve ampul ürün kapsamına dahil edilmemiştir.'
    return parts,dict(target_cm=[w*100,h*100,d*100],official_axes=list(m),estimated=estimated,features=[shape_note,'Actual open upper/lower surfaces, finite fabric thickness, separate rim bindings and hidden metal support','Intrinsic own-photo cloth albedo/fibre normals; photographic gradient and cast shadow excluded'],scale_note=note,source_measurement_scope='Published dimensions apply to the shade body; stored detachable accessories remain inside that envelope')

L.BUILD={s:shade_builder for s in sources}
if __name__=='__main__':
    for sku in sys.argv[1:]or sources:L.build(sku)
