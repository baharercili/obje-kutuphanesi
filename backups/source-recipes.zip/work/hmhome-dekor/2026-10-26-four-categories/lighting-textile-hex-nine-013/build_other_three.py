"""Own taut cloth petal, elongated hex and tilted painted-metal fixtures."""
from pathlib import Path
import sys,json,math,ast,copy
import numpy as np
from PIL import Image
P=Path(__file__).resolve().parent.parent;sys.path.insert(0,str(P/'lighting-models'));import build_lighting as L
R=Path('/private/tmp/hm-lighting-20261028/textile-other-three-013');S=Path('/private/tmp/hm-lighting-20261028/textile-nine-source-review');R.mkdir(parents=True,exist_ok=True);T=math.tau
IDS=['1277792001','1304450002','1311980002']
if list(R.glob('frozen*manifest*.json')):raise RuntimeError('Frozen outputs require a separate revision.')
qs={q['sku']:q for q in json.loads((S/'source-facts.json').read_text())if q['sku']in IDS};L.sources=lambda:qs;L.R=R;bank0=L.material_bank
qs['1311980002']['official_measurements']=dict(top_diameter_cm=21.5,bottom_diameter_cm=11.7,height_cm=25.5,cord_length_cm=160)
registry=[x for s,xx in json.loads((S/'available-masters.json').read_text()).items()if s in IDS for x in xx]
for x in registry:assert L.sha(x['path'])==x['sha256']
L.dump(R/'original-image-masters.json',registry)
for path,names in[(P/'lighting-portable-batch-008/build_portable.py',['closed_lathe','cylinder','rotate','rounded_loop','prism_loops','rounded_box']),(P/'lighting-geometric-batch-006/build_geometric.py',['eholder','loft']),(P/'lighting-metal-geometric-five-010/build_five.py',['cord']),(P/'lighting-portable-batch-009/build_glass_stone_umbrella.py',['finite_dome']),(P/'lighting-glass-batch-007/build_glass.py',['natural_profile']),(P/'lighting-textile-hex-nine-013/build_first_three.py',['gauss','mirror'])]:
 tree=ast.parse(path.read_text());exec(compile(ast.Module(body=[x for x in tree.body if isinstance(x,ast.FunctionDef)and x.name in names],type_ignores=[]),'readonly-pure-profile-hardware','exec'),globals())
def polar_shell(name,mat,rings,wall=.0005):
 na=256;ny=len(rings);v=[];uv=[]
 for inside in[False,True]:
  for r,y,count,raddepth,ydip in rings:
   for j in range(na):
    a=T*j/na;wave=(1-math.cos(count*a))*.5;rr=r*(1-raddepth*wave)-(wall if inside else 0);yy=y-ydip*wave;v.append((rr*math.cos(a),yy,rr*math.sin(a)));uv.append(((a/T)*T*r/.080,yy/.080))
 faces=[];off=ny*na
 for side in range(2):
  for i in range(ny-1):
   for j in range(na):a=side*off+i*na+j;b=side*off+i*na+(j+1)%na;c=a+na;d=b+na;faces.extend([(a,b,c),(b,d,c)])
 for i in[0,ny-1]:
  for j in range(na):a=i*na+j;b=i*na+(j+1)%na;c=a+off;d=b+off;faces.extend([(a,b,c),(b,d,c)])
 return L.B.solid(name,mat,v,faces,uv,flat=False)
def common(q,parts,note,est,socket,w,le,features,mods):
 defaults=dict(cloth=('plastic',[236,234,225],.9,0),lining=('plastic',[234,232,220],.76,0),white=('plastic',[234,232,222],.67,0),paint=('paint',[178,130,93],.27,0),stone=('plastic',[195,146,110],.64,0),cord=('plastic',[219,216,203],.74,0),switch=('plastic',[230,228,216],.40,0));defaults.update(mods)
 note+=' '+socket+', azami '+str(w)+' W LED; ampul dahil değildir. Armatür varsayılan sahnede; tam boy ayrı kablo isteğe bağlı sahnededir. Yerel kalınlıklar, görünmeyen donanım, optik değerler ve kablo duruşu fotoğraf yorumudur. Üretici CAD dosyası değildir.'
 return parts,dict(target_cm=None,id_suffix='-own-source-r01',official_axes=list(q['official_measurements']),estimated=est+['finite_wall_and_hidden_empty_'+socket+'_hardware','stored_cord_pose','optical_parameters'],features=features,material_overrides=defaults,official_socket_type=socket,official_socket_count=1,official_source_max_led_w=w,bulbs_included=False,measured_cord_length_m=le,scene_variants=[dict(index=0,label='Armatür'),dict(index=1,label='Kablo ile')],default_scene_index=0,source_component_dimension_facts=q['official_dimension_facts'],scale_note_override=note)
def petal(q):
 base=natural_profile([(.058,0),(.059,.012),(.057,.060),(.052,.15),(.051,.176),(.047,.192),(.036,.205)],90);rings=[(r,y,8,.13,-.005*(1-y/.205)**8)for r,y in base];parts=[polar_shell('separate-finite-eight-lobed-taut-fabric-base','cloth',rings,.00045),cylinder('separate-hidden-lower-metal-foot-plate','white',.049,.0002,.0007)]
 head=[(.012+.138*math.cos(v),.200+.096*math.sin(v),12,.06,.010*math.sin(v)**8*math.sqrt(max(0,math.cos(v)))-.003*(1-math.sin(v))**8)for v in np.linspace(0,math.pi/2,65)];parts.append(polar_shell('separate-finite-twelve-panel-taut-cloth-dome','cloth',head,.00045));parts+=eholder('E14',.180)
 for i,a in enumerate(np.linspace(0,T,12,endpoint=False)):
  pp=[((r-.0007)*math.cos(a),y-.0007,(r-.0007)*math.sin(a))for r,y,*_ in head];parts.append(L.tube('separate-functional-white-head-rib-'+str(i),'white',pp,.0006,8))
 for i,a in enumerate(np.linspace(0,T,8,endpoint=False)):
  pp=[((r-.0007)*math.cos(a),y+.0007,(r-.0007)*math.sin(a))for r,y in base];parts.append(L.tube('separate-functional-white-base-rib-'+str(i),'white',pp,.0006,8))
 for i,a in enumerate(np.linspace(0,T,3,endpoint=False)):parts.append(L.tube('separate-estimated-central-frame-contact-'+str(i),'white',[(.019*math.cos(a),.180,.019*math.sin(a)),(.0355*math.cos(a),.205,.0355*math.sin(a))],.0007,8))
 c,le=cord(1.6,.069,.139,(0,.010,-.056),'cord');parts+=c
 note='Kendi resmî toplam yüksekliği 29,6 cm ve çapı 30 cm korunur. Kendi fotoğrafında ince kumaş metal iskelete gerilmiştir; yaklaşık on iki başlık dilimi ve sekiz ayak dilimi, yumuşak ara çöküntüler ve alt kenar uçları fiziksel geometridir. Tam arka kaburga sayısı ve bileşen yükseklikleri fotoğraf tahminidir. Demir %70 ve polyester %30 bileşimi korunur; polistiren astar eklenmez. Üst açıklık ve görünmeyen iç donanım fotoğraf yorumu; kaynaktan kesin doğrulanamıyor. Yayımlanmayan kablo boyu 160 cm tahminidir. Kendi 128 piksellik beyaz kumaş kırpımının çözemediği ince iplikler uydurulmaz; fotoğrafın geniş kıvrım gölgesi rengine aktarılmaz.'
 return common(q,parts,note,['own_photo_12_head_and_8_base_ribs','head_and_base_component_heights','upper_aperture_unverified','soft_panel_tension_profile','unpublished_cord_length_160cm_estimate','native_cloth_repeat_and_detail_limit'],'E14',6,le,['Own continuous twelve-panel soft dome and eight-lobed tapered taut-cloth foot','Finite polyester fabric with separate functional iron ribs, not a generic smooth dome','Exact own source29.6cm height30cm diameter, unknown upper topology explicitly interpreted'],{})
def elliptical_cord(length):
 start=np.array([-.036,.011,-.035])
 def path(turns):
  a=np.linspace(math.pi,math.pi+T*turns,1200);t=np.linspace(0,1,len(a));rx=.073+.039*t;rz=.044+.020*t;pp=np.c_[rx*np.sin(a),np.full(len(a),.002),rz*np.cos(a)];return np.vstack([np.linspace(start,pp[0],50,endpoint=False),pp])
 lo,hi=.1,15
 for _ in range(40):
  m=(lo+hi)/2;p=path(m);le=np.linalg.norm(np.diff(p,axis=0),axis=1).sum()
  if le<length:lo=m
  else:hi=m
 pp=path((lo+hi)/2);assert .020/((lo+hi)/2)>.0032
 parts=[L.tube('optional-stored-cord-full-160cm-elliptical-clear-foot-pose','cord',pp.tolist(),.0015,10)];pos=pp[600];parts+=[L.move(rounded_box('optional-stored-cord-inline-switch','switch',.029,.010,.015,.001,.003),(pos[0],0,pos[2])),L.move(cylinder('optional-stored-cord-raised-rocker','switch',.0038,.011,.002),(pos[0],0,pos[2]))];return parts,float(np.linalg.norm(np.diff(pp,axis=0),axis=1).sum())
def hexagon(q):
 p=np.array([[-.12,0],[-.07,-.07],[.07,-.07],[.12,0],[.07,.07],[-.07,.07]]);base=p*.50;yb=.127;h=.267
 parts=[loft('separate-six-sided-fabric-covered-foot','cloth',base,base,0,.145),loft('separate-finite-elongated-hex-cloth-head','cloth',p,p,yb,h,.001),loft('separate-finite-white-PS-inner-liner','lining',p*.99,p*.99,yb+.0002,h-.0002,.0006),loft('separate-photo-interpreted-thin-upper-fabric-cap','cloth',p*.996,p*.996,h-.001,h),loft('separate-photo-interpreted-upper-PS-backing','lining',p*.99,p*.99,h-.0015,h-.001)]
 parts+=eholder('E27',.144)
 for i,(x,z)in enumerate(p[::2]*.982):parts.append(L.tube('separate-estimated-internal-shade-contact-'+str(i),'white',[(.020*x/.12,.157,.020*z/.12),(x,.157,z)],.0007,8))
 for g in parts:
  if g['material']=='cloth':g['_uvs']=[(x/.110,y/.110)for x,y,z in g['_vertices']]
 c,le=elliptical_cord(1.6);parts+=c
 note='Kendi resmî başlık genişliği 24 cm, başlık derinliği 14 cm, toplam yüksekliği 26,7 cm ve kablo uzunluğu 160 cm korunur. 14 cm derinliktir; başlık yüksekliği değildir. Plan basık altıgendir; 24 cm çaplı düzgün altıgen kullanılmaz. Kaide genişliği/derinliği yaklaşık 12/7 cm, başlık yüksekliği yaklaşık 14 cm ve örtüşme kendi fotoğraf tahminidir. Üst kapak fotoğraftaki kesintisiz dar üst yüzeyin yorumudur; üst açıklık ve görünmeyen iç donanım kaynaktan kesin doğrulanamıyor. Alt montaj açıklığı korunur. Polyester %50, polistiren %30, demir %20; sarı dokuma kendi ana fotoğrafının 256 piksellik yerel kırpımıdır, başka altıgen SKU dokusu değildir. Kablo ayrı eliptik sarımla kaidenin dışında tutulur; başlık bileşen ölçüleri kablo pozuna uydurularak değiştirilmez.'
 return common(q,parts,note,['base_width_depth_height_cm_from_own_photo','shade_height_cm_from_own_photo','upper_cap_interpretation_unverified','native_yellow_cloth_repeat_and_detail_limit'],'E27',15,le,['Own24x14cm elongated six-sided shade and matching narrower foot','Separate finite cloth and PS liner; interpreted upper fabric cap, real lower mounting aperture','Own26.7cm total and160cm cable, no sibling geometry or texture transfer'],dict(cloth=('plastic',[229,202,132],.90,0)))
def bevel_poly(radius):
 pp=np.array([(radius*math.cos(a),radius*math.sin(a))for a in np.linspace(0,T,8,endpoint=False)]);out=[]
 for i,v in enumerate(pp):
  for w in[pp[(i-1)%8],pp[(i+1)%8]]:out.append(v+(w-v)*(.0008/np.linalg.norm(w-v)))
 out=np.array(out);return out*radius/max(np.max(np.abs(out[:,0])),np.max(np.abs(out[:,1])))
def tilted(q):
 r=.1075;hh=.090;th=math.radians(11);ct,st=math.cos(th),math.sin(th);rot=np.array([[ct,-st,0],[st,ct,0],[0,0,1]])
 dome=finite_dome('separate-finite-tilted-lacquered-iron-dome','paint',r,0,hh,.0012,256);rotate(dome,rot);yb=.255-np.array(dome['_vertices'])[:,1].max();L.move(dome,(0,yb,0));parts=[dome,prism_loops('separate-softly-bevelled-eight-facet-stoneware-foot','stone',[(bevel_poly(.0576),0),(bevel_poly(.0585),.001),(bevel_poly(.0585),.002),(bevel_poly(.021),.171),(bevel_poly(.0202),.172)],flat=True)];parts+=eholder('E14',.171)
 Ri=r-.0012;Hi=hh-.0012;joins=[]
 for j,a in enumerate(np.linspace(0,T,3,endpoint=False)):
  x,z=.015*math.cos(a),.015*math.sin(a);A=st*st/(Ri*Ri)+ct*ct/(Hi*Hi);B=2*st*ct*x*(1/(Ri*Ri)-1/(Hi*Hi));C=ct*ct*x*x/(Ri*Ri)+st*st*x*x/(Hi*Hi)+z*z/(Ri*Ri)-1;yy=yb+(-B+math.sqrt(B*B-4*A*C))/(2*A)+.00015;parts.append(L.tube('separate-estimated-physically-contacting-inner-dome-support-'+str(j),'white',[(x,.171,z),(x,yy,z)],.0007,8));joins.append(dict(x=x,z=z,top_y=yy,inner_cap_contact_overlap_m=.00015))
 L.dump(R/'tilted-dome-contact-proof.json',dict(sku=q['sku'],head_max_y=.255,tilt_degrees_estimated=11,body_component_top_diameter_m=.215,stoneware_base_nominal_diameter_m=.117,hidden_supports=joins,hidden_connections_are_estimated=True))
 c,le=cord(1.6,.069,.10,(0,.012,-.057),'cord');parts+=c
 note='Kendi resmî üst başlık çapı 21,5 cm, alt bölüm çapı 11,7 cm, toplam yükseklik 25,5 cm ve 160 cm kablo korunur. Başlık demir %100, diğer parça taş seramiği %100’dür; tüm ürün metal diye gösterilmez. Başlığın kendi fotoğrafındaki yaklaşık 11 derece eğimi, kubbe yüksekliği, sekiz yüzlü kaidenin üst daralması ve küçük pahları fotoğraf tahminidir. Bileşen çapı eğilmiş sahnenin izdüşüm genişliğiyle aynı olmak zorunda değildir; toplam model yeniden ölçeklenmez. Altı açık sonlu boyalı metal kubbe, seramik ayağın içindeki üç küçük tutucuya fiziksel temas eder. Görünmeyen bağlantı üretici detayı olarak ileri sürülmez. Kaynak parlama veya oda yansıması malzemeye yapıştırılmaz; gerçek dielektrik lake boya ve mat seramik malzemesi kullanılır.'
 return common(q,parts,note,['own_photo_dome_tilt_11_degrees','dome_and_base_component_heights','eight_facet_back_count_and_edge_bevel','hidden_contacting_support_rods'],'E14',6,le,['Own inclined open painted-iron dome and distinct faceted stoneware foot','Official component diameters preserved with25.5cm actual posed height','Analytical contact supports meet inner tilted ellipsoid; no floating dome'],{})
SPEC={'1277792001':dict(code='77b9246683f7',box=[530,800,658,928],tile=.040),'1304450002':dict(code='e908be7418c7',box=[600,700,856,956],tile=.055)}
def bank(pid,keys,ims,out,overrides=None):
 mats,maps=bank0(pid,keys,ims,out,overrides)
 if pid not in SPEC:return mats,maps
 sp=SPEC[pid];source=next(x for x in ims if sp['code']in x['path']);patch=Image.open(source['path']).convert('RGB').crop(sp['box']);a=np.array(patch,float);n=a.shape[0];grey=a.mean(2);ratio=grey/np.maximum(gauss(grey,3),1);rgb=np.array(overrides['cloth'][1])[None,None,:]*(1+.35*(ratio[:,:,None]-1));height=(ratio-1)*.000060;rgb=mirror(rgb);height=mirror(height);dx=(np.roll(height,-1,1)-np.roll(height,1,1))/(2*sp['tile']/n);dy=(np.roll(height,-1,0)-np.roll(height,1,0))/(2*sp['tile']/n);nn=np.stack([-dx,-dy,np.ones_like(dx)],2);nn/=np.linalg.norm(nn,axis=2,keepdims=True);orm=np.zeros((2*n,2*n,3),np.uint8);orm[:,:,0]=255;orm[:,:,1]=230
 for slot,arr in [('albedo',np.uint8(np.clip(rgb,0,255))),('normal',np.uint8(np.rint((nn+1)*127.5))),('orm',orm)]:
  path=out/('cloth-'+slot+'.png');Image.fromarray(arr).save(path,optimize=True)
  for rec in maps:
   if rec['material']=='cloth'and rec['slot']==slot:rec.update(sha256=L.sha(path),native_resolution=[2*n,2*n])
 patch.save(out/'own-native-cloth-crop.png');mats['cloth']['normalScale']=.65;mats['cloth']['extras'].update(photo_pixels_baked=True,source_native_material_crop=True,native_resolution=[2*n,2*n],diffuse_transmission_factor=.22 if pid=='1277792001'else.12);L.dump(out/'own-native-cloth-provenance.json',dict(master=source['path'],master_sha256=source['sha256'],native_crop_box=sp['box'],native_crop_pixels=[n,n],geometric_resampling_count=0,mirrored_native_tiling=True,physical_repeat_m_estimated=2*sp['tile'],illumination_separation='Own monochrome sigma3 yarn detail only; low-frequency panel lighting excluded',no_generated_pixels=True,no_product_edge_or_cast_shadow=True,detail_limit='Own primary only; unresolved yarn geometry not invented'))
 return mats,maps
L.BUILD={'1277792001':petal,'1304450002':hexagon,'1311980002':tilted};L.material_bank=bank
if __name__=='__main__':
 for sku in sys.argv[1:]or IDS:
  L.build(sku);rows=json.loads((R/'manifest.json').read_text());e=next(e for e in rows if e['sku']==sku);doc,binary=L.read_glb(e['glb_path']);nodes=copy.deepcopy(doc['nodes']);N=len(nodes);body=[i for i,n in enumerate(nodes)if not n.get('name','').startswith('optional-stored-cord-')];doc['nodes']+=copy.deepcopy(nodes);doc['scenes']=[dict(name='Armatür',nodes=body),dict(name='Kablo ile',nodes=list(range(N,N*2)))];doc['scene']=0;assert set(body).isdisjoint(doc['scenes'][1]['nodes']);L.write_glb(e['glb_path'],doc,binary);e.update(sha256=L.sha(e['glb_path']),bytes=Path(e['glb_path']).stat().st_size,scene_nodes_disjoint=True);L.dump(Path(e['asset_dir'])/'entry.json',e);L.dump(R/'manifest.json',[e if x['sku']==sku else x for x in rows])
