"""Four views from actual GLB accessor bytes; software geometry QA only.
Physical material evaluation belongs to the root browser viewer. Clear glazing
is omitted in these diagnostic views so the neutral inserts remain visible.
"""
from pathlib import Path
import sys,json,struct,io,math,hashlib
sys.dont_write_bytecode=True
import numpy as np
from PIL import Image,ImageDraw,ImageOps
R=Path(__file__).resolve().parent;Q=R/'qa/four-angle';Q.mkdir(parents=True,exist_ok=True)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(path):
 raw=Path(path).read_bytes();jl=struct.unpack_from('<I',raw,12)[0];doc=json.loads(raw[20:20+jl]);binary=raw[28+jl:]
 def attr(i):
  a=doc['accessors'][i];v=doc['bufferViews'][a['bufferView']];dt=np.dtype({5126:'<f4',5125:'<u4',5123:'<u2'}[a['componentType']]);k={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}[a['type']]
  return np.ndarray((a['count'],k),dtype=dt,buffer=binary,offset=v.get('byteOffset',0)+a.get('byteOffset',0),strides=(v.get('byteStride',k*dt.itemsize),dt.itemsize)).copy()
 textures={}
 for i,t in enumerate(doc.get('textures',[])):
  im=doc['images'][t['source']];v=doc['bufferViews'][im['bufferView']];textures[i]=np.array(Image.open(io.BytesIO(binary[v.get('byteOffset',0):v.get('byteOffset',0)+v['byteLength']])).convert('RGB'))/255
 parts=[]
 for m in doc['meshes']:
  pr=m['primitives'][0];parts.append((attr(pr['attributes']['POSITION']),attr(pr['attributes']['NORMAL']),attr(pr['attributes']['TEXCOORD_0']),attr(pr['indices']).reshape(-1,3),doc['materials'][pr['material']]))
 return doc,parts,textures
def draw(parts,textures,extent,direction,path):
 W=H=360;pixels=np.ones((H,W,3))*np.array([.936,.930,.914]);depth=np.ones((H,W))*np.inf;direction=np.array(direction);direction/=np.linalg.norm(direction);target=np.array([0,extent[1]/2,0]);camera=target+direction*max(extent)*3
 fwd=-direction;right=np.cross(fwd,[0,1,0]);right/=np.linalg.norm(right);up=np.cross(right,fwd);basis=np.stack([right,up,fwd],1);focal=H*.78/max(extent);light=np.array([-.3,.7,.8]);light/=np.linalg.norm(light)
 for pos,norm,uv,faces,ma in parts:
  if ma.get('extensions',{}).get('KHR_materials_transmission',{}).get('transmissionFactor',0)>.5:continue
  view=(pos-camera)@basis;xy=np.c_[W/2+focal*view[:,0],H/2-focal*view[:,1]];pbr=ma['pbrMetallicRoughness'];tex=textures[pbr['baseColorTexture']['index']];orm=textures[pbr['metallicRoughnessTexture']['index']];metal=float(orm[:,:,2].mean());rough=float(orm[:,:,1].mean())
  for idx in faces:
   tr=view[idx];pts=xy[idx];lo=np.maximum([0,0],np.floor(pts.min(0)).astype(int));hi=np.minimum([W-1,H-1],np.ceil(pts.max(0)).astype(int))
   if np.any(lo>hi):continue
   x0,y0=lo;x1,y1=hi;xx,yy=np.meshgrid(np.arange(x0,x1+1)+.5,np.arange(y0,y1+1)+.5);a,c,d=pts;den=(c[1]-d[1])*(a[0]-d[0])+(d[0]-c[0])*(a[1]-d[1])
   if abs(den)<1e-10:continue
   w0=((c[1]-d[1])*(xx-d[0])+(d[0]-c[0])*(yy-d[1]))/den;w1=((d[1]-a[1])*(xx-d[0])+(a[0]-d[0])*(yy-d[1]))/den;w2=1-w0-w1;weights=np.stack([w0,w1,w2],-1);z=weights@tr[:,2];mask=(w0>=-1e-8)&(w1>=-1e-8)&(w2>=-1e-8)&(z<depth[y0:y1+1,x0:x1+1])
   if not mask.any():continue
   depth[y0:y1+1,x0:x1+1][mask]=z[mask];nn=weights@norm[idx];nn/=np.maximum(np.linalg.norm(nn,axis=2,keepdims=True),1e-10);shade=.42+.58*np.clip(nn@light,0,1);tuv=weights@uv[idx];tu=np.floor((tuv[:,:,0]%1)*tex.shape[1]).astype(int);tv=np.floor((1-tuv[:,:,1]%1)*tex.shape[0]).astype(int)%tex.shape[0];rgb=tex[tv,tu]**2.2
   if metal>.5:
    reflected=2*(nn@direction)[...,None]*nn-direction
    panel=np.exp(-((reflected[:,:,0]+.3)**2/.16+(reflected[:,:,1]-.55)**2/.35))
    env=.27+.35*np.clip(reflected[:,:,1]+.4,0,1)+.50*panel
    rgb=rgb*np.clip(env[...,None],0,1)
   else:rgb=rgb*shade[...,None]
   pixels[y0:y1+1,x0:x1+1][mask]=np.clip(rgb,0,1)[mask]**(1/2.2)
 Image.fromarray(np.rint(pixels*255).astype('uint8'),'RGB').save(path)
def run(e):
 before=sha(e['glb_path']);doc,parts,textures=read(e['glb_path']);o=Q/e['sku'];o.mkdir(exist_ok=True);extent=np.array(e['dimensions_cm'])/100;files=[]
 for label,direction in [('front',[0,.025,1]),('threequarter',[.58,.26,1]),('side',[1,.12,.06]),('rear',[.4,.20,-1])]:
  p=o/(label+'.png');draw(parts,textures,extent,direction,p);files.append(dict(label=label,path=str(p),sha256=sha(p)))
 sheet=Image.new('RGB',(1800,398),(243,240,234));dr=ImageDraw.Draw(sheet)
 for i,p in enumerate([e['original_image']]+[x['path']for x in files]):
  im=Image.open(p).convert('RGB');im.thumbnail((350,350),Image.Resampling.LANCZOS);sheet.paste(im,(i*360+(360-im.width)//2,(350-im.height)//2));dr.text((i*360+8,362),['official reference','GLB front','GLB threequarter','GLB side','GLB rear'][i],fill=(30,30,30))
 sheet.save(o/'comparison.png');assert sha(e['glb_path'])==before
 rec=dict(sku=e['sku'],actual_glb_path=e['glb_path'],glb_sha256=before,glb_unchanged=True,views=files,comparison=str(o/'comparison.png'),renderer='Deterministic GLB software rasterizer; geometry diagnostics, not physical render',limitations=['Clear glazing omitted in geometry diagnostic views','Normal maps not evaluated; mirror uses procedural diagnostic environment. Root browser view required for physical material review.'])
 (o/'render-validation.json').write_text(json.dumps(rec,indent=2));print('QA4',e['sku'],flush=True);return rec
if __name__=='__main__':
 rows=json.loads((R/'manifest.json').read_text());skus=sys.argv[1:];recs=[]
 for e in rows:
  if not skus or e['sku']in skus:recs.append(run(e))
 (Q/'report.json').write_text(json.dumps(recs,indent=2))
