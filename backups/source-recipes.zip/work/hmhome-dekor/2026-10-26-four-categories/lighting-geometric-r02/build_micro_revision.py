"""Four bounded corrections to frozen006, preserving old payloads and maps."""
from pathlib import Path
import sys,json,copy,math,ast,shutil
import numpy as np
P=Path(__file__).resolve().parent.parent;sys.path.insert(0,str(P/'lighting-models'))
import build_lighting as L
R=Path('/private/tmp/hm-lighting-20261028/geometric-r02');R.mkdir(parents=True,exist_ok=True)
if list(R.glob('frozen*manifest*.json')):raise RuntimeError('Frozen correction preserved; create a new revision folder.')
tree=ast.parse((P/'lighting-rice-closed-top-v4/build_revision.py').read_text());ns=dict(L=L,np=np,math=math)
exec(compile(ast.Module(body=[x for x in tree.body if isinstance(x,ast.FunctionDef)and x.name in['finish','append_mesh']],type_ignores=[]),'pure-existing-GLB-append-helpers','exec'),ns)
finish=ns['finish'];append_mesh=ns['append_mesh']
IDS=['1344597001','1344599001','1344564001','1344566001']

def wall_accessories(back):
 def path(turns):
  aa=np.linspace(0,math.tau*turns,1100);rr=np.linspace(.008,.049,len(aa));pp=np.c_[rr*np.sin(aa),.074+rr*np.cos(aa),np.full(len(aa),back+.004)];lead=np.linspace([0,.005,back+.004],pp[0],26,endpoint=False);return np.vstack([lead,pp])
 lo,hi=.01,30
 for _ in range(36):
  mid=(lo+hi)/2;p=path(mid);le=np.linalg.norm(np.diff(p,axis=0),axis=1).sum()
  if le<2.2:lo=mid
  else:hi=mid
 pp=path((lo+hi)/2);pitch=.041/((lo+hi)/2);assert pitch>.0032
 eligible=np.flatnonzero((pp[:,1]>.097)&(np.abs(pp[:,0])<.020));assert len(eligible);pt=pp[eligible[-1]]
 parts=[L.tube('separate-full-220cm-cord-stored-in-front-interior','cable',pp.tolist(),.0016,10),L.RO.box('separate-source-inline-switch-stored-in-upper-interior','black',.026,.012,.008,(float(pt[0]),float(pt[1]),back+.011)),L.RO.box('separate-source-rocker-stored-in-upper-interior','black',.015,.007,.002,(float(pt[0]),float(pt[1]),back+.016))]
 vertices=np.concatenate([g['_vertices']for g in parts]);x,y,z=vertices.T;localz=z-back;radius=.018+.092*y/.125;assert np.all(localz>=.0008);assert np.all(np.abs(x)+localz<radius-.0005),(np.max(np.abs(x)+localz-radius),'Stored cord/switch must stay inside the front triangular cavity')
 return parts,dict(measured_cord_length_m=float(np.linalg.norm(np.diff(pp,axis=0),axis=1).sum()),stored_turn_pitch_m=pitch,minimum_back_plane_clearance_m=float(localz.min()),minimum_front_wall_clearance_m=float(np.min(radius-np.abs(x)-localz)),all_accessories_in_front_interior=True,no_cord_or_switch_behind_mounting_plane=True)

def main():
 rows=[];proof=[];oldrows=json.loads((P/'lighting-geometric-batch-006/frozen-geometric-nine-manifest.json').read_text())
 for e in oldrows:
  if e['sku']not in IDS:continue
  old=copy.deepcopy(e);model=json.loads(Path(old['model_path']).read_text());doc,binary=L.read_glb(old['glb_path']);old_json_sha=L.sha(old['model_path']);old_glb_sha=L.sha(old['glb_path']);iswall=old['sku'].startswith('134459')
  if iswall:
   keep=[i for i,m in enumerate(model['meshes'])if m['name']not in['separate-full-220cm-fabric-cord-stored-parallel-coil','separate-source-black-inline-switch-body','separate-black-inline-rocker']];assert len(keep)==5
   back=float(np.array(model['meshes'][0]['positions']).reshape(-1,3)[:,2].min());new,detail=wall_accessories(back);suffix='-cord-inside-r02'
  else:
   keep=list(range(len(model['meshes'])));new=[L.RO.box('separate-estimated-chrome-upright-to-dome-contact-bracket','chrome',.006,.009,.016,(-.081,.2345,0))];detail=dict(bracket_dimensions_m=[.006,.009,.016],bracket_is_hidden_connection_interpretation=True,bracket_contact_interval_with_upright_y_m=[.230,.232],bracket_contact_interval_with_dome_y_m=[.233,.239],source_description='Own source photo has continuous support at the side rim; local bracket shape is estimated and makes the separate solids physically touch');suffix='-joined-dome-r02'
  completed=[finish(g)for g in new];added=[m for m,c in completed];checks=[c for m,c in completed];retained=[copy.deepcopy(model['meshes'][i])for i in keep]
  p=np.concatenate([np.array(m['positions']).reshape(-1,3)for m in retained+added]);low=p.min(0);high=p.max(0);shift=np.array([(low[0]+high[0])/2,low[1],(low[2]+high[2])/2]);dims=((high-low)*100).tolist()
  for mesh in retained+added:mesh['positions']=(np.array(mesh['positions']).reshape(-1,3)-shift).reshape(-1).tolist()
  # Preserve existing accessor bytes apart from the common origin translation.
  for mi,source_index in enumerate(keep):
   prim=doc['meshes'][source_index]['primitives'][0];acc=doc['accessors'][prim['attributes']['POSITION']];view=doc['bufferViews'][acc['bufferView']];assert not view.get('byteStride');offset=view.get('byteOffset',0)+acc.get('byteOffset',0);arr=np.asarray(retained[mi]['positions'],dtype='<f4').reshape(-1,3);payload=arr.tobytes();binary=binary[:offset]+payload+binary[offset+len(payload):];acc.update(min=arr.min(0).tolist(),max=arr.max(0).tolist())
  doc['meshes']=[doc['meshes'][i]for i in keep];doc['nodes']=[dict(name=m['name'],mesh=i)for i,m in enumerate(doc['meshes'])];mat={m['name']:i for i,m in enumerate(doc['materials'])};new_glb=[]
  for mesh in added:gm,binary=append_mesh(doc,binary,mesh,mat[mesh['material']]);new_glb.append(gm)
  temporary=dict(doc);temporary['meshes']=new_glb;binary=L.G.M.embed_tangents(temporary,binary);doc['meshes']+=new_glb;doc['buffers'][0]['byteLength']=len(binary)
  for i,m in enumerate(new_glb,len(keep)):doc['nodes'].append(dict(name=m['name'],mesh=i))
  fmt=lambda x:format(x,'.6g').replace('.','p');ident='hm-'+old['sku']+'-h'+fmt(dims[1])+'-w'+fmt(dims[0])+'-d'+fmt(dims[2])+suffix;out=R/'models'/ident;out.mkdir(parents=True,exist_ok=True)
  for material in model['materials'].values():
   for key in['baseColorTexture','normalTexture','metallicRoughnessTexture']:
    if key in material:
     src=Path(old['model_path']).parent/material[key];dest=out/material[key];shutil.copyfile(src,dest);assert L.sha(src)==L.sha(dest)
  entry=copy.deepcopy(old);entry.update(id=ident,dimensions_cm=dims,source_dimensions_hwd_cm=[dims[1],dims[0],dims[2]],asset_dir=str(out),model_path=str(out/'model.json'),glb_path=str(out/(ident+'.glb')),model_revision='hm-geometric-bounded-correction-r02-2026-10-28',model_status='pending_root_visual_review',quality_pending=True,micro_revision_evidence=detail)
  if iswall:
   note='Resmî gövde 22 × 12,5 × 11 cm olarak korunmuştur. Tam 220 cm kablo ve anahtar, arka montaj düzleminin önündeki boş iç hacimde sarılı pozda sunulur. Kablo veya anahtar duvarın arkasına geçmez. Ayrı 2,5 mm arka bağlantı levhası nedeniyle bütün modelin derinliği yaklaşık 11,25 cm’dir; bu levha ve depolama pozu tahmindir. G9, azami 4 W LED; ampul dahil değildir. Üretici CAD dosyası değildir.'
   entry['estimated_fields']+=["cord_and_switch_pose_inside_front_cavity","rear_mounting_plate_2p5mm"];entry.update(measured_cord_length_m=detail['measured_cord_length_m'],scale_note=note,diameter_semantics=note);entry['photographed_features']=[x.replace('stored parallel behind fixture','stored inside the front cavity of fixture')for x in entry['photographed_features']]
  else:
   entry['scale_note']+=' Kendi kaynak fotoğrafındaki yan taşıyıcı bağlantısına karşılık, dikey parça ile kubbe kenarını fiziksel olarak birleştiren küçük krom braket eklenmiştir. Braketin 6 × 9 × 16 mm boyutu ve gizli bağlantı biçimi fotoğraf yorumudur; üretici teknik çizimi değildir.';entry['diameter_semantics']=entry['scale_note'];entry['estimated_fields']+=['upright_to_dome_contact_bracket_dimensions_and_profile'];entry['photographed_features']+=['Physically joined side upright and hemisphere rim via a separate small explicitly estimated chrome connector']
  entry['geometry_limitations']=entry['estimated_fields'];metadata=copy.deepcopy(entry)
  for k in['sha256','bytes','asset_dir','model_path','glb_path','geometry_validation','material_validation']:metadata.pop(k,None)
  L.dump(out/'model.json',dict(metadata=metadata,materials=model['materials'],meshes=retained+added));doc['extras']=metadata;doc['scenes'][0]=dict(name=ident,nodes=list(range(len(doc['nodes']))));L.write_glb(entry['glb_path'],doc,binary);entry.update(sha256=L.sha(entry['glb_path']),bytes=Path(entry['glb_path']).stat().st_size,geometry_validation=str(out/'geometry-validation.json'),material_validation=str(out/'material-validation.json'));L.dump(entry['geometry_validation'],dict(valid=True,retained_mesh_indices=keep,common_origin_translation_m=shift.tolist(),retained_shape_normals_uv_indices_unchanged=True,added_meshes=checks,source_or_contact_validation=detail,full_audit=str(R/'native-glb-validation.json')));L.dump(entry['material_validation'],dict(valid=True,all_pngs_byte_identical_to_frozen006=True,no_baked_source_reflections=True));L.dump(out/'entry.json',entry);rows.append(entry)
  proof.append(dict(sku=e['sku'],old_glb_sha256=old_glb_sha,old_model_json_sha256=old_json_sha,old_files_unchanged=L.sha(old['glb_path'])==old_glb_sha and L.sha(old['model_path'])==old_json_sha,new_id=ident,retained_meshes=keep,retained_shapes_unchanged_apart_common_origin_translation=True,common_origin_translation_m=shift.tolist(),all_material_png_bytes_unchanged=True,details=detail));print('BUILT',ident,dims,flush=True)
 L.dump(R/'manifest.json',rows);L.dump(R/'revision-preservation-and-fit-proof.json',proof)

if __name__=='__main__':main()
