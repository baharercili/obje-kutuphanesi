"""Source-only normalized furniture queue; never edits a catalog/model/canonical file."""
from pathlib import Path
import json,re,hashlib,datetime,collections
P=Path(__file__).resolve().parent;E=P/'evidence';OUT=P/'pdp-evidence';OUT.mkdir(exist_ok=True)
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
now=datetime.datetime.now(datetime.timezone.utc).isoformat();records=[];image_links=[]
for f in sorted(E.glob('*.json')):
 data=read(f)
 if not isinstance(data,str):continue
 for piece in re.split(r'-{15,}',data):
  piece=piece.lstrip('\n')
  head=re.search(r'^([^\n]+) \((https://www2\.hm\.com/(en_gb|de_de|tr_tr)/productpage\.(\d{10})\.html)\)\n.*?cite.*?(turn\w+)',piece,re.S)
  if head:
   title,url,market,sku,ref=head.groups();ref=re.search(r'cite([^]+)',piece).group(1);age=re.search(r'Crawled: ([^;]+)',piece);lines='\n'.join(re.sub(r'^L\d+: ?', '',line)for line in piece.splitlines()if re.match(r'^L\d+:',line));anchors=[]
   for m in re.finditer(r'【(\d+)†Image:\s*(.*?)†image\.hm\.com】',lines):
    if not any(x['id']==int(m[1])for x in anchors):anchors.append(dict(ref_id=ref,id=int(m[1]),alt=m[2]))
   identity=bool(re.search(r'(?:Art\.\s*No\.|Art\.-Nr\.|Ürün No\.)\s*:\s*'+sku,lines));records.append(dict(sku=sku,market=market,url=url,page_title=title,source_ref=ref,cache_age=age[1]if age else None,source_kind='official_web_reader_cache',identity_verified=identity,raw_visible_lines=lines,gallery_anchor_refs=anchors,evidence_file=str(f),evidence_sha256=sha(f)))
  click=re.search(r'Source: click\(\{"ref_id":"([^"]+)","id":(\d+)\}',piece)
  image=re.search(r'https://image\.hm\.com/[^\s:]+\.(?:jpe?g|png|webp)(?:\?[^\s:]+)?',piece)
  if click and image:image_links.append(dict(ref_id=click[1],id=int(click[2]),url=image[0],evidence_file=str(f),evidence_sha256=sha(f),resource_fetch_note='URL observed in official image hyperlink; web reader may report image cache miss, not a substituted URL.'))
bindings=E/'galleryURLs-0-290-request-bindings.json'
if bindings.exists():
 requests=read(bindings)
 for f in sorted(E.glob('galleryURLs-*.json')):
  m=re.fullmatch(r'galleryURLs-(\d+)\.json',f.name)
  if not m:continue
  pieces=[x for x in re.split(r'-{15,}',read(f))if 'cite'in x]
  start=int(m[1]);batch=requests[start:start+24]
  assert len(pieces)==len(batch),(f,len(pieces),len(batch))
  for request,piece in zip(batch,pieces):
   image=re.search(r'https://image\.hm\.com/[^\s:]+\.(?:jpe?g|png|webp)(?:\?[^\s:)]+)?',piece)
   assert image,(f,request)
   image_links.append(dict(ref_id=request['ref_id'],id=request['id'],url=image[0],evidence_file=str(f),evidence_sha256=sha(f),request_order_binding_file=str(bindings),resource_fetch_note='Exact official image hyperlink URL returned for this ordered web-tool click; successful image-only tool results omit Source: click, so the saved ordered request list is the binding proof.'))
for bindings in E.glob('galleryURLs-*-request-bindings.json'):
 if bindings.name=='galleryURLs-0-290-request-bindings.json':continue
 f=E/(bindings.name.replace('-request-bindings',''))
 if not f.exists():continue
 requests=read(bindings);pieces=[x for x in re.split(r'-{15,}',read(f))if 'cite'in x]
 assert len(requests)==len(pieces),(f,len(requests),len(pieces))
 for request,piece in zip(requests,pieces):
  image=re.search(r'https://image\.hm\.com/[^\s:]+\.(?:jpe?g|png|webp)(?:\?[^\s:)]+)?',piece)
  assert image,(f,request)
  image_links.append(dict(ref_id=request['ref_id'],id=request['id'],url=image[0],evidence_file=str(f),evidence_sha256=sha(f),request_order_binding_file=str(bindings),resource_fetch_note='Exact official hyperlink returned in ordered click result.'))
by=collections.defaultdict(list)
for r in records:by[(r['market'],r['sku'])].append(r)
partners=['Gallery Direct','ARKET','SOFACOMPANY','WOOOD','Venture Home','Pastill','Petite Amélie','Mica Decorations','vtwonen','In The Mood Collection','Present Time','Häxan','VIND','Jollein']
PDP={};exclusions=[];gallery_queue=[]
for key,rs in by.items():
 market,sku=key;strong=[r for r in rs if r['identity_verified']];best=max(strong or rs,key=lambda r:len(r['raw_visible_lines']));text='\n'.join(dict.fromkeys(r['raw_visible_lines']for r in strong));axis=[]
 for m in re.finditer(r'(?:(Top|Total|Base|Seat|Largest|Smallest):\s*)?(Height|Width|Depth|Length|Diameter|Höhe|Breite|Tiefe|Länge|Durchmesser|Yükseklik|Genişlik|Derinlik|Uzunluk|Çap)(?: of (?:shelf|bracket|table|seat))?:?\s*(\d+(?:[.,]\d+)?)\s*cm',text,re.I):
  qualifier=re.search(r'of (shelf|bracket|table|seat)',m[0],re.I)
  item=dict(axis_label=m[2],value_cm=float(m[3].replace(',','.')),scope_label=m[1]or(qualifier[1]if qualifier else None),verbatim=m[0],source_context=text[max(0,m.start()-130):min(len(text),m.end()+90)])
  if item not in axis:axis.append(item)
 unlabelled=list(dict.fromkeys(m[0]for m in re.finditer(r'\d+(?:[.,]\d+)?\s*[×x]\s*\d+(?:[.,]\d+)?(?:\s*[×x]\s*\d+(?:[.,]\d+)?)?\s*cm',text)))
 descriptions=[];compositions=[];colors=[]
 for r in strong:
  t=r['raw_visible_lines'];m=re.search(r'\n(?:Description|Beschreibung|Açıklama)\n(.*?)\n(?:Art\.\s*No\.|Art\.-Nr\.|Ürün No\.)\s*:',t,re.S)
  if m and m[1].strip()not in descriptions:descriptions.append(m[1].strip())
  m=re.search(r'### (?:Composition|Zusammensetzung|Ürün İçeriği)\n(.*?)(?=\n###|\n(?:Delivery and Payment|Lieferung und Bezahlung|Teslimat ve Ödeme)|$)',t,re.S)
  if m and m[1].strip()not in compositions:compositions.append(m[1].strip())
  m=re.search(r'\n(?:Description|Beschreibung|Açıklama):\n\s*([^\n]+)',t)
  if m and m[1].strip()not in colors:colors.append(m[1].strip())
 gallery_best=max(rs,key=lambda r:len(r['gallery_anchor_refs']));anchors=gallery_best['gallery_anchor_refs'];images=[]
 for a in anchors:
  matches=[x for x in image_links if x['ref_id']==a['ref_id']and x['id']==a['id']]
  for link in matches:
   if not any(x['url']==link['url']for x in images):images.append(dict(url=link['url'],alt=a['alt'],source_pdp_url=best['url'],source_anchor_ref=a,URL_evidence_file=link['evidence_file']))
  if not matches:gallery_queue.append(dict(sku=sku,market=market,pdp_url=best['url'],**a))
 partner=next((brand for brand in partners if (' - '+brand+' - ')in best['page_title']or('| '+brand+' |')in best['page_title']),None)
 row=dict(sku=sku,market=market,url=best['url'],page_title=best['page_title'],identity_verified=bool(strong),current_stock_not_asserted_from_cache=True,source_kind='official_cached_PDP',color_description=colors,official_axis_labels=axis,official_unlabelled_dimension_strings=unlabelled,axes_pending=bool(unlabelled),measurement_context_required=bool(unlabelled or any(sum(a['axis_label']==b['axis_label']and not a['scope_label']for b in axis)>1 for a in axis)),description_statements=descriptions,material_statements=compositions,gallery_images=images,gallery_anchor_count=len(anchors),gallery_URL_scan_complete=bool(anchors and len(images)==len(anchors)),gallery_anchor_refs=anchors,cache_observations=[{k:r[k]for k in['source_ref','cache_age','identity_verified','evidence_file','evidence_sha256']}for r in rs],brand_partner_label=partner,external_fulfillment_mention=bool(re.search('Venture Design',text)),no_axis_or_dimension_inferred=True)
 PDP[key]=row;folder=OUT/market;folder.mkdir(exist_ok=True);dump(folder/(sku+'.json'),row)
 if partner:exclusions.append(dict(sku=sku,market=market,url=best['url'],brand=partner,page_title=best['page_title'],reason='Explicit third-party brand in official PDP heading; not H&M HOME. Fulfillment alone is never an exclusion criterion.',evidence=row['cache_observations']))
live_cards=[];pageproof=[];unfiltered_root_cards=[]
for f in sorted(P.glob('root-*.json')):
 d=read(f)
 if not isinstance(d,dict)or not isinstance(d.get('cards'),list):continue
 url=d.get('url','');market=next((x for x in['en_gb','de_de','tr_tr']if'/'+x+'/'in url),None)
 if not market:continue
 filtered='brandNames=H%26M'in url or 'hm-filter'in f.name
 pageproof.append(dict(path=str(f),sha256=sha(f),url=url,market=market,brand_filtered=filtered,card_count=len(d['cards']),pagination=d.get('pagination'),nextButtons=d.get('nextButtons')))
 for rank,c in enumerate(d['cards'],1):
  m=re.search(r'productpage\.(\d{10})\.html',c.get('url',''))
  if not m:continue
  if not filtered:
   unfiltered_root_cards.append(dict(sku=m[1],market=market,card=c,source_file=str(f),source_sha256=sha(f),status='brand_classification_required_before_live_own_brand_queue'))
   continue
  live_cards.append(dict(sku=m[1],market=market,name=c.get('name'),url=c['url'],card_text=c.get('text'),images=[x for x in c.get('images',[])if str(x.get('url','')).startswith('https://image.hm.com/')],placeholder_image_count=sum(not str(x.get('url','')).startswith('https://image.hm.com/')for x in c.get('images',[])),observed_variant_urls=list(dict.fromkeys(c.get('variants',[]))),brand_filter_verified=filtered,source_file=str(f),source_sha256=sha(f),source_category_url=url,ordinal_within_observation=rank))
queue={}
for c in live_cards:
 sku=c['sku'];e=queue.setdefault(sku,dict(sku=sku,brand='H&M HOME / own H&M Home category',name=c['name'],markets=[],source_category_cards=[],pdp_evidence=[],images=[],variants_scan_complete=False,article_prefix_grouping_only=sku[:7],geometry_family_not_inferred_from_code=True))
 if c['market']not in e['markets']:e['markets'].append(c['market'])
 e['source_category_cards'].append(c)
 p=PDP.get((c['market'],sku))
 if p and p not in e['pdp_evidence']:e['pdp_evidence'].append(p)
 for image in c['images']+(p['gallery_images']if p else[]):
  if not any(x['url']==image['url']for x in e['images']):e['images'].append(image)
for e in queue.values():
 e['identity_verified']=any(p['identity_verified']for p in e['pdp_evidence']);e['official_measurement_available']=any(p['official_axis_labels']or p['official_unlabelled_dimension_strings']for p in e['pdp_evidence']);e['material_available']=any(p['material_statements']for p in e['pdp_evidence']);e['gallery_urls_available']=sum(len(p['gallery_images'])for p in e['pdp_evidence']);e['status']='source_details_and_gallery_available'if e['identity_verified']and e['official_measurement_available']and e['material_available']and e['gallery_urls_available']else'pending_gallery_URLs'if e['identity_verified']and e['official_measurement_available']and e['material_available']else'pending_PDP_details'
dump(P/'unfiltered-root-card-review.json',unfiltered_root_cards)
dump(P/'gallery-anchor-queue.json',gallery_queue);dump(P/'excluded-partner-discovery.json',dict(excluded_records=exclusions,observed_unique_partner_SKUs=len({x['sku']for x in exclusions}),not_a_complete_partner_catalog=True));dump(P/'source-queue.json',dict(observed_at=now,scope='Official H&M own Home furniture, TR+UK+DE only; external brands excluded.',source_only=True,catalog_or_models_modified=False,live_unique_SKUs=len(queue),source_page_observations=pageproof,scan_complete=False,limitations=['Live brand-filter pagination coverage is being reconciled by root.','Cached PDP facts carry their own cache-age labels; not a live stock assertion.','SKU/color variants not yet exhaustively traced beyond observed category/PDP links.','Placeholders are never counted as official JPEG photos.'],products=list(queue.values())))
print(json.dumps(dict(live_unique_SKUs=len(queue),PDP_market_records=len(PDP),verified_PDP_market_records=sum(p['identity_verified']for p in PDP.values()),gallery_anchors_waiting_URL=len(gallery_queue),unique_live_market_SKUs=len({(c['market'],c['sku'])for c in live_cards}),status_counts=dict(collections.Counter(e['status']for e in queue.values())),partner_discovery_SKUs=len({x['sku']for x in exclusions})),ensure_ascii=False),flush=True)
