"""Create a new immutable research snapshot. Does not modify source captures or models."""
from pathlib import Path
import json,re,hashlib,datetime,collections,shutil
P=Path(__file__).resolve().parent
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,d):Path(p).write_text(json.dumps(d,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
S=P/'source-handoff-02'
if S.exists():raise SystemExit('Snapshot exists; create a new version instead of overwriting.')
S.mkdir();(S/'observed-captures').mkdir()
live=read(P/'source-queue.json');q={x['sku']:dict(x)for x in live['products']};pdps=[]
for f in sorted((P/'pdp-evidence').glob('*/*.json')):
 d=read(f)
 if d['brand_partner_label']:continue
 pdps.append(d);e=q.setdefault(d['sku'],dict(sku=d['sku'],name=d['page_title'],brand='H&M HOME / H&M own Home candidate',markets=[],source_category_cards=[],pdp_evidence=[],images=[],variants_scan_complete=False,article_prefix_grouping_only=d['sku'][:7],geometry_family_not_inferred_from_code=True))
 if d['market']not in e['markets']:e['markets'].append(d['market'])
 # Use the current normalized PDP evidence, replacing older copies embedded in working queues.
 e['pdp_evidence']=[x for x in e['pdp_evidence']if x['market']!=d['market']]+[d]
 for im in d['gallery_images']:
  if not any(x['url']==im['url']for x in e['images']):e['images'].append(im)
for e in q.values():
 e['identity_verified']=any(x['identity_verified']for x in e['pdp_evidence']);e['official_measurement_available']=any(x['official_axis_labels']or x['official_unlabelled_dimension_strings']for x in e['pdp_evidence']);e['material_available']=any(x['material_statements']for x in e['pdp_evidence']);e['gallery_urls_available']=len({i['url']for x in e['pdp_evidence']for i in x['gallery_images']});e['live_brand_filtered_market_presence']=sorted({x['market']for x in e['source_category_cards']if x['brand_filter_verified']});e['cached_presence_is_not_live_availability']=True
 e['source_status']='identity_measurement_material_gallery_available'if all(e[k]for k in ['identity_verified','official_measurement_available','material_available','gallery_urls_available'])else'pending_exact_PDP_identity'if not e['identity_verified']else'pending_measurement_material_or_gallery'
 e['measurement_context_required']=any(x['measurement_context_required']for x in e['pdp_evidence']);e['not_ready_for_modeling_without_source_form_review']=True
archive=[]
for f in sorted(P.glob('root-*.json')):
 target=S/'observed-captures'/(f.stem+'-'+sha(f)[:12]+'.json');shutil.copyfile(f,target);assert sha(f)==sha(target)
 archive.append(dict(original_path=str(f),archive_path=str(target),sha256=sha(f)))
rawproof=[dict(path=str(f),sha256=sha(f),bytes=f.stat().st_size)for f in sorted((P/'evidence').glob('*.json'))]
own_brands={'H&M':98,'H&M HOME':21};partners={'ARKET':1,'In The Mood Collection':1,'Mica Decorations':47,'Pastill':180,'Petite Amélie':30,'SOFACOMPANY':61,'Venture Home':271,'VIND':47,'vtwonen':23,'WOOOD':261}
de_brandproof=P/'evidence/de-brand-filter-cache-evidence.json'
assert sum(own_brands.values())+sum(partners.values())==1041
countproof=[]
for f in sorted(P.glob('root-*hm-filter*.json')):
 d=read(f);m=re.search(r'(\d+) Products',d.get('text',''))
 if m:countproof.append(dict(path=str(f),sha256=sha(f),url=d.get('url'),advertised_own_brand_count=int(m[1]),actual_cards=len(d.get('cards',[]))))
coverage=dict(observed_at=now,source_only=True,scan_complete=False,markets=dict(
 en_gb=dict(live_brand_filtered_advertised_count=111,live_unique_observed_SKUs=live['live_unique_SKUs'],missing_live_cards_against_advertised_count=111-live['live_unique_SKUs'],live_count_proof=countproof,live_pagination_problem='Root observed H&M Elevate API/pageSize error on transition to filtered page3; one ordinary reload remained empty. Filtered cache pages3/4 were inaccessible. No bypass/retry loop.',cached_page_numbers_attempted=list(range(1,9)),cached_pages_are_inconsistent_snapshots=True),
 de_de=dict(live_brand_filtered_count=None,live_own_brand_scan_complete=False,cached_own_brand_counts=own_brands,cached_excluded_brand_counts=partners,cached_total=1041,cached_count_reconciles=True,cached_age='4 weeks ago',cached_count_source=dict(path=str(de_brandproof),sha256=sha(de_brandproof),source_ref='turn1499view0'),cached_page_numbers_attempted=list(range(1,31)),cached_pages_are_inconsistent_snapshots=True,required_live_brand_filters=['H&M','H&M HOME']),
 tr_tr=dict(live_empty_state_verified_by_this_agent=False,http_status=403,http_403_is_not_zero_products=True,cached_category_advertised_count=2,cached_category_age='4 days ago',cached_verified_SKUs=['1347782001','1347781001'],cached_PDP_age='6 days ago',conclusion='Current TR zero is unresolved by this agent: public HTTP was access-blocked, while dated official cache contained2 products. Cached presence does not assert current availability.')),
 limitations=['No complete current UK+DE union is claimed until live filtered pagination is reconciled.','Distinct SKU/color codes are separate; article-prefix groups are only hints, never inferred geometry or unobserved variants.','Unlabelled dimensions and component qualifiers remain explicit; no dimensions or axis ordering are invented.','Official image URLs are observed hyperlink values, with original query strings; binary JPEGs were not downloaded or hashed in this research task.','Successful image-only tool results use saved ordered request bindings; a web image cache miss does not mean the hyperlink URL was invented.','Partner counts from different cache dates are not mixed into current live counts.','Venture Design fulfillment is distinct from Venture Home brand; explicit H&M HOME items remain own-brand candidates.'],root_capture_archives=archive)
blocked=[dict(sku=e['sku'],name=e['name'],status=e['source_status'],markets=e['markets'],PDP_urls=[x['url']for x in e['pdp_evidence']],live_card_urls=[x['url']for x in e['source_category_cards']])for e in q.values()if e['source_status']!='identity_measurement_material_gallery_available']
unresolved=read(P/'cached-unresolved-card-anchors.json')
dump(S/'source-queue.json',dict(observed_at=now,source_only=True,scan_complete=False,scope='TR + UK + DE, H&M own Home only; third-party brands excluded.',products=sorted(q.values(),key=lambda x:x['sku']),no_catalog_or_model_changes=True))
dump(S/'coverage-proof.json',coverage)
dump(S/'blockers.json',dict(exact_SKU_blockers=blocked,unresolved_cached_card_anchors=unresolved,missing_live_UK_cards=39,missing_live_DE_filtered_scan=True))
dump(S/'excluded-partners.json',dict(live_GB_count_relay_from_root=dict(all_brands=287,H_and_M=111,Gallery_Direct=173,ARKET=3,reconciles=True,proof_kind='Trusted parent live-browser observation relayed in task messages; raw filter DOM/screenshot not supplied here.'),DE_dated_cache=coverage['markets']['de_de'],individual_PDP_exclusions=read(P/'excluded-partner-discovery.json'),all_excluded_brands_are_out_of_model_scope=True))
dump(S/'raw-evidence-index.json',dict(files=rawproof,root_capture_archives=archive))
for name in ['cached-category-card-observations.json','cached-own-candidate-queue.json','cached-excluded-partner-card-observations.json']:
 shutil.copyfile(P/name,S/name)
# Check every delivered JPEG URL is exact and well formed; never build an image URL from a SKU.
urls={i['url']for e in q.values()for p in e['pdp_evidence']for i in p['gallery_images']}
assert all(re.fullmatch(r'https://image\.hm\.com/[^\s]+\.(?:jpg|jpeg|png|webp)(?:\?[^\s()]+)?',u)for u in urls)
summary=dict(source_only=True,scan_complete=False,scope_SKUs=len(q),verified_exact_SKUs=sum(e['identity_verified']for e in q.values()),source_complete_SKUs=sum(e['source_status']=='identity_measurement_material_gallery_available'for e in q.values()),live_GB_SKUs=live['live_unique_SKUs'],verified_PDP_market_records=sum(p['identity_verified']for p in pdps),exact_unique_gallery_URLs=len(urls),blocked_SKUs=len(blocked),unresolved_cached_card_anchors=len(unresolved),gallery_anchor_URLs_unresolved=len(read(P/'gallery-anchor-queue.json')),models_generated=0,canonical_files_modified=0,raw_evidence_files=len(rawproof))
dump(S/'summary.json',summary)
files=[dict(path=str(f),sha256=sha(f),bytes=f.stat().st_size)for f in sorted(S.rglob('*'))if f.is_file()]
dump(S/'manifest.json',dict(created_at=now,kind='immutable_source_research_snapshot',scope_complete=False,supersedes=str(P/'source-handoff-01/manifest.json'),revision_note='Excluded explicit Jollein brand1336844001 after final brand-title audit; completed1311946001 composition and1341717001 gallery. Original interim snapshot preserved, not silently altered.',summary=summary,files=files))
print(json.dumps(dict(folder=str(S),manifest_sha256=sha(S/'manifest.json'),summary=summary),ensure_ascii=False))
