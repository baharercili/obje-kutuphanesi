"""Four own-source two-tier woven pendants with physically checked compact cable."""
from pathlib import Path
import sys,json,math,ast
import numpy as np
from PIL import Image
P=Path(__file__).resolve().parent.parent;sys.path.insert(0,str(P/'lighting-models'));import build_lighting as L
R=Path('/private/tmp/hm-lighting-20261028/tiered-pendant-four-014');S=Path('/private/tmp/hm-lighting-20261028/tiered-pendant-four-source-review');R.mkdir(parents=True,exist_ok=True);T=math.tau
IDS=['1226657001','1226657002','1226657008','1226657009']
if list(R.glob('frozen*manifest*.json')):raise RuntimeError('Frozen candidates require a separate revision.')
qs={q['sku']:q for q in json.loads((S/'source-facts.json').read_text())};L.sources=lambda:qs;L.R=R;bank0=L.material_bank
for q in qs.values():q['official_measurements']=dict(top_diameter_cm=40,published_height_cm=29.4,cord_length_cm=160)
registry=[x for xs in json.loads((S/'available-masters.json').read_text()).values()for x in xs]
for x in registry:assert L.sha(x['path'])==x['sha256']
L.dump(R/'original-image-masters.json',registry)
for path,names in[(P/'lighting-portable-batch-008/build_portable.py',['closed_lathe','cylinder','rotate','rounded_loop','prism_loops','rounded_box']),(P/'lighting-geometric-batch-006/build_geometric.py',['eholder']),(P/'lighting-glass-batch-007/build_glass.py',['natural_profile']),(P/'lighting-textile-hex-nine-013/build_first_three.py',['gauss','mirror','shell'])]:
 tree=ast.parse(path.read_text());exec(compile(ast.Module(body=[x for x in tree.body if isinstance(x,ast.FunctionDef)and x.name in names],type_ignores=[]),'readonly-pure-hardware-profile','exec'),globals())
SPEC={'1226657001':dict(code='d2c29ae7cb2e',box=[600,300,1112,812],col=[225,218,197],tile=.070),'1226657002':dict(code='4ba99115f7f1',box=[650,600,1162,1112],col=[124,111,99],tile=.065),'1226657008':dict(code='5816efb83901',box=[700,600,1212,1112],col=[158,113,73],tile=.065),'1226657009':dict(code='e287cde0cffe',box=[600,800,1112,1312],col=[111,91,75],tile=.060)}
def compact_cord(length=1.6):
 def pp(turns):
  aa=np.linspace(0,T*turns,1100);rad=np.linspace(.008,.030,len(aa));first=np.c_[rad*np.cos(aa),np.full(len(aa),.514),rad*np.sin(aa)];bb=np.linspace(aa[-1],aa[-1]+T*turns,1100);rad=np.linspace(.030,.008,len(bb));second=np.c_[rad*np.cos(bb),np.full(len(bb),.520),rad*np.sin(bb)];lead=np.vstack([np.linspace((0,.260,0),(0,.514,0),80,endpoint=False),np.linspace((0,.514,0),first[0],10,endpoint=False)]);bridge=np.linspace(first[-1],second[0],10,endpoint=False);end=np.linspace(second[-1],(0,.529,0),25);return np.vstack([lead,first,bridge,second,end])
 lo,hi=.1,12
 for _ in range(45):
  mid=(lo+hi)/2;p=pp(mid);le=np.linalg.norm(np.diff(p,axis=0),axis=1).sum()
  if le<length:lo=mid
  else:hi=mid
 turns=(lo+hi)/2;p=pp(turns);pitch=.022/turns;assert pitch>.0034
 # Radial wall capacity is assessed for the modelled assumed canopy, not claimed as manufacturer capacity.
 coil=p[90:90+1100+10+1100];allow=np.interp(coil[:,1],[.474,.477,.5325,.534],[.004,.005,.051,.052])-.0015;rr=np.linalg.norm(coil[:,[0,2]],axis=1);clearance=float(np.min(allow-rr-.0015));assert clearance>.0008
 return p,float(np.linalg.norm(np.diff(p,axis=0),axis=1).sum()),dict(exact_cord_centreline_length_m=float(np.linalg.norm(np.diff(p,axis=0),axis=1).sum()),two_layer_turns_each=turns,minimum_radial_turn_pitch_m=pitch,cord_diameter_m=.003,modelled_conical_inner_wall_radial_clearance_m=clearance,vertical_layer_centreline_separation_m=.006,assumed_canopy_dimensions_m=[.104,.060,.104],manufacturer_hidden_capacity_unverified=True)
def build(q):
 sku=q['sku'];sp=SPEC[sku];mainR=.20;lowerR=.155;mainY=.066;top=.294;parts=[shell('separate-finite-upper-woven-cylindrical-drum','cloth',mainR,mainR,mainY,top-mainY,.0011),shell('separate-finite-lower-narrow-woven-cylinder','cloth',lowerR,lowerR,0,.090,.0011),shell('separate-upper-white-polystyrene-liner','lining',mainR-.0012,mainR-.0012,mainY+.0002,top-mainY-.0004,.0005),shell('separate-lower-white-polystyrene-liner','lining',lowerR-.0012,lowerR-.0012,.0002,.0896,.0005)]
 for g in parts:
  if g['material']=='cloth':
   radius=mainR if'upper'in g['name']else lowerR;g['_uvs']=[((math.atan2(z,x)/T+.5)*T*radius/(2*sp['tile']),y/(2*sp['tile']))for x,y,z in g['_vertices']]
 # The empty pendant E27 cup faces down, with no bulb included.
 holder=eholder('E27',0)
 for g in holder:g['_vertices']=[(x,.260-y,-z)for x,y,z in g['_vertices']]
 parts+=holder;parts.append(L.B.lathe('separate-interpreted-hollow-central-cord-socket-carrier','white',[(.002,.258),(.0038,.258),(.0038,.294),(.002,.294)],128,True))
 for i,a in enumerate(np.linspace(0,T,3,endpoint=False)):
  for yy,r0,r1,label in[(.272,.005,.1985,'upper-frame'),(.078,.1538,.1985,'lower-tier-frame')]:parts.append(L.tube('separate-estimated-contacting-'+label+'-'+str(i),'white',[(r0*math.cos(a),yy,r0*math.sin(a)),(r1*math.cos(a),yy,r1*math.sin(a))],.0007,8))
 white=[232,231,224];black=sku=='1226657002';rounded=sku=='1226657008';capcolor=[34,33,32]if black else white
 if rounded:
  outer=natural_profile([(.004,.474),(.006,.478),(.015,.485),(.032,.497),(.046,.513),(.052,.527),(.052,.534)],90);inside=outer.copy();inside[:,0]-=.0015;profile=outer.tolist()+inside[::-1].tolist()
 else:profile=[(.004,.474),(.005,.477),(.051,.5325),(.052,.534),(.0505,.534),(.0035,.478),(.0025,.474)]
 parts.append(L.B.lathe('separate-own-rounded-ceiling-cup'if rounded else'separate-own-hollow-conical-ceiling-canopy','canopy',profile,224,True))
 cable,le,proof=compact_cord();parts.append(L.tube('separate-full-160cm-cord-compact-two-layer-canopy-pose','cord',cable.tolist(),.0015,10));parts.append(L.move(rounded_box('separate-official-plastic-cord-switch-hidden-pose-interpreted','switch',.024,.006,.012,.526,.0015),(.020,0,0)));parts.append(L.move(cylinder('separate-interpreted-small-switch-rocker','switch',.003,.532,.001),(.020,0,0)))
 proof.update(sku=sku,canopy_is_own_rounded_cup=rounded,clearance_uses_narrower_conical_lower_bound=True,default_visible_drop_m=.180,source_published_height_m=.294,photo_height_interpreted_as_tiered_shade_not_cord_inclusive=True);L.dump(R/(sku+'-cord-canopy-fit-proof.json'),proof)
 note='Kendi resmî üst çapı 40 cm, yükseklik 29,4 cm ve kablo uzunluğu 160 cm korunur. 29,4 cm kendi fotoğraf oranıyla iki kademeli başlık yüksekliği olarak yorumlanmıştır; kablo dahil kurulum yüksekliği diye ileri sürülmez. Büyük silindir yaklaşık 22,8 cm ve altta görünen kademe 6,6 cm; alt çap yaklaşık 31 cm ve örtüşme fotoğraf tahminidir. Üst açıklık ve görünmeyen iç donanım fotoğraf yorumu; kaynaktan kesin doğrulanamıyor. Kendi kaynakta E27, azami 15 W LED ve plastik anahtarlı kablo yazılıdır; ampul dahil değildir. '+('Bu exact SKU’nun tavan kapağı kendi yakın planındaki yuvarlak cup formudur. 'if rounded else'Bu exact SKU’nun tavan kapağı kendi yakın planındaki konik formdur. ')+'Kapak çapı yaklaşık 10,4 cm ve yüksekliği 6 cm tahmindir. Sunum için görünen askı yaklaşık 18 cm tutulur; tam 160 cm kablonun fazlası kapağın varsayılan boş iç hacminde iki ayrı katmanda sarılıdır. Model boşluğu/kablo çarpışma denetimi geçer; gerçek üretici iç kapasitesi ve gizli anahtar yerleşimi doğrulanmış değildir. Fotoğraf benzeri uzun kurulumda kablo açılabilir; üretici askı ölçüsü diye bu kısa poz kullanılmaz. Her kumaş kendi orijinal 512 piksellik makro kırpımından fiziksel iplik ölçeğinde yorumlanmıştır; kat veya ışık gölgeleri albedoya işlenmez. Bileşim kendi exact SKU kaynağındaki polyester/polistiren/demir oranlarıyla korunur; keten diye değiştirilmez. Üretici CAD dosyası değildir.'
 return parts,dict(target_cm=None,id_suffix='-own-tiered-pendant-r01',official_axes=list(q['official_measurements']),estimated=['published_height_semantics_as_tiered_shade','lower_diameter_cm','two_drum_component_heights_and_overlap','upper_aperture_unverified','finite_cloth_and_PS_liner_thickness','empty_downward_E27_mount_and_frame','canopy_diameter_and_height','compact_drop18cm_and_hidden_coil_pose','manufacturer_canopy_internal_capacity_unverified','hidden_plastic_switch_pose_and_dimensions','native_cloth_repeat_and_optical_parameters'],features=['Own two-tier woven cylinder, separate narrower lower tier and white PS liners','Own distinct rounded or conical canopy and exact full160cm cable in checked assumed interior','Separate downward-facing empty E27 and physically contacting support frame; no bulb/no photo shadows'],material_overrides=dict(cloth=('plastic',sp['col'],.91,0),lining=('plastic',[234,232,222],.75,0),white=('plastic',white,.6,0),canopy=('paint',capcolor,.30,0),cord=('plastic',[26,25,24]if black else[205,207,202],.72,0),switch=('plastic',capcolor,.4,0)),official_socket_type='E27',official_socket_count=1,official_source_max_led_w=15,bulbs_included=False,measured_cord_length_m=le,canopy_cord_fit_proof=proof,fixture_shade_dimensions_cm=[40,29.4,40],posed_scene_dimensions_include_compact_drop_and_canopy=True,quality_label='Askı pozu ve iç kapasite tahminidir',quality_note='Başlık ölçüsü ve tam kablo boyu korunur. Kısa askı, kapak içi kablo yerleşimi ve gizli donanım fotoğraf yorumudur.',source_component_dimension_facts=q['official_dimension_facts'],scale_note_override=note)
def bank(pid,keys,ims,out,overrides=None):
 mats,maps=bank0(pid,keys,ims,out,overrides);sp=SPEC[pid];source=next(x for x in ims if sp['code']in x['path']);patch=Image.open(source['path']).convert('RGB').crop(sp['box']);a=np.array(patch,float);n=patch.width;grey=a.mean(2);ratio=grey/np.maximum(gauss(grey,4),1);rgb=np.array(sp['col'])[None,None,:]*(1+.45*(ratio[:,:,None]-1));detail=grey-gauss(grey,1.5);p95=max(float(np.percentile(np.abs(detail),95)),1);height=np.clip(detail/p95*.000025,-.000050,.000050);rgb=mirror(rgb);h=mirror(height);step=sp['tile']/n;dx=(np.roll(h,-1,1)-np.roll(h,1,1))/(2*step);dy=(np.roll(h,-1,0)-np.roll(h,1,0))/(2*step);nn=np.stack([-dx,-dy,np.ones_like(dx)],2);nn/=np.linalg.norm(nn,axis=2,keepdims=True);orm=np.zeros((2*n,2*n,3),np.uint8);orm[:,:,0]=255;orm[:,:,1]=np.rint(mirror(np.clip(.91-(ratio-1)*.12,.84,.97))*255)
 for slot,arr in [('albedo',np.uint8(np.clip(rgb,0,255))),('normal',np.uint8(np.rint((nn+1)*127.5))),('orm',orm)]:
  path=out/('cloth-'+slot+'.png');Image.fromarray(arr).save(path,optimize=True)
  for rec in maps:
   if rec['material']=='cloth'and rec['slot']==slot:rec.update(sha256=L.sha(path),native_resolution=[2*n,2*n])
 patch.save(out/'own-native-cloth-crop.png');mats['cloth']['normalScale']=.75;mats['cloth']['extras'].update(photo_pixels_baked=True,source_native_material_crop=True,native_resolution=[2*n,2*n],physical_repeat_m_estimated=2*sp['tile'],diffuse_transmission_factor=.12);L.dump(out/'own-cloth-material-provenance.json',dict(master=source['path'],master_sha256=source['sha256'],native_crop_box=sp['box'],native_crop_pixels=[n,n],geometric_resampling_count=0,mirrored_native_tiling=True,no_generated_pixels=True,physical_repeat_m_estimated=2*sp['tile'],interpreted_yarn_relief_p95_m=.000025,illumination_separation='Float Gaussian4 monochrome yarn colour and Gaussian1.5 fine height; broad lighting/step shadows excluded',no_silhouette_background_or_shadow=True))
 return mats,maps
L.BUILD={s:build for s in IDS};L.material_bank=bank
if __name__=='__main__':
 for sku in sys.argv[1:]or IDS:L.build(sku)
