"""Independent byte checks and immutable source preservation for root seven."""
from pathlib import Path
import sys, importlib.util, json, hashlib, subprocess
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parent.parent
R=Path('/private/tmp/hm-lighting-20261028/root-remaining-six-models')
def module(name,path):
    s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
A=module('independent_seven_byte_audit',P/'lighting-paper-models/audit_glb.py')
Q=module('prepare_root_seven_native',P/'lighting-models/prepare_native_qa.py')
rows=json.loads((R/'manifest.json').read_text())
if sys.argv[1:]:rows=[e for e in rows if e['sku'] in sys.argv[1:]]
assert rows and len({e['sku']for e in rows})==len(rows)
checks=[]
for e in rows:
    checks.append(A.run(e))
    if 'measured_cord_length_m'in e:assert abs(e['measured_cord_length_m'] - (2 if e['sku']=='1297367001'else 1.6))<1e-6
    assert not e['bulbs_included']
    print('INDEPENDENT_BYTE_PASS',e['sku'],flush=True)
selected=R/('selected-four-r03.json' if sys.argv[1:] else 'manifest.json')
if sys.argv[1:]:selected.write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
(R/('four-r03-byte-audit.json' if sys.argv[1:] else 'independent-glb-byte-audit.json')).write_text(json.dumps(checks,indent=2)+'\n')
native=Q.prepare(selected,R/'native-qa')
print('NATIVE_MANIFEST',native,flush=True)
