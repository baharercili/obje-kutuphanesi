from pathlib import Path
import sys,json
from PIL import Image,ImageDraw
R=Path(__file__).resolve().parent/sys.argv[1]
rows=json.loads((R/'manifest.json').read_text())
for start in range(0,len(rows),3):
 group=rows[start:start+3];out=Image.new('RGB',(1800,len(group)*500),'#f3f2f0');d=ImageDraw.Draw(out)
 for k,e in enumerate(group):
  for j,key in enumerate(['source','on','on-capraz','yan','arka','ustten']):
   p=Path(e['original_image'])if key=='source'else R/'native-scene-qa'/(e['id']+'-scene0')/(key+'.png');im=Image.open(p).convert('RGBA');im.thumbnail((290,450));bg=Image.new('RGBA',im.size,'#f3f2f0');bg.alpha_composite(im);out.paste(bg.convert('RGB'),(j*300+(300-im.width)//2,k*500+30));d.text((j*300+5,k*500+5),e['sku']+' '+key,fill='black')
 tag=sys.argv[2]if len(sys.argv)>2 else'white';name='qa-source-native-five-comparison-'+tag+'-'+str(start//3+1)+'.jpg';assert not(R/name).exists();out.save(R/name,quality=94);print(R/name)
