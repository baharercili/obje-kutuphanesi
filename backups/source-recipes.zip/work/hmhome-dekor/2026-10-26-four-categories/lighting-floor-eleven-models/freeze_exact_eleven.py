from pathlib import Path
import json,hashlib,datetime
R=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
dump=lambda p,x:Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
target=R/'frozen-exact-eleven-floor-delivery-01-manifest.json';assert not target.exists()
deliveries=json.loads((R/'root-review-inputs.json').read_text());selected={};references=[]
for item in deliveries:
 p=Path(item['manifest_path']);assert sha(p)==item['sha256'];rows=json.loads(p.read_text());include=[];exclude=[]
 for e in rows:
  if e['sku']=='1339269003'and'capsule-three-r01'in str(p):exclude.append(e['sku']);continue
  assert e['sku']not in selected;selected[e['sku']]=e;include.append(e['sku']);references.append(dict(sku=e['sku'],source_frozen_manifest=str(p),source_frozen_manifest_sha256=sha(p),entry_preserved_without_rewriting=True,glb_sha256=e['sha256']))
 item.update(include_skus=include,excluded_superseded_skus=exclude,active_count=len(include))
expected=json.loads((R/'immutable-delegated-source-packet.json').read_text())['skus'];assert set(expected)==set(selected)and len(selected)==11
rows=[selected[s]for s in expected];masters=json.loads((R/'original-image-masters.json').read_text());jpeg_checks=[];actual=[]
for x in masters:
 assert sha(x['path'])==x['sha256'];jpeg_checks.append(dict(path=x['path'],sku=x['sku'],url=x['url'],sha256=x['sha256'],freshly_read=True,original_owner_path=x['original_owner_path'],APFS_clone=x.get('APFS_clone'),encoded_JPEG_alias_identical=x.get('encoded_JPEG_alias_identical',False)))
for e in rows:
 assert sha(e['glb_path'])==e['sha256'];assert Path(e['glb_path']).stat().st_size<96000000;assert len(e['native_five_angles_per_scene'])==10
 auditpath=Path(e['independent_glb_byte_audit']);audit=json.loads(auditpath.read_text());a=next(x for x in audit['models']if x['sku']==e['sku']);assert audit['valid']and a['sha256']==e['sha256']
 mats=json.loads(Path(e['material_validation']).read_text())['maps']
 for m in mats:assert sha(m['path'])==m['sha256']
 actual.append(dict(sku=e['sku'],id=e['id'],glb_path=e['glb_path'],sha256=e['sha256'],fresh_GLB_SHA_verified=True,bytes=e['bytes'],model_json_path=e['model_path'],model_json_sha256=sha(e['model_path']),all_used_maps_fresh_SHA_verified=mats,independent_actual_GLB_audit=dict(path=str(auditpath),sha256=sha(auditpath),valid=True,scope='Per-batch actual embeddedGLB bytes/topology/F32/normals/UV/tangents/maps'),native_five_per_scene=e['native_five_angles_per_scene'],own_material_provenance=dict(path=e['own_material_provenance'],sha256=sha(e['own_material_provenance']))))
dump(target,rows);dump(R/'root-review-inputs.json',deliveries)
receipt=R/'parent-reported-actual-PASS-six-receipt.json';approved=json.loads(receipt.read_text());assert len(approved['six_exact_owned_skus'])==6
for x in approved['six_exact_owned_skus']:assert selected[x['sku']]['sha256']==x['sha256']
proof=R/'frozen-exact-eleven-floor-delivery-01-scope-preservation-proof.json'
dump(proof,dict(status='ALL_ELEVEN_FROZEN_SOURCE_SPECIFIC_CANDIDATES',manifest=dict(path=str(target),sha256=sha(target)),scope_count=11,scope_exact_skus=expected,source_complete=False,category_complete=False,owned_asset_scope_complete=True,root_actual_accepted_six_receipt=dict(path=str(receipt),sha256=sha(receipt)),other_five_root_actual_status_not_assumed=True,original_JPEG_freshly_read_count=len(jpeg_checks),original_exact_sku_count=len({x['sku']for x in jpeg_checks}),originals=jpeg_checks,deferred_nonessential_offloaded_gallery_metadata=str(R/'deferred-offloaded-gallery-current.json'),unused_master_archive_fresh_read_performed=False,source_packet=dict(path=str(R/'immutable-delegated-source-packet.json'),sha256=sha(R/'immutable-delegated-source-packet.json')),source_entry_preservation=references,latest_exact_models=actual,superseded=dict(sku='1339269003',old_batch='capsule-three-r01',reason='Own QA found mirror-star print repetition; print-only R02 replaces it, all old frozen bytes retained',direct_actual_GLB_preservation_proof=dict(path=str(R/'one-dark-print-periodic-r02/direct-old-new-GLB-byte-attribute-and-other-map-preservation.json'),sha256=sha(R/'one-dark-print-periodic-r02/direct-old-new-GLB-byte-attribute-and-other-map-preservation.json'))),old_furniture166_preserved_by_own_write_scope=True,old_furniture166_prior_manifest=dict(path=str(R.parent/'furniture-models/frozen-final166-root-source-reviewed-v13-manifest.json'),prior_sha256='d6cbe0c807e3e4fa1f7f579e987bb880070341a4fc23cb52ce1a01819437dc77',fresh_bulk_GLB_or_JPEG_reread=False),canonical_Git_Site_cloud_write_performed=False,created_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()))
dump(R/'source-scope-final-eleven.json',dict(exclusive_owned_skus=expected,technical_candidate_count=11,root_actual_accepted_count_last_reported=6,other_actual_status_not_assumed=True,all_models_frozen=True,category_complete=False,source_complete=False,manifest_path=str(target),manifest_sha256=sha(target),scope_preservation_proof=str(proof),scope_preservation_proof_sha256=sha(proof)))
dump(R/'production-checkpoint.json',dict(status='EXACT_ELEVEN_FROZEN_DELIVERED_ROOT_ACTUAL_GATE_REMAINING',active_processes=[],scope=expected,exclusive_output_root=str(R),final_manifest=str(target),manifest_sha256=sha(target),scope_proof=str(proof),scope_proof_sha256=sha(proof),accepted_six_exact_GLBS_preserved=True,root_actual_five_status_not_assumed=True,canonical_writes=False,old_furniture_and_frozen_preserved=True,source_complete=False,resume='Only parent-requested bounded actual-visual revisions; never overwrite frozen entries or accepted GLBs',root_review_inputs=str(R/'root-review-inputs.json')))
print(target);print('MANIFEST_SHA',sha(target));print('PROOF_SHA',sha(proof));print('GLB_BYTES',sum(e['bytes']for e in rows));print('SCOPE',len(rows),'OWN_JPEGS_FRESH',len(jpeg_checks),'IMAGES',sum(len(e['native_five_angles_per_scene'])for e in rows))
