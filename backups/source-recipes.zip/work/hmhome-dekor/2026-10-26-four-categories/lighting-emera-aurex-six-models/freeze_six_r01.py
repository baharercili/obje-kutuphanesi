from pathlib import Path
import sys,json,hashlib,subprocess,datetime
sys.dont_write_bytecode=True
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R.parent/'lighting-paper-models'));from audit_glb import run
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
rows=json.loads((R/'manifest.json').read_text());F=R/'frozen-own-emera-aurex-six-r01';F.mkdir(exist_ok=False);frozen=[];copies=[];renders=[]
for e in rows:
 old=Path(e['asset_dir']);new=F/e['sku'];subprocess.run(['/usr/bin/ditto','--clone',str(old),str(new)],check=True)
 for a in old.rglob('*'):
  if a.is_file():b=new/a.relative_to(old);assert sha(a)==sha(b);copies.append(dict(source=str(a),frozen=str(b),sha256=sha(b),bytes=b.stat().st_size))
 x=dict(e)
 for k in ['asset_dir','model_path','glb_path','geometry_validation','material_validation']:
  x[k]=str(new)+str(e[k])[len(str(old)):]
 assert sha(x['glb_path'])==x['sha256'];frozen.append(x)
 for n in['on.png','on-capraz.png','ustten.png','yan.png','arka.png']:
  p=new/n;assert p.exists();renders.append(dict(sku=x['sku'],path=str(p),sha256=sha(p),angle=n))
independent=[run(e)for e in frozen];dump(F/'independent-glb-byte-audit.json',independent);dump(F/'manifest.json',frozen)
for n in ['source-records.json','exact-brand-size-material-electrical-source-facts.json','original-image-masters.json','registered-original-masters.json','native-own-source-contact-r01.jpg','needed-source-hydration-request.json','needed-source-hydration-status.json']:
 subprocess.run(['/usr/bin/ditto','--clone',str(R/n),str(F/n)],check=True);assert sha(R/n)==sha(F/n)
originals=[]
for m in json.loads((R/'original-image-masters.json').read_text()):
 h=sha(m['path']);assert h==m['sha256'];originals.append(dict(sku=m['sku'],path=m['path'],sha256=h,expected=m['sha256'],unchanged=True))
proof=dict(owner='hm_scope_audit',scope_skus=[e['sku']for e in frozen],products=6,GLB_candidates=6,actual_browser_approved=0,ready_model_variants=0,canonical_writes=0,all6_exact_brand_confirmed=True,originals_preserved=originals,full_original_gallery_not_claimed_fresh_hydrated=True,necessary_normal_macOS_hydrations=4,no_network_bypass=True,cloned_files=copies,native_five_angles=renders,independent_GLBarrrays_and_closed_topology_pass=True,no_upscale=True,no_photo_light_bake=True,raw_labeled_official_axes_retained=True,external_cord160cm_explicit_estimate=True,hidden_construction_explicit_interpretation=True,emera_description_linen_blend_vs_PS45PET45Iron10_composition_discrepancy_visible=True,emera_base_diameter10_applied_fabric_cylinder_external_cage_photoestimate=True,emera_top_closed_GB_own_close_photo_confirmed_DE_centre_interpreted=True,unpowered_PBR=True,manufacturing_CAD_or_calibrated_scan_claim=False,manifest_sha256=sha(F/'manifest.json'),all_GLBlower96MiB=True,total_GLB_bytes=sum(e['bytes']for e in frozen),historical_frozen_and_other_lanes_untouched=True,created_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
dump(F/'scope-source-preservation-native-proof.json',proof)
ledger=json.loads((R/'scope-ledger.json').read_text());ledger.update(status='six_technical_candidates_complete_actual_browser_review_pending',produced_candidates=6,actual_browser_approved=0,canonical_writes=0,final_manifest=str(F/'manifest.json'),manifest_sha256=sha(F/'manifest.json'));dump(R/'scope-ledger.json',ledger)
print('FROZEN',F/'manifest.json');print('SHA',sha(F/'manifest.json'));print('PROOF',sha(F/'scope-source-preservation-native-proof.json'));print('BYTES',sum(e['bytes']for e in frozen));print('ORIGINALS',len(originals),'NATIVE',len(renders))
