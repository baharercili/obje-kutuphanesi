from pathlib import Path
import sys,json,hashlib,datetime
sys.dont_write_bytecode=True
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R.parent/'lighting-paper-models'));from audit_glb import run
rows=json.loads((R/'manifest.json').read_text());out=[]
for e in rows:
 out.append(run(e));print('INDEPENDENT',e['sku'],'PASS',flush=True)
(R/'independent-glb-byte-audit-r01.json').write_text(json.dumps(out,indent=2)+'\n');(R/'native-manifest-r01.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
