"""Own exact source/PBR build; output only this delegated six-model directory."""
from pathlib import Path
import sys,json,math,hashlib,copy
sys.dont_write_bytecode=True
import numpy as np
from PIL import Image,ImageFilter,ImageCms
import geometry_own_six as O
R=Path(__file__).resolve().parent;L,B,G=O.L,O.B,O.G;T=math.tau;REV='r01'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
Q={x['sku']:x for x in json.loads((R/'source-records.json').read_text())};MASTERS=json.loads((R/'original-image-masters.json').read_text())
S={
 '1206693001':dict(kind='rattan',fn=O.rattan,name='Örgülü rattan masa lambası · 28,1 cm',hero='265338deceac',token='f1e1c626ae0a',box=[450,200,706,224]),
 '1226315001':dict(kind='fluted',fn=lambda:O.fluted(False),name='Şeffaf oluklu camlı iki katlı avize',hero='8edba6e21382'),
 '1226315002':dict(kind='fluted',fn=lambda:O.fluted(True),name='Bal rengi oluklu camlı iki katlı avize',hero='ebb6c8067232'),
 '1251180001':dict(kind='plastic_petal',fn=O.plastic_petals,name='Kıvrımlı plastik yaprak sarkıt · 44,3 cm',hero='b7c0c576b3ca',token='404d3e47996c',box=[350,1700,478,1828]),
 '1253603001':dict(kind='fabric_petal',fn=O.fabric_petals,name='Altı yapraklı dokuma görünümlü sarkıt · 78 × 81 cm',hero='6152746b6a61',token='034964814286',box=[500,1800,756,2056]),
 '1277548001':dict(kind='hammered',fn=O.hammered_chandelier,name='Üç katlı dövme dokulu cam avize · 57,2 cm',hero='ab22547b0268'),
}
def materials(pid,s,ims,out,keys):
 defs={};provenance=[];ext={};mats={};maps=[];kind=s['kind'];pigment=None
 if 'token'in s:
  m=next(x for x in ims if s['token']in x['path']);im=Image.open(m['path']).convert('RGB');patch=im.crop(s['box']);raw=np.array(patch,float);low=np.array(patch.filter(ImageFilter.GaussianBlur(18 if kind!='rattan'else 8)),float);grain=raw/np.maximum(low,1);pigment=np.percentile(raw,75,axis=(0,1));rgb=np.clip(grain*pigment,0,255);detail=grain.mean(2)-1;dy,dx=np.gradient(detail*(.65 if kind!='rattan'else .50));normal=np.stack([-dx,-dy,np.ones_like(dx)],2);normal/=np.linalg.norm(normal,axis=2,keepdims=True)
  provenance.append(dict(sku=pid,master=m['path'],master_sha256=m['sha256'],native_crop_box=s['box'],native_output_pixels=list(patch.size),upscale=False,no_object_edge_or_background=True,pigment_percentile75_srgb=pigment.tolist(),illumination_removed='Per-channel native low-frequency Gaussian normalization; studio shadow/highlight not copied',physical_repeat_estimate_m=.035 if kind=='rattan'else(.08 if kind=='fabric_petal'else .01)))
  if kind=='rattan':
   palette=np.percentile(raw,[30,45,60,75,88],axis=(0,1));bright=palette.max(0);base=np.clip(grain*bright,0,255)
   for i in range(5):defs['cane'+str(i)]=(base,normal,.77,0);ext['cane'+str(i)]={'factor':np.clip((palette[i]/bright)**2.2,0,1).tolist()+[1]}
  elif kind=='fabric_petal':defs['fabric']=(rgb,normal,.87,0);ext['fabric']={'sheen':[.28,.24,.19]}
  else:
   # Own smooth white plastic native pigment. Broad shadow is excluded;
   # no photograph of a folded/lighted petal is wrapped onto a flat mesh.
   defs['plastic_petal']=(np.broadcast_to(pigment,(16,16,3)).copy(),None,.58,0);ext['plastic_petal']={'diffuse':.25}
 paint=[235,234,227]if kind in['rattan','plastic_petal']else([149,140,119]if kind=='fabric_petal'else[173,174,169])
 cable=[231,231,224]if kind!='hammered'else[197,196,187]
 for k,col,rough,metal in [('paint',paint,.46,0),('metal',[190,191,185],.18,1),('socket',[225,224,215]if kind in['rattan','fluted']else[40,39,36],.49,0),('contact',[169,156,121],.28,1),('cable',cable,.70,0)]:defs[k]=(np.broadcast_to(col,(32,32,3)).astype(float).copy(),None,rough,metal)
 if kind=='fluted':
  defs['glass']=(np.broadcast_to([255,255,255],(16,16,3)).copy(),None,.10,0);ext['glass']={'transmission':.97,'ior':1.50,'thickness':.0012,'attenuation':[1,.78,.46]if pid.endswith('002')else[.96,.99,1],'distance':.003 if pid.endswith('002')else 1.0}
 if kind=='hammered':
  # Reflection in own photographs is evidence of relief only. Actual normal
  # field uses an intrinsic deterministic fine physical bump, albedo stays clear.
  n=128;y,x=np.mgrid[0:n,0:n]/n;v=(np.sin(T*(x*7+y*3))+.65*np.sin(T*(x*13-y*9))+.4*np.cos(T*(x*22+y*17)))*.09;dy,dx=np.gradient(v);nn=np.stack([-dx*5,-dy*5,np.ones_like(dx)],2);nn/=np.linalg.norm(nn,axis=2,keepdims=True);defs['hammer_glass']=(np.broadcast_to([255,255,255],(n,n,3)).copy(),nn,.15,0);ext['hammer_glass']={'transmission':.96,'ior':1.52,'thickness':.0034,'attenuation':[.98,1,1],'distance':.7}
 for key in sorted(keys):
  rgb,nn,rough,metal=defs[key]
  if nn is None:nn=np.broadcast_to([0.,0.,1.],rgb.shape).copy()
  if key=='cable'and kind!='rattan':
   y,x=np.indices(rgb.shape[:2]);v=np.sin((x+y)*T/7)*np.sin((x-y)*T/7);rgb=rgb+v[:,:,None]*1.1;dy,dx=np.gradient(v*.03);nn=np.stack([-dx,-dy,np.ones_like(dx)],2);nn/=np.linalg.norm(nn,axis=2,keepdims=True)
  orm=np.zeros_like(rgb,dtype='uint8');orm[:,:,0]=255;orm[:,:,1]=int(rough*255);orm[:,:,2]=int(metal*255)
  for slot,arr in [('albedo',rgb),('normal',(nn+1)*127.5),('orm',orm)]:
   p=out/(key+'-'+slot+'.png');Image.fromarray(np.clip(arr,0,255).astype('uint8'),'RGB').save(p);maps.append(dict(path=str(p),sha256=sha(p),material=key,slot=slot))
  mats[key]=dict(baseColorFactor=ext.get(key,{}).get('factor',[1,1,1,1]),baseColorTexture=key+'-albedo.png',normalTexture=key+'-normal.png',metallicRoughnessTexture=key+'-orm.png',normalScale=.48 if key in['fabric']or key.startswith('cane')else(.35 if key=='hammer_glass'else .15),metallic=1,roughness=1,alphaMode='OPAQUE',doubleSided=False)
 dump(out/'native-material-provenance.json',dict(native_crops=provenance,glass_images_not_used_for_albedo_or_reflection_or_geometry_height=True,all_glass_relief_physical_interpretation=True,glass_intrinsic_tint_interpreted_not_calibrated=True,no_upscale=True));return mats,maps,ext

def build(pid):
 q=Q[pid];s=S[pid];ims=[m for m in MASTERS if m['sku']==pid]
 for m in ims:assert sha(m['path'])==m['sha256']
 out=R/('candidate-'+REV)/pid;out.mkdir(parents=True,exist_ok=True);assert not any(out.iterdir());print('GEOMETRY_START',pid,flush=True);parts,info=s['fn']();core=np.concatenate([g['_vertices']for g in parts[:info['core_mesh_count']]])
 if s['kind']=='rattan':
  ym=core[:,1].min();fac=.281/np.ptp(core[:,1])
  for g in parts[:info['core_mesh_count']]:g['_vertices']=[(x,(y-ym)*fac,z)for x,y,z in g['_vertices']]
  core=np.concatenate([g['_vertices']for g in parts[:info['core_mesh_count']]])
 pos=np.concatenate([g['_vertices']for g in parts]);lo,hi=pos.min(0),pos.max(0);shift=np.array([(lo[0]+hi[0])/2,lo[1],(lo[2]+hi[2])/2]);meshes=[];checks=[]
 for j,g in enumerate(parts):
  # Remove vertices wholly inside removed real aperture cells; they have no faces.
  used=sorted({i for f in g['_faces']for i in f})
  if len(used)!=len(g['_vertices']):
   mapping={a:b for b,a in enumerate(used)};g['_vertices']=[g['_vertices'][i]for i in used];g['_uvs']=[g['_uvs'][i]for i in used];g['_faces']=[tuple(mapping[i]for i in f)for f in g['_faces']]
  g['_vertices']=[tuple(np.array(v)-shift)for v in g['_vertices']];m,c=L._finalize(G.H.orient(g));meshes.append(m);checks.append(c)
  if j%20==0:print('MESH',pid,j,'/',len(parts),flush=True)
 repairs=G.M.ensure_uv_faces(meshes)+G.H.ensure_float32_uv(meshes);keys={m['material']for m in meshes};mats,maps,ext=materials(pid,s,ims,out,keys);dims=((hi-lo)*100).tolist();core_dims=np.ptp(core,axis=0)*100;ident='hm-'+pid+'-own-rattan-petal-chandelier-'+REV;hero=next(m for m in ims if s['hero']in m['path']);note='Kendi exactSKU resmî marka/ölçü/malzeme/duy ve kablo bilgileri aynı kaynak kayıtlarında tutulur. Kendi orijinal fotoğraflarından profil, adet/örgü ritmi, yerel kalınlık, bağlantı ve optik değerler yorumlandı; fabrikaCAD’i veya kalibre tarama değildir. Gerçek kapalı ince parçalar, boşduy, kendi native tane/pigment ve fiziksel PBR vardır; fotoğraf stüdyo ışığı/gölge/refleksiyonu, unlit/emission ve dahil olmayan ampul eklenmedi. Kablo yayımlanan uzunluğuyla modellenir; sarkıtta artan kısım tahmini göbek iç hacminde saklama pozundadır, bu gizli kapasite fabrika doğrulaması değildir. Gösterilen tam kutu ayrı askı/kablo pozunu da içerir; yayımlanmış armatür/bileşen ölçüsü aşağıda ayrı saklanır.'
 label={'rattan':'Gerçek açık örgü · Ayrı G4 duy','fluted':'Oluklu ince cam · Ölçü eşlemesi yorumlu','fabric_petal':'Kendi dokuma yüzeyi · Ayrı yaprak çerçeveleri','plastic_petal':'Kıvrımlı ince plastik · Ayrı yapraklar','hammered':'Gerçek cam rölyefi · Ayrı tel askılar'}[s['kind']]
 if s['kind']=='fluted':note+=' Kaynakta Height26cm genel etiketi vardır; kendi fotoğrafındaki7,3cm çaplı camların oranıyla bu26cm camlı iki-kat kolgövdesine eşlendi. Kaynak toplam/komponent anlamını açıkça doğrulamaz. Üstteki yaklaşık19cm metalstem,25cm sunumaskısı ve göbek yükseklikleri ayrıca fotoğraforanı/poz tahminidir; tüm model yüksekliği resmî26cm diye sunulmaz. Onmetal kol ve TEKE27 duy resmî tanıma uyar;10duy uydurulmadı.96oluk, duvar ve yandaki pin delikleri kendi yakınplanın yorumudur.'
 if s['kind']=='fabric_petal':note+=' Kendi kaynak yalnızWidth78cm/Depth81cm yayımlar; tüm yükseklikler ve altı yaprak sayısı fotoğraf yorumudur. Kaynak açıklaması fabric derken bileşim polyesterresin%70/demir%30 verir; keten yüzdesi uydurulmadı. Metal çerçeve ayrı, doku kendi native kumaş görünümüdür.'
 if s['kind']=='plastic_petal':note+=' KaynakHeight24cm/Diameter44,3cm plastik armatür yaprak zarfına uygulanır; çap merkezden en büyük radyal uzaklığın iki katıdır, gerçek XZ kutusu ayrıca ölçülür. Onkıvrımlıparça sayısı görünmeyen arkayla birlikte fotoğraf yorumudur. Küçük etkalınlığı, iç taşıyıcı ve duy konumu doğrulanmış fabrika ayrıntısı değildir.'
 if s['kind']=='rattan':note+=' ResmîBaseØ11,6/ ShadeØ15,3/Height28,1cm gerçek örgü zarfında korunur.56dikeyörme ve10dalgalıkenar ritmi fotoğraf yorumudur; her rattan atkı/çözgü ayrı kapalı hacimdir, araları gerçektir. G4iki pinyuvası ayrı boş bırakılmıştır, ampul dahil değildir.'
 if s['kind']=='hammered':note+=' ResmîØ30,2/Height57,2cm camlı üçkatlı gövdeye uygulanır; üst zincir/25cm askı pozu tahmindir. Kaynak square glass prisms derken kendi fotoğrafı uzun dikdörtgen levhalar gösterir; levhalar fotoğraftaki gibi yorumlandı.14/10/6levha adedi fotoğraf tahmini, resmî envanter sayısı değildir. Askı delikleri ve tel halkaları gerçek; cam fotoğrafındaki yansımalar albedo/bump olarak kopyalanmaz, intrinsic dövme rölyefi geometriyle kurulur.'
 official_height={'rattan':28.1,'fluted':26,'plastic_petal':24,'fabric_petal':None,'hammered':57.2}[s['kind']];socket='G4'if s['kind']=='rattan'else'E27';meta=dict(id=ident,sku=pid,name=s['name'],brand='H&M Home',category='Aydınlatma',category_id='lighting',category_slug='aydinlatma',url=q['url'],source_market=q['source_market'],markets=q['markets'],colour=q.get('colour'),official_materials=q['composition'],composition_facts=q['composition_facts'],official_measurements=q['official_measurements'],official_dimension_facts=q['official_dimension_facts'],dimensions_cm=dims,source_dimensions_hwd_cm=[dims[1],dims[0],dims[2]],verified_model_core_dimensions_cm=dict(x=float(core_dims[0]),y=float(core_dims[1]),z=float(core_dims[2])),official_fixture_height_label_cm=official_height,official_socket_type=socket,official_socket_count=1,official_max_LED_watt=info['max_LED_watt'],bulbs_included=False,measured_cord_length_m=info.get('cord_length_m',info.get('cord',{}).get('measured_cord_length_m')),source_images=q['reference_images'],source_evidence_files=q['source_evidence_files']+[str(R/'exact-source-facts.json')],source_size_pointer=str(R/'exact-source-facts.json')+'#sku='+pid,size_source_kind='official_exact_SKU_raw_axes_with_explicit_fixture_component_and_photo_interpretations',size_source_urls=[q['url']],original_image=hero['path'],original_image_url=hero['url'],original_image_sha256=hero['sha256'],original_images=[{k:m[k]for k in['path','url','sha256']}for m in ims],material_label={'rattan':'Rattan / Demir / Plastik kablo','fluted':'Paslanmaz çelik / Oluklu cam','fabric_petal':'Polyester reçine / Demir','plastic_petal':'Plastik / Kaplı bakır kablo','hammered':'Cam / Demir / Kaplı bakır kablo'}[s['kind']],quality_label=label,scale_note=note,estimated_dimensions=True,estimated_fields=['local_profiles_and_detail_counts','wall_and_strand_thickness','unseen_mounts_and_socket_dimensions','intrinsic_optical_values','cord_and_canopy_storage_pose','presentation_suspension_height']+(['Height26_fixture_body_mapping_not_explicit_in_source','extra_metal_stem_height']if s['kind']=='fluted'else[])+(['all_heights_not_published']if s['kind']=='fabric_petal'else[]),units='metres',up_axis='Y',origin='bottom bounding-box centre',component_mapping_notes=info,model_status='pending_root_visual_review',quality_pending=True,ready_model_variants=0,unlit=False,display_state_unpowered=True,baked_reflections=False,complete_category_claim=False)
 dump(out/'model.json',dict(metadata=meta,materials=mats,meshes=meshes));dump(out/'geometry-validation.json',dict(valid=True,mesh_count=len(meshes),triangles=sum(x['triangles']for x in checks),meshes=checks,uv_repairs=repairs,source_geometry_info=info));dump(out/'material-validation.json',dict(valid=True,maps=maps,original_JPEGs_same_SHA=True,no_upscale=True,no_baked_reflections=True,native_renderer_glass_transmission_not_supported_actual_browser_required=True));print('EXPORT',pid,len(meshes),flush=True);report=L.export_assets(out/'model.json',out,ident);glb=out/(ident+'.glb');doc,binary=L.read_glb(glb);binary=G.M.embed_tangents(doc,binary)
 for m in doc['materials']:
  p=ext.get(m['name'],{});ex=m.setdefault('extensions',{})
  if'transmission'in p:
   ex['KHR_materials_transmission']=dict(transmissionFactor=p['transmission']);ex['KHR_materials_ior']=dict(ior=p['ior']);ex['KHR_materials_volume']=dict(thicknessFactor=p['thickness'],attenuationDistance=p['distance'],attenuationColor=p['attenuation'])
  if'diffuse'in p:ex['KHR_materials_diffuse_transmission']=dict(diffuseTransmissionFactor=p['diffuse'],diffuseTransmissionColorFactor=[1,1,1])
  if'sheen'in p:ex['KHR_materials_sheen']=dict(sheenColorFactor=p['sheen'],sheenRoughnessFactor=.9)
  if not ex:m.pop('extensions',None)
 used=set(doc.get('extensionsUsed',[]))
 for m in doc['materials']:used.update(m.get('extensions',{}))
 doc['extensionsUsed']=sorted(used);L.write_glb(glb,doc,binary);assert glb.stat().st_size<96*1024*1024;report['deliverable_sha256']['glb']=sha(glb);report['source_sha256']=sha(out/'model.json');report['glb_bytes']=glb.stat().st_size;dump(report['files']['validation'],report);e=dict(meta,asset_dir=str(out),model_path=str(out/'model.json'),glb_path=str(glb),sha256=sha(glb),bytes=glb.stat().st_size,geometry_validation=str(out/'geometry-validation.json'),material_validation=str(out/'material-validation.json'));dump(out/'entry.json',e);rows=json.loads((R/'manifest.json').read_text())if(R/'manifest.json').exists()else[];dump(R/'manifest.json',[x for x in rows if x['sku']!=pid]+[e]);print('BUILT',pid,e['bytes'],e['sha256'],flush=True)
if __name__=='__main__':
 for pid in sys.argv[1:]or S:build(pid)
