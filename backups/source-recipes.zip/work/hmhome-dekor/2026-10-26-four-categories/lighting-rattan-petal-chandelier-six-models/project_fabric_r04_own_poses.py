"""Read-only geometry-contour projections from immutable candidate GLB arrays."""
from pathlib import Path
import sys,json,struct,hashlib,math
sys.dont_write_bytecode=True
import numpy as np
from PIL import Image,ImageDraw
R=Path(__file__).resolve().parent;e=next(x for x in json.loads((R/'manifest.json').read_text())if x['sku']=='1253603001');out=Path(e['asset_dir']);raw=Path(e['glb_path']).read_bytes();jl=struct.unpack_from('<I',raw,12)[0];d=json.loads(raw[20:20+jl]);b=raw[28+jl:];N=150*41+1
parts=[]
for mesh in d['meshes']:
 if not mesh['name'].startswith('own-R04-alternating'):continue
 a=d['accessors'][mesh['primitives'][0]['attributes']['POSITION']];v=d['bufferViews'][a['bufferView']];p=np.ndarray((a['count'],3),dtype='<f4',buffer=b,offset=v.get('byteOffset',0)+a.get('byteOffset',0),strides=(v.get('byteStride',12),4)).astype(float);mid=(p[:N]+p[N:2*N])/2;edge=[k*41 for k in range(150)]+[N-1]+[k*41+40 for k in range(149,-1,-1)]+list(range(39,0,-1));j=int(mesh['name'].rsplit('-',1)[1]);parts.append((j,mid,edge))
assert len(parts)==6
records=[]
for label,yaw,pitch in [('primary',.02,.20),('lifestyle',math.pi-.35,.17)]:
 right=np.array([math.cos(yaw),0,-math.sin(yaw)]);up=np.array([-math.sin(yaw)*math.sin(pitch),math.cos(pitch),-math.cos(yaw)*math.sin(pitch)]);view=np.array([math.sin(yaw)*math.cos(pitch),math.sin(pitch),math.cos(yaw)*math.cos(pitch)]);shapes=[];allxy=[]
 for j,p,edge in parts:
  xy=np.c_[p@right,-p@up];shapes.append((float(p.mean(0)@view),j,xy,edge));allxy.append(xy)
 xy=np.concatenate(allxy);lo=xy.min(0);hi=xy.max(0);scale=1100/(hi[0]-lo[0]);h=math.ceil((hi[1]-lo[1])*scale)+100;canvas=Image.new('RGB',(1160,h),(248,247,242));dr=ImageDraw.Draw(canvas);dr.text((20,12),label+' own-source-equivalent geometry projection; yaw '+str(round(yaw,3))+' pitch '+str(pitch),fill='black')
 for dep,j,xy,edge in sorted(shapes):
  q=(xy-lo)*scale+[30,55];dr.polygon([tuple(v)for v in q[edge]],fill=(225,214,195)if j%2==0 else(235,229,216),outline=(86,78,65));tip=q[-1];dr.text(tuple(tip+[0,-12]),str(j)+(' lower'if j%2==0 else' upper'),fill='black')
 canvas.save(out/(label+'-actual-GLB-contour-projection.png'));records.append(dict(pose=label,yaw=yaw,pitch=pitch,interpretation='Source framing estimate, not factory angle/camera',geometry_source='Actual unchanged GLB float32 front/back midpoint positions',projection_file=str(out/(label+'-actual-GLB-contour-projection.png'))))
# Native source crops are preserved losslessly, master untouched.
primary=Image.open(R/'originals/1253603001-6152746b6a61.jpg').convert('RGB').crop([100,1080,1440,1570]);life=Image.open(R/'readonly-source-pose-r03/1253603001-lifestyle-immutable.jpg').convert('RGB').crop([170,620,2280,1320]);primary.save(out/'own-primary-native-petal-crop.png');life.save(out/'own-lifestyle-native-petal-crop.png');sheet=Image.new('RGB',(1160,1300),(248,247,242));dr=ImageDraw.Draw(sheet)
for k,(src,label)in enumerate([(primary,'primary'),(life,'lifestyle')]):
 src.thumbnail((1100,280));sheet.paste(src,((1160-src.width)//2,k*650+25));im=Image.open(out/(label+'-actual-GLB-contour-projection.png'));im.thumbnail((1120,300));sheet.paste(im,((1160-im.width)//2,k*650+320));dr.text((15,k*650+4),'Own original photo (display thumbnail only)',fill='black')
sheet.save(out/'own-two-source-vs-actual-geometry-projections.png');(out/'own-two-source-pose-projection-proof.json').write_text(json.dumps(dict(sku=e['sku'],GLB_SHA256=hashlib.sha256(raw).hexdigest(),GLB_not_modified=True,geometric_projections=records,all_leaf_widths_same_source_profile=True,source_confirmed_alternating_3_3_pose=True,photo_estimated_neck_tip_drop_m=[.158 if j%2==0 else .047 for j in range(6)],published_width_depth_m=[.78,.81],own_materials_unchanged_from_R03=True,no_illumination_baked_or_faked=True,diagram_role_colours_not_material_replacement=True),indent=2)+'\n');print(out/'own-two-source-vs-actual-geometry-projections.png')
