from pathlib import Path
import sys,json
sys.dont_write_bytecode=True
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R.parent/'lighting-paper-models'));from audit_glb import run
rows=json.loads((R/'manifest.json').read_text());out=[]
for e in rows:
 if sys.argv[1:]and e['sku']not in sys.argv[1:]:continue
 out.append(run(e));print('BYTEAUDIT',e['sku'],'PASS',flush=True)
path=R/('independent-byte-audit-'+('-'.join(sys.argv[1:])or'all')+'.json');path.write_text(json.dumps(out,indent=2)+'\n');(R/'native-current.json').write_text(json.dumps([e for e in rows if not sys.argv[1:]or e['sku']in sys.argv[1:]],ensure_ascii=False,indent=2)+'\n')
