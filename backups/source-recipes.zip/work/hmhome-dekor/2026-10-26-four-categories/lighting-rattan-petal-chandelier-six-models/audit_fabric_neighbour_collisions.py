"""Read-only actual float32 triangle SAT between distinct physical petals/rims."""
from pathlib import Path
import sys,json,struct,hashlib,itertools,time
sys.dont_write_bytecode=True
import numpy as np
R=Path(__file__).resolve().parent;e=next(x for x in json.loads((R/'manifest.json').read_text()) if x['sku']=='1253603001');raw=Path(e['glb_path']).read_bytes();jl=struct.unpack_from('<I',raw,12)[0];d=json.loads(raw[20:20+jl]);b=raw[28+jl:]
def attr(i):
 a=d['accessors'][i];v=d['bufferViews'][a['bufferView']];dt=np.dtype({5126:'<f4',5125:'<u4',5123:'<u2'}[a['componentType']]);n={'VEC3':3,'SCALAR':1}[a['type']];return np.ndarray((a['count'],n),dtype=dt,buffer=b,offset=v.get('byteOffset',0)+a.get('byteOffset',0),strides=(v.get('byteStride',dt.itemsize*n),dt.itemsize)).copy()
parts=[];cell=.006
for i,m in enumerate(d['meshes']):
 name=m['name']
 if not ('own-R03-smooth' in name or 'fine-coated-iron-petal-rim' in name):continue
 p=m['primitives'][0];v=attr(p['attributes']['POSITION']).astype(float);f=attr(p['indices']).reshape(-1,3);t=v[f];lo=t.min(1);hi=t.max(1);bins={}
 for k,(a,c)in enumerate(zip(np.floor(lo/cell).astype(int),np.floor(hi/cell).astype(int))):
  for key in itertools.product(*(range(a[z],c[z]+1)for z in range(3))):bins.setdefault(key,[]).append(k)
 parts.append(dict(index=i,name=name,petal=int(name.rsplit('-',1)[1]),tri=t,lo=lo,hi=hi,bins=bins))
assert len(parts)==12, 'Expected all6physical petals and6rims';assert set(p['petal']for p in parts)==set(range(6))
def sat(a,b):
 ea=np.roll(a,-1,axis=1)-a;eb=np.roll(b,-1,axis=1)-b;na=np.cross(ea[:,0],ea[:,1]);nb=np.cross(eb[:,0],eb[:,1]);axes=np.concatenate([na[:,None],nb[:,None],np.cross(ea[:,:,None,:],eb[:,None,:,:]).reshape(-1,9,3),np.cross(na[:,None,:],ea),np.cross(nb[:,None,:],eb)],axis=1);norm=np.linalg.norm(axes,axis=2);axes/=np.maximum(norm[:,:,None],1e-30);pa=np.einsum('nvi,nai->nav',a,axes);pb=np.einsum('nvi,nai->nav',b,axes);sep=((pa.max(2)<pb.min(2)-1e-10)|(pb.max(2)<pa.min(2)-1e-10))&(norm>1e-18);return ~sep.any(1)
rows=[];start=time.time();hits=0
for ia,pa in enumerate(parts):
 for pb in parts[ia+1:]:
  if pa['petal']==pb['petal']:continue
  candidates=set()
  for key in pa['bins'].keys() & pb['bins'].keys():
   for x in pa['bins'][key]:
    for y in pb['bins'][key]:candidates.add((x,y))
  if not candidates:continue
  c=np.array(list(candidates),int);mask=((pa['lo'][c[:,0]]<=pb['hi'][c[:,1]]+1e-10)&(pb['lo'][c[:,1]]<=pa['hi'][c[:,0]]+1e-10)).all(1);c=c[mask];found=[]
  for z in range(0,len(c),4000):
   cc=c[z:z+4000];ok=sat(pa['tri'][cc[:,0]],pb['tri'][cc[:,1]]);found+=cc[ok].tolist()
  hits+=len(found);rows.append(dict(mesh_a=pa['name'],mesh_b=pb['name'],exact_bbox_candidate_pairs=len(c),triangle_intersections=len(found),examples=found[:5]))
report=dict(GLB_path=e['glb_path'],GLB_SHA256=hashlib.sha256(raw).hexdigest(),method='All distinct petal/rim actualfloat32 triangles: exact3Dbbox grid broadphase then17axis triangle-triangle SAT including coplanar separating axes; touching tolerance0.1nm.',physical_petal_mesh_count=6,physical_rim_mesh_count=6,total_actual_triangle_count=sum(len(p['tri'])for p in parts),distinct_mesh_pairs_tested=60,nonempty_shared_grid_pairs=len(rows),all_petal_triangle_shells_and_rims_closed_previously_validated=True,same_petal_rim_binding_contact_excluded=True,triangle_intersections=hits,valid=hits==0,rows=rows,seconds=time.time()-start,no_asset_changes=True)
p=Path(e['asset_dir'])/'actual-float32-distinct-petal-intersection-audit.json';p.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:report[k]for k in ['valid','triangle_intersections','seconds','GLB_SHA256']},indent=2));print(p)
