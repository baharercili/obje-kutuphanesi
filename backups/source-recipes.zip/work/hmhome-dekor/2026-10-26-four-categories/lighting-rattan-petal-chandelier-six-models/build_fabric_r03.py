"""Only own1253603001 revision03; no historical/frozen/canonical writes."""
from pathlib import Path
import sys,math,json
sys.dont_write_bytecode=True
import numpy as np
from PIL import Image,ImageFilter
import build_six as A
O=A.O;B=A.B;L=A.L;R=A.R;T=math.tau
A.REV='r03';PID='1253603001';NCOUNTS={}
def closed_smooth_petal(j,a):
 ny,nx=150,40;pts=[];uv=[];faces=[];stride=nx+1;repeat=.045
 # Own teardrop: long slim stem, late broad bulb, truly round pole at the end.
 power=1.35;smax=power/(power+.5);norm=smax**power*math.sqrt(1-smax)
 for k in range(ny):
  t=(1-math.cos(math.pi*k/ny))/2;s=max(0,(t-.20)/.80);w=.0035*math.sqrt(1-t)+.183*s**power*math.sqrt(1-s)/norm
  rad=.024+.381*t;curve=t*t*(3-2*t)
  for i in range(nx+1):
   u=2*i/nx-1;lat=w*u;y=.155-.106*(.18*t+.82*curve)+.0075*u*u*math.sin(math.pi*t)**2
   pts.append((rad*math.cos(a)-lat*math.sin(a),y,rad*math.sin(a)+lat*math.cos(a)));uv.append((lat/repeat,rad/repeat))
 tip=len(pts);pts.append((.405*math.cos(a),.049,.405*math.sin(a)));uv.append((0,.405/repeat));n=len(pts)
 for k in range(ny-1):
  for i in range(nx):
   p=k*stride+i;q=p+1;r=p+stride;s=r+1;faces.extend([(p,q,r),(q,s,r)])
 for i in range(nx):faces.append(((ny-1)*stride+i,(ny-1)*stride+i+1,tip))
 pos=np.array(pts);f=np.array(faces);fn=np.cross(pos[f[:,1]]-pos[f[:,0]],pos[f[:,2]]-pos[f[:,0]]);sn=np.zeros_like(pos)
 for col in range(3):np.add.at(sn,f[:,col],fn)
 sn/=np.maximum(np.linalg.norm(sn,axis=1,keepdims=True),1e-30);assert np.all(sn[:,1]>0)
 th=.00075;v=np.vstack([pos+sn*th/2,pos-sn*th/2]);ff=[tuple(x)for x in f]+[tuple(x+n for x in x[::-1])for x in f]
 edge=[k*stride for k in range(ny)]+[tip]+[k*stride+nx for k in range(ny-1,-1,-1)]+list(range(nx-1,0,-1))
 for k,p in enumerate(edge):q=edge[(k+1)%len(edge)];ff.extend([(p,p+n,q),(q,p+n,q+n)])
 g=B.solid('own-R03-smooth-long-neck-rounded-teardrop-'+str(j),'fabric',[tuple(x)for x in v],ff,uv+uv);g['_surface_vertex_count']=n;NCOUNTS[g['name']]=n
 border=pos[edge];return g,border

def geometry():
 parts=[]
 for j in range(6):
  a=math.pi/2+T*j/6;g,border=closed_smooth_petal(j,a);parts.append(g);parts.append(L.tube('own-photo-fine-coated-iron-petal-rim-'+str(j),'paint',border,.001,10,True));parts.append(L.tube('own-source-petal-neck-metal-spoke-'+str(j),'paint',[(.013*math.cos(a),.155,.013*math.sin(a)),(.045*math.cos(a),.151,.045*math.sin(a))],.002,12))
 parts.append(L.lathe('own-photo-six-spoke-assembly-hub','paint',[(0,.105),(.017,.105),(.017,.170),(.021,.170),(.021,.180),(0,.180)],96));parts+=O.e27(.145,True)
 for j,a in enumerate(np.linspace(0,T,6,endpoint=False)):
  x,z=.015*math.cos(a),.015*math.sin(a);parts.append(B.cylinder('own-source-photo-hub-screw-'+str(j),'metal',.0022,.180,.1813,offset=(x,0,z),n=40))
 parts.append(L.lathe('own-photo-metal-pendant-neck','paint',[(0,.18),(.0042,.18),(.0042,.285),(0,.285)],96));core=len(parts);pp=np.concatenate([g['_vertices']for g in parts]);scale=np.array([.78/np.ptp(pp[:,0]),1,.81/np.ptp(pp[:,2])]);ymin=pp[:,1].min()
 for g in parts:g['_vertices']=[(x*scale[0],y-ymin,z*scale[2])for x,y,z in g['_vertices']]
 c,storage=O.canopy_and_cord(.285-ymin,1.6,.25,.10,.048,'canopy')
 for g in c:
  if 'plastic-cable-gland' in g['name']:g['material']='canopy'
 parts+=c
 return parts,dict(core_mesh_count=core,published_width_depth_m=[.78,.81],all_heights_estimated_from_own_photo=True,petal_count_photo_interpretation=6,finite_petal_thickness_m=.00075,source_resin70_iron30_not_assumed_linen=True,own_native_fabric_surface=True,own_petal_long_neck_fraction=.20,own_photo_rounded_tip_implemented_as_single_pole_not_clipped_edge=True,cross_cup_depth_estimate_m=.0075,top_bottom_surface_normals_exclude_edge_wall_averaging=True,canopy_own_pigment_distinct_from_taupe_hub=True,cord=storage,max_LED_watt=6)

original_finalize=L._finalize
def smooth_finalize(g):
 mesh,check=original_finalize(g)
 if g['name']in NCOUNTS:
  n=NCOUNTS[g['name']];v=np.array(mesh['positions']).reshape(-1,3);f=np.array(mesh['indices']).reshape(-1,3);nn=np.zeros_like(v)
  selected=f[(f.max(1)<n)|(f.min(1)>=n)];fn=np.cross(v[selected[:,1]]-v[selected[:,0]],v[selected[:,2]]-v[selected[:,0]])
  for col in range(3):np.add.at(nn,selected[:,col],fn)
  nn/=np.maximum(np.linalg.norm(nn,axis=1,keepdims=True),1e-30);assert np.all(np.linalg.norm(nn,axis=1)>.99999);mesh['normals']=nn.round(8).reshape(-1).tolist();check['front_back_smooth_surface_normals_without_edge_wall_contamination']=True
 return mesh,check
L._finalize=smooth_finalize
original_materials=A.materials
def materials(pid,s,ims,out,keys):
 mats,maps,ext=original_materials(pid,s,ims,out,keys-{'canopy'})
 # Master-derived intrinsic thread grain; physical derivative scale was missing
 # in R02. This uses the original crop anew, not any earlier edited texture.
 master=next(m for m in ims if '034964814286'in m['path']);im=Image.open(master['path']).convert('RGB');box=[500,1800,756,2056];patch=im.crop(box);raw=np.array(patch,float);low=np.array(patch.filter(ImageFilter.GaussianBlur(32)),float);grain=raw/np.maximum(low,1);pigment=np.percentile(raw,75,axis=(0,1));rgb=np.clip(grain*pigment,0,255)
 height=(grain.mean(2)-1)*.0014;dy,dx=np.gradient(height,.045/256);nn=np.stack([-dx,-dy,np.ones_like(dx)],2);nn/=np.linalg.norm(nn,axis=2,keepdims=True)
 owncanopy=next(m for m in ims if 'ca008bd33615'in m['path']);canopybox=[800,1000,1056,1256];canopyraw=np.array(Image.open(owncanopy['path']).convert('RGB').crop(canopybox),float);canopycol=np.percentile(canopyraw,75,axis=(0,1))
 def put(key,albedo,normal,rough):
  orm=np.zeros_like(albedo,dtype=np.uint8);orm[:,:,0]=255;orm[:,:,1]=round(rough*255)
  for slot,arr in [('albedo',albedo),('normal',(normal+1)*127.5),('orm',orm)]:
   path=out/(key+'-'+slot+'.png');Image.fromarray(np.clip(arr,0,255).astype('uint8'),'RGB').save(path);maps[:]=[m for m in maps if m['path']!=str(path)];maps.append(dict(path=str(path),sha256=A.sha(path),material=key,slot=slot))
 put('fabric',rgb,nn,.86);mats['fabric']['normalScale']=.65
 # Source appears thin fabric/resin; only a restrained interpreted diffuse
 # transmission is provided, never emission/unlit or studio shadow in maps.
 ext['fabric']={'sheen':[.35,.31,.25],'diffuse':.18}
 cc=np.broadcast_to(canopycol,(32,32,3)).copy();flat=np.broadcast_to([0.,0.,1.],cc.shape).copy();put('canopy',cc,flat,.5);mats['canopy']=dict(baseColorFactor=[1,1,1,1],baseColorTexture='canopy-albedo.png',normalTexture='canopy-normal.png',metallicRoughnessTexture='canopy-orm.png',normalScale=0.,metallic=1.,roughness=1.,alphaMode='OPAQUE',doubleSided=False)
 proof=json.loads((out/'native-material-provenance.json').read_text());proof.update(revision='R03 own physical grain and distinct canopy',own_fabric_master_SHA=master['sha256'],native_fabric_crop_box=box,native_crop_pixels=[256,256],native_crop_physical_repeat_estimate_m=.045,intrinsic_height_mapping_m_per_relative_grain=.0014,physical_derivatives_account_for_metres_per_pixel=True,own_canopy_master_SHA=owncanopy['sha256'],own_canopy_crop_box=canopybox,canopy_pigment_srgb=canopycol.tolist(),hub_taupe_srgb_preserved=[149,140,119],diffuse_transmission_factor_photo_interpretation=.18,no_photo_edge_or_background_in_fabric_crop=True,all_original_JPEGs_same_SHA=True)
 A.dump(out/'native-material-provenance.json',proof);return mats,maps,ext
A.materials=materials;A.S[PID]['fn']=geometry
if __name__=='__main__':A.build(PID)
