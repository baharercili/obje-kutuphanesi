from pathlib import Path
import sys,json,hashlib,subprocess,datetime
sys.dont_write_bytecode=True
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R.parent/'lighting-paper-models'));from audit_glb import run
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
label=sys.argv[1];skus=sys.argv[2:];rows={x['sku']:x for x in json.loads((R/'manifest.json').read_text())};F=R/label;F.mkdir(exist_ok=False);entries=[];clones=[];native=[]
for sku in skus:
 e=rows[sku];src=Path(e['asset_dir']);dst=F/sku;assert sha(e['glb_path'])==e['sha256'];subprocess.run(['/usr/bin/ditto','--clone',str(src),str(dst)],check=True)
 for p in src.rglob('*'):
  if p.is_file():q=dst/p.relative_to(src);assert sha(p)==sha(q);clones.append(dict(source=str(p),frozen=str(q),sha256=sha(q)))
 x=dict(e)
 for k in['asset_dir','model_path','glb_path','geometry_validation','material_validation']:x[k]=str(dst)+e[k][len(str(src)):]
 entries.append(x)
 for n in['on.png','on-capraz.png','ustten.png','yan.png','arka.png']:
  p=dst/n;assert p.exists();native.append(dict(sku=sku,path=str(p),sha256=sha(p)))
a=[]
for x in entries:a.append(run(x));print('FROZEN_BYTE',x['sku'],'PASS',flush=True)
dump(F/'manifest.json',entries);dump(F/'independent-glb-byte-audit.json',a)
for n in['source-records.json','exact-source-facts.json','original-image-masters.json','registered-original-masters.json','needed-own-source-hydration-request.json','needed-own-source-hydration-status.json']:
 subprocess.run(['/usr/bin/ditto','--clone',str(R/n),str(F/n)],check=True);assert sha(R/n)==sha(F/n)
originals=[]
for x in entries:
 for m in x['original_images']:
  assert sha(m['path'])==m['sha256'];originals.append(dict(sku=x['sku'],path=m['path'],sha256=m['sha256'],unchanged=True))
proof=dict(owner='hm_scope_audit',scope_skus=skus,products=len(entries),candidate_GLBS=len(entries),root_actual_approved=0,ready_variants=0,canonical_writes=0,total_glb_bytes=sum(x['bytes']for x in entries),all_below96MiB=True,original_JPEG_preservation=originals,native_five_angle_checks=native,native_glass_transmission_not_supported_actual_root_browser_required=True,all_source_axis_component_interpretations_visible=True,raw_source_labels_unchanged=True,no_other_SKU_official_measurement_transfer=True,no_upscale=True,no_photo_shadow_or_reflection_bake=True,physical_PBR_no_emission_unlit=True,all_recursive_extensions_declared=True,cloned_files=clones,historical_frozen_and_other_lanes_unchanged=True,manifest_sha256=sha(F/'manifest.json'),created_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());dump(F/'scope-source-byte-native-preservation-proof.json',proof);print('FROZEN_MANIFEST',F/'manifest.json');print('SHA',sha(F/'manifest.json'));print('PROOF',sha(F/'scope-source-byte-native-preservation-proof.json'))
