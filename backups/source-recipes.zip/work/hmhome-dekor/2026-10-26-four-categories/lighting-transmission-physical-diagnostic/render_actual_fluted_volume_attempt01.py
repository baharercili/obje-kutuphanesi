"""Read-only actual-GLB Mitsuba3 scalar_rgb glass/absorption diagnostic.
Asset positions/normals/UV/indices and embedded PNGs are copied byte-for-byte;
all render intermediates and scenery live only in this diagnostic directory.
"""
from pathlib import Path
import sys,json,struct,hashlib,io,math,time,argparse
sys.dont_write_bytecode=True
import numpy as np
from PIL import Image,ImageDraw
R=Path(__file__).resolve().parent;P=R.parent;sys.path.insert(0,str(R.parents[2]/'bruna-render/runtime'))
import mitsuba as mi
mi.set_variant('scalar_rgb');T=mi.ScalarTransform4f
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def read_glb(path):
 raw=Path(path).read_bytes();magic,version,total=struct.unpack_from('<III',raw);assert magic==0x46546c67 and version==2 and total==len(raw);jl=struct.unpack_from('<I',raw,12)[0];d=json.loads(raw[20:20+jl]);binary=raw[28+jl:]
 def attr(i):
  a=d['accessors'][i];b=d['bufferViews'][a['bufferView']];dt=np.dtype({5126:'<f4',5125:'<u4',5123:'<u2',5121:'u1'}[a['componentType']]);n={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}[a['type']];return np.ndarray((a['count'],n),dtype=dt,buffer=binary,offset=b.get('byteOffset',0)+a.get('byteOffset',0),strides=(b.get('byteStride',dt.itemsize*n),dt.itemsize)).copy()
 return d,binary,attr

def ply(path,p,n,uv,f):
 fields=[('x','<f4'),('y','<f4'),('z','<f4'),('nx','<f4'),('ny','<f4'),('nz','<f4'),('s','<f4'),('t','<f4')];v=np.empty(len(p),dtype=fields);data=np.c_[p,n,uv]
 for i,key in enumerate(v.dtype.names):v[key]=data[:,i]
 faces=np.empty(len(f),dtype=[('n','u1'),('i','<u4',(3,))]);faces['n']=3;faces['i']=f
 head='ply\nformat binary_little_endian 1.0\nelement vertex '+str(len(p))+'\n'+''.join('property float '+key+'\n'for key in v.dtype.names)+'element face '+str(len(f))+'\nproperty list uchar uint vertex_indices\nend_header\n';path.write_bytes(head.encode()+v.tobytes()+faces.tobytes());assert np.array_equal(v['x'],p[:,0])and np.array_equal(v['ny'],n[:,1])and np.array_equal(faces['i'],f)

def srgb_linear(a):return np.where(a<=.04045,a/12.92,((a+.055)/1.055)**2.4)
def bitmap(arr,raw=True):return {'type':'bitmap','bitmap':mi.Bitmap(np.asarray(arr,dtype=np.float32)),'raw':raw,'filter_type':'bilinear','wrap_mode':'repeat'}
def run(e,size,spp):
 out=R/e['sku'];out.mkdir(exist_ok=True);before=sha(e['glb_path']);assert before==e['sha256'];d,binary,attr=read_glb(e['glb_path']);images=[];maps=[]
 for i,img in enumerate(d['images']):
  assert 'uri'not in img;v=d['bufferViews'][img['bufferView']];b=binary[v.get('byteOffset',0):v.get('byteOffset',0)+v['byteLength']];p=out/('embedded-'+str(i)+'.png');p.write_bytes(b);assert sha(p)==hashlib.sha256(b).hexdigest();images.append(np.asarray(Image.open(io.BytesIO(b)).convert('RGB'))/255.);maps.append(dict(index=i,path=str(p),sha256=sha(p),bytes=len(b),asset_bytes_identical=True))
 def texture(slot):return images[d['textures'][slot['index']]['source']]
 scene={'type':'scene','integrator':{'type':'volpath','max_depth':64,'rr_depth':16,'hide_emitters':False},'environment':{'type':'constant','radiance':{'type':'rgb','value':[.30,.30,.30]}}}
 # Neutral clean studio; actual geometry source below is not changed.
 target=[0,.205,0];origin=[.40,.36,.96]
 scene['sensor']={'type':'perspective','fov':30,'to_world':T.look_at(origin=origin,target=target,up=[0,1,0]),'film':{'type':'hdrfilm','width':size,'height':size,'pixel_format':'rgb','rfilter':{'type':'tent'}},'sampler':{'type':'independent','sample_count':spp}}
 scene['floor']={'type':'rectangle','to_world':T.translate([0,-.006,0])@T.rotate([1,0,0],-90)@T.scale([1.8,1.8,1]),'bsdf':{'type':'diffuse','reflectance':{'type':'rgb','value':[.66,.66,.66]}}}
 scene['backdrop']={'type':'rectangle','to_world':T.translate([0,.35,-.65])@T.scale([1.5,1.2,1]),'bsdf':{'type':'diffuse','reflectance':{'type':'rgb','value':[.82,.82,.82]}}}
 for i,(pos,scale,power)in enumerate([([-.65,.85,.60],[.40,.55,1],3.0),([.80,.55,.12],[.30,.50,1],1.8),([0,.90,-.30],[.45,.20,1],2.2)]):scene['light'+str(i)]={'type':'rectangle','to_world':T.look_at(origin=pos,target=target,up=[0,1,0])@T.scale(scale),'emitter':{'type':'area','radiance':{'type':'rgb','value':[power]*3}}}
 for i,(pos,scale,rgb)in enumerate([([-.45,.27,0],[.14,.38,1],[.018]*3),([.48,.28,-.12],[.14,.4,1],[.9]*3),([.32,.28,-.30],[.035,.32,1],[.035]*3)]):scene['reflection_card'+str(i)]={'type':'rectangle','to_world':T.look_at(origin=pos,target=target,up=[0,1,0])@T.scale(scale),'bsdf':{'type':'diffuse','reflectance':{'type':'rgb','value':rgb}}}
 bsdfs=[];media=[];material_log=[]
 for i,m in enumerate(d['materials']):
  pbr=m['pbrMetallicRoughness'];factor=np.array(pbr.get('baseColorFactor',[1,1,1,1]));albedo=srgb_linear(texture(pbr['baseColorTexture']))*factor[:3];orm=texture(pbr['metallicRoughnessTexture']);roughfield=orm[:,:,1]*pbr.get('roughnessFactor',1);metalfield=orm[:,:,2]*pbr.get('metallicFactor',1);assert np.ptp(roughfield)<1e-7 and np.ptp(metalfield)<1e-7;rough=float(roughfield.mean());metal=float(metalfield.mean());ext=m.get('extensions',{});medium=None;log=dict(name=m.get('name'),glTF_material_index=i,roughness_from_actual_G_channel=rough,metallic_from_actual_B_channel=metal,vertex_normals_unchanged=True)
  if'KHR_materials_transmission'in ext:
   trans=float(ext['KHR_materials_transmission'].get('transmissionFactor',0));ior=float(ext.get('KHR_materials_ior',{}).get('ior',1.5));vol=ext.get('KHR_materials_volume',{});atten=np.array(vol.get('attenuationColor',[1,1,1]),float);distance=float(vol.get('attenuationDistance',1e30));sigma=-np.log(np.clip(atten,1e-15,1))/distance
   bs={'type':'roughdielectric','distribution':'ggx','alpha':max(rough*rough,1e-5),'int_ior':ior,'ext_ior':1.,'specular_transmittance':{'type':'rgb','value':[trans]*3}}
   # ConstVolume permits physical unbounded extinction coefficients. Albedo0
   # means pure absorption: sigma_t=sigma_a, sigma_s=0.
   medium=mi.load_dict({'type':'homogeneous','sigma_t':{'type':'constvolume','value':mi.ScalarColor3f(sigma.tolist())},'albedo':0.})
   log.update(renderer_BSDF='roughdielectric GGX',alpha=rough*rough,int_ior=ior,ext_ior=1.,specular_transmittance=trans,actual_geometry_wall_m=.0012,homogeneous_absorption_sigma_a_per_m=sigma.tolist(),sigma_s=[0,0,0],attenuationColor_linear=atten.tolist(),attenuationDistance_m=distance,source_volume_thicknessFactor_not_used_to_replace_actual_mesh_walls=vol.get('thicknessFactor'),true_multiple_refractive_mesh_boundaries=True)
  else:bs={'type':'principled','base_color':bitmap(albedo),'roughness':rough,'metallic':metal};log['renderer_BSDF']='principled actual albedo/ORM'
  if'normalTexture'in m:
   raw=texture(m['normalTexture']);nn=raw*2-1;scale=float(m['normalTexture'].get('scale',1));nn=nn.copy();nn[:,:,:2]*=scale;nn/=np.maximum(np.linalg.norm(nn,axis=2,keepdims=True),1e-20);encoded=(nn+1)/2
   # Evaluate glTF normalScale exactly as a shader in memory; the original
   # embedded PNG and vertex-normal arrays remain byte-identical on disk.
   bs={'type':'normalmap','normalmap':bitmap(encoded),'bsdf':bs};log.update(normalScale_evaluated_in_memory=scale,asset_normal_texture_bytes_unchanged=True)
  bsdfs.append(mi.load_dict(bs));media.append(medium);material_log.append(log)
 shapes=[]
 # Generated assets have baked metre-space vertices and identity glTF nodes.
 for n in d.get('nodes',[]):assert not any(k in n for k in['matrix','translation','rotation','scale'])
 for i,m in enumerate(d['meshes']):
  assert len(m['primitives'])==1;p=m['primitives'][0];pos=attr(p['attributes']['POSITION']);norm=attr(p['attributes']['NORMAL']);uv=attr(p['attributes']['TEXCOORD_0']);faces=attr(p['indices']).reshape(-1,3);path=out/('actual-glb-part-'+str(i)+'.ply');ply(path,pos,norm,uv,faces);j=p['material'];shape={'type':'ply','filename':str(path),'face_normals':False,'bsdf':bsdfs[j]}
  if media[j]is not None:shape['interior']=media[j]
  scene['asset_part'+str(i)]=shape;shapes.append(dict(index=i,name=m['name'],material=d['materials'][j].get('name'),PLY_path=str(path),PLY_SHA256=sha(path),positions_SHA256=hashlib.sha256(pos.tobytes()).hexdigest(),normals_SHA256=hashlib.sha256(norm.tobytes()).hexdigest(),UV_SHA256=hashlib.sha256(uv.tobytes()).hexdigest(),indices_SHA256=hashlib.sha256(faces.tobytes()).hexdigest(),copied_actual_accessor_bits=True,vertices=len(pos),triangles=len(faces),glass_medium_attached=media[j]is not None))
 dump(out/'pre-render-mapping-proof.json',dict(sku=e['sku'],GLB_SHA_before=before,actual_GLBarrrays_unchanged=True,embedded_maps=maps,materials=material_log,shapes=shapes,renderer='Mitsuba3.8 scalar_rgb',integrator='volpath max_depth64 rr_depth16',resolution=[size,size],spp=spp,lighting='Neutral studio area emitters, white/black reflection cards, clean diffuse backdrop; all separate from asset',geometry_units='metres, Y up',camera=dict(origin=origin,target=target,fov=30),source_image=e['original_image'],original_source_SHA=e['original_image_sha256'],no_asset_files_written=True))
 print('BUILD_SCENE',e['sku'],len(shapes),'meshes',flush=True);start=time.time();native=mi.load_dict(scene);print('RENDER_BEGIN',e['sku'],'size',size,'spp',spp,flush=True);render=native.integrator().render(native,sensor=0,spp=spp,seed=39);linear=np.asarray(render);mi.util.write_bitmap(str(out/'physical-volume-linear.exr'),linear);mi.util.write_bitmap(str(out/'physical-volume.png'),linear*.70);assert sha(e['glb_path'])==before;assert sha(e['original_image'])==e['original_image_sha256']
 source=Image.open(e['original_image']).convert('RGB');source.crop([150,350,1386,1900]).save(out/'source-fixture-native-crop.png');result=dict(sku=e['sku'],GLB_SHA_before=before,GLB_SHA_after=sha(e['glb_path']),asset_unchanged=True,source_original_unchanged=True,renderer='Mitsuba3.8 scalar_rgb volpath',samples_per_pixel=spp,resolution=[size,size],max_depth=64,rr_depth=16,render_seconds=time.time()-start,HDR_path=str(out/'physical-volume-linear.exr'),PNG_path=str(out/'physical-volume.png'),display_linear_exposure_factor=.70,display_sRGB=True,normalScale_in_memory_shader_equivalent_only=True,no_geometry_normals_UV_maps_or_GLBartefact_modified=True,scattering=False,absorption_from_GLTF_exact=True,root_optical_approval_pending=True);dump(out/'render-readonly-proof.json',result);print('RENDERED',e['sku'],result['render_seconds'],flush=True);return result
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--size',type=int,default=320);p.add_argument('--spp',type=int,default=32);p.add_argument('skus',nargs='*');args=p.parse_args();entries=json.loads((P/'lighting-rattan-petal-chandelier-six-models/frozen-own-fluted-two-r01/manifest.json').read_text());results=[]
 for e in entries:
  if not args.skus or e['sku']in args.skus:results.append(run(e,args.size,args.spp));dump(R/'render-report.json',results)
 # A side-by-side diagnostic sheet; source is only a native crop for display.
 c=Image.new('RGB',(960,560*len(results)),(238,238,238));dr=ImageDraw.Draw(c)
 for k,x in enumerate(results):
  for j,p in enumerate([Path(x['PNG_path']).parent/'source-fixture-native-crop.png',Path(x['PNG_path'])]):
   im=Image.open(p).convert('RGB');im.thumbnail((470,510));c.paste(im,(j*480+(480-im.width)//2,k*560+30));dr.text((j*480+8,k*560+8),x['sku']+(' own source crop'if j==0 else' actual GLB physical volume'),fill='black')
 c.save(R/'own-source-vs-physical-volume.jpg');print('CONTACT',R/'own-source-vs-physical-volume.jpg',flush=True)
