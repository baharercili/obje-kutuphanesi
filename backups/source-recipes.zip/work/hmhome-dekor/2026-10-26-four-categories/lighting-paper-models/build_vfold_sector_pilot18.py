"""One non-product pilot: nine actual paper folds across three source tiers.
This isolates the cut shoulder, face camber and section depth before another
whole rounded lampshade is generated. It never enters the active SKU manifest.
"""
from pathlib import Path
import sys,json,math,hashlib,importlib.util,shutil
sys.dont_write_bytecode=True
import numpy as np
R=Path(__file__).resolve().parent
sys.path.insert(0,str(R));import build_paper as BASE
sp=importlib.util.spec_from_file_location('readonly_r17_materials',R/'build_rounded_vfold_r17.py');OLD=importlib.util.module_from_spec(sp);sp.loader.exec_module(OLD)
H,B,G=BASE.H,BASE.B,BASE.G;T=math.tau
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def fold(name,a,length,tip_z,fullwidth,ridge,cap_ratio=.12):
 nr=28;nu=24;th=.00035;vv=[];uv=[];ff=[];grids=[]
 # A rounded pair of shallow elliptical cuts remains open at the centre ridge.
 # R18 used.12 from the uncalibrated projected close-up. It is not a measured
 # physical3Dsource ratio; controlled pilots may vary only this parameter.
 # Width peaks before the shoulder and retains a finite paired cut lip.
 for back in (0,1):
  root=len(vv);vv.append((0,.275,-back*th));uv.append((0,0));rings=[]
  for k in range(1,nr+1):
   t=k/nr;profile=t*(1-.36*t**10)/.793;ring=[]
   for j in range(nu+1):
    u=2*j/nu-1;q=2*u+1 if u<=0 else 2*u-1
    endwidth=fullwidth*(1-.36)/.793;cap=endwidth*cap_ratio
    end_r=length-cap*(1-math.sqrt(max(0,1-q*q)));rr=end_r*t;lateral=fullwidth*.5*profile*u
    z=tip_z*t+.016*4*t*(1-t)+ridge*t*(1-abs(u))+.0032*t*math.sin(math.pi*abs(u))-back*th
    ring.append(len(vv));vv.append((rr*math.cos(a)-lateral*math.sin(a),.275+rr*math.sin(a)+lateral*math.cos(a),z));uv.append((rr/.025,lateral/.025))
   rings.append(ring)
  grids.append((root,rings))
 for side,(root,rs)in enumerate(grids):
  f=[(root,rs[0][j],rs[0][j+1])for j in range(nu)]
  for k in range(nr-1):
   for j in range(nu):a,b,c,d=rs[k][j],rs[k][j+1],rs[k+1][j],rs[k+1][j+1];f.extend([(a,c,b),(b,c,d)])
  ff.extend(f if side==0 else[(a,c,b)for a,b,c in f])
 rt,rs=grids[0];st,ss=grids[1];a=[rt]+[r[0]for r in rs]+rs[-1][1:]+[r[-1]for r in rs[-2::-1]];b=[st]+[r[0]for r in ss]+ss[-1][1:]+[r[-1]for r in ss[-2::-1]]
 for j in range(len(a)):
  k=(j+1)%len(a);ff.extend([(a[j],a[k],b[j]),(a[k],b[k],b[j])])
 return B.solid(name,'paper',vv,ff,uv,flat=False)
def main():
 out=R/'pilot18-sector';out.mkdir(exist_ok=False);source=json.loads((R/'frozen-rounded-passive-steel-r15/manifest.json').read_text())[0]
 # Dimensions are explicit source-photo hypotheses, not official depth values.
 configs=[dict(tier=1,radius=.275,tip_z=.020,max_width=.030,ridge=.032,count_hypothesis=56,phase=0),dict(tier=2,radius=.220,tip_z=.105,max_width=.030,ridge=.027,count_hypothesis=56,phase=T/112),dict(tier=3,radius=.15125,tip_z=.180,max_width=.026,ridge=.022,count_hypothesis=42,phase=T/168)]
 parts=[]
 for c in configs:
  for j in[-1,0,1]:
   a=math.pi+j*T/c['count_hypothesis']+c['phase'];parts.append(fold('tier-'+str(c['tier'])+'-physical-V-fold-'+str(j+2),a,c['radius']*(.84 if j==1 else 1),c['tip_z'],c['max_width'],c['ridge']))
 pos=np.concatenate([p['_vertices']for p in parts]);lo=pos.min(0);hi=pos.max(0);cen=np.array([(lo[0]+hi[0])/2,lo[1],(lo[2]+hi[2])/2]);extent=hi-lo;meshes=[];checks=[]
 for g in parts:
  g['_vertices']=[tuple(np.array(v)-cen)for v in g['_vertices']];m,c=H._finalize(G.H.orient(g));meshes.append(m);checks.append(c)
 repairs=G.M.ensure_uv_faces(meshes)+G.H.ensure_float32_uv(meshes);mats,maps,crop=OLD.reused_materials({},source['original_images'],out)
 meta={k:v for k,v in source.items()if k not in['asset_dir','model_path','glb_path','sha256','bytes','geometry_validation','material_validation']}
 meta.update(id='hm-1248079003-V-fold-sector-pilot18',name='V kıvrımı ve üç kat kesiti · İnceleme prototipi',model_revision='partial-nine-fold-pilot18-not-a-whole-product',partial_geometry_prototype=True,complete_product_model=False,model_status='geometry_method_pilot_pending_root_actual_review',ready_model_variants=0,quality_pending=True,dimensions_cm=(extent*100).tolist(),source_dimensions_hwd_cm=[extent[1]*100,extent[0]*100,extent[2]*100],scale_note='Yalnız üç katın dar kesitinde9kâğıt kıvrımı; tam ürün değildir ve kütüphaneye eklenmez.55cm kaynak çapından radyal uzunluklar kurulmuştur; genişlik, çift ovalkesim, yüz kamberi, katların öne çıkması ve iç42/dış56kıvrım hipotezi fotoğrafa dayalı yorumdur. Kaynak resmî derinlik/foldcount yayımlamaz.',photographed_features=['Paired shallow rounded paper cuts with an open central ridge','Width peaks before the shoulder; no single spoon tip and no uniform rectangular strip','Gentle physical face/longitudinal camber and three separately projecting tier tip depths'],estimated_fields=['paper_cut_profile','face_camber','tier_depths','tier_fold_count','paper_wall_thickness'],unlit=False,geometry_limitations=['Partial9foldsector; not a full lampshade, not a measurement or manufacturerCAD.'])
 dump(out/'model.json',dict(metadata=meta,materials=mats,meshes=meshes));dump(out/'geometry-validation.json',dict(valid=True,mesh_count=len(meshes),triangles=sum(c['triangles']for c in checks),meshes=checks,closed_material_solids=True,uv_repairs=repairs));dump(out/'material-validation.json',dict(valid=True,maps=maps,paper_PNGs_and_parameters_identical_to_frozenR15=True,originalJPEGs_unchanged=True))
 report=H.export_assets(out/'model.json',out,meta['id']);glb=out/(meta['id']+'.glb');doc,binary=H.read_glb(glb);binary=G.M.embed_tangents(doc,binary);H.write_glb(glb,doc,binary);report['deliverable_sha256']['glb']=sha(glb);report['glb_bytes']=glb.stat().st_size;dump(Path(report['files']['validation']),report)
 e=dict(meta,asset_dir=str(out),model_path=str(out/'model.json'),glb_path=str(glb),sha256=sha(glb),bytes=glb.stat().st_size,geometry_validation=str(out/'geometry-validation.json'),material_validation=str(out/'material-validation.json'));dump(out/'entry.json',e);dump(out/'manifest.json',[e]);dump(out/'source-to-pilot-hypotheses.json',dict(source_native_crops=str(R/'pilot18-source-analysis/crop-provenance.json'),source_frontal_azimuth_evidence=str(R/'pilot18-source-analysis/source-azimuth-analysis.json'),configs=configs,official_depth_or_fold_count_claimed=False,cut_depth_to_terminal_total_width_ratio=.12,prior_R17_ratio=.25,finite_paper_thickness_m=.00035,tier_depths_diagnostic_not_official=True,previous_frozen_unchanged=True,whole_fixture_not_generated=True))
 print('PILOT18',e['bytes'],e['sha256'],flush=True)
if __name__=='__main__':main()
