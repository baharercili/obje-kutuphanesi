"""One bounded beige revision: narrow open V-cut paper, not closed paddle tips.
The prior frozenR15 and its native pigment/maps remain immutable.
"""
from pathlib import Path
import sys,json,math,hashlib,shutil
sys.dont_write_bytecode=True
import numpy as np
R=Path(__file__).resolve().parent
sys.path.insert(0,str(R))
import build_paper as BASE
H=BASE.H;B=BASE.B;TAU=math.tau
OLD=R/'frozen-rounded-passive-steel-r15/1248079003'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def header(path):
    lines=[]
    with Path(path).open()as f:
        for line in f:
            if line.startswith('  "meshes": ['):break
            lines.append(line)
    text=''.join(lines).rstrip();assert text.endswith(',')
    return json.loads(text[:-1]+'\n}')

def folded_strip(name,angle,radius,centre,root_z,tip_z):
    # End width is ~4.7%of radial length: outer12.9mm, inner7.1mm.
    # The continuous central valley and two planar faces remain open at the
    # double-rounded cut lip. They never collapse into a single smooth point.
    nr=12;nu=16;th=.00035;half_width=radius*.0235
    fold_depth=radius*.047*.60;cap_radius=half_width*.50
    vertices=[];uv=[];faces=[];grids=[]
    for back in (0,1):
        root=len(vertices);vertices.append((0,centre,root_z-back*th));uv.append((0,0));rings=[]
        for k in range(1,nr+1):
            t=k/nr;ring=[]
            for j in range(nu+1):
                u=2*j/nu-1
                # Two semicircular cut lips, one on each folded paper half.
                q=2*u+1 if u<=0 else 2*u-1
                end_r=radius-cap_radius*(1-math.sqrt(max(0,1-q*q)))
                rr=end_r*t;lateral=(rr/radius)*half_width*u
                z=root_z+(tip_z-root_z)*t+.004*(radius/.275)*math.sin(math.pi*t)
                z+=fold_depth*(rr/radius)*abs(u)-back*th
                # Source-neutral slight rotation is retained, but the planar
                # crosssection is not swollen into an oval/spoon surface.
                a=angle+.012*math.sin(7*angle)*t*t
                ring.append(len(vertices));vertices.append((rr*math.cos(a)-lateral*math.sin(a),centre+rr*math.sin(a)+lateral*math.cos(a),z));uv.append((rr/.025,lateral/.025))
            rings.append(ring)
        grids.append((root,rings))
    for side,(root,rings)in enumerate(grids):
        ff=[(root,rings[0][j],rings[0][j+1])for j in range(nu)]
        for k in range(nr-1):
            for j in range(nu):
                a=rings[k][j];b=rings[k][j+1];c=rings[k+1][j];d=rings[k+1][j+1];ff.extend([(a,c,b),(b,c,d)])
        faces.extend(ff if side==0 else[(a,c,b)for a,b,c in ff])
    root,rs=grids[0];rt,ss=grids[1]
    border=[root]+[row[0]for row in rs]+rs[-1][1:]+[row[-1]for row in rs[-2::-1]]
    other=[rt]+[row[0]for row in ss]+ss[-1][1:]+[row[-1]for row in ss[-2::-1]]
    for j in range(len(border)):
        k=(j+1)%len(border);a=border[j];b=border[k];c=other[j];d=other[k];faces.extend([(a,b,c),(b,d,c)])
    return B.solid(name,'paper',vertices,faces,uv,flat=True)

def geometry(spec):
    radius=spec['diameter']/2;centre=radius;root_z=.060;parts=[]
    configs=[(1.,56,-.035,0.),(.80,56,.020,TAU/56),(.55,56,.055,TAU/112)]
    for layer,(scale,count,tip_z,phase)in enumerate(configs):
        for j in range(count):
            a=j*TAU/count+phase;variation=.96+.04*math.cos(7*a+layer*.8)
            if j%2:variation*=.84
            parts.append(folded_strip('tier-'+str(layer+1)+'-narrow-open-V-paper-fold-'+str(j+1),a,radius*scale*variation,centre,root_z,tip_z))
    # SourcePaper90%/Steel10%: passive support only, explicitly hidden-form
    # interpretation. No bulb, electricalsocket or cable set is supplied.
    z=root_z-.004;rad=.016
    parts.append(H.tube('interpreted-passive-rear-steel-shade-mount-ring','steel_mount',[(rad*math.cos(a),centre+rad*math.sin(a),z)for a in np.linspace(0,TAU,96,endpoint=False)],.0007,8,True))
    for j,a in enumerate([math.pi/6,math.pi*7/6]):parts.append(H.tube('interpreted-passive-rear-steel-frame-spoke-'+str(j+1),'steel_mount',[(rad*math.cos(a),centre+rad*math.sin(a),z),(.027*math.cos(a),centre+.027*math.sin(a),z+.001)],.00065,8))
    return parts

def reused_materials(spec,masters,out):
    src=header(OLD/'model.json')['materials'];maps=[]
    for material,m in src.items():
        for key,slot in [('baseColorTexture','albedo'),('normalTexture','normal'),('metallicRoughnessTexture','orm')]:
            name=m[key];p=OLD/name;target=out/name;shutil.copyfile(p,target);assert sha(p)==sha(target)
            maps.append(dict(material=material,slot=slot,path=str(target),sha256=sha(target),original_r15_map=str(p),same_png_bytes=True))
    proof=json.loads((OLD/'native-paper-crop-provenance.json').read_text());dump(out/'native-paper-crop-provenance.json',proof)
    return src,maps,proof

def main():
    BASE.REV='r16';BASE.paper_geometry=geometry;BASE.materials=reused_materials
    e=BASE.run('1248079003');out=Path(e['asset_dir'])
    model=json.loads((out/'model.json').read_text());meta=model['metadata']
    features=['Three distinct tiers of narrow long/short paper folds; count unchanged at56per tier for controlled geometry comparison','Continuous centralVvalley, two planar paper faces, paired rounded cut lips and finite0.35mm axial paper thickness','Separate minimal passive rear steel mount; officialPaper90%/Steel10%; exact hidden mount form/measurements are interpreted','No lightbulb/electricalsocket/cable set, matching sold-separately source']
    meta['photographed_features']=features
    meta['scale_note']+=' Uzun şeritlerin ön eni yaklaşık dışta13mm/içte7mm ve kesilmiş uçta devam edenVkatı fotoğraf oranından yorumlandı; bu enler resmî ölçü değildir. Arka pasif çelik desteğin görünmeyen biçimi ayrıca yorumdur.'
    meta['model_revision']='paper-rounded-narrow-open-V-r16';dump(out/'model.json',model)
    doc,binary=H.read_glb(e['glb_path']);doc['extras']['metadata']=meta;H.write_glb(e['glb_path'],doc,binary)
    g=json.loads((out/'geometry-validation.json').read_text());g['features']=features;dump(out/'geometry-validation.json',g)
    construction=dict(revision='r16',controlled_changes='Width and crosssection/terminal cut; not count-only.',previous_frozen=str(OLD.parent/'manifest.json'),same_count_per_tier=56,long_short_per_tier=[28,28],outer_fold_end_width_mm=12.925,inner_fold_end_width_mm=7.10875,outer_radial_length_mm=275,outer_length_to_end_width_ratio=275/12.925,continuous_terminal_V_depth_mm=7.755,tip_is_not_collapsed_to_one_vertex=True,two_planar_faces=True,paired_round_cut_lips=True,source_photo_ratio_estimates_not_official_dimensions=True,tier_terminal_front_margin_m=dict(middle_over_outer_approx=.029,inner_over_middle_approx=.016),paper_and_steel_PNGs_all_identical_to_frozenR15=True,paper_optics_unchanged=True,originalJPEGs_unchanged=True)
    dump(out/'source-proportion-and-open-V-proof.json',construction)
    e.update(meta);e.update(sha256=sha(e['glb_path']),bytes=Path(e['glb_path']).stat().st_size);dump(out/'entry.json',e)
    rows=json.loads((R/'manifest.json').read_text());rows=[a for a in rows if a['sku']!=e['sku']]+[e];dump(R/'manifest.json',rows)
    p=out/(e['id']+'.validation.json');v=json.loads(p.read_text());v['source_sha256']=sha(out/'model.json');v['deliverable_sha256']['glb']=e['sha256'];v['glb_bytes']=e['bytes'];dump(p,v)
    dump(R/'native-rounded-open-V-r16.json',[e]);print('ROUNDED_OPEN_V_R16',e['bytes'],e['sha256'],flush=True)

if __name__=='__main__':main()
