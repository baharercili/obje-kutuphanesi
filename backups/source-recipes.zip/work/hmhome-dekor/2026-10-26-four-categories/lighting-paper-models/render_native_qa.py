"""Read actual GLB, render four native Mitsuba QA views. Asset masters read-only."""
from pathlib import Path
import sys,json,struct,hashlib,io,math
sys.dont_write_bytecode=True
import numpy as np
from PIL import Image,ImageOps,ImageDraw
sys.path.insert(0,str(Path(__file__).parents[2].parent/'bruna-render/runtime'))
import mitsuba as mi
mi.set_variant('scalar_rgb')
R=Path(__file__).resolve().parent;Q=R/'qa/native';Q.mkdir(parents=True,exist_ok=True)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
T=mi.ScalarTransform4f
def read(path):
 raw=Path(path).read_bytes();jl=struct.unpack_from('<I',raw,12)[0];doc=json.loads(raw[20:20+jl]);binary=raw[28+jl:]
 def attr(i):
  a=doc['accessors'][i];v=doc['bufferViews'][a['bufferView']];dt=np.dtype({5126:'<f4',5125:'<u4',5123:'<u2'}[a['componentType']]);k={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}[a['type']]
  return np.ndarray((a['count'],k),dtype=dt,buffer=binary,offset=v.get('byteOffset',0)+a.get('byteOffset',0),strides=(v.get('byteStride',k*dt.itemsize),dt.itemsize)).copy()
 return doc,binary,attr
def ply(path,p,n,uv,f):
 fields=[('x','<f4'),('y','<f4'),('z','<f4'),('nx','<f4'),('ny','<f4'),('nz','<f4'),('s','<f4'),('t','<f4')];vv=np.empty(len(p),dtype=fields)
 data=np.c_[p,n,uv]
 for i,k in enumerate(vv.dtype.names):vv[k]=data[:,i]
 ff=np.empty(len(f),dtype=[('n','u1'),('i','<u4',(3,))]);ff['n']=3;ff['i']=f
 head='ply\nformat binary_little_endian 1.0\nelement vertex '+str(len(p))+'\n'+''.join('property float '+k+'\n'for k in vv.dtype.names)+'element face '+str(len(f))+'\nproperty list uchar uint vertex_indices\nend_header\n'
 path.write_bytes(head.encode()+vv.tobytes()+ff.tobytes())
def run(e):
 out=Q/e['sku'];out.mkdir(exist_ok=True);before=sha(e['glb_path']);doc,binary,attr=read(e['glb_path']);a=Path(e['asset_dir']);model=json.loads(Path(e['model_path']).read_text())
 scene={'type':'scene','integrator':{'type':'path','max_depth':6},'environment':{'type':'constant','radiance':{'type':'rgb','value':[.60,.60,.60]}}}
 dims=np.array(e['dimensions_cm'])/100;span=max(dims);target=np.array([0,dims[1]*.50,0])
 for i,(direction,label)in enumerate([([0,.04,1],'front'),([.65,.28,1],'threequarter'),([1,.12,.06],'side'),([.5,.22,-1],'rear')]):
  d=np.array(direction);d=d/np.linalg.norm(d);origin=target+d*span*2.2
  scene['sensor'+str(i)]={'type':'perspective','fov':35,'to_world':T.look_at(origin=origin.tolist(),target=target.tolist(),up=[0,1,0]),'film':{'type':'hdrfilm','width':320,'height':320,'pixel_format':'rgb','rfilter':{'type':'box'}},'sampler':{'type':'independent','sample_count':8}}
 for i,(origin,scale,power)in enumerate([([-1.5,2,2],[1.2,1.6,1],5),([1.8,1,1],[.8,1.4,1],3),([0,2,-1],[1.4,.8,1],4)]):
  p=target+np.array(origin)*span
  scene['light'+str(i)]={'type':'rectangle','to_world':T.look_at(origin=p.tolist(),target=target.tolist(),up=[0,1,0])@T.scale((np.array(scale)*span).tolist()),'emitter':{'type':'area','radiance':{'type':'rgb','value':[power]*3}}}
 # Ground is separate QA scenery, never part of the asset.
 scene['floor']={'type':'rectangle','to_world':T.rotate([1,0,0],-90)@T.scale([span*5,span*5,1]),'bsdf':{'type':'diffuse','reflectance':{'type':'rgb','value':[.63,.62,.59]}}}
 for mi0,m in enumerate(doc['meshes']):
  pr=m['primitives'][0];p=attr(pr['attributes']['POSITION']);norm=attr(pr['attributes']['NORMAL']);uv=attr(pr['attributes']['TEXCOORD_0']);f=attr(pr['indices']).reshape(-1,3)
  path=out/('part-'+str(mi0)+'.ply');ply(path,p,norm,uv,f)
  ma=doc['materials'][pr['material']];name=ma['name'];src=model['materials'][name];orm=np.asarray(Image.open(a/src['metallicRoughnessTexture']));rough=float(orm[:,:,1].mean()/255);metal=float(orm[:,:,2].mean()/255)
  bs={'type':'principled','base_color':{'type':'bitmap','filename':str(a/src['baseColorTexture']),'raw':False,'filter_type':'bilinear','wrap_mode':'repeat'},'roughness':rough,'metallic':metal}
  if src.get('transmission',0)>0:bs.update(spec_trans=src['transmission'],eta=src.get('ior',1.49))
  if src.get('clearcoat',0)>0:bs.update(clearcoat=src['clearcoat'],clearcoat_gloss=1-src.get('clearcoatRoughness',.1))
  scene['part'+str(mi0)]={'type':'ply','filename':str(path),'bsdf':bs}
 native=mi.load_dict(scene);files=[]
 for i,label in enumerate(['front','threequarter','side','rear']):
  path=out/(label+'.png')
  im=native.integrator().render(native,sensor=i,spp=8,seed=12+i);mi.util.write_bitmap(str(path),im);files.append(dict(label=label,path=str(path),sha256=sha(path)))
 assert sha(e['glb_path'])==before
 sheet=Image.new('RGB',(1600,350),(243,240,234));draw=ImageDraw.Draw(sheet);paths=[e['original_image']]+[x['path']for x in files]
 for i,p in enumerate(paths):
  im=Image.open(p).convert('RGB');im.thumbnail((310,310),Image.Resampling.LANCZOS);sheet.paste(im,(i*320+(320-im.width)//2,(310-im.height)//2));draw.text((i*320+8,318),['official reference','GLB front','GLB threequarter','GLB side','GLB rear'][i],fill=(25,25,25))
 sheet.save(out/'comparison.png')
 result=dict(sku=e['sku'],glb_path=e['glb_path'],glb_sha256=before,glb_unchanged=sha(e['glb_path'])==before,renderer='Mitsuba3 scalar_rgb native path tracer',geometry_source='Actual exported GLB accessor bytes',resolution=[320,320],samples_per_pixel=8,views=files,comparison=str(out/'comparison.png'),note='QA renderer approximates glTF physical material with principled BSDF; local display lighting only. Asset is unchanged.')
 (out/'render-validation.json').write_text(json.dumps(result,indent=2));print('RENDERED',e['sku'],flush=True);return result
if __name__=='__main__':
 entries=json.loads((R/'manifest.json').read_text());skus=sys.argv[1:];results=[]
 for e in entries:
  if not skus or e['sku']in skus:results.append(run(e))
 (Q/'render-report.json').write_text(json.dumps(results,indent=2))
