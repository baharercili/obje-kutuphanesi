"""Own white paper after root accepted corrected beige fold method.
The accepted beige GLB and PNGs are read-only; own paper maps are rebuilt from
the previously verified native white32px crop, not recoloured beige textures.
"""
from pathlib import Path
import sys,json,hashlib,subprocess
sys.dont_write_bytecode=True
import numpy as np
from PIL import Image,ImageFilter
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R));import build_paper as A
L=A.H;sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def main():
 sku='1248079001';src=R/'frozen-full-beige-diameter55-UVpreserved-r23/1248079003';out=R/'candidate-r24'/sku;out.mkdir(parents=True,exist_ok=False);model=json.loads((src/'model.json').read_text());queue=json.loads((R.parent/'lighting-research/confirmed-queue.research-final-02.json').read_text());q=next(x for x in queue if x['sku']==sku);registry=json.loads((R.parent/'lighting-models/original-image-masters.json').read_text());allims=[x for x in registry if x['sku']==sku];ims=[x for x in allims if not(Path(x['path']).stat().st_flags&0x40000000)]
 for m in ims:assert sha(m['path'])==m['sha256']
 assert len(ims)>=2
 plan=json.loads((R/'white9001-source-prep-2026-10-28/source-specific-plan.json').read_text());crop=Path(plan['native_crop']['derived_crop']);assert sha(crop)==plan['native_crop']['derived_crop_sha256'];im=Image.open(crop).convert('RGB');raw=np.array(im,float);low=np.array(im.filter(ImageFilter.GaussianBlur(4)),float);pigment=np.array([240,239,236]);rgb=np.clip(raw/np.maximum(low,1)*pigment,0,255);grain=(raw-low).mean(2);dy,dx=np.gradient(grain*.01);nn=np.stack([-dx,-dy,np.ones_like(dx)],2);nn/=np.linalg.norm(nn,axis=2,keepdims=True);orm=np.zeros_like(raw,dtype=np.uint8);orm[:,:,0]=255;orm[:,:,1]=np.clip(225+grain*.3,218,232).astype('uint8')
 maps=[]
 for slot,data in [('albedo',rgb),('normal',(nn+1)*127.5),('orm',orm)]:
  p=out/('paper-'+slot+'.png');Image.fromarray(np.clip(data,0,255).astype('uint8'),'RGB').save(p);maps.append(dict(path=str(p),sha256=sha(p),own_white_native_crop=True,upscale=False))
 for slot in['albedo','normal','orm']:
  p=src/('steel-'+slot+'.png');subprocess.run(['/usr/bin/ditto','--clone',str(p),str(out/p.name)],check=True)
 meta=model['metadata'];ident='hm-'+sku+'-white-paper-r24-d55';meta.update(id=ident,sku=sku,name='Katlı beyaz kâğıt abajur · 55 cm',url=q['url'],source_market=q['source_market'],markets=q['markets'],colour=q.get('colour','White'),official_materials=q.get('composition')or q.get('composition_facts'),source_evidence_files=q['source_evidence_files'],source_images=q['gallery_images'],original_image=ims[0]['path'],original_image_url=ims[0]['url'],original_image_sha256=ims[0]['sha256'],original_images=[{k:m[k]for k in['path','url','sha256']}for m in ims],source_size_pointer=str(R.parent/'lighting-research/confirmed-queue.research-final-02.json')+'#sku='+sku,model_revision='own-white-three-tier-physical-paper-r24',model_status='pending_root_visual_review',quality_pending=True,ready_model_variants=0,scale_note='Resmî55cm çap, kâğıt noktalarının kat merkezine azami uzaklığının iki katına uygulanır. Gerçek XY kutu eni/yüksekliği ayrıca ölçülür. Üç kat, uzun/kısa kıvrım ritmi ve çift yuvarlak uç, onaylanan fiziksel yöntemle kendi beyaz ürün fotoğraflarına yaklaşık yorumlanmıştır; resmî kat sayısı veya CAD değildir. Derinlik,0,35mm aksiyel kâğıt kalınlığı, görünmeyen arka pasif çelik desteğin geometrisi ve optik değerler tahmindir. Kâğıt haritaları bu SKU’nun daha önce piksel eşitliğiyle doğrulanan32×32 native cropundan üretildi; bej kaplaması renklendirilmedi. Küçük beyazlık/ambient renk düzeltmesi optik yorumdur, fotoğraf ışığı/gölgesi/refleksiyonu bake edilmedi. Duy/ampul/kablo seti ayrı satıldığından eklenmedi.',photographed_features=['Own white source: three visible tiers and long/short paired rounded V folds','Corrected maximum radial55cm diameter; separate XY envelope and estimated depth','Own native white paper grain; minimal passive steel mount interpreted; no supplied cable/socket/bulb'])
 meta.pop('historical_r21_scale_interpretation',None);meta['source_crop_archival_master']=dict(path=plan['native_crop']['master'],sha256=plan['native_crop']['master_sha256'],pixel_equality_proof=str(R/'white9001-source-prep-2026-10-28/source-specific-plan.json'),currently_local=any(x['path']==plan['native_crop']['master']for x in ims),no_archival_writes=True)
 dump(out/'model.json',model)
 for name in['geometry-validation.json','material-validation.json']:
  d=json.loads((src/name).read_text());d['source_white_sku']=sku
  if name=='material-validation.json':d.update(maps=maps,own_paper_maps=True,no_beige_albedo_recolour=True)
  dump(out/name,d)
 dump(out/'native-paper-crop-provenance.json',dict(**plan['native_crop'],own_pigment_interpretation_srgb=pigment.tolist(),native_output_pixels=[32,32],normalization='Per-channel native low-frequency normalization; no resizing or source shadow transfer',original_registry_records=allims))
 report=L.export_assets(out/'model.json',out,ident);glb=out/(ident+'.glb');doc,binary=L.read_glb(glb);binary=A.G.M.embed_tangents(doc,binary);L.write_glb(glb,doc,binary);report['deliverable_sha256']['glb']=sha(glb);report['glb_bytes']=glb.stat().st_size;dump(report['files']['validation'],report)
 e=dict(meta,asset_dir=str(out),model_path=str(out/'model.json'),glb_path=str(glb),sha256=sha(glb),bytes=glb.stat().st_size,geometry_validation=str(out/'geometry-validation.json'),material_validation=str(out/'material-validation.json'));dump(out/'entry.json',e);dump(R/'native-white-source-r24.json',[e]);rows=json.loads((R/'manifest.json').read_text());dump(R/'manifest.json',[x for x in rows if x['sku']!=sku]+[e]);dump(out/'geometry-and-source-preservation.json',dict(accepted_beige_manifest=str(src.parent/'manifest.json'),accepted_beige_GLBSHA=sha(src/Path(json.loads((src.parent/'manifest.json').read_text())[0]['glb_path']).name),all_mesh_arrays_same_as_accepted_r23=True,all_beige_source_bytes_unchanged=True,own_white_originals_checked=len(ims),own_white_registered=len(allims),own_native_crop_sha256=sha(crop),no_ready_claim=True));print('WHITE',e['sha256'],e['bytes'],flush=True)
if __name__=='__main__':main()
