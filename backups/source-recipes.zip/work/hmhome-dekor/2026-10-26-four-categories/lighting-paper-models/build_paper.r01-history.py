"""Bounded twelve-SKU paper-light candidates. Source masters and peer files read-only.

The visible folded paper is geometry, not a photographic cutout. Hidden joins,
wall thickness and assembly poses are explicitly photo interpretations.
"""
from pathlib import Path
import sys, json, math, hashlib, datetime, re
sys.dont_write_bytecode = True
import numpy as np
from PIL import Image, ImageFilter
R = Path(__file__).resolve().parent
P = R.parent
sys.path.insert(0, str(P/'lighting-models'))
import build_lighting as H
B, G = H.B, H.G
TAU = math.tau
IDS = '1356851001 1355249001 1356852001 1355252002 1356750002 1355248001 1355252001 1356750001 1356851002 1248076001 1248079001 1248079003'.split()
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p, x):
    p=Path(p); p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(x, ensure_ascii=False, indent=2, allow_nan=False)+'\n')

SPECS = {
 '1356851001': dict(family='seven', diameter=.45, table=True, base_h=.20, centre=.315, phase=math.pi/2, pigment=[238,237,232], crop_token='02260014cead', crop=[720,720,976,976], label='7 uçlu beyaz kâğıt yıldız masa lambası'),
 '1356852001': dict(family='seven', diameter=.45, table=True, base_h=.20, centre=.315, phase=math.pi/2, pigment=[239,238,233], crop_token='fcab319d7ec1', crop=[720,720,976,976], label='7 uçlu beyaz kâğıt yıldız masa lambası'),
 '1356851002': dict(family='seven', diameter=.45, table=True, base_h=.20, centre=.315, phase=math.pi/2, pigment=[123,58,61], crop_token='887c7a7ab5f7', crop=[760,960,1016,1216], label='7 uçlu bordo kâğıt yıldız masa lambası'),
 '1355249001': dict(family='seven', diameter=.70, table=False, phase=-math.pi/2, pigment=[239,238,233], crop_token='8f97ab5a123c', crop=[850,750,978,878], label='7 uçlu beyaz kâğıt yıldız abajur'),
 '1355252001': dict(family='pointed', diameter=.40, table=True, base_h=.295, centre=.315, pigment=[239,237,231], crop_token='43a713a93e69', crop=[660,410,788,538], label='Katlı beyaz kâğıt yıldız masa lambası'),
 '1355252002': dict(family='pointed', diameter=.40, table=True, base_h=.295, centre=.315, pigment=[165,141,128], crop_token='1dc13246fcfd', crop=[1080,540,1112,572], label='Katlı vizon kâğıt yıldız masa lambası'),
 '1356750001': dict(family='pointed', diameter=.55, table=False, pigment=[239,237,231], crop_token='db14112c9bad', crop=[1000,850,1064,914], label='Katlı beyaz kâğıt yıldız abajur'),
 '1356750002': dict(family='pointed', diameter=.55, table=False, pigment=[202,177,148], crop_token='18fa5db1a180', crop=[800,600,928,728], label='Katlı açık bej kâğıt yıldız abajur'),
 '1355248001': dict(family='scalloped', diameter=.45, table=False, pigment=[239,239,231], crop_token='7eaf70481a5a', crop=[480,380,608,508], label='Üç katlı pileli beyaz kâğıt yıldız abajur'),
 '1248076001': dict(family='leaf', diameter=.52, table=False, pigment=[239,238,232], crop_token='df796e6dead4', crop=[600,650,856,906], label='Yaprak uçlu beyaz kâğıt abajur'),
 '1248079001': dict(family='rounded', diameter=.55, table=False, pigment=[240,238,230], crop_token='4aca88e86ab3', crop=[620,200,748,328], label='Yuvarlak uçlu katlı beyaz kâğıt abajur'),
 '1248079003': dict(family='rounded', diameter=.55, table=False, pigment=[172,155,129], crop_token='ec86feff370d', crop=[730,240,858,368], label='Yuvarlak uçlu katlı toz bej kâğıt abajur'),
}

def seven_star(radius, centre, phase):
    """Hollow folded seven-point shell with physical rear mounting aperture.

    Front and back triangular facets join at the outer seam; inner facets and
    the aperture rim form one thin, closed solid. It is not a solid pyramid.
    """
    n=14; th=.0004; front=.22*radius; back=-.18*radius; hole=.075*radius
    ang=np.arange(n)*TAU/n+phase
    radii=np.where(np.arange(n)%2==0, radius, radius*.395)
    v=[(0,centre,front)]
    v += [(float(r*math.cos(a)),float(centre+r*math.sin(a)),0.) for r,a in zip(radii,ang)]
    v += [(float(hole*math.cos(a)),float(centre+hole*math.sin(a)),back) for a in ang]
    inner_c=len(v);v.append((0,centre,front-th))
    inner_edge=len(v)
    v += [(float((r-th)*math.cos(a)),float(centre+(r-th)*math.sin(a)),0.)for r,a in zip(radii,ang)]
    inner_hole=len(v)
    v += [(float((hole+th)*math.cos(a)),float(centre+(hole+th)*math.sin(a)),back+th)for a in ang]
    f=[]
    for j in range(n):
        k=(j+1)%n;a=1+j;b=1+k;c=1+n+j;d=1+n+k
        f += [(0,a,b),(a,c,b),(b,c,d)]
        aa=inner_edge+j;bb=inner_edge+k;cc=inner_hole+j;dd=inner_hole+k
        f += [(inner_c,bb,aa),(aa,bb,cc),(bb,dd,cc)]
        f += [(c,cc,d),(d,cc,dd)]
    uv=[(x/.025,y/.025)for x,y,z in v]
    return B.solid('seven-point-folded-hollow-paper-with-rear-aperture','paper',v,f,uv,flat=True)

def pleat_fan(name, radius, centre, zcentre, folds, depth, drop, phase=0., style='pointed', reverse=False):
    """Closed 0.35mm accordion sheet. Concentric layers remain separate solids."""
    na=folds*8; nr=8; th=.00035; v=[];uv=[]
    for back in (0,1):
        for k in range(nr+1):
            t=k/nr
            for j in range(na):
                a=j*TAU/na+phase;p=(j%8)/8;tri=1-4*abs(p-.5)
                if style=='pointed': outer=radius*(.80+.20*(1-abs(2*p-1)))
                elif style=='rounded': outer=radius*(.87+.13*math.sqrt(max(0,1-(2*p-1)**2)))
                else:
                    # Three small accordion ridges under each broad round-ended lobe.
                    envelope=(.5+.5*math.cos(20*a))**.28
                    outer=radius*(.90+.10*envelope)
                rr=.0011*(1-t)+outer*t
                zz=zcentre-drop*t+depth*t*tri + .004*math.sin(math.pi*t)
                zz-=back*th
                if reverse:zz=-zz
                v.append((rr*math.cos(a),centre+rr*math.sin(a),zz))
                uv.append((rr*math.cos(a)/.025,rr*math.sin(a)/.025))
    side=(nr+1)*na;f=[]
    for s in (0,1):
        off=s*side
        for k in range(nr):
            for j in range(na):
                a=off+k*na+j;b=off+k*na+(j+1)%na;c=a+na;d=off+(k+1)*na+(j+1)%na
                f.extend([(a,b,c),(b,d,c)] if s==0 else [(a,c,b),(b,c,d)])
    for k in (0,nr):
        for j in range(na):
            a=k*na+j;b=k*na+(j+1)%na;c=a+side;d=b+side
            f.extend([(a,c,b),(b,c,d)])
    return B.solid(name,'paper',v,f,uv,flat=True)

def folded_leaf(name, angle, radius, centre, z0=.0):
    """Curved lens outline, a raised longitudinal crease and finite paper rim."""
    nu=10; nt=22;th=.0004; v=[];uv=[];f=[];rings=[]
    for back in (0,1):
        root=len(v);v.append((0,centre,z0-back*th));uv.append((0,0));rs=[]
        for k in range(1,nt):
            t=k/nt;rr=radius*t;half=.145*math.sin(math.pi*t)**.68;ring=[]
            for j in range(nu+1):
                u=2*j/nu-1;a=angle+half*u
                zz=z0+.18*radius*math.sin(math.pi*t)*(1-abs(u))-.025*radius*math.sin(math.pi*t)*abs(u)-back*th
                ring.append(len(v));v.append((rr*math.cos(a),centre+rr*math.sin(a),zz));uv.append((rr/.025,u*rr*half/.025))
            rs.append(ring)
        tip=len(v);v.append((radius*math.cos(angle),centre+radius*math.sin(angle),z0-back*th));uv.append((radius/.025,0));rings.append((root,rs,tip))
    for s,(root,rs,tip) in enumerate(rings):
        ff=[]
        for j in range(nu):ff.append((root,rs[0][j],rs[0][j+1]))
        for k in range(len(rs)-1):
            for j in range(nu):a=rs[k][j];b=rs[k][j+1];c=rs[k+1][j];d=rs[k+1][j+1];ff.extend([(a,c,b),(b,c,d)])
        for j in range(nu):ff.append((rs[-1][j],tip,rs[-1][j+1]))
        f.extend(ff if s==0 else [(a,c,b)for a,b,c in ff])
    root,rs,tip=rings[0];rr,ss,tt=rings[1]
    border=[root]+[a[0]for a in rs]+[tip]+[a[-1]for a in rs[::-1]]
    border2=[rr]+[a[0]for a in ss]+[tt]+[a[-1]for a in ss[::-1]]
    for j in range(len(border)):
        k=(j+1)%len(border);a=border[j];b=border[k];c=border2[j];d=border2[k];f.extend([(a,b,c),(b,d,c)])
    return B.solid(name,'paper',v,f,uv)

def paper_geometry(spec):
    family=spec['family'];r=spec['diameter']/2;c=spec.get('centre',r);parts=[]
    if family=='seven':parts=[seven_star(r,c,spec['phase'])]
    elif family=='leaf':
        for j in range(14):
            angle=math.pi/2-j*TAU/14;rr=r if j%2==0 else r*.83
            parts.append(folded_leaf('separate-curved-creased-paper-leaf-'+str(j+1),angle,rr,c))
        # A small frame is sold with this 90%paper/10%steel SKU; its hidden routing is inferred.
        parts.append(H.tube('rear-steel-mounting-ring','steel',[(.014*math.cos(a),c+.014*math.sin(a),-.007)for a in np.linspace(0,TAU,80,endpoint=False)],.0007,8,True))
    else:
        if family=='scalloped': configs=[(1.,60,.050,.048,.017,0.),(.77,60,.073,.037,.014,TAU/120),(.49,42,.093,.029,.010,0.)];style='scalloped'
        elif family=='rounded': configs=[(1.,48,.058,.070,.025,0.),(.83,48,.080,.048,.021,TAU/96),(.57,40,.102,.040,.015,0.)];style='rounded'
        else: configs=[(1.,48,.060,.082,.029,0.),(.83,48,.087,.059,.024,TAU/96),(.60,40,.112,.047,.018,0.)];style='pointed'
        # Depth is scaled with official diameter, never treated as an official axis.
        for i,(scale,n,zc,drop,depth,phase)in enumerate(configs):
            factor=spec['diameter']/.55
            parts.append(pleat_fan('front-physical-paper-accordion-tier-'+str(i+1),r*scale,c,zc*factor,n,depth*factor,drop*factor,phase,style))
        for i,(scale,n,zc,drop,depth,phase)in enumerate(configs[:2]):
            factor=spec['diameter']/.55
            parts.append(pleat_fan('rear-interpreted-physical-paper-tier-'+str(i+1),r*scale,c,zc*factor*.75,n,depth*factor,drop*factor,phase,style,True))
    if spec['table']:
        bh=spec['base_h'];stem_r=.0027;foot_r=.055
        parts += [H.lathe('separate-flat-black-iron-foot','black',[(0,0),(foot_r-.002,0),(foot_r,.0007),(foot_r,.002),(foot_r-.002,.003),(0,.003)],160),H.lathe('separate-official-base-height-upright','black',[(0,.003),(stem_r,.003),(stem_r,bh),(0,bh)],96)]
        if bh<c-.02:
            parts.append(H.lathe('photo-interpreted-shade-mount-extension','black',[(0,bh),(stem_r,bh),(stem_r,c-.02),(0,c-.02)],96))
        for pp in H.holder(c-.020,'E14'):parts.append(H.move(pp,np.array([0,0,-.028])))
        # Physical matching cord/switch, stored coil is an explicit presentation interpretation.
        pp,le=H.cord(1.6,(0,.009,-foot_r*.85),.075,switch=True);parts+=pp
    return parts

def materials(spec, masters, out):
    picked=next((x for x in masters if spec['crop_token']in x['path']),masters[0]);original=Image.open(picked['path']).convert('RGB');box=spec['crop'];patch=original.crop(box);arr=np.asarray(patch,dtype=np.float32)
    if patch.size!=(box[2]-box[0],box[3]-box[1]):raise ValueError('Crop error')
    low=np.asarray(patch.filter(ImageFilter.GaussianBlur(max(4,patch.width/6))),dtype=np.float32)
    # Only fine intrinsic paper pigment/grain survives; no broad facet shadow/scene/background.
    detail=np.clip(arr/np.maximum(low,8),.97,1.03)
    pigment=np.array(spec['pigment'],np.float32);rgb=np.clip(detail*pigment,0,255).astype('uint8');grey=arr.mean(2)-low.mean(2);dy,dx=np.gradient(grey*.005);nn=np.stack([-dx,-dy,np.ones_like(dx)],2);nn/=np.linalg.norm(nn,axis=2,keepdims=True)
    orm=np.empty((*rgb.shape[:2],3),np.uint8);orm[:]=[255,231,0]
    paper_maps={'albedo':rgb,'normal':np.rint((nn+1)*127.5).astype('uint8'),'orm':orm};maps=[];mats={}
    for slot,a in paper_maps.items():
        p=out/('paper-'+slot+'.png');Image.fromarray(a).save(p,optimize=True);maps.append(dict(path=str(p),sha256=sha(p),resolution=list(a.shape[:2][::-1]),slot=slot,material='paper'))
    mats['paper']=dict(baseColorFactor=[1,1,1,1],baseColorTexture='paper-albedo.png',normalTexture='paper-normal.png',metallicRoughnessTexture='paper-orm.png',normalScale=.13,metallic=1,roughness=1,alphaMode='OPAQUE',doubleSided=False,extras=dict(intrinsic_paper_grain=True,no_baked_lighting=True,emission=False,measured_pigment_not_claimed=True,pigment_photo_interpretation=spec['pigment'],native_crop_pixels=box,texture_physical_repeat_metres=.025))
    for key,col,rough,metal in [('black',[22,21,20],.56,0),('socket',[50,47,42],.60,0),('steel',[139,141,142],.30,1),('cable',[23,23,22],.86,0)]:
        for slot,a in [('albedo',np.full((8,8,3),col,np.uint8)),('normal',np.full((8,8,3),[128,128,255],np.uint8)),('orm',np.full((8,8,3),[255,int(rough*255),int(metal*255)],np.uint8))]:
            p=out/(key+'-'+slot+'.png');Image.fromarray(a).save(p);maps.append(dict(path=str(p),sha256=sha(p),resolution=[8,8],slot=slot,material=key))
        mats[key]=dict(baseColorFactor=[1,1,1,1],baseColorTexture=key+'-albedo.png',normalTexture=key+'-normal.png',metallicRoughnessTexture=key+'-orm.png',normalScale=.05,metallic=1,roughness=1,alphaMode='OPAQUE',doubleSided=False)
    proof=dict(master=picked['path'],master_sha256=picked['sha256'],native_master_dimensions=list(original.size),crop_native_pixels=box,output_dimensions=list(patch.size),geometric_resampling_count=0,upscale=False,method='Native crop; low-frequency per-channel illumination normalization; retained own high-frequency grain; explicit photo-interpreted neutral pigment.',photo_shadows_or_room_pixels_baked=False,pigment_rgb_interpretation=spec['pigment'],master_unchanged=sha(picked['path'])==picked['sha256'])
    dump(out/'native-paper-crop-provenance.json',proof)
    return mats,maps,proof

def run(sku):
    spec=SPECS[sku];queue=json.loads((P/'lighting-research/confirmed-queue.research-final-02.json').read_text());q=next(a for a in queue if a['sku']==sku);ims=[a for a in json.loads((P/'lighting-models/original-image-masters.json').read_text())if a['sku']==sku]
    assert ims and all(sha(a['path'])==a['sha256']for a in ims)
    out=R/'candidate-r01'/sku
    if (out/'entry.json').exists():raise RuntimeError('Existing candidate preserved; use a new revision folder')
    out.mkdir(parents=True,exist_ok=True);parts=paper_geometry(spec);pos=np.concatenate([g['_vertices']for g in parts]);lo=pos.min(0);hi=pos.max(0);shift=np.array([(hi[0]+lo[0])/2,lo[1],(hi[2]+lo[2])/2]);meshes=[];checks=[]
    for raw in parts:
        raw['_vertices']=[tuple(np.array(p)-shift)for p in raw['_vertices']];raw=G.H.orient(raw);m,c=H._finalize(raw);meshes.append(m);checks.append(c)
    repairs=G.M.ensure_uv_faces(meshes)+G.H.ensure_float32_uv(meshes)
    mats,maps,crop=materials(spec,ims,out);keys={m['material']for m in meshes};mats={k:v for k,v in mats.items()if k in keys}
    dims=((hi-lo)*100).tolist();fmt=lambda n:format(n,'.6g').replace('.','p');id='hm-'+sku+'-paper-r01-h'+fmt(dims[1])+'-w'+fmt(dims[0])+'-d'+fmt(dims[2])
    features={
     'seven':['Seven sharply folded points; true hollow star cavity, rear mounting aperture, finite paper rim and front/back facets'],
     'leaf':['Fourteen individual curved, creased leaf tips; seven long/seven shorter photo-interpreted petals; thin physical paper and rear steel mounting ring'],
     'rounded':['Three radial accordion tiers with rounded spoon-like ends; visible separate folds and true paper rims'],
     'pointed':['Three radial accordion tiers with long pointed ends; individually folded faces and staggered tier depths'],
     'scalloped':['Three radial accordion tiers with broad round scallops and finer subordinate pleats']
    }[spec['family']]
    if spec['table']:features+=['Separate black metal foot/upright, E14 empty holder, fabric-covered cord and plastic inline switch; bulb absent as sold']
    else:features+=['Standalone shade only; no bulb, cable set, powered glow or invented electrical assembly']
    estimates=['paper_wall_thickness','unseen_rear_fold_arrangement','paper_optics_and_intrinsic_pigment','exact_fold_count_and_depth','hidden_mounting_frame','depth_cm']
    note='Resmî çap, yıldızın çevreleyen çemberinin çapıdır; kutu eni/yüksekliğiyle aynı kabul edilmedi. Kendi fotoğrafına göre katlar, derinlik, kâğıt kalınlığı, arka kurgu ve pigment yorumlandı; üretici CAD veya kalibre tarama değildir. Fotoğraf ışığı/düşen gölge kaplamaya taşınmadı. Model ışığı kapalı fiziksel PBR malzemeyle sunulur.'
    if spec['table']:
        estimates+=['overall_height_cm','base_diameter','shade_mount_overlap','cord_length_and_stored_pose','socket_switch_dimensions']
        note+=' Resmî taban yüksekliği ayrı dikme bileşeninde korunur; toplam yükseklik ve abajurun montaj kotu fotoğraf yorumudur. Kablo pozu/160cm uzunluğu resmî ölçü değildir.'
        if spec['base_h']==.20:note+=' Fotoğraftaki dikme/abajur oranı ile 20cm taban bilgisi birebir uzlaşmadığından abajur içindeki ek montaj uzantısı ve toplam yükseklik açık yorumdur.'
    official=dict(diameter_cm=spec['diameter']*100)
    if spec['table']:official=dict(shade_diameter_cm=spec['diameter']*100,base_height_cm=spec['base_h']*100)
    meta=dict(id=id,sku=sku,name=spec['label'],brand='H&M Home',category='Aydınlatma',category_id='lighting',category_slug='aydinlatma',url=q['url'],source_market=q.get('source_market'),markets=q.get('markets'),colour=q.get('colour',q.get('colour_verbatim','')),material_label='Kâğıt / Demir'if spec['table']else('Kâğıt / Çelik'if sku.startswith('124807')else'Kâğıt'),official_materials=q.get('composition')or q.get('composition_facts'),dimensions_cm=dims,source_dimensions_hwd_cm=[dims[1],dims[0],dims[2]],official_measurements=official,estimated_dimensions=True,estimated_fields=estimates,scale_note=note,quality_label='Fiziksel katlı kâğıt · Fotoğrafa dayalı ayrıntılar',source_size_pointer=str(P/'lighting-research/confirmed-queue.research-final-02.json')+'#sku='+sku,source_evidence_files=q['source_evidence_files'],source_images=q['gallery_images'],original_image=ims[0]['path'],original_image_url=ims[0]['url'],original_image_sha256=ims[0]['sha256'],original_images=[{k:a[k]for k in ['path','url','sha256']}for a in ims],units='metres',up_axis='Y',origin='bottom bounding-box centre',photo_pixels_baked=False,native_intrinsic_crop_used=True,baked_reflections=False,unlit=False,display_state_unpowered=True,model_status='pending_root_visual_review',ready_model_variants=0,quality_pending=True,photographed_features=features,geometry_limitations=estimates,model_revision='paper-source-specific-r01',no_cable_as_sold_separately=not spec['table'])
    dump(out/'source-evidence.json',dict(source_record=q,own_spec=spec,original_image_masters=ims,exact_identity=True,source_research_sha256=sha(P/'lighting-research/confirmed-queue.research-final-02.json')))
    dump(out/'model.json',dict(metadata=meta,materials=mats,meshes=meshes));dump(out/'geometry-validation.json',dict(valid=True,mesh_count=len(meshes),triangles=sum(x['triangles']for x in checks),meshes=checks,closed_material_solids=True,uv_repairs=repairs,metres=True,y_up=True,bottom_zero=True,dimensions_metres=(hi-lo).tolist(),source_anchor=official,features=features))
    dump(out/'material-validation.json',dict(valid=True,maps=maps,native_paper_crop=crop,all_master_sha_unchanged=all(sha(a['path'])==a['sha256']for a in ims),physical_PBR=True,unlit=False,baked_lighting=False))
    report=H.export_assets(out/'model.json',out,id);glb=out/(id+'.glb');doc,binary=H.read_glb(glb)
    assert 'KHR_materials_unlit'not in doc.get('extensionsUsed',[])
    # The main viewer may ignore diffuse-transmission; opaque diffuse is a faithful unpowered fallback.
    for ma in doc['materials']:
        if ma['name']=='paper':ma.setdefault('extensions',{})['KHR_materials_diffuse_transmission']=dict(diffuseTransmissionFactor=.12,diffuseTransmissionColorFactor=[1,1,1])
    doc['extensionsUsed']=sorted(set(doc.get('extensionsUsed',[]))|{'KHR_materials_diffuse_transmission'})
    binary=G.M.embed_tangents(doc,binary);H.write_glb(glb,doc,binary)
    assert glb.stat().st_size<96*1024*1024
    entry=dict(meta,asset_dir=str(out),model_path=str(out/'model.json'),glb_path=str(glb),sha256=sha(glb),bytes=glb.stat().st_size,geometry_validation=str(out/'geometry-validation.json'),material_validation=str(out/'material-validation.json'),actual_model_variants=1,size_source_kind='official_other_market_same_exact_sku',size_source_urls=[q['url']])
    dump(out/'entry.json',entry);rows=json.loads((R/'manifest.json').read_text())if(R/'manifest.json').exists()else[];rows=[a for a in rows if a['sku']!=sku]+[entry];dump(R/'manifest.json',rows)
    print('CANDIDATE',sku,len(meshes),'meshes',sum(x['triangles']for x in checks),'triangles',glb.stat().st_size,'bytes',flush=True)
    return entry

if __name__=='__main__':
    for sku in sys.argv[1:]or IDS:run(sku)
