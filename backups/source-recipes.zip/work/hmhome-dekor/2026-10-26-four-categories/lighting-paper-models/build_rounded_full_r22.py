"""Only one beige full product after root accepted the partial fold method.
All historical frozen assets stay immutable; white is not built here.
"""
from pathlib import Path
import sys,json,math,hashlib,importlib.util
sys.dont_write_bytecode=True
import numpy as np
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R))
import build_paper as BASE
sp=importlib.util.spec_from_file_location('accepted_partial_fold_method',R/'build_vfold_sector_pilot18.py');F=importlib.util.module_from_spec(sp);sp.loader.exec_module(F)
sp=importlib.util.spec_from_file_location('same_own_paper_material',R/'build_rounded_vfold_r17.py');M=importlib.util.module_from_spec(sp);sp.loader.exec_module(M)
H=BASE.H;T=math.tau
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
CONFIGS=[dict(tier=1,radius=.275,tip_z=.020,max_width=.030,ridge=.032,count_hypothesis=56,phase=0),dict(tier=2,radius=.220,tip_z=.105,max_width=.030,ridge=.027,count_hypothesis=56,phase=T/112),dict(tier=3,radius=.15125,tip_z=.180,max_width=.026,ridge=.022,count_hypothesis=42,phase=T/168)]
def geometry(spec):
 parts=[]
 for c in CONFIGS:
  for j in range(c['count_hypothesis']):
   a=j*T/c['count_hypothesis']+c['phase'];variation=.97+.03*math.cos(7*a+c['tier']*.4)
   if j%2:variation*=.84
   parts.append(F.fold('tier-'+str(c['tier'])+'-paired-cut-cambered-paper-fold-'+str(j+1),a,c['radius']*variation,c['tip_z'],c['max_width'],c['ridge'],cap_ratio=.55))
 rad=.016;z=-.004;centre=.275
 parts.append(H.tube('interpreted-passive-rear-steel-shade-mount-ring','steel_mount',[(rad*math.cos(a),centre+rad*math.sin(a),z)for a in np.linspace(0,T,96,endpoint=False)],.0007,8,True))
 for j,a in enumerate([math.pi/6,7*math.pi/6]):parts.append(H.tube('interpreted-passive-rear-steel-frame-spoke-'+str(j+1),'steel_mount',[(rad*math.cos(a),centre+rad*math.sin(a),z),(.027*math.cos(a),centre+.027*math.sin(a),z+.001)],.00065,8))
 return parts
UNSCALED_GEOMETRY=geometry
SCALE_PROOF={}
def geometry(spec):
 parts=UNSCALED_GEOMETRY(spec);paper=[g for g in parts if g['material']=='paper'];vv=np.concatenate([g['_vertices']for g in paper]);rr=np.linalg.norm(vv[:,:2]-[0,.275],axis=1);old_d=float(rr.max()*2);factor=.55/old_d
 for g in paper:g['_vertices']=[(x*factor,.275+(y-.275)*factor,z)for x,y,z in g['_vertices']]
 after=np.concatenate([g['_vertices']for g in paper]);actual=float(np.linalg.norm(after[:,:2]-[0,.275],axis=1).max()*2)
 SCALE_PROOF.update(old_actual_radial_diameter_m=old_d,new_actual_radial_diameter_m=actual,in_plane_paper_scale=factor,depth_scale=1.,paper_wall_Z_separation_m=.00035,steel_details_rescaled=False,steel_vertices_unchanged=True,XY_envelope_m=np.ptp(after[:,:2],axis=0).tolist())
 return parts
def main():
 BASE.REV='r22';BASE.paper_geometry=geometry;BASE.materials=M.reused_materials;e=BASE.run('1248079003');out=Path(e['asset_dir']);model=json.loads((out/'model.json').read_text());meta=model['metadata']
 features=['Three full radial tiers using the root-reviewed partialVfold method: two softly cambered paper faces, open central ridge and shallow paired rounded cuts','Width peaks before the shoulder and retains a finite cut lip; no single collapsed spoon tip and no rectangular strip','Separate tier front projection; inner42/outer56folds are photo-interpretation hypotheses supported by own-frontal azimuth evidence, not official counts','Minimal separate passive rear steel support from ownPaper90%/Steel10%; exact unseen mount is interpreted. No bulb/socket/cable set']
 meta.update(photographed_features=features,model_revision='full-beige-rounded-source-Vfold-r22',source_photo_fold_count_hypotheses=[56,56,42],partial_geometry_prototype=False,complete_product_model=True)
 meta['actual_radial_diameter_cm']=55.;meta['diameter_axis_semantics']='Maximum paper radius from fold centre times two; in-plane XY bounding widths are separately measured and are not each official diameter';meta['estimated_fields']+=['photo_asymmetric_XY_envelope'];meta['historical_r21_scale_interpretation']='55cm was the nominal pre-cut fold radial length, not its measured post-cut envelope';meta['scale_note']+=' 実' if False else '';meta['scale_note']+='Önceki sürümde55cm nominal kesim öncesi radyal uzunluktu; bu sürümde gerçek kâğıt noktalarının kat merkezine azami uzaklığının iki katı55cm olacak biçimde yalnız düzlem içi kâğıt ölçeği düzeltildi. X/Y kutu ölçüleri ayrıca gerçek modelden hesaplanır; ikisi de ayrı resmî55cm eksen diye sunulmaz. Metal detaylar ve Z kat derinlikleri/0,35mm kalınlık değişmedi. ';meta['scale_note']+='Uç kesiminin yuvarlaklığı ayrı fiziksel denemede kaynak yakın planına göre ayarlandı; bu resmî üretici ölçüsü değildir.  Üç katın56/56/42kıvrım ritmi, çift yuvarlak kesim, yüz kamberi ve yaklaşık20cmderinliği kendi fotoğrafından yorumlanmıştır; resmîfoldcount/derinlik değildir. Bu yöntem önce dokuzkıvrımlık fiziksel kesit pilotunda incelenmiştir; tam ürünün kabulü ayrıca gerçek tarayıcı karşılaştırmasına bağlıdır.'
 dump(out/'model.json',model);doc,binary=H.read_glb(e['glb_path']);doc['extras']['metadata']=meta;H.write_glb(e['glb_path'],doc,binary);e.update(meta,sha256=sha(e['glb_path']),bytes=Path(e['glb_path']).stat().st_size);dump(out/'entry.json',e)
 g=json.loads((out/'geometry-validation.json').read_text());g['features']=features;dump(out/'geometry-validation.json',g)
 p=out/(e['id']+'.validation.json');report=json.loads(p.read_text());report['source_sha256']=sha(out/'model.json');report['deliverable_sha256']['glb']=e['sha256'];report['glb_bytes']=e['bytes'];dump(p,report)
 rows=json.loads((R/'manifest.json').read_text());rows=[r for r in rows if r['sku']!=e['sku']]+[e];dump(R/'manifest.json',rows);dump(R/'native-rounded-full-r22.json',[e]);dump(out/'source-to-full-method-proof.json',dict(accepted_partial_pilot_manifest=str(R/'frozen-partial-Vfold-pilot18/manifest.json'),source_native_crops=str(R/'pilot18-source-analysis/crop-provenance.json'),source_frontal_azimuth_evidence=str(R/'pilot18-source-analysis/source-azimuth-analysis.json'),configs=CONFIGS,official_depth_or_fold_count_claimed=False,paper_thickness_m=.00035,paper_PNGs_and_originalJPEGs_unchanged=True,previous_frozen_unchanged=True,white_not_generated=True,selected_controlled_cap_pilot=str(R/'frozen-controlled-cut-ratio-pilot20/manifest.json'),selected_cap_ratio=.55,unchanged_other_geometry_parameters=True))
 dump(out/'in-plane-diameter-preservation-proof.json',SCALE_PROOF)
 print('FULL_BEIGE_R22',e['bytes'],e['sha256'],flush=True)
if __name__=='__main__':main()
