"""17 exact-SKU H&M mirrors/frames. Immutable photo masters; isolated asset output.

Meshes are interpreted from official exact-SKU photographs, never maker CAD.
No product photographs, room reflections, lettering or artwork enter the PBR.
"""
from pathlib import Path
import sys,json,math,hashlib,importlib.util,shutil
sys.dont_write_bytecode=True
import numpy as np
from PIL import Image
R=Path(__file__).resolve().parent
RESEARCH=R.parent/'mirrors-frames-research'
spec=importlib.util.spec_from_file_location('hm_root_readonly',R.parents[1]/'2026-10-23-production/root/build_root.py')
ROOT=importlib.util.module_from_spec(spec);spec.loader.exec_module(ROOT)
G=ROOT.G; B=G.B; MB=G.H.M.G
from export_catalog import export_assets,read_glb,write_glb
from vase_geometry import _finalize
T=math.tau
SOURCES=json.loads((RESEARCH/'mirrors-frames-source-queue.json').read_text())['products']
MASTERS=json.loads((RESEARCH/'image-master-audit.json').read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,x):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def rect(w,h,cy=None,n=128):return MB.rounded(w,h,.0002,n,cy=h/2 if cy is None else cy)
def offset(p,d):
 t=np.roll(p,-1,axis=0)-np.roll(p,1,axis=0);n=np.c_[t[:,1],-t[:,0]];n/=np.linalg.norm(n,axis=1)[:,None];return p+n*d
def curve(pts,w,h,n=360):return G.H.M.curve(pts,w,h,n)
def rawparts(b):return list(b.groups.values())
def rear(b,p,d,hardware=True):
 b.slab('separate-contour-MDF-backing','back',offset(p,-.0012),-d*.48,-d*.34,.0002)
 if hardware:
  w=np.ptp(p[:,0]);h=np.ptp(p[:,1])
  for x,y in [(-w*.20,h*.73),(w*.20,h*.73)]:
   outer=MB.circle(.004,48,cy=y)+[x,0];inner=MB.circle(.002,48,cy=y)+[x,0]
   b.ring('rear-wall-hanging-eyelet-'+str(x),'steel',[(outer,-d*.50),(outer,-d*.37),(inner,-d*.37),(inner,-d*.50)])
def pane(b,p,z,th=.003):b.slab('intrinsic-planar-silver-reflecting-pane','mirror',p,z-th,z,.00004)
def profile_mirror(p,d,width,mat='wood',b=None):
 b=b or MB.Builder();inside=offset(p,-width);mix=lambda a:p*(1-a)+inside*a
 b.ring('continuous-rounded-'+mat+'-profile','frame',[(p,-d*.32),(p,d*.10),(mix(.08),d*.32),(mix(.22),d*.46),(mix(.43),d*.50),(mix(.67),d*.42),(mix(.90),d*.21),(inside,d*.10),(inside,-d*.32)])
 if mat=='wood':
  g=b.groups[('continuous-rounded-'+mat+'-profile','frame')];length=np.r_[0,np.cumsum(np.linalg.norm(np.diff(p,axis=0),axis=1))]
  g['_uvs']=[(float(length[j]/.25),k*.016)for k in range(9)for j in range(len(p))]
 pane(b,offset(inside,.0001),d*.10);rear(b,p,d)
 return b
CHROME=[(-.17,0),(.15,.006),(.38,.075),(.48,.24),(.50,.49),(.46,.77),(.33,.94),(.07,1),(-.22,.97),(-.41,.86),(-.48,.65),(-.50,.37),(-.45,.13)]
MANGO1=[(-.14,0),(.12,.015),(.31,.095),(.39,.265),(.50,.45),(.49,.59),(.33,.76),(.10,.955),(-.12,1),(-.35,.94),(-.49,.80),(-.48,.62),(-.44,.46),(-.49,.25),(-.46,.10),(-.32,.025)]
MANGO2=[(-.07,0),(.20,.025),(.39,.13),(.49,.31),(.50,.46),(.43,.62),(.41,.79),(.29,.94),(.09,1),(-.13,.975),(-.33,.85),(-.46,.65),(-.50,.44),(-.46,.24),(-.31,.075)]
def chrome():
 p=curve(CHROME,.488,.855,432);b=profile_mirror(p,.05,.054,'aluminium')
 return rawparts(b),['Wide convex polished aluminium surround, organic rounded rectangle traced for this exact SKU','48.8×85.5×5 cm official exterior; recessed actual silver pane; separate MDF back and inferred steel hangers']
def mango(pid):
 w,h,d,band=(.35,.45,.025,.020)if pid=='1213141001'else(.56,.765,.03,.028)
 p=curve(MANGO1 if pid=='1213141001'else MANGO2,w,h,448);b=profile_mirror(p,d,band)
 return rawparts(b),['Distinct own-photo asymmetric mango contour; smoothly rolled wood surround','Separate silver mirror sheet, shaped MDF backing and mounting eyelets; local depth/profile/hardware inferred']
def wave():
 a=np.arange(640)*T/640;r=.1925+.0075*np.cos(16*a+.22)
 p=np.c_[r*np.cos(a),.20+r*np.sin(a)];b=profile_mirror(p,.018,.014,'painted-MDF')
 return rawparts(b),['True sixteen-scallop cobalt circular contour on both outer and inner edge','Rounded glossy painted MDF edge follows the real undulation; independent recessed reflective pane and back']
def grid():
 b=MB.Builder();w=.38;h=.45;d=.016;rail=.0065
 pane(b,rect(w-.011,h-.011,cy=h/2),.0015)
 # Four outer rails; two full-height verticals; two horizontal through bars;
 # one additional crossbar only in each side strip at the centre.
 for s in[-1,1]:
  b.add('outer-vertical-rail-'+str(s),'frame',**{}) if False else None
  g=ROOT.box('outer-vertical-rail-'+str(s),'frame',rail,h,d,(s*(w-rail)/2,h/2,0));b.add(g['name'],g['material'],g['_vertices'],g['_faces'],g['_uvs'])
  g=ROOT.box('outer-horizontal-rail-'+str(s),'frame',w-2*rail,rail,d,(0,(rail/2 if s<0 else h-rail/2),0));b.add(g['name'],g['material'],g['_vertices'],g['_faces'],g['_uvs'])
  x=s*w*.355
  g=ROOT.box('full-height-interior-vertical-'+str(s),'frame',rail,h-2*rail,d,(x,h/2,.001));b.add(g['name'],g['material'],g['_vertices'],g['_faces'],g['_uvs'])
  sidew=w/2-abs(x)-rail
  g=ROOT.box('side-only-middle-crossbar-'+str(s),'frame',sidew,rail,d,(s*(abs(x)+w/2)/2,h*.50,.001));b.add(g['name'],g['material'],g['_vertices'],g['_faces'],g['_uvs'])
 for y in[h*.125,h*.875]:
  g=ROOT.box('full-width-interior-horizontal-'+str(y),'frame',w-2*rail,rail,d,(0,y,.001));b.add(g['name'],g['material'],g['_vertices'],g['_faces'],g['_uvs'])
 rear(b,rect(w-.003,h-.003,cy=h/2),d)
 return rawparts(b),['Photographed iron grid: four outer rails, two full-height interior uprights, two through crossrails and two side-only central crossbars','38×45 cm outer face; thin black iron bars stand in front of a continuous silver pane; depth inferred']
def asym_metal():
 b=MB.Builder();h=.48
 # The rear oval hoop is an exposed structural element, not a second reflection.
 hoop=curve([(-.10,0),(.20,.04),(.43,.21),(.50,.49),(.47,.77),(.25,.95),(-.04,1),(-.31,.94),(-.47,.74),(-.50,.45),(-.39,.14)],.385,h,384)
 hoop[:,0]-=.019
 b.tube('separate-exposed-offset-rear-iron-oval-hoop','frame',[(x,y,-.012)for x,y in hoop],.0024,14,True)
 front=curve([(-.14,0),(.20,.025),(.43,.11),(.49,.37),(.50,.66),(.36,.89),(.10,1),(-.17,.955),(-.39,.81),(-.50,.63),(-.47,.37),(-.37,.12)],.332,.428,384)
 front[:,0]+=.032;front[:,1]+=.025
 inn=offset(front,-.006);mix=lambda t:front*(1-t)+inn*t
 b.ring('thin-organic-polished-iron-front-rim','frame',[(front,-.004),(front,.008),(mix(.3),.010),(inn,.007),(inn,-.004)])
 pane(b,offset(inn,.0001),.007);rear(b,front,.018,False)
 for x,y in[(.035,.46),(.032,.028)]:
  b.tube('front-to-hoop-mount-'+str(y),'steel',[(x,y,-.012),(x,y,.002)],.003,12)
 return rawparts(b),['Asymmetric front mirror with thin silver iron rim plus separate offset oval rear hoop, as visible in its own source','Official32 cm width excludes frame; 48 cm height used for hoop; outer width/depth and relative offsets interpreted']
def tabletop():
 b=MB.Builder();cy=.245;r=.11;rim=.007
 out=MB.circle(r,384,cy=cy);inn=MB.circle(r-rim,384,cy=cy)
 b.ring('separate-rounded-arjuna-circular-rim','frame',[(out,-.007),(out,.004),(offset(out,-.001),.007),(inn,.006),(inn,-.007)])
 g=b.groups[('separate-rounded-arjuna-circular-rim','frame')];g['_uvs']=[(j/384*T*r/.25,k*.025)for k in range(5)for j in range(384)]
 pane(b,inn,.005)
 b.slab('separate-round-MDF-mirror-back','back',inn,-.007,-.004,.0001)
 # The shallow tray-like circular wood base has an actual recessed top.
 pr=[(0,0),(.10,0),(.11,.002),(.113,.005),(.113,.014),(.111,.017),(.106,.017),(.106,.009),(0,.009)]
 bparts=rawparts(b)
 bparts.append(ROOT.wood_uv(B.lathe('separate-arjuna-shallow-tray-base','frame',pr,192,False),False))
 for name,prof in [('separate-upright-arjuna-stem',[(0,.013),(.009,.013),(.009,.137),(.007,.145),(0,.145)]),('separate-stepped-stem-socket',[(0,.010),(.017,.010),(.017,.052),(.015,.055),(0,.055)])]:
  g=B.lathe(name,'frame',prof,128,False);g['_uvs']=[(y/.25,math.atan2(z,x)/T*.20)for x,y,z in g['_vertices']];bparts.append(g)
 return bparts,['22 cm circular mirror and35.5 cm official overall height','Individual shallow tray base, stepped socket, upright stem, MDF back and detachable circular framed mirror; base diameter/depth interpreted']
def cone():
 # For W20/D15 cm the cone can rest on one generatrix. This analytic pose
 # gives normalY=R/D and overall height2R*sqrt(1-(R/D)^2).
 radius=.10;depth=.15;ny=radius/depth;nz=math.sqrt(1-ny*ny);axis=math.sqrt(depth*depth-radius*radius)
 normal=np.array([0,ny,nz]);u=np.array([1,0,0]);v=np.array([0,nz,-ny]);c=axis*normal
 parts=[];n=384
 def transform(g):
  g['_vertices']=[tuple(u*x+normal*y+v*z)for x,y,z in g['_vertices']];return g
 parts.append(transform(B.lathe('closed-stainless-cone-body','frame',[(0,0),(.0004,.0005),(radius*(axis-.0006)/axis,axis-.0006),(0,axis-.0006)],n,False)))
 parts.append(transform(B.lathe('separate-flat-polished-stainless-reflecting-face','mirror',[(0,axis-.0001),(radius-.0002,axis-.0001),(radius,axis),(0,axis)],n,False)))
 parts.append(transform(B.lathe('separate-MDF-inner-lining-hidden-behind-disc','back',[(0,axis-.0025),(.096,axis-.0025),(.096,axis-.001),(0,axis-.001)],192,False)))
 return parts,['Analytical resting cone:20 cm disk diameter,15 cm depth and14.90711985 cm derived height','Reflecting surface is polished stainless steel, as official composition; no glass or photographed reflection','Separate steel conical body, polished flat face and internal MDF lining']
FRAME_SPECS={
 '1277126001':(.314,.43,.022,.014,False,'black',None),
 '1277126003':(.314,.43,.022,.014,False,'white',None),
 '1225351002':(.24,.327,.04,.014,False,'black',None),
 '1225351004':(.24,.327,.04,.014,False,'white',None),
 '1092949001':(.174,.234,.018,.012,True,'oak',(.112,.172)),
 '1092946001':(.234,.324,.018,.012,False,'oak',(.156,.246)),
 '1092946002':(.234,.324,.018,.012,False,'black',(.156,.246)),
 '1092937001':(.324,.424,.018,.012,False,'oak',(.204,.304)),
 '1092928001':(.524,.524,.019,.012,False,'oak',(.410,.410)),
}
def frame(pid):
 w,h,d,band,stand,color,matopening=FRAME_SPECS[pid];b=MB.Builder()
 # Four separate real mitered boards, with 0.35mm front/back edge bevels.
 outer=np.array([[-w/2,0],[w/2,0],[w/2,h],[-w/2,h]])
 inner=np.array([[-w/2+band,band],[w/2-band,band],[w/2-band,h-band],[-w/2+band,h-band]])
 for i,label in enumerate(['bottom','right','top','left']):
  j=(i+1)%4;poly=np.array([outer[i],outer[j],inner[j],inner[i]])
  b.slab('separate-mitered-beveled-'+label+'-board','frame',poly,-d*.40,d*.50,.00035)
  g=b.groups[('separate-mitered-beveled-'+label+'-board','frame')]
  g['_uvs']=[((y/.30+.5,x/.055+.5)if i in[1,3]else(x/.30+.5,y/.055+.5))for x,y,z in g['_vertices']]
  g['_flat_normals']=True
 opening=rect(w-band*2,h-band*2,cy=h/2)
 # All inserts are unprinted neutral paper; no brand text, product photo or art.
 b.slab('plain-removable-unprinted-display-paper','paper',opening,-d*.10,d*.03,.00004)
 if matopening:
  matinner=rect(matopening[0],matopening[1],cy=h/2)
  b.ring('separate-offwhite-beveled-passepartout','mat',[(opening,d*.04),(opening,d*.085),(matinner,d*.085),(offset(matinner,-.0006),d*.045)])
 b.slab('separate-clear-acrylic-protective-front','glass',opening,d*.09,d*.14,.00003)
 b.slab('separate-MDF-rear-panel','back',rect(w-band*1.5,h-band*1.5,cy=h/2),-d*.46,-d*.36,.00015)
 for x in[-w*.27,w*.27]:
  p=rect(.009,.015,cy=h*.74,n=32)+[x,0]
  b.slab('rear-retaining-tab-'+str(x),'steel',p,-d*.495,-d*.45,.0001)
 # Small closed hanging loops are an explicitly interpreted unseen detail.
 for x,y in[(0,h*.82),(-w*.25,h*.5)]:
  a=MB.circle(.004,48,cy=y)+[x,0];i=MB.circle(.0022,48,cy=y)+[x,0]
  b.ring('separate-rear-hanging-loop-'+str(x),'steel',[(a,-d*.5),(a,-d*.46),(i,-d*.46),(i,-d*.5)])
 if pid.startswith(('1277126','1225351')):
  # Storage frames have a visible opening seam and separate hinge components.
  for y in[h*.24,h*.76]:
   b.slab('storage-front-side-hinge-'+str(y),'steel',rect(.004,.027,cy=y,n=32)+[-w/2+.003,0],-d*.35,d*.23,.0001)
 if stand:
  # Source photograph shows an open easel. Tilt only the front assembly8deg.
  angle=math.radians(8);cc=math.cos(angle);ss=math.sin(angle)
  for g in b.groups.values():g['_vertices']=[(x,cc*y+ss*z,-ss*y+cc*z)for x,y,z in g['_vertices']]
  st=rect(w*.40,h*.59,cy=h*.33,n=80)
  # Inclined stand meets the floor behind the frame and the hinge at~60%height.
  gg=MB.Builder();gg.slab('separate-open-black-MDF-easel-stand','back',st,-.002,.002,.0002)
  g=rawparts(gg)[0]
  vals=[]
  for x,y,z in g['_vertices']:
   yy=y-(h*.33-h*.59/2);t=yy/(h*.59)
   vals.append((x,yy*.96,-.085*(1-t)-.033*t+z))
  g['_vertices']=vals;b.groups[(g['name'],g['material'])]=g
  g=ROOT.box('separate-easel-hinge','steel',w*.18,.004,.004,(0,h*.59,-.032));b.groups[(g['name'],g['material'])]=g
 return rawparts(b),['Four independent mitered wooden boards with physical bevels, separate transparent acrylic front and MDF back','Plain paper'+(' and a separate beveled neutral mat'if matopening else'')+'; source lettering/artwork deliberately excluded','Open rear easel matches the small tabletop reference'if stand else'Separate interpreted rear retaining tabs and hanging loops; storage-frame hinges separated where applicable']

PALETTES={
 '1213141001':('wood',[73,40,23],.38,0), '1228551001':('wood',[54,34,23],.43,0),
 '1277362001':('wood',[114,62,35],.42,0), '1339007001':('metal',[231,232,230],.10,1),
 '1231505001':('paint',[5,52,176],.18,0), '1206936002':('paint',[22,21,24],.36,0),
 '1251335002':('metal',[222,222,216],.11,1), '1289466001':('metal',[213,215,213],.14,1),
}
def materials(out,pid,used):
 n=512;rng=np.random.default_rng(int(pid[-6:]));u=np.arange(n)[None,:]/n;v=np.arange(n)[:,None]/n
 grain=np.sin(T*(v*76+np.sin(u*6)*.30))+np.sin(T*(v*189+u*.6))*.20
 fine=rng.normal(0,1,(n,n));broad=np.sin(T*(v*5+u*.13))*.45
 if pid in PALETTES:kind,col,rough,metal=PALETTES[pid]
 else:
  color=FRAME_SPECS[pid][5];kind='wood'if color=='oak'else'paint';col={'oak':[190,150,109],'black':[22,21,20],'white':[231,230,224]}[color];rough=.52 if color=='oak'else .40;metal=0
 defs={'frame':(kind,col,rough,metal),'mirror':('metal',[239,242,240],.035 if pid!='1289466001'else .028,1),'back':('fibre',[47,42,35],.84,0),'steel':('metal',[125,127,125],.31,1),'paper':('paper',[235,235,230],.88,0),'mat':('paper',[235,234,227],.88,0),'glass':('glass',[255,255,255],.035,0)}
 mats={};maps=[]
 for key in sorted(used):
  kind,col,rough,metal=defs[key];nn=n if kind in['wood','fibre','paper','paint']else 8
  if nn==n:
   texture=(grain*.8+broad+fine*.06)if kind=='wood'else fine*.06
   rgb=np.array(col)[None,None,:]+texture[:,:,None]*(4.2 if kind=='wood'else .6)
   height=(grain*.015+fine*.006)if kind=='wood'else fine*.001
   dy,dx=np.gradient(height);normal=np.stack([-dx,-dy,np.ones_like(dx)],2);normal/=np.linalg.norm(normal,axis=2,keepdims=True)
   rr=rough+texture*.008
  else:rgb=np.broadcast_to(np.array(col),(nn,nn,3));normal=np.broadcast_to([0,0,1],(nn,nn,3));rr=np.full((nn,nn),rough)
  orm=np.zeros((nn,nn,3),np.uint8);orm[:,:,0]=255;orm[:,:,1]=np.clip(rr*255,1,254);orm[:,:,2]=round(metal*255)
  for slot,arr in [('albedo',np.clip(rgb,0,255).astype(np.uint8)),('normal',np.rint((normal+1)*127.5).astype(np.uint8)),('orm',orm)]:
   path=out/(key+'-'+slot+'.png');Image.fromarray(arr,'RGB').save(path,optimize=True);maps.append(dict(material=key,slot=slot,path=str(path),sha256=sha(path),native_resolution=[nn,nn]))
  ma=dict(baseColorFactor=[1,1,1,1],baseColorTexture=key+'-albedo.png',normalTexture=key+'-normal.png',metallicRoughnessTexture=key+'-orm.png',normalScale=.15 if kind=='wood'else .02,metallic=1,roughness=1,alphaMode='OPAQUE',doubleSided=False,extras=dict(intrinsic_material=True,photo_pixels_baked=False,baked_reflections=False,native_resolution=[nn,nn],source_guided_palette=True,grain_interpretation='Deterministic intrinsic grain, not a captured exact individual wood pattern'if kind=='wood'else None))
  if key=='glass':ma.update(transmission=.96,ior=1.49,thickness=.0015,attenuationColor=[.99,.995,1],attenuationDistance=.8)
  if pid=='1231505001'and key=='frame':ma.update(clearcoat=.65,clearcoatRoughness=.11)
  if key=='mirror':ma['extras'].update(reflecting_material='polished_stainless_steel'if pid=='1289466001'else'silvered_mirror',metalness=1,intrinsic_roughness=rough)
  mats[key]=ma
 return mats,maps

def make(pid):
 if pid in FRAME_SPECS:return frame(pid)
 return {'1339007001':chrome,'1231505001':wave,'1206936002':grid,'1251335002':asym_metal,'1277362001':tabletop,'1289466001':cone}.get(pid,lambda:mango(pid))()
def build(pid):
 if (R/'frozen-manifest.json').exists():raise RuntimeError('Frozen manifest present; create a new isolated revision instead')
 q=next(x for x in SOURCES if x['sku']==pid);ims=[x for x in MASTERS if x['sku']==pid];im=ims[0]
 parts,features=make(pid)
 pos=np.concatenate([g['_vertices']for g in parts]);lo=pos.min(0);hi=pos.max(0);centre=np.array([(lo[0]+hi[0])/2,lo[1],(lo[2]+hi[2])/2]);extent=hi-lo
 # Exact outside measurements are fitted only for products that publish them.
 exact={'1339007001':[.488,.855,.05],'1277126001':[.314,.43,.022],'1277126003':[.314,.43,.022],'1225351002':[.24,.327,.04],'1225351004':[.24,.327,.04]}
 targets=exact.get(pid,extent);scale=np.array(targets)/extent
 if pid=='1213141001':scale[:2]=[.35,.45]/extent[:2]
 if pid=='1228551001':scale[:2]=[.56,.765]/extent[:2]
 if pid=='1231505001':scale[:2]=[.40,.40]/extent[:2]
 if pid=='1206936002':scale[:2]=[.38,.45]/extent[:2]
 if pid=='1251335002':scale[1]=.48/extent[1]
 if pid=='1277362001':scale[1]=.355/extent[1]
 if pid=='1289466001':scale[[0,2]]=[.20,.15]/extent[[0,2]]
 extent*=scale;dims=np.round(extent*100,8).tolist();fmt=lambda x:format(x,'.6g').replace('.','p');id='hm-'+pid+'-h'+fmt(dims[1])+'-w'+fmt(dims[0])+'-d'+fmt(dims[2]);out=R/'models'/id;out.mkdir(parents=True,exist_ok=True)
 meshes=[];checks=[]
 for g in parts:
  g['_vertices']=[tuple((np.array(v)-centre)*scale)for v in g['_vertices']]
  if g['material']in['mirror','paper','mat','glass','back']:g['_flat_normals']=True
  g=G.H.orient(g);m,c=_finalize(g);G.H.S.flatcap_normals(m);meshes.append(m);checks.append(c)
 repairs=G.M.ensure_uv_faces(meshes)+G.H.ensure_float32_uv(meshes)
 used={x['material']for x in meshes};mats,maps=materials(out,pid,used)
 estimated=['local_profile','hidden_backing_and_hardware','optical_parameters']
 if pid not in exact:estimated.append('depth_cm')
 if pid.startswith('10929'):estimated+=['outside_width_cm','outside_height_cm']
 if pid=='1092949001':estimated+=['open_easel_footprint_cm'];
 if pid=='1251335002':estimated+=['outer_width_cm','outer_depth_cm','height_anchor_interpretation']
 notes='ÖlçülerW/H/D sırasındadır. Resmî ölçü ankrajları aşağıda ayrı kaydedildi. Yerel profil, görünmeyen bağlantılar ve optik ayarlar kendi ürün fotoğraflarından yorumlandı; üretici CAD veya taraması değildir.'
 if pid.startswith('10929'):notes+=' Resmî21×30/30×40/50×50 gibi değerler nominal baskı formatıdır; çerçeve dışı ve derinliği doğrulanmadı. Model dış ölçüleri fotoğraf oranına dayalı tahmindir.'
 if pid=='1092949001':notes+=' Açıklama15×21cm der; boyut seçeneklerinde14×21/15×21 belirsizliği var. Dış ölçü ve açık ayak derinliği tahmindir.'
 if pid=='1251335002':notes+=' Resmî32cm genişlik çerçeveyi dışlar; dış halka ve derinlik tahmin edildi. 48cm yükseklik dış halka ankrajı olarak yorumlandı.'
 if pid=='1289466001':notes+='20cm çap ve15cm derinlikten analitik yatış türetildi;14.9071cm yükseklik üretici ölçüsü değildir. Yüzey cam değil parlatılmış paslanmaz çeliktir.'
 if pid=='1277362001':notes+='22cm çap ve35.5cm boy korunur; taban çapı22.6cm ve derinlik fotoğraf yorumudur.'
 evidence=R/'source-evidence'/(pid+'.json')
 dump(evidence,dict(sku=pid,official_url=q['url'],evidence_urls=q['evidence'],observed_date='2026-10-26',source_record=q,pdp_observations_file=str(RESEARCH/'pdp-observations.json'),category_observations_file=str(RESEARCH/'category-observations.json'),raw_directory=str(RESEARCH/'raw'),official_measurements=q['dimensions_cm'],original_image_masters=ims,interpretation_note=notes))
 sourceimages=[dict(url=x['url'],alt=q['name']+' · '+q['color'])for x in ims]
 meta=dict(id=id,sku=pid,brand='H&M Home',name=q['name'],category='Dekoratif aynalar'if q['category']=='mirrors'else'Fotoğraf çerçeveleri',url=q['url'],dimensions_cm=dims,source_dimensions_hwd_cm=[dims[1],dims[0],dims[2]],official_measurements=q['dimensions_cm'],estimated_dimensions=any(x.endswith('_cm')for x in estimated),estimated_fields=estimated,diameter_semantics=notes,scale_note=notes,material_label=' / '.join(q['materials'])+' · '+q['color'],color=q['color'],source_market={'tr_tr':'Türkiye','en_gb':'United Kingdom','de_de':'Germany'}[q['market']],source_size_pointer=str(evidence)+'#official_measurements',source_evidence_files=[str(evidence),str(RESEARCH/'pdp-observations.json'),str(RESEARCH/'category-observations.json')],source_images=sourceimages,original_image=im['path'],original_image_url=im['url'],original_image_sha256=im['sha256'],original_images=[{k:x[k]for k in['path','url','sha256']}for x in ims],variant_status_verbatim='Resmî aynıSKU ürün kimliği ve listelenmiş ölçü ankrajları doğrulandı; stok durumu iddia edilmez.',units='metres',up_axis='Y',origin='bottom bounding-box centre',native_texture_resolution='Intrinsic procedural512px maps; constant smooth optical materials8px. No source images resampled or projected.',photo_pixels_baked=False,baked_reflections=False,source_anomalies=([q['notes']]if q['notes']else[]),geometry_limitations=['Photo interpreted local outline, bevel profiles, unseen backing, stand and hardware; not manufacturer CAD.'],production_scope='17 researched mirrors/frames in2026-10-26 four-category task',model_status='pending_root_browser_review',quality_pending=True)
 if pid=='1289466001':meta['derived_height_cm']=2*.1*math.sqrt(1-(.1/.15)**2)*100
 dump(out/'model.json',dict(metadata=meta,materials=mats,meshes=meshes))
 dump(out/'geometry-validation.json',dict(valid=True,units='metres',up_axis='Y',origin='bottom bounding-box centre',dimensions_metres=extent.tolist(),affine_fit_scale=scale.tolist(),closed_material_solids=True,mesh_count=len(meshes),triangles=sum(c['triangles']for c in checks),meshes=checks,uv_repairs=repairs,photographed_features=features))
 dump(out/'material-validation.json',dict(valid=True,maps=maps,original_master_checks=[dict(path=x['path'],expected_sha256=x['sha256'],actual_sha256=sha(x['path']),unchanged=sha(x['path'])==x['sha256'])for x in ims],source_master_unchanged=all(sha(x['path'])==x['sha256']for x in ims),no_source_photo_upscale=True,photo_pixels_baked=False,baked_reflections=False,physical_mirror_metalness=1,mirror_roughness=mats['mirror']['extras']['intrinsic_roughness']if'mirror'in mats else None))
 report=export_assets(out/'model.json',out,id);glb=out/(id+'.glb');doc,binary=read_glb(glb);doc['samplers']=[dict(magFilter=9729,minFilter=9987,wrapS=10497,wrapT=10497)]
 for tex in doc.get('textures',[]):tex['sampler']=0
 binary=G.M.embed_tangents(doc,binary);write_glb(glb,doc,binary)
 assert glb.stat().st_size<96*1024*1024
 report['deliverable_sha256']['glb']=sha(glb);report['glb_bytes']=glb.stat().st_size;dump(report['files']['validation'],report)
 entry=dict(meta);entry.update(asset_dir=str(out),model_path=str(out/'model.json'),glb_path=str(glb),sha256=sha(glb),bytes=glb.stat().st_size,geometry_validation=str(out/'geometry-validation.json'),material_validation=str(out/'material-validation.json'),model_revision='hm-mirrors-frames-source-specific-2026-10-26-v1',size_source_kind='official_tr_public_pdp'if q['market']=='tr_tr'else'official_other_market_same_exact_sku',size_source_urls=q['evidence'])
 dump(out/'entry.json',entry)
 entries=json.loads((R/'manifest.json').read_text())if(R/'manifest.json').exists()else[];entries=[x for x in entries if x['sku']!=pid]+[entry];dump(R/'manifest.json',entries)
 print('BUILT',pid,len(meshes),'meshes',glb.stat().st_size,'bytes',dims,flush=True)
if __name__=='__main__':
 for pid in sys.argv[1:]or[x['sku']for x in SOURCES]:build(pid)
