"""Append exact observed gallery references without changing approved models."""
from pathlib import Path
from urllib.parse import urlsplit
import copy, hashlib, json

P=Path(__file__).resolve().parent
SITE=P.parents[2]/'sites/zarahome-vazo-kutuphanesi-final-378'
source=P/'lighting-research/confirmed-queue.research-final-02.json'
assert hashlib.sha256(source.read_bytes()).hexdigest()=='92962d5eac45d0f22df58749e132a995aec2d7c2045f85208611c38857fbc004'
read=lambda f:json.loads(f.read_text())
target=SITE/'ui/hmhome-discovered.json'
data=read(target);before=copy.deepcopy(data);by_sku={e['sku']:e for e in data['products']}
changes=[]
for researched in read(source):
    sku=researched['sku'];entry=by_sku[sku]
    assert entry['category_id']=='lighting' and researched['source_research_complete']
    if entry['model_status']=='ready':continue
    have={urlsplit(p['url']).path for p in entry['reference_images']}
    added=0
    for photo in researched['gallery_images']:
        url=photo['url'];parsed=urlsplit(url)
        assert parsed.scheme=='https' and parsed.hostname=='image.hm.com' and parsed.path.lower().endswith('.jpg')
        if parsed.path in have:continue
        entry['reference_images'].append(dict(url=url,thumbnail_url=url,alt=photo.get('alt')or entry['name']))
        have.add(parsed.path);added+=1
    entry['model_status']='pending_model'
    entry['source_research_complete']=True
    entry['status_note']='Resmî ürün sayfası ve fotoğraf galerisi incelendi. Modelleme ve kalite kontrolü sürüyor. Kaynakta yayımlanmayan ölçüler tahmin olarak belirtilecek.'
    details=entry.setdefault('source_details',{})
    details['measurements_research_status']=researched['measurements_research_status']
    details['material_source_complete']=researched['material_source_complete']
    details['all_visible_gallery_references_complete']=researched['all_PDP_gallery_complete']
    details['official_pdp_records']=[r for r in researched.get('pdp_detail_records',[])if r.get('pdp_identity_verified')]
    entry['source_evidence_files']=list(dict.fromkeys(entry.get('source_evidence_files',[])+researched.get('source_evidence_files',[])+[str(source)]))
    changes.append(dict(sku=sku,added_photos=added,total_photos=len(entry['reference_images'])))
assert len(data['products'])==len(before['products'])
assert {e['sku']for e in data['products']}=={e['sku']for e in before['products']}
for old in before['products']:
    if old['model_status']=='ready' or old['category_id']!='lighting':assert by_sku[old['sku']]==old
target.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
proof=dict(changed_products=len(changes),added_original_photo_urls=sum(e['added_photos']for e in changes),ready_products_unchanged=True,product_identities_unchanged=True,new_models=0,source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),changes=changes)
(P/'lighting-gallery-enrichment-proof.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in proof.items()if k!='changes'}))
