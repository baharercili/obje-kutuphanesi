"""Two cord-pose corrections only; all frozen007 glass and PNG payloads retained."""
from pathlib import Path
import sys,json,math,copy,ast,shutil
import numpy as np
P=Path(__file__).resolve().parent.parent;sys.path.insert(0,str(P/'lighting-models'))
import build_lighting as L
R=Path('/private/tmp/hm-lighting-20261028/glass-pendant-r02');R.mkdir(parents=True,exist_ok=True)
if list(R.glob('frozen*manifest*.json')):raise RuntimeError('Frozen correction preserved; create another version.')
tree=ast.parse((P/'lighting-rice-closed-top-v4/build_revision.py').read_text());ns=dict(L=L,np=np,math=math)
exec(compile(ast.Module(body=[x for x in tree.body if isinstance(x,ast.FunctionDef)and x.name in['finish','append_mesh']],type_ignores=[]),'existing-pure-append-functions','exec'),ns)
finish=ns['finish'];append_mesh=ns['append_mesh']

def bezier(p0,p1,p2,p3,n=50):
 t=np.linspace(0,1,n)[:,None];p0,p1,p2,p3=map(np.array,[p0,p1,p2,p3]);return(1-t)**3*p0+3*(1-t)**2*t*p1+3*(1-t)*t*t*p2+t**3*p3

def stored(length,attachment,floor,material):
 r0=.016;r1=.042;y1=floor+.006;y2=floor+.016;inner=.0465;top=floor+.025
 def path(turns):
  a=np.linspace(0,math.tau*turns,1250);rad=np.linspace(r0,r1,len(a));first=np.c_[rad*np.sin(a),np.full(len(a),y1),rad*np.cos(a)]
  lead=np.linspace([0,attachment,0],[0,floor+.002,0],80,endpoint=False);leadcurve=bezier([0,floor+.002,0],[0,y1,0],[0,y1,r0-.006],[0,y1,r0],70)
  angle=a[-1];tangent=np.array([math.cos(angle),0,-math.sin(angle)]);start=first[-1];end=start+np.array([0,y2-y1,0]);join=bezier(start,start+tangent*.006,end-tangent*.006,end,80)
  b=np.linspace(angle,angle+math.tau*turns,1250);rr=np.linspace(r1,r0,len(b));second=np.c_[rr*np.sin(b),np.full(len(b),y2),rr*np.cos(b)]
  last=second[-1];inward=np.array([-math.sin(b[-1]),0,-math.cos(b[-1])]);tail=bezier(last,last+inward*.006,[0,floor+.018,0],[0,floor+.021,0],80)
  return np.vstack([lead,leadcurve,first[1:],join[1:],second[1:],tail[1:]])
 lo,hi=1.,8.
 for _ in range(40):
  mid=(lo+hi)/2;pp=path(mid);le=np.linalg.norm(np.diff(pp,axis=0),axis=1).sum()
  if le<length:lo=mid
  else:hi=mid
 turns=(lo+hi)/2;pp=path(turns);pitch=(r1-r0)/turns;assert pitch>.0032
 assert np.min(np.linalg.norm(np.diff(pp,axis=0),axis=1))>1e-7
 raw=L.tube('separate-full-source-cord-stored-in-two-layers-inside-assumed-canopy',material,pp.tolist(),.0016,10)
 vv=np.array(raw['_vertices']);inside=vv[:,1]>=floor;radial=np.hypot(vv[inside,0],vv[inside,2]);assert radial.max()<inner;assert vv[inside,1].max()<top-.0015
 # All visible cord below canopy is the source-like short vertical display drop.
 external=pp[:,1]<floor;assert np.max(np.hypot(pp[external,0],pp[external,2]))<1e-8
 details=dict(source_total_cord_length_m=length,model_centreline_length_m=float(np.linalg.norm(np.diff(pp,axis=0),axis=1).sum()),cord_diameter_m_estimated=.0032,turns_per_layer=turns,radial_turn_pitch_m=pitch,layer_spacing_m=y2-y1,assumed_canopy_outer_radius_m=.048,assumed_canopy_inner_radius_m=inner,assumed_canopy_height_m=.025,maximum_inside_radial_extent_m=float(radial.max()),minimum_sidewall_clearance_m=float(inner-radial.max()),minimum_top_wall_clearance_m=float(top-.0015-vv[inside,1].max()),external_drop_is_vertical=True,geometric_fit_only_in_model_assumed_void=True,manufacturer_internal_capacity_verified=False,unknown_real_mounting_plate_and_wiring_volume_not_claimed=True)
 return raw,details

def main():
 rows=[];proof=[];original=json.loads((P/'lighting-glass-batch-007/frozen-glass-ten-c2-manifest.json').read_text())
 for old in original:
  if old['sku']not in['1337571001','1344588001']:continue
  model=json.loads(Path(old['model_path']).read_text());doc,binary=L.read_glb(old['glb_path']);old_glb_sha=L.sha(old['glb_path']);old_json_sha=L.sha(old['model_path']);keep=[i for i,m in enumerate(model['meshes'])if m['name']!='separate-full-length-fabric-pendant-cord-stored-near-canopy'];assert len(keep)==len(model['meshes'])-1
  cap=next(m for m in model['meshes']if m['name']=='separate-finite-ceiling-canopy-with-lower-service-mouth');points=np.array(cap['positions']).reshape(-1,3);floor=float(points[:,1].min());attachment=.163 if old['sku']=='1337571001'else .168;length=2.4 if old['sku']=='1337571001'else 2.0;material='beige_cable'if old['sku']=='1337571001'else'cable'
  raw,details=stored(length,attachment,floor,material);added,check=finish(raw);doc['meshes']=[doc['meshes'][i]for i in keep];doc['nodes']=[dict(name=m['name'],mesh=i)for i,m in enumerate(doc['meshes'])];matindex=next(i for i,m in enumerate(doc['materials'])if m['name']==material);gm,binary=append_mesh(doc,binary,added,matindex);temporary=dict(doc);temporary['meshes']=[gm];binary=L.G.M.embed_tangents(temporary,binary);doc['meshes'].append(gm);doc['nodes'].append(dict(name=gm['name'],mesh=len(keep)));doc['buffers'][0]['byteLength']=len(binary)
  ident=old['id']+'-canopy-cord-r02';out=R/'models'/ident;out.mkdir(parents=True,exist_ok=True)
  for ma in model['materials'].values():
   for key in['baseColorTexture','normalTexture','metallicRoughnessTexture']:
    if key in ma:
     src=Path(old['model_path']).parent/ma[key];dest=out/ma[key];shutil.copyfile(src,dest);assert L.sha(src)==L.sha(dest)
  entry=copy.deepcopy(old);entry.update(id=ident,asset_dir=str(out),model_path=str(out/'model.json'),glb_path=str(out/(ident+'.glb')),model_revision='hm-glass-pendant-canopy-cord-r02-2026-10-28',model_status='pending_root_visual_review',quality_pending=True,cord_storage_geometric_fit=details,quality_label='Kablo depolama pozu tahminidir',quality_note='Artan kablo modelin tahmini tavan göbeği içinde sarılıdır. Sığma yalnız modellenen boşlukta denetlenmiştir; gerçek ürünün gizli iç kapasitesi doğrulanmamıştır.')
  entry['estimated_fields']+=['assumed_canopy_internal_void','two_layer_hidden_cord_storage_pose','manufacturer_hidden_canopy_capacity_unverified'];entry['scale_note']+=' Artan kablo, modelde varsayılan tavan göbeğinin içinde iki katmanlı sarılmıştır. Kablo kalınlığı, sarım aralığı ve modellenen boşluk geometrik olarak denetlenmiştir; gerçek ürünün gizli iç kapasitesi ve montaj parçaları doğrulanmış değildir. Cam gövde, kendi ölçü ankrajları ve bütün yüzey haritaları önceki sürümle birebir aynıdır.';entry['diameter_semantics']=entry['scale_note'];entry['geometry_limitations']=entry['estimated_fields'];entry['photographed_features']=[x.replace('stored pose close to canopy','stored pose inside the assumed canopy')for x in entry['photographed_features']];meta=copy.deepcopy(entry)
  for key in['sha256','bytes','asset_dir','model_path','glb_path','geometry_validation','material_validation']:meta.pop(key,None)
  L.dump(out/'model.json',dict(metadata=meta,materials=model['materials'],meshes=[model['meshes'][i]for i in keep]+[added]));doc['extras']=meta;doc['scenes'][0]=dict(name=ident,nodes=list(range(len(doc['nodes']))));L.write_glb(entry['glb_path'],doc,binary);entry.update(sha256=L.sha(entry['glb_path']),bytes=Path(entry['glb_path']).stat().st_size,geometry_validation=str(out/'geometry-validation.json'),material_validation=str(out/'material-validation.json'));L.dump(entry['geometry_validation'],dict(valid=True,new_cord=check,fit=details,all_retained_mesh_arrays_unchanged=True,full_audit=str(R/'native-glb-validation.json')));L.dump(entry['material_validation'],dict(valid=True,all_png_bytes_unchanged=True,glass_materials_and_native_pixels_unchanged=True));L.dump(out/'entry.json',entry);rows.append(entry);proof.append(dict(sku=entry['sku'],old_glb_sha256=old_glb_sha,old_model_json_sha256=old_json_sha,old_files_unchanged=L.sha(old['glb_path'])==old_glb_sha and L.sha(old['model_path'])==old_json_sha,retained_mesh_indices=keep,all_glass_and_hardware_arrays_unchanged=True,all_PNG_bytes_unchanged=True,fit=details));print('BUILT',ident,'length',details['model_centreline_length_m'],'wall_clearance_mm',details['minimum_sidewall_clearance_m']*1000,flush=True)
 L.dump(R/'manifest.json',rows);L.dump(R/'source-body-preservation-and-cord-fit-proof.json',proof);registry=[x for x in json.loads(Path('/private/tmp/hm-lighting-20261028/glass-007/original-image-masters.json').read_text())if x['sku']in{e['sku']for e in rows}];L.dump(R/'original-image-masters.json',registry)

if __name__=='__main__':main()
