"""Add only hidden contacting screw stems; reviewed visible form remains identical."""
from pathlib import Path
import sys,json,math,copy,hashlib
sys.dont_write_bytecode=True
import numpy as np
P=Path('/Users/USER/Documents/ChatGPT/Studio/work/hmhome-dekor/2026-10-26-four-categories');R=Path('/private/tmp/hm-lighting-20261028/branch-two-r03-final');sys.path.insert(0,str(P/'lighting-models'));import build_lighting as L
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
rows=json.loads((R/'manifest.json').read_text());pres=json.loads((R/'prototype-to-final-binary-preservation.json').read_text());proof=[]
for e in rows:
 asset=Path(e['asset_dir']);m=json.loads(Path(e['model_path']).read_text());assert len(m['meshes'])==27;previous=copy.deepcopy(m['meshes']);oldglb,oldbin=L.read_glb(e['glb_path']);shift=np.array(json.loads((asset/'geometry-validation.json').read_text())['common_recentering_translation_m']);new=[];checks=[];contacts=[]
 for j,a in enumerate(m['metadata']['arm_anchor_and_contact_interpretation']):
  ang=math.radians(a['azimuth_degrees_estimated']);beta=math.radians(a['head_axis_tilt_degrees_estimated']);u=np.array([math.sin(ang),0,math.cos(ang)]);t=np.array([math.cos(ang),0,-math.sin(ang)]);v=math.cos(beta)*np.array([0,1,0])-math.sin(beta)*u;nh=np.cross(-t,v);C=np.array(a['contact_centre_m'])-shift;p0=C-nh*.003;p1=C+nh*.004;g=L.tube('separate-estimated-contacting-scroll-screw-shank-'+str(j),'paint',[p0.tolist(),p1.tolist()],.0011,16);mesh,check=L._finalize(L.G.H.orient(g));new.append(mesh);checks.append(check);contacts.append(dict(branch=j,mesh_index=27+j,source_estimated_hidden_screw_shank=True,centreline_length_m=.007,radius_m=.0011,back_endpoint=p0.tolist(),front_endpoint=p1.tolist(),connects_short_back_link_plate_and_recessed_front_fastener=True,visible_cap_profile_unchanged=True))
 L.G.M.ensure_uv_faces(new);L.G.H.ensure_float32_uv(new);m['meshes']+=new;m['metadata']['estimated_fields']=sorted(set(m['metadata']['estimated_fields']+['hidden_contacting_screw_shank_7mm']));m['metadata']['scale_note']+=' Küçük ön vida başını levha ve arka bağlantıya bağlayan 7 mm gizli vida gövdesi ayrıca fotoğraf yorumudur.';m['metadata']['fastener_contact_interpretations']=contacts;dump(e['model_path'],m);gqa=json.loads(Path(e['geometry_validation']).read_text());gqa['hidden_screw_stem_checks']=checks;gqa['all_visible_reviewed_27_meshes_unchanged']=True;dump(e['geometry_validation'],gqa)
 report=L.export_assets(e['model_path'],asset,e['id']);doc,binary=L.read_glb(e['glb_path']);binary=L.G.M.embed_tangents(doc,binary);oldmat={x['name']:x for x in oldglb['materials']}
 for ma in doc['materials']:
  if 'extensions'in oldmat[ma['name']]:ma['extensions']=copy.deepcopy(oldmat[ma['name']]['extensions'])
 doc['extensionsUsed']=sorted(set(doc.get('extensionsUsed',[]))|set(oldglb.get('extensionsUsed',[])));L.write_glb(e['glb_path'],doc,binary);e.update(m['metadata']);e.update(sha256=sha(e['glb_path']),bytes=Path(e['glb_path']).stat().st_size);dump(asset/'entry.json',e);report['deliverable_sha256']['glb']=e['sha256'];report['source_sha256']=sha(e['model_path']);report['glb_bytes']=e['bytes'];dump(report['files']['validation'],report);assert m['meshes'][:27]==previous
 for x in pres:
  if x['sku']==e['sku']:
   x.pop('all_binary_geometry_maps_normals_UV_tangents_payload_identical_to_prototype',None);x.update(final_SHA=e['sha256'],all_existing_27_mesh_arrays_and_materials_maps_identical_to_reviewed_prototype=True,only_added_geometry='Three hidden7mm screw shanks connect front cap through sheet to back mounting link; no visible form or bounds changed.',whole_binary_payload_identical=False)
 proof.append(dict(sku=e['sku'],contacting_fastener_stems=contacts,previous_visible_27_meshes_arrays_identical=True,all_materials_and_maps_unchanged=True,no_global_scale_or_profile_change=True))
dump(R/'manifest.json',rows);dump(R/'prototype-to-final-binary-preservation.json',pres);dump(R/'fastener-contact-completion-proof.json',proof);notes=json.loads((R/'source-and-native-self-review.json').read_text());notes['hidden_contact_completion']='Final audit added only3 short7mm hidden screw shanks perproduct to bridge front cap/plate/back link, preserving all27 reviewed visible/body/hardware meshes and PBR maps.';dump(R/'source-and-native-self-review.json',notes);print('CONTACTS_COMPLETED',len(rows))
