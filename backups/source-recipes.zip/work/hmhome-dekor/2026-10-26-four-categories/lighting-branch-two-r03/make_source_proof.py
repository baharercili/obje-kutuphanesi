from pathlib import Path
import sys,json,hashlib
from PIL import Image,ImageDraw
R=Path(sys.argv[1]);A=Path(__file__).resolve().parent;Q=R/'qa/source-comparisons';Q.mkdir(parents=True,exist_ok=True);proof=[]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for e in json.loads((R/'manifest.json').read_text()):
 sku=e['sku'];orig=e['original_images'];master=lambda token:next(Path(x['path'])for x in orig if token in x['path']);tokens=['97ee375f4d0b','e35442e9044c','c3246632e661']if sku.endswith('001')else['868a5312bf0a','026a4aa6d623','aea57e2e7970'];hero,macro,life=[master(t)for t in tokens];assert all(sha(x['path'])==x['sha256']for x in orig)
 macros=(280,300,1240,1240)if sku.endswith('001')else(40,850,1260,1720)
 rows=[(hero,(100,710,1450,1510),R/'qa/native'/(e['id']+'-scene0')/'source-front-low.png','Own primary; common display height only','Actual model arrays: yaw0 /pitch1.15deg'),(macro,macros,R/'qa/head-macro'/(sku+'-head0')/'ustten.png','Own native macro crop; no resampling before panel','Exact GLB head subset: yaw30 /pitch62deg'),(life,(80,0,2300,900)if sku.endswith('001')else(0,0,2333,2900),R/'qa/native'/(e['id']+'-scene0')/'source-under.png','Own lifestyle, independent view','Same complete model: yaw-85 /pitch-10deg; approximate view')]
 out=Image.new('RGB',(1240,1200),(242,240,235));d=ImageDraw.Draw(out);d.text((16,10),sku+' R03 CANDIDATE / pending root actual review; own-source comparison',fill=(25,25,25));st=[]
 for row,(src,box,native,l1,l2)in enumerate(rows):
  y=40+row*375;im=Image.open(src).convert('RGB').crop(box);nim=Image.open(native).convert('RGBA');bb=nim.getbbox();nim=nim.crop(bb)
  for col,pic in enumerate([im,nim]):
   pic.thumbnail((590,330),Image.Resampling.LANCZOS);xx=col*620+(620-pic.width)//2;yy=y+(335-pic.height)//2
   if pic.mode=='RGBA':out.paste(pic,(xx,yy),pic)
   else:out.paste(pic,(xx,yy))
  d.text((16,y+342),l1,fill=(25,25,25));d.text((636,y+342),l2,fill=(25,25,25));st.append(dict(source=str(src),source_SHA256=sha(src),native_crop_box=box,source_crop_native_pixels=True,panel_display_downsample_only=True,native_model_render=str(native),native_QA_only_material_opaque_fallback=True))
 path=Q/(sku+'-own-source-vs-native-r03.png');out.save(path);proof.append(dict(sku=sku,panel=str(path),model_sha256=e['sha256'],model_dimensions_WHD_cm=e['dimensions_cm'],official_approx_height_cm=45,source_approx_arm_label_cm=61.5,display_operations=st,no_product_photo_pixels_used_in_materials=True,source_SHA_preserved=True,photo_angles_and_unseen_details_interpreted_not_CAD=True,root_actual_review_pending=True))
(Q/'source-comparison-proof.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n');print('SOURCE_NATIVE_PANELS',len(proof))
