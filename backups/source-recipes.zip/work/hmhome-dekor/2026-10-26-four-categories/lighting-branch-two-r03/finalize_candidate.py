"""Prepare new immutable-candidate paths from the reviewed source-frame prototype."""
from pathlib import Path
import sys,json,hashlib,subprocess,copy,datetime
sys.dont_write_bytecode=True
P=Path('/Users/USER/Documents/ChatGPT/Studio/work/hmhome-dekor/2026-10-26-four-categories');A=Path(__file__).resolve().parent;D=Path('/private/tmp/hm-lighting-20261028/branch-two-r03-source-frame-d');F=Path('/private/tmp/hm-lighting-20261028/branch-two-r03-final');F.mkdir(exist_ok=False);sys.path.insert(0,str(P/'lighting-models'));import build_lighting as L
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def rebase(x):
 if isinstance(x,dict):return{k:rebase(v)for k,v in x.items()}
 if isinstance(x,list):return[rebase(v)for v in x]
 return str(F)+x[len(str(D)):]if isinstance(x,str)and x.startswith(str(D))else x
rows=json.loads((D/'manifest.json').read_text());copies=[]
for folder in [D/e['sku']for e in rows]+[D/'originals']:
 for p in sorted(folder.rglob('*')):
  if not p.is_file():continue
  d=F/p.relative_to(D);d.parent.mkdir(parents=True,exist_ok=True);subprocess.run(['/bin/cp','-c',str(p),str(d)],check=True);assert sha(p)==sha(d);copies.append(dict(source=str(p),copy=str(d),initial_SHA=sha(d),APFS_clone_requested=True))
for p in F.rglob('*.json'):dump(p,rebase(json.loads(p.read_text())))
masters=rebase(json.loads((D/'original-image-masters.json').read_text()));dump(F/'original-image-masters.json',masters);final=[];proof=[]
for olde in rows:
 e=rebase(olde);mp=Path(e['model_path']);m=json.loads(mp.read_text());meta=m['metadata'];meta.update(model_status='pending_root_visual_review',quality_pending=True,ready_model_variants=0,source_form_pre_freeze_review_by_root=True)
 meta['scale_note']=meta['scale_note'].replace('montaj deliği konumu','bağlantı vidasının konumu').replace('yaklaşık 3,9 cm','yaklaşık 4 cm')
 for info in meta['scroll_profile_interpretations']:
  info['maximum_outward_head_radius_from_sheet_fastener_m']=info.pop('maximum_outward_head_radius_m')
 meta['source_evidence_files']=list(dict.fromkeys(meta['source_evidence_files']+[str(F/'source-and-native-self-review.json'),str(F/'independent-geometry-map-pose-audit.json')]))
 olddoc,oldbin=L.read_glb(olde['glb_path']);doc,binary=L.read_glb(e['glb_path']);assert binary==oldbin;doc['extras']['metadata']=copy.deepcopy(meta);dump(mp,m);L.write_glb(e['glb_path'],doc,binary);e.update(meta);e.update(sha256=sha(e['glb_path']),bytes=Path(e['glb_path']).stat().st_size);dump(Path(e['asset_dir'])/'entry.json',e)
 reportp=Path(e['asset_dir'])/(e['id']+'.validation.json');report=json.loads(reportp.read_text());report['deliverable_sha256']['glb']=e['sha256'];report['source_sha256']=sha(mp);report['glb_bytes']=e['bytes'];dump(reportp,report)
 assert sha(olde['glb_path'])==olde['sha256'];proof.append(dict(sku=e['sku'],reviewed_prototype_GLb=olde['glb_path'],reviewed_prototype_SHA=olde['sha256'],reviewed_prototype_unchanged=True,final_GLb=e['glb_path'],final_SHA=e['sha256'],all_binary_geometry_maps_normals_UV_tangents_payload_identical_to_prototype=True,changes='Paths, pending-root status, clarified fastener/radial-reference wording, and supporting evidence pointers only. No physical geometry or material change.'));final.append(e)
dump(F/'manifest.json',final);dump(F/'prototype-to-final-binary-preservation.json',proof);dump(F/'APFS-clone-receipt.json',copies)
notes=dict(status='self_review_pending_root_actual_before_freeze',root_pre_freeze_source_review='Root viewed source-frame-d own primary/macro/lifestyle versus native; soft scroll and overall proportions materially closer, authorized bounded beige pose and freeze2 with audits.',all_six_own_originals_checked=True,source_observations=['Both own hero images show three soft rolled metal sheets with differing tilt and broad rounded faces.','Both own macros show a single continuous scroll curvature and a small source fastener near the lower area.','Both own lifestyle photographs confirm the open scroll, curved branch and separate socket/mount family from different views.'],preserved='Official approximate45cm height; source label approximate61.5cm for one arm; interpreted47.5cm tube centrelines retained; nominal14cm half of28cm unrolled cut boundary clearly separated from posed radial extent. All sourcePBRPNG and old frozenGLB unchanged; exact emptyE14 solids retained under rigid pose.',limitations='Local dimensions, mounting offsets, arm azimuths/end heights and unidentifiable hidden angles are own-photo interpretations, not manufacturerCAD. The three own photos are sparse views and do not determine a unique 3Dpose. No zero-RMS or pixel-perfect claim.',source_finish='Each exactSKU retains its own previous source-specific intrinsic paint/cable/socket/steel PNGs and material values; no reflection/shadow/product-picture bake.',holder_connection='Separate short rod links actual arm endpoint to the back of each sheet, collar joins actual emptyE14cup to arm; socket axis/out-of-view placement remains explicitly estimated.',native_review='Whole exact model and exact head subset, standard5views plus frontal yaw0/pitch1.15deg and alternate yaw-85/pitch-10deg. Separate reference angles are labelled, not asserted to be the true photo camera.',root_actual_gate_pending=True,no_canonical_UI_changes=True)
dump(F/'source-and-native-self-review.json',notes);print('FINAL_PATHS_PREPARED',len(final));print([(e['sku'],e['sha256'],e['dimensions_cm'])for e in final])
