"""Independent actual-GLB cylinder, arm, connection, map and preservation checks."""
from pathlib import Path
import json,struct,hashlib,math
import numpy as np
R=Path('/private/tmp/hm-lighting-20261028/branch-two-r03-final');P=Path('/Users/USER/Documents/ChatGPT/Studio/work/hmhome-dekor/2026-10-26-four-categories');old={e['sku']:e for e in json.loads((P/'lighting-branch-two-r02/frozen-own-one-axis-branch-two-r02-manifest.json').read_text())};proto={e['sku']:e for e in json.loads(Path('/private/tmp/hm-lighting-20261028/branch-two-r03-source-frame-d/manifest.json').read_text())};out=[]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for e in json.loads((R/'manifest.json').read_text()):
 raw=Path(e['glb_path']).read_bytes();jl=struct.unpack_from('<I',raw,12)[0];doc=json.loads(raw[20:20+jl]);binary=raw[28+jl:];assert sha(e['glb_path'])==e['sha256'];m=json.loads(Path(e['model_path']).read_text());om=json.loads(Path(old[e['sku']]['model_path']).read_text());pm=json.loads(Path(proto[e['sku']]['model_path']).read_text());assert len(m['meshes'])==30;assert m['meshes'][:27]==pm['meshes'];assert m['materials']==om['materials'];assert m['gltf_material_extensions']=={x['name']:x.get('extensions',{})for x in doc['materials']};assert sha(old[e['sku']]['glb_path'])==old[e['sku']]['sha256'];assert sha(proto[e['sku']]['glb_path'])==proto[e['sku']]['sha256']
 def attr(index):
  a=doc['accessors'][index];v=doc['bufferViews'][a['bufferView']];dt=np.dtype({5126:'<f4',5125:'<u4',5123:'<u2'}[a['componentType']]);k={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}[a['type']];return np.ndarray((a['count'],k),dtype=dt,buffer=binary,offset=v.get('byteOffset',0)+a.get('byteOffset',0),strides=(v.get('byteStride',k*dt.itemsize),dt.itemsize)).copy()
 def positions(i):return attr(doc['meshes'][i]['primitives'][0]['attributes']['POSITION']).astype(float)
 shift=np.array(json.loads(Path(e['geometry_validation']).read_text())['common_recentering_translation_m']);body=[];delta=np.asarray(om['meshes'][0]['positions']).reshape(-1,3)[0]-np.asarray(m['meshes'][0]['positions']).reshape(-1,3)[0]
 for i in [0,1,2,21,22,23]:
  a,b=om['meshes'][i],m['meshes'][i];err=float(np.abs(np.asarray(a['positions']).reshape(-1,3)-delta-np.asarray(b['positions']).reshape(-1,3)).max());assert err<2e-9;assert a['normals']==b['normals']and a['uvs']==b['uvs']and a['indices']==b['indices'];body.append(dict(mesh_index=i,same_shape_and_maps=True,common_translation_only_m=delta.tolist(),max_position_error_m=err))
 arms=[];sheets=[];contacts=[]
 for j,(arm,head,a,s)in enumerate(zip([3,9,15],[4,10,16],e['arm_anchor_and_contact_interpretation'],e['scroll_profile_interpretations'])):
  ang=math.radians(a['azimuth_degrees_estimated']);beta=math.radians(a['head_axis_tilt_degrees_estimated']);u=np.array([math.sin(ang),0,math.cos(ang)]);t=np.array([math.cos(ang),0,-math.sin(ang)]);v=math.cos(beta)*np.array([0,1,0])-math.sin(beta)*u;n=np.cross(-t,v);frame=np.column_stack([-t,v,n]);C=np.array(a['contact_centre_m'])-shift;Carm=u*a['radial_endpoint_m']+np.array([0,a['endpoint_y_m'],0])-shift
  p=positions(arm);rings=p[:160*11].reshape(160,11,3);centres=rings[:,:10,:].mean(1);length=float(np.linalg.norm(np.diff(centres,axis=0),axis=1).sum());assert abs(length-.475)<1e-6;assert np.linalg.norm(centres[-1]-Carm)<1e-7;arms.append(dict(mesh_index=arm,actual_GLB_ring_centreline_length_m=length,source_component_semantics_explicit=True,source_approx61p5_label_m=.615,nominal_interpreted_tube_plus_half_cut_m=length+.14,not_a_claim_of_posed_radial_envelope=True))
  pr=doc['meshes'][head]['primitives'][0];p=positions(head);f=attr(pr['indices']).astype(int).reshape(-1,3);norm=attr(pr['attributes']['NORMAL']).astype(float);q=(p-C)@frame;rr=.16;rad=np.sqrt(q[:,0]**2+(q[:,2]-rr)**2);rerr=np.minimum(abs(rad-(rr-.0005)),abs(rad-(rr+.0005)));assert rerr.max()<1e-7;sg=np.where(rad<rr,1.,-1.);surf=np.all(sg[f]==sg[f[:,0,None]],axis=1);ids=np.unique(f[surf]);expected=np.c_[-q[ids,0]/rad[ids],np.zeros(len(ids)),(rr-q[ids,2])/rad[ids]]*sg[ids,None];expected=expected@frame.T;ne=float(np.linalg.norm(expected-norm[ids],axis=1).max());assert ne<1e-5;flat_u=rr*np.arctan2(q[:,0],rr-q[:,2]);span_u=float(np.ptp(flat_u));span_v=float(np.ptp(q[:,1]));assert abs(span_u-.28)<1e-6 and abs(span_v-.20)<1e-6
  sheets.append(dict(mesh_index=head,actual_cylinder_radius_m=rr,actual_wall_m=.001,max_two_cylinder_position_error_m=float(rerr.max()),max_analytic_surface_normal_error=ne,actual_unrolled_cut_span_m=[span_u,span_v],single_axis_curvature=True,no_flat_meridian_or_conical_triangle_band=True,all_profiles_and_pose_photo_estimated=True))
  # Actual holder/collar vertices stay on the back side of the curved sheet.
  back=[]
  for hi in [head+3,head+4,24+j]:
   hp=(positions(hi)-C)@frame;hrad=np.sqrt(hp[:,0]**2+(hp[:,2]-rr)**2);clearance=float(hrad.min()-(rr+.0005));assert clearance>0;back.append(dict(mesh_index=hi,minimum_back_cylinder_clearance_m=clearance,hardware_behind_curved_leaf=True))
  # Tube caps provide independently readable actual link/collar/shank centres.
  link=positions(head+1)[:34].reshape(2,17,3)[:,:16,:].mean(1);assert np.linalg.norm(link[0]-Carm)<1e-7;assert np.linalg.norm(link[1]-(C-n*.002))<1e-7
  collar=positions(24+j)[:34].reshape(2,17,3)[:,:16,:].mean(1);assert np.linalg.norm(collar[0]-(Carm-u*.003))<1e-7;assert np.linalg.norm(collar[1]-(Carm+u*.008))<1e-7
  shank=positions(27+j)[:34].reshape(2,17,3)[:,:16,:].mean(1);assert np.linalg.norm(shank[0]-(C-n*.003))<1e-7;assert np.linalg.norm(shank[1]-(C+n*.004))<1e-7
  cap_q=(positions(head+2)-C)@n;cap_min,cap_max=float(cap_q.min()),float(cap_q.max());assert cap_min<.004<cap_max
  contacts.append(dict(branch=j,empty_E14_body_and_contact_separate=True,holder_back_clearances=back,actual_short_link_centreline_m=float(np.linalg.norm(link[1]-link[0])),arm_to_collar_and_holder_contiguous=True,back_link_to_plate_and_front_cap_through_hidden_shank_contiguous=True,actual_hidden_shank_length_m=float(np.linalg.norm(shank[1]-shank[0])),front_cap_axis_range_m=[cap_min,cap_max],no_floating_visible_holder=True,hidden_offsets_are_photo_estimates=True))
 maps=[]
 for ma in m['materials'].values():
  for k in ['baseColorTexture','normalTexture','metallicRoughnessTexture']:
   if k not in ma:continue
   a0=Path(old[e['sku']]['asset_dir'])/ma[k];b0=Path(e['asset_dir'])/ma[k];assert sha(a0)==sha(b0);maps.append(dict(name=ma[k],sha256=sha(b0),same_own_SKU_R02_bytes=True))
 assert abs(e['dimensions_cm'][1]-45)<1e-6 and abs(e['measured_cord_length_m']-2)<1e-7
 out.append(dict(sku=e['sku'],valid=True,GLB_sha256=e['sha256'],existing27_reviewed_mesh_arrays_identical_to_prototype=True,added_hidden_7mm_contact_stems_only=True,old_R02_and_prototype_GLB_SHA_unchanged=True,body_components=body,actual_GLB_arm_measurements=arms,actual_GLB_scroll_profile_checks=sheets,physical_contact_checks=contacts,maps=maps,all_nominal_approx_source_semantics_disclosed=True,no_global_affine_scale=True,official_approx_total_height_m=.45,retained_actual_full_cord_m=e['measured_cord_length_m'],root_actual_review_pending=True))
masters=json.loads((R/'original-image-masters.json').read_text())
for x in masters:assert sha(x['path'])==x['sha256']
(R/'independent-geometry-map-pose-audit.json').write_text(json.dumps(dict(valid=True,actual_GLB_candidate_count=2,own_original_JPEGs_fresh_SHA_checked=len(masters),originals_unchanged=True,models=out),ensure_ascii=False,indent=2)+'\n');print('ACTUAL_GLb_PROFILE_CONTACT_MAP_PASS',len(out),'MASTERS',len(masters))
