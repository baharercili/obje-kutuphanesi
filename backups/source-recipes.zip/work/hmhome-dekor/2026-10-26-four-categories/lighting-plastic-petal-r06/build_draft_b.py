"""Narrow own-source plastic-leaf revision. Only this task's output is written."""
from pathlib import Path
import sys,json,math,hashlib,copy,subprocess,datetime
sys.dont_write_bytecode=True
import numpy as np
from PIL import Image
P=Path('/Users/USER/Documents/ChatGPT/Studio/work/hmhome-dekor/2026-10-26-four-categories')
A=Path(__file__).resolve().parent
B=P/'lighting-rattan-petal-chandelier-six-models';F=B/'frozen-own-plastic-petal-source-crown-r05'
sys.path.insert(0,str(B));import geometry_own_six as O
L=O.L;T=math.tau
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def clone(src,dst):
 dst=Path(dst);dst.parent.mkdir(parents=True,exist_ok=True);assert not dst.exists();subprocess.run(['/bin/cp','-c',str(src),str(dst)],check=True);assert sha(src)==sha(dst)
def leaves():
 parts=[];n=10;ny=150;nx=46
 for j in range(n):
  phi=T*j/n;p=[];uv=[]
  for k in range(ny+1):
   q=math.pi*k/ny;s=math.sin(q);c=math.cos(q)
   # Oblate, continuous curved meridian. Broad radial shingles overlap even
   # close to both crowns; the R05 narrow wedges are explicitly removed.
   r=.0375+.0125*c+.176*s**.90
   halfangle=.36+.26*s
   theta=phi+.22*math.sin(2*q)
   for i in range(nx+1):
    u=2*i/nx-1;aa=theta+u*halfangle
    rr=r+(.048*u+.024*u*u)*(.10+.90*s)
    y=.12+.12*c-.008*(1-s)*u*u*c
    p.append((rr*math.cos(aa),y,rr*math.sin(aa)));uv.append((i/nx,k/ny))
  parts.append(O.shell('own-source-broad-rounded-overlapping-plastic-leaf-'+str(j),'plastic_petal',p,uv,ny,nx,.00055))
 pp=np.concatenate([np.asarray(g['_vertices'])for g in parts]);sx=.443/(2*np.linalg.norm(pp[:,[0,2]],axis=1).max());sy=.24/np.ptp(pp[:,1]);ym=pp[:,1].min()
 for g in parts:g['_vertices']=[(x*sx,(y-ym)*sy,z*sx)for x,y,z in g['_vertices']]
 return parts,dict(photo_interpreted_curled_petal_count=10,continuous_oblate_meridian=True,broad_radial_shingle_overlap=True,halfangle_range_radians=[.36,.62],finite_plastic_wall_m=.00055,crown_edge_rounding_m=.008,no_added_inner_fake_cap_or_opaque_backing=True,local_profiles_count_overlap_and_unseen_assembly_are_photo_interpretation=True)
def build(out):
 out=Path(out);out.mkdir(parents=True,exist_ok=False);asset=out/'1251180001';asset.mkdir();oldentry=json.loads((F/'manifest.json').read_text())[0];oldmodel=json.loads(Path(oldentry['model_path']).read_text());old_doc,old_bin=L.read_glb(oldentry['glb_path'])
 masters=[x for x in json.loads((F/'original-image-masters.json').read_text())if x['sku']=='1251180001'];newmasters=[]
 for x in masters:
  assert sha(x['path'])==x['sha256'];dest=out/'originals'/Path(x['path']).name;clone(x['path'],dest);z=dict(x,original_path=x['path'],path=str(dest));newmasters.append(z)
 dump(out/'original-image-masters.json',newmasters)
 for ma in oldmodel['materials'].values():
  for k in ['baseColorTexture','normalTexture','metallicRoughnessTexture']:
   if k in ma:clone(Path(oldentry['asset_dir'])/ma[k],asset/ma[k])
 raw,info=leaves();new=[];checks=[]
 for i,g in enumerate(raw):
  mesh,check=L._finalize(O.G.H.orient(g));new.append(mesh);checks.append(check);print('LEAF',i,flush=True)
 O.G.M.ensure_uv_faces(new);O.G.H.ensure_float32_uv(new)
 meshes=new+copy.deepcopy(oldmodel['meshes'][10:]);pos=np.concatenate([np.asarray(m['positions']).reshape(-1,3)for m in meshes]);lo=pos.min(0);hi=pos.max(0);assert abs(lo[1])<1e-8;assert max(abs(lo[[0,2]]+hi[[0,2]]))<1e-7
 body=np.concatenate([np.asarray(m['positions']).reshape(-1,3)for m in new]);assert abs(np.ptp(body[:,1])-.24)<1e-8;assert abs(2*np.linalg.norm(body[:,[0,2]],axis=1).max()-.443)<1e-8
 meta=copy.deepcopy(oldmodel['metadata']);ident='hm-1251180001-own-rounded-overlap-plastic-petal-r06';dims=((hi-lo)*100).tolist();meta.update(id=ident,dimensions_cm=dims,source_dimensions_hwd_cm=[dims[1],dims[0],dims[2]],verified_model_core_dimensions_cm=dict(zip(['x','y','z'],np.ptp(body,axis=0)*100)),original_images=[{k:x[k]for k in ['path','url','sha256']}for x in newmasters],original_image=next(x['path']for x in newmasters if 'b7c0' in x['path']),original_image_sha256=oldentry['original_image_sha256'],model_status='pending_root_visual_review',quality_pending=True,ready_model_variants=0)
 meta['scale_note']='Resmî 24 cm yükseklik ve 44,3 cm çap plastik başlığın zarfına uygulanır; çap merkezden en büyük radyal uzaklığın iki katıdır, gerçek XZ kutusu ayrıca ölçülür. Tam yükseklik, değişmeden korunan kablo ve konik tavan rozeti pozunu da içerir. Dört özgün fotoğrafa göre geniş, yuvarlak ve örtüşen kıvrımlı yapraklar yorumlandı. On yaprak sayısı, 0,55 mm et kalınlığı, yerel kıvrım ve örtüşme, gizli taşıyıcı ve boş E27 duy ayrıntıları fotoğraf yorumudur; üretici CAD’i veya tarama değildir. Yaprakların arasındaki gerçek açık armatür hacmi korunur; içe sahte opak kapak eklenmedi. Önceki adayın 11 donanım ve kablo parçası, 1,6 m kablo uzunluğu ve konik tavan rozeti aynen korunur. Kablonun rozet içinde saklama pozu ve gizli kapasite yorumu önceki adayla aynıdır; üretici doğrulaması değildir. Kendi pigmenti ve fiziksel PBR haritaları değişmedi, fotoğraf ışığı, gölgesi veya yansıması yüzeye taşınmadı.'
 meta['component_mapping_notes'].update(info);meta['component_mapping_notes'].pop('maximum_midheight_halfangle_radians',None);meta['component_mapping_notes'].pop('radial_neighbour_layer_separation_estimate_m',None)
 meta['estimated_fields']=sorted(set(meta['estimated_fields']+['petal_local_overlap_profile_and_crown_edge_rounding']))
 model=dict(metadata=meta,materials=copy.deepcopy(oldmodel['materials']),meshes=meshes);dump(asset/'model.json',model);dump(asset/'geometry-validation.json',dict(valid=True,new_leaf_meshes=checks,unchanged_hardware_mesh_count=11,all_hardware_JSON_arrays_identical=True,published_height_m=.24,published_diameter_m=.443,source_geometry_info=info))
 maps=[]
 for p in sorted(asset.glob('*.png')):maps.append(dict(path=str(p),sha256=sha(p),preserved_from=str(Path(oldentry['asset_dir'])/p.name)))
 dump(asset/'material-validation.json',dict(valid=True,maps=maps,all_maps_equal_r05=True,all_material_JSON_equal_r05=True,no_baked_reflections=True,no_product_photo_bake=True))
 report=L.export_assets(asset/'model.json',asset,ident);glb=asset/(ident+'.glb');doc,binary=L.read_glb(glb);binary=O.G.M.embed_tangents(doc,binary);oldm={x['name']:x for x in old_doc['materials']}
 for m in doc['materials']:
  if 'extensions' in oldm[m['name']]:m['extensions']=copy.deepcopy(oldm[m['name']]['extensions'])
 doc['extensionsUsed']=sorted(set(doc.get('extensionsUsed',[]))|set(old_doc.get('extensionsUsed',[])));L.write_glb(glb,doc,binary)
 e=dict(meta,asset_dir=str(asset),model_path=str(asset/'model.json'),glb_path=str(glb),sha256=sha(glb),bytes=glb.stat().st_size,geometry_validation=str(asset/'geometry-validation.json'),material_validation=str(asset/'material-validation.json'));dump(out/'manifest.json',[e]);dump(asset/'entry.json',e)
 hardware_equal=all(a==b for a,b in zip(oldmodel['meshes'][10:],model['meshes'][10:]));assert hardware_equal and oldmodel['materials']==model['materials'];assert sha(oldentry['glb_path'])==oldentry['sha256']
 dump(out/'narrow-revision-preservation-proof.json',dict(old_manifest=str(F/'manifest.json'),old_glb_sha256=oldentry['sha256'],old_glb_unchanged=True,changed_mesh_indices=list(range(10)),unchanged_hardware_mesh_indices=list(range(10,21)),hardware_JSON_byte_values_identical=True,materials_JSON_identical=True,maps=maps,source_masters=newmasters,source_images_fresh_SHA_checked=4,no_other_owner_or_canonical_files_changed=True,new_body_height_m=float(np.ptp(body[:,1])),new_body_max_radial_diameter_m=float(2*np.linalg.norm(body[:,[0,2]],axis=1).max()),pose_height_m=float(np.ptp(pos[:,1])),root_actual_visual_approval_pending=True))
 print('BUILT',out,e['sha256'],e['bytes'],flush=True)
if __name__=='__main__':build(sys.argv[1])
