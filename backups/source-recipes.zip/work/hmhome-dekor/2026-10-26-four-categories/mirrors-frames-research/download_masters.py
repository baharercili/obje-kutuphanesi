import json,subprocess,hashlib,re,os
from pathlib import Path
p=Path(__file__).parent
q=json.loads((p/'mirrors-frames-source-queue.json').read_text())
d=p/'official-image-masters';d.mkdir(exist_ok=True)
audit=[]
for r in q['products']:
 seen=set()
 for ix,url in enumerate(r['official_images'],1):
  key=url.split('?')[0]
  if key in seen:continue
  seen.add(key)
  f=d/f"{r['sku']}-{ix:02d}.jpg"
  if not f.exists():
   result=subprocess.run(['curl','-L','--fail','--max-time','30','-sS','-o',str(f),url],capture_output=True,text=True)
   if result.returncode:
    audit.append({'sku':r['sku'],'url':url,'error':result.stderr.strip()});continue
  blob=f.read_bytes()
  if not blob.startswith(b'\xff\xd8'):
   audit.append({'sku':r['sku'],'url':url,'error':'Not JPEG','path':str(f)});continue
  f.chmod(0o444)
  audit.append({'sku':r['sku'],'url':url,'path':str(f.resolve()),'bytes':len(blob),'sha256':hashlib.sha256(blob).hexdigest(),'immutable':True})
(p/'image-master-audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2))
print(json.dumps({'downloaded':sum('sha256' in r for r in audit),'errors':[r for r in audit if 'error' in r]},ensure_ascii=False,indent=2))
