import json,re,csv
from pathlib import Path
from collections import Counter
p=Path(__file__).parent
obs=json.loads((p/'category-observations.json').read_text())
pdps=json.loads((p/'pdp-observations.json').read_text())
rows=[]
def row(sku,name,cat,color,market,dims,materials,notes='',extra=[]):
 url=f'https://www2.hm.com/{market}/productpage.{sku}.html'
 matches=[x for x in pdps if x['url'].endswith(f'productpage.{sku}.html')]
 images=list(dict.fromkeys(i['src'] for x in matches for i in x.get('images',[]) if i['src'].startswith('https://image.hm.com/')))
 variants={v['url']:v.get('name') for x in matches for v in x.get('variants',[]) if v.get('url')}
 rows.append(dict(sku=sku,family=sku[:7],name=name,category=cat,color=color,brand='H&M HOME',market=market,url=url,official_images=images,dimensions_cm=dims,materials=materials,notes=notes,evidence=[url]+extra,observed_color_links=[dict(url=u,color=c) for u,c in variants.items()],queue_status='source_record_only_no_model'))
row('1213141001','Büyük mango ağacı ayna','mirrors','Koyu kahverengi','en_gb',{'width':35,'height':45},['Mango wood','Glass','MDF back'],extra=['https://www2.hm.com/tr_tr/productpage.1213141001.html','https://www2.hm.com/de_de/productpage.1213141001.html'])
row('1277362001','Ahşap masa aynası','mirrors','Kahverengi','en_gb',{'mirror_diameter':22,'overall_height':35.5},['Arjuna wood','MDF back','Glass'],'3x magnification; detachable mirror; depth not specified.',extra=['https://www2.hm.com/de_de/productpage.1277362001.html'])
row('1339007001','Metal ayna','mirrors','Gümüş rengi','en_gb',{'width':48.8,'height':85.5,'depth':5},['Aluminium frame','Glass front','MDF back'],extra=['https://www2.hm.com/de_de/productpage.1339007001.html'])
row('1231505001','Dalgalı ayna','mirrors','Parlak mavi','en_gb',{'diameter':40},['Painted MDF','Glass front'],'Frame depth not specified.')
row('1228551001','Asimetrik mango ağacı ayna','mirrors','Koyu kahverengi','de_de',{'maximum_width':56,'height':76.5},['Mango wood','Glass'],'Official category indexed snapshot and DE PDP; UK live PDP redirects. Not in live enumerated category.',extra=['https://www2.hm.com/en_gb/productpage.1228551001.html'])
rows[-1]['official_images']=['https://image.hm.com/assets/hm/35/75/3575138a60fe2a6150332f8e9ec746b1f6503f2a.jpg?imwidth=2160']
row('1206936002','Metal çerçeveli ayna','mirrors','Siyah','tr_tr',{'width':38,'height':45},['Iron frame','MDF back','Glass front'],'TR live page shows coming soon; depth not specified.')
row('1251335002','Asimetrik metal ayna','mirrors','Gümüş rengi','tr_tr',{'width_excluding_frame':32,'height':48},['Iron frame','MDF back','Glass'],'Width explicitly excludes frame; outer width and depth unknown. Indexed stock says out of stock, initial live DOM shows add-to-bag; availability not asserted.')
row('1289466001','Koni şeklinde ayna','mirrors','Gümüş rengi','tr_tr',{'depth':15,'diameter':20},['Stainless steel','MDF inner lining'],'TR live page out of stock; cone surface itself is reflective metal per composition, no glass specified.')
for sku,color in [('1277126001','Siyah'),('1277126003','Beyaz')]:
 row(sku,'Çocuk resimleri için büyük çerçeve','frames',color,'en_gb',{'width':31.4,'height':43,'depth':2.2},['Oak frame','Paper inside panel','Acrylic front','MDF back'],'Description says oak; outer dimensions provided.',extra=([f'https://www2.hm.com/tr_tr/productpage.{sku}.html'] if sku.endswith('003') else []))
row('1092949001','Ahşap fotoğraf çerçevesi','frames','Açık bej','tr_tr',{'nominal_photo_width':15,'nominal_photo_height':21},['Wood','Plastic glazing','MDF back'],'Outer dimensions/depth unknown. Description supports photos up to 15x21; live size choices contain 14x21 and 15x21, both out of stock. Keep size discrepancy explicit.')
for sku,color in [('1092946001','Açık bej'),('1092946002','Siyah')]:
 row(sku,'Ahşap çerçeve 21x30','frames',color,'tr_tr',{'nominal_size_width':21,'nominal_size_height':30},['Wood','Plastic glazing','MDF back','Metal hangers'],'Live size label is 21x30, probably print format; outer dimensions/depth unverified. Out of stock.')
row('1092928001','Ahşap çerçeve 50x50','frames','Açık bej','tr_tr',{'nominal_size_width':50,'nominal_size_height':50},['Oak','Acrylic glazing','MDF back','Metal hangers'],'Live size label is 50x50, probably print format; outer dimensions/depth unverified. Out of stock.')
row('1092937001','Ahşap çerçeve 30x40','frames','Açık bej','tr_tr',{'nominal_size_width':30,'nominal_size_height':40},['Pine','Plastic glazing','MDF back','Metal hangers'],'Live size label is 30x40, probably print format; outer dimensions/depth unverified. Out of stock.')
for sku,color in [('1225351002','Siyah'),('1225351004','Beyaz')]:
 row(sku,'Çocuk resimleri için çerçeve','frames',color,'tr_tr',{'width':24,'height':32.7,'depth':4},['Pine frame','Paper inside panel','Acrylic front','MDF back'],'Description calls frame oak, but official composition says pine; composition retained. Black live nominal size is 31x22.5, distinct from stated outer dimensions. White redirects to homepage in live browser; indexed official PDP persists.')
rows[-1]['official_images']=['https://image.hm.com/assets/hm/96/d5/96d5ccd352e53367ea060f43f676a56b6cec9ce2.jpg?imwidth=2160']
# Deduplicate media and retain all observed resolutions verbatim.
for r in rows:
 r['official_images']=list(dict.fromkeys(r['official_images']))
 r['main_image']=r['official_images'][0] if r['official_images'] else None
 r['color_variants_in_verified_queue']=[dict(sku=x['sku'],color=x['color']) for x in rows if x['family']==r['family']]
# Preserve all marketplace records and complete pagination evidence.
partners=[]
reconcile=[]
for key,pages,market,cat in [('ukMirrors',[obs['ukMirrors']],'en_gb','mirrors'),('ukFrames',[obs['ukFrames']],'en_gb','frames'),('deMirrors',obs['deMirrors'],'de_de','mirrors'),('deFrames',obs['deFrames'],'de_de','frames')]:
 entries=[]
 for ix,page in enumerate(pages,1):
  for r in page['articles']:
   sku=r.get('sku') or re.search(r'productpage\.(\d+)',r['url']).group(1)
   entries.append(dict(sku=sku,name=r['name'],brand=r['brand'],url=r.get('url') or f'https://www2.hm.com/{market}/productpage.{sku}.html',page=ix))
  for r in entries:
   if r['brand']!='H&M': pass
 partners += [dict(**r,market=market,category=cat,exclusion_reason='Marketplace partner; requested H&M HOME scope') for r in entries if r['brand']!='H&M']
 reconcile.append(dict(key=key,market=market,category=cat,total_shown=int(re.search(r'\d+',pages[0]['count']).group()),page_counts=[len(x['articles']) for x in pages],unique_skus=len(set(x['sku'] for x in entries)),brands=dict(Counter(x['brand'] for x in entries)),category_hm_skus=[x['sku'] for x in entries if x['brand']=='H&M'],last_page_pagination=pages[-1]['pagination'],observed_urls=[x['url'] for x in pages]))
# 0 counts from official rendered/indexed TR responses; no page 2 possible.
for cat,url in [('mirrors','https://www2.hm.com/tr_tr/home/urune-gore-satin-al/dekorasyon/ayna.html'),('frames','https://www2.hm.com/tr_tr/home/urune-gore-satin-al/dekorasyon/cercerve.html')]:
 reconcile.append(dict(market='tr_tr',category=cat,total_shown=0,page_counts=[0],unique_skus=0,brands={},method='Official web reader response',observed_urls=[url],last_page_pagination=[],note='Category count zero does not negate retained indexed/stock-out PDP records.'))
output=dict(observed_date='2026-10-26',scope='All live category records in TR+UK+DE, restricted to H&M HOME; supplement with discovered official indexed PDPs. No guessed SKU or product.',products=rows,total=len(rows),category_counts=dict(Counter(x['category'] for x in rows)),reconciliation=reconcile,limitations=['Full live category enumeration is reconciled. Historical stock-out archive has no official total; search supplementation cannot certify the entire historical archive.','Only officially observed colors are included. No fabricated variant URLs.','Some frames publish nominal print format rather than exterior dimensions; model must not claim exterior dimensions until verified.','PDP image lists may contain only the first lazy-loaded image; all captured official URLs are retained.'])
(p/'mirrors-frames-source-queue.json').write_text(json.dumps(output,ensure_ascii=False,indent=2))
(p/'excluded-marketplace-records.json').write_text(json.dumps(partners,ensure_ascii=False,indent=2))
with (p/'mirrors-frames-source-queue.csv').open('w',newline='') as f:
 fields=['sku','name','category','color','market','url','main_image','dimensions_cm','materials','notes']
 w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
 for r in rows:w.writerow({k:json.dumps(r[k],ensure_ascii=False) if isinstance(r[k],(list,dict)) else r[k] for k in fields})
print(json.dumps({'products':len(rows),'category_counts':output['category_counts'],'reconciled':reconcile,'excluded_partner_records':len(partners),'missing_images':[r['sku'] for r in rows if not r['main_image']]},ensure_ascii=False,indent=2))
