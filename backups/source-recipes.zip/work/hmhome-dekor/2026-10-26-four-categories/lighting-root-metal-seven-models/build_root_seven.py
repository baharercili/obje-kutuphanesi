"""Seven reserved exact-SKU lighting candidates. No canonical writes.

All hidden construction and intrinsic colour/roughness are photo interpretations.
The first scene shows the fixture; a second scene includes its stored loose cord.
"""
from pathlib import Path
import sys, json, math, hashlib, importlib.util
import numpy as np
from PIL import Image, ImageFilter

sys.dont_write_bytecode = True
P = Path(__file__).resolve().parent.parent
ROOT = Path(__file__).resolve().parent
R = Path('/private/tmp/hm-lighting-20261028/root-metal-seven-models')
R.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(P / 'lighting-models'))
import build_lighting as L

packet = json.loads((P / 'lighting-models/root-metal-seven-production-packet.json').read_text())
assert hashlib.sha256((P / 'lighting-models/root-metal-seven-production-packet.json').read_bytes()).hexdigest() == '0466a8e740864100aae90d236d6f04d3d5a86aadb2c71dbdc827dd2615702898'
SOURCES = {q['sku']: q for q in packet['source_products']}
ORIGINALS = [x for rows in packet['already_local_verified_master_clones'].values() for x in rows]
extra = Path('/private/tmp/hm-lighting-20261028/root-metal-seven-source/necessary-own-heroes/verified-necessary-own-heroes.json')
if extra.exists():
    ORIGINALS += json.loads(extra.read_text())
assert len(SOURCES) == 7
for im in ORIGINALS:
    assert L.sha(im['path']) == im['sha256']
L.R = R
L.sources = lambda: SOURCES
L.update_ledger = lambda: None
L.dump(R / 'original-image-masters.json', ORIGINALS)
T = math.tau

FACTS = {
    '0924200001': dict(socket='E14', watt=4, cord=2.0, source='https://www2.hm.com/de_de/productpage.0924200001.html', description_glass_and_wood=True),
    '0943083001': dict(socket='E14', watt=4, cord=2.0, source='https://www2.hm.com/en_gb/productpage.0943083001.html', description_glass_and_wood=True),
    '1017740027': dict(socket='GU9/G9', watt=4, cord=1.6, source='https://www2.hm.com/de_de/productpage.1017740027.html'),
    '1024398021': dict(socket='GU9/G9', watt=4, cord=1.6, source='https://www2.hm.com/en_gb/productpage.1024398021.html'),
    '1024398022': dict(socket='GU9/G9', watt=4, cord=1.6, source='https://www2.hm.com/en_gb/productpage.1024398022.html'),
    '1337564001': dict(socket='E14', watt=6, cord=1.6, source='https://www2.hm.com/de_de/productpage.1337564001.html', electrical_source=str(P/'lighting-research/root-pdp-1337564001-accordion-v2.json')),
    '1337565001': dict(socket='E14', watt=6, cord=1.6, source='https://www2.hm.com/en_gb/productpage.1337565001.html'),
}
L.dump(R / 'official-source-enrichment.json', dict(observed_date='2026-10-28', facts=FACTS,
    arch_wall_discrepancy='Own description names a glass shade and wooden mounting plate; own composition table lists iron and plastic only. Both source statements retained; wood species and coating unknown.',
    shade_socket_no_bulbs=True, no_source_quotes_or_reflections_baked=True))

def trans(g, centre):
    g['_vertices'] = [tuple(np.asarray(v) + centre) for v in g['_vertices']]
    return g

def on_wall(g, centre):
    # Lathe axis +Y becomes outward +Z. Mounting wall remains at z=0.
    g['_vertices'] = [(x + centre[0], z + centre[1], y + centre[2]) for x, y, z in g['_vertices']]
    return g

def g9(y):
    parts = [L.RO.box('separate-G9-ceramic-empty-socket', 'ceramic', .018, .022, .011, (0, y+.011, 0))]
    for x in [-.0045, .0045]:
        parts.append(L.RO.box('separate-G9-contact-recess-'+str(x), 'socket', .0028, .002, .0032, (x, y+.022, 0)))
    return parts

def dome(name, material, radius, bottom, top, wall=.0012):
    angle = np.linspace(0, math.pi/2, 90)
    outer = [(radius*math.cos(a), bottom+(top-bottom)*math.sin(a)) for a in angle]
    outer[-1] = (0, top)
    inner = [((radius-wall)*math.cos(a), bottom+(top-bottom-wall)*math.sin(a)) for a in angle[::-1]]
    inner[0] = (0, top-wall)
    return L.B.lathe(name, material, outer+inner, 224, True)

def cable(length, start, radius, centre=(0,.0035,0), vertical=False, colour='cable'):
    start=np.array(start, float); centre=np.array(centre, float); r0=.016
    def points(turns):
        first = -math.pi/2 if vertical else math.pi/2
        a=np.linspace(first, first+T*turns, 900); rr=np.linspace(r0,radius,len(a))
        local=np.c_[rr*np.cos(a), rr*np.sin(a), np.zeros(len(a))] if vertical else np.c_[rr*np.cos(a), np.zeros(len(a)), rr*np.sin(a)]
        coil=local+centre
        return np.vstack([np.linspace(start,coil[0],30,endpoint=False),coil])
    low=.1; high=18
    for _ in range(42):
        turns=(low+high)/2; pp=points(turns); measured=np.linalg.norm(np.diff(pp,axis=0),axis=1).sum()
        if measured < length: low=turns
        else: high=turns
    pp=points((low+high)/2); measured=float(np.linalg.norm(np.diff(pp,axis=0),axis=1).sum())
    pitch=(radius-r0)/((low+high)/2)
    assert pitch>.0034, 'Stored turns must have finite clearance.'
    parts=[L.tube('stored-cord-full-published-length',colour,pp.tolist(),.00145,10)]
    pos=pp[int(len(pp)*.92)]
    parts.append(L.RO.box('stored-cord-inline-switch','switch',.024,.008,.012,(pos[0],pos[1]+(.001 if vertical else .005),pos[2])))
    parts.append(L.RO.box('stored-cord-switch-rocker','switch',.014,.003,.007,(pos[0],pos[1]+(.005 if vertical else .0105),pos[2]+(.005 if vertical else 0))))
    return parts, measured, pitch

def arch_wall(q):
    # Approximate source Width29 interpreted as deployed outreach, not height.
    parts=[]
    # Oval wooden mount with rounded perimeter, finite depth, no room pixels.
    g=L.lathe('separate-oval-wooden-wall-mount','wood',[(0,0),(.018,0),(.021,.0015),(.021,.0125),(.018,.014),(0,.014)],160)
    g['_vertices']=[(x, z*(.100/.021)+.310, y)for x,y,z in g['_vertices']]
    g['_uvs']=[(x/.04+.5,(y-.210)/.16)for x,y,z in g['_vertices']]
    parts.append(g)
    pp=[(0,y,.025)for y in np.linspace(.105,.405,80)]
    pp += [(0,.405+.145*math.sin(a),.1125+.0875*math.cos(a))for a in np.linspace(math.pi,0,120)][1:]
    parts.append(L.tube('separate-continuous-adjustable-brass-finish-arch','brass',pp,.0032,14))
    for y in [.235,.379]:
        parts.append(on_wall(L.lathe('separate-adjustable-collar-'+str(y),'brass',[(0,0),(.006,0),(.006,.017),(0,.017)],96),(0,y,.012)))
        parts.append(on_wall(L.lathe('separate-collar-thumb-fastener-'+str(y),'brass',[(0,0),(.004,0),(.004,.003),(0,.003)],64),(.009,y,.028)))
    # A short exposed fabric lead joins the arch tip to the cylindrical cap.
    parts.append(L.tube('separate-short-head-fabric-lead','white_cable',[(0,.405,.20),(0,.388,.20)],.0014,10))
    parts.append(trans(L.lathe('separate-brass-finish-socket-cap','brass',[(0,.346),(.016,.346),(.017,.348),(.017,.383),(.015,.387),(0,.387)],144),(0,0,.20)))
    # Own described glass, finite wall and a real underside opening.
    prof=[(.090,.292),(.090,.294),(.020,.348),(.017,.350),(.016,.348),(.018,.346),(.0875,.292)]
    parts.append(trans(L.B.lathe('separate-open-bottom-conical-white-glass','opal',prof,224,True),(0,0,.20)))
    holder=L.holder(.319,'E14')
    for g in holder:
        g['_vertices']=[(x,.662-y,z)for x,y,z in g['_vertices']]
    parts.extend(trans(g,(0,0,.20)) for g in holder)
    for y in [.242,.379]:
        parts.append(on_wall(L.lathe('separate-wood-mount-fixing-head-'+str(y),'brass',[(0,0),(.0028,0),(.0028,.0013),(0,.0013)],64),(0,y,.0141)))
    stored,le,pitch=cable(2,(0,.107,.025),.061,(0,.184,.050),True,'white_cable');parts+=stored
    return parts, dict(target_cm=None, official_axes=['approximate_source_width29cm','shade_diameter18cm','cord200cm'],
        estimated=['overall_height_cm','source_Width_mapped_to_wall_outreach','wood_species','mount_dimensions','arm_curve_and_joint_dimensions','glass_thickness','empty_socket_hardware','stored_cord_pose'],
        features=['Own brass-finish arched adjustable arm and oval wooden mounting plate','Separate18cm conical finite white-glass shell with real underside opening and emptyE14holder','Own2mcord; fixture scene and separate full-cord stored-pose scene'],
        measured_cord_length_m=le,stored_cord_turn_pitch_m=pitch,official_fixture_shade_diameter_cm=18,source_width_approximate_cm=29,
        source_width_axis_interpretation='Approximate29cm deployed wall outreach corresponds to modelZ; own source does not publish height.',
        source_material_discrepancy=FACTS[q['sku']]['description_glass_and_wood'],
        material_overrides={'opal':('opal',[236,232,216],.32,0),'wood':('paint',[171,80,39],.42,0),'brass':('metal',[190,143,62],.27,1),'white_cable':('woven',[227,223,210],.83,0),'switch':('plastic',[225,221,209],.45,0),'ceramic':('plastic',[226,225,214],.65,0)},
        scale_note_override='Kendi resmî kaynağındaki yaklaşık29cm en, duvardan dışa uzanım olarak yorumlanmıştır; yükseklik yayımlanmamıştır.18cm başlık çapı ve200cm kablo korunur. Açıklama cam başlık/ahşap duvar kaidesi der; bileşim tablosu yalnız demir/plastik listeler. İki bilgi birlikte saklanmıştır; ahşap türü bilinmez. Kol eğrisi, eklemler, yükseklik ve gizli bağlantılar fotoğraftan tahmindir. Kablo ayrı, armatür zarfında sarılı pozdadır. Ampul dahil değildir; E14/azami4W LED. Üretici CAD dosyası değildir.')

def conical_table(q):
    parts=[L.lathe('separate-tapered-painted-iron-base','body',[(0,0),(.044,0),(.047,.0015),(.047,.005),(.0235,.202),(.022,.207),(0,.207)],224),
        L.lathe('separate-short-chrome-neck','chrome',[(0,.204),(.007,.204),(.007,.222),(0,.222)],128)]
    parts.append(L.B.lathe('separate-shallow-open-bottom-conical-iron-shade','body',[(.130,.219),(.130,.221),(.007,.278),(0,.280),(0,.2785),(.006,.2765),(.1285,.219)],224,True))
    parts.append(L.B.lathe('separate-thin-painted-inner-shade-surface','inner',[(.1283,.2192),(.006,.2762),(0,.2777),(0,.2774),(.006,.2759),(.128,.2192)],224,True))
    parts+=g9(.221)
    stored,le,pitch=cable(1.6,(0,.009,-.046),.107,colour='cable');parts+=stored
    return parts,dict(target_cm=[26,28,26],official_axes=['height28cm','shade_diameter26cm','cord160cm'],estimated=['base_taper_profile','neck_and_socket_hardware','shade_wall_thickness','stored_cord_pose','intrinsic_colour_roughness'],features=['Own taupe shallow cone and tapered iron base','Real open underside, separate short chrome neck and emptyG9ceramic holder; no bulb','Official26cmshade/28cmtotalheight and1.6mcord'],measured_cord_length_m=le,stored_cord_turn_pitch_m=pitch,material_overrides={'body':('paint',[132,113,101],.48,0),'chrome':('metal',[226,227,223],.12,1),'ceramic':('plastic',[229,228,217],.64,0),'switch':('plastic',[36,34,31],.49,0)})

def large_mushroom(q):
    foot=.055; profile=[(0,0),(.052,0),(foot,.003),(foot,.175)]
    profile += [(.014+(foot-.014)*math.cos(a),.175+.047*math.sin(a))for a in np.linspace(0,math.pi/2,60)][1:]
    profile.append((0,.222))
    parts=[L.lathe('separate-rounded-cylindrical-iron-foot','body',profile,224),L.lathe('separate-slender-iron-neck','body',[(0,.218),(.007,.218),(.007,.273),(0,.273)],128),dome('separate-broad-hollow-rounded-iron-shade','body',.185,.269,.370)]
    parts.append(dome('separate-thin-white-inner-shade-coating','inner',.1836,.2694,.3686,.0003))
    parts+=g9(.273)
    stored,le,pitch=cable(1.6,(0,.009,-foot),.140,colour='fabric_cable');parts+=stored
    col=[151,150,89]if q['sku']=='1024398021'else[226,214,165]
    return parts,dict(target_cm=[37,37,37],official_axes=['height37cm','shade_diameter37cm','cord160cm'],estimated=['rounded_base_and_cap_profiles','neck_and_socket_hardware','shade_wall_thickness','stored_cord_pose','intrinsic_colour_roughness'],features=['Own broad rounded cap, narrow short neck and rounded cylindrical base','Separate finite open shade shell, thin inner coating, emptyG9holder and160cmfabric cord','Own olive or yellow source colour; polished highlights are environment reflections'],measured_cord_length_m=le,stored_cord_turn_pitch_m=pitch,material_overrides={'body':('paint',col,.27,0),'fabric_cable':('woven',col,.86,0),'ceramic':('plastic',[230,228,216],.65,0),'switch':('plastic',col,.45,0)})

def round_wall(q):
    # Own product is a gently concave circular rear dish and continuous chrome
    # dome. Black photographic reflections are NOT openings in the dome.
    profile=[(0,.016)]
    for r in np.linspace(.001,.130,100):profile.append((r,.016+.026*(r/.130)**2))
    profile += [(.130,.043),(.1288,.043)]
    for r in np.linspace(.1288,.001,100):profile.append((r,.0148+.026*(r/.130)**2))
    profile.append((0,.0148))
    parts=[on_wall(L.lathe('separate-curved-circular-painted-backplate','body',profile,256),(0,.130,0)),
        on_wall(L.lathe('separate-rear-circular-mounting-case','steel',[(0,0),(.054,0),(.057,.002),(.057,.015),(0,.015)],160),(0,.130,0)),
        on_wall(dome('separate-continuous-chrome-reflector-dome','chrome',.074,.043,.107), (0,.130,0))]
    parts.extend(on_wall(g,(0,.130,.014))for g in L.holder(0,'E14'))
    # Loose cord stored in the *interpreted* 29mm cavity, forward of wall plane.
    stored,le,pitch=cable(1.6,(0,.007,.027),.058,(0,.130,.028),True,'clear_cable');parts+=stored
    for x in [-.026,.026]:
        parts.append(L.RO.box('separate-internal-steel-mounting-ear-'+str(x),'steel',.014,.050,.002,(x,.130,.009)))
    return parts,dict(target_cm=None,official_axes=['body_diameter26cm','body_depth10p7cm','cord160cm'],estimated=['dish_curvature_and_dome_profile','shell_thickness','hidden_mount_and_empty_socket','stored_cord_pose','hidden_cavity_capacity_unverified'],features=['Own26cmcurved circular backplate with a continuous polished chrome central dome','Real finite shells; source dark reflections are not invented cut-outs','Separate emptyE14holder, own160cmPVCcord and switch; optional stored-cord scene'],measured_cord_length_m=le,stored_cord_turn_pitch_m=pitch,official_fixture_diameter_cm=26,official_fixture_depth_cm=10.7,stored_cable_inside_interpreted_cavity_only=True,hidden_real_capacity_verified=False,material_overrides={'body':('paint',[226,221,198],.23,0),'chrome':('metal',[232,233,230],.085,1),'clear_cable':('plastic',[219,219,211],.35,0),'switch':('plastic',[226,226,218],.24,0)},scale_note_override='Kendi resmî kaynağındaki26cm armatür çapı ve10,7cm gövde derinliği korunur. Kablo160cm; E14/azami6W LED ve ampulsüzdür. İç montaj, metal kalınlıkları, kubbe profili ve kablonun gövde zarfında sarılı pozu tahmindir. Sargı yalnız modellenen boşluğa sığar; gerçek gizli kapasite doğrulanmamıştır. Koyu fotoğraf yansımaları delik olarak modellenmemiştir. İlk görünüm armatürü; ikinci görünüm ayrı kabloyu da gösterir. Üretici CAD dosyası değildir.')

BUILD={**{sku:arch_wall for sku in ['0924200001','0943083001']},'1017740027':conical_table,**{sku:large_mushroom for sku in ['1024398021','1024398022']},**{sku:round_wall for sku in ['1337564001','1337565001']}}

def wrap(q):
    parts,info=BUILD[q['sku']](q)
    f=FACTS[q['sku']]
    info.update(official_socket_type=f['socket'],official_socket_count=1,official_source_max_led_w=f['watt'],bulbs_included=False,
        source_revision='root-own-metal-seven-r01',id_suffix='-source-r01',
        scene_variants=[dict(index=0,label='Armatür'),dict(index=1,label='Kablo ile')],default_scene_index=0)
    if q['sku']in ['1024398021','1024398022']:
        info.update(id_suffix='-source-neck-r03',source_revision='root-own-mushroom-photo-proportions-r03',own_photo_shade_bottom_height_cm_estimate=26.9,own_photo_foot_diameter_cm_estimate=11.0)
    if q['sku']in ['0924200001','0943083001']:
        info.update(id_suffix='-source-own-wood-r03',source_revision='root-own-native-wood-r03',own_native_wood_crop=True)
        info['scale_note_override']+=' Ahşap damar ayrıntısı kendi ürün fotoğrafının doğal64×256piksel kesiminden alınmıştır; gölge değişimleri giderilmiştir. Damarın tüm yüzeydeki yerleşimi ve tekrar ölçeği tahmindir.'
    return parts,info

L.BUILD={sku:wrap for sku in SOURCES}
BASE_BANK=L.material_bank
def own_bank(pid,keys,ims,out,overrides=None):
    mats,maps=BASE_BANK(pid,keys,ims,out,overrides)
    if 'wood' not in keys:return mats,maps
    source=next(x for x in ims if '?imwidth=1536' in x['url'])
    master=Image.open(source['path']).convert('RGB');box=(218,1040,282,1296);crop=master.crop(box)
    raw=np.array(crop,dtype=float);blur=np.array(crop.filter(ImageFilter.GaussianBlur(16)),dtype=float)
    ratio=raw/np.maximum(blur,1);albedo=np.clip(ratio*np.array([171,80,39]),0,255)
    height=(raw.mean(2)/np.maximum(blur.mean(2),1)-1)*.000025
    def mirror(a):return np.concatenate([np.concatenate([a,a[:,::-1]],1),np.concatenate([a[::-1],a[::-1,::-1]],1)],0)
    albedo=mirror(albedo);height=mirror(height)
    dy=(np.roll(height,-1,0)-np.roll(height,1,0))/(2*.16/512)
    dx=(np.roll(height,-1,1)-np.roll(height,1,1))/(2*.04/128)
    normal=np.stack([-dx,-dy,np.ones_like(dx)],2);normal/=np.linalg.norm(normal,axis=2,keepdims=True)
    orm=np.zeros((512,128,3),np.uint8);orm[:,:,0]=255;orm[:,:,1]=112
    for slot,pixels in [('albedo',albedo.astype('uint8')),('normal',np.rint((normal+1)*127.5).astype('uint8')),('orm',orm)]:
        dest=out/('wood-'+slot+'.png');Image.fromarray(pixels).save(dest,optimize=True)
        for rec in maps:
            if rec['material']=='wood' and rec['slot']==slot:rec.update(sha256=L.sha(dest),native_resolution=[128,512])
    crop.save(out/'source-wood-native-crop.png')
    mats['wood']['extras'].update(photo_pixels_baked=True,native_resolution=[128,512],own_native_wood_detail=True,whole_board_pattern_exact=False)
    L.dump(out/'native-wood-crop-provenance.json',dict(source=source['path'],source_sha256=source['sha256'],source_native_crop_box=box,crop_pixels=[64,256],mirrored_tile_pixels=[128,512],geometric_resampling_count=0,source_pixels_equal_crop=True,low_frequency_illumination_removed=True,wood_pigment_and_repeat_photo_estimated=True,physical_repeat_m=[.04,.16],no_background_or_hardware_pixels=True))
    assert L.sha(source['path'])==source['sha256']
    return mats,maps
L.material_bank=own_bank
NAMES={'0924200001':'Kavisli kollu cam başlıklı ahşap kaideli aplik',
       '0943083001':'Kavisli kollu cam başlıklı ahşap kaideli aplik',
       '1017740027':'Konik kaideli geniş başlıklı metal masa lambası · Vizon',
       '1024398021':'Yuvarlak başlıklı metal masa lambası · Zeytin yeşili',
       '1024398022':'Yuvarlak başlıklı metal masa lambası · Sarı',
       '1337564001':'Krom kubbeli dairesel metal duvar lambası',
       '1337565001':'Krom kubbeli dairesel metal duvar lambası'}
for sku,q in SOURCES.items():q['name_tr']=NAMES[sku]
if __name__=='__main__':
    for sku in sys.argv[1:]or SOURCES:
        L.build(sku)
        rows=json.loads((R/'manifest.json').read_text());e=next(x for x in rows if x['sku']==sku)
        doc,binary=L.read_glb(e['glb_path'])
        allnodes=doc['scenes'][0]['nodes'];body=[i for i in allnodes if not doc['nodes'][i].get('name','').startswith('stored-cord-')]
        assert body and len(body)<len(allnodes)
        second=[]
        for i in allnodes:
            second.append(len(doc['nodes']))
            doc['nodes'].append(json.loads(json.dumps(doc['nodes'][i])))
        doc['scenes']=[dict(name='Armatür',nodes=body),dict(name='Kablo ile',nodes=second)];doc['scene']=0
        if sku in ['1337564001','1337565001']:
            for material in doc['materials']:
                if material['name'] in ['clear_cable','switch']:
                    material.setdefault('extensions',{}).update(KHR_materials_transmission=dict(transmissionFactor=.70),KHR_materials_ior=dict(ior=1.49))
            doc['extensionsUsed']=sorted(set(doc.get('extensionsUsed',[]))|{'KHR_materials_transmission','KHR_materials_ior'})
        L.write_glb(e['glb_path'],doc,binary)
        e.update(sha256=L.sha(e['glb_path']),bytes=Path(e['glb_path']).stat().st_size)
        L.dump(Path(e['asset_dir'])/'entry.json',e);L.dump(R/'manifest.json',rows)
        print('SCENES',sku,len(body),len(allnodes),flush=True)
