"""Independent scene nodes avoid reparenting shared objects in Three.js.

Frozen r01 is retained as a rejected technical candidate. All mesh/accessor,
material and texture bytes are preserved; only node/scene wiring is repaired.
"""
from pathlib import Path
import json,hashlib,subprocess,sys
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parent/'lighting-models'))
import build_lighting as L
old=ROOT/'frozen-source-seven-r01'
new=ROOT/'frozen-source-seven-r02'
new.mkdir(exist_ok=False)
rows=json.loads((old/'manifest.json').read_text());out=[];proof=[]
for e in rows:
    folder=new/e['sku']
    subprocess.run(['/usr/bin/ditto','--clone',e['asset_dir'],str(folder)],check=True)
    original,binary=L.read_glb(e['glb_path'])
    doc=json.loads(json.dumps(original))
    allnodes=original['scenes'][1]['nodes']
    second=[]
    for i in allnodes:
        second.append(len(doc['nodes']))
        doc['nodes'].append(json.loads(json.dumps(original['nodes'][i])))
    doc['scenes'][1]['nodes']=second
    assert set(doc['scenes'][0]['nodes']).isdisjoint(second)
    assert doc['meshes']==original['meshes'] and doc['materials']==original['materials'] and doc['accessors']==original['accessors']
    identifier=e['id']+'-scenes-r02'
    glb=folder/(identifier+'.glb');L.write_glb(glb,doc,binary)
    rec=dict(e,id=identifier,asset_dir=str(folder),glb_path=str(glb),model_path=str(folder/'model.json'),geometry_validation=str(folder/'geometry-validation.json'),material_validation=str(folder/'material-validation.json'),sha256=L.sha(glb),bytes=glb.stat().st_size,model_revision='root-metal-seven-independent-scene-nodes-r02')
    L.dump(folder/'entry.json',rec);out.append(rec)
    proof.append(dict(sku=e['sku'],old_sha256=e['sha256'],new_sha256=rec['sha256'],binary_payload_SHA_unchanged=hashlib.sha256(binary).hexdigest(),meshes_accessors_materials_unchanged=True,independent_node_indices_per_scene=True,source_JPEG_and_native_QA_reused_unchanged=True))
L.dump(new/'manifest.json',out)
L.dump(new/'scene-repair-preservation.json',dict(previous_frozen_r01_preserved=True,root_actual_accepted=0,ready_claimed=0,models=proof))
print('SCENE_REPAIR',new/'manifest.json',L.sha(new/'manifest.json'))
