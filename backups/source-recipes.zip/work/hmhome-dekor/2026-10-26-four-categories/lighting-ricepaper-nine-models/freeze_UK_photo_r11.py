from pathlib import Path
import sys,json,hashlib,subprocess,datetime
sys.dont_write_bytecode=True
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R.parent/'lighting-paper-models'));from audit_glb import run
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
e=json.loads((R/'native-UK-photo-proportion-r11.json').read_text())[0];src=Path(e['asset_dir']);F=R/'frozen-own-UK-photo-proportion-conflict-r11';F.mkdir(exist_ok=False);dest=F/e['sku'];subprocess.run(['/usr/bin/ditto','--clone',str(src),str(dest)],check=True);copies=[]
for p in src.rglob('*'):
 if p.is_file():q=dest/p.relative_to(src);assert sha(p)==sha(q);copies.append(dict(source=str(p),frozen=str(q),sha256=sha(q)))
x=dict(e)
for k in['asset_dir','model_path','glb_path','geometry_validation','material_validation']:x[k]=str(dest)+e[k][len(str(src)):]
dump(F/'manifest.json',[x]);dump(F/'independent-glb-byte-audit.json',[run(x)]);subprocess.run(['/usr/bin/ditto','--clone',str(R/'UK-own-photo-analysis-r11'),str(F/'own-UK-source-analysis')],check=True);native=[]
for n in['on.png','on-capraz.png','ustten.png','yan.png','arka.png']:p=dest/n;assert p.exists();native.append(dict(path=str(p),sha256=sha(p)))
proof=dict(scope='UK1337581001_own_source_photo_proportion_alternative',products=1,root_actual_approved=False,ready_variants=0,canonical_writes=0,own_UK_published_top22_bottom55_topWidth41p5_bottomWidth26p2_unchanged=True,published_component_depths_absent_and_photo_estimated=True,total81_only_official_geometry_anchor=True,all_other_component_dimensions_photoestimated_with_explicit_conflict=True,DE_unpublished_sizes_not_transferred_as_UK_facts=True,own_3_JPEGs_SHA_verified=True,own_UK_PNGmaps_unchanged=True,geometry_arrays_use_root_accepted_photo_method=True,own_frontal_JPEG_bytes_not_equal_to_DE_but_native_landmarks_match=True,historical_r06_and_accepted_DE_frozen_unchanged=True,cloned_files=copies,native_five_angles=native,manifest_sha256=sha(F/'manifest.json'),checked_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());dump(F/'own-source-preservation-native-proof.json',proof);print('MANIFEST',F/'manifest.json');print('SHA',sha(F/'manifest.json'));print('PROOF',sha(F/'own-source-preservation-native-proof.json'));print('GLB',x['sha256'])
