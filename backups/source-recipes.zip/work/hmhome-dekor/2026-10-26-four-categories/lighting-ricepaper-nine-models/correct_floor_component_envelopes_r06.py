"""Correct measured lower paper envelope to its own published26.2cm anchor.
Natural spline overshoot is removed by a smooth local scale; upper41.5cm,
heights, frame, textures, UV and previous candidates remain unchanged.
"""
from pathlib import Path
import sys,json,subprocess,hashlib
sys.dont_write_bytecode=True
import numpy as np
import build_ricepaper as M
R=Path(__file__).resolve().parent;L=M.L
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def fix(sku):
 src=R/'candidate-r04'/sku;out=R/'candidate-r06'/sku;assert not out.exists();subprocess.run(['/usr/bin/ditto','--clone',str(src),str(out)],check=True);e=json.loads((src/'entry.json').read_text());old=json.loads((src/'model.json').read_text());model=json.loads((src/'model.json').read_text());p0=np.array(old['meshes'][0]['positions']).reshape(-1,3);bottom=p0[p0[:,1]<.59];old_xz=np.ptp(bottom[:,[0,2]],axis=0);factor=.262/old_xz;checks=[]
 for a,m in zip(old['meshes'],model['meshes']):
  if not m['material'].startswith('paper'):continue
  p=np.array(m['positions']).reshape(-1,3);y=p[:,1];t=np.clip((y-.57)/.04,0,1);t=t**3*(10-15*t+6*t*t);sx=factor[0]+(1-factor[0])*t;sz=factor[1]+(1-factor[1])*t;p[:,0]*=sx;p[:,2]*=sz;p=np.round(p,9);faces=np.array(m['indices']).reshape(-1,3);tri=p[faces];fn=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]);n=np.zeros_like(p)
  for j in range(3):np.add.at(n,faces[:,j],fn)
  n/=np.maximum(np.linalg.norm(n,axis=1,keepdims=True),1e-20);oldn=np.array(m['normals']).reshape(-1,3);mask=y<.61;oldn[mask]=n[mask];m['positions']=p.reshape(-1).tolist();m['normals']=oldn.reshape(-1).tolist();assert np.array_equal(np.array(a['positions']).reshape(-1,3)[~mask],p[~mask]);assert a['uvs']==m['uvs']and a['indices']==m['indices'];checks.append(dict(name=m['name'],upper_y_ge_061_geometry_identical=True,UV_and_indices_identical=True))
 pp=np.array(model['meshes'][0]['positions']).reshape(-1,3);new_xz=np.ptp(pp[pp[:,1]<.59][:,[0,2]],axis=0);assert np.allclose(new_xz,.262,atol=1e-8);meta=model['metadata'];ident='hm-'+sku+'-source-ricepaper-component-corrected-r06';meta.update(id=ident,model_revision='source-component-envelope-corrected-r06',model_status='pending_root_visual_review',quality_pending=True,ready_model_variants=0,verified_model_component_envelopes_cm=dict(bottom_width=float(new_xz[0]*100),bottom_depth=float(new_xz[1]*100),top_width=41.5,top_depth=41.5));meta['scale_note']+=' Modelin alt kâğıt gövdesindeki spline taşması ayrıca ölçülüp düzeltilmiştir: alt en26,2cm, üst en41,5cm gerçek geometri zarfında korunur; yüksekliği, üst bölüm, donanım ve malzeme değişmez.'
 if sku=='1337581001':meta['scale_note']+=' Alt derinlik26,2cm resmî UK etiketinde bulunmaz; kendi fotoğraftaki kare kesit nedeniyle tahmindir.'
 M.dump(out/'model.json',model);report=L.export_assets(out/'model.json',out,ident);glb=out/(ident+'.glb');doc,binary=L.read_glb(glb);binary=M.G.M.embed_tangents(doc,binary);olddoc,_=L.read_glb(src/Path(e['glb_path']).name)
 for n,o in zip(doc['materials'],olddoc['materials']):
  if'extensions'in o:n['extensions']=o['extensions']
 doc['extensionsUsed']=olddoc.get('extensionsUsed',[]);L.write_glb(glb,doc,binary);e.update(meta,asset_dir=str(out),model_path=str(out/'model.json'),glb_path=str(glb),sha256=sha(glb),bytes=glb.stat().st_size,geometry_validation=str(out/'geometry-validation.json'),material_validation=str(out/'material-validation.json'));report['deliverable_sha256']['glb']=e['sha256'];report['glb_bytes']=e['bytes'];M.dump(report['files']['validation'],report);M.dump(out/'entry.json',e);proof=dict(old_r04_source_GLBSHA=sha(src/Path(json.loads((src/'entry.json').read_text())['glb_path']).name),old_bottom_width_depth_m=old_xz.tolist(),new_bottom_width_depth_m=new_xz.tolist(),constant_lower_xz_scale=factor.tolist(),C2_quintic_transition_y_m=[.57,.61],height_and_all_nonpaper_meshes_identical=all(a==b for a,b in zip(old['meshes'],model['meshes'])if not a['material'].startswith('paper')),all_PNGs_identical=all(sha(p)==sha(src/p.name)for p in out.glob('*.png')if p.name not in['on.png','on-capraz.png','ustten.png','yan.png','arka.png']),mesh_checks=checks,root_actual_approved=False);M.dump(out/'source-component-envelope-preservation-proof.json',proof);rows=json.loads((R/'manifest.json').read_text());M.dump(R/'manifest.json',[x for x in rows if x['sku']!=sku]+[e]);print('COMPONENT_CORRECTED',sku,e['sha256'],flush=True);return e
if __name__=='__main__':M.dump(R/'native-corrected-floor-components-r06.json',[fix(s)for s in['1337580001','1337581001']])
