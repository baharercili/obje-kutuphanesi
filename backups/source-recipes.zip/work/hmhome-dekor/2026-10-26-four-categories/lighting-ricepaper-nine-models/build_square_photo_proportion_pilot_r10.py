"""First DE square-floor photo-proportion alternative: published sizes conflict
with its own uncalibrated frontal image. Only total81cm remains an official
geometry anchor. Never modifies full-official r06 frozen interpretation.
"""
from pathlib import Path
import sys,json,copy,hashlib,subprocess
sys.dont_write_bytecode=True
import numpy as np
from PIL import Image,ImageDraw
import build_ricepaper as M
import build_remaining_seven as F
R=Path(__file__).resolve().parent;L=M.L;B,G=M.B,M.G;SKU='1337580001'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def build():
 source=R/'frozen-corrected-two-floor-components-r06'/SKU;out=R/'candidate-photo-proportion-r10'/SKU;out.mkdir(parents=True,exist_ok=False);old=json.loads((source/'entry.json').read_text());oldmodel=json.loads((source/'model.json').read_text());s=copy.deepcopy(M.S[SKU]);s.update(w=.36,d=.36,profile=[(.072,.04),(.10,.055),(.119,.085),(.125,.12),(.125,.47),(.122,.52),(.115,.54),(.108,.555),(.106,.562),(.109,.567),(.13,.578),(.158,.595),(.176,.615),(.18,.635),(.18,.72),(.178,.745),(.17,.765),(.15,.784),(.12,.795),(.10,.799)])
 parts,info=F.floor_geometry(s)
 # Remove natural-cubic local overshoot from the approximate25cm lower envelope.
 # This remains a photo estimate, never a new official dimension.
 pp=np.array(parts[0]['_vertices']);lower=pp[pp[:,1]<.562];factor=.25/np.ptp(lower[:,[0,2]],axis=0)
 for g in parts:
  if not g['material'].startswith('paper'):continue
  v=np.array(g['_vertices']);t=np.clip((v[:,1]-.54)/.03,0,1);t=t**3*(10-15*t+6*t*t);v[:,0]*=factor[0]+(1-factor[0])*t;v[:,2]*=factor[1]+(1-factor[1])*t;g['_vertices']=[tuple(x)for x in v]
 info['photo_lower_C2_overshoot_correction']=dict(factors=factor.tolist(),lower_target_estimate_m=.25,transition_y_m=[.54,.57])
 pos=np.concatenate([g['_vertices']for g in parts]);lo,hi=pos.min(0),pos.max(0);shift=np.array([(lo[0]+hi[0])/2,lo[1],(lo[2]+hi[2])/2]);meshes=[];checks=[]
 for g in parts:
  g['_vertices']=[tuple(np.array(v)-shift)for v in g['_vertices']];a,c=L._finalize(G.H.orient(g));meshes.append(a);checks.append(c)
 repairs=G.M.ensure_uv_faces(meshes)+G.H.ensure_float32_uv(meshes)
 for p in source.glob('*.png'):
  if p.name not in['on.png','on-capraz.png','ustten.png','yan.png','arka.png']:
   subprocess.run(['/usr/bin/ditto','--clone',str(p),str(out/p.name)],check=True);assert sha(p)==sha(out/p.name)
 for n in['native-crop-provenance.json','material-validation.json']:
  subprocess.run(['/usr/bin/ditto','--clone',str(source/n),str(out/n)],check=True)
 pp=np.array(meshes[0]['positions']).reshape(-1,3);upper=pp[pp[:,1]>=.562];lower=pp[pp[:,1]<=.562];dim=((hi-lo)*100).tolist();meta=copy.deepcopy(oldmodel['metadata']);ident='hm-'+SKU+'-own-photo-proportion-conflict-pilot-r10';q=M.Q[SKU]
 note='Bu ayrı fotoğraf-oran adayıdır; yalnız kendi DE kaynağının toplam81cm yüksekliği resmî geometri ankrajıdır. Aynı SKU’nun yayımlanmış üst41,5×41,5cm ve alt26,2×26,2cm etiketleri aynen saklanır, fakat kendi ön JPEG’inin görünen üst en/yükseklik ve üst/alt en oranlarıyla uyuşmaz. Ölçüsü kalibre edilmemiş fotoğraftan yaklaşıküst36×36cm/en-derinlik ve24cm görünenyükseklik,alt25×25cm ve53cm yükseklik,yaklaşık4cmayak payı yorumlandı; geçişte yaklaşık1cm örtüşme vardır. Bu tahminler resmî ürün ölçüsü değildir ve genel üretimCAD’i/kalibre tarama sayılmaz. Daha dar alt/üst ölçülere sahip bu fotoğraf yorumu,41,5/26,2cm resmi-zarf yorumunun yerine sessizce geçirilmedi: önceki r06 ayrı tarihsel dosya olarak korunur. DE kaynağında yayımlanmayan üst/alt yükseklikleri başka UKSKU’dan resmî diye aktarılmadı. Kendi fotoğrafındaki üst daha dik yanlar ve küçük oturma geçişi kullanıldı; önceki güçlü boğaz biçimi azaltıldı. MalzemePNG,ownJPEG,duylar/ayaklar/kablo/gerçek üst açıklık ve tüm elektrik/not kaynağı korunur; fotodaki stüdyo ışığı/gölge PBR’ye boyanmadı.'
 meta.update(id=ident,name='Geniş üstlü kare kâğıt lambader · Fotoğraf oranı yorumu · 81 cm',model_revision='own-photo-proportion-conflict-pilot-r10',dimensions_cm=dim,source_dimensions_hwd_cm=[81,36,36],estimated_dimensions=True,estimated_fields=['all_component_widths_and_depths_photo_estimates','component_heights_and_overlap_photo_estimates','uncalibrated_frontal_reference_interpretation','paper_thickness','hidden_supports_and_electrical_positions','cord_length_and_stored_pose'],scale_note=note,size_source_kind='official_total_height81_only_with_own_photo_component_conflict',size_source_urls=[q['url']],quality_label='Fotoğraf oranı yorumu · Ölçü uyuşmazlığı',model_status='pending_root_visual_review',quality_pending=True,ready_model_variants=0,official_measurements=F.exact_component_axes(SKU,q),component_anchor=dict(official_total_height_cm=81,photographic_upper_width_depth_estimate_cm=[36,36],photographic_upper_visible_height_estimate_cm=24,photographic_lower_width_depth_estimate_cm=[25,25],photographic_lower_height_estimate_cm=53,photographic_feet_height_estimate_cm=4,photographic_overlap_estimate_cm=1),measurement_discrepancy=dict(published_upper_width_depth_cm=[41.5,41.5],published_lower_width_depth_cm=[26.2,26.2],photo_interpreted_upper_width_depth_cm=[36,36],photo_interpreted_lower_width_depth_cm=[25,25],all_photo_component_dimensions_estimated=True,published_Height81_retained=True,source_cause_unverified=True,no_other_SKU_measurement_transfer=True,historical_official_envelope_candidate=str(source/'entry.json')))
 # Source own frontal anchors; spans are approximate pixel selections, not a
 # calibrated camera solve. Repeated underlying JPEG is still own exact source.
 master=next(x for x in M.MASTERS if x['sku']==SKU and 'dc08e20ec3e9'in x['path']);im=Image.open(master['path']).convert('RGB');d=ImageDraw.Draw(im)
 for box,label in [([400,248,1106,720],'upper own photo ~704x472px'),([509,720,994,1748],'lower own photo ~485x1028px'),([350,248,1150,1830],'height81 anchor incl feet; no camera calibration')]:d.rectangle(box,outline='red',width=3);d.text((box[0],box[1]+4),label,fill='red')
 analysis=R/'square-own-gallery-analysis-r10';analysis.mkdir(exist_ok=True);im.save(analysis/'DE-own-frontal-native-anchors.png');photo=dict(sku=SKU,source_master=master['path'],source_master_sha256=master['sha256'],native_dimensions=list(im.size),uncalibrated=True,upper_approx_pixel_bounds=[400,248,1106,720],lower_approx_pixel_bounds=[509,720,994,1748],foot_tip_y_approx=1830,observed_upper_width_height_ratio=704/472,observed_upper_lower_width_ratio=704/485,official_upper_lower_width_ratio=41.5/26.2,official_total_height_cm=81,all_other_dimensions_photo_interpretations=True,profile_spec=s['profile'],actual_upper_bounds_cm=dict(width=float(np.ptp(upper[:,0])*100),depth=float(np.ptp(upper[:,2])*100),height=float(np.ptp(upper[:,1])*100)),actual_lower_bounds_cm=dict(width=float(np.ptp(lower[:,0])*100),depth=float(np.ptp(lower[:,2])*100),height=float(np.ptp(lower[:,1])*100)))
 dump(analysis/'DE-source-photo-component-conflict.json',photo);meta['source_evidence_files']=[x for x in meta['source_evidence_files']if 'source-component-mapping-'not in x]+[str(analysis/'DE-source-photo-component-conflict.json')];meta['source_size_pointer']=str(analysis/'DE-source-photo-component-conflict.json');dump(out/'model.json',dict(metadata=meta,materials=oldmodel['materials'],meshes=meshes));dump(out/'geometry-validation.json',dict(valid=True,meshes=checks,uv_repairs=repairs,source_geometry_info=info,photo_proportion_alternative_not_official_component_sizes=photo))
 report=L.export_assets(out/'model.json',out,ident);glb=out/(ident+'.glb');doc,binary=L.read_glb(glb);binary=G.M.embed_tangents(doc,binary);oldglb,_=L.read_glb(old['glb_path'])
 for a,b in zip(doc['materials'],oldglb['materials']):
  if 'extensions'in b:a['extensions']=b['extensions']
 doc['extensionsUsed']=oldglb.get('extensionsUsed',[]);L.write_glb(glb,doc,binary);e=dict(old,**meta,asset_dir=str(out),model_path=str(out/'model.json'),glb_path=str(glb),sha256=sha(glb),bytes=glb.stat().st_size,geometry_validation=str(out/'geometry-validation.json'),material_validation=str(out/'material-validation.json'));dump(out/'entry.json',e);report['source_sha256']=sha(out/'model.json');report['deliverable_sha256']['glb']=e['sha256'];report['glb_bytes']=e['bytes'];dump(Path(report['files']['validation']),report)
 proof=dict(official_r06_glb_sha_unchanged=sha(old['glb_path'])==old['sha256'],original_JPEGs_same_SHA=True,all_texture_PNGs_identical=all(sha(p)==sha(source/p.name)for p in out.glob('*.png')),old_official_dimension_facts_unchanged=meta['official_dimension_facts']==old['official_dimension_facts'],no_canonical_writes=True,root_actual_approved=False,nonpaper_meshes_identical=all(a==b for a,b in zip(oldmodel['meshes'],meshes)if not a['material'].startswith('paper')));dump(out/'photo-proportion-preservation-proof.json',proof);dump(R/'native-photo-proportion-pilot-r10.json',[e]);print('PILOT',e['sha256'],e['bytes'],photo['actual_upper_bounds_cm'],photo['actual_lower_bounds_cm'])
if __name__=='__main__':build()
