"""Material-only own Tyvek-like crease revision. Frozen009 geometry and source bytes preserved."""
from pathlib import Path
import sys,json,copy,subprocess,math
import numpy as np
from PIL import Image,ImageFilter
P=Path(__file__).resolve().parent.parent;sys.path.insert(0,str(P/'lighting-models'));import build_lighting as L
R=Path('/private/tmp/hm-lighting-20261028/umbrella-crease-r02');R.mkdir(parents=True,exist_ok=True)
if list(R.glob('frozen*manifest*.json')):raise RuntimeError('Frozen material revision preserved.')
OLD=P/'lighting-portable-batch-009/frozen-glass-stone-umbrella-nine-manifest.json';IDS=['1344518001','1344521001'];SOURCE=Path('/private/tmp/hm-lighting-20261028/rechargeable-source-review');SPEC={'1344518001':'a9ed3f965172','1344521001':'d8095a0ac630'}

def append_png(doc,binary,path):
 binary+=b'\0'*((-len(binary))%4);data=Path(path).read_bytes();view=len(doc['bufferViews']);doc['bufferViews'].append(dict(buffer=0,byteOffset=len(binary),byteLength=len(data)));binary+=data;image=len(doc['images']);doc['images'].append(dict(bufferView=view,mimeType='image/png',name=Path(path).name));tex=len(doc['textures']);doc['textures'].append(dict(sampler=0,source=image));return binary,tex

def crease_maps(source,out):
 box=[350,700,862,1212];master=Image.open(source['path']).convert('RGB');patch=master.crop(box);n=patch.width;raw=np.array(patch,float);grey=raw.mean(2)
 def blurred(s):
  radius=int(math.ceil(3*s));x=np.arange(-radius,radius+1);kernel=np.exp(-.5*(x/s)**2);kernel/=kernel.sum()
  result=grey.copy()
  for axis in[0,1]:result=np.apply_along_axis(lambda row:np.convolve(np.pad(row,(radius,radius),mode='reflect'),kernel,'valid'),axis,result)
  return result
 medium=(blurred(8)-blurred(64))/np.maximum(blurred(64),1);medium-=medium.mean();p90=float(np.percentile(np.abs(medium),90));mediumheight=np.clip(medium/max(p90,1e-6)*.00065,-.0013,.0013)
 fine=(grey-blurred(1.2))/np.maximum(blurred(1.2),1);fineheight=np.clip(fine,-.20,.20)*.00006;h=mediumheight+fineheight
 def mirror(a):return np.concatenate([np.concatenate([a,a[:,::-1]],1),np.concatenate([a[::-1],a[::-1,::-1]],1)],0)
 h=mirror(h);period=.17;step=period/(2*n);dy=(np.roll(h,-1,0)-np.roll(h,1,0))/(2*step);dx=(np.roll(h,-1,1)-np.roll(h,1,1))/(2*step);normal=np.stack([-dx,-dy,np.ones_like(dx)],2);normal/=np.linalg.norm(normal,axis=2,keepdims=True)
 albedo=np.zeros((2*n,2*n,3),np.uint8);albedo[:]=[235,233,224];orm=np.zeros_like(albedo);orm[:,:,0]=255;orm[:,:,1]=np.rint(mirror(np.clip(.88-fine*.10,.84,.93))*255)
 for slot,a in[('albedo',albedo),('normal',np.rint((normal+1)*127.5).astype('uint8')),('orm',orm)]:Image.fromarray(a).save(out/('nonwoven_shade_crease-'+slot+'.png'),optimize=True)
 # Both base and shade retain neutral intrinsic white albedo; only the shade gains medium relief.
 Image.fromarray(albedo).save(out/'nonwoven-albedo.png',optimize=True);patch.save(out/'own-source-native-crease-crop.png');height=np.rint((np.clip(h,-.0016,.0016)/.0032+.5)*65535).astype('uint16');Image.fromarray(height).save(out/'interpreted-crease-height-16bit.png')
 detail=dict(own_SKU=source['sku'],master=source['path'],master_sha256=source['sha256'],native_crop_box=box,native_crop_pixels=[n,n],geometric_resampling_count=0,mirrored_native_pixel_tiling=True,physical_repeat_m_estimated=.17,crease_height_is_photo_interpretation_not_measurement=True,medium_crease_extraction='native float Gaussian8 minus64 luminance band; medium creases separated from fine fibrils without intermediate8bit quantization',medium_raw_p90=p90,interpreted_relief_p90_m=.00065,interpreted_height_min_m=float(h.min()),interpreted_height_max_m=float(h.max()),normal_scale=1.0,white_albedo_has_no_photographic_shadows=True,base_microfibril_normal_preserved=True,no_generated_image_pixels=True,source_light_does_not_define_measured_crease_sign=True)
 L.dump(out/'own-crease-material-provenance.json',detail);return detail

def main():
 rows=[];proof=[];registry=[x for x in json.loads(Path('/private/tmp/hm-lighting-20261028/portable-009/original-image-masters.json').read_text())if x['sku']in IDS]
 for x in registry:assert L.sha(x['path'])==x['sha256']
 L.dump(R/'original-image-masters.json',registry)
 for old in json.loads(OLD.read_text()):
  if old['sku']not in IDS:continue
  src=Path(old['model_path']);model=json.loads(src.read_text());before=copy.deepcopy(model);doc,binary=L.read_glb(old['glb_path']);oldbinary=bytes(binary);oldsha=L.sha(old['glb_path']);oldjsonsha=L.sha(src);ident=old['id']+'-own-crease-r02';out=R/'models'/ident;out.mkdir(parents=True,exist_ok=True)
  for pp in src.parent.glob('*.png'):subprocess.run(['/bin/cp','-c',str(pp),str(out/pp.name)],check=True);assert L.sha(pp)==L.sha(out/pp.name)
  source=next(x for x in registry if x['sku']==old['sku']and SPEC[old['sku']]in x['path']);detail=crease_maps(source,out)
  ma=copy.deepcopy(model['materials']['nonwoven']);ma.update(baseColorTexture='nonwoven_shade_crease-albedo.png',normalTexture='nonwoven_shade_crease-normal.png',metallicRoughnessTexture='nonwoven_shade_crease-orm.png',normalScale=1.0);ma['extras'].update(interpreted_medium_crease_relief=True,photo_shadow_in_albedo=False,physical_repeat_m_estimated=.17,native_resolution=[1024,1024],photo_pixels_baked=True,crease_height_provenance=str(out/'own-crease-material-provenance.json'));model['materials']['nonwoven_shade_crease']=ma
  oldmatindex=next(i for i,m in enumerate(doc['materials'])if m['name']=='nonwoven');newmat=copy.deepcopy(doc['materials'][oldmatindex]);newmat['name']='nonwoven_shade_crease';newmatindex=len(doc['materials'])
  # Neutral base white replaces its albedo image, retaining the original micro-normal/roughness.
  basetex=doc['materials'][oldmatindex]['pbrMetallicRoughness']['baseColorTexture']['index'];baseimage=doc['textures'][basetex]['source'];binary,newtex=append_png(doc,binary,out/'nonwoven-albedo.png');doc['images'][baseimage]=copy.deepcopy(doc['images'][doc['textures'][newtex]['source']])
  for slot,file in[('albedo','nonwoven_shade_crease-albedo.png'),('normal','nonwoven_shade_crease-normal.png'),('orm','nonwoven_shade_crease-orm.png')]:
   binary,ti=append_png(doc,binary,out/file)
   if slot=='albedo':newmat['pbrMetallicRoughness']['baseColorTexture']['index']=ti
   elif slot=='normal':newmat['normalTexture']=dict(index=ti,scale=1.0)
   else:newmat['pbrMetallicRoughness']['metallicRoughnessTexture']['index']=ti
  doc['materials'].append(newmat);changed=[]
  for i,m in enumerate(model['meshes']):
   if m['name']=='separate-finite-eight-panel-nonwoven-umbrella-shade'or m['name'].startswith('separate-subtle-source-radial-panel-seam-'):
    assert m['material']=='nonwoven';m['material']='nonwoven_shade_crease';changed.append(i)
    for primitive in doc['meshes'][i]['primitives']:assert primitive['material']==oldmatindex;primitive['material']=newmatindex
  assert len(changed)==9
  for oldmesh,newmesh in zip(before['meshes'],model['meshes']):
   for key in['positions','normals','uvs','indices']:assert oldmesh[key]==newmesh[key]
  entry=copy.deepcopy(old);entry.update(id=ident,asset_dir=str(out),model_path=str(out/'model.json'),glb_path=str(out/(ident+'.glb')),model_revision='hm-own-umbrella-crease-material-r02-2026-10-28',model_status='pending_root_visual_review',quality_pending=True,crease_material_interpretation=detail,quality_label='Kırışık yüzey yüksekliği tahminidir',quality_note='Kendi kaynak fotoğrafındaki geniş kırışıklar yaklaşık kabartı olarak normal haritasına yorumlandı; beyaz renge fotoğraf gölgesi işlenmedi.')
  entry['estimated_fields']+=['own_medium_diagonal_crease_height_and_sign','normal_only_relief_not_measured_geometry'];entry['scale_note']+=' Başlığın orta ölçekli çapraz kırışıkları yalnız bu exact SKU’nun kendi doğal fotoğraf kırpımından yaklaşık yükseklik/normal alanına yorumlanmıştır. Kırışık yüksekliği ve yön işareti fiziksel ölçüm değildir. Renk özünde nötr beyazdır; fotoğrafın kırışık gölgesi albedoya işlenmemiştir. Kaidenin ince lif normali, tüm gövde konum/normal/UV/indeks dizileri ve resmî bileşen eşlemeleri önceki frozen sürümle birebir korunmuştur.';entry['diameter_semantics']=entry['scale_note'];entry['geometry_limitations']=entry['estimated_fields'];meta=copy.deepcopy(entry)
  for k in['sha256','bytes','asset_dir','model_path','glb_path','geometry_validation','material_validation']:meta.pop(k,None)
  model['metadata']=meta;L.dump(out/'model.json',model);doc['extras']=meta;doc['scenes'][0]['name']=ident;doc['buffers'][0]['byteLength']=len(binary);L.write_glb(entry['glb_path'],doc,binary);entry.update(sha256=L.sha(entry['glb_path']),bytes=Path(entry['glb_path']).stat().st_size,geometry_validation=str(out/'geometry-validation.json'),material_validation=str(out/'material-validation.json'));L.dump(entry['geometry_validation'],dict(valid=True,all_body_positions_normals_UVs_indices_identical_to_frozen009=True,only_shade_material_assignments_changed=changed,official_component_mapping_unchanged=True));L.dump(entry['material_validation'],dict(valid=True,own_crease_provenance=detail,neutral_white_albedo=True,source_master_sha_unchanged=True,base_micro_normal_map_identical=L.sha(out/'nonwoven-normal.png')==L.sha(src.parent/'nonwoven-normal.png')));L.dump(out/'entry.json',entry);rows.append(entry);after,newbin=L.read_glb(entry['glb_path']);assert newbin[:len(oldbinary)]==oldbinary;assert L.sha(old['glb_path'])==oldsha and L.sha(src)==oldjsonsha;proof.append(dict(sku=entry['sku'],old_frozen_glb_sha256=oldsha,old_frozen_model_json_sha256=oldjsonsha,old_frozen_files_unchanged=True,original_geometry_binary_prefix_identical=True,all_mesh_positions_normals_UVs_indices_identical=True,old_texture_payloads_other_than_new_materials_not_modified=True,shade_material_mesh_indices=changed,own_source_master_sha256=source['sha256']))
 L.dump(R/'manifest.json',rows);L.dump(R/'body-and-source-preservation-proof.json',proof);print('UMBRELLA2 MATERIAL REVISION generated')
if __name__=='__main__':main()
