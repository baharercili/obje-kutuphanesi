"""Append reviewed four-category assets; source registration is a separate explicit step."""
from pathlib import Path
from urllib.parse import urlsplit
import copy,hashlib,importlib.util,json,re,shutil,sys,struct,io
import numpy as np
from PIL import Image
P=Path(__file__).resolve().parent;ROOT=P.parents[2];SITE=ROOT/'sites/zarahome-vazo-kutuphanesi-final-378'
def read(p):return json.loads(Path(p).read_text())
def write(p,d):Path(p).write_text(json.dumps(d,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
manifest_path=Path(sys.argv[1]).resolve();expected=sys.argv[2]
assert sha(manifest_path)==expected,'Reviewed frozen batch changed'
rows=read(manifest_path);entries=rows if isinstance(rows,list)else rows['models']
assert entries and len({e['id']for e in entries})==len(entries)
files=['model-manifest.json','ui/hmhome-catalog.json','ui/hmhome-preview.json','ui/hmhome-discovered.json']
baseline=P/'baseline-2182';baseline.mkdir(exist_ok=True)
for f in files:
 target=baseline/f.replace('/','__')
 if not target.exists():shutil.copy2(SITE/f,target)
manifest=read(SITE/'model-manifest.json');catalog=read(SITE/'ui/hmhome-catalog.json');preview=read(SITE/'ui/hmhome-preview.json');discovered=read(SITE/'ui/hmhome-discovered.json')
old={r['id']:copy.deepcopy(r)for r in manifest['models']};sources={r['sku']:r for r in discovered['products']}
original_inventory=read(SITE/'ui/hmhome-inventory.json')
original_sources={r['sku']:r for r in original_inventory['products']}
source_identities_before=set(sources)|set(original_sources)
source_overlay_skus=[]
for sku in {e['sku']for e in entries}:
 if sku not in sources:
  assert sku in original_sources,'Reviewed SKU is absent from both observed source inventories'
  overlay=copy.deepcopy(original_sources[sku])
  overlay['already_in_existing_166']=True
  overlay['source_categories']=[dict(id=overlay['category_id'],slug=overlay['category_slug'],label=overlay['category'])]
  discovered['products'].append(overlay);sources[sku]=overlay;source_overlay_skus.append(sku)
assert (set(sources)|set(original_sources))==source_identities_before,'Status overlays must not add source identities'
quality_path=ROOT/'work/zarahome-dekor/completeness-repair-2026-10-21/integrate_repair.py'
sys.path.insert(0,str(quality_path.parent));spec=importlib.util.spec_from_file_location('independent_quality',quality_path);quality=importlib.util.module_from_spec(spec);spec.loader.exec_module(quality)
def validate_native(entry):
 data=Path(entry['glb_path']).read_bytes();assert len(data)==entry['bytes']and hashlib.sha256(data).hexdigest()==entry['sha256']
 assert struct.unpack_from('<III',data)==(0x46546c67,2,len(data))
 json_len,json_kind=struct.unpack_from('<II',data,12);assert json_kind==0x4e4f534a
 doc=json.loads(data[20:20+json_len]);bin_len,bin_kind=struct.unpack_from('<II',data,20+json_len);assert bin_kind==0x004e4942
 binary=data[28+json_len:28+json_len+bin_len];assert len(binary)==bin_len
 assert doc['meshes']and doc['materials']and doc['images'];bounds=[]
 for mesh in doc['meshes']:
  for primitive in mesh['primitives']:
   accessor=doc['accessors'][primitive['attributes']['POSITION']];view=doc['bufferViews'][accessor['bufferView']]
   assert accessor['componentType']==5126 and accessor['type']=='VEC3'
   positions=np.ndarray((accessor['count'],3),dtype='<f4',buffer=binary,offset=view.get('byteOffset',0)+accessor.get('byteOffset',0),strides=(view.get('byteStride',12),4))
   assert np.isfinite(positions).all();bounds.append((positions.min(0),positions.max(0)))
 minimum=np.min([b[0]for b in bounds],axis=0);maximum=np.max([b[1]for b in bounds],axis=0)
 assert np.allclose((maximum-minimum)*100,entry['dimensions_cm'],atol=2e-4,rtol=1e-5)
 assert abs(float(minimum[1]))<1e-6 and abs(float(minimum[0]+maximum[0]))<1e-6 and abs(float(minimum[2]+maximum[2]))<1e-6
 image_sizes=[]
 for image in doc['images']:
  assert 'bufferView'in image and 'uri'not in image
  view=doc['bufferViews'][image['bufferView']];offset=view.get('byteOffset',0)
  with Image.open(io.BytesIO(binary[offset:offset+view['byteLength']]))as im:
   im.load();assert min(im.size)>0;image_sizes.append(list(im.size))
 assert read(entry.get('geometry_validation',str(Path(entry['asset_dir'])/'geometry-validation.json')))['valid']
 model=read(entry['model_path']);assert not model.get('metadata',{}).get('geometry_only_qa',False)and not model.get('metadata',{}).get('baked_reflections',False)
 if entry.get('original_image_sha256'):assert sha(entry['original_image'])==entry['original_image_sha256']
 return dict(id=entry['id'],sha256=entry['sha256'],bytes=len(data),dimensions_cm=entry['dimensions_cm'],embedded_image_sizes=image_sizes,texture_policy='Preserve native source crops and masks; constant PBR maps need no artificial resolution floor or upscaling',valid=True)
approvals=read(P/'browser-approvals.json')['models']
byte_proofs={r['id']:r for r in read(P/'candidate-download-proof.json')['checks']}
for e in entries:
 approval=approvals.get(e['id']);proof=byte_proofs.get(e['id'])
 assert approval and approval['approved'] and approval['sha256']==e['sha256'],'Actual browser approval missing or stale'
 assert proof and proof['valid'] and proof['sha256']==e['sha256'] and proof['bytes']==e['bytes'],'Download proof missing or stale'
display_names=read(P/'display-name-overrides.json')if(P/'display-name-overrides.json').exists()else{}
display_notes=read(P/'display-note-overrides.json')if(P/'display-note-overrides.json').exists()else{}
def display_material_label(value):
 terms=[(r'mango wood','Mango ağacı'),(r'stainless steel','Paslanmaz çelik'),(r'rubber wood|rubberwood','Kauçuk ağacı'),(r'particleboard','Sunta'),(r'plywood','Kontrplak'),(r'fibreboard|fiberboard|\bmdf\b','MDF'),(r'\bpine\b','Çam'),(r'\boak\b','Meşe'),(r'\bbeech\b','Kayın'),(r'\bacacia\b','Akasya'),(r'\brattan\b','Rattan'),(r'\bmarble\b|marmor','Mermer'),(r'\bstone ware\b|\bstoneware\b','Stoneware seramik'),(r'\bceramic\b','Seramik'),(r'\bporcelain\b','Porselen'),(r'\bglass\b|\bglas\b','Cam'),(r'\bpolyester\b','Polyester'),(r'\bcotton\b','Pamuk'),(r'\blinen\b','Keten'),(r'\bpaper\b|papier','Kâğıt'),(r'\bpolystyrene\b','Polistiren'),(r'\bpolypropylene\b','Polipropilen'),(r'\baluminium\b|\baluminum\b','Alüminyum'),(r'\bbrass\b','Pirinç'),(r'\biron\b|\beisen\b','Demir'),(r'\bsteel\b|\bstahl\b','Çelik'),(r'\bmetal\b|\bmetall\b','Metal'),(r'\bwood\b|\bholz\b','Ahşap'),(r'\bstone\b|\bstein\b','Taş')]
 terms.extend([(r'\bkiefer(?:nholz)?\b','Çam'),(r'\bpolyacryl\b|\bacrylic\b','Akrilik'),(r'\bspanplatte\b','Sunta'),(r'\bzinklegierung\b|\bzinc alloy\b','Çinko alaşımı')])
 labels=[]
 for pattern,label in terms:
  if re.search(pattern,value,re.I)and label not in labels: labels.append(label)
 if 'Paslanmaz çelik'in labels and'Çelik'in labels: labels.remove('Çelik')
 if any(x in labels for x in ['Demir','Çelik','Paslanmaz çelik','Alüminyum','Pirinç'])and'Metal'in labels: labels.remove('Metal')
 if any(x in labels for x in ['Mango ağacı','Kauçuk ağacı','Meşe','Kayın','Çam','Akasya','MDF','Kontrplak','Sunta'])and'Ahşap'in labels: labels.remove('Ahşap')
 if 'Mermer'in labels and'Taş'in labels: labels.remove('Taş')
 return ' · '.join(labels)if labels else re.sub(r'\s+',' ',value.replace('*','')).strip()
checks=[];new=[]
fields=['id','name','sku','brand','url','dimensions_cm','material_label','estimated_dimensions','size_source_kind','size_source_urls','source_market','scale_note','quality_status','quality_label','quality_note','estimated_axes','estimated_fields','scene_variants','default_scene_index','set_quantity','official_measurements','source_anomalies']
for e in entries:
 assert re.fullmatch(r'hm-[A-Za-z0-9_-]+',e['id'])and re.fullmatch(r'\d{10}',e['sku'])
 assert e['brand']=='H&M Home'and re.fullmatch(r'https://www2\.hm\.com/(tr_tr|en_gb|de_de)/productpage\.'+e['sku']+r'\.html',e['url'])
 assert e['sku']in sources and sha(e['glb_path'])==e['sha256']and Path(e['glb_path']).stat().st_size==e['bytes']
 assert e.get('size_source_urls')and 12<e['bytes']<=96*1024*1024
 if e['id']in old:
  assert old[e['id']]['sha256']==e['sha256'],'Never replace an existing reviewed master through an append'
  continue
 checks.append(dict(master=validate_native(e),topology=quality.audit(e)))
 p=sources[e['sku']];record={k:e[k]for k in fields if k in e}
 record['name']=display_names.get(e['sku'],e['name'])
 if e['id']in display_notes:
  record['model_notes_verbatim']={k:e[k]for k in ['scale_note','quality_note']if k in e}
  record.update({k:v for k,v in display_notes[e['id']].items()if k in ['scale_note','quality_note']})
 record['source_materials_verbatim']=e['material_label'];record['material_label']=display_material_label(e['material_label'])
 if e.get('official_measurements',{}).get('cover_size_label'):record['size_source_kind']='official_cushion_plan_estimated_depth'
 if e.get('official_measurements',{}).get('panel_flat_width_cm'):record['size_source_kind']='official_panel_dimensions_estimated_hanging_pose'
 photos=e.get('source_images')or p['reference_images'];photos=[dict(url=i['url'],thumbnail_url=i.get('thumbnail_url',i['url']),alt=i.get('alt')or e['name'])for i in photos if isinstance(i,dict)and urlsplit(i.get('url','')).hostname=='image.hm.com']
 assert photos
 record.update(category=p['category'],category_id=p['category_id'],category_slug=p['category_slug'],category_source_url=next((c['source_url']for c in discovered['categories']if c['id']==p['category_id']),e['url']),glb_url='/models/'+e['id']+'.glb?v='+e['sha256'],reference_images=photos,reference_photo_scope='exact_product',reference_source_url=e['url'],reference_observed_date='2026-10-27')
 filename=e['id']+'.glb';shutil.copy2(e['glb_path'],SITE/'model-source'/filename)
 manifest['models'].append(dict(id=e['id'],name=e['name'],filename=filename,accepted_filenames=[filename],bytes=e['bytes'],sha256=e['sha256'],key='models/'+e['sha256']+'.glb'));catalog.append(record)
 config={k:record[k]for k in ['id','name','sku','url','dimensions_cm','category','estimated_dimensions','size_source_kind','size_source_urls','source_market','quality_status','quality_label','quality_note','scene_variants','default_scene_index','set_quantity']if k in record}
 config.update(category=p['category'],materialLabel=record['material_label'],source_notes=list(dict.fromkeys(n for n in [record.get('scale_note'),record.get('quality_note')]if n)),materials={},meshes=[]);preview['models'].append(config)
 new.append(e['id'])
for sku in {e['sku']for e in entries}:
 p=sources[sku];ready=[r for r in catalog if r['sku']==sku];first=ready[0];p.update(model_status='ready',model_ids=[r['id']for r in ready],ready_model_variants=len(ready),model_url='/hmhome?model='+first['id']+'#koleksiyon',dimensions_cm=first['dimensions_cm'],material_label=first['material_label'],status_note='Malzemeli GLB hazır. '+first.get('scale_note',''),reference_images=first['reference_images'])
 for key in ['quality_label','quality_note','quality_status']:
  if first.get(key):p[key]=first[key]
assert all(next(r for r in manifest['models']if r['id']==id)==record for id,record in old.items())
manifest.update(model_count=len(manifest['models']),total_bytes=sum(r['bytes']for r in manifest['models']))
write(SITE/files[0],manifest);write(SITE/files[1],catalog);write(SITE/files[2],preview);write(SITE/files[3],discovered)
report=dict(reviewed_batch=str(manifest_path),reviewed_batch_sha256=expected,added_model_ids=new,prior_models_preserved=len(old),original_inventory_status_overlays=source_overlay_skus,source_identities_preserved=len(source_identities_before),total_models=len(manifest['models']),hm_model_variants=len(catalog),independent_checks=checks,local_only=True,cloud_published=False)
proof_dir=P/'integration-proofs';proof_dir.mkdir(exist_ok=True);write(proof_dir/(expected[:16]+'.json'),report);print(json.dumps({k:v for k,v in report.items()if k!='independent_checks'}))
