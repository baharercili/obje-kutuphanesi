"""Two own-source fabric material prototypes; previous frozen outputs preserved."""
from pathlib import Path
import sys,json,math,shutil
import numpy as np
from PIL import Image,ImageFilter
R=Path(__file__).resolve().parent;ROOT=R.parent/'lighting-models';sys.path.insert(0,str(ROOT));import build_lighting as L
OUTPUT=Path('/private/tmp/hm-lighting-20261027/hex-closed-top-v2');OUTPUT.mkdir(parents=True,exist_ok=True);L.R=OUTPUT
ids=['1311994002','1311994001','1311993001','1311993002','1316391001','1316390001'];registry=[]
for x in json.loads((ROOT/'original-image-masters.json').read_text()):
 if x['sku']in ids:
  origin=Path('/private/tmp/hm-lighting-20261027/textile-r03/originals')if x['sku']=='1311994002'else Path('/private/tmp/hm-lighting-20261027/hex-r04-sources/originals');registry.append(dict(x,original_path=x['path'],path=str(origin/Path(x['path']).name)))
L.dump(OUTPUT/'original-image-masters.json',registry);original_bank=L.material_bank
SPEC={'1311994002': {'master_code': '3a53f9352a70', 'box': [900, 700, 1412, 1212], 'tile_m': [0.0275, 0.0275], 'rgb': [218, 193, 143], 'kind': 'hexagon'}, '1311994001': {'master_code': 'c541fc199ed2', 'box': [900, 700, 1412, 1212], 'tile_m': [0.0275, 0.0275], 'rgb': [225, 217, 203], 'kind': 'hexagon'}, '1311993001': {'master_code': '0eb401c26231', 'box': [900, 700, 1412, 1212], 'tile_m': [0.0275, 0.0275], 'rgb': [213, 204, 188], 'kind': 'hexagon'}, '1311993002': {'master_code': '8ee729780981', 'box': [900, 700, 1412, 1212], 'tile_m': [0.0275, 0.0275], 'rgb': [208, 183, 133], 'kind': 'hexagon'}, '1316391001': {'master_code': '8fd6c42294e4', 'box': [900, 700, 1412, 1212], 'tile_m': [0.083, 0.083], 'rgb': [235, 227, 212], 'kind': 'hexagon'}, '1316390001': {'master_code': '6d79a49e69af', 'box': [900, 700, 1412, 1212], 'tile_m': [0.083, 0.083], 'rgb': [235, 227, 212], 'kind': 'hexagon'}}
# Per-SKU framing differs; these boxes exclude the actual upper edge.
SPEC['1311993001']['box']=[950,1100,1462,1612]
SPEC['1311993002']['box']=[950,1100,1462,1612]


def apply_uv(raw,spec):
 tw,th=np.array(spec['tile_m'])*2
 if spec['kind']=='cylinder':
  raw['_uvs']=[((math.atan2(z,x)/math.tau+.5)*math.tau*math.hypot(x,z)/tw,y/th)for x,y,z in raw['_vertices']]
 else:
  vertices=[];uv=[];faces=[]
  for tri in raw['_faces']:
   p=np.array([raw['_vertices'][i]for i in tri]);n=np.cross(p[1]-p[0],p[2]-p[0]);n/=np.linalg.norm(n);tangent=np.array([n[2],0,-n[0]]);tangent/=max(np.linalg.norm(tangent),1e-10);first=len(vertices)
   for v in p:vertices.append(tuple(v));uv.append((v[0]/tw,v[2]/th)if abs(n[1])>.99 else(float(v@tangent)/tw,v[1]/th))
   faces.append((first,first+1,first+2))
  raw['_vertices']=vertices;raw['_uvs']=uv;raw['_faces']=faces
 return raw

def cap_prism(name,mat,p,y0,y1):
 p=np.array(p);n=len(p);v=[(float(x),y,float(z))for y in[y0,y1]for x,z in p];uv=[(x/.05,z/.05)for x,y,z in v];f=[]
 for j in range(n):a=j;b=(j+1)%n;c=a+n;d=b+n;f.extend([(a,b,c),(b,d,c)])
 for k in[0,1]:
  ci=len(v);v.append((0,[y0,y1][k],0));uv.append((.5,.5))
  for j in range(n):f.append((ci,k*n+j,k*n+(j+1)%n))
 return L.B.solid(name,mat,v,f,uv,flat=True)
SOCKET={'1311994001':('E27',1,15),'1311994002':('E27',1,15),'1311993001':('E14',1,6),'1311993002':('E14',1,6),'1316391001':('E14',2,6),'1316390001':('E14',2,6)}
def holder(kind,y,number):
 outer,inside,th,h,pitch,turns=(.0175,.0145,.0141,.033,.0036,4.6)if kind=='E27'else(.0115,.0078,.00745,.024,.0028,4.2)
 cup=L.B.lathe('separate-'+kind+'-empty-insulating-cup-'+str(number),'socket',[(0,y),(outer-.001,y),(outer,y+.001),(outer,y+h-.001),(outer-.001,y+h),(inside,y+h),(inside,y+.005),(0,y+.005)],128,False)
 angles=np.linspace(0,math.tau*turns,360);pts=[(th*math.cos(a),y+.008+pitch*a/math.tau,th*math.sin(a))for a in angles];thread=L.tube('separate-'+kind+'-interpreted-metal-thread-'+str(number),'steel',pts,.0005 if kind=='E27'else .0004,10)
 return [cup,thread]
def wall_prism(name,mat,poly,y0,y1,thickness):
 poly=np.array(poly);scale=1-thickness/(min(np.ptp(poly[:,0]),np.ptp(poly[:,1]))/2);loops=[(poly,y0),(poly,y1),(poly*scale,y1),(poly*scale,y0)];n=len(poly);v=[(float(x),y,float(z))for pp,y in loops for x,z in pp];f=[]
 for k in range(4):
  for j in range(n):a=k*n+j;b=k*n+(j+1)%n;c=((k+1)%4)*n+j;d=((k+1)%4)*n+(j+1)%n;f.extend([(a,b,c),(b,d,c)])
 return L.B.solid(name,mat,v,f,[(x/.05,y/.05)for x,y,z in v],flat=True)
BUILD0=dict(L.BUILD)
def fabric(q):
 parts,info=BUILD0[q['sku']](q);spec=SPEC[q['sku']];shade=next(x for x in parts if x['name']=='separate-open-six-sided-fabric-shade');liner=next(x for x in parts if x['name']=='separate-six-sided-polystyrene-liner');h=max(y for x,y,z in shade['_vertices']);yb=min(y for x,y,z in shade['_vertices']);p=np.array(shade['_vertices'])[12:18][:,[0,2]];lp=np.array(liner['_vertices'])[12:18][:,[0,2]]
 parts+=[cap_prism('separate-native-woven-closed-upper-cover','textile',p*.9999,h-.00065,h-.00005),cap_prism('separate-polystyrene-upper-cover-liner','lining',lp*.9999,h-.00135,h-.00085)]
 bh=max(y for x,y,z in parts[0]['_vertices']);basepoly=np.array(parts[0]['_vertices'])[:6][:,[0,2]];outerpoly=np.array(shade['_vertices'])[:6][:,[0,2]];kind,count,maxw=SOCKET[q['sku']]
 parts=[part for part in parts if 'E27'not in part['name']and 'separate-upper-shade-mount'not in part['name']]
 if count==1:
  hy=yb+.012;parts+=holder(kind,hy,1);parts.append(L.lathe('separate-hidden-'+kind+'-insulating-support-neck','socket',[(0,bh-.002),(.008,bh-.002),(.008,hy+.004),(0,hy+.004)],96))
  for j,corner in enumerate(outerpoly[::2]*.94):parts.append(L.tube('separate-estimated-holder-support-'+str(j),'steel',[(0,hy+.002,0),(float(corner[0]),hy+.002,float(corner[1]))],.001,8))
 else:
  # Both light chambers are hollow; the two bulb positions and wire frame are interpreted.
  parts[0]=wall_prism('separate-hollow-fabric-covered-lower-light-chamber','textile',basepoly,0,bh,.0008);parts.append(wall_prism('separate-lower-polystyrene-inner-liner','lining',basepoly*.985,.001,bh-.001,.0007))
  heights=[bh*.40,yb+(h-yb)*.40]
  for j,(lower,upper)in enumerate(zip(basepoly[::2]*.93,outerpoly[::2]*.93)):
   parts.append(L.tube('separate-estimated-internal-frame-post-'+str(j),'steel',[(float(lower[0]),.003,float(lower[1])),(float(lower[0]),bh-.002,float(lower[1])),(float(upper[0]),h-.003,float(upper[1]))],.0009,8))
  for number,hy in enumerate(heights,1):
   parts+=holder(kind,hy,number)
   t=max(0,min(1,(hy-bh)/(h-bh)));frame=(basepoly[::2]*(1-t)+outerpoly[::2]*t)*.93
   for j,corner in enumerate(frame):parts.append(L.tube('separate-estimated-holder-'+str(number)+'-support-'+str(j),'steel',[(0,hy+.002,0),(float(corner[0]),hy+.002,float(corner[1]))],.001,8))
 if q['sku'].startswith('131639'):
  parts=[p for p in parts if 'inline-switch'not in p['name']and'inline-rocker'not in p['name']]
  parts.extend([L.B.cylinder('separate-source-round-floor-switch-body','white_switch',.025,0,.012,offset=(.130,0,0),n=128),L.B.cylinder('separate-source-raised-round-floor-button','white_switch',.017,.010,.015,offset=(.130,0,0),n=128)])
 for part in parts:
  if part['material']=='textile':apply_uv(part,spec)
 info['estimated']+=['weave_microheight_and_optical_parameters','material_crop_physical_repeat_scale','top_fabric_and_liner_thickness','hidden_holder_support_neck','floor_switch_dimensions_where_present'];info.update(id_suffix='-closed-top-v2',source_revision='r04-own-weave-closed-top-v2',source_top_cover_evidence='Own exact SKU close-up '+spec['master_code'],top_cover_semantics='Separate thin woven upper cover and lining from the own close-up; lower mounting access remains open',features=['Own-source closed woven upper surface, finite side shade and separate polystyrene upper/side liner','Real lower mounting opening; own source socket type/count, with separate empty cups, interpreted threads and supporting frame','Own native warp/weft crop with physical thread scale, per-face UV orientation and varying roughness/normal; source-specific round floor switch on the two floor versions'])
 note='Üst yüzey, bu ürünün kendi yakın plan fotoğrafındaki kumaş kapalı yüzeye göre yeniden kurulmuştur. İnce kumaş kapak ile iç astar ayrı parçalardır; alttaki gerçek montaj açıklığı korunmuştur. Kumaş örgüsü aynı ürünün özgün yakın planından, yeniden örnekleme yapılmadan alınmıştır. İplik ölçeği, mikro kabarıklık, yerel kalınlıklar ve görünmeyen bağlantılar fotoğraftan tahmin edilmiştir. Üretici CAD dosyası değildir.'
 if not q.get('official_measurements'):note+=' Bu exact SKU için resmî santimetre ölçüsü yayımlanmamıştır. Gösterilen tüm dış ölçüler fotoğraftan tahmin edilmiştir; başka SKU ölçüsü resmî veri olarak aktarılmamıştır.'
 else:note+=' Resmî ölçüler kendi kaynağındaki bileşen anlamlarıyla korunmuştur; toplam boy ve serbest kablo yerleşimi gereken yerlerde ayrıca tahmindir.'
 if q['sku'].startswith('131639'):note+=' Kaynaktaki yuvarlak ayak anahtarı ayrı geometriyle sunulmuştur; çapı ve düğme kalınlığı tahminidir.'
 note+=' Duy tipi ve adedi kendi resmî kaynak metninden korunmuştur: '+str(count)+' × '+kind+'. Ampul ürünle dahil değildir. İç taşıyıcı ve duyların yerleşimi, kalınlığı ve vida profili fotoğrafta görünmediği için yorumdur.'
 info.update(official_socket_type=kind,official_socket_count=count,official_source_max_led_w=maxw,bulbs_included=False,official_socket_evidence='/private/tmp/hm-lighting-20261027/hex-closed-top-v2/electrical-source-facts.json');info['estimated']+=['hidden_holder_positions_and_frame','holder_dimensions_and_thread_profile'];info['scale_note_override']=note;return parts,info

def bank(pid,keys,ims,out,overrides=None):
 mats,maps=original_bank(pid,keys,ims,out,overrides)
 if pid not in SPEC:return mats,maps
 spec=SPEC[pid];src=next(x for x in ims if spec['master_code']in x['path']);patch=Image.open(src['path']).convert('RGB').crop(spec['box']);raw=np.array(patch,dtype=float);blur=np.array(patch.filter(ImageFilter.GaussianBlur(8)),dtype=float);ratio=raw/np.maximum(blur,1);albedo=np.clip((1+.82*(ratio-1))*spec['rgb'],0,255)
 rowmean=albedo.mean(1);kk=np.arange(-32,33);gg=np.exp(-.5*(kk/10)**2);gg/=gg.sum();smooth=np.stack([np.convolve(np.pad(rowmean[:,c],(32,32),mode='reflect'),gg,'valid')for c in range(3)],1);albedo*=np.array(spec['rgb'])[None,None,:]/np.maximum(smooth[:,None,:],1)
 luminance=raw.mean(2);low=blur.mean(2);height=(luminance/np.maximum(low,1)-1)*.000060
 if spec['kind']=='hexagon':
  height=np.clip(height/max(height.std(),1e-10)*.000022,-.000060,.000060)
  for axis in [0,1]:
   padding=[(0,0),(0,0)];padding[axis]=(1,1);hp=np.pad(height,padding,mode='reflect');height=(np.take(hp,range(0,512),axis=axis)+2*np.take(hp,range(1,513),axis=axis)+np.take(hp,range(2,514),axis=axis))/4
 dy,dx=np.gradient(height,spec['tile_m'][1]/512,spec['tile_m'][0]/512);normal=np.stack([-dx,-dy,np.ones_like(dx)],2);normal/=np.linalg.norm(normal,axis=2,keepdims=True);rough=np.clip(.90-(ratio.mean(2)-1)*.07,.82,.97);orm=np.zeros((512,512,3),np.uint8);orm[:,:,0]=255;orm[:,:,1]=np.rint(rough*255)
 # Lossless mirrored tiles avoid edge discontinuities, without resizing native pixels.
 def mirror(a):return np.concatenate([np.concatenate([a,a[:,::-1]],1),np.concatenate([a[::-1],a[::-1,::-1]],1)],0)
 albedo=mirror(albedo);height=mirror(height);dy=(np.roll(height,-1,0)-np.roll(height,1,0))/(2*spec['tile_m'][1]/512);dx=(np.roll(height,-1,1)-np.roll(height,1,1))/(2*spec['tile_m'][0]/512);normal=np.stack([-dx,-dy,np.ones_like(dx)],2);normal/=np.linalg.norm(normal,axis=2,keepdims=True);orm=mirror(orm)
 for slot,a in [('albedo',np.clip(albedo,0,255).astype('uint8')),('normal',np.rint((normal+1)*127.5).astype('uint8')),('orm',orm)]:
  path=out/('textile-'+slot+'.png');Image.fromarray(a).save(path,optimize=True)
  for rec in maps:
   if rec['material']=='textile'and rec['slot']==slot:rec.update(sha256=L.sha(path),native_resolution=[1024,1024])
 ma=mats['textile'];ma['normalScale']=.45;ma['extras'].update(photo_pixels_baked=True,native_resolution=[1024,1024],material_crop_physical_repeat_m=(np.array(spec['tile_m'])*2).tolist(),microheight_m_estimated=.000060,source_weave_native=True)
 L.dump(out/'native-crop-provenance.json',[dict(material='textile',master=src['path'],master_sha256=src['sha256'],source_crop_native_pixels=spec['box'],native_crop_pixels=[512,512],output_pixels=[1024,1024],lossless_reflected_tiling=True,geometric_resampling_count=0,no_generated_pixels=True,no_background_or_silhouette=True,illumination_removed='Native local sigma8 normalization plus smooth row-mean drift correction; normals computed after reflection with seam-continuous periodic derivatives',physical_repeat_m_estimated=spec['tile_m'],microheight_m_estimated=.000060,scale_evidence='Own table-shade component height 12.3 cm and close-up weave grid; floor repeat separately photo-estimated at 8.3 cm per native512 crop. Unknown GB floor exterior remains estimated.',optical_parameters_estimated=True)])
 if 'lining'in mats:mats['lining']['extras']['diffuse_transmission_factor']=.22
 return mats,maps
L.material_bank=bank;L.BUILD={s:fabric for s in SPEC}
if __name__=='__main__':
 for sku in sys.argv[1:]or L.BUILD:L.build(sku)
