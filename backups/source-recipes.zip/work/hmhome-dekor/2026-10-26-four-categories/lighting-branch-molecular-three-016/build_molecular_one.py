"""Exact own molecular pendant, full official176cm assembly plus head detail scene."""
from pathlib import Path
import sys,json,math,ast,copy
import numpy as np
P=Path(__file__).resolve().parent.parent;sys.path.insert(0,str(P/'lighting-models'));import build_lighting as L
R=Path('/private/tmp/hm-lighting-20261028/molecular-one-016');S=Path('/private/tmp/hm-lighting-20261028/metal-glass-final-six-source-review');R.mkdir(parents=True,exist_ok=True);T=math.tau;pid='1275547001'
if list(R.glob('frozen*manifest*.json')):raise RuntimeError('Frozen output requires a separate revision.')
q=next(q for q in json.loads((S/'source-facts.json').read_text())if q['sku']==pid);q['official_measurements']=dict(width_cm=59,height_cm=176,depth_cm=31.5,cord_length_cm=200);L.sources=lambda:{pid:q};L.R=R;bank0=L.material_bank
registry=json.loads((S/'available-masters.json').read_text())[pid]
for x in registry:assert L.sha(x['path'])==x['sha256']
L.dump(R/'original-image-masters.json',registry)
for path,names in[(P/'lighting-portable-batch-008/build_portable.py',['closed_lathe','cylinder','rotate']),(P/'lighting-geometric-batch-006/build_geometric.py',['g9']),(P/'lighting-glass-batch-007/build_glass.py',['natural_profile'])]:
 tree=ast.parse(path.read_text());exec(compile(ast.Module(body=[x for x in tree.body if isinstance(x,ast.FunctionDef)and x.name in names],type_ignores=[]),'readonly-pure-standard-hardware','exec'),globals())
def align_y(n):
 n=np.array(n,float);n/=np.linalg.norm(n);v=np.cross([0,1,0],n);c=n[1]
 if c<-.999999:return np.diag([1,-1,-1])
 k=np.array([[0,-v[2],v[1]],[v[2],0,-v[0]],[-v[1],v[0],0]]);return np.eye(3)+k+k@k/(1+c)
def globe(index,n):
 r=.050;ri=.0482;hole=.0185;cut=math.sqrt(r*r-hole*hole);phi=sorted(set(list(np.linspace(-math.pi/2,math.asin(cut/r),95))+[0]));innerphi=sorted(set(list(np.linspace(-math.pi/2,math.asin(cut/ri),93))+[0]));profile=[(0,-r)]+[(r*math.cos(a),r*math.sin(a))for a in phi[1:]]+[(ri*math.cos(a),ri*math.sin(a))for a in innerphi[:0:-1]]+[(0,-ri)];parts=[L.B.lathe('separate-finite-open-mount-frosted-globe-'+str(index),'glass',profile,224,False),L.B.lathe('separate-painted-globe-mount-cap-'+str(index),'paint',[(.0036,cut-.0005),(.0205,cut-.0005),(.0205,cut+.003),(.0036,cut+.003)],128,True),L.B.lathe('separate-hollow-contacting-globe-ferrule-'+str(index),'paint',[(.0036,cut+.002),(.005,cut+.002),(.005,.056),(.0036,.056)],96,True)]
 holder=g9(0)
 for g in holder:g['name']+='-globe-'+str(index);g['_vertices']=[(x,cut-.0005-y,z)for x,y,z in g['_vertices']]
 parts+=holder;matrix=align_y(n)
 for g in parts:rotate(g,matrix)
 return parts

def cord():
 def path(turns):
  a=np.linspace(0,T*turns,900);r=np.linspace(.007,.034,len(a));coil=np.c_[r*np.cos(a),np.full(len(a),1.748),-.05+r*np.sin(a)];lead=np.vstack([np.linspace((0,.14,-.05),(0,1.748,-.05),100,endpoint=False),np.linspace((0,1.748,-.05),coil[0],10,endpoint=False)]);up=coil[-1].copy();up[1]=1.754;return np.vstack([lead,coil,np.linspace(coil[-1],up,10,endpoint=False),np.linspace(up,(0,1.754,-.05),30,endpoint=False),np.linspace((0,1.754,-.05),(0,1.758,-.05),10)])
 lo,hi=.01,8
 for _ in range(45):
  mid=(lo+hi)/2;p=path(mid);le=np.linalg.norm(np.diff(p,axis=0),axis=1).sum()
  if le<2:lo=mid
  else:hi=mid
 turns=(lo+hi)/2;p=path(turns);assert .027/turns>.0035
 proof=dict(official_cord_length_m=2,centreline_length_m=float(np.linalg.norm(np.diff(p,axis=0),axis=1).sum()),modelled_turns=turns,turn_pitch_m=.027/turns,coil_wall_clearance_m=.045-.0015-.034-.0015,visible_cord_drop_m=1.075,modelled_canopy_dimensions_m=[.09,.035,.09],manufacturer_hidden_capacity_unverified=True);L.dump(R/'cord-fit-proof.json',proof);return L.tube('separate-full-source-200cm-cord-with-hidden-canopy-excess','cord',p.tolist(),.0015,10),proof

def build(q):
 parts=[];centres=[np.array([-.245,.075,-.05]),np.array([.245,.125,-.05]),np.array([.035,.05,.165])];joint=np.array([-.090,.126,-.05]);directions=[np.array([1,0,0]),np.array([-1,0,0]),(joint-centres[2])/np.linalg.norm(joint-centres[2])];assemblies=[globe(i,n)for i,n in enumerate(directions)];v=np.array(assemblies[2][0]['_vertices']);centres[2][1]=-v[:,1].min();centres[2][2]=.215-v[:,2].max()
 for c,gg in zip(centres,assemblies):
  for g in gg:L.move(g,c);parts.append(g)
 left=centres[0]+directions[0]*.054;right=centres[1]+directions[1]*.054;xy=natural_profile([(left[0],left[1]),(-.10,.114),(0,.148),(.11,.157),(right[0],right[1])],150);main=np.c_[xy[:,0],xy[:,1],np.full(len(xy),-.05)];parts.append(L.tube('separate-source-curved-main-iron-branch','paint',main.tolist(),.0035,10));joint=main[np.argmin(abs(main[:,0]+.090))];end=centres[2]+directions[2]*.054;controls=np.array([joint,joint+np.array([.04,0,.07]),end+directions[2]*.04,end]);tt=np.linspace(0,1,120);branch=sum((np.array([1,3,3,1])[k]*(1-tt)**(3-k)*tt**k)[:,None]*controls[k]for k in range(4));parts.append(L.tube('separate-source-curved-third-iron-branch','paint',branch.tolist(),.0035,10));parts.append(L.move(L.B.lathe('separate-hollow-long-vertical-iron-stem','paint',[(.002,.145),(.0035,.145),(.0035,.650),(.002,.650)],128,True),(0,0,-.05)))
 parts.append(L.move(L.B.lathe('separate-ceiling-canopy-source-flat-cylinder','paint',[(.0036,1.725),(.044,1.725),(.045,1.726),(.045,1.760),(.0435,1.760),(.0435,1.7265),(.0036,1.7265)],192,True),(0,0,-.05)));cp,proof=cord();parts.append(cp)
 note='Kendi resmî genişliği 59 cm, toplam yüksekliği 176 cm, derinliği 31,5 cm ve kablo boyu 200 cm korunur. Kendi fotoğrafındaki üç buzlu cam küre, eğrisel iki metal dal ve uzun ince dik gövde ayrı parçalardır. Küre çapı yaklaşık 10 cm, cam kalınlığı, dal açıları/eğrileri ve metal gövde uzunluğu fotoğraf tahminidir. Başlık ve kablo dahil tam sarkıt varsayılan görünümde 176 cm’dir; ikinci görünüm yalnız aynı ölçekte başlık ayrıntısını incelemek içindir. Kaynak G9, azami 4 W LED ve üç cam küre der; ampuller dahil değildir. Her kürede gerçek montaj açıklığı, ayrı siyah kapak ve iç boş G9 duy vardır. Ana bileşim demir %80/cam %20’dir; opak beyaz plastik küre kullanılmaz. Cam buzlanması ve ışık geçirgenliği fiziksel malzeme yorumudur; ampul veya parlama resmi eklenmez. Tam 2 m kablo gövdenin içinden geçer, yaklaşık 107,5 cm görünür askıyı izler; kalan bölüm tahmini 9 cm çaplı tavan kapağı içinde tek ayrı düzeyde sarılıdır. Model kapasitesi denetlenmiştir; gerçek üretici iç kapasitesi ve gizli bağlantı boyutları doğrulanmamıştır. Üretici CAD dosyası değildir.'
 return parts,dict(target_cm=None,id_suffix='-own-three-globe-r01',official_axes=list(q['official_measurements']),estimated=['globe_diameter_cm_and_glass_thickness','branch_curves_angles_and_globe_mount_directions','long_iron_stem_component_height','canopy_diameter_and_height','canopy_excess_cord_pose_and_unverified_capacity','mount_apertures_caps_and_hidden_G9_hardware','frosted_glass_optical_parameters'],features=['Own three frosted glass globes and distinct bowed main/third iron branches','Full official176cm hanging assembly,59cm width31.5cm depth and200cm cord','Each real hollow glass sphere has a mounting aperture, cap/ferrule and empty G9 slot holder','Whole source-like pendant plus same-scale head detail view; no emissive bulbs or photo reflection'],material_overrides=dict(paint=('paint',[27,28,27],.34,0),glass=('plastic',[236,234,224],.40,0),cord=('plastic',[24,25,24],.68,0),ceramic=('plastic',[231,230,220],.72,0)),official_socket_type='G9',official_socket_count=3,official_source_max_led_w=4,bulbs_included=False,measured_cord_length_m=proof['centreline_length_m'],scene_variants=[dict(index=0,label='Tam sarkıt'),dict(index=1,label='Başlık ayrıntısı')],default_scene_index=0,quality_label='Yerel form ve optik değerler fotoğraf yorumudur',quality_note='176 cm tam askı ölçüsüdür. Başlık ayrıntısı aynı fiziksel ölçekte eksik parçaları göstermez.',scale_note_override=note,source_component_dimension_facts=q['official_dimension_facts'])
def bank(pid,keys,ims,out,overrides=None):
 mats,maps=bank0(pid,keys,ims,out,overrides);mats['glass'].update(ior=1.48,thickness=.0018,transmission=.015,attenuationColor=[1,1,1],attenuationDistance=.03,normalScale=0);mats['glass']['extras']['diffuse_transmission_factor']=.55;mats['paint'].update(clearcoat=.06,clearcoatRoughness=.35,normalScale=0);return mats,maps
L.BUILD={pid:build};L.material_bank=bank
if __name__=='__main__':
 L.build(pid);rows=json.loads((R/'manifest.json').read_text());e=rows[0];doc,binary=L.read_glb(e['glb_path']);nodes=copy.deepcopy(doc['nodes']);N=len(nodes);detail=[i for i,n in enumerate(nodes)if not n.get('name','').startswith(('separate-ceiling-canopy','separate-full-source-200cm-cord'))];doc['nodes']+=copy.deepcopy(nodes);doc['scenes']=[dict(name='Tam sarkıt',nodes=list(range(N))),dict(name='Başlık ayrıntısı',nodes=[N+i for i in detail])];doc['scene']=0;L.write_glb(e['glb_path'],doc,binary);e.update(sha256=L.sha(e['glb_path']),bytes=Path(e['glb_path']).stat().st_size,scene_nodes_disjoint=True);L.dump(Path(e['asset_dir'])/'entry.json',e);L.dump(R/'manifest.json',[e])
