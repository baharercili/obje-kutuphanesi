"""Two exact-source three-branch painted iron ceiling fixtures, real finite cupped leaves."""
from pathlib import Path
import sys,json,math,ast
import numpy as np
P=Path(__file__).resolve().parent.parent;sys.path.insert(0,str(P/'lighting-models'));import build_lighting as L
R=Path('/private/tmp/hm-lighting-20261028/branch-two-016');S=Path('/private/tmp/hm-lighting-20261028/metal-glass-final-six-source-review');R.mkdir(parents=True,exist_ok=True);T=math.tau;IDS=['1253907001','1253907003']
if list(R.glob('frozen*manifest*.json')):raise RuntimeError('Frozen output requires another revision.')
qs={q['sku']:q for q in json.loads((S/'source-facts.json').read_text())if q['sku']in IDS};L.sources=lambda:qs;L.R=R;bank0=L.material_bank
for q in qs.values():q['official_measurements']=dict(height_cm=45,approx_arm_length_cm=61.5,cord_length_cm=200)
registry=[x for s,xs in json.loads((S/'available-masters.json').read_text()).items()if s in IDS for x in xs]
for x in registry:assert L.sha(x['path'])==x['sha256']
L.dump(R/'original-image-masters.json',registry)
for path,names in[(P/'lighting-portable-batch-008/build_portable.py',['closed_lathe','cylinder','rotate']),(P/'lighting-geometric-batch-006/build_geometric.py',['eholder']),(P/'lighting-glass-batch-007/build_glass.py',['natural_profile'])]:
 tree=ast.parse(path.read_text());exec(compile(ast.Module(body=[x for x in tree.body if isinstance(x,ast.FunctionDef)and x.name in names],type_ignores=[]),'readonly-pure-standard-hardware','exec'),globals())
def leaf(name):
 na=192;nr=44;vertices=[];uv=[];loops=[]
 for inside in[False,True]:
  index=[];index.append([len(vertices)]);vertices.append((0,.001 if inside else 0,0));uv.append((.5,.5))
  for rho in np.linspace(1/nr,1,nr):
   ids=[]
   for a in np.linspace(0,T,na,endpoint=False):
    x=.14*rho*math.cos(a);z=.11*rho*math.sin(a)*(1+.30*rho*math.cos(a));y=.09*rho*rho+.22*x+(.001 if inside else 0);ids.append(len(vertices));vertices.append((x,y,z));uv.append((x/.28+.5,z/.22+.5))
   index.append(ids)
  loops.append(index)
 faces=[]
 for index in loops:
  for a,b in zip(index[:-1],index[1:]):
   for j in range(na):
    if len(a)==1:faces.append((a[0],b[j],b[(j+1)%na]))
    else:faces.extend([(a[j],a[(j+1)%na],b[j]),(a[(j+1)%na],b[(j+1)%na],b[j])])
 a,b=loops[0][-1],loops[1][-1]
 for j in range(na):faces.extend([(a[j],a[(j+1)%na],b[j]),(a[(j+1)%na],b[(j+1)%na],b[j])])
 return L.B.solid(name,'paint',vertices,faces,uv,flat=False)
def rotate_local(angle,roll):
 # Local negative X is the narrow outward leaf tip; local Z follows the tangent.
 u=np.array([math.sin(angle),0,math.cos(angle)]);t=np.array([math.cos(angle),0,-math.sin(angle)]);base=np.column_stack([-u,np.array([0,1,0]),t]);c,s=math.cos(roll),math.sin(roll);rz=np.array([[c,-s,0],[s,c,0],[0,0,1]]);return base@rz

def cord():
 def path(turns):
  a=np.linspace(0,T*turns,1000);rr=np.linspace(.009,.043,len(a));first=np.c_[rr*np.cos(a),np.full(len(a),.433),rr*np.sin(a)];b=np.linspace(a[-1],a[-1]+T*turns,1000);rr=np.linspace(.043,.009,len(b));second=np.c_[rr*np.cos(b),np.full(len(b),.440),rr*np.sin(b)];lead=np.vstack([np.linspace((0,.095,0),(0,.433,0),90,endpoint=False),np.linspace((0,.433,0),first[0],12,endpoint=False)]);return np.vstack([lead,first,np.linspace(first[-1],second[0],12,endpoint=False),second,np.linspace(second[-1],(0,.440,0),20,endpoint=False),np.linspace((0,.440,0),(0,.447,0),12)])
 lo,hi=.01,12
 for _ in range(45):
  mid=(lo+hi)/2;p=path(mid);le=np.linalg.norm(np.diff(p,axis=0),axis=1).sum()
  if le<2:lo=mid
  else:hi=mid
 turns=(lo+hi)/2;p=path(turns);p=p[np.r_[True,np.linalg.norm(np.diff(p,axis=0),axis=1)>1e-8]];pitch=.034/turns;assert pitch>.0035;clearance=.073*math.sqrt(1-((.450-.433)/.095)**2)-.0015-.043-.0015;assert clearance>.003
 proof=dict(official_cord_length_m=2,centreline_length_m=float(np.linalg.norm(np.diff(p,axis=0),axis=1).sum()),two_layer_turns_each=turns,turn_pitch_m=pitch,minimum_modelled_canopy_wall_clearance_m=clearance,layer_separation_m=.007,canopy_dimensions_m=[.146,.095,.146],hidden_manufacturer_capacity_unverified=True);L.dump(R/'two-layer-cord-fit-proof.json',proof);return L.tube('separate-full-200cm-cord-in-hollow-post-and-canopy','cord',p.tolist(),.0015,10),proof

def build(q):
 parts=[cylinder('separate-lower-painted-iron-junction-cylinder','paint',.027,.005,.090),cylinder('separate-source-lower-junction-cap-screw','paint',.005,0,.006),L.B.lathe('separate-hollow-long-central-painted-post','paint',[(.002,.090),(.004,.090),(.004,.360),(.002,.360)],144,True)];anchor_proof=[]
 for i,(angle,yy,roll)in enumerate(zip(np.radians([-150,-55,60]),[.275,.160,.205],np.radians([-12,-4,8]))):
  def curve(radius):return natural_profile([(.014,.090),(.014,.110),(.025,min(yy-.025,.160)),(.070,min(yy-.008,.185)),(radius,yy)],140)
  lo,hi=.15,.65
  for _ in range(40):
   mid=(lo+hi)/2;pr=curve(mid);length=float(np.linalg.norm(np.diff(pr,axis=0),axis=1).sum())
   if length<.475:lo=mid
   else:hi=mid
  rr=(lo+hi)/2;pr=curve(rr);u=np.array([math.sin(angle),0,math.cos(angle)]);points=np.c_[pr[:,0]*u[0],pr[:,1],pr[:,0]*u[2]];parts.append(L.tube('separate-source-curved-painted-branch-'+str(i),'paint',points.tolist(),.0030,10));centre=u*rr+np.array([0,yy+.003,0]);matrix=rotate_local(angle,float(roll));gg=[leaf('separate-finite-open-egg-leaf-cupped-iron-shade-'+str(i)),cylinder('separate-source-underleaf-contact-stud-'+str(i),'paint',.005,-.005,.010),cylinder('separate-source-visible-underleaf-fastener-'+str(i),'paint',.0035,-.006,.003)]
  hh=eholder('E14',.003)
  for g in hh:g['name']+='-leaf-'+str(i)
  gg+=hh
  for g in gg:rotate(g,matrix,centre);parts.append(g)
  anchor_proof.append(dict(branch=i,source_approx_arm_length_m=.615,interpreted_curved_tube_centreline_m=float(np.linalg.norm(np.diff(points,axis=0),axis=1).sum()),interpreted_radial_half_leaf_length_m=.14,arm_semantics_interpreted=True,radial_endpoint_m=rr,azimuth_degrees_estimated=float(math.degrees(angle)),head_roll_degrees_estimated=float(math.degrees(roll)),physical_stud_meets_branch_endpoint=True))
 outer=[(.073*math.sin(a),.450-.095*math.cos(a))for a in np.linspace(math.asin(.004/.073),math.pi/2,65)];inner=[(max(.0025,r-.0015),min(.450,y+.001))for r,y in outer];parts.append(L.B.lathe('separate-own-bowl-shaped-open-ceiling-canopy','paint',outer+inner[::-1],192,True));parts.append(L.move(cylinder('separate-source-small-canopy-side-screw','steel',.0018,0,.0015),(0,0,0)))
 # Orient the side screw to the visible source canopy wall, then set its contact position.
 screw=parts[-1];screw['_vertices']=[(x,.430-z,.0708+y)for x,y,z in screw['_vertices']]
 cp,proof=cord();parts.append(cp);L.dump(R/(q['sku']+'-arm-anchor-and-contact-proof.json'),anchor_proof)
 note='Kendi resmî yaklaşık toplam yüksekliği 45 cm ve bir kolun yaklaşık uzunluğu 61,5 cm korunur. Kaynak 61,5 cm’nin parça sınırlarını ayrıca çizmediğinden modelde yaklaşık 47,5 cm eğrisel metal kol merkez çizgisi ve 14 cm yarım başlık uzanımı olarak yorumlanmıştır; bu üretici montaj çizimi değildir. Diğer dış genişlik/derinlik, üç kolun azimut/yükseklikleri, yaprak biçimli başlığın 28/22 cm yerel zarfı ve eklem açıları kendi fotoğraf oranından tahmindir. Kendi ana fotoğrafının karanlık ürün maskesiyle yaklaşık 14,6 cm tavan cup çapı / 9,5 cm yüksekliği, 5,4 cm alt silindir çapı / 9 cm yüksekliği ve 8 mm dik gövde kalınlığı yorumlanmıştır; bunlar perspektif fotoğraf tahminidir. Kendi fotoğrafındaki üç ayrı kıvrımlı kol, sonlu açık cupped metal yapraklar, alt bağlantı silindiri, tavan cup’ı ve küçük görünen bağlantı vidaları ayrı geometridir. Her başlıkta boş E14 duy vardır; azami 6 W LED, ampuller dahil değildir. Ana bileşim demir %100’dür; başlığa kumaş veya cam eklenmez. Kendi açıklamasındaki 2 m kablo, içi boş dik gövdeden geçip kendi fotoğraf oranıyla tahmini 14,6 cm çaplı tavan cup’ındaki iki ayrı düzeyde sarılır. Modelin boş hacmi ve aralıkları denetlenmiştir; üreticinin gerçek gizli kapasitesi ve iç donanımı doğrulanmamıştır. Mat lake boya fiziksel malzemedir; fotoğraf parlama/gölgesi yüzeye yapıştırılmaz. Üretici CAD dosyası değildir.'
 return parts,dict(target_cm=None,id_suffix='-own-three-leaf-r01',official_axes=list(q['official_measurements']),estimated=['published_arm_length_component_boundary_interpretation','overall_width_and_depth_cm','own_three_branch_azimuths_and_end_heights','leaf_length_width_cup_profile_and_roll','finite_iron_sheet_thickness','hidden_empty_E14_hardware_and_contact_studs','canopy_and_post_dimensions','canopy_stored_cord_capacity_unverified','paint_roughness_colour_and_fastener_dimensions'],features=['Own three curved iron arms, cupped egg-shaped open leaves and lower central junction cylinder','Separate finite painted metal sheets, contacting studs and empty E14 holders×3','Source45cm approximate height and61.5cm arm semantics explicitly interpreted; full200cm internal cord','Own bowl ceiling cup and small side screw, hidden cable capacity explicitly unverified'],material_overrides=dict(paint=('paint',[42,44,46]if q['sku']=='1253907001'else[190,171,151],.36,0),cord=('plastic',[30,30,28]if q['sku']=='1253907001'else[184,172,152],.70,0)),official_socket_type='E14',official_socket_count=3,official_source_max_led_w=6,bulbs_included=False,measured_cord_length_m=proof['centreline_length_m'],arm_anchor_and_contact_interpretation=anchor_proof,quality_label='Kol sınırları ve başlık formu fotoğraf yorumudur',quality_note='45 cm toplam yükseklik ve 61,5 cm kol uzunluğu yaklaşık kaynak ölçüleridir. Diğer yerel ölçüler tahmindir.',source_component_dimension_facts=q['official_dimension_facts'],scale_note_override=note)
def bank(pid,keys,ims,out,overrides=None):
 mats,maps=bank0(pid,keys,ims,out,overrides);mats['paint'].update(clearcoat=.06,clearcoatRoughness=.35,normalScale=0);return mats,maps
L.BUILD={s:build for s in IDS};L.material_bank=bank
if __name__=='__main__':
 for sku in sys.argv[1:]or IDS:L.build(sku)
