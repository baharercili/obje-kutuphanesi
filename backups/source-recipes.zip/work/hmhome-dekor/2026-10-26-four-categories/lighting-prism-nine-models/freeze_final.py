"""Freeze the selected nine candidates without changing any historical file."""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess

ROOT = Path(__file__).resolve().parent
FROZEN = ROOT / "frozen-source-specific-prism-nine-r04"
FROZEN.mkdir(exist_ok=False)
def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def save(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")

rows = json.loads((ROOT / "manifest.json").read_text())
checks = {row["sku"]: row for row in json.loads((ROOT / "independent-glb-byte-audit.json").read_text())}
assert len(rows) == 9 and len({row["sku"] for row in rows}) == 9
masters = json.loads((ROOT / "original-image-masters.json").read_text())
assert len(masters) == 36 and all(digest(row["path"]) == row["sha256"] for row in masters)

selected = []
preservation = []
for row in rows:
    assert checks[row["sku"]]["valid"] and checks[row["sku"]]["sha256"] == row["sha256"]
    source = Path(row["asset_dir"])
    target = FROZEN / row["sku"]
    subprocess.run(["/usr/bin/ditto", "--clone", str(source), str(target)], check=True)
    frozen = dict(row,
        asset_dir=str(target),
        model_path=str(target / "model.json"),
        glb_path=str(target / Path(row["glb_path"]).name),
        geometry_validation=str(target / "geometry-validation.json"),
        material_validation=str(target / "material-validation.json"),
    )
    assert digest(frozen["glb_path"]) == row["sha256"]
    selected.append(frozen)
    views = [{"label": label, "path": str(target / (label + ".png")),
              "sha256": digest(target / (label + ".png"))}
             for label in ["on", "on-capraz", "ustten", "yan", "arka"]]
    preservation.append({
        "sku": row["sku"],
        "glb_sha256": row["sha256"],
        "candidate_GLBequals_frozen": True,
        "source_model_sha256": digest(target / "model.json"),
        "all_source_JPEGs_unchanged": all(digest(m["path"]) == m["sha256"] for m in row["original_images"]),
        "native_five_views": views,
        "original_hero_is_own_live_primary_asset": row["source_hero_exact_asset_matched"],
    })

save(FROZEN / "manifest.json", selected)
save(FROZEN / "independent-glb-byte-audit.json", list(checks.values()))
supplements = []
for name in ["source-records.final02.json", "original-image-masters.json",
             "unavailable-own-master-records.json", "electrical-source-facts.raw.json",
             "socket-count-and-cord-length-proof.json", "cache-exact-SHA-recovery-plan.json",
             "two-necessary-cloud-masters-proof.json", "four-critical-cloud-masters-proof.json",
             "final-metadata-source-enrichment-proof.json", "wall-own-lit-face-colour-preservation.json"]:
    source = ROOT / name
    target = FROZEN / name
    target.write_bytes(source.read_bytes())
    assert digest(target) == digest(source)
    supplements.append({"path": str(target), "sha256": digest(target)})

proof = {
    "frozen": True,
    "created_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "assigned_scope_products": 9,
    "this_frozen_count": 9,
    "root_actual_accepted": 0,
    "ready_claimed": 0,
    "review_status": "pending_root_actual_Three_browser_review",
    "no_full_category_completion_claim": True,
    "manifest_sha256": digest(FROZEN / "manifest.json"),
    "cached_own_original_JPEGs": 36,
    "expected_source_gallery_JPEG_records": 38,
    "remaining_two_lifestyle_JPEGs_archival_not_required_for_geometry_or_cloth": True,
    "master_JPEG_SHA_unchanged": True,
    "nominal_socket_count_type_and_published_cord_lengths_checked": True,
    "all_part_solids_closed_metres_Yup_bottom0_XZcentre": True,
    "all_textures_embedded_and_all_extensions_declared": True,
    "unlit_or_emissive_lighting_not_used": True,
    "own_source_component_labels_and_unknown_construction_explicit": True,
    "native_renderer": str(ROOT.parent / "furniture-models/render-native"),
    "native_renderer_sha256": digest(ROOT.parent / "furniture-models/render-native"),
    "native_limitations": [
        "SceneKit fixed studio exposures differ across object sizes; actual Three.js is required for final PBR colour/material judgement.",
        "SceneKit ignores KHR_materials_diffuse_transmission and renders an opaque fallback.",
    ],
    "upper_closure_limitations": "Table own heroes show covered upper planes; floor and pendant unseen cover construction remains a labelled photo interpretation.",
    "historical_candidates_and_masters_preserved": True,
    "canonical_modified_by_lane": False,
    "preservation": preservation,
    "supplements": supplements,
}
save(FROZEN / "preservation-and-local-QA.json", proof)
ledger = json.loads((ROOT / "scope-ledger.json").read_text())
ledger.update(frozen_manifest=str(FROZEN / "manifest.json"),
              frozen_manifest_sha256=proof["manifest_sha256"],
              root_actual_accepted=0, ready_claimed=0)
save(ROOT / "scope-ledger.json", ledger)
print("FROZEN", FROZEN / "manifest.json", proof["manifest_sha256"], flush=True)
print("PROOF", digest(FROZEN / "preservation-and-local-QA.json"), flush=True)
print("GLB_BYTES", sum(row["bytes"] for row in selected), flush=True)
