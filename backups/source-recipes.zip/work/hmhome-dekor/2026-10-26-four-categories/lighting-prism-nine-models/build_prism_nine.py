"""Source-specific nine geometric textile lights. Own output only.
No top-level execution from the historical cylinder/hex production scripts.
"""
from pathlib import Path
import sys,json,math,hashlib,datetime
sys.dont_write_bytecode=True
import numpy as np
from PIL import Image,ImageFilter
R=Path(__file__).resolve().parent;P=R.parent;sys.path.insert(0,str(P/'lighting-models'))
import build_lighting as L
B,G=L.B,L.G;T=math.tau;REV='r04'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,x):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
Q={e['sku']:e for e in json.loads((R/'source-records.final02.json').read_text())};MASTERS=json.loads((R/'original-image-masters.json').read_text())
S={
 '1344539001':dict(kind='small',w=.17,d=.17,shade_h=.185,base_w=.085,base_h=.115,total=.30,socket='E14',count=1,cord=1.6,token='57066bde2612',box=[900,700,1412,1212],tile=[.025,.025],label='Kumaş kaplı geometrik masa lambası · 30 cm'),
 '1344543001':dict(kind='small',w=.17,d=.17,shade_h=.185,base_w=.085,base_h=.115,total=.30,socket='E14',count=1,cord=1.6,token='49df3e4df25e',box=[900,700,1412,1212],tile=[.025,.025],label='Kumaş kaplı geometrik masa lambası · 30 cm'),
 '1344555001':dict(kind='large',w=.27,d=.27,shade_h=.28,base_w=.135,base_h=.15,total=.43,socket='E27',count=1,cord=1.6,token='dce87ad4e380',box=[900,600,1412,1112],tile=[.025,.025],label='Büyük geometrik kumaş masa lambası · 43 cm'),
 '1344556001':dict(kind='large',w=.27,d=.27,shade_h=.28,base_w=.135,base_h=.15,total=.43,socket='E27',count=1,cord=1.6,token='a3789e0bb982',box=[900,600,1412,1112],tile=[.025,.025],label='Büyük geometrik kumaş masa lambası · 43 cm'),
 '1344559001':dict(kind='floor',w=.30,d=.30,shade_h=.90,base_w=.18,base_h=.30,total=1.20,socket='E27',count=2,cord=2.,token='3421c06627ef',box=[450,900,962,1412],tile=[.025,.025],label='İki duylu geometrik kumaş lambader · 120 cm'),
 '1344560001':dict(kind='floor',w=.30,d=.30,shade_h=.90,base_w=.18,base_h=.30,total=1.20,socket='E27',count=2,cord=2.,token='27ae3cd024d0',box=[450,900,962,1412],tile=[.025,.025],label='İki duylu geometrik kumaş lambader · 120 cm'),
 '1344557001':dict(kind='wall',w=.22,d=.112,shade_h=.60,total=.60,socket='E27',count=2,cord=2.,token='309a6844945b',box=[610,800,738,1312],pigment_box=[820,800,948,1312],tile=[.036,.144],label='V kesitli kumaş duvar aydınlatması · 60 cm'),
 '1344558001':dict(kind='wall',w=.22,d=.112,shade_h=.60,total=.60,socket='E27',count=2,cord=2.,token='00781561da41',box=[610,800,738,1312],pigment_box=[820,800,948,1312],tile=[.036,.144],label='V kesitli kumaş duvar aydınlatması · 60 cm'),
 '1344535001':dict(kind='pendant',w=.42,d=.42,shade_h=.225,base_w=.25,base_h=.080,total=.305,socket='E27',count=1,cord=2.,token='f4fd477c6f55',box=[800,1000,1312,1512],tile=[.030,.030],label='İki katlı geometrik kumaş sarkıt · 42 cm'),
}
def poly(w,d):return np.array([[-w/2,-d/2],[w/2,-d/2],[w/2,d/2],[-w/2,d/2]],float)
def shell(name,mat,p,y0,y1,th):
 p=np.array(p);c=p.mean(0);inside=c+(p-c)*(1-th/(min(np.ptp(p[:,0]),np.ptp(p[:,1]))/2));loops=[(p,y0),(p,y1),(inside,y1),(inside,y0)];n=len(p);v=[(x,y,z)for pp,y in loops for x,z in pp];f=[]
 for k in range(4):
  for j in range(n):a=k*n+j;b=k*n+(j+1)%n;c0=((k+1)%4)*n+j;d0=((k+1)%4)*n+(j+1)%n;f.extend([(a,b,c0),(b,d0,c0)])
 return B.solid(name,mat,v,f,[(0,0)]*len(v),flat=True)
def cap(name,mat,p,y0,y1):
 n=len(p);v=[(x,y,z)for y in[y0,y1]for x,z in p];f=[]
 for j in range(n):a=j;b=(j+1)%n;c=a+n;d=b+n;f.extend([(a,b,c),(b,d,c)])
 for k,y in enumerate([y0,y1]):
  ci=len(v);v.append((*p.mean(0)[:1],y,p.mean(0)[1]))
  for j in range(n):f.append((ci,k*n+j,k*n+(j+1)%n))
 return B.solid(name,mat,v,f,[(0,0)]*len(v),flat=True)
def uv_face(g,tw,th):
 vv=[];ff=[];uv=[]
 for tri in g['_faces']:
  p=np.array([g['_vertices'][i]for i in tri]);n=np.cross(p[1]-p[0],p[2]-p[0]);n/=max(np.linalg.norm(n),1e-15);t=np.array([n[2],0,-n[0]]);t/=max(np.linalg.norm(t),1e-15);start=len(vv)
  for v in p:vv.append(tuple(v));uv.append((v[0]/tw,v[2]/th)if abs(n[1])>.98 else(float(v@t)/tw,v[1]/th))
  ff.append((start,start+1,start+2))
 g['_vertices']=vv;g['_faces']=ff;g['_uvs']=uv;return g
def holder(kind,y,number,down=False,x=0,z=0):
 r,ri,h,pitch=(.0185,.0135,.033,.00363)if kind=='E27'else(.0115,.007,.024,.00282)
 cup=L.B.lathe('separate-empty-'+kind+'-insulating-cup-'+str(number),'socket',[(0,0),(r-.001,0),(r,.001),(r,h-.001),(r-.001,h),(ri,h),(ri,.004),(0,.004)],128,False)
 aa=np.linspace(0,T*3.3,320);thread=L.tube('separate-nominal-'+kind+'-helical-contact-'+str(number),'contact',[(ri*.98*math.cos(a),.006+pitch*a/T,ri*.98*math.sin(a))for a in aa],.00045 if kind=='E27'else .00035,8)
 for g in[cup,thread]:g['_vertices']=[(px+x,y+(-py if down else py),pz+z)for px,py,pz in g['_vertices']]
 return[cup,thread]
def plate_with_keyholes():
 # Analytic radial frames make the two real keyhole openings without a boolean
 # dependency. Nine touching closed pieces form one flat mounting plate.
 parts=[]
 for j,(x0,x1)in enumerate([(-.053,-.043),(-.023,.023),(.043,.053)]):parts.append(L.RO.box('mounting-plate-solid-column-'+str(j),'frame',x1-x0,.46,.0012,((x0+x1)/2,.30,-.0006)))
 for number,cx in enumerate([-.033,.033],1):
  for j,(y0,y1)in enumerate([(.07,.480),(.512,.53)]):parts.append(L.RO.box('mounting-plate-hole-column-fill-'+str(number)+'-'+str(j),'frame',.020,y1-y0,.0012,(cx,(y0+y1)/2,-.0006)))
  aa=list(np.linspace(0,T,96,endpoint=False));aa +=[math.atan2(y,x)%T for x in[-.010,.010]for y in[-.012,.020]];aa +=[math.atan2(.012,x)%T for x in[-.0018,.0018]];aa +=[math.acos(.0018/.004),math.pi-math.acos(.0018/.004)];aa=sorted(set(round(a,12)for a in aa));outer=[];inner=[]
  for a in aa:
   co,si=math.cos(a),math.sin(a);bound=min(.010/max(abs(co),1e-14),(.020 if si>=0 else .012)/max(abs(si),1e-14));ri=.004
   if si>0:ri=max(ri,min(.0018/max(abs(co),1e-14),.012/si))
   outer.append((cx+bound*co,.492+bound*si));inner.append((cx+ri*co,.492+ri*si))
  loops=[(outer,-.0012),(outer,0),(inner,0),(inner,-.0012)];n=len(aa);v=[(x,y,z)for p,z in loops for x,y in p];f=[]
  for k in range(4):
   for j in range(n):a=k*n+j;b=k*n+(j+1)%n;c=((k+1)%4)*n+j;d=((k+1)%4)*n+(j+1)%n;f.extend([(a,b,c),(b,d,c)])
  parts.append(B.solid('source-rear-mounting-plate-real-keyhole-'+str(number),'frame',v,f,[(x,y)for x,y,z in v],flat=True))
 return parts
def v_panel(name,p0,p1,h,mat,th,offset=0):
 a=np.array(p0);b=np.array(p1);direction=b-a;normal=np.array([direction[1],-direction[0]])/np.linalg.norm(direction);a=a+normal*offset;b=b+normal*offset
 v=[(x,y,z)for y in[0,h]for x,z in[a,b,a+normal*th,b+normal*th]];f=[(0,1,4),(1,5,4),(2,6,3),(3,6,7),(0,4,2),(2,4,6),(1,3,5),(3,7,5),(0,2,1),(1,2,3),(4,5,6),(5,7,6)]
 return B.solid(name,mat,v,f,[(0,0)]*8,flat=True)
def switch_and_cord(s):
 # Exact published centreline length; coiling is an uninstalled/stored pose.
 start=np.array([0,.010,-s.get('base_w',s['w'])*.48]);radius=min(.065,s['w']*.25)
 def points(turns):
  a=np.linspace(0,T*turns,700);rr=np.linspace(.016,radius,len(a));coil=np.c_[rr*np.sin(a),.0025+np.arange(len(a))/len(a)*.002,-.012+rr*np.cos(a)];return np.vstack([np.linspace(start,coil[0],24,endpoint=False),coil])
 lo,hi=.1,12
 for _ in range(36):
  mid=(lo+hi)/2;p=points(mid)
  if np.linalg.norm(np.diff(p,axis=0),axis=1).sum()<s['cord']:lo=mid
  else:hi=mid
 p=points((lo+hi)/2);le=float(np.linalg.norm(np.diff(p,axis=0),axis=1).sum());parts=[L.tube('separate-published-length-fabric-cord-stored-coil','cable',p,.0016,10)];k=int(len(p)*.78);pos=p[k];direction=p[k+2]-p[k-2];direction[1]=0;direction/=np.linalg.norm(direction);side=np.array([direction[2],0,-direction[0]])
 if s['kind']=='floor':
  parts +=[B.cylinder('separate-source-round-floor-switch','switch',.026,0,.010,offset=(pos[0],0,pos[2]),n=128),B.cylinder('separate-source-raised-floor-switch-button','switch',.017,.009,.014,offset=(pos[0],0,pos[2]),n=128)]
 else:
  g=L.lathe('separate-rounded-inline-plastic-switch','switch',[(0,-.022),(.008,-.022),(.011,-.018),(.011,.018),(.008,.022),(0,.022)],96);g['_vertices']=[tuple(pos+side*x+direction*y+np.array([0,.003+z*.42,0]))for x,y,z in g['_vertices']];parts.append(g)
  g=L.lathe('separate-oval-inline-rocker','switch',[(0,-.009),(.003,-.009),(.0043,-.006),(.0043,.006),(.003,.009),(0,.009)],64);g['_vertices']=[tuple(pos+side*x+direction*y+np.array([0,.008+z*.25,0]))for x,y,z in g['_vertices']];parts.append(g)
 return parts,le
def pendant_cord(s):
 def pts(turns):
  lead=np.linspace([0,s['total'],0],[0,.582,0],70,endpoint=False);a=np.linspace(0,T*turns,600);r=np.linspace(.008,.045,len(a));coil=np.c_[r*np.sin(a),.584+np.arange(len(a))*.00002,r*np.cos(a)];finish=np.linspace(coil[-1],[0,.60,0],25);return np.vstack([lead,coil,finish])
 lo,hi=.2,15
 for _ in range(36):
  mid=(lo+hi)/2;p=pts(mid)
  if np.linalg.norm(np.diff(p,axis=0),axis=1).sum()<s['cord']:lo=mid
  else:hi=mid
 p=pts((lo+hi)/2);parts=[L.tube('separate-published-two-metre-fabric-cord-stored-surplus','cable',p,.0016,10),L.lathe('separate-source-white-ceiling-rose','frame',[(0,.60),(.058,.60),(.060,.602),(.060,.627),(.058,.629),(0,.629)],160)]
 # The source states a switch. Its unseen exact position and dimensions are
 # interpreted; no electrical connector or bulb is invented.
 g=L.lathe('separate-interpreted-cord-inline-switch','switch',[(0,.402),(.009,.402),(.010,.407),(.010,.438),(.009,.443),(0,.443)],96);parts.append(g)
 return parts,float(np.linalg.norm(np.diff(p,axis=0),axis=1).sum())
def wall_cord(s):
 # Visible short downward lead and the remaining exact length in a loose
 # vertical stored coil. Everything stays in front of the wall datum Z=0.
 def pts(turns):
  lead=np.linspace([0,0,.026],[0,-.116,.026],60,endpoint=False);a=np.linspace(0,T*turns,700);r=np.linspace(.010,.044,len(a));coil=np.c_[r*np.sin(a),-.16+r*np.cos(a),.027+np.arange(len(a))*.000010];return np.vstack([lead,coil])
 lo,hi=.2,15
 for _ in range(36):
  mid=(lo+hi)/2;p=pts(mid)
  if np.linalg.norm(np.diff(p,axis=0),axis=1).sum()<s['cord']:lo=mid
  else:hi=mid
 p=pts((lo+hi)/2);parts=[L.tube('separate-two-metre-wall-cord-front-of-wall-stored-pose','cable',p,.0016,10)]
 g=L.lathe('separate-wall-cord-rounded-inline-switch','switch',[(0,-.022),(.008,-.022),(.011,-.018),(.011,.018),(.008,.022),(0,.022)],96);g['_vertices']=[(x,y-.060,.026+z*.42)for x,y,z in g['_vertices']];parts.append(g)
 g=L.lathe('separate-wall-cord-oval-rocker','switch',[(0,-.009),(.003,-.009),(.0043,-.006),(.0043,.006),(.003,.009),(0,.009)],64);g['_vertices']=[(x,y-.060,.0318+z*.25)for x,y,z in g['_vertices']];parts.append(g)
 return parts,float(np.linalg.norm(np.diff(p,axis=0),axis=1).sum())
def geometry(s):
 parts=[];kind=s['kind'];top_evidence=''
 if kind=='wall':
  # Own rear photo shows a V shade with an open rear, open end access,
  # separate liner and a mounting plate. No hexagon upper lid is copied here.
  p=[[-s['w']/2,0],[0,s['d']],[s['w']/2,0]]
  for j in range(2):
   parts.append(v_panel('separate-V-front-woven-face-'+str(j),p[j],p[j+1],s['total'],'textile',.00045))
   parts.append(v_panel('separate-V-polystyrene-liner-'+str(j),p[j],p[j+1],s['total'],'lining',.0006,offset=.0005))
  parts+=plate_with_keyholes();parts+=holder('E27',.18,1,True,z=.040)+holder('E27',.42,2,z=.040)
  for yy in[.18,.42]:parts.append(L.tube('separate-interpreted-socket-mounting-arm-'+str(yy),'frame',[(0,yy,-.001),(0,yy,.040)],.0020,8))
  for yy in[.12,.48]:parts.append(L.tube('separate-source-cross-frame-'+str(yy),'frame',[(-.10,yy,.008),(-.07,yy,.008),(-.058,yy,.02),(.058,yy,.02),(.07,yy,.008),(.10,yy,.008)],.0011,8))
  top_evidence='Ürünün kendi arka ve ön fotoğrafları V kesitli kaplamayı, açık arka ve uç erişimini, ayrı astarı ve asma levhasını gösteriyor; kapalı üst kapak eklenmedi.'
 else:
  bh=s['base_h'];yb=bh;yt=s['total'];upper=poly(s['w'],s['d']);lower=poly(s['base_w'],s['base_w'])
  for name,p,y0,y1,mat in [('upper',upper,yb,yt,'textile'),('lower',lower,0,bh,'lower')]:
   parts.append(shell('separate-'+name+'-woven-surface',mat,p,y0,y1,.00045));parts.append(shell('separate-'+name+'-polystyrene-liner','lining',p*.994,y0+.0004,y1-.0004,.00065))
  rim=.0055;cover=poly(s['w']-rim*2,s['d']-rim*2)
  parts.append(shell('separate-woven-inward-upper-return-rim','textile',upper,yt-.0005,yt,rim));parts.append(cap('separate-recessed-covered-top-surface-photo-interpretation','textile',cover,yt-.0012,yt-.00075));parts.append(cap('separate-inner-top-diffuser','lining',cover*.996,yt-.0020,yt-.0014));parts.append(cap('separate-lower-contact-plate','frame',lower*.99,0,.0018))
  parts.append(L.tube('separate-soft-upper-woven-edge-hem','textile',[(x,yt-.0004,z)for x,z in upper*.997],.00035,8,True))
  top_evidence='Bu ürünün kendi ön fotoğrafında kumaş kapalı üst yüzey ve içe kıvrılan kenar görülüyor. 5,5 mm kenar genişliği, kapak kotu ve katman kalınlıkları fotoğrafa dayalı tahmindir.'
  if kind=='floor':top_evidence='Bu ürünün ön ve kumaş yakın planında üst kapak yapısı kesin seçilemiyor. Ayrı kapalı kumaş üst yüzey, astar ve kenar dönüşü yorumlanarak kurulmuştur; doğrulanmış üretici detayı değildir.'
  if kind=='pendant':
   # The smaller stage hangs below the broad upper light chamber.
   parts+=holder('E27',bh+.075,1,True);parts.append(L.lathe('separate-estimated-pendant-holder-support','frame',[(0,bh+.074),(.003,bh+.074),(.003,yt-.002),(0,yt-.002)],96));top_evidence='Ürünün kendi fotoğrafları iki kumaş katı ile beyaz tavan rozetini gösteriyor. Görünmeyen üst kapak yapısı ayrıca yorumlanmıştır.'
  else:
   ys=[bh+.018]if s['count']==1 else[bh*.45,bh+s['shade_h']*.45]
   for j,y in enumerate(ys,1):
    parts+=holder(s['socket'],y,j);parts.append(L.lathe('separate-interpreted-holder-support-neck-'+str(j),'frame',[(0,.002 if j==1 else bh+.002),(.003,.002 if j==1 else bh+.002),(.003,y+.002),(0,y+.002)],96))
  for x,z in upper*.93:parts.append(L.tube('separate-estimated-inner-frame-post-'+str(x)+'-'+str(z),'frame',[(x,by,z)for by in[yb+.002,yt-.002]],.0008,8))
  for yy,p in[(yb+.002,upper*.94),(yt-.002,upper*.94)]:parts.append(L.tube('separate-perimeter-inner-frame-'+str(yy),'frame',[(x,yy,z)for x,z in p],.0008,8,True))
 if kind=='pendant':cord,le=pendant_cord(s)
 elif kind=='wall':cord,le=wall_cord(s)
 else:cord,le=switch_and_cord(s)
 parts+=cord;tw,th=np.array(s['tile'])*2
 for g in parts:
  if g['material']in['textile','lower']:uv_face(g,tw,th)
 return parts,le,top_evidence
def bank(pid,s,ims,out):
 m=next(m for m in ims if s['token']in m['path']);original=Image.open(m['path']).convert('RGB');patch=original.crop(s['box']);raw=np.array(patch,float);low=np.array(patch.filter(ImageFilter.GaussianBlur(8)),float);ratio=raw/np.maximum(low,1)
 if 'pigment_box'in s:
  lit=np.asarray(original.crop(s['pigment_box']),float);pigment=np.minimum(np.quantile(lit.reshape(-1,3),.85,axis=0),244)
 else:pigment=np.minimum(np.quantile(raw.reshape(-1,3),.85,axis=0)*1.03,244)
 albedo=np.clip((1+.82*(ratio-1))*pigment,0,255);height=np.clip((ratio.mean(2)-1)*.00022,-.000055,.000055)
 def mirror(a):return np.concatenate([np.concatenate([a,a[:,::-1]],1),np.concatenate([a[::-1],a[::-1,::-1]],1)],0)
 albedo=mirror(albedo);height=mirror(height);ny,nx=height.shape;dy=(np.roll(height,-1,0)-np.roll(height,1,0))/(2*s['tile'][1]/(ny/2));dx=(np.roll(height,-1,1)-np.roll(height,1,1))/(2*s['tile'][0]/(nx/2));normal=np.stack([-dx,-dy,np.ones_like(dx)],2);normal/=np.linalg.norm(normal,axis=2,keepdims=True)
 defs={'textile':(albedo,.91,0,normal),'lower':(albedo,.92,0,normal),'lining':(np.full((8,8,3),[233,230,216]),.72,0,None),'frame':(np.full((8,8,3),[232,231,220]),.42,0,None),'socket':(np.full((8,8,3),[231,230,216]),.52,0,None),'contact':(np.full((8,8,3),[135,119,77]),.30,1,None),'switch':(np.full((8,8,3),[235,234,224]),.46,0,None),'cable':(np.full((128,128,3),[226,224,211]),.83,0,None)};mats={};maps=[]
 for key,(rgb,rough,metal,nn)in defs.items():
  yy,xx=rgb.shape[:2]
  if nn is None:nn=np.zeros_like(rgb,dtype=float);nn[:,:,2]=1
  if key=='cable':
   ys,xs=np.indices((yy,xx));gr=np.sin((xs+ys)*T/8)*np.sin((xs-ys)*T/8);dy,dx=np.gradient(gr*.055);nn=np.stack([-dx,-dy,np.ones_like(dx)],2);nn/=np.linalg.norm(nn,axis=2,keepdims=True)
  orm=np.zeros((yy,xx,3),np.uint8);orm[:,:,0]=255;orm[:,:,1]=round(rough*255);orm[:,:,2]=metal*255
  for slot,data in [('albedo',np.clip(rgb,0,255).astype('uint8')),('normal',np.rint((nn+1)*127.5).astype('uint8')),('orm',orm)]:
   p=out/(key+'-'+slot+'.png');Image.fromarray(data,'RGB').save(p,optimize=True);maps.append(dict(material=key,slot=slot,path=str(p),sha256=sha(p),native_resolution=[xx,yy]))
  ma=dict(baseColorFactor=[1,1,1,1],baseColorTexture=key+'-albedo.png',normalTexture=key+'-normal.png',metallicRoughnessTexture=key+'-orm.png',normalScale=.45 if key=='textile'else(.22 if key=='lower'else .16),metallic=1,roughness=1,alphaMode='OPAQUE',doubleSided=False,extras=dict(intrinsic_material=True,baked_reflections=False,native_resolution=[xx,yy],photo_pixels_baked=key in['textile','lower'],estimated_optics=True))
  mats[key]=ma
 proof=dict(materials=['textile','lower'],own_master=m,source_crop_native_pixels=s['box'],native_crop_pixels=list(patch.size),output_pixels=[nx,ny],geometric_resampling_count=0,no_upscale=True,lossless_reflected_tiling=True,own_intrinsic_pigment_rgb=pigment.tolist(),intrinsic_pigment_native_box=s.get('pigment_box',s['box']),own_brighter_diffuse_face_used_for_wall_pigment='pigment_box'in s,colour_is_photo_interpretation_not_calibrated_reflectance=True,source_illumination_removed='Per-channel local sigma8 normalization; wall pigment comes separately from the own lit diffuse face so its shaded face is not baked into material colour',physical_crop_repeat_m_estimated=s['tile'],microheight_m_max_estimated=.000055,source_specific_no_other_SKU_texture=True,no_background_edge_or_product_silhouette=True)
 dump(out/'own-native-weave-provenance.json',proof);return mats,maps
def build(pid):
 s=S[pid];q=Q[pid];ims=[m for m in MASTERS if m['sku']==pid];preferred=q['reference_images'][0]['url'].split('?')[0];ims.sort(key=lambda m:0 if m['url'].split('?')[0]==preferred else 1);assert ims and all(sha(m['path'])==m['sha256']for m in ims);out=R/('candidate-'+REV)/pid;out.mkdir(parents=True,exist_ok=False);parts,le,top=geometry(s);p=np.concatenate([g['_vertices']for g in parts]);lo=p.min(0);hi=p.max(0);shift=np.array([(lo[0]+hi[0])/2,lo[1],(lo[2]+hi[2])/2]);meshes=[];checks=[]
 for g in parts:
  g['_vertices']=[tuple(np.array(v)-shift)for v in g['_vertices']];m,c=L._finalize(G.H.orient(g));G.H.S.flatcap_normals(m);meshes.append(m);checks.append(c)
 repair=G.M.ensure_uv_faces(meshes)+G.H.ensure_float32_uv(meshes);mats,maps=bank(pid,s,ims,out);used={m['material']for m in meshes};mats={k:v for k,v in mats.items()if k in used};dims=((hi-lo)*100).tolist();fmt=lambda n:format(n,'.6g').replace('.','p');ident='hm-'+pid+'-textile-prism-'+REV+'-h'+fmt(dims[1])+'-w'+fmt(dims[0])+'-d'+fmt(dims[2])
 note='Resmî ölçülerin ham bileşen etiketleri aynen korundu. Yerel kalınlıklar, kare kesit varsayımı gereken derinlikler, kumaşın fiziksel iplik ölçeği/optik değerleri, iç taşıyıcı ve boş duy yerleşimleri fotoğrafa dayalı yorumdur; üretici CAD veya kalibre tarama değildir. Duy adedi/tipi kendi resmî exactSKU metninden; ampul eklenmedi. Kablo yayımlanan uzunluğunda ayrı geometriyle sarılı sunum pozundadır. '
 if s['kind']=='floor':note+='Resmî toplam120cm, üst30cm vealt18cm ankrajları korunur; iki katın90/30cmyükseklik paylaşımı fotoğraf yorumudur. '
 if s['kind']=='pendant':note+='Resmî Total30.5cm kumaş gövde ankrajıdır; sargılı2mkablo, yaklaşık30cmgösterim asması ve tavan rozeti ayrı olduğundan tüm montajın kutu yüksekliği bundan büyüktür. Bu üst kurulum pozu ve iki katın22.5/8cmpaylaşımı yorumdur. '
 if s['kind']=='wall':note+='60cmkumaş kasanın altındaki kısa kablo çıkışı ve gevşek düşey sargı ayrıca yorumlanmış kurulum/saklama pozudur; tüm kutu yüksekliğini artırır. Kablo duvar düzleminin arkasına geçirilmemiştir. '
 note+='Üst kapak durumu: '+top
 evidence=out/'source-evidence.json';dump(evidence,dict(source_record=q,own_spec=s,exact_electrical_source=str(R/'electrical-source-facts.raw.json'),original_image_masters=ims,measured_cord_length_m=le,top_evidence=top))
 meta=dict(id=ident,sku=pid,name=s['label'],brand='H&M Home',category='Aydınlatma',category_id='lighting',category_slug='aydinlatma',url=q['url'],source_market=q['source_market'],markets=q['markets'],colour=q.get('colour_verbatim'),material_label='Dokuma polyester / Polistiren / Demir',official_materials=q.get('composition',q['composition_facts']),official_measurements=q.get('official_measurements',{}),official_dimension_facts=q['official_dimension_facts'],official_dimension_component_labels_preserved=True,dimensions_cm=dims,source_dimensions_hwd_cm=[dims[1],dims[0],dims[2]],source_size_pointer=str(evidence)+'#source_record/official_dimension_facts',source_evidence_files=[str(evidence),str(R/'electrical-source-facts.raw.json')]+q['source_evidence_files'],source_images=q['gallery_images'],original_image=ims[0]['path'],original_image_url=ims[0]['url'],original_image_sha256=ims[0]['sha256'],original_images=[{k:m[k]for k in['path','url','sha256']}for m in ims],units='metres',up_axis='Y',origin='bottom bounding-box centre',estimated_dimensions=True,estimated_fields=['unpublished_depths','cloth_repeat_scale','microheight_and_optical_parameters','cloth_and_liner_thickness','internal_supports_and_holder_positions','upper_closure_where_not_resolved','cord_stored_pose','switch_dimensions'],scale_note=note,quality_label='Özgün dokuma yüzey · Malzemeli geometrik aydınlatma',unlit=False,baked_reflections=False,photo_pixels_baked=True,display_state_unpowered=True,official_socket_type=s['socket'],official_socket_count=s['count'],bulbs_included=False,measured_cord_length_m=le,source_top_cover_evidence=top,model_status='pending_root_visual_review',ready_model_variants=0,quality_pending=True,model_revision='source-specific-textile-prism-'+REV,photographed_features=['Own-SKU native weave crop with physical normal/roughness and per-face physical UV scale','Thin closed fabric solids, separate polystyrene liner and internal wire support','Own-source socket count/type; separate empty cups, nominal contact helix and source switch','Open V/back access and keyhole mounting plate only on the two wall versions; no generic hex cap copied'],no_category_completion_claim=True)
 dump(out/'model.json',dict(metadata=meta,materials=mats,meshes=meshes));dump(out/'geometry-validation.json',dict(valid=True,mesh_count=len(meshes),triangles=sum(c['triangles']for c in checks),closed_material_solids=True,meshes=checks,uv_repairs=repair,no_affine_dimension_distortion=True));dump(out/'material-validation.json',dict(valid=True,maps=maps,master_SHA_unchanged=all(sha(m['path'])==m['sha256']for m in ims),unlit=False,baked_reflections=False))
 report=L.export_assets(out/'model.json',out,ident);glb=out/(ident+'.glb');d,bb=L.read_glb(glb);used=set(d.get('extensionsUsed',[]))
 for ma in d['materials']:
  if ma['name']in['textile','lower','lining']:ma.setdefault('extensions',{})['KHR_materials_diffuse_transmission']=dict(diffuseTransmissionFactor=.14 if ma['name']!='lining'else .24,diffuseTransmissionColorFactor=[1,1,1]);used.add('KHR_materials_diffuse_transmission')
 d['extensionsUsed']=sorted(used);bb=G.M.embed_tangents(d,bb);L.write_glb(glb,d,bb);assert glb.stat().st_size<96*1024*1024;report['deliverable_sha256']['glb']=sha(glb);report['glb_bytes']=glb.stat().st_size;dump(report['files']['validation'],report)
 e=dict(meta,asset_dir=str(out),model_path=str(out/'model.json'),glb_path=str(glb),sha256=sha(glb),bytes=glb.stat().st_size,geometry_validation=str(out/'geometry-validation.json'),material_validation=str(out/'material-validation.json'),size_source_kind='official_exact_SKU_component_facts_with_photo_interpretation',size_source_urls=[q['url']]);dump(out/'entry.json',e);rows=json.loads((R/'manifest.json').read_text())if(R/'manifest.json').exists()else[];rows=[x for x in rows if x['sku']!=pid]+[e];dump(R/'manifest.json',rows);print('PRISM',pid,len(meshes),glb.stat().st_size,e['sha256'],flush=True)
if __name__=='__main__':
 for pid in sys.argv[1:]or S:build(pid)
