"""Two own-source fabric material prototypes; previous frozen outputs preserved."""
from pathlib import Path
import sys,json,math,shutil
import numpy as np
from PIL import Image,ImageFilter
R=Path(__file__).resolve().parent;ROOT=R.parent/'lighting-models';sys.path.insert(0,str(ROOT));import build_lighting as L
L.R=R;shutil.copyfile(ROOT/'original-image-masters.json',R/'original-image-masters.json');original_bank=L.material_bank
SPEC={'1223602009':dict(master_code='441ba0e56d5e',box=[700,700,1212,1212],tile_m=[.0204,.0375],rgb=[149,163,175],kind='cylinder'),'1311994002':dict(master_code='3a53f9352a70',box=[900,700,1412,1212],tile_m=[.0275,.0275],rgb=[218,193,143],kind='hexagon')}

def apply_uv(raw,spec):
 tw,th=np.array(spec['tile_m'])*2
 if spec['kind']=='cylinder':
  raw['_uvs']=[((math.atan2(z,x)/math.tau+.5)*math.tau*math.hypot(x,z)/tw,y/th)for x,y,z in raw['_vertices']]
 else:
  vertices=[];uv=[];faces=[]
  for tri in raw['_faces']:
   p=np.array([raw['_vertices'][i]for i in tri]);n=np.cross(p[1]-p[0],p[2]-p[0]);n/=np.linalg.norm(n);tangent=np.array([n[2],0,-n[0]]);tangent/=max(np.linalg.norm(tangent),1e-10);first=len(vertices)
   for v in p:vertices.append(tuple(v));uv.append((v[0]/tw,v[2]/th)if abs(n[1])>.99 else(float(v@tangent)/tw,v[1]/th))
   faces.append((first,first+1,first+2))
  raw['_vertices']=vertices;raw['_uvs']=uv;raw['_faces']=faces
 return raw

BUILD0=dict(L.BUILD)
def fabric(q):
 parts,info=BUILD0[q['sku']](q);spec=SPEC[q['sku']]
 for part in parts:
  if part['material']=='textile':apply_uv(part,spec)
 info['estimated']+=['weave_microheight_and_optical_parameters','material_crop_physical_repeat_scale'];info['features']+=['Own exact-SKU native woven material crop: separated warp/weft albedo, variable roughness and a physical microheight-derived normal map; no generic noise texture'];info['source_revision']='r03-own-native-weave'
 info['scale_note_override']='Resmî ölçüler kendi ürün kaynağındaki bileşen anlamlarıyla korunmuştur. Kumaşın iplik örgüsü aynı ürünün özgün yakın planından, yeniden örnekleme yapılmadan alınmıştır. Işık değişimi giderilmiş; iplik ölçeği, mikro kabarıklık ve yüzey pürüzlülüğü fotoğraftan tahmin edilmiştir. Abajur gerçek iç açıklığı ve ayrı iç astarıyla sunulur. Üretici CAD dosyası değildir.'
 return parts,info

def bank(pid,keys,ims,out,overrides=None):
 mats,maps=original_bank(pid,keys,ims,out,overrides)
 if pid not in SPEC:return mats,maps
 spec=SPEC[pid];src=next(x for x in ims if spec['master_code']in x['path']);patch=Image.open(src['path']).convert('RGB').crop(spec['box']);raw=np.array(patch,dtype=float);blur=np.array(patch.filter(ImageFilter.GaussianBlur(32)),dtype=float);ratio=raw/np.maximum(blur,1);albedo=np.clip((1+.82*(ratio-1))*spec['rgb'],0,255)
 luminance=raw.mean(2);low=blur.mean(2);height=(luminance/np.maximum(low,1)-1)*.000060
 if spec['kind']=='hexagon':
  height=np.clip(height/max(height.std(),1e-10)*.000022,-.000060,.000060)
  for axis in [0,1]:height=(np.roll(height,1,axis)+2*height+np.roll(height,-1,axis))/4
 dy,dx=np.gradient(height,spec['tile_m'][1]/512,spec['tile_m'][0]/512);normal=np.stack([-dx,-dy,np.ones_like(dx)],2);normal/=np.linalg.norm(normal,axis=2,keepdims=True);rough=np.clip(.90-(ratio.mean(2)-1)*.07,.82,.97);orm=np.zeros((512,512,3),np.uint8);orm[:,:,0]=255;orm[:,:,1]=np.rint(rough*255)
 # Lossless mirrored tiles avoid edge discontinuities, without resizing native pixels.
 def mirror(a):return np.concatenate([np.concatenate([a,a[:,::-1]],1),np.concatenate([a[::-1],a[::-1,::-1]],1)],0)
 albedo=mirror(albedo);norm=normal.copy();right=norm[:,::-1].copy();right[:,:,0]*=-1;top=np.concatenate([norm,right],1);bottom=top[::-1].copy();bottom[:,:,1]*=-1;normal=np.concatenate([top,bottom],0);orm=mirror(orm)
 for slot,a in [('albedo',np.clip(albedo,0,255).astype('uint8')),('normal',np.rint((normal+1)*127.5).astype('uint8')),('orm',orm)]:
  path=out/('textile-'+slot+'.png');Image.fromarray(a).save(path,optimize=True)
  for rec in maps:
   if rec['material']=='textile'and rec['slot']==slot:rec.update(sha256=L.sha(path),native_resolution=[1024,1024])
 ma=mats['textile'];ma['normalScale']=.45;ma['extras'].update(photo_pixels_baked=True,native_resolution=[1024,1024],material_crop_physical_repeat_m=(np.array(spec['tile_m'])*2).tolist(),microheight_m_estimated=.000060,source_weave_native=True)
 L.dump(out/'native-crop-provenance.json',[dict(material='textile',master=src['path'],master_sha256=src['sha256'],source_crop_native_pixels=spec['box'],native_crop_pixels=[512,512],output_pixels=[1024,1024],lossless_reflected_tiling=True,geometric_resampling_count=0,no_generated_pixels=True,no_background_or_silhouette=True,illumination_removed='Local per-channel low-frequency normalization; room light/shadow excluded',physical_repeat_m_estimated=spec['tile_m'],microheight_m_estimated=.000060,scale_evidence='Blue primary weave spectrum: vertical pitch 5.89 px / horizontal 4.16 px; own official 20 cm shade width. Detail crop periods 17.07 / 22.26 px. Hex own 12.3 cm component height and visible detail grid, conservative photo estimate.',optical_parameters_estimated=True)])
 return mats,maps
L.material_bank=bank;L.BUILD={s:fabric for s in SPEC}
if __name__=='__main__':
 for sku in sys.argv[1:]or L.BUILD:L.build(sku)
