from pathlib import Path
import sys, math, json, numpy as np
sys.dont_write_bytecode=True
R=Path(__file__).resolve().parents[1]; sys.path.insert(0,str(R));import build_one_rattan_r04 as F
L=F.L;O=F.O
old_sweep=F.sweep

def flat_sweep(name,mat,points,radials,width,thick,closed=False):
 if 'ONE-true-continuous' not in name:return old_sweep(name,mat,points,radials,width,thick,closed)
 p=np.asarray(points);rn=np.asarray(radials);w=np.broadcast_to(np.asarray(width),len(p));t=np.gradient(p,axis=0);t/=np.linalg.norm(t,axis=1,keepdims=True);bn=np.cross(t,rn);bn/=np.linalg.norm(bn,axis=1,keepdims=True);rn=np.cross(bn,t);rn/=np.linalg.norm(rn,axis=1,keepdims=True)
 # Source flat cane face, same outer 3mm width and0.86mm depth;0.18mm soft corners.
 ns=16;v=[];uv=[];faces=[];dist=np.r_[0,np.cumsum(np.linalg.norm(np.diff(p,axis=0),axis=1))]
 for i in range(len(p)):
  rad=min(.00018,thick/2,w[i]/2); profile=[]
  for corner in range(4):
   ang0=corner*math.pi/2;cr=(thick/2-rad)*(1 if corner in[0,3]else-1);cb=(w[i]/2-rad)*(1 if corner in[0,1]else-1)
   for k in range(4):
    a=ang0+k*math.pi/6; profile.append((cr+rad*math.cos(a),cb+rad*math.sin(a)))
  peri=sum(math.hypot(profile[(j+1)%ns][0]-profile[j][0],profile[(j+1)%ns][1]-profile[j][1])for j in range(ns));d=0
  for j,(a,b)in enumerate(profile):
   v.append(tuple(p[i]+rn[i]*a+bn[i]*b));uv.append((dist[i]/.020,d/.0019));d+=math.hypot(profile[(j+1)%ns][0]-a,profile[(j+1)%ns][1]-b)
 for k in range(len(p)-1):
  for j in range(ns):a=k*ns+j;b=k*ns+(j+1)%ns;c=(k+1)*ns+j;dd=(k+1)*ns+(j+1)%ns;faces.extend([(a,b,c),(b,dd,c)])
 for k in[0,len(p)-1]:
  c=len(v);v.append(tuple(p[k]));uv.append((dist[k]/.020,.5))
  for j in range(ns):faces.append((c,k*ns+j,k*ns+(j+1)%ns))
 return O.B.solid(name+'-source-rounded-flat-face',mat,v,faces,uv)
F.sweep=flat_sweep;F.R=R/'qa/flat-weft-candidate-study';F.R.mkdir(exist_ok=True);L.R=F.R;L.dump(F.R/'original-image-masters.json',F.REG);L.build(F.SKU)
