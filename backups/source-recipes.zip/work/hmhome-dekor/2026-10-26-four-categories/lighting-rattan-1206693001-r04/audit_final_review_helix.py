from pathlib import Path
import json,math,hashlib
import numpy as np
R=Path(__file__).resolve().parent;B=R/'review-candidate-r04';e=json.loads((B/'manifest.json').read_text())[0];m=json.loads(Path(e['model_path']).read_text());results=[]
for label,ylo,yhi in [('base',.001,.158),('shade',.1475,.2804)]:
 g=next(x for x in m['meshes']if'own-'+label+'-ONE-'in x['name']);points=np.asarray(g['positions'],dtype=np.float32).reshape(-1,3);faces=np.asarray(g['indices']).reshape(-1,3);start=(ylo+.0015 if label=='base'else .1555);end=yhi-.0015;pitch=(.0049 if label=='base'else .0045);turns=(end-start)/pitch;n=int(math.ceil(turns*280))+1;centres=points[:n*16].reshape(n,16,3).mean(1);a=np.linspace(0,2*math.pi*turns,n)
 rows=[]
 for k in range(2,int(turns)-2):
  ys=np.interp([2*math.pi*k,2*math.pi*k+math.pi,2*math.pi*(k+1)],a,centres[:,1]);rows.append(dict(turn=k,measured_half_turn_delta_mm=float((ys[1]-ys[0])*1000),measured_full_turn_delta_mm=float((ys[2]-ys[0])*1000)))
 _,weld=np.unique(points,axis=0,return_inverse=True);wf=weld[faces];edges=np.concatenate([wf[:,[0,1]],wf[:,[1,2]],wf[:,[2,0]]]);parent=np.arange(weld.max()+1)
 for iteration in range(64):
  for _ in range(32):
   jump=parent[parent]
   if np.array_equal(jump,parent):break
   parent=jump
  aa=parent[edges[:,0]];bb=parent[edges[:,1]];before=parent.copy();np.minimum.at(parent,np.maximum(aa,bb),np.minimum(aa,bb))
  if np.array_equal(before,parent):break
 for _ in range(32):
  jump=parent[parent]
  if np.array_equal(jump,parent):break
  parent=jump
 components=len(np.unique(parent));assert components==1,(label,components)
 half=np.array([r['measured_half_turn_delta_mm']for r in rows]);full=np.array([r['measured_full_turn_delta_mm']for r in rows]);herror=float(np.max(np.abs(half-pitch*500)));ferror=float(np.max(np.abs(full-pitch*1000)));assert herror<.05 and ferror<.05,(label,herror,ferror)
 results.append(dict(component=label,actual_mesh=g['name'],single_connected_closed_solid_after_exact_F32_weld=True,centreline_sample_count=n,measured_ring_centre_results=rows,max_half_turn_error_mm=herror,max_full_turn_error_mm=ferror,sampling_tolerance_mm=.05,nominal_pitch_mm=pitch*1000,nominal_half_pitch_mm=pitch*500,not_separate_closed_rings=True));print(label,'single actual component; pitch errors',herror,ferror,flush=True)
p=B/'actual-helical-continuity-and-half-pitch-proof.json';p.write_text(json.dumps(dict(glb_path=e['glb_path'],glb_sha256=e['sha256'],components=results),indent=2)+'\n');print('PASS',hashlib.sha256(p.read_bytes()).hexdigest(),flush=True)
