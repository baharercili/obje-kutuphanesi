from pathlib import Path
import json,hashlib,subprocess,os
from PIL import Image,ImageDraw
R=Path(__file__).resolve().parent;D=R/'review-candidate-r04';h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
e=json.loads((D/'manifest.json').read_text())[0];out=Path(e['asset_dir']);assert json.loads((D/'independent-native-glb-byte-audit.json').read_text())['valid'];assert h(e['glb_path'])==e['sha256'];assert not list(D.glob('frozen*manifest*.json'))
S=R/'qa/flat-surface-calibrated-study';study=json.loads((S/'manifest.json').read_text())[0]
if not(out/'textures').exists():subprocess.run(['cp','-cR',str(Path(study['asset_dir'])/'textures'),str(out/'textures')],check=True)
v=next(out.glob('*.validation.json'));report=json.loads(v.read_text().replace(str(S),str(D)));report.update(source=e['model_path'],metadata=json.loads(Path(e['model_path']).read_text())['metadata'],source_sha256=h(e['model_path']),glb_bytes=e['bytes'],delivery_format='GLB plus source model/material/QA; OBJ/MTL intentionally not duplicated');report['files']={k:report['files'][k]for k in['glb','validation']};report['deliverable_sha256']={'glb':e['sha256']};dump(v,report)
p=D/'prior-r03-preservation-receipt.json';x=json.loads(p.read_text());x['frozen_manifest_path']=str(Path(x['frozen_manifest_path']).resolve());dump(p,x)
p=D/'actual-helical-continuity-and-half-pitch-proof.json';x=json.loads(p.read_text())
for a in x['components']:a['measured_helix_turn_centres']=a.pop('measured_ring_centre_results')
dump(p,x)
ns=json.loads((D/'native-scene-qa/manifest.json').read_text());records=[]
for scene in ns:
 imgs=[]
 for name in['on','on-capraz','yan','arka','ustten']:
  p=Path(scene['asset_dir'])/(name+'.png');assert p.exists();im=Image.open(p);assert im.size==(1000,1000);imgs.append(dict(view=name,path=str(p),sha256=h(p),pixels=list(im.size)))
 records.append(dict(scene_index=scene['scene_index'],scene_name=scene['scene_name'],source_glb_sha256=e['sha256'],renders=imgs))
# A plain own-source contact preserves master pixels; it is a diagnostic sheet,
# not an albedo edit or a claim that source similarity has passed.
q=D/'qa';q.mkdir(exist_ok=True);panel=Image.new('RGB',(1880,1040),(248,248,248));draw=ImageDraw.Draw(panel);src=Image.open(e['original_image']).convert('RGB').crop([337,275,1197,1833]);src.thumbnail((450,880),Image.Resampling.LANCZOS);panel.paste(src,((470-src.width)//2,80));draw.text((15,15),'Own source | R04 REVIEW ONLY - native source similarity not accepted',fill='black')
for i,rec in enumerate(records[0]['renders']):
 im=Image.open(rec['path']).convert('RGBA');bb=im.getchannel('A').getbbox();im=im.crop(bb);back=Image.new('RGBA',im.size,(248,248,248,255));back.alpha_composite(im);im=back.convert('RGB');im.thumbnail((430,430),Image.Resampling.LANCZOS);x=490+(i%3)*455;y=60+(i//3)*480;panel.paste(im,(x+(430-im.width)//2,y));draw.text((x,y+435),rec['view'],fill='black')
contact=q/'own-source-native-five-review-only.jpg';panel.save(contact,quality=94)
proof=dict(review_only=True,visual_approval=False,ready_model_variants=0,known_native_shortfall=e['review_only_known_native_shortfall'],glb_path=e['glb_path'],glb_sha256=e['sha256'],native_manifest=str(D/'native-scene-qa/manifest.json'),scenes=records,source_contact=str(contact),source_contact_sha256=h(contact),world_origin_proof=str(D/'per-scene-world-origin-proof.json'),note='Scene native preparation uses unchanged local arrays; common per-scene GLB node translations are invariant under bbox-fitted camera and lights. Actual WebGL remains final gate.')
dump(D/'native-five-scenes-review-only-proof.json',proof)
e.update(native_qa_manifest=str(D/'native-scene-qa/manifest.json'),native_review_proof=str(D/'native-five-scenes-review-only-proof.json'),source_native_contact=str(contact),independent_glb_audit=str(D/'independent-native-glb-byte-audit.json'),study_preservation_proof=str(D/'study-to-review-preservation-proof.json'),helix_proof=str(D/'actual-helical-continuity-and-half-pitch-proof.json'),prior_frozen_preservation_proof=str(D/'prior-r03-preservation-receipt.json'))
dump(out/'entry.json',e);dump(D/'manifest.json',[e]);F=R/'frozen-own-rattan-1206693001-r04-review-only-manifest.json';dump(F,[e]);dump(D/F.name,[e]);files=[]
for p in[D/'manifest.json',F,D/F.name,Path(e['glb_path']),Path(e['model_path']),D/'independent-native-glb-byte-audit.json',D/'study-to-review-preservation-proof.json',D/'native-five-scenes-review-only-proof.json',D/'actual-helical-continuity-and-half-pitch-proof.json',D/'per-scene-world-origin-proof.json',D/'prior-r03-preservation-receipt.json',out/'material-validation.json',out/'geometry-validation.json',v]:files.append(dict(path=str(p),sha256=h(p),bytes=p.stat().st_size));p.chmod(0o444)
for p in out.glob('*.png'):p.chmod(0o444)
receipt=dict(scope_skus=['1206693001'],status='frozen_review_only_pending_root_actual',accepted=False,ready_variants=0,manifest=str(F),manifest_sha256=h(F),glb_sha256=e['sha256'],files=files,original_count=3,all_originals_fresh_verified=True,study_unchanged=True,source_complete=False,canonical_edits=False,materials_or_physical_pigment_changed_after_study=False)
dump(R/'frozen-own-rattan-1206693001-r04-review-only-receipt.json',receipt);dump(R/'root-review-inputs.json',[dict(manifest=str(F),sha256=h(F),sku='1206693001',review_only=True,accepted=False)]);dump(R/'ACTIVE_REVIEW_ONLY.json',receipt);print(json.dumps(dict(manifest=str(F),manifest_sha256=h(F),glb_sha256=e['sha256'],receipt_sha256=h(R/'frozen-own-rattan-1206693001-r04-review-only-receipt.json'),native_images=10,bytes=e['bytes']),indent=2),flush=True)
