"""Only exactSKU1206693001; own photo-led coarse paired-carrier rattan."""
from pathlib import Path
import sys,json,math,copy,ast
import numpy as np
from PIL import Image,ImageFilter
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent;P=ROOT.parent;S=P/'lighting-rattan-petal-chandelier-six-models'
sys.path.insert(0,str(P/'lighting-models'));import build_lighting as L
sys.path.insert(0,str(S));import geometry_own_six as O
R=ROOT/'candidate-r04';R.mkdir(exist_ok=True);assert not list(R.glob('frozen*manifest*.json'))
SKU='1206693001';T=math.tau;REG=json.loads((ROOT/'original-image-masters.json').read_text());Q=next(q for q in json.loads((S/'source-records.json').read_text())if q['sku']==SKU)
Q['name_tr']='Örgülü rattan masa lambası';Q['official_measurements']=dict(base_diameter_cm=11.6,shade_diameter_cm=15.3,total_height_cm=28.1,plastic_cord_length_cm=160)
L.R=R;L.sources=lambda:{SKU:Q};L.dump(R/'original-image-masters.json',REG)
for path,names in[(P/'lighting-textile-hex-nine-013/build_first_three.py',['gauss','mirror'])]:
 tree=ast.parse(path.read_text());exec(compile(ast.Module(body=[x for x in tree.body if isinstance(x,ast.FunctionDef)and x.name in names],type_ignores=[]),'readonly-own-source-native-math','exec'),globals())

def sweep(name,mat,p,rn,width,thick,closed=False):
 g=O.cane_sweep(name,mat,p,rn,width,thick,closed,ns=8)
 # Native grain direction follows the actual cane length, with its measured
 # short cross-section rather than a photograph wrapped around the lamp.
 perimeter=math.pi*math.sqrt((float(np.asarray(width).mean())**2+thick**2)/2)
 g['_uvs']=[(u*.035/.020,v*perimeter/.0019)for u,v in g['_uvs']];return g

def component(label,knots,ylo,yhi):
 pitch=.00490;ng=15;off=.00044;start_y=ylo+.0015;end_y=yhi-.0015;a0=math.pi/2;turns=(end_y-start_y)/pitch;N=int(math.ceil(turns*280))+1;aa=np.linspace(a0,a0+T*turns,N);yy0=start_y+pitch*(aa-a0)/T
 def hem(y,a):return y+.010*(.5-.5*np.cos(10*(a-a0)))*np.exp(-((y-ylo)/.020)**2)if label=='shade'else y
 def slope(y):
  eps=.000025;return(O.radius_interp(knots,y+eps)-O.radius_interp(knots,y-eps))/(2*eps)
 radius=O.radius_interp(knots,yy0);rr=radius+off*np.cos(ng/2*(aa-a0));yy=hem(yy0,aa);pts=np.c_[rr*np.cos(aa),yy,rr*np.sin(aa)];rn=np.c_[np.cos(aa),-slope(yy0),np.sin(aa)];rn/=np.linalg.norm(rn,axis=1,keepdims=True);width=.003*(1+.035*np.sin((aa-a0)/13+.3))
 # One capped continuous centreline, never a stack of closed horizontal rings.
 weft=sweep('own-'+label+'-ONE-true-continuous-4p9mm-helical-broad-weft','cane2',pts,rn,width,.00086,False)
 groups=[[]for _ in range(5)];rng=np.random.default_rng(120669+(1 if label=='shade'else 0));ys=np.linspace(ylo+.0015,yhi-.0015,190);radius=O.radius_interp(knots,ys)
 for j in range(ng):
  ac=a0+T*j/ng;separation=.00140
  for member in[-1,1]:
   a=ac+member*separation/2/np.maximum(radius,.010)
   # Odd 15 paired stakes let a single continuous strand alternate over/under
   # each revolution; the hidden-back count is an explicit photo interpretation.
   phase=math.pi*((ys-start_y)/pitch-(a-a0)/T)+math.pi*j;rr=radius-off*np.cos(phase);yy=hem(ys,a);pp=np.c_[rr*np.cos(a),yy,rr*np.sin(a)];rad=np.c_[np.cos(a),-slope(ys),np.sin(a)];rad/=np.linalg.norm(rad,axis=1,keepdims=True);w=np.minimum(.00080,.00080*np.maximum(.28,radius/.020));col=int(rng.choice(5,p=[.08,.18,.32,.27,.15]));groups[col].append(sweep(label+'-paired-carrier-'+str(j)+'-'+str(member),'cane'+str(col),pp,rad,w,.00066))
 return[weft]+[O.merge(gs,'own-'+label+'-15-paired-carriers-'+str(i),'cane'+str(i))for i,gs in enumerate(groups)if gs]

def wrapped_rim(label,r,y,wave,turns):
 N=turns*10;aa=np.linspace(0,T,N,endpoint=False);centre=np.c_[r*np.cos(aa),y+wave*(.5-.5*np.cos(10*(aa-math.pi/2))),r*np.sin(aa)];t=np.gradient(centre,axis=0);t/=np.linalg.norm(t,axis=1,keepdims=True);rad=np.c_[np.cos(aa),np.zeros(N),np.sin(aa)];vertical=np.cross(t,rad);vertical/=np.linalg.norm(vertical,axis=1,keepdims=True);phase=aa*turns;helix=centre+.00140*(np.cos(phase)[:,None]*rad+np.sin(phase)[:,None]*vertical)
 return[L.tube('own-'+label+'-continuous-soft-core','cane2',centre[::10],.00125,10,True),L.tube('own-'+label+'-individual-continuous-bound-cane-wrap','cane3',helix,.00031,6,True)]

def build(q):
 base=[(.049,.001),(.055,.006),(.0572,.018),(.0572,.09),(.054,.122),(.046,.145),(.034,.158)];shade=[(.0750,.1475),(.0751,.1590),(.069,.2005),(.057,.2360),(.039,.2624),(.015,.2775),(.004,.2804)]
 parts=component('base',base,.001,.158)+component('shade',shade,.1475,.2804);parts+=wrapped_rim('shade-ten-scallop',.0750,.1475,.010,580)+wrapped_rim('base-bottom',.0563,.0022,0,430)
 parts.append(L.lathe('own-small-woven-crown-finish','cane2',[(0,.279),(.0045,.279),(.0045,.281),(0,.281)],64))
 for j,a in enumerate(np.linspace(0,T,3,endpoint=False)):parts.append(L.tube('interpreted-hidden-iron-shade-support-'+str(j),'metal',[(.005,.176,0),(.03*math.cos(a),.176,.03*math.sin(a)),(.073*math.cos(a),.151,.073*math.sin(a))],.00085,8))
 parts+=O.g4(.162)
 # Exact official component envelopes; all internal section/pitch remains a
 # bounded own-photo interpretation, never an invented manufacturer number.
 for prefix,target in [('own-base',.116),('own-shade',.153)]:
  gs=[g for g in parts if g['name'].startswith(prefix)];p=np.concatenate([np.asarray(g['_vertices'])for g in gs]);fac=target/np.ptp(p[:,[0,2]],axis=0)
  for g in gs:g['_vertices']=[(x*fac[0],y,z*fac[1])for x,y,z in g['_vertices']]
 core=np.concatenate([np.asarray(g['_vertices'])for g in parts]);lo=float(core[:,1].min())
 for g in parts:
  crown='crown-finish'in g['name'];g['_vertices']=[(x,y-lo+(lo*np.clip((y-.279)/.002,0,1)if crown else 0),z)for x,y,z in g['_vertices']]
 # The original exact own electrical hardware/cord recipe is reused read-only.
 cp,le=O.table_cord()
 for g in cp:g['name']='optional-stored-cord-'+g['name']
 parts+=cp
 note='Resmî toplam yükseklik 28,1 cm, kaide çapı 11,6 cm, başlık çapı 15,3 cm ve plastik kablo uzunluğu 160 cm korunur. Tek G4 duy, azami 2 W LED; ampul dahil değildir. Her bölümde tek helisel yatay kamışın nominal 4,9 mm tur adımı, yaklaşık 3 mm genişliği ve 15 çift dik taşıyıcı grubu kendi fotoğrafından yorumlanmıştır; görünmeyen arka örgü adedi kesin sayım değildir. Yerel kamış kalınlıkları, yaklaşık 10 mm dalgalı ve sarımlı kenar, başlık profili ve ayak bölümünün yüksekliği fotoğraf tahminidir. Üstte rattan %70 / demir %30, altta rattan %100 olan resmî bileşim korunur. Saman rengi yalnız bu ürünün aydınlık kamış merkezlerinden, lif dokusu kendi yakın planından alınır. Ön ve arka örgü yarım turda nominal 2,45 mm yükselir; araları sahte bir astarla kapatılmamıştır. Başlık toplam yüksekliğin yaklaşık %48’i olarak kendi fotoğrafından yorumlanmıştır. Örgü araları gerçek açıklıklardır; iki G4 pin yuvası boş bırakılmıştır. Kablo ayrı isteğe bağlı sahnede, tam 160 cm uzunluğunda tahmini sarılı pozdadır. Armatür zarfı 15,3 × 28,1 × 15,3 cm; tüm sahnelerin ortak kutusu sarılı kabloyu da içerir. Üretici CAD dosyası değildir.'
 mods={**{'cane'+str(i):('plastic',[214,190,151],.73,0)for i in range(5)},'metal':('metal',[171,169,155],.34,1),'paint':('plastic',[233,231,222],.45,0),'socket':('plastic',[225,223,212],.56,0),'contact':('metal',[169,156,121],.28,1),'cable':('plastic',[232,231,223],.70,0)}
 return parts,dict(target_cm=None,id_suffix='-own-rattan-r04',official_axes=list(q['official_measurements']),estimated=['paired_carrier_group_count_15_unseen_rear_interpreted','weft_pitch_4p9mm_true_front_bands_from_own_photo','weft_width_3mm_and_radial_0p86mm','lower_scallop_depth_10mm_and_profile','head_height_48percent_source_ratio','single_helix_front_back_half_pitch_geometry','upper_component_and_visible_base_height','bound_rim_wrap_pitch_and_thickness','hidden_shade_frame_and_socket_placement','native_cane_pigment_and_optics','stored_cord_pose'],features=['Own coarse horizontal rounded-flat cane with15paired carrier groups and true over/under gaps','Own taller softly tapered head with pronounced10scallop bound rim; no solid lining','Official28.1cm height/11.6cm base/15.3cm head, separate empty G4and exact160cmcord'],material_overrides=mods,official_socket_type='G4',official_socket_count=1,official_source_max_led_w=2,bulbs_included=False,measured_cord_length_m=le,source_component_dimension_facts=q['official_dimension_facts'],verified_model_core_dimensions_cm=dict(x=15.3,y=28.1,z=15.3),scale_note_override=note,scene_variants=[dict(index=0,label='Armatür'),dict(index=1,label='Kablo ile')],default_scene_index=0)

bank0=L.material_bank
def bank(pid,keys,ims,out,overrides=None):
 mats,maps=bank0(pid,keys,ims,out,overrides);src=next(x for x in ims if'f1e1c626ae0a'in x['path']);patch=Image.open(src['path']).convert('RGB').crop([450,200,706,224]);raw=np.asarray(patch,float);lum=raw.mean(2);ratio=lum/np.maximum(gauss(lum,4),1);sample_proof=json.loads((ROOT/'own-straw-pigment-samples.json').read_text());palette=np.array([x['mean_srgb']for x in sample_proof['native_sample_boxes']]);ratio_rgb=raw/np.maximum(gauss(lum,4),1)[:,:,None];ratio_rgb/=ratio_rgb.mean((0,1));records=[]
 for i in range(5):
  key='cane'+str(i)
  if key not in mats:continue
  col=palette[i];rgb=mirror(ratio_rgb*col[None,None,:]);height=mirror((ratio-1)*.000018);dy=(np.roll(height,-1,0)-np.roll(height,1,0))/(2*.0019/height.shape[0]);dx=(np.roll(height,-1,1)-np.roll(height,1,1))/(2*.020/height.shape[1]);nn=np.stack([-dx,-dy,np.ones_like(dx)],2);nn/=np.linalg.norm(nn,axis=2,keepdims=True);orm=np.zeros_like(rgb,np.uint8);orm[:,:,0]=255;orm[:,:,1]=np.rint(mirror(np.clip(.73-(ratio-1)*.18,.62,.86))*255)
  for slot,a in [('albedo',np.uint8(np.clip(rgb,0,255))),('normal',np.uint8(np.rint((nn+1)*127.5))),('orm',orm)]:
   p=out/(key+'-'+slot+'.png');Image.fromarray(a).save(p,optimize=True)
   for rec in maps:
    if rec['material']==key and rec['slot']==slot:rec.update(sha256=L.sha(p),native_resolution=[512,48])
  mats[key]['normalScale']=.55;mats[key]['extras'].update(photo_pixels_baked=True,source_native_material_crop=True,native_resolution=[512,48],native_donor_resolution=[256,24],physical_repeat_m_estimated=[.020,.0019],natural_rattan_not_fabric=True,no_generated_or_upscaled_detail=True)
  records.append(dict(material=key,own_master=src['path'],master_sha256=src['sha256'],native_crop_box=[450,200,706,224],native_crop_pixels=[256,24],output_native_repeated_pixels=[512,48],geometric_resampling_count=0,pigment_own_primary_strand_centre_patch=sample_proof['native_sample_boxes'][i],pigment_srgb=col.tolist(),no_chroma_desaturation=True,no_per_channel_illuminant_white_balance=True,illumination_removed='Own single-cane native luminance ratio sigma4; no between-cane gaps or studio shadow in map',physical_repeat_estimated_m=[.020,.0019],no_cross_SKU_pixels=True,no_AI_or_upscale=True))
 patch.save(out/'own-single-cane-native-donor.png');L.dump(out/'own-native-material-provenance.json',records);return mats,maps
L.BUILD={SKU:build};L.material_bank=bank
if __name__=='__main__':
 L.build(SKU);e=json.loads((R/'manifest.json').read_text())[0];doc,bb=L.read_glb(e['glb_path']);nodes=copy.deepcopy(doc['nodes']);N=len(nodes);body=[i for i,n in enumerate(nodes)if not n.get('name','').startswith('optional-stored-cord-')];doc['nodes']+=copy.deepcopy(nodes);doc['scenes']=[dict(name='Armatür',nodes=body),dict(name='Kablo ile',nodes=list(range(N,2*N)))];doc['scene']=0;model=json.loads(Path(e['model_path']).read_text());origins=[]
 for si,scene in enumerate(doc['scenes']):
  pp=np.concatenate([np.asarray(model['meshes'][doc['nodes'][ni]['mesh']]['positions']).reshape(-1,3)for ni in scene['nodes']]);lo,hi=pp.min(0),pp.max(0);delta=np.array([-(lo[0]+hi[0])/2,-lo[1],-(lo[2]+hi[2])/2]);delta[np.abs(delta)<1e-9]=0
  for ni in scene['nodes']:doc['nodes'][ni]['translation']=delta.tolist()
  origins.append(dict(scene_index=si,common_node_translation_m=delta.tolist(),world_bbox_min_m=(lo+delta).tolist(),world_bbox_max_m=(hi+delta).tolist(),dimensions_cm=((hi-lo)*100).tolist(),bottom_zero=True,XZcentre_zero=True))
 L.write_glb(e['glb_path'],doc,bb);L.dump(R/'per-scene-world-origin-proof.json',dict(glb_sha256=L.sha(e['glb_path']),scenes=origins));e.update(sha256=L.sha(e['glb_path']),bytes=Path(e['glb_path']).stat().st_size,model_revision='own-source-continuous-helix-rattan-r04',scene_nodes_disjoint=True,quality_label='Fotoğraftan yorumlanan rattan örgü',source_complete=False);L.dump(Path(e['asset_dir'])/'entry.json',e);L.dump(R/'manifest.json',[e]);print('READY_R03',e['sha256'],e['bytes'])
