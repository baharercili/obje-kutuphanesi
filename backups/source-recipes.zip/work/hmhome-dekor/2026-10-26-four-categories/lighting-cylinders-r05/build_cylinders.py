"""Eleven exact-source fixture drums: own weave and documented upper uncertainty."""
from pathlib import Path
import sys,json,math,shutil,hashlib
import numpy as np
from PIL import Image,ImageFilter
P=Path(__file__).resolve().parent.parent;sys.path.insert(0,str(P/'lighting-models'))
import build_lighting as L
R=Path('/private/tmp/hm-lighting-20261028/cylinders-r05');R.mkdir(parents=True,exist_ok=True)
S=Path('/private/tmp/hm-lighting-20261028/cylinder-source-review')
SPEC={
 '1223812001':dict(code='0fe7cfe7c1bb',box=[900,700,1412,1212],tile=[.035,.035],rgb=[228,222,208]),
 '1223812006':dict(code='5ca43f8e0627',box=[1110,900,1366,1156],tile=[.094,.094],rgb=[124,123,81]),
 '1223812009':dict(code='ede881855e05',box=[900,700,1412,1212],tile=[.028,.040],rgb=[149,163,175]),
 '1223812008':dict(code='269a0d08cf55',box=[900,700,1412,1212],tile=[.032,.038],rgb=[177,136,92]),
 '1223602001':dict(code='dbebdcae0f12',box=[900,700,1412,1212],tile=[.035,.035],rgb=[228,222,208]),
 '1223602009':dict(code='441ba0e56d5e',box=[700,700,1212,1212],tile=[.0204,.0375],rgb=[149,163,175]),
 '1223602008':dict(code='90a0112fc9da',box=[900,700,1412,1212],tile=[.032,.038],rgb=[177,136,92]),
 '1223813001':dict(code='525251ce777f',box=[900,700,1412,1212],tile=[.035,.035],rgb=[228,222,208]),
 '1223813006':dict(code='afe9e4d23deb',box=[900,700,1412,1212],tile=[.032,.038],rgb=[177,136,92]),
 '1223603001':dict(code='184a828fbe81',box=[900,700,1412,1212],tile=[.035,.035],rgb=[228,222,208]),
 '1223603006':dict(code='65cb4fc96bff',box=[470,1200,982,1712],tile=[.137,.137],rgb=[177,136,92]),
}
registry=[]
for x in json.loads((P/'lighting-models/original-image-masters.json').read_text()):
 if x['sku']not in SPEC:continue
 parent=Path('/private/tmp/hm-lighting-20261027/blue-r04/originals')if x['sku']=='1223602009'else S/'originals';path=parent/Path(x['path']).name
 if path.exists():
  assert L.sha(path)==x['sha256'];registry.append(dict(x,archival_path=x['path'],path=str(path)))
L.R=R;L.dump(R/'original-image-masters.json',registry)
base_bank=L.material_bank;BUILD0=dict(L.BUILD)

def holder(kind,y):
 outer,inner,r,h,pitch,turns=(.0175,.0145,.0141,.033,.0036,4.6)if kind=='E27'else(.0115,.0078,.00745,.024,.0028,4.2)
 cup=L.B.lathe('separate-'+kind+'-empty-insulating-cup','socket',[(0,y),(outer-.001,y),(outer,y+.001),(outer,y+h-.001),(outer-.001,y+h),(inner,y+h),(inner,y+.005),(0,y+.005)],128,False)
 a=np.linspace(0,math.tau*turns,360);thread=L.tube('separate-'+kind+'-estimated-helical-metal-thread','steel',[(r*math.cos(v),y+.008+pitch*v/math.tau,r*math.sin(v))for v in a],.0005 if kind=='E27'else .0004,10)
 return [cup,thread]

def model(q):
 parts,info=BUILD0[q['sku']](q);large=q['sku'][:7]in['1223813','1223603'];kind='E27'if large else'E14';watts=15 if large else 6
 oldholder=next(p for p in parts if p['name']=='separate-E27-socket-insulating-body');hy=min(v[1]for v in oldholder['_vertices'])
 parts=[p for p in parts if 'E27'not in p['name']];parts+=holder(kind,hy)
 tw,th=np.array(SPEC[q['sku']]['tile'])*2
 for g in parts:
  if g['material']=='textile':g['_uvs']=[((math.atan2(z,x)/math.tau+.5)*math.tau*math.hypot(x,z)/tw,y/th)for x,y,z in g['_vertices']]
 info['features']=[s.replace('emptyE27socket','empty '+kind+' socket')for s in info['features']]
 info['features']+=['Own exact-SKU weave at native source pixels, local illumination removed; physical repeat scale and optical parameters are photo estimates','Upper aperture retained as an explicitly uncertain photo interpretation: available low-angle views cannot distinguish a closed diffuser from the far inner lining']
 info['estimated']+=['upper_aperture_unverified_from_low_angle_own_photos','native_crop_physical_repeat_scale','weave_microheight_and_optical_parameters','socket_nominal_thread_geometry']
 info.update(id_suffix='-own-weave-r05',source_revision='own-source-weave-and-hardware-r05',official_socket_type=kind,official_socket_count=1,official_source_max_led_w=watts,bulbs_included=False,source_top_closure_verified=False,source_top_interpretation='Open upper aperture with white inner lining; unresolved from low-angle own photos',quality_label='Üst yüzey yorumu doğrulanmadı',quality_note='Kendi kaynak fotoğrafları beyaz iç astarı gösterir; üst açıklık ile kapalı difüzörü kesin ayırt etmez. Üst düzen fotoğraftan yorumlanmıştır.',source_top_evidence=str(R/'upper-surface-evidence.json'))
 info['scale_note_override']='Resmî yükseklik ve çap bu ürünün kendi kaynağından korunmuştur. Kumaş örgüsü aynı ürünün özgün fotoğrafından, doğal piksel çözünürlüğü korunarak alınmıştır. Işık değişimleri giderilmiştir. Üst kenar ve beyaz iç astar fotoğrafta görünür; düşük bakış açısı üst açıklık ile kapalı difüzörü kesin ayırt etmediğinden modeldeki üst açıklık yorumdur. Kumaş iplik ölçeği, kalınlıklar, iç taşıyıcı, nominal vida geometrisi ve kablonun sarılı duruşu tahmindir. Resmî duy '+kind+', azami '+str(watts)+' W LED; ampul dahil değildir. Üretici CAD dosyası değildir.'
 return parts,info

def bank(pid,keys,ims,out,overrides=None):
 mats,maps=base_bank(pid,keys,ims,out,overrides);s=SPEC[pid];src=next(x for x in ims if s['code']in x['path']);master=Image.open(src['path']).convert('RGB');patch=master.crop(s['box']);raw=np.array(patch,dtype=float);n=patch.width;assert patch.height==n
 blur=np.array(patch.filter(ImageFilter.GaussianBlur(8)),dtype=float);ratio=raw/np.maximum(blur,1);rgb=np.array(s['rgb']);albedo=np.clip((1+.82*(ratio-1))*rgb,0,255)
 rowmean=albedo.mean(1);k=np.arange(-32,33);g=np.exp(-.5*(k/10)**2);g/=g.sum();smooth=np.stack([np.convolve(np.pad(rowmean[:,c],(32,32),mode='reflect'),g,'valid')for c in range(3)],1);albedo*=rgb[None,None,:]/np.maximum(smooth[:,None,:],1)
 height=(raw.mean(2)/np.maximum(blur.mean(2),1)-1)*.000060
 rough=np.clip(.90-(ratio.mean(2)-1)*.07,.82,.97);orm=np.zeros((n,n,3),np.uint8);orm[:,:,0]=255;orm[:,:,1]=np.rint(rough*255)
 def mirror(a):return np.concatenate([np.concatenate([a,a[:,::-1]],1),np.concatenate([a[::-1],a[::-1,::-1]],1)],0)
 albedo=mirror(albedo);height=mirror(height);orm=mirror(orm);dy=(np.roll(height,-1,0)-np.roll(height,1,0))/(2*s['tile'][1]/n);dx=(np.roll(height,-1,1)-np.roll(height,1,1))/(2*s['tile'][0]/n);norm=np.stack([-dx,-dy,np.ones_like(dx)],2);norm/=np.linalg.norm(norm,axis=2,keepdims=True)
 for slot,a in [('albedo',np.clip(albedo,0,255).astype('uint8')),('normal',np.rint((norm+1)*127.5).astype('uint8')),('orm',orm)]:
  path=out/('textile-'+slot+'.png');Image.fromarray(a).save(path,optimize=True)
  for rec in maps:
   if rec['material']=='textile'and rec['slot']==slot:rec.update(sha256=L.sha(path),native_resolution=[2*n,2*n])
 patch.save(out/'source-fabric-native-crop.png');assert np.array_equal(np.array(patch),np.array(master)[s['box'][1]:s['box'][3],s['box'][0]:s['box'][2]])
 mats['textile']['normalScale']=.45;mats['textile']['extras'].update(photo_pixels_baked=True,native_resolution=[2*n,2*n],source_weave_native=True,material_crop_physical_repeat_m=(np.array(s['tile'])*2).tolist(),microheight_m_estimated=.000060)
 L.dump(out/'native-crop-provenance.json',dict(master=src['path'],archival_master=src.get('archival_path'),master_sha256=src['sha256'],native_crop_box=s['box'],native_crop_pixels=[n,n],output_pixels=[2*n,2*n],lossless_mirrored_tiling=True,geometric_resampling_count=0,native_crop_pixel_equality=True,no_background_or_product_edge=True,own_SKU_only=True,low_frequency_illumination_removed='sigma8 local ratio + smooth row-drift correction',physical_repeat_m_estimated=s['tile'],normal_from_periodic_mirrored_height=True,colour_and_optical_parameters_estimated=True,no_generated_pixels=True))
 return mats,maps

L.BUILD={sku:model for sku in SPEC};L.material_bank=bank
if __name__=='__main__':
 for sku in sys.argv[1:]or SPEC:L.build(sku)
