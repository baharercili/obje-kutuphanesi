"""Withdraw one unpublished new model after a clearer source photo was found.
The GLB and all frozen evidence stay intact; no baseline master can be removed.
"""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
P=Path(__file__).resolve().parent;SITE=P.parents[2]/'sites/zarahome-vazo-kutuphanesi-final-378'
read=lambda f:json.loads(f.read_text())
write=lambda f,d:Path(f).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
mid='hm-1311994002-h26p7-w24-d18p3569'
baseline=read(P/'baseline-2182/model-manifest.json')
assert mid not in {e['id']for e in baseline['models']}
manifest=read(SITE/'model-manifest.json');catalog=read(SITE/'ui/hmhome-catalog.json');preview=read(SITE/'ui/hmhome-preview.json');sources=read(SITE/'ui/hmhome-discovered.json');approvals=read(P/'browser-approvals.json')
old=next(e for e in manifest['models']if e['id']==mid)
expected=next(e for e in read(P/'lighting-root-approved-hex-yellow-r03.json')if e['id']==mid)['sha256']
assert old['sha256']==expected
photo=P/'lighting-textile-followup-r04/qa/hex-top-source-native.png'
archive=dict(id=mid,withdrawn_at=datetime.now(timezone.utc).isoformat(),reason='Exact source close-up shows a textile-covered closed upper surface; candidate incorrectly modeled a large top opening.',source_photo=str(photo),source_photo_sha256=hashlib.sha256(photo.read_bytes()).hexdigest(),master=old,catalog=next(e for e in catalog if e['id']==mid),preview=next(e for e in preview['models']if e['id']==mid),prior_browser_approval=approvals['models'][mid],old_glb_preserved=str(SITE/'model-source'/old['filename']),baseline_masters_unchanged=True)
folder=P/'quality-withdrawals';folder.mkdir(exist_ok=True);record=folder/(mid+'-'+old['sha256']+'.json');assert not record.exists();write(record,archive)
manifest['models']=[e for e in manifest['models']if e['id']!=mid];manifest.update(model_count=len(manifest['models']),total_bytes=sum(e['bytes']for e in manifest['models']))
catalog=[e for e in catalog if e['id']!=mid];preview['models']=[e for e in preview['models']if e['id']!=mid]
product=next(e for e in sources['products']if e['sku']=='1311994002')
product.update(model_status='pending_model',model_ids=[],ready_model_variants=0,model_url=None,status_note='Üst yüzey, ürünün yakın plan fotoğrafına göre yeniden modelleniyor. Bu sürüm henüz hazır değildir.')
product.pop('dimensions_cm',None)
approvals['models'][mid].update(approved=False,revoked_at=archive['withdrawn_at'],revocation_reason=archive['reason'],withdrawal_record=str(record))
for file,data in [(SITE/'model-manifest.json',manifest),(SITE/'ui/hmhome-catalog.json',catalog),(SITE/'ui/hmhome-preview.json',preview),(SITE/'ui/hmhome-discovered.json',sources),(P/'browser-approvals.json',approvals)]:write(file,data)
print(json.dumps(dict(withdrawn=mid,master_bytes_preserved=True,baseline_models_preserved=len(baseline['models']),active_models=len(manifest['models']),hm_variants=len(catalog))))
