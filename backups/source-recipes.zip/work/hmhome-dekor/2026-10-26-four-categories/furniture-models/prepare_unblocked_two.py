"""Resolve the two current photographed identities without changing old blocked snapshots."""
from pathlib import Path
import sys,json,re,hashlib,datetime,urllib.request,io,concurrent.futures
from PIL import Image
P=Path(__file__).resolve().parent;R=P.parent/'furniture-research';S=P/'source-unblocked-two-05'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
assert not S.exists()
f=R/'root-pdp-1337814001-accordion-v2.json';root=json.loads(f.read_text());assert'1337814001'in root['text'];gallery={}
for im in root['images']:
 u=im.get('src','')
 if u.startswith('https://image.hm.com/')and'.jpg'in u:gallery.setdefault(u,dict(url=u,alt=im['alt'],source_pdp_url=root['url'],URL_evidence_file=str(f)))
rawfile=P/'source-extras/unblocked-last-two-pdp-09.json';source=json.loads(rawfile.read_text());piece=next(x for x in source.split('--------------------------------------------------------------------------------')if'productpage.1337873001.html'in x);text='\n'.join(re.sub(r'^L\d+: ?','',l)for l in piece.splitlines()if re.match(r'^L\d+:',l));assert'Art.-Nr.: 1337873001'in text
alts={int(i):a for i,a in re.findall(r'【(\d+)†Image: ([^】]+)†image\.hm\.com】',piece)};cf=P/'source-extras/unblocked-travertine-galleryURLs-11.json';clicked=json.loads(cf.read_text());blocks=[x for x in clicked['raw'].split('--------------------------------------------------------------------------------')if'cite'in x];assert len(blocks)==len(clicked['requests']);trav=[]
for req,b in zip(clicked['requests'],blocks):
 u=re.search(r'https://image\.hm\.com/[^\s:]+\.jpg\?imwidth=\d+',b);assert u;trav.append(dict(url=u[0],alt=alts[req['id']],source_pdp_url='https://www2.hm.com/de_de/productpage.1337873001.html',URL_evidence_file=str(cf)))
tasks=[]
for sku,ims in[('1337814001',list(gallery.values())),('1337873001',trav)]:
 for im in ims:
  u=im['url'];tasks.append(dict(im,sku=sku,path=str(P/'originals-unblocked'/sku/(sku+'-'+hashlib.sha256(u.encode()).hexdigest()[:12]+'.jpg')),source_kind='exact_official_PDP_gallery'))
dump(P/'unblocked-two-photo-download-queue.json',tasks)
def get(t):
 path=Path(t['path']);path.parent.mkdir(parents=True,exist_ok=True)
 if not path.exists():
  with urllib.request.urlopen(t['url'],timeout=45)as response:b=response.read()
  Image.open(io.BytesIO(b)).verify();path.write_bytes(b)
 b=path.read_bytes();im=Image.open(io.BytesIO(b));profile=im.info.get('icc_profile',b'');return dict(t,sha256=sha(path),pixel_sha256=hashlib.sha256(im.tobytes()).hexdigest(),width=im.width,height=im.height,mode=im.mode,format=im.format,icc_profile_sha256=hashlib.sha256(profile).hexdigest()if profile else None,exif_orientation=im.getexif().get(274),bytes=len(b),immutable_master=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=3)as pool:masters=list(pool.map(get,tasks))
index=P/('unblocked-two-original-image-masters-'+str(len(masters))+'.json');assert not index.exists();dump(index,masters)
axis=lambda label,value,context:dict(axis_label=label,value_cm=value,scope_label=None,verbatim=context,source_context=context)
common=dict(identity_verified=True,current_stock_not_asserted_from_cache=True,color_description=[],official_unlabelled_dimension_strings=[],axes_pending=False,measurement_context_required=True,no_axis_or_dimension_inferred=True)
pdps=[dict(common,sku='1337814001',market='en_gb',url=root['url'],page_title=root['title'],source_kind='official_live_DOM',official_axis_labels=[axis('Height',40.5,'Height: 40.5 cm'),axis('Depth',50,'Depth: 50 cm'),axis('Width',80,'Width: 80 cm')],description_statements=[root['description_text']],material_statements=[root['materials_text']],gallery_images=list(gallery.values()),gallery_URL_scan_complete=len(gallery)==4,cache_observations=[dict(source_file=str(f),source_sha256=sha(f),captured_at=root['captured_at'])]),dict(common,sku='1337873001',market='de_de',url='https://www2.hm.com/de_de/productpage.1337873001.html',page_title='Wandregal aus Travertin - Beige/Silberfarben - Home All | H&M DE',source_kind='official_web_reader_cache',official_axis_labels=[axis('Tiefe',15,'Tiefe: 15 cm'),axis('Breite',35,'Breite: 35 cm'),dict(axis('Breite',12,'Rückseite: Breite: 12 cm'),scope_label='Rückseite')],description_statements=[re.search(r'Beschreibung\n\n(.*?)\nArt\.-Nr\.',text,re.S)[1]],material_statements=[re.search(r'### Zusammensetzung\n(.*?)(?=\n###)',text,re.S)[1]],gallery_images=trav,gallery_URL_scan_complete=True,cache_observations=[dict(source_file=str(rawfile),source_sha256=sha(rawfile),cache_age='3 days ago')])]
rows=[dict(sku=p['sku'],name=p['page_title'],brand='H&M HOME / live own-brand category',markets=[p['market']],pdp_evidence=[p],source_category_cards=[],identity_verified=True,official_measurement_available=True,material_available=True,original_photo_count=sum(r['sku']==p['sku']for r in masters),source_status='identity_measurement_material_gallery_available',old_blocked_snapshot_retained=True)for p in pdps]
S.mkdir();dump(S/'source-queue2.json',dict(source_scope_complete=False,products=rows));dump(S/'manifest.json',dict(created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_scope_complete=False,exactSKU_count=2,source_queue=str(S/'source-queue2.json'),source_queue_SHA=sha(S/'source-queue2.json'),source_master_index=str(index),source_master_index_SHA=sha(index),own_JPEG_count=len(masters),old_source117_and_blocked_records_unchanged=True,evidence_files=[dict(path=str(p),sha256=sha(p))for p in[f,rawfile,cf]]));hs=sha(S/'manifest.json')
for row in rows:dump(P/'source-evidence'/(row['sku']+'.json'),dict(source_handoff_manifest=str(S/'manifest.json'),source_handoff_sha256=hs,source_queue_file=str(S/'source-queue2.json'),source_master_index=str(index),source_record=row))
q=json.loads((P/'source-queue-163-current.json').read_text());dump(P/'source-queue-165-current.json',dict(source_scope_complete=False,model_scope_count=165,products=q['products']+rows,blocked_products_not_modeled=[r for r in q['blocked_products_not_modeled']if r['sku']=='1304431006'],immutable_source_snapshots=[q['original117_source_SHA'],q['extra46_source_SHA'],hs]));print('165 source queue; unblocked2 source SHA',hs,'new JPEGs',len(masters))
