"""Root-caught oval-plan and three material-only corrections; frozen v1 remains untouched."""
from pathlib import Path
import sys,json,shutil,math,copy
sys.dont_write_bytecode=True
import numpy as np
from PIL import Image,ImageFilter
import build_models as F
P=Path(__file__).resolve().parent;R=P/'revisions/root-four-corrections-v2';R.mkdir(parents=True,exist_ok=True)
SKUS=['1254575001','1206454001','1206454002','1337878001']
oldrows={e['sku']:e for n in['frozen-stone-metal-tables18-manifest.json','frozen-wood-wall-family01-manifest.json']for e in json.loads((P/n).read_text())}
grain={'1206454001':('wood',[75,52,34],.49),'1206454002':('wood',[151,91,44],.49),'1337878001':('wood',[153,111,75],.55)}
crop_specs={'1206454001':('b6a6122349e7',[650,2100,1034,2868],True),'1206454002':('ccfe42c1de0a',[865,1300,1217,2212],True),'1337878001':('6f280ebc7e4e',[400,900,1936,1284],False)}
def dump(p,x):F.dump(p,x)
def make(sku):
 old=oldrows[sku];src=Path(old['asset_dir']);out=R/'models'/old['id'];assert not(out/'frozen.json').exists();out.mkdir(parents=True,exist_ok=True)
 before={str(p):F.sha(p)for p in src.iterdir()if p.is_file()};model=json.loads(Path(old['model_path']).read_text());original_meshes=copy.deepcopy(model['meshes']);oldmat=json.loads(Path(old['material_validation']).read_text());geo=json.loads(Path(old['geometry_validation']).read_text())
 for p in src.glob('*.png'):
  if p.name not in['on.png','on-capraz.png','yan.png','arka.png','ustten.png']:shutil.copyfile(p,out/p.name)
 for p in src.glob('*-provenance.json'):shutil.copyfile(p,out/p.name)
 maps=[dict(x,path=str(out/Path(x['path']).name))for x in oldmat['maps']]
 masters=[x for x in json.loads((P/'original-image-masters.json').read_text())if x['sku']==sku]
 if sku=='1254575001':
  # Organic oval, as in its own uncropped front master; retain official51×42cm plan.
  a=np.linspace(0,math.tau,320,endpoint=False);r=1+.028*np.sin(3*a+.6);plan=np.c_[.255*np.cos(a)*r,.21*np.sin(a)*r];plan-=((plan.max(0)+plan.min(0))/2);plan*=np.array([.51,.42])/(plan.max(0)-plan.min(0))
  b=F.G.H.M.G.Builder();b.slab('own-organic-oval-marble-top','stone',plan,.421,.440,.0025);g=list(b.groups.values())[0];g['_vertices']=[(x,z,y)for x,y,z in g['_vertices']]
  # One native, full-component stone chart; natural vein phase remains interpretation.
  v=np.array(g['_vertices']);lo=v.min(0);span=np.maximum(v.max(0)-lo,1e-6);vv=[];ff=[];uv=[]
  for tri in g['_faces']:
   q=v[list(tri)];axis=int(np.argmax(np.abs(np.cross(q[1]-q[0],q[2]-q[0]))));axes=[k for k in range(3)if k!=axis];ii=[]
   for j in tri:ii.append(len(vv));vv.append(tuple(v[j]));u=(v[j]-lo)/span;uv.append((u[axes[0]],u[axes[1]]))
   ff.append(tuple(ii))
  g['_vertices']=vv;g['_faces']=ff;g['_uvs']=uv;g=F.G.H.orient(g);m,c=F._finalize(g);F.G.H.S.flatcap_normals(m);model['meshes'][0]=m;geo['meshes'][0]=c;geo['photographed_features'][0]='Root-caught v2: own clearly organic oval marble plan51×42cm replaces overly rectangular v1 top.'
  for x,y in zip(model['meshes'][1:],original_meshes[1:]):assert x==y
  reason='Kaynak tam fotoğrafındaki belirgin organik oval51×42cm tabla düzeltildi. İki U kesimli ahşap ayak ve bütün mevcut malzeme baytları korunur.'
 else:
  key='body'if sku=='1337878001'else'wood';suffix,box,rotate=crop_specs[sku];master=next(x for x in masters if suffix in x['path']);patch=Image.open(master['path']).convert('RGB').crop(box);raw=out/(key+'-native-donor.png');patch.save(raw)
  if rotate:patch=patch.transpose(Image.Transpose.ROTATE_90)
  rgb=np.asarray(patch).astype(float);hh,ww=rgb.shape[:2]
  # Remove only a fitted illumination plane; retain the photographed irregular vessels and growth figure.
  yy,xx=np.mgrid[:hh,:ww];A=np.c_[np.ones(hh*ww),xx.ravel()/ww,yy.ravel()/hh];plane=np.linalg.lstsq(A,rgb.mean(2).ravel(),rcond=None)[0];gradient=(A@plane).reshape(hh,ww);rgb=np.clip(rgb-(gradient-gradient.mean())[:,:,None],0,255)
  grey=rgb.mean(2);lo=np.asarray(Image.fromarray(grey.astype('uint8')).filter(ImageFilter.GaussianBlur(1.5))).astype(float);height=(grey-lo)*.012;dy,dx=np.gradient(height);normal=np.stack([-dx,-dy,np.ones_like(dx)],2);normal/=np.linalg.norm(normal,axis=2,keepdims=True);orm=np.zeros((hh,ww,3),np.uint8);orm[:,:,0]=255;orm[:,:,1]=int(grain[sku][2]*255)
  newmaps=[]
  for slot,a in[('albedo',rgb.astype('uint8')),('normal',np.clip((normal+1)*127.5,0,255).astype('uint8')),('orm',orm)]:
   f=out/(key+'-'+slot+'.png');Image.fromarray(a,'RGB').save(f,optimize=True);newmaps.append(dict(material=key,slot=slot,path=str(f),sha256=F.sha(f),native_resolution=[ww,hh]))
  provenance=dict(master=master['path'],master_sha256=master['sha256'],source_crop_pixel_box=box,pixel_identical_raw_crop=str(raw),raw_crop_sha256=F.sha(raw),right_angle_rotation_degrees=90 if rotate else 0,native_crop_pixels=[box[2]-box[0],box[3]-box[1]],output_pixels=[ww,hh],no_upscale=True,geometric_resampling_count=0,method='Own exact-SKU wood-only native pixels, no edges/stone/backdrop/props. Raw crop immutable derivative retained; lossless right-angle orientation and fitted affine illumination plane subtraction only. Existing geometry/UV preserved; natural pattern phase and physical sampling scale are interpretation.')
  dump(out/(key+'-crop-provenance.json'),provenance);model['materials'][key].update(normalScale=.35,extras=dict(intrinsic_material=True,own_photo_material_crop=True,photo_pixels_baked=True,native_resolution=[ww,hh],crop_provenance=str(out/(key+'-crop-provenance.json')),baked_reflections=False,natural_pattern_placement_interpreted=True));maps=[x for x in maps if x['material']!=key]+newmaps;assert model['meshes']==original_meshes
  reason='KendiSKU yakın planındaki gerçek doğal ahşap damar pikselleri native ölçüde korunur; yalnız ışık eğimi ayrılır. Geometri, normal, indeks ve UV dizileri birebir korunur. Ham crop ayrı saklıdır; doğal tekil damar yerleşimi ve örnek ölçeği yorumdur.'
 meta=model['metadata'];meta.update(model_revision='hm-furniture-root-caught-four-v2',revision_note=reason,supersedes_glb=old['glb_path'],supersedes_glb_sha256=old['sha256'],quality_pending=True,model_status='pending_root_browser_review',photo_pixels_baked=any(m.get('extras',{}).get('photo_pixels_baked')for m in model['materials'].values()))
 dump(out/'model.json',model);geo.update(revision_note=reason);geo['triangles']=sum(len(x['indices'])//3 for x in model['meshes']);dump(out/'geometry-validation.json',geo)
 for x in maps:x['sha256']=F.sha(x['path'])
 dump(out/'material-validation.json',dict(oldmat,maps=maps,revision_note=reason))
 report=F.EX.export_assets(out/'model.json',out,old['id']);glb=out/(old['id']+'.glb');doc,binary=F.EX.read_glb(glb);doc['samplers']=[dict(magFilter=9729,minFilter=9987,wrapS=10497,wrapT=10497)]
 for t in doc.get('textures',[]):t['sampler']=0
 binary=F.G.M.embed_tangents(doc,binary);F.EX.write_glb(glb,doc,binary);report['deliverable_sha256']['glb']=F.sha(glb);report['glb_bytes']=glb.stat().st_size;report['source_sha256']=F.sha(out/'model.json');dump(report['files']['validation'],report)
 entry=dict(old,**{k:v for k,v in meta.items()if k in['revision_note','model_revision','supersedes_glb','supersedes_glb_sha256','photo_pixels_baked']});entry.update(asset_dir=str(out),model_path=str(out/'model.json'),glb_path=str(glb),sha256=F.sha(glb),bytes=glb.stat().st_size,geometry_validation=str(out/'geometry-validation.json'),material_validation=str(out/'material-validation.json'),quality_pending=True,root_actual_review_pending=True)
 for key in['independent_qa','native_render_paths','source_native_comparison']:entry.pop(key,None)
 dump(out/'entry.json',entry)
 assert all(F.sha(p)==s for p,s in before.items())
 preserve=dict(sku=sku,old_GLb_SHA=old['sha256'],new_GLb_SHA=entry['sha256'],old_entire_asset_files_unchanged=True,geometry_normals_indices_UV_identical=sku!='1254575001',unchanged_wood_leg_meshes=sku=='1254575001',old_source_JPEGs_unchanged=all(F.sha(x['path'])==x['sha256']for x in masters),revision_note=reason)
 dump(out/'revision-preservation.json',preserve);print('REVISION BUILT',sku,flush=True);return entry
if __name__=='__main__':
 selected=sys.argv[1:]or SKUS;previous=json.loads((R/'manifest.json').read_text())if(R/'manifest.json').exists()else[];rows=[e for e in previous if e['sku']not in selected]+[make(sku)for sku in selected];dump(R/'manifest.json',rows)
 for name in['audit_assets.py','make_contacts.py','freeze_batch.py']:shutil.copyfile(P/name,R/name)
 shutil.copyfile(P/'source-master-freeze-503.json',R/'source-master-freeze-503.json')
