"""Resolved exactDE1304431006: own ivory-looking stainless interlocking plates."""
from pathlib import Path
import sys,math,json,copy,shutil
sys.dont_write_bytecode=True
import numpy as np
import build_models as F
BASE=F.materials
from geometry_extra import extrude_xy
P=Path(__file__).resolve().parent;R=P/'revisions/resolved-ivory-cross-table-06';R.mkdir(parents=True,exist_ok=True);T=math.tau

def cross_table():
 p=[];r=.177;cut=.171;slot=.0017;mid=.159;top=lambda x:.455-.145*math.sqrt(max(0,1-(x/cut)**2))
 # Two independently closed slotted steel plates really interlock; one top-open,
 # the other bottom-open, rather than two unnotched intersecting box planes.
 arc1=[(x,top(x))for x in np.linspace(cut,slot,110)]
 arc2=[(x,top(x))for x in np.linspace(-slot,-cut,110)]
 a=[(-r,.005),(r,.005),(r,.455),(cut,.455)]+arc1+[(slot,mid),(-slot,mid)]+arc2+[(-r,.455)]
 b=[(-r,.005),(-slot,.005),(-slot,mid+.0003),(slot,mid+.0003),(slot,.005),(r,.005),(r,.455),(cut,.455)]+[(x,top(x))for x in np.linspace(cut,-cut,220)]+[(-r,.455)]
 for i,poly in enumerate([a,b]):
  g=extrude_xy('own-one-of-TWO-real-slotted-concave-U-steel-support-plates-'+str(i),'finish',poly,-.0016,.0016)
  if i:g['_vertices']=[(z,y,x)for x,y,z in g['_vertices']]
  p.append(g)
 # Four narrow real open rim notches receive the support fins at the plate edge.
 outline=[];ro=.17975;ri=.1735;eps=.0105
 for q in range(4):
  a=q*math.pi/2;outline.extend([(ri*math.cos(a-eps),ri*math.sin(a-eps)),(ri*math.cos(a+eps),ri*math.sin(a+eps))]);outline.extend((ro*math.cos(v),ro*math.sin(v))for v in np.linspace(a+eps,a+math.pi/2-eps,90))
 g=extrude_xy('own-thin-circular-stainless-top-with-four-small-fixing-rim-notches','finish',outline,-.0015,.0015);g['_vertices']=[(x,z+.440,y)for x,y,z in g['_vertices']];p.append(g);p.append(F.tube('own-submillimetre-softened-steel-top-rim','finish',[(x,.44115,z)for x,z in outline],.00025,sides=8,closed=True))
 for sx,sz in[(1,0),(-1,0),(0,1),(0,-1)]:p.append(F.board('one-of-four-own-small-ivory-floor-glides','glide',.012 if sx else .006,.006,.006 if sx else .012,(sx*.169,.003,sz*.169),.001))
 return p,['Own exactDE images0da74cd0e0ad/934aa763962c: thin36cm round top, four small fixing edge notches and two crossing flat support plates with broad U-concave upper cutouts; small outer fins rise above the top.','Two separately closed finite3.2mm steel plates have complementary open slots and really interlock; the large spaces under the round top remain open. Four small source floor glides and softened finite rim included.','OfficialØ36/H45.5cm and stainless steel100% are preserved. Own photographs show an opaque warm ivory satin appearance rather than mirrored chrome; surface finish chemistry/coating system is not published and is an explicit appearance interpretation.','All local sheet/notch/slot/foot sections and assembly phase are photo estimates, not official manufacturer measurements. No lamp/styling/accessories or source reflection baked.'],dict(official_diameter_cm=36,official_total_height_cm=45.5,interlocking_closed_steel_plate_count=2,complementary_open_slots=True,large_real_concave_upper_cutouts=True,top_rim_fixing_notches=4,small_floor_glide_count=4,local_sheet_thickness_mm_photo_estimate=3.2,source_substrate='stainless steel100%',source_color_label='Weiß',finish_appearance_photo_interpreted='opaque warm ivory satin; not mirrored chrome',finish_chemistry_or_coating_not_verified=True,prior_UK_identity_failure_resolved_by_exact_DE=True)

def materials(out,pid,defs,masters):
 m,maps=BASE(out,pid,defs,masters);m['finish']['extras'].update(source_substrate='Official stainless steel100%',finish_appearance_photo_interpreted=True,finish_chemistry_unpublished=True,appearance='Warm ivory opaque satin from own exactSKU photos; no assumed white-paint chemical formulation or chromed sibling copied');return m,maps
S=dict(name='İç içe levha ayaklı yuvarlak paslanmaz çelik yan sehpa',dims=[36,45.5,36],build=cross_table,primary_index=1,materials={'finish':('paint',[240,237,225],.44),'glide':('paint',[236,232,217],.72)},official={'diameter_cm':[36],'height_cm':[45.5]},color='Kendi fotoğrafında sıcak kırık beyaz/ivory görünüm; resmî Weiß',note='DE resmîaynıSKU kimliği,Ø36/H45.5cm ve paslanmazçelik100% doğrulandı; eski boşUK kaydı değiştirilmedi. Kendi fotoğraflarında opak sıcak kırıkbeyaz saten görünüm var; yüzey boya/kaplama kimyası yayımlanmadığı için yalnız görünüm yorumu yapılır, krom veya beyaz boyalı bileşim resmî iddia edilmez. İki gerçek kapalı çelik levha tamamlayıcı açık yarıklarla iç içe geçer, üstte büyük U boşlukları ve ince yuvarlak tabla vardır. Yerel kalınlık/kenar/tırnak/ayak glides fotoğraf tahminidir.')
if __name__=='__main__':
 for n in['original-image-masters.json','source-queue-117.json','source-master-freeze-503.json']:shutil.copyfile(P/n,R/n)
 (R/'source-evidence').mkdir(exist_ok=True);shutil.copyfile(P/'source-evidence/1304431006.json',R/'source-evidence/1304431006.json');F.R=R;F.materials=materials;F.SPECS['1304431006']=S;F.build('1304431006')
 for n in['audit_assets.py','make_contacts.py','batch_contacts.py','freeze_batch.py']:shutil.copyfile(P/n,R/n)
