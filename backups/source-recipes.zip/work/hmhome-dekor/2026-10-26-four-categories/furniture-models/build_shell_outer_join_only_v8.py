"""Only fill the visible rear/side collar gap, preserving all V7 parts."""
from pathlib import Path
import sys,json,math
sys.dont_write_bytecode=True
import numpy as np
import build_models as F
import build_last_soft_six as L
import build_shell_plump_lower_body_v7 as V7
import build_continuous_u_pilot_v4 as C
from revision_export_exact import export
P=Path(__file__).resolve().parent;R=P/'revisions/own-shell-soft-outer-U-join-only-v8'
OLD=P/'revisions/own-shell-plump-lower-and-soft-upper-rolls-v7/frozen-own-plump-lower-soft-upper-shell-pouf-v7-CANDIDATE-manifest.json'

def apron(scale,translation,front_source=None):
    path=L.smooth_path([(.214,.205),(.226,.120),(.218,-.015),(.172,-.137),(.094,-.177),(0,-.186),(-.094,-.177),(-.172,-.137),(-.218,-.015),(-.226,.120),(-.214,.205)],24)
    length=np.r_[0,np.cumsum(np.linalg.norm(np.diff(path,axis=0),axis=1))];u=length/length[-1];ny=28;n=len(path);v=[];uv=[];faces=[];geometry=[];loY=.065;hiY=.260
    for inside in[False,True]:
        for i,(x,z)in enumerate(path):
            tangent=path[min(i+1,n-1)]-path[max(0,i-1)];tangent/=np.linalg.norm(tangent);out=np.array([-tangent[1],tangent[0]])
            rear=np.clip((.205-z)/.391,0,1);phase=5*np.clip((u[i]-.30)/.40,0,1);lobe=math.cos(math.pi*phase)**2;top=.284+.111*rear**.63+.006*lobe-.007*(1-lobe)**3
            # Exact own V5/V7 rounded-tube section at the join height. The top
            # edge is8mm inside the padded collar and is completely buried.
            rise=(hiY-.125)/(top-.125);cosv=np.sign(2*rise-1)*abs(2*rise-1)**(1/.60);sinv=math.sqrt(max(0,1-cosv*cosv));phase_y=5*np.clip((u[i]-.30+.025*(u[i]-.5)*(1-rise))/.40,0,1);filled=math.cos(math.pi*phase_y)**2;half=.044+.027*filled**.55*(.35+.65*rise**.55);offset=half*sinv**.72-.008;qt=np.array([x,z])+out*offset
            direction=qt/np.linalg.norm(qt);power=2/.45;radius=(abs(direction[0]/.269)**power+abs(direction[1]/.259)**power)**(-1/power);qb=direction*radius*.972
            for j,t in enumerate(np.linspace(0,1,ny+1)):
                blend=t*t*t*(10+t*(-15+6*t));endfade=min(1.,u[i]/.12,(1-u[i])/.12);endfade=endfade*endfade*(3-2*endfade);soft_padding=(.012+.010*rear)*endfade;xz=qb*(1-blend)+qt*blend+out*soft_padding*math.sin(math.pi*t)**2
                if inside:xz-=out*.006
                p=np.array([xz[0],loY+(hiY-loY)*t,xz[1]])*scale+translation;v.append(tuple(p));uv.append((length[i]/.18,p[1]/.18))
            geometry.append(dict(path_index=i,upper_join_raw_y=hiY,buried_top_outer_offset_from_collar_mm=8,lower_join_raw_y=loY))
    stride=ny+1;layer=n*stride
    for side in[0,1]:
        off=side*layer
        for i in range(n-1):
            for j in range(ny):
                a=off+i*stride+j;b=a+stride;faces.extend([(a,b,a+1),(a+1,b,b+1)])
    # Close both long borders and both sewn end borders: finite padded shell.
    for j in[0,ny]:
        for i in range(n-1):
            a=i*stride+j;b=a+stride;faces.extend([(a,a+layer,b),(b,a+layer,b+layer)])
    for i in[0,n-1]:
        for j in range(ny):
            a=i*stride+j;b=a+1;faces.extend([(a,b,a+layer),(b,b+layer,a+layer)])
    p=np.asarray(v);fit={}
    for axis,limit in[(0,.275),(2,.245)]:
        gain=min(1.,limit/max(abs(p[:,axis].min()),abs(p[:,axis].max())));p[:,axis]*=gain;fit[str(axis)]=float(gain)
    if front_source:
        triangles=np.concatenate([np.asarray(m['positions']).reshape(-1,3)[np.asarray(m['indices']).reshape(-1,3)]for m in front_source]);edges=np.concatenate([triangles[:,[0,1]],triangles[:,[1,2]],triangles[:,[2,0]]]);a,b=edges[:,0],edges[:,1];dy=b[:,1]-a[:,1];gain=1.
        for y in np.unique(p[:,1]):
            keep=(abs(dy)>1e-12)&(np.minimum(a[:,1],b[:,1])<=y)&(np.maximum(a[:,1],b[:,1])>=y);x=a[keep,0]+(y-a[keep,1])*(b[keep,0]-a[keep,0])/dy[keep];limit=max(abs(x.min()),abs(x.max()))-.0004;extent=abs(p[p[:,1]==y,0]).max();gain=min(gain,limit/extent)
        p[:,0]*=gain;fit['front_solid_silhouette_guard_global_X']=float(gain)
    g=F.B.solid('new-closed-soft-continuous-outer-U-apron-BEHIND-V7-rolls','fabric',p.tolist(),faces,uv);C.physical_fabric_charts(g);g['_uvs']=[(a*.16/.18,b*.16/.18)for a,b in g['_uvs']];g=F.G.H.orient(g);mesh,check=F._finalize(g);F.G.M.ensure_uv_faces([mesh]);F.G.H.ensure_float32_uv([mesh]);return mesh,dict(new_closed_soft_outer_U_only=True,apron_thickness_mm_raw_photo_estimate=6,soft_outer_padding_mm_raw_photo_estimate=[12,22],new_apron_only_XZ_envelope_fit=fit,original_V7_parts_never_fitted_or_changed=True,top_buried_in_existing_padded_strip_mm_raw=8,lower_buried_in_existing_lower_body=True,raw_Y_span_photo_estimate=[loY,hiY],source_sewn_outer_back_is_continuous=True,no_front_arm_caps_or_existing_parts_modified=True,geometry=check)

def main():
    old=json.loads(OLD.read_text())[0];model=json.loads(Path(old['model_path']).read_text());existing=next(m for m in model['meshes']if'V5-thick-soft-six-upper-rolls'in m['name']);actual=np.asarray(existing['positions']).reshape(-1,3);raw=np.asarray(V7.upper()['_vertices']);scale=(actual.max(0)-actual.min(0))/(raw.max(0)-raw.min(0));translation=actual.min(0)-raw.min(0)*scale;new,proof=apron(scale,translation,[m for m in model['meshes']if m['material']=='fabric']);p=np.asarray(new['positions']).reshape(-1,3);assert(p.min(0)>=np.array([-.275,0,-.245])-1e-7).all()and(p.max(0)<=np.array([.275,.4,.245])+1e-7).all();model['meshes'].append(new);model['metadata']['scale_note']+=' V8: KendiV7ön/üst rulo/alt gövde/post ve haritalar birebir korunur. Yalnız arkada ve yanlarda mevcut rulo ile alt gövde arasında kalan hava aralığı, arkasına eklenen kapalı yumuşak U döşeme sargısıyla birleşir; yerel6mmkalınlık/bağlantı fotoğraf yorumudur.';model['metadata'].update(only_outer_back_side_join_added=True,all_V7_existing_geometry_and_maps_unchanged=True);export(R,old,model,[],'own-shell-pouf-outer-soft-U-join-only-v8',proof)

if __name__=='__main__':main()
