"""Nine own-source complex forms: sets, fabric sling, architectural chair and sofas."""
import sys,math
sys.dont_write_bytecode=True
import numpy as np
from PIL import Image
import build_models as F
BASE=F.materials
import build_wood_furniture01 as W
from geometry_extra import extrude_xy
G=F.G;B=F.B;T=math.tau
def soft(name,dims,c,r=.07,cells=(1,1,1),loft=.009,seam=.006,mat='fabric',tilt=0):return F.soft_block(name,mat,dims,c,r,cells,loft,seam,tilt)
def shift(p,x=0,z=0,a=0):
 for g in p:g['_vertices']=[(u*math.cos(a)+v*math.sin(a)+x,y,-u*math.sin(a)+v*math.cos(a)+z)for u,y,v in g['_vertices']]
 return p
def tube(name,pts,r=.01,mat='frame',sides=20):return F.tube(name,mat,pts,r,sides=sides)
def bent(points,rad=.028):
 a=np.asarray(points);out=[a[0]]
 for i in range(1,len(a)-1):
  b=a[i];v1=a[i-1]-b;v2=a[i+1]-b;l1=np.linalg.norm(v1);l2=np.linalg.norm(v2);cut=min(rad,l1*.45,l2*.45);s=b+v1/l1*cut;e=b+v2/l2*cut;out.append(s)
  out.extend((1-t)**2*s+2*(1-t)*t*b+t*t*e for t in np.linspace(0,1,18)[1:])
 out.append(a[-1]);return out
def timber(name,w,h,d,c,vertical=False,mat='wood'):return F.ROOT.wood_uv(F.board(name,mat,w,h,d,c,.003),vertical)
def feet(xs,zs,h=.06,r=.025):return[tube('small-source-wooden-foot',[(x,0,z),(x,h,z)],r,'wood',24)for x in xs for z in zs]
def avern():
 p=[soft('own-low-architectural-full-upholstered-seat-base',(.565,.255,.915),(0,.128,0),.025,loft=.004),soft('own-separate-full-seat',(.465,.115,.80),(.050,.26,.024),.035,loft=.008),soft('own-one-left-architectural-arm',(.10,.57,.915),(-.2325,.285,0),.028,loft=.004),soft('own-straight-low-back',(.48,.345,.13),(.0425,.407,-.3925),.028,loft=.005)]
 return p,['Own KellyWearstler Avern narrow deep architectural chair: one left full arm, separate filled seat, straight low back and continuous upholstered base','Official56.5×91.5×58cm and29.5cm seat height; own rust/dark-beige flamed fabric appearance retained','Local seams/softened edges are photo reconstruction; no white sibling or room props'],{'one_arm_only':True,'official_seat_height_cm':29.5,'architectural_source_form':True}
def beam(name,a,b,w=.027,d=.033):
 a=np.asarray(a);b=np.asarray(b);direction=(b-a)/np.linalg.norm(b-a);normal=np.array([1,0,0]);side=np.cross(direction,normal);g=timber(name,w,np.linalg.norm(b-a),d,(0,0,0),True);g['_vertices']=[tuple((a+b)/2+x*normal+y*direction+z*side)for x,y,z in g['_vertices']];return g
def deck():
 p=[]
 for sx in[-1,1]:
  x=sx*.267
  p.append(beam('one-long-reclining-back-frame-beech-beam',(x,0,.42),(x,.732,-.425)))
  p.append(beam('one-crossed-front-seat-to-rear-foot-beech-beam',(x,0,-.45),(x,.402,.335)))
  p.append(beam('one-short-real-recline-adjusting-strut',(x,.34,-.018),(x,.13,-.35),.023,.027))
  # The own closeup clearly shows three concave notches, cut into a real lower support.
  poly=[(-.20,-.014),(.20,-.014),(.20,.014)]
  for cx in[.095,.020,-.055]:
   poly.append((cx+.018,.014));poly.extend((cx+.018*math.cos(a),.014-.020*math.sin(a))for a in np.linspace(0,math.pi,36))
  poly.append((-.20,.014));g=extrude_xy('three-actual-concave-recline-notches','wood',poly,-.012,.012);g['_vertices']=[(x+zz,yy+.09,xx-.24)for xx,yy,zz in g['_vertices']];p.append(F.ROOT.wood_uv(g,False))
  p.append(tube('visible-closed-metal-side-pivot',[(x-.017,.324,.037),(x+.017,.324,.037)],.007,'hardware',20))
 for y,z in[(.72,-.414),(.38,.34),(.02,.416),(.02,-.44)]:p.append(tube('real-round-crosswise-beech-frame-rod',[(-.267,y,z),(.267,y,z)],.013,'wood',24))
 sling=F.soft_block('own-sagging-finite-striped-canvas-sling','fabric',(.455,.0024,.84),(0,0,0),.0007,(1,1,1),0,0)
 sling['_vertices']=[(x,y+.355+.355*((.42-z)/.84)-.235*math.sin(math.pi*(.42-z)/.84),z)for x,y,z in sling['_vertices']];sling['_uvs']=[(x/.075,z/.84)for x,y,z in sling['_vertices']];p.append(sling)
 return p,['Own striped beech deckchair: two real X side frames, physical pivots, side adjusting struts and THREE concave recline notches','Finite blue/white canvas sling genuinely sags from the top cross rod through the seat, not a flat rectangular card','Official56.3×96.4×73.2cm preserved; chosen open pose, local canvas drape/notches and stripe phase photo interpreted'],{'folding_X_frames':2,'physical_canvas_sag':True,'adjuster_notch_count_per_side':3,'stripe_repeat_metres_photo_estimate':.075}
def dining_pair():
 allp=[]
 for i in range(2):
  p=[soft('own-round-boucle-dining-seat',(.50,.11,.47),(0,.446,.025),.048,loft=.012)]
  path=[(.224*math.cos(a),.645,.224*math.sin(a)-.025)for a in np.linspace(math.pi-.22,T+.22,140)];p.append(F.tube('own-continuous-concave-wrap-around-upholstered-back','fabric',path,.103,.035,sides=28,guide=[0,1,0]))
  for sx in[-1,1]:
   for sz in[-1,1]:p.append(tube('one-of-four-slim-splayed-steel-chair-legs',[(sx*.235,0,sz*.225),(sx*.185,.425,sz*.165)],.0075,'frame',20))
  allp+=shift(W.fit_piece(p,.55,.76,.58),x=(-.35 if i==0 else .35),z=(-.12 if i==0 else .12))
 return allp,['BOTH actual chairs in the2-pack: each55×58×76cm, full round seat, one continuous curved padded wrap-back and four independent slender steel legs','Native intrinsic own cream boucle interpretation; two-chair relative pose is estimated, not a manufacturer overall size','No dining table, room, blanket or photographed background'],{'set_quantity':2,'set_piece_dimensions_whd_cm':[[55,76,58],[55,76,58]],'set_display_arrangement_estimated':True,'total_leg_count':8}
def outdoor_frame(w,h,d,n=1,striped=True):
 p=[];inner=w-.095
 for sx in[-1,1]:
  x=sx*(w/2-.016);path=[(x,0,d*.39),(x,.510,d*.39),(x,.570,d*.36),(x,.580,-d*.30),(x,.550,-d*.36),(x,.12,-d*.36),(x,0,-d*.40)];p.append(tube('own-continuous-rounded-aluminium-side-arm-frame',bent(path),.014))
 for z in[-d*.33,d*.33]:p.append(tube('real-under-seat-aluminium-cross-support',[(-w/2+.016,.30,z),(w/2-.016,.30,z)],.013))
 p.append(tube('real-aluminium-back-upper-cross-support',[(-w/2+.016,h-.032,-d*.34),(w/2-.016,h-.032,-d*.34)],.013))
 cw=inner/n
 for j in range(n):
  x=(j-(n-1)/2)*cw;p.append(soft('own-full-outdoor-seat-cushion',(cw-.008,.145,d*.79),(x,.366,d*.035),.048,loft=.012));p.append(soft('own-loose-filled-outdoor-back-cushion',(cw-.004,h*.48,.145),(x,h*.735,-d*.30),.052,loft=.014,tilt=-.025))
 return p
def outdoor_single(pid):
 if pid=='1347482001':
  p=[]
  for sx in[-1,1]:
   x=sx*.379;p.extend([timber('own-wide-wood-look-aluminium-flat-arm',.095,.042,.88,(x,.585,0),mat='frame'),timber('own-flat-front-aluminium-post',.045,.59,.060,(x,.295,.355),True,'frame'),timber('own-flat-rear-aluminium-post',.045,.69,.060,(x,.345,-.355),True,'frame')])
  for z in[-.355,.355]:p.append(timber('real-aluminium-under-seat-wide-crossrail',.79,.075,.04,(0,.315,z),mat='frame'))
  p+=[soft('own-thick-plain-outdoor-seat',(.69,.17,.72),(0,.395,.040),.055,loft=.015),soft('own-plump-plain-outdoor-back',(.72,.43,.17),(0,.51,-.31),.065,loft=.018,tilt=-.04)]
  return p,['Own86×88×73cm wide-arm outdoor lounge: broad wood-look ALUMINIUM frame, four true flat posts/arms and separate thick seat/back cushions','Official composition is aluminium/polyester, not solid timber; warm grain finish is an interpreted coating','Local frame joints, cushion seams and softness reconstructed; no other outdoor furnishings'],{'official_frame_material':'aluminium','wood_look_is_finish_not_solid_wood':True,'separate_plain_seat_and_back':True}
 w=.66 if pid=='1347485001'else 1.805;n=1 if pid=='1347485001'else 3;p=outdoor_frame(w,.685,.735,n)
 return p,['Own beige powder-coated round aluminium frame, gently bent arm sides and'+str(n)+' full seat/back cushion pair(s)','Own wide beige/cream vertical stripes follow actual physical canvas/fabric X direction; small piping/seam phase interpreted','Official'+('66'if n==1 else'180.5')+'×73.5×68.5cm; no source pool, room or props'],{'seat_cushion_count':n,'back_cushion_count':n,'physical_aluminium_frame':True,'stripe_repeat_metres_photo_estimate':.18}
def curved_sofa():
 p=[soft('own-left-thin-full-rounded-arm',(.245,.555,.98),(-1.0575,.398,-.010),.11,loft=.008),soft('own-left-full-seat-base',(1.02,.33,.91),(-.425,.235,-.005),.11,loft=.015),soft('own-right-elongated-soft-chaise-base',(1.20,.33,1.06),(.545,.235,.035),.15,loft=.015)]
 # The right open end bows outward; the source has no right-hand arm.
 p[-1]['_vertices']=[(x+.045*math.sin((z+.495)/1.06*math.pi),y,z)for x,y,z in p[-1]['_vertices']]
 for x,w in[(-.535,.91),(.375,.91)]:p.append(soft('one-of-two-own-loose-plump-back-cushions',(w,.35,.22),(x,.524,-.36),.07,loft=.018,tilt=-.035))
 p+=feet([-.95,-.15,.90],[-.32,.36],.065,.027)
 return p,['Own236×106×71cm curved three-seat sofa: ONLY left arm, two independent loose back pillows and an open rounded elongated right chaise end','Separate soft upholstered base/seat sections, genuinely bowed right edge and small wood feet','Own cream boucle intrinsic surface, no styled throw pillow or room'],{'left_arm_only':True,'right_chaise_end_open':True,'back_cushion_count':2,'curved_right_end_is_geometry':True}
def quilt_sofa():
 p=[soft('own-six-column-two-row-full-quilt-seat-and-front',(1.85,.34,.84),(0,.24,.055),.075,(6,2,2),.024,.011),soft('own-six-column-two-row-full-quilt-back',(1.85,.45,.25),(0,.440,-.345),.075,(6,2,1),.021,.010)]
 for sx in[-1,1]:p.append(soft('own-three-row-three-depth-soft-quilt-arm',(.27,.60,1.01),(sx*1.055,.335,0),.087,(1,3,3),.017,.009))
 p+=feet([-.98,.98],[-.34,.34],.06,.022)
 return p,['Own238×101×67cm boucle sofa has six broad quilt columns across the filled seat/front and back, two rows, and three-row quilt arms','Every quilt valley and convex stuffed cell is physical; not a dark printed grid on a rigid panel','Own natural loop texture and understated feet; no room or other modular piece'],{'physical_quilt_channels':True,'seat_quilt_columns':6,'seat_quilt_rows':2,'rounded_soft_cell_volumes':True}
def lounge_set():
 sofa=W.fit_piece(outdoor_frame(1.80,.73,.79,2,False),1.80,.73,.79);p=shift(sofa,z=-.70)
 for sx in[-1,1]:p+=shift(W.fit_piece(outdoor_frame(.665,.73,.79,1,False),.665,.73,.79),x=sx*1.34,z=.16,a=-sx*.20)
 profiles=[(G.rounded(w,d,r,32),y)for w,d,r,y in[(1.142,.542,.096,.378),(1.15,.55,.10,.384),(1.15,.55,.10,.394),(1.142,.542,.096,.40)]];table=[G.capped('own-rounded-oval-rectangular-outdoor-tabletop','frame',profiles,True,.20)]
 for x in[-.465,.465]:
  for z in[-.180,.180]:table.append(tube('one-of-four-outdoor-coffee-table-legs',[(x,0,z),(x,.383,z)],.012))
 p+=shift(W.fit_piece(table,1.15,.40,.55),z=.48)
 return p,['Complete actual4-piece outdoor group: two chairs, one two-cushion sofa and one coffee table, all finite rounded aluminium frames/plain cream full cushions','Official per-piece table115×55×40,sofa180×79×73,chairs66.5×79×73cm individually preserved before display placement','Overall layout/orientation is an estimated scene, not a manufacturer group-size claim; no vase/rug/cushion styling added'],{'set_quantity':4,'set_piece_dimensions_whd_cm':[[180,73,79],[66.5,73,79],[66.5,73,79],[115,40,55]],'set_display_arrangement_estimated':True,'included_sofa_seat_back_cushion_pairs':2}
def materials(out,pid,defs,masters):
 mats,maps=BASE(out,pid,defs,masters);n=2048;rng=np.random.default_rng(int(pid[-8:]));yy,xx=np.mgrid[:n,:n]/n;fine=rng.normal(0,1,(n,n));slub=np.asarray(Image.fromarray(rng.normal(0,1,(66,14)).astype('float32'),'F').resize((n,n),Image.Resampling.BICUBIC));weave=(np.sin(T*xx*210)+np.sin(T*yy*225))*.22+slub*.30+fine*.11
 if pid in ['1331378001','1331381001','1301068001']:
  # Source shows millimetre-scale irregular boucle loops rather than plain smooth paint.
  rx=(xx*118)%1-.5;ry=(yy*118+((xx*118).astype(int)%2)*.46)%1-.5;loop=np.exp(-((np.sqrt((rx/.40)**2+(ry/.31)**2)-.80)/.15)**2);height=loop*.52+weave*.11
 else:height=weave*.38
 base=np.asarray(defs['fabric'][1]);rgb=base+weave[...,None]*6
 if pid in ['1263418006','1347485001','1347487001']:
  rgb=np.where((xx<.5)[...,None],np.array([44,134,190]if pid=='1263418006'else[170,159,137]),np.array([235,231,215]))+weave[...,None]*5
 grey=rgb.mean(2);dy,dx=np.gradient(height);normal=np.stack([-dx,-dy,np.ones_like(dx)],2);normal/=np.linalg.norm(normal,axis=2,keepdims=True);orm=np.zeros((n,n,3),np.uint8);orm[:,:,0]=255;orm[:,:,1]=230
 for slot,a in [('albedo',np.clip(rgb,0,255).astype('uint8')),('normal',np.clip((normal+1)*127.5,0,255).astype('uint8')),('orm',orm)]:
  f=out/('fabric-'+slot+'.png');Image.fromarray(a,'RGB').save(f,optimize=True);maps=[x for x in maps if not(x['material']=='fabric'and x['slot']==slot)]+[dict(material='fabric',slot=slot,path=str(f),sha256=F.sha(f),native_resolution=[n,n])]
 mats['fabric'].update(normalScale=.72,sheen=.12,extras=dict(intrinsic_material=True,photo_pixels_baked=False,source_guided_palette=True,appearance_photo_interpreted=True,native_resolution=[n,n],baked_reflections=False,texture_generation='Own-SKU observed colour, boucle/fine weave and stripe count/scale interpretation; native procedural2K intrinsic maps, no photo upsample/product silhouette/room/staging.'))
 return mats,maps
F.materials=materials
S={};NOTE='KendiSKU tam galeri fotoğraflarındaki özel form, kol/ayak/minder ve set parçası sayısı yeniden kuruldu. Resmî dış ölçü, kendi renk ve dokuma ailesi korunur; yerel dikiş/bağlantı/kalınlık/kumaş fazı fotoğraf yorumudur, üreticiCAD değildir. Hiçbir oda/staging fotoğrafı geometriye veya dokuya eklenmez.'
def add(pid,name,dims,fn,rgb,pi=0,**kw):S[pid]=dict(name=name,dims=dims,build=fn,primary_index=pi,materials={'fabric':('paint',rgb,.92),'frame':('paint',[205,202,184],.40),'wood':('wood',[190,151,110],.55),'hardware':('metal',[156,157,148],.30)},color=kw.pop('color','Kendi resmî renk varyantı'),note=kw.pop('note',NOTE),**kw)
add('1343871002','Tek kollu Avern döşemeli dinlenme koltuğu',[56.5,58,91.5],avern,[146,103,76],pi=1,official={'width_cm':[56.5],'depth_cm':[91.5],'total_height_cm':[58],'seat_height_cm':[29.5]},color='Koyu bej/pas melanj')
add('1263418006','Çizgili sarkık kumaşlı katlanır ahşap şezlong',[56.3,73.2,96.4],deck,[44,134,190],color='Mavi/beyaz çizgili')
add('1301068001','İki kıvrımlı sırtlı bukle yemek sandalyesi seti',[125,76,82],dining_pair,[224,215,192],pi=0,official={'each_chair_dimensions_whd_cm':[55,76,58],'set_quantity':2},official_hwd=[None,None,None],estimated_axes=['set_scene_display_dimensions'],color='Krem/siyah');S['1301068001']['materials']['frame']=('paint',[29,29,27],.48)
for pid,dims in [('1347485001',[66,68.5,73.5]),('1347487001',[180.5,68.5,73.5]),('1347482001',[86,73,88])]:add(pid,('Çizgili minderli alüminyum bahçe berjeri'if pid=='1347485001'else'Çizgili minderli alüminyum bahçe kanepesi'if pid=='1347487001'else'Geniş kollu ahşap görünümlü alüminyum berjer'),dims,lambda pid=pid:outdoor_single(pid),[221,213,191],pi=0,color='Bej/çizgili'if pid!='1347482001'else'Kahverengi/bej')
S['1347482001']['materials']['frame']=('wood',[150,105,67],.50)
add('1331378001','Tek kollu kavisli uzun bukle kanepe',[236,71,106],curved_sofa,[225,216,194],pi=0,color='Bej/krem')
add('1331381001','Altı kolonlu dolgun kapitone bukle kanepe',[238,67,101],quilt_sofa,[196,178,149],pi=0,color='Bej')
parts,_,_=lounge_set();v=np.concatenate([g['_vertices']for g in parts]);dims=((v.max(0)-v.min(0))*100).round(5).tolist();add('1347488001','Dört parçalı alüminyum bahçe oturma grubu',dims,lounge_set,[228,222,201],pi=0,official={'table_whd_cm':[115,40,55],'sofa_whd_cm':[180,73,79],'each_chair_whd_cm':[66.5,73,79],'set_quantity':4},official_hwd=[None,None,None],estimated_axes=['set_scene_display_dimensions'],color='Bej/krem')
F.SPECS.update(S)
if __name__=='__main__':
 for pid in sys.argv[1:]or S:F.build(pid)
