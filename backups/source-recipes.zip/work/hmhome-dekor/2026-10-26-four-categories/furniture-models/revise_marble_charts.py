"""Three isolated stone-chart candidates. Frozen originals remain unchanged."""
from pathlib import Path
import json,sys,shutil
sys.dont_write_bytecode=True
import build_tables as TB
F=TB.F;P=F.R;R=P/'revisions/marble-single-chart-r1';R.mkdir(parents=True,exist_ok=True)
for n in ['original-image-masters.json','source-queue-117.json']:
 if not(R/n).exists():shutil.copyfile(P/n,R/n)
(R/'source-evidence').mkdir(exist_ok=True)
for sku in ['1225700002','1225700003','1225700006']:
 dst=R/'source-evidence'/(sku+'.json')
 if not dst.exists():shutil.copyfile(P/'source-evidence'/dst.name,dst)
F.R=R
def slab_once():
 parts,features,extras=TB.marble_pedestal();g=parts[-1]
 g['_uvs']=[(x/.25+.5,z/.25+.5)for x,y,z in g['_vertices']]
 features.append('One continuous planar chart covers the entire circular slab exactly once; no inside-slab tile boundary. Natural individual vein phase remains an explicit interpretation from the own native sample.')
 extras['stone_chart_coverage']='single continuous full slab, no visible material tile repeats'
 return parts,features,extras
for sku in ['1225700002','1225700003','1225700006']:
 sp=dict(TB.S[sku]);sp['build']=slab_once;sp['note']=sp['note'].replace('yerel örnek kullanılır; damar yerleşimi tekrarlı yorumdur','yerel örnek tek kesintisiz düzlemsel alana bir kez yerleştirilir; damar yerleşimi yorumdur');F.SPECS[sku]=sp;F.build(sku)
