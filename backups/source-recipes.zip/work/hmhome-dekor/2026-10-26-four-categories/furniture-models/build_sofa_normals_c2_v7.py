"""Only normal continuity on the accepted V6 cushion silhouettes; no vertex moves."""
from pathlib import Path
import sys,json,hashlib,copy,itertools
sys.dont_write_bytecode=True
import numpy as np
from revision_export_exact import export
P=Path(__file__).resolve().parent;R=P/'revisions/sofa-three-seat-c2-normals-v7';OLD=P/'revisions/sofa-three-seat-crowns-v6/frozen-own-local-three-sofa-seat-crowns-v6-reviewed-manifest.json'
def digest(a,kind):return hashlib.sha256(np.asarray(a,dtype=kind).tobytes()).hexdigest()
def smooth(m):
 p=np.asarray(m['positions'],dtype='float32').reshape(-1,3);n=np.asarray(m['normals'],float).reshape(-1,3);f=np.asarray(m['indices']).reshape(-1,3);v,weld=np.unique(p,axis=0,return_inverse=True);q=p[f].astype(float);ar=np.linalg.norm(np.cross(q[:,1]-q[:,0],q[:,2]-q[:,0]),axis=1)/6;weight=np.zeros(len(v));nn=np.zeros((len(v),3));counts=np.bincount(weld,minlength=len(v));np.add.at(nn,weld,n);nn/=counts[:,None];nn/=np.linalg.norm(nn,axis=1)[:,None]
 for k in range(3):np.add.at(weight,weld[f[:,k]],ar)
 voxel=.006;keys=np.floor(v/voxel).astype('int32');uk,iv=np.unique(keys,axis=0,return_inverse=True);aw=np.bincount(iv,weights=weight,minlength=len(uk));ap=np.zeros((len(uk),3));an=ap.copy()
 for k in range(3):ap[:,k]=np.bincount(iv,weights=v[:,k]*weight,minlength=len(uk))/aw;an[:,k]=np.bincount(iv,weights=nn[:,k]*weight,minlength=len(uk))/aw
 radius=.065;cell=np.floor(ap/radius).astype('int32');bins={}
 for i,k in enumerate(cell):bins.setdefault(tuple(k),[]).append(i)
 querykeys=np.floor(v/radius).astype('int32');uq,iq=np.unique(querykeys,axis=0,return_inverse=True);result=np.zeros_like(nn);shifts=list(itertools.product([-1,0,1],repeat=3))
 for gi,key in enumerate(uq):
  inds=np.flatnonzero(iq==gi);neighbors=np.array(sum([bins.get(tuple(key+np.array(off)),[])for off in shifts],[]),dtype=int);a=ap[neighbors];norm=an[neighbors];mass=aw[neighbors]
  for start in range(0,len(inds),48):
   ids=inds[start:start+48];r=np.sqrt(np.sum((v[ids,None,:]-a[None,:,:])**2,axis=2))/radius;t=np.maximum(0,1-r);kernel=t**4*(4*r+1);z=(kernel*mass[None,:])@norm;z/=np.linalg.norm(z,axis=1)[:,None];result[ids]=z
 dot=np.clip((result*nn).sum(1),-1,1);angles=np.degrees(np.arccos(dot));new=result[weld].astype('float32');original=dict(position=digest(m['positions'],'<f4'),uv=digest(m['uvs'],'<f4'),indices=digest(m['indices'],'<u4'),normal=digest(m['normals'],'<f4'));m['normals']=new.reshape(-1).tolist();assert original['position']==digest(m['positions'],'<f4')and original['uv']==digest(m['uvs'],'<f4')and original['indices']==digest(m['indices'],'<u4');return dict(mesh=m['name'],method='C2 compact Wendland surface-normal convolution, area-weighted6mm surfel quadrature,65mm support. No geometry/UV/index deformation.',normal_angle_change_degrees_percentiles={str(x):float(np.percentile(angles,x))for x in[0,50,90,99,100]},position_UV_indices_byte_identical=original,all_positions_and_V6_silhouette_preserved=True,unit_normals=True,surfel_count=len(ap),unique_query_vertices=len(v),source_rows_not_reintroduced_as_flatcap_normals=True)
def main():
 old=json.loads(OLD.read_text())[0];model=json.loads(Path(old['model_path']).read_text());names=[];proof=[]
 for m in model['meshes']:
  if 'THREE-own-full-supported-seat'in m['name']:names.append(m['name']);proof.append(smooth(m));print('SMOOTHED',m['name'],flush=True)
 assert len(names)==3;model['metadata']['scale_note']+=' V7: V6nın onaylanan tüm silüeti ve tüm konum/UV/index baytları aynıdır; yalnız3minder yüzey normali C2 sürekli alanla düzeltilerek yatay ışık/facet bantları giderilir. Dolgunluk/ölçü/poz değişmez.';export(R,old,model,names,'own-sofa-three-cushions-C2-normal-continuity-only-v7',dict(normal_corrections=proof,only_normals_and_dependent_tangents_changed_on_three_seats=True,all_12_meshes_positions_UV_indices_identical=True,outerU_back_base_seams_preserved=True,own_material_PNGbytes_identical=True))
if __name__=='__main__':main()
