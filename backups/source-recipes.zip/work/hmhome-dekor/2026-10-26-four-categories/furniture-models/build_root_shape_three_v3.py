"""Root-observed exact-source flat metal straps and capped/slot book display."""
from pathlib import Path
import sys,math,copy,shutil
sys.dont_write_bytecode=True
import numpy as np
import build_models as F
BASE=F.materials
import build_live_three_v2 as V
import build_live_hard_nineteen as H
H.BASE=BASE;G=F.G;B=F.B;T=math.tau
P=Path(__file__).resolve().parent;R=P/'revisions/source-straps-and-bookcap-v3';R.mkdir(parents=True,exist_ok=True)
def plate_hole(name,mat,w,h,cx,cy,z0,z1,hx,hy,r,segment=0,corner=.002):
 outer=np.array([(x+cx,y+cy)for x,y in G.rounded(w,h,corner,16)]);inner=[]
 for x,y in outer:
  a=math.atan2(y-hy,x-hx);dx,dy=math.cos(a),math.sin(a);t=r/max(abs(dx),1e-12)
  if abs(t*dy)>segment:
   c=math.copysign(segment,dy);t=c*dy+math.sqrt(max(0,(c*dy)**2-c*c+r*r))
  inner.append((hx+t*dx,hy+t*dy))
 n=len(outer);v=[(x,y,z)for z in[z0,z1]for ring in[outer,inner]for x,y in ring];f=[]
 for j in range(n):
  k=(j+1)%n
  for off in[0,2*n]:f.extend([(off+j,off+k,off+n+j),(off+k,off+n+k,off+n+j)])
 for j in range(n):
  k=(j+1)%n;f.extend([(j,j+2*n,k),(k,j+2*n,k+2*n),(n+j,n+k,n+j+2*n),(n+k,n+k+2*n,n+j+2*n)])
 g=B.solid(name,mat,v,f,[(x/.16,y/.16)for x,y,z in v]);g['_flat_cap_face_count']=4*n;return g
def strap(name,path,x):
 path=np.asarray(path);outline=G.rounded(.014,.004,.0012,10);n=len(outline);vv=[];uv=[];ff=[];length=np.r_[0,np.cumsum(np.linalg.norm(np.diff(path,axis=0),axis=1))]
 for i,(z,y)in enumerate(path):
  t=path[min(i+1,len(path)-1)]-path[max(i-1,0)];t/=np.linalg.norm(t);perp=np.array([-t[1],t[0]])
  for j,(a,b)in enumerate(outline):vv.append((x+a,y+perp[1]*b,z+perp[0]*b));uv.append((j/n,length[i]/.08))
 for i in range(len(path)-1):
  for j in range(n):a=i*n+j;b=i*n+(j+1)%n;c=a+n;d=b+n;ff.extend([(a,c,b),(b,c,d)])
 for i in[0,len(path)-1]:
  ci=len(vv);z,y=path[i];vv.append((x,y,z));uv.append((.5,length[i]/.08))
  for j in range(n):ff.append((ci,i*n+j,i*n+(j+1)%n))
 return B.solid(name,'frame',vv,ff,uv)
def shelf():
 old,f,e=V.shelf();p=[g for g in old if 'iron-support'not in g['name']];path=[(-.105,.637),(-.105,.590),(.105,.550),(.105,.490),(-.105,.450),(-.105,.360),(.105,.320),(.105,.260),(-.105,.220),(-.105,.130),(.105,.090),(.105,.030),(-.105,.022)]
 for sx in[-1,1]:
  x=sx*.233;p.append(strap('own-wide-flat-rounded-section-continuous-iron-strap',V.rounded_bends(path),x));p.append(plate_hole('own-upper-flat-wall-tab-with-real-open-screw-hole','frame',.016,.030,x,.645,-.107,-.103,x,.653,.00225,corner=.0028));p.append(plate_hole('own-lower-flat-wall-tab-with-real-open-screw-hole','frame',.016,.026,x,.013,-.107,-.103,x,.006,.00225,corner=.0028))
 f+=['V3 own red AND sage closeups confirm a broad flat iron strip with rounded section edges, not a round wire. Physical width14mm/thickness4mm is explicit photo estimate.','Each continuous S support has upper/lower finite flat wall tab and a genuine circular through-hole; no painted black dot or included screw is invented.'];e.update(source_cross_section='flat rounded rectangular iron strap',strap_width_thickness_mm_photo_estimate=[14,4],wall_tabs_with_open_screw_holes=4);return p,f,e
def books():
 p,f,e=H.floor_books();p=[g for g in p if g['name']!='actual-tall-book-display-rear-panel'];back=plate_hole('own-full-back-panel-with-source-oblong-hanging-through-slot','body',.432,.90,0,.45,-.150,-.134,0,.858,.007,.012,corner=.0008);p.append(F.ROOT.wood_uv(back,True));p.append(H.wood('own-source-full-horizontal-top-cap-shelf',.414,.016,.125,(0,.892,-.080)))
 f+=['Root-observed own full source59eadde32827: add the complete horizontal top cap/shelf and real vertical oblong hanging slot near the upper back. Three source-correct stepped side/pocket outlines are preserved.','Cap depth125mm,slot14×38mm and local placement are photo estimates inside unchanged official43.2×30×90cm, not newly invented official measurements.'];e.update(full_horizontal_top_cap_present=True,physical_oblong_hanging_through_slot=True,local_cap_and_slot_dimensions_photo_estimated=True);return p,f,e
S={}
for sku in['1096727005','1096727007','1281678002']:
 sp=copy.deepcopy(H.S[sku]if sku=='1281678002'else V.S[sku]);sp['build']=books if sku=='1281678002'else shelf;sp['note']+=' V3: Kendi resmî fotoğrafında görünen yassı yuvarlatılmış metal şerit+delikli vida uçları veya tam üstkapak+oblong askı deliği fiziksel olarak düzeltildi. Yerel kesit/delik ölçüleri açık fotoğraf tahminidir, resmî dış zarf sabittir.';S[sku]=sp
if __name__=='__main__':
 for n in['original-image-masters.json','source-queue-117.json','source-master-freeze-503.json']:shutil.copyfile(P/n,R/n)
 (R/'source-evidence').mkdir(exist_ok=True)
 for sku in S:shutil.copyfile(P/'source-evidence'/(sku+'.json'),R/'source-evidence'/(sku+'.json'))
 F.R=R;F.materials=BASE;F.SPECS.update(S)
 for sku in sys.argv[1:]or S:F.build(sku)
 for n in['audit_assets.py','make_contacts.py','batch_contacts.py','freeze_batch.py']:shutil.copyfile(P/n,R/n)
