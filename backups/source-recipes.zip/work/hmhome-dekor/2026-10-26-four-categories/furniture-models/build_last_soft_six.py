"""Six last own-SKU soft forms; fine capped free fibres, native botanical cloth."""
import sys,math
sys.dont_write_bytecode=True
import numpy as np
from PIL import Image,ImageFilter
import build_models as F
BASE=F.materials;G=F.G;B=F.B;T=math.tau
def soft(n,d,c,r=.07,cells=(1,1,1),loft=.006,seam=.004):return F.soft_block(n,'fabric',d,c,r,cells,loft,seam)
def ellipsoid(n,d,c,mat='fabric'):
 profile=[(0,-.5)]+[(math.cos(a),.5*math.sin(a))for a in np.linspace(-math.pi/2,math.pi/2,64)[1:-1]]+[(0,.5)];g=B.lathe(n,mat,profile,144,False);g['_vertices']=[(x*d[0]/2+c[0],y*d[1]+c[1],z*d[2]/2+c[2])for x,y,z in g['_vertices']];return g
def plump_base(name,w,d,h,z=.025):
 # The source base has a full soft vertical front and broad floor contact,
 # rather than an isolated lens/disc that touches the floor at one point.
 profile=[(0,.004),(.38,.004),(.45,.018),(.49,.065),(.50,.18),(.50,.72),(.49,.86),(.45,.96),(.38,1),(0,.978)];g=B.lathe(name,'fabric',[(r*w,y*h)for r,y in profile],192,False);g['_vertices']=[(x,y,zz*d/w+z)for x,y,zz in g['_vertices']];return g
def smooth_path(points,steps=22):
 a=np.asarray(points,float);out=[]
 for i in range(len(a)-1):
  q0,q1,q2,q3=a[max(0,i-1)],a[i],a[i+1],a[min(len(a)-1,i+2)]
  for t in np.linspace(0,1,steps,endpoint=False):out.append(.5*((2*q1)+(-q0+q2)*t+(2*q0-5*q1+4*q2-q3)*t*t+(-q0+3*q1-3*q2+q3)*t*t*t))
 out.append(a[-1]);return np.asarray(out)
def full_wrap(name,path,top,bottom,halfwidth,exponent=.42,flare=0,flutes=0):
 """Closed swept plump wall, down to its base rather than a floating back bar."""
 p=np.asarray(path,float);n=len(p);sides=40;v=[];uv=[];ff=[];length=np.r_[0,np.cumsum(np.linalg.norm(np.diff(p,axis=0),axis=1))]
 for i,c in enumerate(p):
  t=p[min(i+1,n-1)]-p[max(0,i-1)];t/=np.linalg.norm(t);side=np.array([-t[1],t[0]]);h=top(c)if callable(top)else top;mid=(h+bottom)/2;ry=(h-bottom)/2
  for j in range(sides+1):
   a=(j%sides)*T/sides;yy=mid+ry*np.sign(math.cos(a))*abs(math.cos(a))**exponent;off=halfwidth*np.sign(math.sin(a))*abs(math.sin(a))**.58;rise=np.clip((yy-bottom)/(h-bottom),0,1);off+=flutes*math.cos(i/(n-1)*12*math.pi)*rise**1.8;xx,zz=c+off*side;xx*=1+flare*rise**4
   v.append((xx,yy,zz));uv.append((length[i]/.60,yy/.90))
 for i in range(n-1):
  for j in range(sides):a=i*(sides+1)+j;b=a+sides+1;ff.extend([(a,b,a+1),(a+1,b,b+1)])
 for i in[0,n-1]:
  ci=len(v);c=p[i];h=top(c)if callable(top)else top;v.append((c[0],(h+bottom)/2,c[1]));uv.append((length[i]/.60,(h+bottom)/2/.90))
  for j in range(sides):ff.append((ci,i*(sides+1)+j,i*(sides+1)+j+1))
 return B.solid(name,'fabric',v,ff,uv)
def own_planar_charts(g):
 v=np.asarray(g['_vertices']);nv=[];nf=[];uv=[]
 for f in g['_faces']:
  q=v[list(f)];normal=np.cross(q[1]-q[0],q[2]-q[0]);axis=int(abs(normal).argmax());a,b=[k for k in range(3)if k!=axis];idx=len(nv);nv.extend(q.tolist());uv.extend((float(x[a]/.60),float(x[b]/.90))for x in q);nf.append((idx,idx+1,idx+2))
 g.update(_vertices=nv,_faces=nf,_uvs=uv);return g
def fine_fur(parts,pid,count,length,width):
 """Area-weighted roots, slowly varying flow, independent tapered closed fibres.
 The free centreline is never joined into a loop; only its tiny end section caps.
 """
 rng=np.random.default_rng(int(pid));triangles=[]
 for g in parts:
  if g['material']!='fabric':continue
  g=G.H.orient(g);v=np.asarray(g['_vertices']);ff=np.asarray(g['_faces']);q=v[ff];nn=np.cross(q[:,1]-q[:,0],q[:,2]-q[:,0]);area=np.linalg.norm(nn,axis=1);nn/=area[:,None];keep=nn[:,1]>-.45;triangles.append((q[keep],nn[keep],area[keep]))
 q=np.concatenate([x[0]for x in triangles]);nn=np.concatenate([x[1]for x in triangles]);weights=np.concatenate([x[2]for x in triangles]);parents=(count+5)//6;idx=rng.choice(len(q),parents,p=weights/weights.sum());q=q[idx];parent_n=nn[idx];u=np.sqrt(rng.random(parents));v=rng.random(parents);parent_root=(1-u)[:,None]*q[:,0]+(u*(1-v))[:,None]*q[:,1]+(u*v)[:,None]*q[:,2];root=np.repeat(parent_root,6,axis=0)[:count];n=np.repeat(parent_n,6,axis=0)[:count]
 # Macro flow varies over source-scale patches rather than uniform short carpet.
 parent_random=np.repeat(rng.normal(0,1.0,parents),6)[:count];a=.8*np.sin(root[:,0]*23+root[:,2]*16)+.5*np.sin(root[:,2]*41-root[:,1]*13)+parent_random+rng.normal(0,.15,count);flow=np.c_[np.sin(a),np.zeros(count),np.cos(a)];flow-=n*(flow*n).sum(1)[:,None];bad=np.linalg.norm(flow,axis=1)<1e-7;flow[bad]=[1,0,0];flow/=np.linalg.norm(flow,axis=1)[:,None];across=np.cross(n,flow);across/=np.linalg.norm(across,axis=1)[:,None];root+=flow*rng.uniform(-.0008,.0008,count)[:,None]+across*rng.uniform(-.0006,.0006,count)[:,None]
 stations=12 if pid=='1311946001'else 8;nr=stations*3;per=nr+2;lens=np.repeat(rng.uniform(*length,parents),6)[:count]*rng.uniform(.75,1.10,count)
 if length[1]>.015:lens*=.78+.52*(.5+.25*np.sin(root[:,0]*107+root[:,2]*61)+.25*np.sin(root[:,2]*93-root[:,0]*49+root[:,1]*37))
 widths=rng.uniform(*width,count);phase=np.repeat(rng.uniform(0,T,parents),6)[:count]+rng.normal(0,.18,count);freq=np.repeat(rng.uniform(.65,1.25,parents),6)[:count]+rng.uniform(-.03,.03,count);f=np.linspace(0,1,stations);lift=1.45*np.sin(f*math.pi*.84);centres=root[:,None,:]+n[:,None,:]*(lens[:,None,None]*lift[None,:,None])+flow[:,None,:]*(lens[:,None,None]*f[None,:,None]**1.12*.45)
 wave=np.sin(f[None,:]*T*freq[:,None]+phase[:,None])-np.sin(phase)[:,None];centres+=across[:,None,:]*(lens[:,None,None]*.26*wave[:,:,None]*f[None,:,None]**.65);centres[:,:,1]-=lens[:,None]*.50*f[None,:]**1.7
 # Undercoat intersection hides every root; endpoint independently tapers and remains free.
 centres-=n[:,None,:]*.0006;direction=np.gradient(centres,axis=1);direction/=np.linalg.norm(direction,axis=2,keepdims=True);guide=np.broadcast_to(np.array([1.,0,0]),direction.shape).copy();near=abs(direction[:,:,0])>.90;guide[near]=[0,0,1];span=np.cross(direction,guide);span/=np.linalg.norm(span,axis=2,keepdims=True);up=np.cross(direction,span);ang=np.arange(3)*T/3;radial=span[:,:,None,:]*np.cos(ang)[None,None,:,None]+up[:,:,None,:]*np.sin(ang)[None,None,:,None];radius=widths[:,None]*(.5*(1-f)**.65+.035)[None,:];rings=centres[:,:,None,:]+radial*radius[:,:,None,None];vertices=np.concatenate([rings.reshape(count,nr,3),centres[:,:1],centres[:,-1:]],axis=1)
 local=[]
 for j in range(stations-1):
  for k in range(3):
   a=j*3+k;b=j*3+(k+1)%3;c=(j+1)*3+k;d=(j+1)*3+(k+1)%3;local.extend([(a,c,b),(b,c,d)])
 for k in range(3):local.extend([(nr,k,(k+1)%3),(nr+1,nr-3+(k+1)%3,nr-3+k)])
 faces=np.array(local)[None,:,:]+np.arange(count)[:,None,None]*per;trip=vertices.reshape(-1,3)[faces.reshape(-1,3)];vol=np.einsum('ij,ij->i',trip[:,0],np.cross(trip[:,1],trip[:,2])).reshape(count,-1).sum(1)/6;assert abs(vol).min()>1e-14;faces[vol<0]=faces[vol<0][:,:,[0,2,1]]
 # UV vertically follows each root-to-free-tip pigment gradient on a native2K map.
 uv=np.empty((count,per,2));rootu=rng.uniform(.004,.992,count);uv[:,:nr,0]=rootu[:,None]+np.tile(np.arange(3)/3,stations)[None,:]*.003;uv[:,:nr,1]=np.repeat(f,3)[None,:]+np.tile(np.sin(np.arange(3)*T/3),stations)[None,:]*.0003;uv[:,nr,0]=rootu+.001;uv[:,nr+1,0]=rootu+.001;uv[:,nr,1]=0;uv[:,nr+1,1]=1
 g=B.solid('independent-fine-open-centreline-closed-tapered-fur-'+str(count),'pile',vertices.reshape(-1,3).tolist(),faces.reshape(-1,3).tolist(),uv.reshape(-1,2).tolist());parts.append(g);return parts
def furry_stool(pid):
 light=pid=='1311946001';p=[ellipsoid('own-rounded-MDF-backed-padded-round-seat',(.285,.056,.285),(0,.408,0))]
 for sx in[-1,1]:
  for sz in[-1,1]:p.append(F.tube('one-of-four-splayed-slender-iron-legs','steel',[(sx*.119,.003,sz*.119),(sx*.091,.397,sz*.091)],.006,sides=20))
 p=fine_fur(p,pid,26000,(.016,.043),(.00022,.00065));return p,['Own round padded flocculent seat, actual four slender slightly splayed iron legs and MDF support; own light-cream/cream legs or dark-beige/black legs are separate exact source variants','26000 independent fine capped free wavy fibres, slow tuft-flow variation, no haircards, no coarse petals, no closed centreline rings','Official seatD33/totalH46cm. Local leg spread, padding/undercoat and fibre lengths are photo estimates; no second sibling added'],{'leg_count':4,'independent_fine_fibres':26000,'fur_free_end_centrelines':True,'official_seat_diameter_cm':33,'local_fibre_and_foot_spread_photo_estimated':True}
def timber_fur():
 p=[ellipsoid('own-rounded-filled-fur-seat-undercoat',(.406,.075,.406),(0,.409,0))]
 for a in np.arange(4)*T/4+math.pi/4:
  g=F.ROOT.wood_uv(F.board('one-of-FOUR-own-broad-softly-rounded-pine-blade-legs','wood',.118,.367,.044,(0,.1835,0),.016),True);g['_vertices']=[(x*math.cos(a)+z*math.sin(a)+.153*math.cos(a),y,-x*math.sin(a)+z*math.cos(a)+.153*math.sin(a))for x,y,z in g['_vertices']];p.append(g)
 return fine_fur(p,'1338975001',28000,(.023,.052),(.00023,.00065)),['Own source full packshots explicitly show FOUR broad flattened rounded pine legs, not three generic sticks; own dark longitudinal wood grain and light-beige long fluffy seat','28000 independently tapered free-ended fibres curl/drape irregularly over the seat edges, with real closed fine solids and continuous own undercoat','Official topD46/totalH46cm; fur length, undercoat/wood sections and local joint details estimated from own source'],{'leg_count':4,'independent_fine_fibres':28000,'official_top_diameter_cm':46,'fine_free_tapered_hair':True}
def fur_chair():
 p=[plump_base('own-full-soft-vertical-front-floor-supported-fur-base',.925,.875,.38,.035)]
 path=smooth_path([(.38,.27),(.42,.04),(.34,-.28),(.20,-.35),(0,-.37),(-.20,-.35),(-.34,-.28),(-.42,.04),(-.38,.27)]);p.append(full_wrap('own-full-height-continuous-U-fur-wall-down-to-base',path,lambda c:.66+.075*np.clip((.27-c[1])/.64,0,1),.020,.075,.56));p.append(soft('own-source-packshot-loose-filled-fur-back-cushion',(.66,.34,.16),(0,.540,-.255),.069,loft=.015))
 return fine_fur(p,'1331379001',44000,(.015,.038),(.00023,.00064)),['Own round generously stuffed tub chair, continuous rounded U arms/back, full rounded base/seat and one own isolated-packshot back cushion','44000 independent free-ended fine fibres with slow local flow, soft down-hanging edges and no petal cards or closed rings','Official101×94×75cm. Own beige longhaired polyester100, Venture external fulfilment does not substitute the exact source identity; local padding, hair and hidden base estimated'],{'independent_fine_fibres':44000,'continuous_U_tub_back':True,'own_packshot_back_cushion_count':1,'local_hair_length_photo_estimate_m':[.015,.038]}
def shell():
 p=[plump_base('own-shell-pouf-full-floor-supported-soft-base',.50,.43,.235,.030)];path=np.array([(.206*math.cos(a),-.016-.162*math.sin(a))for a in np.linspace(-.70,math.pi+.70,166)]);p.append(full_wrap('own-full-height-radially-fluted-shell-wall',path,lambda c:.295+.10*np.clip((.09-c[1])/.27,0,1),.012,.047,.57,flutes=.012))
 return fine_fur(p,'1254723001',30000,(.003,.009),(.00015,.00038)),['Own white low child clam-shell pouf: one soft deep rounded base/seat and continuous fan-fluted shell back with lower rounded arms, no legs','Radial shell seams/scallops are physically shaped; short plush is 30000 independent capped fine free fibres, not long wool fur','Source approximateH40/W55cm retained as published approximate, depth49cm is explicit photo estimate; local shell ribs, tuft length and hidden underside estimated'],{'shell_fan_flutes_photo_interpreted':6,'short_plush_independent_fibres':30000,'published_approximate_axes':['width_cm','height_cm'],'depth_cm_photo_estimate':49}
def floral():
 p=[ellipsoid('own-independent-full-oval-botanical-seat',(.700,.16,.585),(0,.332,.015))]
 path=smooth_path([(.403,.19),(.355,.06),(.35,-.22),(.24,-.31),(0,-.32),(-.24,-.31),(-.35,-.22),(-.355,.06),(-.403,.19)]);p.append(full_wrap('own-continuous-full-height-botanical-side-wings-and-back',path,lambda c:.603+.073*np.clip((.19-c[1])/.51,0,1),.003,.047,.36,flare=.035));p=[own_planar_charts(g)for g in p]
 return p,['Own dark-green/cream native botanical woven upholstery, rounded continuous concave wrap-back with rolled-outward arm tips, full separate oval seat, upholstered front side wings and rear apron; open under-seat void retained','Exact own fabric-only gallery JPEG supplies native2048×3072 botanical pixels; no source silhouette, room, seam shadow or styled object baked','Official94.5×69.7×67.6cm; local upholstery outline/hidden apron and exact unseen pattern phase are interpreted, not makerCAD'],{'own_native_botanical_pattern':True,'continuous_curved_wrap_back':True,'separate_oval_seat':True,'pattern_phase_photo_interpreted':True}
PALETTE={'1311946001':[237,228,211],'1311946002':[163,140,111],'1338975001':[238,224,203],'1331379001':[237,227,210],'1254723001':[245,242,232]}
def materials(out,pid,defs,masters):
 mats,maps=BASE(out,pid,defs,masters)
 if pid=='1286071003':
  m=next(x for x in masters if 'd6cc1ee4e412'in x['path']);box=[56,84,2104,3156];patch=Image.open(m['path']).convert('RGB').crop(box);raw=out/'fabric-native-botanical-donor.png';patch.save(raw);rgb=np.asarray(patch).copy();n,h=patch.width,patch.height
  # No palette reduction or colour de-lighting: retain rare cream/green motifs.
  grey=rgb.mean(2);low=np.asarray(Image.fromarray(grey.astype('uint8')).filter(ImageFilter.GaussianBlur(1.0)));height=(grey-low)*.020;rr=.92;keys=['fabric'];F.dump(out/'fabric-crop-provenance.json',dict(master=m['path'],master_sha256=m['sha256'],source_crop_pixel_box=box,native_crop_pixels=[n,h],output_pixels=[n,h],raw_crop=str(raw),raw_crop_sha256=F.sha(raw),pixel_identical_albedo=True,no_upscale=True,no_quantization=True,physical_repeat_wh_m_photo_estimate=[.60,.90],hidden_pattern_phase_interpreted=True,method='Native exactSKU flat textile closeup only. No product edges/background present; native RGB unchanged, no palette quantization.'))
 else:
  n=h=2048;yy,xx=np.mgrid[:h,:n]/n;rng=np.random.default_rng(int(pid));variation=np.asarray(Image.fromarray(rng.normal(0,1,(57,79)).astype('float32'),'F').resize((n,h),Image.Resampling.BICUBIC));fine=rng.normal(0,.35,(h,n));base=np.array(PALETTE[pid]);rgb=np.clip(base+(variation*1.8+fine)[...,None],0,255);height=variation*.02;rr=.88;keys=['fabric','pile']
 for key in keys:
  # Same native pigment in undercoat and fine visible fibres, opaqueAO255, no shadow bake.
  if key=='pile':
   y=np.arange(h)[:,None]/(h-1);rgb=np.clip(np.array(PALETTE[pid])[None,None,:]+(y[:,:,None]-.4)*np.array([7,7,6])[None,None,:]+variation[:,:,None]*1.5,0,255)
  dy,dx=np.gradient(height);normal=np.stack([-dx,-dy,np.ones_like(dx)],2);normal/=np.linalg.norm(normal,axis=2,keepdims=True);orm=np.zeros((h,n,3),np.uint8);orm[:,:,0]=255;orm[:,:,1]=int(rr*255)
  for slot,a in [('albedo',np.clip(rgb,0,255).astype('uint8')),('normal',np.clip((normal+1)*127.5,0,255).astype('uint8')),('orm',orm)]:
   f=out/(key+'-'+slot+'.png');Image.fromarray(a,'RGB').save(f,optimize=True);maps=[x for x in maps if not(x['material']==key and x['slot']==slot)]+[dict(material=key,slot=slot,path=str(f),sha256=F.sha(f),native_resolution=[n,h])]
  mats[key].update(normalScale=.35 if pid=='1286071003'else .12,sheen=.25,extras=dict(intrinsic_material=True,photo_pixels_baked=pid=='1286071003',own_photo_material_crop=pid=='1286071003',native_resolution=[n,h],source_guided_palette=True,physical_free_fur_interpreted=pid!='1286071003',no_haircards_or_alpha=True,baked_reflections=False))
 return mats,maps
F.materials=materials
NOTE='KendiSKU fotoğrafındaki dolgun dış form ve parça sayısı, resmî ölçü/malzeme korunur. Lifler serbest biten, ayrı kapalı ince fiziksel katılardır; fotoğrafın gölgesi, silüeti veya oda/aksesuar bake edilmez. Yerel dolgu/lif boyu/kalınlığı/akışı ve görünmeyen birleşim fotoğraf yorumudur; üreticiCAD değildir.'
S={}
def add(sku,name,dims,fn,pi,col,**kw):S[sku]=dict(name=name,dims=dims,build=fn,primary_index=pi,materials={'fabric':('paint',PALETTE.get(sku,[93,94,72]),.9),'pile':('paint',PALETTE.get(sku,[93,94,72]),.88),'steel':('paint',[230,225,209]if sku=='1311946001'else[26,26,25],.48),'wood':('wood',[93,62,42],.64)},color=col,note=kw.pop('note',NOTE),**kw)
for sku in ['1311946001','1311946002']:add(sku,'İnce metal ayaklı uzun tüylü tabure',[33,46,33],lambda sku=sku:furry_stool(sku),0,'Açık bej/krem'if sku.endswith('1')else'Koyu bej/siyah',official={'top_diameter_cm':[33],'height_cm':[46]})
add('1338975001','Dört geniş çam ayaklı uzun tüylü tabure',[46,46,46],timber_fur,2,'Kahverengi/bej',official={'top_diameter_cm':[46],'height_cm':[46]})
add('1331379001','Yuvarlak kavisli uzun tüylü dolgun berjer',[101,75,94],fur_chair,1,'Bej/krem')
add('1254723001','Deniz kabuğu sırtlı kısa peluş çocuk pufu',[55,40,49],shell,0,'Beyaz',official={'width_cm':[55],'height_cm':[40]},official_hwd=[40,55,None],estimated_axes=['depth_cm_photo_estimate49'],published_approximate_axes=['width_cm','height_cm'],note=NOTE+' Resmîgenişlik55/yükseklik40cm kaynakta yaklaşık olarak yayımlanır. Derinlik49cm açık fotoğraf tahminidir.')
add('1286071003','Botanik desenli kıvrımlı döşemeli dinlenme koltuğu',[94.5,67.6,69.7],floral,0,'Koyu yeşil/krem botanik')
S['1286071003']['materials'].pop('pile');F.SPECS.update(S)
if __name__=='__main__':
 for sku in sys.argv[1:]or S:F.build(sku)
