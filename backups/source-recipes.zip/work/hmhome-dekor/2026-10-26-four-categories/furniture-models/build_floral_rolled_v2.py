"""Exact native botanical pixels, own source flared rolled-over wing silhouette."""
from pathlib import Path
import sys,math,copy,json,shutil
sys.dont_write_bytecode=True
import numpy as np
from PIL import Image,ImageFilter
import build_models as F
import build_last_soft_six as L
from geometry_extra import extrude_xy
P=Path(__file__).resolve().parent;R=P/'revisions/botanical-rolled-wings-v2';R.mkdir(parents=True,exist_ok=True);B=F.B;T=math.tau
OLD=P/'frozen-botanical-own-native-cloth-source-reviewed-manifest.json'
def closed_smooth(points,steps=5):
 a=np.asarray(points,float);o=[]
 for i in range(len(a)):
  p0,p1,p2,p3=[a[j%len(a)]for j in[i-1,i,i+1,i+2]]
  for t in np.linspace(0,1,steps,endpoint=False):o.append(.5*(2*p1+(-p0+p2)*t+(2*p0-5*p1+4*p2-p3)*t*t+(-p0+3*p1-3*p2+p3)*t*t*t))
 return o

def charts(g):
 v=np.asarray(g['_vertices']);vv=[];ff=[];uv=[]
 for f in g['_faces']:
  q=v[list(f)];axis=int(np.argmax(abs(np.cross(q[1]-q[0],q[2]-q[0]))));a,b=[j for j in range(3)if j!=axis];off=len(vv);vv.extend(q.tolist());ff.append((off,off+1,off+2));uv.extend((float(p[a]/.18),float(p[b]/.27))for p in q)
 g.update(_vertices=vv,_faces=ff,_uvs=uv);return g

def build():
 path=L.smooth_path([(.34,.295),(.32,.12),(.31,-.16),(.22,-.275),(0,-.290),(-.22,-.275),(-.31,-.16),(-.32,.12),(-.34,.295)],20)
 cross=closed_smooth([(-.022,.0),(.022,.0),(.026,.70),(.040,.79),(.082,.83),(.120,.84),(.145,.90),(.144,.94),(.126,.98),(.098,1),(.068,.99),(.033,.95),(.005,.89),(-.018,.80),(-.025,.66)],5)
 template=extrude_xy('concave-roll-cap-template','fabric',cross,0,.001);n=len(template['_vertices'])//2;cross=np.asarray(template['_vertices'])[:n,:2];caps=[f for f in template['_faces']if max(f)<n];vv=[];uv=[];ff=[];sections=[]
 for i,c in enumerate(path):
  tangent=path[min(i+1,len(path)-1)]-path[max(i-1,0)];tangent/=np.linalg.norm(tangent);side=np.array([-tangent[1],tangent[0]]);top=.620+.056*np.clip((.295-c[1])/.550,0,1);ring=[]
  for off,rise in cross:
   roll=1-.75*np.clip((-c[1]-.16)/.12,0,1);off=off if off<=.03 else .03+(off-.03)*roll;x,z=c+side*off;y=.002+(top-.002)*rise;vv.append((x,y,z));uv.append((x/.18,y/.27));ring.append((x,y,z))
  sections.append(ring)
 for i in range(len(path)-1):
  for j in range(n):a=i*n+j;b=i*n+(j+1)%n;ff.extend([(a,a+n,b),(b,a+n,b+n)])
 ff.extend(caps);off=(len(path)-1)*n;ff.extend(tuple(off+j for j in f)for f in caps)
 shell=charts(B.solid('own-continuous-U-with-real-outward-soft-ROLLED-TOP-overhang','fabric',vv,ff,uv));seat=charts(L.ellipsoid('own-generously-filled-separate-oval-seat',(.700,.16,.585),(0,.332,.015)));p=[shell,seat];p.append(F.tube('own-soft-seat-midheight-perimeter-piping','fabric',[(.35*math.cos(a),.332,.2925*math.sin(a)+.015)for a in np.linspace(0,T,240,endpoint=False)],.0013,sides=8,closed=True))
 for ring in[sections[0],sections[-1]]:p.append(F.tube('own-same-fabric-front-wing-profile-seam','fabric',ring,.0010,sides=8,closed=True))
 return p,['Own full front5803a3d35fd5/787d2d920b0f and lifestyle5800dd52d424: narrow upholstered floor-reaching side wings flare into a broad outward rolled-over upper lip; separate full oval seat and open below-seat void. No thin upright generic U wall.','Native exactSKU2048×3072 fabric-only RGB and raw pixel master preserved from immutable firstcandidate; only smooth periodic boundary correction derives this new albedo/normal tile; changed physical repeat18×27cm is an explicit source-photo estimate matching leaf scale, never official manufacturer repeat. Hidden phase/layout interpreted.','Own full front width94.5cm provides a plan anchor; leaves read roughly1.5–2.5cm in source rather than oversized branches. Local rolled section, seams and unseen phase are reconstructions, no props/room/photo silhouette baked.'],dict(own_native_botanical_pattern=True,continuous_curved_wrap_back=True,separate_oval_seat=True,source_outward_rolled_upper_wings=True,pattern_phase_photo_interpreted=True,physical_pattern_repeat_wh_m_photo_estimate=[.18,.27],pattern_scale_source='Own full front width94.5cm and native fabric closeup; local leaf span photo estimated, not official',quality_label='Desen yerleşimi yorumu',quality_note='Kumaş kendi ürününün özgün yakın planından alınmıştır. Yaprak ölçeği fotoğraftan yaklaşık kurulmuş, kumaşın gizli yüzlerdeki kesim ve desen fazı yorumlanmıştır.')

def materials(out,pid,defs,masters):
 e=json.loads(OLD.read_text())[0];m=json.loads(Path(e['model_path']).read_text());v=json.loads(Path(e['material_validation']).read_text());maps=[];proof=[]
 for im in v['maps']:
  src=Path(im['path']);assert F.sha(src)==im['sha256'];dst=out/src.name;shutil.copyfile(src,dst);assert F.sha(dst)==im['sha256'];maps.append(dict(im,path=str(dst)));proof.append(dict(source=str(src),new=str(dst),sha256=im['sha256'],byte_identical=True))
 olddir=Path(e['asset_dir']);raw=olddir/'fabric-native-botanical-donor.png';shutil.copyfile(raw,out/raw.name);prov=json.loads((olddir/'fabric-crop-provenance.json').read_text());prov.update(raw_crop=str(out/raw.name),physical_repeat_wh_m_photo_estimate=[.18,.27],repeat_revision_note='Previous60×90cm repeat superseded only in this new revision. Native albedo pixels are unchanged; own packshot leaf scale photo estimated.');F.dump(out/'fabric-crop-provenance.json',prov);m['materials']['fabric']['extras'].update(physical_repeat_wh_m_photo_estimate=[.18,.27],crop_provenance=str(out/'fabric-crop-provenance.json'));# Derive a periodic intrinsic tile at the original native resolution.  The
 # smooth boundary correction removes the conspicuous rectangular repeat; it
 # does not synthesize branches, resize the crop, or quantize rare pigments.
 a=np.asarray(Image.open(out/'fabric-albedo.png').convert('RGB'),dtype=float);h,w=a.shape[:2];den=2*np.cos(T*np.arange(h)[:,None]/h)+2*np.cos(T*np.arange(w)[None,:]/w)-4;den[0,0]=1;derived=a.copy()
 for ch in range(3):
  z=a[:,:,ch];v=np.zeros((h,w));v[0]=z[-1]-z[0];v[-1]=z[0]-z[-1];v[:,0]+=z[:,-1]-z[:,0];v[:,-1]+=z[:,0]-z[:,-1];freq=np.fft.fft2(v)/den;freq[0,0]=0;derived[:,:,ch]=z-np.fft.ifft2(freq).real
 correction=derived-a;rgb=np.clip(derived,0,255).astype('uint8');grey=rgb.mean(2);lo=np.asarray(Image.fromarray(grey.astype('uint8')).filter(ImageFilter.GaussianBlur(1))).astype(float);dy,dx=np.gradient((grey-lo)*.020);normal=np.stack([-dx,-dy,np.ones_like(dx)],axis=2);normal/=np.linalg.norm(normal,axis=2,keepdims=True)
 for slot,im in[('albedo',rgb),('normal',np.clip((normal+1)*127.5,0,255).astype('uint8'))]:
  f=out/('fabric-'+slot+'.png');Image.fromarray(im,'RGB').save(f,optimize=True);maps=[x for x in maps if not(x['material']=='fabric'and x['slot']==slot)]+[dict(material='fabric',slot=slot,path=str(f),sha256=F.sha(f),native_resolution=[w,h])]
 prov.update(pixel_identical_albedo=False,raw_crop_pixel_identical=True,no_upscale=True,no_quantization=True,derived_periodic_boundary_correction=True,mean_absolute_RGB_correction=float(np.mean(abs(correction))),max_absolute_RGB_correction=float(np.max(abs(correction))),method='Native exactSKU fabric-only crop retained pixel-identical. Derived periodic-plus-smooth boundary correction removes a rectangular repeating edge without resizing or quantization; source leaf detail/pigments retained. Hidden layout is interpreted.');F.dump(out/'fabric-crop-provenance.json',prov);
 for rec in proof:
  rec['derived_sha256']=F.sha(rec['new']);rec['byte_identical']=rec['derived_sha256']==rec['sha256'];rec['operation']='source-native periodic boundary derivation'if not rec['byte_identical']else'preserved unchanged'
 F.dump(out/'own-original-map-source-binding.json',proof);return m['materials'],maps
S=copy.deepcopy(L.S['1286071003']);S['build']=build;S['note']+=' Ayrı V2: Kendi packshotundaki geniş dışa kıvrık üst kanat/rulo ve dar dik alt yan paneller yeniden kuruldu. Native ham donör değişmez; türevde dikdörtgen tekrar sınırı yumuşak periyodik düzeltmeyle giderilir; yaprak ölçeği foto-tahmini18×27cm tekrar ile düzeltilir. Desenin gizli fazı yorumdur, resmî motif ölçeği iddiası yoktur.'
if __name__=='__main__':
 for n in['original-image-masters.json','source-queue-117.json','source-master-freeze-503.json']:shutil.copyfile(P/n,R/n)
 (R/'source-evidence').mkdir(exist_ok=True);shutil.copyfile(P/'source-evidence/1286071003.json',R/'source-evidence/1286071003.json');F.R=R;F.materials=materials;F.SPECS['1286071003']=S;F.build('1286071003')
 for n in['audit_assets.py','make_contacts.py','batch_contacts.py','freeze_batch.py']:shutil.copyfile(P/n,R/n)
