from pathlib import Path
import json,hashlib,datetime
R=Path(__file__).resolve().parent
q=json.loads((R/'source-queue-117.json').read_text());entries={e['sku']:e for e in json.loads((R/'manifest.json').read_text())}
# Revisions are immutable overlays. Never replace earlier frozen candidates in place.
rev=R/'revisions/marble-single-chart-r1/frozen-marble-single-chart-r1-manifest.json'
if rev.exists():entries.update({e['sku']:e for e in json.loads(rev.read_text())})
rows=[]
for p in q['products']:
 sku=p['sku'];e=entries.get(sku);rows.append(dict(sku=sku,model_status='pending_root_browser_review'if e else'pending_source_specific_geometry',candidate_glb=e.get('glb_path')if e else None,glb_sha256=e.get('sha256')if e else None,own_native_views_complete=bool(e and all((Path(e['asset_dir'])/(s+'.png')).exists()for s in['on','on-capraz','yan','arka','ustten'])),root_approved=False))
out=dict(updated_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_scope_complete=False,source_exact_products=117,root_approved_count=0,candidate_count=len(entries),blocked_source_identities=q['blocked_products_not_modeled'],products=rows)
(R/'all117-status.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print('STATUS',len(rows),'candidates',len(entries))
