"""Root-caught real concavity and native own-oak corrections, separate from frozen six."""
from pathlib import Path
import sys,json,math,copy,shutil
sys.dont_write_bytecode=True
import numpy as np
from PIL import Image,ImageFilter
import build_models as F
P=Path(__file__).resolve().parent;R=P/'revisions/finalwood-two-v2';R.mkdir(parents=True,exist_ok=True)
OLD={x['sku']:x for x in json.loads((P/'frozen-finalwood-six-manifest.json').read_text())}
def finalize(g):
 g=F.G.H.orient(g);m,c=F._finalize(g);F.G.H.S.flatcap_normals(m);return m,c
def curved_seat():
 g=F.soft_block('own-physically-dished-rounded-wood-seat','body',(.535,.029,.555),(0,0,0),.006,(1,1,1),0,0)
 g['_vertices']=[(x,y+.285-.060*z+.028*(x/.2675)**2+.017*(z/.2775)**2,z+.010)for x,y,z in g['_vertices']]
 return F.ROOT.wood_uv(g,False)
def curved_back():
 g=F.soft_block('own-concave-wood-backrest','body',(.535,.325,.025),(0,0,0),.002,(1,1,1),0,0);a=-.21
 pts=[]
 for x,y,z in g['_vertices']:
  z+=.028*(x/.2675)**2;pts.append((x,y*math.cos(a)-z*math.sin(a)+.438,y*math.sin(a)+z*math.cos(a)-.239))
 g['_vertices']=pts;return F.ROOT.wood_uv(g,True)
def make(sku):
 old=OLD[sku];src=Path(old['asset_dir']);out=R/'models'/old['id'];assert not(out/'frozen.json').exists();out.mkdir(parents=True,exist_ok=True);before={str(p):F.sha(p)for p in src.iterdir()if p.is_file()};model=json.loads(Path(old['model_path']).read_text());oldmeshes=copy.deepcopy(model['meshes']);geo=json.loads(Path(old['geometry_validation']).read_text());mat=json.loads(Path(old['material_validation']).read_text());maps=[dict(x,path=str(out/Path(x['path']).name))for x in mat['maps']]
 for p in src.glob('*.png'):
  if p.name not in ['on.png','on-capraz.png','yan.png','arka.png','ustten.png']:shutil.copyfile(p,out/p.name)
 masters=[x for x in json.loads((P/'original-image-masters.json').read_text())if x['sku']==sku]
 if sku=='1333438001':
  import build_finalwood_six as FW
  raw_parts,_,_=FW.broad_arm_chair();v=np.concatenate([g['_vertices']for g in raw_parts]);lo=v.min(0);hi=v.max(0);origin=np.array([(lo[0]+hi[0])/2,lo[1],(lo[2]+hi[2])/2]);fit=np.asarray(geo['affine_fit_scale'])
  replacements={'single-solid-wood-seat-with-rounded-front':curved_seat(),'single-leaning-wide-wood-backrest':curved_back()}
  replaced=[]
  for i,m in enumerate(model['meshes']):
   if m['name']in replacements:
    g=replacements[m['name']];v=(np.asarray(g['_vertices'])-origin)*fit
    if 'backrest'in m['name']:
     oldv=np.asarray(m['positions']).reshape(-1,3);a,b=oldv[:,1].min(),oldv[:,1].max();v[:,1]=a+(v[:,1]-v[:,1].min())*(b-a)/(v[:,1].max()-v[:,1].min())
    g['_vertices']=v.tolist();model['meshes'][i],geo['meshes'][i]=finalize(g);replaced.append(i)
  assert len(replaced)==2
  for i,(a,b)in enumerate(zip(model['meshes'],oldmeshes)):
   if i not in replaced:assert a==b
  reason='Kendi ön/yan fotoğrafındaki belirgin oturma çanağı ve hafif konkav sırt gerçek geometri yapıldı. Oturak ortası yan/ön kenarlardan yaklaşık2–3cm alçak, sırt kenarları merkezden yaklaşık2,8cm öndedir; bu yerel eğimler fotoğraf tahminidir. Resmî83,4×60,5cm en/yükseklik, tahmini75cm derinlik, kollar/ayaklar ve malzeme baytları aynen korunur.'
  preserve=dict(other_meshes_identical=True,all_texture_bytes_identical=True,changed_meshes=[model['meshes'][i]['name']for i in replaced])
 else:
  master=next(x for x in masters if 'b46a2a47a88a'in x['path']);box=[550,1350,950,2400];patch=Image.open(master['path']).convert('RGB').crop(box);raw=out/'body-native-donor.png';patch.save(raw);patch=patch.transpose(Image.Transpose.ROTATE_90);rgb=np.asarray(patch).astype(float);hh,ww=rgb.shape[:2];yy,xx=np.mgrid[:hh,:ww];A=np.c_[np.ones(hh*ww),xx.ravel()/ww,yy.ravel()/hh];plane=A@np.linalg.lstsq(A,rgb.mean(2).ravel(),rcond=None)[0];rgb=np.clip((rgb-(plane.reshape(hh,ww)-plane.mean())[:,:,None])*np.array([1.12,1.14,1.18]),0,255);grey=rgb.mean(2);low=np.asarray(Image.fromarray(grey.astype('uint8')).filter(ImageFilter.GaussianBlur(1.3))).astype(float);dy,dx=np.gradient((grey-low)*.009);n=np.stack([-dx,-dy,np.ones_like(dx)],2);n/=np.linalg.norm(n,axis=2,keepdims=True);orm=np.zeros((hh,ww,3),np.uint8);orm[:,:,0]=255;orm[:,:,1]=128
  for slot,a in [('albedo',rgb.astype('uint8')),('normal',np.clip((n+1)*127.5,0,255).astype('uint8')),('orm',orm)]:
   f=out/('body-'+slot+'.png');Image.fromarray(a,'RGB').save(f,optimize=True);maps=[x for x in maps if not(x['material']=='body'and x['slot']==slot)]+[dict(material='body',slot=slot,path=str(f),sha256=F.sha(f),native_resolution=[ww,hh])]
  # The long donor direction follows X on the top/beam and Y on the legs.
  for m in model['meshes']:
   v=np.asarray(m['positions']).reshape(-1,3);norm=np.asarray(m['normals']).reshape(-1,3);faces=np.asarray(m['indices']).reshape(-1,3);vertical='leg'in m['name'];vv=[];nn=[];uv=[];ff=[]
   for tri in faces:
    q=v[tri];axis=int(np.argmax(np.abs(np.cross(q[1]-q[0],q[2]-q[0]))));ids=[]
    for j in tri:
     x,y,z=v[j]
     if vertical:u,t=(x/.735,z/.735)if axis==1 else(y/.715,(z/.735 if axis==0 else x/.035))
     else:u,t=(x/1.8,z/.9)if axis==1 else((x/1.8,y/.035)if axis==2 else(z/.9,y/.035))
     ids.append(len(vv));vv.append(v[j]);nn.append(norm[j]);uv.append((u+.5,t+.5))
    ff.append(ids)
   m.update(positions=np.asarray(vv).reshape(-1).tolist(),normals=np.asarray(nn).reshape(-1).tolist(),uvs=np.asarray(uv).reshape(-1).tolist(),indices=np.asarray(ff).reshape(-1).tolist())
  prov=dict(master=master['path'],master_sha256=master['sha256'],source_crop_pixel_box=box,raw_crop=str(raw),raw_crop_sha256=F.sha(raw),native_crop_pixels=[400,1050],output_pixels=[1050,400],right_angle_rotation_degrees=90,no_upscale=True,geometric_resampling_count=0,physical_component_charts_photo_estimate={'tabletop':[1.8,.9],'leg':[.715,.735]},method='Own exactSKU broad-oak-leg crop, no boundary/staging. Native vessels/rays retained; lossless right-angle rotation and only fitted illumination-plane subtraction. One own native material chart per broad component avoids periodic block figures; long donor grain follows X on the tabletop/brace and Y on legs. Component-scale phase is an interpretation, not a full photographic veneer scan. Derived diffuse correction1.12/1.14/1.18 separates the shaded donor from intrinsic light oak; raw native pixels retained independently. No fake painted-grain mask.');F.dump(out/'body-crop-provenance.json',prov)
  model['materials']['body'].update(baseColorFactor=[1,1,1,1],normalScale=.30,extras=dict(intrinsic_material=True,photo_pixels_baked=True,own_photo_material_crop=True,native_resolution=[1050,400],crop_provenance=str(out/'body-crop-provenance.json'),baked_reflections=False,natural_grain_phase_interpreted=True))
  reason='KendiSKU meşe kaplama yakın planının native doğal damar pikselleri kullanıldı. Damar uzunluğu her parçanın gerçek yönüne uyar; her geniş parçanın kendi malzeme chartında damar fazı/ölçeği yorumdur. Yalnız crop ışık eğimi ayrıldı, gölgeli donör için sınırlı diffuse kalibrasyonu açık kayıttadır. Tabla/iki levha ayak/bağlantı geometrisi ve her üçgenin fiziksel konumu aynen korunur; yalnızUV kenarlarında köşeler ayrılır; UV her parçanın gerçek yönü ve geniş yüzeyi için ayrı yeniden yönlenir.'
  for a,b in zip(model['meshes'],oldmeshes):
   av=np.asarray(a['positions']).reshape(-1,3)[np.asarray(a['indices']).reshape(-1,3)];bv=np.asarray(b['positions']).reshape(-1,3)[np.asarray(b['indices']).reshape(-1,3)];assert np.array_equal(av,bv)
  preserve=dict(physical_triangle_positions_identical=True,UV_seams_split_only=True,UV_longitudinal_direction_preserved=True,UV_component_chart_reorientation=True)
 meta=model['metadata'];meta.update(model_revision='hm-furniture-finalwood-root-caught-two-v2',revision_note=reason,supersedes_glb=old['glb_path'],supersedes_glb_sha256=old['sha256'],quality_pending=True,model_status='pending_root_browser_review',photo_pixels_baked=sku=='1341708001');meta['source_evidence_files']=meta['source_evidence_files']+[str(P.parent/'furniture-research'/('root-pdp-'+sku+'-accordion-v3.json'))]if sku=='1333438001'else meta['source_evidence_files']
 geo.update(revision_note=reason,triangles=sum(len(m['indices'])//3 for m in model['meshes']));F.dump(out/'model.json',model);F.dump(out/'geometry-validation.json',geo);F.dump(out/'material-validation.json',dict(mat,maps=maps,revision_note=reason));report=F.EX.export_assets(out/'model.json',out,old['id']);glb=out/(old['id']+'.glb');doc,binary=F.EX.read_glb(glb);doc['samplers']=[dict(magFilter=9729,minFilter=9987,wrapS=10497,wrapT=10497)]
 for t in doc.get('textures',[]):t['sampler']=0
 binary=F.G.M.embed_tangents(doc,binary);F.EX.write_glb(glb,doc,binary);report['deliverable_sha256']['glb']=F.sha(glb);report['glb_bytes']=glb.stat().st_size;report['source_sha256']=F.sha(out/'model.json');F.dump(report['files']['validation'],report)
 entry=dict(old,**{k:v for k,v in meta.items()if k in ['revision_note','model_revision','supersedes_glb','supersedes_glb_sha256','photo_pixels_baked','source_evidence_files']});entry.update(asset_dir=str(out),model_path=str(out/'model.json'),glb_path=str(glb),sha256=F.sha(glb),bytes=glb.stat().st_size,geometry_validation=str(out/'geometry-validation.json'),material_validation=str(out/'material-validation.json'),quality_pending=True,root_actual_review_pending=True)
 for key in ['independent_qa','native_render_paths','source_native_comparison']:entry.pop(key,None)
 F.dump(out/'entry.json',entry);assert all(F.sha(p)==s for p,s in before.items());F.dump(out/'revision-preservation.json',dict(sku=sku,old_files_unchanged=True,source_JPEGs_unchanged=all(F.sha(x['path'])==x['sha256']for x in masters),revision_note=reason,**preserve));return entry
if __name__=='__main__':
 rows=[make(s)for s in sys.argv[1:]or ['1333438001','1341708001']];F.dump(R/'manifest.json',rows)
 for n in ['audit_assets.py','make_contacts.py','freeze_batch.py','batch_contacts.py']:shutil.copyfile(P/n,R/n)
 shutil.copyfile(P/'source-master-freeze-503.json',R/'source-master-freeze-503.json')
