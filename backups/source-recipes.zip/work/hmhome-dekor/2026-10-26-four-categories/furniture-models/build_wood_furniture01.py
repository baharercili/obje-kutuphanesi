"""Eighteen own-reference child/storage/coffee-table variants, no staged objects."""
from pathlib import Path
import sys,math
sys.dont_write_bytecode=True
import numpy as np
import build_models as F
from geometry_extra import extrude_xy
G=F.G;B=F.B;T=math.tau;R=F.R

def plank(name,w,h,d,c,mat='body',vertical=False,bevel=.002):return F.ROOT.wood_uv(F.board(name,mat,w,h,d,c,bevel),vertical)
def shift(parts,x=0,y=0,z=0):
 for g in parts:g['_vertices']=[(a+x,b+y,c+z)for a,b,c in g['_vertices']]
 return parts

def oriented_poly(name,p,th,c,plane='xy',mat='body'):
 g=extrude_xy(name,mat,p,-th/2,th/2)
 if plane=='yz':g['_vertices']=[(z,y,x)for x,y,z in g['_vertices']]
 elif plane=='xz':g['_vertices']=[(x,z,y)for x,y,z in g['_vertices']]
 g['_vertices']=[tuple(np.array(v)+np.array(c))for v in g['_vertices']];return F.ROOT.wood_uv(g,plane!='xz')

def fit_piece(parts,w,h,d):
 v=np.concatenate([g['_vertices']for g in parts]);lo=v.min(0);hi=v.max(0);c=np.array([(lo[0]+hi[0])/2,lo[1],(lo[2]+hi[2])/2]);scale=np.array([w,h,d])/(hi-lo)
 for g in parts:g['_vertices']=[tuple((np.array(a)-c)*scale)for a in g['_vertices']]
 return parts

def fasteners(points,axis='x'):
 p=[]
 for i,c in enumerate(points):
  v=np.zeros(3);v['xyz'.index(axis)]=.0015;p.append(F.tube('separate-visible-round-fastener-'+str(i),'hardware',[np.array(c)-v,np.array(c)+v],.0033,sides=16))
 return p

def child_chair():
 p=[plank('rounded-front-seat-panel',.31,.021,.28,(0,.248,0),bevel=.008)]
 for x in[-.167,.167]:
  p.append(plank('long-rear-square-upright',.026,.45,.027,(x,.225,-.137),vertical=True,bevel=.005))
  p.append(plank('short-front-square-leg',.026,.25,.027,(x,.125,.137),vertical=True,bevel=.005))
  p.append(plank('side-seat-apron',.022,.041,.28,(x,.232,0),bevel=.005))
 p.append(F.tube('one-round-backrest-rail','body',[(-.167,.435,-.137),(.167,.435,-.137)],.009,sides=24))
 p+=fasteners([(x,y,z)for x in[-.182,.182]for y,z in[(.247,.137),(.435,-.137)]])
 return p,['Own child chair: two tall rear posts, two short front legs, one round back rail and softly rounded flat seat','45cm full height,36cm overall width,31cm depth; local seat height and sections photo estimated','Only beige actualSKU chair; other coloured chairs/toys in the gallery excluded'],{'back_rail_count':1,'leg_count':4,'seat_height_cm_photo_estimated':25.8}

def child_desk():
 p=[]
 for x in[-.310,.310]:
  for z in[-.23,.23]:p.append(plank('separate-rounded-corner-square-leg',.030,.45,.030,(x,.225,z),vertical=True,bevel=.007))
 p.append(plank('main-writing-top',.590,.017,.384,(0,.439,.043),bevel=.005))
 # Open rear pencil trough is an actual storage recess, with bottom and three finite walls.
 p.append(plank('empty-rear-pencil-tray-bottom',.590,.010,.080,(0,.405,-.192),bevel=.001))
 p.append(plank('rear-pencil-trough-wall',.590,.050,.012,(0,.425,-.236),bevel=.002))
 for x in[-.309,.309]:p.append(plank('long-side-apron-and-tray-end',.022,.050,.472,(x,.425,0),bevel=.005))
 p.append(plank('front-support-apron',.590,.040,.018,(0,.422,.229),bevel=.003));p.append(plank('rear-under-tray-stretcher',.590,.018,.020,(0,.351,-.228),bevel=.003));p+=fasteners([(x,y,z)for x in[-.325,.325]for y,z in[(.431,-.23),(.420,.23),(.351,-.23)]])
 return p,['Own65×50×45cm children desk, four actual legs, broad writing top and empty rear pencil compartment','Rounded post fronts/assembly fasteners and separate rear low stretcher; no generic closed cube','Source pencils, phone/music toy, chair and hanging props excluded'],{'open_pencil_trough':True,'leg_count':4,'local_trough_depth_photo_estimated':True}

def finger_front(w,h,y0,z,mat='body',count=0):
 # The centre finger recess is cut into the real top edge, not painted dark.
 half_opening=w*.42
 p=[(-w/2,0),(w/2,0),(w/2,h),(half_opening,h)]
 for a in np.linspace(0,math.pi,70):p.append((half_opening*math.cos(a),h-.017*math.sin(a)))
 p.append((-w/2,h));return oriented_poly('actual-front-panel-with-cut-finger-recess',p,.014,(0,y0,z),mat=mat)

def child_bench():
 p=[]
 for x in[-.285,.285]:
  p.append(plank('full-height-back-corner-post',.030,.45,.030,(x,.225,-.140),vertical=True,bevel=.006));p.append(plank('short-front-corner-post',.030,.279,.030,(x,.1395,.140),vertical=True,bevel=.006))
 for x in[-.278,.278]:p.append(plank('actual-empty-storage-side-wall',.014,.206,.257,(x,.160,0),bevel=.002))
 p+=[plank('actual-empty-storage-bottom',.55,.013,.267,(0,.061,0),bevel=.002),plank('actual-storage-back-wall',.55,.206,.014,(0,.160,-.132),bevel=.002),finger_front(.55,.206,.057,.133),plank('separate-closed-lifting-seat-lid',.548,.014,.267,(0,.274,0),bevel=.005),F.tube('round-full-width-backrest','body',[(-.285,.436,-.140),(.285,.436,-.140)],.009,sides=24)]
 p+=fasteners([(x,y,z)for x in[-.301,.301]for y,z in[(.435,-.14),(.252,.14),(.071,.14)]])
 # Hidden hinge is still present; toys and source strap are not decorative geometry.
 p.append(plank('small-real-rear-lid-hinge',.13,.008,.018,(0,.267,-.128),mat='hardware',bevel=.001))
 return p,['Own60×31cm storage bench,45cm total including the backrest and28cm seat/lid height','Four separate corner posts, one round backrest, truly empty finite-wall chest and independent closed hinged lid','Physical centre finger cutout and fasteners; no frog/bear/toy/styled blanket'],{'official_seat_height_cm':28,'official_total_height_cm':45,'lid_pose':'closed','storage_has_real_interior':True}

COFFEE_BEAN=[(-.50,-.08),(-.43,-.35),(-.10,-.49),(.24,-.42),(.48,-.18),(.50,.10),(.36,.42),(.00,.46),(-.28,.32),(-.44,.27)]
WAVE_DOUBLE=[(-.50,-.42),(-.42,-.50),(.40,-.50),(.50,-.40),(.48,.20),(.36,.43),(.15,.37),(-.04,.34),(-.25,.50),(-.45,.40)]
IRREG=[(-.50,-.12),(-.43,-.40),(-.20,-.49),(.12,-.48),(.40,-.33),(.50,-.02),(.43,.31),(.20,.45),(-.03,.35),(-.31,.44),(-.47,.23)]
def shape_top(name,w,d,y,h,points,mat='body'):
 p=G.H.M.curve(points,w,d,256);p[:,1]-=d/2;mb=G.H.M.G.Builder();mb.slab(name,mat,p,y,y+h,min(.0025,h/4));g=list(mb.groups.values())[0];g['_vertices']=[(x,z,y)for x,y,z in g['_vertices']];return F.ROOT.wood_uv(g,False)

def coffee_mango():
 p=[shape_top('own-long-bean-solid-mango-top',.981,.548,.324,.024,COFFEE_BEAN)]
 for x,z,a in[(-.34,-.13,0),(-.25,.14,.25),(.29,-.15,-.12),(.35,.12,.15)]:
  g=plank('one-of-four-broad-mango-leg-blades',.115,.327,.045,(0,.1635,0),vertical=True,bevel=.010);g['_vertices']=[(xx*math.cos(a)+zz*math.sin(a)+x,yy,-xx*math.sin(a)+zz*math.cos(a)+z)for xx,yy,zz in g['_vertices']];p.append(g)
 return p,['Own98.1×54.8×34.8cm asymmetrical mango coffee table','Irregular bean top with round finite edge and four broad slightly oriented blade legs','Own natural/dark wood pigment and grain interpretation; no source sofa/book/cups'],{'leg_count':4,'local_leg_positions_and_top_outline_photo_interpreted':True}

def metal_bedside():
 p=[F.board('actual-top-metal-sheet','body',.35,.0025,.35,(0,.47875,0),.0007),F.board('actual-lower-metal-sheet','body',.346,.0025,.348,(0,.281,0),.0006)]
 for s in[-1,1]:p.append(F.board('one-of-two-side-metal-sheets','body',.0025,.197,.35,(s*.17375,.38,0),.0006))
 for x in[-.163,.163]:
  for z in[-.162,.162]:p.append(F.tube('separate-round-long-painted-metal-leg','body',[(x,.003,z),(x,.282,z)],.0048,sides=16));p.append(F.tube('separate-black-floor-cap','foot',[(x,0,z),(x,.005,z)],.0051,sides=16))
 return p,['Own35×35×48cm metal bedside, genuinely open back/front cabinet and four long round legs','Finite metal top/bottom/side walls, small rounded edges and separate dark floor protectors','Other yellow/green tables and styled source objects excluded'],{'open_back':True,'leg_count':4,'local_shelf_height_photo_estimated':True}

def mango_stool():
 p=[plank('wide-softened-solid-mango-seat',.37,.023,.30,(0,.3785,0),bevel=.008)]
 for s in[-1,1]:
  poly=[(-.135,0),(.135,0),(.105,.356),(-.105,.356)];g=oriented_poly('one-of-two-splayed-wide-mango-leg-panels',poly,.028,(0,0,0),plane='xy');g['_vertices']=[(s*(.145-y*.11)+z,y,x)for x,y,z in g['_vertices']];p.append(g)
 p.append(plank('under-seat-central-cross-brace',.27,.025,.055,(0,.350,0),bevel=.006))
 return p,['Own37×30×39cm mango stool with two wide outward-splayed solid panels','Rounded top and real small under-seat cross brace; local foot taper and material grain photo interpreted','Source hanging cloth excluded'],{'broad_leg_panel_count':2,'local_splay_angle_photo_estimated':True}

def scalloped_apron(w,h,count,name,notch=False,amplitude=None):
 rad=w/(2*count);p=[(-w/2,h)]
 depth=rad if amplitude is None else amplitude
 if notch:
  p.append((-.080,h))
  p.extend((.080*math.cos(a),h-.017*math.sin(a))for a in np.linspace(math.pi,0,50)[1:])
 p.extend([(w/2,h),(w/2,depth)])
 for i in reversed(range(count)):
  cx=-w/2+(i+.5)*2*rad
  for a in np.linspace(0,math.pi,22):p.append((cx+rad*math.cos(a),depth-depth*math.sin(a)))
 clean=[]
 for v in p:
  if not clean or np.linalg.norm(np.array(v)-clean[-1])>1e-8:clean.append(v)
 return extrude_xy(name,'body',clean,-.008,.008)

def scallop_desk_set():
 p=[plank('actual-independent-lifting-desk-lid',.65,.018,.40,(0,.511,0),bevel=.006),plank('empty-under-lid-storage-floor',.59,.014,.35,(0,.436,0),bevel=.002)]
 for x in[-.300,.300]:
  for z in[-.177,.177]:p.append(F.tube('one-of-four-round-desk-legs','body',[(x,0,z),(x,.502,z)],.014,sides=24))
 for z in[-.181,.181]:p.append(shift([scalloped_apron(.615,.086,9,'actual-scalloped-front-and-rear-apron')],y=.418,z=z)[0])
 for x in[-.309,.309]:
  g=scalloped_apron(.365,.086,5,'actual-scalloped-side-apron');g['_vertices']=[(x+z,y+.418,xx)for xx,y,z in g['_vertices']];p.append(g)
 # Stool is a separate actual set piece: eight-petal flower seat and four splayed round legs.
 stool=[];pr=[]
 for y,r in[(.265,.137),(.268,.142),(.287,.142),(.29,.137)]:pr.append(([(math.cos(a)*(r+.008*math.cos(a*8)),math.sin(a)*(r+.008*math.cos(a*8)))for a in np.linspace(0,T,256,endpoint=False)],y))
 stool.append(G.capped('separate-eight-petal-flower-stool-seat','body',pr,True,.20))
 for a in np.arange(4)*math.pi/2+math.pi/4:stool.append(F.tube('one-of-four-splayed-stool-legs','body',[(math.cos(a)*.121,0,math.sin(a)*.121),(math.cos(a)*.070,.270,math.sin(a)*.070)],.013,sides=20))
 p=fit_piece(p,.65,.52,.40);stool=fit_piece(stool,.30,.29,.30);p+=shift(stool,x=.28,z=.38)
 return p,['Actual complete two-piece children desk and flower stool set','Desk65×40×52cm with empty finite storage and real downward scalloped aprons; stoolD30×H29cm with eight-petal seat and four real legs','Stool scene placement is estimated; no pencils/books/phone props'],{'set_quantity':2,'set_piece_dimensions_whd_cm':[[65,52,40],[30,29,30]],'display_pose_estimated':True,'stool_petal_count':8}

def capsule_coffee():
 p=[plank('single-capsule-rounded-painted-MDF-top',1,.022,.50,(0,.289,0),bevel=.012)]
 # End caps are a true stadium outline, not just a square with small corner fillets.
 points=np.array([(math.cos(a)*.25+(.25 if math.cos(a)>0 else-.25),math.sin(a)*.25)for a in np.linspace(0,T,256,endpoint=False)]);mb=G.H.M.G.Builder();mb.slab('own-oval-stadium-top','body',points,.278,.30,.003);g=list(mb.groups.values())[0];g['_vertices']=[(x,z,y)for x,y,z in g['_vertices']];p=[F.ROOT.wood_uv(g,False)]
 for x in[-.335,.335]:
  for z in[-.11,.11]:p.append(plank('one-of-four-thin-blade-legs',.12,.280,.025,(x,.14,z),vertical=True,bevel=.006))
 return p,['Own100×50×30cm painted oval/capsule coffee table','One true stadium top and four independent narrow flat blade legs','No book/bowl or surrounding furniture; local leg positions/thickness photo estimated'],{'leg_count':4,'top_is_true_stadium':True}

def irregular_metal_set():
 p=[]
 for i,(w,d,h,cx,cz)in enumerate([(.577,.456,.46,-.16,-.03),(.37,.31,.40,.29,.22)]):
  item=[];g=shape_top('separate-asymmetrical-set-table-top-'+str(i),w,d,h-.003,.003,IRREG);item.append(g)
  for a in[.55,2.55,4.65]:
   sx,sz=math.cos(a),math.sin(a);item.append(F.tube('one-of-three-splayed-set-table-legs-'+str(i),'body',[(sx*w*.42,.003,sz*d*.40),(sx*w*.28,h-.003,sz*d*.27)],.0065,sides=18))
  p+=shift(fit_piece(item,w,h,d),x=cx,z=cz)
 return p,['Both own asymmetrical metal side tables with three separately splayed legs each','Large57.7×45.6cm,H46cm; small37×31cm,H40cm; both complete physical objects','Relative display arrangement is estimated, not one manufacturer overall size'],{'set_quantity':2,'set_piece_dimensions_whd_cm':[[57.7,46,45.6],[37,40,31]],'display_pose_estimated':True,'total_leg_count':6}

def wave_double(pid):
 w,h,d=(1.02,.50,.32)if pid=='1226037002'else(1.10,.74,.53);p=[]
 lower=.205 if pid=='1226037002'else h-.110
 for y,th in[(h-.017,.017),(lower,.014)]:p.append(shape_top('separate-own-wave-upper-or-lower-surface',w,d,y,th,WAVE_DOUBLE))
 for x,z in[(-w*.39,-d*.21),(-w*.35,d*.28),(w*.36,-d*.27),(w*.38,d*.25)]:
  p.append(B.lathe('one-of-four-slim-tapered-round-wood-legs','body',[(0,0),(.010,0),(.015,h-.014),(0,h-.014)],48,False,offset=(x,0,z)))
 return p,['Two distinct thin own irregular wave-plan surfaces and four separate tapered round legs','Own long wavy footprint and small open document storage gap; finite softened edges','No source lamp, books, cups, chair or platter'],{'surface_count':2,'leg_count':4,'console_depth_cm_photo_estimated':32 if pid=='1226037002'else None,'local_open_gap_and_leg_positions_photo_estimated':True}

def scallop_chest():
 w=.62;d=.38;h=.33;p=[plank('actual-separate-storage-lid',w,.017,d,(0,.3215,0),bevel=.005),plank('actual-empty-storage-bottom',.583,.012,.343,(0,.045,0),bevel=.001)]
 for z in[-.181,.181]:
  g=scalloped_apron(.62,.313,8,'physical-eight-shallow-scallops-front-rear-wall',notch=z>0,amplitude=.018);p+=shift([g],z=z)
 for x in[-.302,.302]:
  g=scalloped_apron(.36,.313,5,'physical-five-shallow-scallops-side-wall',notch=True,amplitude=.018);g['_vertices']=[(x+z,y,xx)for xx,y,z in g['_vertices']];p.append(g)
 # Separate recessed finger slot gap is physical between lid and narrow front wall; hinge remains hidden inside.
 p.append(plank('small-real-lid-hinge',.12,.006,.022,(0,.307,-.168),mat='hardware',bevel=.001))
 return p,['Own62×38×33cm solid wooden storage chest/bench with genuinely empty interior','Own shallow eight-lobe front lower edge, five-lobe sides, visible front/side finger cutouts and separate softly rounded closed lid','No styling baskets; unseen rear scallops/side symmetry and concealed hinge interpreted'],{'real_empty_storage_interior':True,'lid_pose':'closed','scalloped_wall_edges':True,'front_scallop_lobes':8,'scallop_relief_cm_photo_estimated':1.8}

def round_blade_stool():
 p=[B.lathe('thick-round-sculpted-solid-wood-seat','body',[(0,.348),(.137,.348),(.149,.355),(.150,.389),(.146,.4),(0,.4)],192,False)]
 for a in np.arange(3)*T/3:
  g=oriented_poly('one-of-three-splayed-tapered-blade-stool-legs',[(-.075,0),(.075,0),(.034,.345),(-.034,.345)],.025,(0,0,0));g['_vertices']=[(x*math.cos(a)+(z+.095-y*.14)*math.sin(a),y,-x*math.sin(a)+(z+.095-y*.14)*math.cos(a))for x,y,z in g['_vertices']];p.append(g)
 return p,['Own30cm round thick seat,40cm stool height and three broad splayed blade legs','Rounded thick seat edge and tapering finite wide leg panels; own dark wood or black paint','No source books or decor'],{'blade_leg_count':3,'depth_cm_photo_estimated':30,'local_seat_and_leg_sections_photo_estimated':True}

def tambour_bedside():
 p=[plank('rounded-top-board',.46,.018,.27,(0,.591,0),bevel=.012),plank('rounded-bottom-board',.46,.018,.27,(0,.242,0),bevel=.012),plank('rear-finite-enclosure-panel',.40,.34,.012,(0,.414,-.123),vertical=True,bevel=.003),plank('empty-interior-shelf',.393,.012,.217,(0,.406,0),bevel=.001)]
 for x in[-.185,.185]:
  for z in[-.100,.100]:p.append(F.tube('separate-painted-round-metal-leg','hardware',[(x,0,z),(x,.235,z)],.0055,sides=16))
 for z in[-.10,.10]:p.append(F.tube('real-lower-leg-stretcher','hardware',[(-.185,.112,z),(.185,.112,z)],.0038,sides=14))
 # Real vertical tambour staves wrap around the curved side corners; closed-door display.
 path=[]
 for a in np.linspace(math.pi/2,math.pi,19):path.append((-.19+.04*math.cos(a),.093+.04*math.sin(a)))
 path +=[(x,.133)for x in np.linspace(-.19,.19,56)]
 for a in np.linspace(0,math.pi/2,19):path.append((.19+.04*math.cos(a),.093+.04*math.sin(a)))
 for sx in[-1,1]:path +=[(sx*.228,z)for z in np.linspace(-.112,.087,32)]
 for i,(x,z)in enumerate(path):p.append(plank('individual-physical-vertical-tambour-stave-'+str(i),.0049,.331,.010,(x,.414,z),vertical=True,bevel=.002))
 p.append(plank('recessed-continuous-closed-tambour-backing',.419,.331,.006,(0,.414,.119),vertical=True,bevel=.002))
 for sx in[-1,1]:p.append(plank('concealed-finite-side-wall-behind-tambour',.006,.331,.228,(sx*.219,.414,-.002),vertical=True,bevel=.001))
 for x in[-.008,.008]:p.append(plank('separate-long-vertical-door-pull',.006,.300,.010,(x,.414,.143),vertical=True,bevel=.003))
 return p,['Own46×27×60cm rounded tambour-door bedside cabinet','Individual real vertical pine slats wrap the rounded front sides, paired slim door pulls, interior shelf, four steel legs and stretchers','Closed-door pose; no source props or fake embossed photo of doors'],{'individual_tambour_staves':len(path),'door_count':2,'leg_count':4,'local_stave_width_and_tracks_photo_estimated':True}

S={}
def add(pid,name,dims,fn,col,rgb,pi=0,kind='wood',**kw):S[pid]=dict(name=name,dims=dims,build=fn,primary_index=pi,materials={'body':(kind,rgb,.47),'hardware':('metal',[135,136,130],.27)},color=col,note=kw.pop('note','Resmî dış ölçüler korunur. KendiSKU fotoğraflarından izlenen parça sayısı, yumuşak kenar, levha/ayak kalınlığı, bağlantı ve doğal ahşap damar dizilimi fotoğraf yorumudur; üretici CAD değildir. Aksesuarlar ve başka SKU renkleri dahil değildir.'),**kw)
add('0801287004','Jaluzi kapaklı ahşap komodin',[46,60,27],tambour_bedside,'Siyah',[32,31,28],kind='wood');S['0801287004']['materials']['hardware']=('paint',[25,25,24],.45)
add('1038907001','Yuvarlak sırt çıtalı çocuk sandalyesi',[36,45,31],child_chair,'Açık bej',[224,216,194],kind='paint')
add('1038909001','Kalem bölmeli çocuk çalışma masası',[65,45,50],child_desk,'Açık bej',[224,216,194],pi=1,kind='paint')
for pid,col,rgb in[('1038910001','Açık bej',[224,216,194]),('1038910002','Yeşil',[137,164,142]),('1038910004','Gri',[94,97,102])]:add(pid,'Sırtlıklı sandık çocuk bankı',[60,45,31],child_bench,col,rgb,pi=0 if pid=='1038910001'else 2 if pid=='1038910002'else 3,kind='paint',official={'width_cm':[60],'depth_cm':[31],'total_height_including_back_cm':[45],'seat_height_cm':[28]},note='KendiSKU açıklaması oturma yüksekliği28cm ve sırt dahil toplam45cm der; ikisi ayrı korunur. Resmî60×31cm plan ve45cm toplam modele aktarılır. Gerçek boş sandık, kapalı ayrı kapak, parmak kesimi ve yuvarlak sırt çıtası fotoğrafa özeldir. Yerel parçalar/kalınlık tahmindir; oyuncaklar dahil değildir.')
for pid,col,rgb in[('1059079001','Koyu kahverengi',[106,76,48]),('1059079015','Doğal kahverengi',[158,112,68])]:add(pid,'Asimetrik mango ahşap orta sehpa',[98.1,34.8,54.8],coffee_mango,col,rgb,pi=1 if pid=='1059079001'else 0,official={'length_cm':[98.1],'width_cm':[54.8],'height_cm':[34.8]},official_hwd=[34.8,None,None],estimated_axes=['official_length_mapped_to_X'])
add('1108354004','Açık bölmeli metal komodin',[35,48,35],metal_bedside,'Açık bej',[217,196,151],pi=1,kind='paint',official={'unlabelled_plan_cm':['35×35'],'height_cm':[48]})
S['1108354004']['materials']['foot']=('paint',[27,27,26],.8)
add('1206311001','İki geniş ayaklı mango tabure',[37,39,30],mango_stool,'Koyu kahverengi',[62,37,23],pi=1)
add('1206767001','Dalgalı kenarlı çocuk masası ve çiçek tabure', [1,1,1],scallop_desk_set,'Kahverengi',[149,81,42],official={'desk_width_cm':[65],'desk_depth_cm':[40],'desk_height_cm':[52],'stool_diameter_cm':[30],'stool_height_cm':[29]},official_hwd=[None,None,None],estimated_axes=['set_display_arrangement_bounds'],note='İki gerçek set parçası: resmî65×40×52cm masa ve30cmçap×29cmH tabure. Masa saklama boşluğu/kapalı kapak, dört ayak, aşağıdalgalı önlükler ve8yapraklı tabure ayrı geometri. Sahne dış zarfı parça ölçüsü değildir; göreli yerleşim tahminidir. Desen, kitap veya oyuncak bake edilmez.')
add('1206850002','Oval boyalı ahşap orta sehpa',[100,30,50],capsule_coffee,'Açık bej',[219,210,190],pi=0,kind='paint',official={'length_cm':[100],'depth_cm':[50],'height_cm':[30]})
add('1221137005','İkili asimetrik metal sehpa seti',[1,1,1],irregular_metal_set,'Siyah',[25,26,27],pi=2,kind='paint',official={'large_dimensions_lwh_cm':[57.7,45.6,46],'small_dimensions_lwh_cm':[37,31,40]},official_hwd=[None,None,None],estimated_axes=['set_display_arrangement_bounds'],note='İki ayrı gerçek metal sehpa: büyük57,7×45,6cmH46, küçük37×31cmH40. Her parçada asimetrik tabla ve3eğik ayak var. Sahnenin toplam zarfı/yerleşimi tahmindir; tek ürün resmî ölçüsü olarak kullanılmaz.')
add('1226037002','İki katlı dalgalı ahşap konsol',[102,50,32],lambda:wave_double('1226037002'),'Kahverengi',[112,78,49],pi=1,official={'length_cm':[102],'height_cm':[50]},official_hwd=[50,None,None],estimated_axes=['depth_cm','length_mapped_to_X'],note='Resmî uzunluk102cm ve yükseklik50cm korunur;32cm derinlik kendi fotoğrafından tahmindir. İki ince dalgalı tabla, açık aralık ve dört konik yuvarlak ayak fiziksel; yerel profiller/kalınlık tahmin, dekorlar dahil değildir.')
add('1226038002','İki katlı dalgalı ahşap çalışma masası',[110,74,53],lambda:wave_double('1226038002'),'Kahverengi',[105,70,44],official={'width_cm':[110],'height_cm':[74],'depth_cm':[53]})
add('1254726001','Dalgalı alt kenarlı ahşap sandık bank',[62,33,38],scallop_chest,'Kahverengi',[159,90,49],pi=1)
for pid,col,rgb,kind in[('1332995002','Koyu kahverengi',[61,39,26],'wood'),('1332995004','Siyah',[24,23,22],'paint')]:add(pid,'Kalın yuvarlak oturaklı üç ayaklı tabure',[30,40,30],round_blade_stool,col,rgb,pi=0 if kind=='wood'else 1,kind=kind,official={'width_cm':[30],'height_cm':[40]},official_hwd=[40,30,None],estimated_axes=['round_depth_cm'])
# Actual set scene bounds are measured from its complete local arrangement, without distorting either official item.
for pid in['1206767001','1221137005']:
 parts,_,_=S[pid]['build']();v=np.concatenate([g['_vertices']for g in parts]);S[pid]['dims']=((v.max(0)-v.min(0))*100).tolist()
F.SPECS.update(S)
if __name__=='__main__':
 for pid in sys.argv[1:]or S:F.build(pid)
