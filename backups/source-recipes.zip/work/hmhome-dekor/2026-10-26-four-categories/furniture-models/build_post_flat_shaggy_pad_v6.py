"""ONE local V5 post refinement: lower long-hair crown only, exact pad/legs."""
from pathlib import Path
import sys,json,copy,hashlib,math
sys.dont_write_bytecode=True
import numpy as np
from revision_export_exact import export
P=Path(__file__).resolve().parent;R=P/'revisions/wood-stool-low-shaggy-envelope-v6'
OLD=P/'revisions/wood-stool-clumped-drape-v5/frozen-one-source-clumped-post-PILOT-v5-manifest.json'

def digest(a,kind='<f4'):return hashlib.sha256(np.asarray(a,dtype=kind).tobytes()).hexdigest()

def main():
    old=json.loads(OLD.read_text())[0];model=json.loads(Path(old['model_path']).read_text());hair=next(m for m in model['meshes']if'500-coherent-locks-16000'in m['name']);p=np.asarray(hair['positions'],dtype='float32').reshape(-1,3);before=p.copy();count=16000;stations=18;sides=3;nr=stations*sides;per=nr+2;assert len(p)==count*per
    v=p.astype(float).reshape(count,per,3);root=v[:,nr].copy();before_y=v[:,:,1].copy();delta=v[:,:,1]-root[:,None,1]
    # Smooth the spatial LOCK loft, not individual strand sections. A hard
    # ceiling flattened the first own trial like a cut plate; that trial was
    # rejected before freeze. Gaussian macro-loft has no flat clip or added
    # flyaway arches and preserves every original wavy free strand.
    parents=500;children=32;pr=root.reshape(parents,children,3).mean(1);peak=before_y.reshape(parents,children,per).max((1,2));distance=np.sum((pr[:,None,[0,2]]-pr[None,:,[0,2]])**2,axis=2);weights=np.exp(-distance/(2*.060**2));smoothed=weights@peak/weights.sum(1);target=.18*peak+.82*smoothed
    old_amplitude=np.maximum(.006,peak-pr[:,1]);new_amplitude=np.maximum(.006,target-pr[:,1]);gain=np.repeat(new_amplitude/old_amplitude,children);positive=delta>0;v[:,:,1]=root[:,None,1]+np.where(positive,delta*gain[:,None],delta)
    # Preserve the official total height through the existing natural curls,
    # without adding a high sentinel strand or moving/affine-fitting the body.
    dv=v[:,:,1]-root[:,None,1];up=dv>1e-10;normalization=float(np.min(np.where(up,(.46-root[:,None,1])/np.maximum(dv,1e-10),np.inf)));v[:,:,1]=root[:,None,1]+np.where(up,dv*normalization,dv);v[:,nr,1]=root[:,1]
    assert abs(v[:,:,1].max()-.46)<1e-9
    p=v.reshape(-1,3).astype('float32');assert np.array_equal(before[:,[0,2]],p[:,[0,2]])
    face=np.asarray(hair['indices']).reshape(-1,3);unique,weld=np.unique(p,axis=0,return_inverse=True);q=p[face].astype(float);area_normal=np.cross(q[:,1]-q[:,0],q[:,2]-q[:,0]);normal=np.zeros((len(unique),3))
    for j in range(3):np.add.at(normal,weld[face[:,j]],area_normal)
    normal/=np.linalg.norm(normal,axis=1)[:,None];hair['positions']=p.reshape(-1).tolist();hair['normals']=normal[weld].astype('float32').reshape(-1).tolist()
    after=v[:,:,1];percentiles=lambda x:{str(k):float(np.percentile(x,k))for k in[0,10,50,90,95,99,99.9,100]}
    proof=dict(source_parent_manifest=str(OLD),only_one_long_guard_mesh_changed=True,all_original_pad_four_wood_legs_and_short_underfur_geometry_unchanged=True,hair_XZ_positions_byte_identical=digest(before[:,[0,2]])==digest(p[:,[0,2]]),hair_UV_sha256_unchanged=digest(hair['uvs']),hair_indices_sha256_unchanged=digest(hair['indices'],'<u4'),individual_curls_cross_seat_flow_and_broken_drape_preserved=True,long_fibre_count=count,no_added_sentinel_strands_or_clipped_flat_ceiling=True,own_rejected_trial='Hard per-strand ceiling and24 added flyaways produced a flat-cut surface and visible arches; own nativeQA rejected before freeze, not delivered.',macro_loft_gaussian_sigma_m_photo_interpretation=.060,macro_peak_original_weight=.18,macro_peak_smoothed_weight=.82,official_height_preserving_positive_loft_normalization=normalization,before_all_long_hair_y_m_percentiles=percentiles(before_y),after_all_long_hair_y_m_percentiles=percentiles(after),macro_peak_sd_before_m=float(peak.std()),macro_peak_sd_smoothed_m=float(target.std()),source_complete=False,no_source_photo_changes=True)
    model['metadata'].update(source_fur_macro_lock_loft_spatially_smoothed=True,source_macro_loft_smoothing_sigma_m_photo_estimate=.060,no_added_flyaway_or_flat_clip=True);model['metadata']['scale_note']+=' V6tekpilotta yalnız uzun postun makro tutam tepe farkları6cmölçekli yumuşak alanla dengelendi; yatık akış ve serbest tekil kıvrımlar korunur. Sert üst düzlem veya ek yüksek tel yok. Gövde,4ayak,kısa underfur,ownPNG,uzun lif X/Z/UV/index baytları aynıdır. Yerel post loftu fotoğraf yorumudur.'
    export(R,old,model,[hair['name']],'own-wood-stool-low-cross-swept-shaggy-pad-envelope-v6',proof)

if __name__=='__main__':main()
