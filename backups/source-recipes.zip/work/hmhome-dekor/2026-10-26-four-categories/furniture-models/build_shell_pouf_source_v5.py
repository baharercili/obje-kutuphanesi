"""Own 1254723001: deep filled shell rolls and short plush, separate candidate."""
from pathlib import Path
import sys, math, json, copy, shutil
sys.dont_write_bytecode=True
import numpy as np
from PIL import Image,ImageFilter
import build_models as F
import build_last_soft_six as L
import build_continuous_u_pilot_v4 as C
P=Path(__file__).resolve().parent
R=P/'revisions/own-shell-pouf-deep-filled-rolls-v5'
OLD=P/'revisions/last-five-soft-technical-candidates-v4/frozen-own-last-five-TECHNICAL-candidates-visual-pending-manifest.json'
B=F.B;G=F.G;T=math.tau

def wall():
    path=L.smooth_path([(.214,.205),(.226,.120),(.218,-.015),(.172,-.137),(.094,-.177),(0,-.186),(-.094,-.177),(-.172,-.137),(-.218,-.015),(-.226,.120),(-.214,.205)],24)
    length=np.r_[0,np.cumsum(np.linalg.norm(np.diff(path,axis=0),axis=1))];u=length/length[-1]
    sides=64;v=[];uv=[];faces=[];tops=[]
    for i,(x,z) in enumerate(path):
        t=path[min(i+1,len(path)-1)]-path[max(i-1,0)];t/=np.linalg.norm(t);normal=np.array([-t[1],t[0]])
        rear=np.clip((.205-z)/.391,0,1);top=.284+.111*rear**.63
        # Each roll adds actual width to BOTH faces; valleys are not a wiggling
        # wall centreline. The six filled regions and five channels are visible
        # across the own source shell, including its lower arm ends.
        # Six back rolls are concentrated on the rear fan, rather than losing
        # half of them along the side arms where a frontal source cannot see.
        fan=np.clip((u[i]-.30)/.40,0,1);phase=5*fan;lobe=math.cos(math.pi*phase)**2
        top+=.006*lobe-.007*(1-lobe)**3;tops.append(top)
        for j in range(sides+1):
            a=(j%sides)*T/sides;cy=math.cos(a);sy=math.sin(a)
            y=.008+(top-.008)*(.5+.5*np.sign(cy)*abs(cy)**.60)
            rise=(y-.008)/(top-.008)
            # Strong, soft filled lobes above the seat, tapering toward the
            # lower welded base. Six roll crowns are C1/C2 smooth, not boxes.
            phase_y=5*np.clip((u[i]-.30+.025*(u[i]-.5)*(1-rise))/.40,0,1)
            filled=math.cos(math.pi*phase_y)**2
            half=.044+.027*filled**.55*(.35+.65*rise**.55)
            off=half*np.sign(sy)*abs(sy)**.72
            xx,zz=np.array([x,z])+normal*off
            v.append((xx,y,zz));uv.append((length[i]/.18,y/.18))
    for i in range(len(path)-1):
        for j in range(sides):
            a=i*(sides+1)+j;b=a+sides+1;faces.extend([(a,b,a+1),(a+1,b,b+1)])
    # Rounded filled end panels: no exposed flat rectangle at either arm tip.
    for endpoint,sgn in [(0,-1),(len(path)-1,1)]:
        boundary=[endpoint*(sides+1)+j for j in range(sides)]
        centre=np.array([path[endpoint,0],(.008+tops[endpoint])/2,path[endpoint,1]])
        tangent=path[min(endpoint+1,len(path)-1)]-path[max(endpoint-1,0)];tangent/=np.linalg.norm(tangent)
        outward=sgn*np.array([tangent[0],0,tangent[1]])
        original=np.asarray(v)[boundary]
        for scale in [.82,.56,.28]:
            ring=[]
            for q in original:
                q=centre+(q-centre)*scale+outward*.028*(1-scale*scale);ring.append(len(v));v.append(tuple(q));uv.append((q[0]/.18,q[1]/.18))
            for j in range(sides):
                k=(j+1)%sides;faces.extend([(boundary[j],boundary[k],ring[j]),(boundary[k],ring[k],ring[j])])
            boundary=ring
        ci=len(v);q=centre+outward*.028;v.append(tuple(q));uv.append((q[0]/.18,q[1]/.18))
        for j in range(sides):faces.append((boundary[j],boundary[(j+1)%sides],ci))
    return B.solid('own-six-plump-shell-rolls-five-deep-fan-channels-rounded-arm-ends','fabric',v,faces,uv)

def short_plush(parts):
    """Short dense free pile follows the actual shell, not a long radial halo."""
    rng=np.random.default_rng(1254723001+5);count=38000;stations=6;sides=3;nr=stations*sides;per=nr+2
    qq=[];nn=[];aa=[]
    for g in parts:
        g=G.H.orient(g);v=np.asarray(g['_vertices']);f=np.asarray(g['_faces']);q=v[f];n=np.cross(q[:,1]-q[:,0],q[:,2]-q[:,0]);a=np.linalg.norm(n,axis=1);n/=a[:,None];keep=n[:,1]>-.58;qq.append(q[keep]);nn.append(n[keep]);aa.append(a[keep])
    q=np.concatenate(qq);n=np.concatenate(nn);a=np.concatenate(aa);pick=rng.choice(len(q),count,p=a/a.sum());q=q[pick];n=n[pick];u=np.sqrt(rng.random(count));w=rng.random(count);root=(1-u)[:,None]*q[:,0]+(u*(1-w))[:,None]*q[:,1]+(u*w)[:,None]*q[:,2]
    flow=np.tile([0.,-1.,0.],(count,1));top=n[:,1]>.7;flow[top]=[.55,0,1.];flow-=n*(flow*n).sum(1)[:,None];flow/=np.linalg.norm(flow,axis=1)[:,None];cross=np.cross(n,flow);length=rng.uniform(.0025,.007,count);phase=rng.uniform(0,T,count);f=np.linspace(0,1,stations)
    c=root[:,None,:]-.0005*n[:,None,:]+n[:,None,:]*(length[:,None,None]*.82*np.sin(f*math.pi*.7)[None,:,None])+flow[:,None,:]*(length[:,None,None]*.58*f[None,:,None]);c+=cross[:,None,:]*(length[:,None,None]*.12*(np.sin(T*f[None,:]+phase[:,None])-np.sin(phase)[:,None])[:,:,None]*f[None,:,None])
    tt=np.gradient(c,axis=1);tt/=np.linalg.norm(tt,axis=2,keepdims=True);guide=np.broadcast_to([0.,1,0],tt.shape).copy();guide[abs(tt[:,:,1])>.9]=[1,0,0];span=np.cross(tt,guide);span/=np.linalg.norm(span,axis=2,keepdims=True);up=np.cross(tt,span);ang=np.arange(sides)*T/sides;radius=rng.uniform(.00012,.00028,count)[:,None]*(.5*(1-f)**.7+.025)[None,:];rings=c[:,:,None,:]+(span[:,:,None,:]*np.cos(ang)[None,None,:,None]+up[:,:,None,:]*np.sin(ang)[None,None,:,None])*radius[:,:,None,None];v=np.concatenate([rings.reshape(count,nr,3),c[:,:1],c[:,-1:]],1)
    local=[]
    for j in range(stations-1):
        for k in range(sides):
            a=j*sides+k;b=j*sides+(k+1)%sides;cc=a+sides;d=b+sides;local.extend([(a,cc,b),(b,cc,d)])
    for k in range(sides):local.extend([(nr,k,(k+1)%sides),(nr+1,nr-sides+(k+1)%sides,nr-sides+k)])
    faces=np.asarray(local)[None,:,:]+np.arange(count)[:,None,None]*per;trip=v.reshape(-1,3)[faces.reshape(-1,3)];vol=np.einsum('ij,ij->i',trip[:,0],np.cross(trip[:,1],trip[:,2])).reshape(count,-1).sum(1)/6;assert abs(vol).min()>1e-14;faces[vol<0]=faces[vol<0][:,:,[0,2,1]]
    uv=np.zeros((count,per,2));ru=rng.uniform(.004,.991,count);uv[:,:nr,0]=ru[:,None]+np.tile(np.arange(sides)/sides,stations)[None,:]*.003;uv[:,:nr,1]=np.repeat(f,sides)[None,:]+np.tile(np.sin(ang),stations)[None,:]*.0003;uv[:,nr:,0]=ru[:,None]+.001;uv[:,nr+1,1]=1
    parts.append(B.solid('own-short-close-dense-source-plush-38000-free-capped-fibres','pile',v.reshape(-1,3).tolist(),faces.reshape(-1,3).tolist(),uv.reshape(-1,2).tolist()));return parts

def build():
    base=L.plump_base('own-full-floor-supported-front-seat-within-arm-tips',.487,.399,.213,.006)
    # The source seat is set behind the arm fronts, rather than protruding past.
    parts=[base,wall()]
    for g in parts:
        C.physical_fabric_charts(g);g['_uvs']=[(a*.16/.18,b*.16/.18)for a,b in g['_uvs']]
    parts=short_plush(parts)
    return parts,['Own 1254723001 source96e5/b058/69a1/7db9: six physically full soft shell-roll regions concentrated on the back fan, five deep curved channels; filled rounded arm ends meet the seat front.','Short plush follows actual surfaces; no generic long fur halo, no printed seam shadows, no open shell. Own white guard-pigment map preserved, own native plush closeup supplies only the conformal undercoat grain.','Published approximate W55/H40cm kept. D49cm and local channel depth/roll phase/2.5–7mm plush are explicitly photo estimates, not maker CAD.'],dict(own_shell_roll_regions_photo_interpreted=6,deep_fan_channels=5,arm_end_panels_rounded=True,seat_not_forward_of_arm_tip=True,short_plush_independent_fibres=38000,local_short_pile_length_m_photo_estimate=[.0025,.007])

def materials(out,pid,defs,masters):
    old=next(e for e in json.loads(OLD.read_text())if e['sku']==pid);model=json.loads(Path(old['model_path']).read_text());mats=copy.deepcopy(model['materials']);mv=json.loads(Path(old['material_validation']).read_text());doc,bin=F.EX.read_glb(old['glb_path']);payload={}
    assert F.sha(old['glb_path'])==old['sha256']
    for im in doc['images']:
        v=doc['bufferViews'][im['bufferView']];b=bin[v.get('byteOffset',0):v.get('byteOffset',0)+v['byteLength']];payload[F.hashlib.sha256(b).hexdigest()]=b
    maps=[]
    for im in mv['maps']:
        dst=out/Path(im['path']).name;dst.write_bytes(payload[im['sha256']]);assert F.sha(dst)==im['sha256'];maps.append(dict(im,path=str(dst)))
    master=next(x for x in masters if'69a1846f94af'in x['path']);box=[1000,200,2024,1224];patch=Image.open(master['path']).convert('RGB').crop(box);raw=out/'fabric-native-own-short-plush-closeup.png';patch.save(raw);a=np.asarray(patch).astype(float);low=np.asarray(patch.filter(ImageFilter.GaussianBlur(24))).astype(float);rgb=np.clip(np.array([245,242,232])+(a-low)*.65,0,255).astype('uint8');grey=a.mean(2);blur=np.asarray(Image.fromarray(grey.astype('uint8')).filter(ImageFilter.GaussianBlur(2))).astype(float);height=(grey-blur)*.12;dy,dx=np.gradient(height);n=np.stack([-dx,-dy,np.ones_like(dx)],2);n/=np.linalg.norm(n,axis=2,keepdims=True);n=np.clip((n+1)*127.5,0,255).astype('uint8')
    for slot,arr in [('albedo',rgb),('normal',n)]:
        # Match the periodic boundary in the derived map, not the untouched crop.
        for axis in[0,1]:
            arr=arr.swapaxes(0,axis).copy()
            for k in range(20):
                t=(20-k)/20*.5;x=arr[k].astype(float);y=arr[-1-k].astype(float);mid=(x+y)/2;arr[k]=np.clip(x*(1-t)+mid*t,0,255);arr[-1-k]=np.clip(y*(1-t)+mid*t,0,255)
            arr=arr.swapaxes(0,axis)
        dst=out/('fabric-'+slot+'.png');Image.fromarray(np.tile(arr,(2,2,1)),'RGB').save(dst,optimize=True);maps=[m for m in maps if not(m['material']=='fabric'and m['slot']==slot)]+[dict(material='fabric',slot=slot,path=str(dst),sha256=F.sha(dst),native_resolution=[2048,2048])]
    mats['fabric'].update(normalScale=.55);mats['fabric']['extras'].update(own_photo_material_crop=True,photo_pixels_baked=True,native_resolution=[2048,2048],source_crop_native_resolution=[1024,1024],four_native_tiles_without_resampling=True,crop_provenance=str(out/'fabric-crop-provenance.json'));F.dump(out/'fabric-crop-provenance.json',dict(master=master['path'],master_sha256=master['sha256'],source_crop_pixel_box=box,native_crop_pixels=[1024,1024],output_pixels=[2048,2048],raw_crop=str(raw),raw_crop_sha256=F.sha(raw),no_upscale=True,native_tiles=[2,2],master_untouched=True,low_frequency_illumination_removed=True,undercoat_pigment_photo_interpreted=[245,242,232],physical_repeat_wh_m_photo_estimate=[.18,.18],method='Own short-plush closeup native crop. DERIVED residual removes low-frequency illumination; own microfibres retained,20px periodic edge blend and2x2 native pixel tiling without upscaling; no product contour/background.'))
    F.dump(out/'own-material-preservation-proof.json',dict(source_glb=old['glb_path'],source_glb_sha256=old['sha256'],own_guard_pigment_PNGbytes_identical=True,changed_maps=['fabric-albedo.png','fabric-normal.png'],maps=maps,source_PNGs_freshly_read=False,recovered_exact_own_map_bytes_from_frozen_GLB=True));return mats,maps

if __name__=='__main__':
    R.mkdir(parents=True,exist_ok=True)
    for name in ['original-image-masters.json','source-queue-117.json','source-master-freeze-503.json','audit_assets.py','make_contacts.py','batch_contacts.py','freeze_batch.py']:shutil.copyfile(P/name,R/name)
    (R/'source-evidence').mkdir(exist_ok=True);shutil.copyfile(P/'source-evidence/1254723001.json',R/'source-evidence/1254723001.json')
    sp=copy.deepcopy(L.S['1254723001']);sp['build']=build;sp['note']+=' V5 kaynak kabuk yorumu: derin dolgun6rulo/5kanal, yuvarlak kol uçları ve kısa yoğun peluş; oturum ön yüzü kol uçlarını aşmaz. Own post pigmenti korunur; kendi yakın planından türetilmiş yüzey tanesi fotoğraf yorumudur.'
    F.R=R;F.materials=materials;F.SPECS['1254723001']=sp;F.build('1254723001')
