"""Immutable exact-SKU latest review union. Root-held candidates remain outside it."""
from pathlib import Path
import json,hashlib,datetime
P=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
paths=['frozen-latest97-root-review-v3-manifest.json','frozen-finalwood-six-manifest.json','revisions/finalwood-two-v2/frozen-finalwood-two-v2-manifest.json','frozen-live-variants-eleven-manifest.json','revisions/rattan-two-v2/frozen-rattan-two-v2-prototypes-manifest.json','frozen-live-hard-nineteen-manifest.json'];held={'1096727005','1096727007','1338724001','1260559002'};rows={};inputs=[]
for name in paths:
 p=P/name;m=json.loads(p.read_text());inputs.append(dict(path=str(p),sha256=sha(p),count=len(m)))
 for e in m:
  if e['sku']in held:continue
  rows[e['sku']]=e
assert len(rows)==131
target=P/'frozen-latest131-root-review-v5-manifest.json';proof=P/'frozen-latest131-root-review-v5-proof.json';assert not target.exists()and not proof.exists();dump(target,list(rows.values()));dump(proof,dict(created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),manifest=str(target),manifest_sha256=sha(target),candidate_count=131,root_actual_accepted_via_parent_messages=112,new19_root_actual_pending=True,source_scope_complete=False,inputs=inputs,held_not_in_union=sorted(held|{'1107974001','1107975001','1161127001','1254736001','1260539001'}),no_assets_modified=True,sha_assurance='Input manifest JSONs freshly hashed. Older GLB/map/source bytes rely on their own frozen independent proof, not a claimed new full readback. New19 were freshly read back by their frozen independent QA. Parent owns actual Three acceptance.'))
dump(P/'root-review-inputs.json',dict(created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_scope_complete=False,candidate_count=131,root_actual_accepted_via_parent_messages=112,root_actual_pending_new_skus=[e['sku']for e in json.loads((P/'frozen-live-hard-nineteen-manifest.json').read_text())],manifests=[dict(manifest=str(target),manifest_sha256=sha(target),proof=str(proof),proof_sha256=sha(proof),count=131,skus=list(rows))],held_not_ready=sorted(held|{'1107974001','1107975001','1161127001','1254736001','1260539001'}),note='Only latest non-rejected immutable candidates; two superseded wood v1 entries and all root-held forms are excluded.97+4+2+8+1 root accepted,19 new pending.'))
scope=json.loads((P/'source-queue-165-current.json').read_text());working={e['sku']:e for e in json.loads((P/'manifest.json').read_text())};accepted=set(rows)-{e['sku']for e in json.loads((P/'frozen-live-hard-nineteen-manifest.json').read_text())};status=[]
for q in scope['products']:
 sku=q['sku'];e=rows.get(sku)or working.get(sku);stage='root_actual_accepted'if sku in accepted else'root_quality_hold'if sku in held|{'1107974001','1107975001','1161127001','1254736001','1260539001'}else'candidate_pending_native_or_root_review'if e else'pending_source_specific_geometry'
 status.append(dict(sku=sku,name=q['name'],status=stage,latest_model=e.get('model_path')if e else None,latest_glb_sha256=e.get('sha256')if e else None,source_identity_verified=q.get('identity_verified'),source_evidence=str(P/'source-evidence'/(sku+'.json'))))
dump(P/'all165-status.json',dict(source_scope_complete=False,model_scope_count=165,root_actual_accepted_count=len(accepted),rows=status,blocked_legacy_not_modeled=scope['blocked_products_not_modeled'],note='Actual acceptance relays parent messages; canonical integration count is not independently asserted. All165 exact photographed identities stay in scope.'))
print(target,sha(target),len(accepted),len(working),flush=True)
