"""Eighteen own-source stone shelves/tables and metal stands, exact SKU bindings."""
from pathlib import Path
import sys,json,math,shutil
sys.dont_write_bytecode=True
import numpy as np
from PIL import Image,ImageFilter
import build_models as F
from geometry_extra import extrude_xy
G=F.G;B=F.B;T=math.tau;R=F.R
BASEMAT=F.materials
CROPS={x['sku']:x for x in json.loads((R/'stone-crop-specs.json').read_text())}
def chart(g):
 v=np.asarray(g['_vertices']);lo=v.min(0);span=np.maximum(v.max(0)-lo,1e-4);vv=[];ff=[];uv=[]
 for tri in g['_faces']:
  a,b,c=v[list(tri)];axis=np.argmax(np.abs(np.cross(b-a,c-a)));axes=[i for i in range(3)if i!=axis];ids=[]
  for i in tri:ids.append(len(vv));vv.append(tuple(v[i]));u=(v[i]-lo)/span;uv.append((u[axes[0]],u[axes[1]]))
  ff.append(tuple(ids))
 g['_vertices']=vv;g['_faces']=ff;g['_uvs']=uv;return g

def stone_box(name,w,h,d,c,mat='stone',b=.002):return chart(F.board(name,mat,w,h,d,c,b))
def rotate_y(g,a,dx=0,dz=0):
 g['_vertices']=[(x*math.cos(a)+z*math.sin(a)+dx,y,-x*math.sin(a)+z*math.cos(a)+dz)for x,y,z in g['_vertices']];return g

def semicircle_shelf(pid):
 p=np.array([(.15*math.cos(a),-.075+.15*math.sin(a))for a in np.linspace(0,math.pi,192)])
 mb=G.H.M.G.Builder();mb.slab('own-semicircular-real-marble-slab','stone',p,.13,.15,.0014);g=list(mb.groups.values())[0];g['_vertices']=[(x,z,y)for x,y,z in g['_vertices']];parts=[chart(g)]
 prof=[(-.073,0),(-.073,.13),(.055,.13)]
 for t in np.linspace(0,1,80)[1:-1]:
  a=(1-t)**3*np.array([.055,.13])+3*(1-t)**2*t*np.array([.065,.04])+3*(1-t)*t*t*np.array([-.005,0])+t**3*np.array([-.073,0]);prof.append(tuple(a))
 h=extrude_xy('own-single-curved-steel-central-support','body',prof,-.0015,.0015);h['_vertices']=[(z,y,x)for x,y,z in h['_vertices']];parts.append(h)
 for x in[-.115,.115]:parts.append(F.board('own-small-rear-steel-mount-tab','body',.015,.025,.002,(x,.115,-.072),.002))
 return parts,['Real semicircular30×15cm marble slab and one independent broad curved stainless bracket','Finite slab thickness, two rear fixing tabs and source-specific stone; no vase/glass props','Bracket13cm and slab thickness/totalheight semantics retained separately'],{'total_height_cm_photo_estimated':15,'slab_thickness_cm_photo_estimated':2,'single_curved_bracket':True}

def rectangle_shelf():
 p=[stone_box('rounded-rectangular-real-marble-top',.35,.016,.15,(0,.052,0),b=.004),stone_box('separate-rear-stone-mounting-block',.30,.026,.018,(0,.037,-.062),b=.002)]
 for s in[-1,1]:p.append(stone_box('separate-real-stone-under-fin-'+str(s),.016,.050,.115,(s*.085,.025,-.008),b=.003))
 return p,['Own35×15cm rectangular marble slab with two separate underside support fins and rear mounting block','Soft finite rounded stone edges and native own-SKU stone sample','6cm overall height and all local thicknesses are photo estimates because source publishes only plan'],{'overall_height_cm_photo_estimated':6,'under_fin_count':2}

def cross_stone():
 p=[stone_box('soft-corner-square-marble-top',.30,.022,.30,(0,.409,0),b=.009),stone_box('full-depth-stone-cross-leg-A',.235,.398,.018,(0,.199,0),b=.003),stone_box('full-depth-stone-cross-leg-B',.018,.398,.235,(0,.199,0),b=.003)]
 return p,['Own30×30×42cm square marble side table','One rounded finite stone top on two perpendicular broad full-height stone slabs','Native actual-SKU stone sample on separate component charts; no room or styling pixels'],{'cross_leg_slabs':2,'local_top_and_leg_thickness_photo_estimated':True}

def u_leg(name,mat,w,h,th,cutdepth):
 p=[(-w/2,0),(w/2,0),(w/2,h),(w*.40,h)]
 for a in np.linspace(0,math.pi,90):p.append((w*.40*math.cos(a),h-cutdepth*math.sin(a)))
 p.append((-w/2,h));clean=[]
 for v in p:
  if not clean or np.linalg.norm(np.array(v)-clean[-1])>1e-8:clean.append(v)
 return extrude_xy(name,mat,clean,-th/2,th/2)

def curved_pine_stone():
 top=stone_box('soft-rounded-square-marble-top',.51,.019,.42,(0,.4305,0),b=.045);a=u_leg('real-curved-U-cut-pine-cross-leg-A','wood',.415,.421,.019,.325);b=rotate_y(u_leg('real-curved-U-cut-pine-cross-leg-B','wood',.350,.421,.019,.325),math.pi/2)
 return[top,F.ROOT.wood_uv(a,True),F.ROOT.wood_uv(b,True)],['Own51×42cm rounded dark marble top,44cm overall height','Two crossed pine panels with deep downward-curved U cutouts, four distinct tall outer leg ends','Own native dark stone veins retained without source sofa or container'],{'crossed_U_cut_wood_panels':2,'local_pine_cut_depth_and_thickness_photo_estimated':True}

def travertine_blocks():
 p=[stone_box('separate-real-travertine-top',.36,.026,.36,(0,.417,0),b=.004)]
 for x in[-.126,.126]:
  for z in[-.131,.131]:p.append(F.board('independent-chunky-stainless-block-leg','body',.083,.411,.062,(x,.2055,z),.002))
 return p,['Own36×36×43cm travertine and stainless steel table','Four separate chunky mirrored steel block legs, softly rounded stone top and real assembly gaps','Own native travertine, not a generic brown marble substitute; no lamp/staging'],{'independent_chunky_block_legs':4,'local_leg_dimensions_photo_estimated':True}

def mango_kidney():
 controls=[(-.50,.15),(-.48,-.20),(-.31,-.44),(.04,-.50),(.36,-.37),(.50,-.09),(.45,.16),(.20,.32),(.00,.30),(-.20,.40),(-.40,.44)]
 plan=G.H.M.curve(controls,.455,.35,256);plan[:,1]-=.175;mb=G.H.M.G.Builder();mb.slab('actual-asymmetric-kidney-marble-top','stone',plan,.438,.46,.003);g=list(mb.groups.values())[0];g['_vertices']=[(x,z,y)for x,y,z in g['_vertices']];p=[chart(g)]
 for x,z,a in[(-.132,.025,-.25),(.126,.042,.34),(.016,-.107,1.32)]:p.append(rotate_y(F.ROOT.wood_uv(F.board('separate-broad-rounded-mango-wood-leg','wood',.120,.439,.028,(0,.2195,0),.010),True),a,x,z))
 return p,['Own asymmetric kidney stone top, three separately oriented wide mango-wood blade legs','Published45.5cm long axis and35cm transverse axis,46cm height; own finite soft top edge','Natural stone and mango colours guided by this exact SKU; no bowl/cushion/sofa baked'],{'leg_count':3,'photo_local_leg_orientation_and_outline_interpreted':True,'long_axis_to_model_X_interpreted':True}

def cross_metal():
 p=[u_leg('own-perpendicular-scooped-metal-plate-A','body',.36,.455,.0024,.080),rotate_y(u_leg('own-perpendicular-scooped-metal-plate-B','body',.36,.455,.0024,.080),math.pi/2)]
 p.append(B.lathe('separate-round-metal-tray-between-raised-corners','body',[(0,.417),(.177,.417),(.180,.418),(.180,.423),(.178,.425),(.176,.425),(.176,.420),(0,.420)],256,False))
 for a in np.arange(4)*math.pi/2:p.append(F.tube('small-tray-retaining-lug','body',[(.174*math.cos(a),.415,.174*math.sin(a)),(.174*math.cos(a),.435,.174*math.sin(a))],.0027,sides=12))
 return p,['Own36cm round tray,45.5cm high cross-plate metal table','Two thin perpendicular broad sheets with curved scooped upper openings, four raised corners and real tray lugs','Own polished steel or black iron surface, no photographed room reflections'],{'crossed_scooped_plate_count':2,'separate_retained_round_tray':True,'local_sheet_thickness_and_tray_height_photo_estimated':True}

def pot_stand():
 y=.285;r=.106;wall=.0014
 # Radial hole passes through the true finite metal floor. Closed profile around the hole is a material shell.
 pot=B.lathe('open-metal-pot-with-real-bottom-drainage-hole','body',[(.004,y),(.103,y),(.105,y+.001),(.106,y+.228),(.107,y+.229),(.106,y+.23),(.1045,y+.23),(.104,y+.228),(.1036,y+.0025),(.004,y+.0025)],256,True)
 tray=B.lathe('separate-recessed-metal-stand-saucer','body',[(0,.280),(.109,.280),(.111,.281),(.111,.300),(.1095,.300),(.1095,.282),(0,.282)],256,False);p=[pot,tray]
 for a in np.arange(4)*math.pi/2+math.pi/4:
  sx,sz=math.cos(a),math.sin(a);p.append(F.tube('separate-curved-stand-leg','body',[(sx*.076,0,sz*.076),(sx*.076,.252,sz*.076),(sx*.075,.270,sz*.075),(sx*.063,.280,sz*.063)],.004,sides=16))
 for a in[math.pi/4,math.pi*3/4]:p.append(F.tube('separate-low-cross-stretcher','body',[(math.cos(a)*.076,.053,math.sin(a)*.076),(-math.cos(a)*.076,.053,-math.sin(a)*.076)],.0023,sides=12))
 return p,['Own removable metal pot:D21.2×H23cm and independent stand/saucer:D22.2×H30cm','Real open mouth, finite wall/floor, through drainage hole, saucer lip, four bent round legs and two cross stretchers','Approx51.5cm assembled height includes estimated pot inset; other pots shown in styling are excluded'],{'included_pot_count':1,'included_stand_count':1,'real_drainage_hole':True,'assembled_height_cm_estimated':51.5,'pot_inset_depth_cm_estimated':1.5}

def stainless_cube():
 # The own source really is a mirrored cubic plinth; a finite beveled shell models its actual seams.
 p=[F.board('actual-mirrored-top-sheet','body',.35,.0014,.35,(0,.4493,0),.00045),F.board('actual-closed-underside-sheet','body',.348,.0014,.348,(0,.0007,0),.0004)]
 for s in[-1,1]:p.append(F.board('actual-side-steel-sheet-X','body',.0014,.448,.35,(s*.1743,.224,0),.0004));p.append(F.board('actual-side-steel-sheet-Z','body',.3472,.448,.0014,(0,.224,s*.1743),.0004))
 return p,['Own35×35×45cm mirror-polished steel cuboid plinth, as photographed','Six separate finite folded-sheet faces and tiny realistic softened edges; no source room reflection is printed','No vase/carafe/glass styling'],{'actual_geometry_is_rectangular_mirrored_plinth':True,'local_sheet_thickness_photo_estimated':True}

def magazine_table():
 p=[F.board('left-full-depth-finite-metal-side','body',.002,.55,.35,(-.199,.275,0),.0005),F.board('right-full-depth-finite-metal-side','body',.002,.55,.35,(.199,.275,0),.0005),F.board('actual-flat-metal-top','body',.398,.0025,.348,(0,.540,0),.0005)]
 # One large diagonal real shelf, lower front and higher rear, forms the photographed magazine pocket.
 g=F.board('real-tilted-integral-magazine-compartment','body',.396,.0022,.414,(0,0,0),.0005);angle=.79;g['_vertices']=[(x,y*math.cos(angle)-z*math.sin(angle)+.258,y*math.sin(angle)+z*math.cos(angle))for x,y,z in g['_vertices']];p.append(g)
 p.append(F.board('small-physical-front-magazine-stop','body',.396,.022,.002,(0,.100,.146),.0005))
 return p,['Own40×55×35cm sheet-metal table with two full flat side plates and thin top','One real broad diagonal interior shelf and small front retaining stop form the magazine pocket','Source book and writing explicitly excluded'],{'integrated_sloping_magazine_shelf':True,'local_sheet_and_stop_dimensions_photo_estimated':True}

def materials(out,pid,defs,masters):
 mats,maps=BASEMAT(out,pid,defs,masters)
 if pid not in CROPS:return mats,maps
 s=CROPS[pid];im=Image.open(s['derivative']).convert('RGB');rgb=np.asarray(im).copy();n=im.width;key='stone';assert any(x['sha256']==s['master']['sha256']for x in masters)
 raw=out/(key+'-native-donor.png');im.save(raw);grey=rgb.mean(2);low=np.asarray(Image.fromarray(grey.astype('uint8')).filter(ImageFilter.GaussianBlur(1.2))).astype(float);height=(grey-low)*.004;dy,dx=np.gradient(height);normal=np.stack([-dx,-dy,np.ones_like(dx)],2);normal/=np.linalg.norm(normal,axis=2,keepdims=True);orm=np.zeros((n,n,3),np.uint8);orm[:,:,0]=255;orm[:,:,1]=138 if pid=='1337811001'else 76
 for slot,a in[('albedo',rgb),('normal',np.clip((normal+1)*127.5,0,255).astype(np.uint8)),('orm',orm)]:
  f=out/(key+'-'+slot+'.png');Image.fromarray(a,'RGB').save(f,optimize=True);maps=[x for x in maps if not(x['material']==key and x['slot']==slot)];maps.append(dict(material=key,slot=slot,path=str(f),sha256=F.sha(f),native_resolution=[n,n]))
 provenance=dict(master=s['master']['path'],master_sha256=s['master']['sha256'],source_crop_pixel_box=s['box'],native_crop_pixels=[n,n],output_pixels=[n,n],raw_crop=str(raw),raw_crop_sha256=F.sha(raw),no_upscale=True,geometric_resampling_count=0,method='Visually reviewed exact-SKU stone-only native crop, no staging, backdrop or edge. Raw RGB pixels preserved. Separate face charts place the own intrinsic sample once per physical component; natural pattern phase/local scale are interpretation, not a maker scan.');F.dump(out/(key+'-crop-provenance.json'),provenance)
 mats[key].update(normalScale=.25,extras=dict(intrinsic_material=True,own_photo_material_crop=True,photo_pixels_baked=True,native_resolution=[n,n],crop_provenance=str(out/(key+'-crop-provenance.json')),baked_reflections=False,natural_pattern_placement_interpreted=True));return mats,maps
F.materials=materials
S={}
for pid in['0946597005','1360296001']:S[pid]=dict(name='Mermer tablalı orta destekli duvar rafı',dims=[30,15,15],build=lambda pid=pid:semicircle_shelf(pid),primary_index=0 if pid=='0946597005'else 1,materials={'stone':('own-stone',[190,175,161],.30),'body':('metal',[202,202,194],.25)},color='Açık kahverengi mermer'if pid=='0946597005'else'Koyu kahverengi mermer',official={'shelf_width_cm':[30],'shelf_depth_cm':[15],**({'bracket_height_cm':[13]}if pid=='0946597005'else{})},official_hwd=[None,30,15],estimated_axes=['overall_height_cm','slab_thickness_cm','bracket_height_cm'if pid=='1360296001'else'local_bracket_shape'],note='KendiSKU resmî30cm en ve15cm raf derinliği korunur.0946597005 metnindeki13cm braket yüksekliği ayrı; toplam15cm ve2cm taş kalınlığı fotoğraf tahminidir.1360296001 boyu yayımlanmadığından15cm toplamı fotoğraf tahminidir. Taş örneği yalnız kendiSKU JPEGinden, doğal damar fazı yorumdur; tek alt kanat/asma parçaları gerçektir.')
for pid,col in[('1299901002','Bej mermer'),('1299901003','Açık mermer')]:S[pid]=dict(name='İki destekli dikdörtgen mermer duvar rafı',dims=[35,6,15],build=rectangle_shelf,primary_index=0,materials={'stone':('own-stone',[214,202,183],.32)},color=col,official={'width_cm':[35],'depth_cm':[15]},official_hwd=[None,35,15],estimated_axes=['overall_height_cm'],note='Resmî35×15cm plan korunur.6cm toplam yükseklik,1,6cm tabla ve destek kalınlıkları kendi fotoğrafından tahmindir. İki ayrı taş alt kanat ve arka taşıyıcı gerçek geometri. Native kendi mermer örneğinin yerleşimi yorumdur, doğal tekil damar taraması değildir.')
for pid,col in[('1227422005','Bej'),('1227422009','Koyu kahverengi'),('1227422010','Açık yeşil')]:S[pid]=dict(name='Çapraz taş ayaklı kare mermer sehpa',dims=[30,42,30],build=cross_stone,primary_index=1 if pid!='1227422010'else 0,materials={'stone':('own-stone',[196,180,162],.30)},color=col,official={'length_cm':[30],'width_cm':[30],'height_cm':[42]},note='Resmî30×30×42cm dış zarf korunur. İki dik kesişen geniş taş levha ve yumuşak köşeli tabla ayrı kapalı geometri; kalınlıkları fotoğraf tahminidir. KendiJPEG native mermeri korunur; her doğal ürün farklı olduğundan faz ve damar ölçeği yorumdur.')
S['1254575001']=dict(name='Kavisli ahşap ayaklı mermer sehpa',dims=[51,44,42],build=curved_pine_stone,primary_index=2,materials={'stone':('own-stone',[64,46,33],.29),'wood':('wood',[57,34,23],.46)},color='Koyu kahverengi',note='Resmî51×44×42cm dış zarf korunur. Kavisli U boşluklu iki çapraz geniş çam levha, dört dış ayak ucu ve yuvarlak köşeli mermer tabla fotoğrafa özeldir. Yerel kesim eğrisi/kalınlık tahmini, taş doğal damar yerleşimi yorumudur; diğer mobilyalar dahil değildir.')
S['1337811001']=dict(name='Traverten tablalı çelik blok ayaklı sehpa',dims=[36,43,36],build=travertine_blocks,primary_index=1,materials={'stone':('own-stone',[188,149,110],.54),'body':('metal',[225,225,220],.10)},color='Traverten/gümüş',note='Resmî36×36×43cm korunur. Dört ayrı geniş paslanmaz çelik blok ayak,2,6cm traverten kalınlığı ve aralıklar kendi fotoğrafından yorumlandı. Taş malzeme metninde mermer de yazsa başlık travertendir; kaynak ikisi de korunur. Yansıma PBRyaklaşığı, doğal taş fazı yorumudur.')
for pid,col,rgb in[('1206454001','Bej/koyu kahverengi',[75,52,34]),('1206454002','Bej/kahverengi',[151,91,44])]:S[pid]=dict(name='Asimetrik mermer tablalı mango ahşap sehpa',dims=[45.5,46,35],build=mango_kidney,primary_index=1,materials={'stone':('own-stone',[210,195,170],.35),'wood':('wood',rgb,.49)},color=col,official={'length_cm':[45.5],'width_cm':[35],'height_cm':[46]},official_hwd=[46,None,None],estimated_axes=['long_length_axis_mapped_to_X'],note='Resmî uzunluk45,5cm,genişlik35cm,yükseklik46cm korunur; modelin Xeni uzunluk eksenine atanmıştır ve üreticinin Width etiketini sessizce değiştirmez. Üç farklı yönlenmiş geniş mango ayak, böbrek üst ve yerel kalınlık fotoğraf yorumudur. KendiSKU taşı native örnek, doğal damar fazı yorumudur.')
for pid,kind,rgb in[('1304431005','metal',[223,220,209]),('1304431008','paint',[21,22,22])]:S[pid]=dict(name='Kavisli çapraz metal levha ayaklı sehpa',dims=[36,45.5,36],build=cross_metal,primary_index=1 if kind=='metal'else 0,materials={'body':(kind,rgb,.18 if kind=='metal'else .38)},color='Gümüş rengi'if kind=='metal'else'Siyah',official={'diameter_cm':[36],'height_cm':[45.5]},note='Resmî36cm çap ve45,5cm yükseklik korunur. İki dik kavisli oyuk levha, dört yükseltilmiş uç, arada yuvarlak tepsi ve küçük tutucular kendi fotoğrafından fiziksel yorumdur. Yerel metal kalınlığı/tabla yüksekliği tahmin; oda yansıması bake edilmez.')
for pid,col,rgb in[('1314714001','Siyah',[21,22,22]),('1314714002','Açık bej',[215,208,180]),('1314714003','Zeytin yeşili',[83,89,53])]:S[pid]=dict(name='Uzun metal ayaklı saksı',dims=[22.2,51.5,22.2],build=pot_stand,primary_index=1 if pid!='1314714002'else 6,materials={'body':('paint',rgb,.39)},color=col,official={'pot_diameter_cm':[21.2],'pot_height_cm':[23],'stand_diameter_cm':[22.2],'stand_height_cm':[30]},official_hwd=[None,None,None],estimated_axes=['assembled_height_cm','pot_inset_depth_cm'],note='KendiSKU bir saksı+bir uzunayak içerir. Resmî saksı21,2cmçap×23cmH ve ayak22,2cmçap×30cmH ayrı korunur. İçte1,5cm oturma varsayımıyla toplam51,5cm fotoğraf tahminidir; resmîtoplam gibi sunulmaz. Gerçek boş iç hacim, taban tahliye deliği, tabak, dört ayak ve çaprazlar fiziksel; diğer boylar/bitkiler dahil değildir.')
S['1276543001']=dict(name='Ayna parlaklığında paslanmaz çelik kübik sehpa',dims=[35,45,35],build=stainless_cube,primary_index=1,materials={'body':('metal',[229,229,225],.075)},color='Gümüş rengi',official={'length_cm':[35],'width_cm':[35],'height_cm':[45]},note='Resmî35×35×45cm kübik form kaynakta aynen görülür. Altı ayrı sonlu kalınlıklı çelik yüz ve küçük gerçek pahlar kullanılır; fotoğraftaki oda yansımaları kaplamaya basılmaz. Metalin çevre yansıması fiziksel PBRönizlemede yaklaşık, kalınlık fotoğraf tahminidir.')
S['1337875001']=dict(name='Eğimli dergilik bölmeli metal sehpa',dims=[40,55,35],build=magazine_table,primary_index=1,materials={'body':('metal',[167,161,145],.49)},color='Fırçalı metal',note='Resmî40×55×35cm korunur. İki tam yan levha, ince üst tabla, gerçek geniş eğimli iç dergilik rafı ve ön tutucu ayrı kapalı parçalardır. Eğim/açı/saç kalınlığı fotoğraf yorumudur; dergi, kitap ve yazılar dahil değildir.')
F.SPECS.update(S)
if __name__=='__main__':
 for pid in sys.argv[1:]or S:F.build(pid)
