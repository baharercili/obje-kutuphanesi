from pathlib import Path
import json,re,hashlib,datetime
R=Path(__file__).resolve().parent;Q=json.loads((R/'source-queue-117.json').read_text());existing={r['sku']for r in Q['products']}|{r['sku']for r in Q['blocked_products_not_modeled']};allrows={};proof=[]
for name in ['root-de-hm-filter-page1.json','root-de-hm-filter-page2.json','root-de-hm-filter-page3.json','root-de-hm-home21-all.json',*[f'root-gb-hm-filter-page{i}-refresh.json'for i in range(1,5)],*[f'root-gb-photos-page{i}.json'for i in range(1,5)],*[f'root-de-photos-page{i}.json'for i in range(1,4)],'root-de-home-photos-all.json']:
 p=R.parent/'furniture-research'/name;x=json.loads(p.read_text());market='en_gb'if name.startswith('root-gb')else'de_de';cards=x.get('cards',x.get('products',[]));proof.append({'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'capture_date':x.get('captured_at','previous_category_capture_2026-10-26'),'market':market,'card_count':len(cards),'url':x.get('url'),'next':x.get('next',x.get('nextButtons'))})
 for i,c in enumerate(cards):
  skus=set(re.findall(r'productpage\.(\d{10})',json.dumps(c)))
  if len(skus)!=1:print('BAD',name,i,list(c));continue
  sku=next(iter(skus));allrows.setdefault(sku,{'sku':sku,'already_in_original120':sku in existing,'official_category_observations':[]});allrows[sku]['official_category_observations'].append({'source_file':str(p),'card_index':i,'card':c,'source_market':market,'captured_at':x.get('captured_at','2026-10-26_previous_capture')})
new=[dict(r,model_status='pending_exact_PDP_dimensions_material_gallery',root_approved=False)for r in allrows.values()if not r['already_in_original120']]
out={'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_scope_complete':False,'original117_handoff_sha256':Q['source_handoff_sha256'],'original120_including3blocked_unchanged':True,'uk_de_live_unique_skus':len(allrows),'new_sku_count':len(new),'category_proof':proof,'new_products':new,'all_uk_de_category_skus':list(allrows)}
(R/'live-uk-de-source-extension-2026-10-27.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print('DE',len(allrows),'NEW',len(new));print([(r['sku'],r['official_category_observations'][0]['card'].get('text','')[:110])for r in new])
