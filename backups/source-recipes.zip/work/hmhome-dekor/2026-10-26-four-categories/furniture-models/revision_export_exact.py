"""New bounded revision output, preserving source attributes/maps unless replaced."""
from pathlib import Path
import copy,json,shutil
import numpy as np
import build_models as F
P=Path(__file__).resolve().parent

def sha_attr(doc,binary,i):
 a=doc['accessors'][i];v=doc['bufferViews'][a['bufferView']];size={5126:4,5125:4,5123:2,5121:1}[a['componentType']]*{'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}[a['type']];off=v.get('byteOffset',0)+a.get('byteOffset',0);step=v.get('byteStride',size);return F.hashlib.sha256(b''.join(binary[off+j*step:off+j*step+size]for j in range(a['count']))).hexdigest()

def export(R,old,model,changed_names,revision,featureproof,map_override=None):
 R=Path(R);R.mkdir(parents=True,exist_ok=True);out=R/'models'/old['id'];out.mkdir(parents=True,exist_ok=True);assert not(out/'frozen.json').exists();assert F.sha(old['glb_path'])==old['sha256'];od,ob=F.EX.read_glb(old['glb_path']);payload={}
 for im in od['images']:
  v=od['bufferViews'][im['bufferView']];b=ob[v.get('byteOffset',0):v.get('byteOffset',0)+v['byteLength']];payload[F.hashlib.sha256(b).hexdigest()]=b
 mv=json.loads(Path(old['material_validation']).read_text());maps=[]
 for im in mv['maps']:
  dst=out/Path(im['path']).name;dst.write_bytes(payload[im['sha256']]);assert F.sha(dst)==im['sha256'];maps.append(dict(im,path=str(dst)))
 if map_override is not None:maps=map_override(out,model['materials'],maps)
 for im in old['original_images']:assert F.sha(im['path'])==im['sha256']
 meta=model['metadata'];meta.update(model_revision=revision,quality_pending=True,model_status='pending_root_actual_visual_gate');model['metadata']=meta;F.dump(out/'model.json',model);F.dump(out/'material-validation.json',dict(valid=True,maps=maps,source_master_checks=[dict(path=x['path'],expected_sha256=x['sha256'],actual_sha256=F.sha(x['path']),unchanged=True)for x in old['original_images']],old_source_PNGs_freshly_read=False,own_PNG_exact_bytes_recovered_from_frozen_GLB=old['glb_path'],own_frozen_GLB_sha256=old['sha256'],no_source_photo_upscale=True));F.dump(out/'geometry-validation.json',dict(valid=True,units='metres',up_axis='Y',origin='bottom bounding-box centre',dimensions_metres=(np.array(old['dimensions_cm'])/100).tolist(),changed_mesh_names=changed_names,photographed_features=featureproof,closed_material_solids=True))
 report=F.EX.export_assets(out/'model.json',out,old['id']);glb=out/(old['id']+'.glb');doc,binary=F.EX.read_glb(glb);doc['samplers']=[dict(magFilter=9729,minFilter=9987,wrapS=10497,wrapT=10497)]
 for t in doc.get('textures',[]):t['sampler']=0
 binary=F.G.M.embed_tangents(doc,binary);F.EX.write_glb(glb,doc,binary);assert glb.stat().st_size<96_000_000;nd,nb=F.EX.read_glb(glb);newby={}
 for mesh in nd['meshes']:newby.setdefault(mesh['name'],[]).append(mesh)
 preserved=[]
 for m in od['meshes']:
  if m['name']in changed_names or m['name']not in newby:continue
  a=m['primitives'][0];b=newby[m['name']].pop(0)['primitives'][0]
  for key in['POSITION','NORMAL','TEXCOORD_0','TANGENT','indices']:
   oi=a['indices']if key=='indices'else a['attributes'].get(key);ni=b['indices']if key=='indices'else b['attributes'].get(key)
   if oi is None:continue
   before=sha_attr(od,ob,oi);after=sha_attr(nd,nb,ni);assert before==after,(m['name'],key);preserved.append(dict(mesh=m['name'],attribute=key,sha256=after,byte_identical=True))
 F.dump(out/'unchanged-geometry-and-map-preservation-proof.json',dict(source_glb=old['glb_path'],source_glb_sha256=old['sha256'],preserved_attributes=preserved,preserved_own_maps=[dict(path=x['path'],sha256=x['sha256'],embedded_original_bytes=True)for x in maps if x['sha256']in payload],revised_own_maps=[dict(path=x['path'],sha256=x['sha256'],embedded_original_bytes=False)for x in maps if x['sha256']not in payload],changed_mesh_names=changed_names,geometry_feature_proof=featureproof));e=copy.deepcopy(old);e.update(meta,asset_dir=str(out),model_path=str(out/'model.json'),glb_path=str(glb),sha256=F.sha(glb),bytes=glb.stat().st_size,geometry_validation=str(out/'geometry-validation.json'),material_validation=str(out/'material-validation.json'),root_actual_review_pending=True,quality_pending=True);e.pop('independent_qa',None);e.pop('native_render_paths',None);e.pop('source_native_comparison',None);F.dump(out/'entry.json',e);F.dump(R/'manifest.json',[e]);report['deliverable_sha256']['glb']=e['sha256'];report['glb_bytes']=e['bytes'];report['source_sha256']=F.sha(out/'model.json');F.dump(report['files']['validation'],report)
 for f in['audit_assets.py','make_contacts.py','batch_contacts.py','freeze_batch.py','source-master-freeze-503.json','original-image-masters.json','source-queue-117.json']:shutil.copyfile(P/f,R/f)
 print('EXPORTED',old['sku'],e['bytes'],'preserved',len(preserved),'attributes',flush=True);return e
