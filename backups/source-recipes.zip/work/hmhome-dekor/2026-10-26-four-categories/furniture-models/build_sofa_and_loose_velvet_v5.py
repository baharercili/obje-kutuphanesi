"""Approved continuous U method on own three-seat sibling; DISTINCT loose velvet."""
from pathlib import Path
import sys,copy,math,shutil,json
sys.dont_write_bytecode=True
import numpy as np
from PIL import Image
import build_models as F
import build_upholstery_eight as U
import build_last_soft_six as L
import build_continuous_u_pilot_v4 as C
P=Path(__file__).resolve().parent;R=P/'revisions/source-sofa-and-loose-velvet-v5';R.mkdir(parents=True,exist_ok=True);B=F.B;G=F.G;T=math.tau
OLD=P/'revisions/convex-arms-three-v3/manifest.json'

def sofa():
 side=1.065;path=L.smooth_path([(-side,.46),(-side,.26),(-side,-.23),(-side+.04,-.35),(-side+.13,-.405),(0,-.405),(side-.13,-.405),(side-.04,-.35),(side,-.23),(side,.26),(side,.46)],18);n=len(path);sides=64;v=[];uv=[];ff=[];length=np.r_[0,np.cumsum(np.linalg.norm(np.diff(path,axis=0),axis=1))]
 for i,(x,z)in enumerate(path):
  t=path[min(i+1,n-1)]-path[max(i-1,0)];t/=np.linalg.norm(t);sn=np.array([-t[1],t[0]]);rear=np.clip((-z-.22)/.18,0,1);half=.135-.040*rear;top=.64+.04*np.clip((.46-z)/.865,0,1);bottom=.043
  for j in range(sides+1):
   a=(j%sides)*T/sides;y=(top+bottom)/2+(top-bottom)/2*np.sign(math.cos(a))*abs(math.cos(a))**.48;off=half*np.sign(math.sin(a))*abs(math.sin(a))**.62;xx,zz=np.array([x,z])+sn*off;v.append((xx,y,zz));uv.append((length[i]/.16,y/.16))
 for i in range(n-1):
  for j in range(sides):a=i*(sides+1)+j;b=a+sides+1;ff.extend([(a,b,a+1),(a+1,b,b+1)])
 for i in[0,n-1]:
  ci=len(v);x,z=path[i];v.append((x,.3415,z));uv.append((length[i]/.16,.3415/.16))
  for j in range(sides):ff.append((ci,i*(sides+1)+j,i*(sides+1)+j+1))
 p=[C.physical_fabric_charts(B.solid('own-source-continuous-240cm-U-outer-shell','fabric',v,ff,uv))]
 for i,x in enumerate([-.624,0,.624]):
  profiles=[(G.rounded(w,d,r,32),y)for w,d,r,y in[(.607,.778,.055,.066),(.619,.790,.060,.075),(.619,.790,.064,.330),(.616,.784,.068,.375),(.597,.760,.080,.409),(.543,.704,.100,.427),(.429,.590,.120,.435),(.239,.400,.105,.437)]];g=G.capped('one-of-THREE-own-full-supported-seat-cushions-'+str(i),'fabric',profiles,True,.16);g['_vertices']=[(a+x,b,c+.078)for a,b,c in g['_vertices']];p.append(C.physical_fabric_charts(g));p.append(U.soft('one-of-three-own-padded-inner-back-panels-'+str(i),(.620,.405,.10),(x,.466,-.345),.035,loft=.004))
 for x,w in[(-.73,.84),(0,.64),(.73,.84)]:p.append(U.soft('one-of-three-source-low-full-plinth-sections',(w,.068,.89),(x,.038,0),.023,loft=.001))
 for sx in[-1,1]:
  pts=[(sx*side+.123*np.sign(math.sin(a))*abs(math.sin(a))**.62,.3415+.287*np.sign(math.cos(a))*abs(math.cos(a))**.48,.4605)for a in np.linspace(0,T,192,endpoint=False)];p.append(F.tube('own-source-arm-front-panel-seam','fabric',pts,.0011,sides=8,closed=True))
 return p,['Own240cm three-seat source e882e64e6880: apply the accepted1368750001 continuous padded U-shell construction at the exact own width; two full side arms/rear frame have no unsupported bottom triangles.','THREE independently full seat cushions, THREE source padded inner back panels and three discreet low base sections; each seat intersects its own support. Back panels are source integrated upholstery, not invented decorative throw pillows.','Own grey woven pigment/maps are byte-identical to this exactSKU earlier frozen source. Unlabelled240×100×68cm keeps the existing explicit axis interpretation; local pad seams/support proportions are photo reconstructed.'],dict(continuous_outer_U_shell=True,separate_seat_cushion_count=3,own_padded_inner_back_panel_count=3,low_support_sections=3,unlabelled_axis_interpretation=True,accepted_method_parent_sku='1368750001',own_source_not_cross_sku_texture=True)

def smooth_closed(points,steps=10):
 a=np.asarray(points,float);o=[]
 for i in range(len(a)):
  p0,p1,p2,p3=[a[j%len(a)]for j in[i-1,i,i+1,i+2]]
  for t in np.linspace(0,1,steps,endpoint=False):o.append(.5*(2*p1+(-p0+p2)*t+(2*p0-5*p1+4*p2-p3)*t*t+(-p0+3*p1-3*p2+p3)*t*t*t))
 return np.asarray(o)

def velvet_arm(sx):
 outline=smooth_closed([(0,.065),(.078,.068),(.110,.095),(.127,.165),(.132,.35),(.127,.48),(.100,.56),(.035,.59),(-.050,.58),(-.105,.54),(-.123,.44),(-.124,.20),(-.105,.10),(-.065,.069)],10);n=len(outline);center=np.array([0,.325]);v=[];ff=[];uv=[];stations=np.linspace(0,1,18);cx=sx*.4475
 def front(y):return .495-.055*(y-.065)/.525
 for f in stations:
  for x,y in outline:
   xx=cx+sx*x*(1+.018*math.sin(math.pi*f));yy=y+.018*f*np.clip((y-.065)/.525,0,1);zz=front(y)*(1-f)-.475*f;v.append((xx,yy,zz));uv.append((xx/.18,yy/.18))
 for i in range(len(stations)-1):
  for j in range(n):a=i*n+j;b=i*n+(j+1)%n;ff.extend([(a,b,a+n),(b,b+n,a+n)])
 for endpoint,side in[(0,1),(len(stations)-1,-1)]:
  previous=[endpoint*n+j for j in range(n)]
  for scale in[.82,.58,.30]:
   ring=[]
   for x,y in outline:
    x,y=center+(np.array([x,y])-center)*scale;f=stations[endpoint];xx=cx+sx*x;yy=y+.018*f*np.clip((y-.065)/.525,0,1);zz=front(y)if endpoint==0 else -.475;zz+=side*.014*(1-scale**2);ring.append(len(v));v.append((xx,yy,zz));uv.append((xx/.18,yy/.18))
   for j in range(n):k=(j+1)%n;ff.extend([(previous[j],previous[k],ring[j]),(previous[k],ring[k],ring[j])])
   previous=ring
  ci=len(v);v.append((cx,.325+.018*stations[endpoint]*.495,(front(.325)if endpoint==0 else -.475)+side*.014));uv.append((cx/.18,.325/.18))
  for j in range(n):ff.append((previous[j],previous[(j+1)%n],ci))
 g=C.physical_fabric_charts(B.solid('own-loose-cover-softly-sloping-convex-arm-'+str(sx),'fabric',v,ff,uv));pts=[(cx+sx*x,y,front(y)+.0013)for x,y in outline];return[g,F.tube('own-finite-front-arm-panel-cloth-seam','fabric',pts,.0011,sides=8,closed=True)]

def backbag():
 # A shared rectangular grid avoids the long radial-fan shading wedges of a
 # polygon pillow; front and reverse meet on the same rounded seam boundary.
 nx,ny=64,48;hw,hh,r=.39,.22,.055;v=[];uv=[];ff=[]
 for side in[-1,1]:
  off=len(v)
  for j in range(ny+1):
   vv=2*j/ny-1
   for i in range(nx+1):
    u=2*i/nx-1;qx,qy=u*hw,vv*hh;ll=math.hypot(qx,qy);ratio=1
    if ll>1e-12:
     dx,dy=qx/ll,qy/ll;ts=min(hw/max(abs(dx),1e-12),hh/max(abs(dy),1e-12));xx,yy=ts*abs(dx),ts*abs(dy)
     if xx>hw-r and yy>hh-r:
      cx,cy=hw-r,hh-r;dot=abs(dx)*cx+abs(dy)*cy;tr=dot+math.sqrt(max(0,dot*dot-cx*cx-cy*cy+r*r));ratio=tr/ts
    x=qx*ratio*(.90+.10*(vv+1)/2);y=qy*ratio+.48;z=-.315-.14*(y-.48)+side*.105*max(0,1-u*u)**.42*max(0,1-vv*vv)**.42
    if side>0:z+=.0035*math.sin(x*105+1.2)*math.exp(-((y-.31)/.065)**2)*(1-u*u)*(1-vv*vv)
    v.append((x,y,z));uv.append((x/.18,y/.18))
  for j in range(ny):
   for i in range(nx):
    aa=off+j*(nx+1)+i;bb=aa+1;cc=aa+nx+1;dd=cc+1;ff.extend([(aa,bb,dd),(aa,dd,cc)]if(i==0 and j==0)or(i==nx-1 and j==ny-1)else[(aa,bb,cc),(bb,dd,cc)])
 return B.solid('own-separate-inclined-generously-filled-loose-back-pillow','fabric',v,ff,uv)

def velvet():
 p=[U.soft('own-thin-soft-source-lower-frame-band',(1.09,.050,.90),(0,.0675,0),.016,loft=.001),U.soft('own-fixed-rear-frame-behind-loose-pillow',(.96,.455,.10),(0,.3125,-.41),.027,loft=.002),backbag()]
 profiles=[(G.rounded(w,d,r,32),y)for w,d,r,y in[(.64,.68,.08,.083),(.70,.75,.10,.12),(.72,.77,.12,.18),(.73,.77,.13,.28),(.69,.73,.12,.36),(.57,.60,.15,.402),(.32,.40,.14,.412),(.08,.10,.039,.413)]];seat=G.capped('own-loose-sagged-puffy-seat-not-hard-pillow-slab','fabric',profiles,True,.18);seat['_vertices']=[(x,y-.015*z/.385+.0025*math.sin(x*62)*math.exp(-((z-.35)/.09)**2),z+.045)for x,y,z in seat['_vertices']];p.append(C.physical_fabric_charts(seat))
 for sx in[-1,1]:p+=velvet_arm(sx)
 p+=U.feet([-.43,.43],[-.34,.34],.045,.038)
 p.append(F.tube('own-soft-loose-seat-equator-perimeter-seam','fabric',[(x,.235-.015*z/.385,z+.045)for x,z in G.rounded(.728,.766,.12,32)],.0010,sides=8,closed=True))
 for g in p:
  if g['material']=='fabric':g['_uvs']=[(a*.16/.18,b*.16/.18)for a,b in g['_uvs']]
 return p,['Own1341711001 full packshot e8ade00781e1/lifestyle52240193f666: DISTINCT softly sloping filled cloth-covered arms with rounded convex sewn front panels; not copied from the grey integrated U chair.','One thick generously domed loose seat cushion, separate inclined tapered filled back pillow with lower tension ripples, thin source frame band and four discreet real feet. No hard flat cushion slab or detached arm balloon.','Native own beige velvet donor/albedo pixels retained; local cloth nap response/roughness adjusted as explicit PBR interpretation. Official115×100×70cm preserved; local folds/seams/hidden frame are photo reconstructed.'],dict(own_loose_seat_and_back_cushions=True,loose_source_arm_cover=True,sloping_convex_arm_fronts=True,thin_source_base_band=True,real_source_foot_count=4,not_grey_U_shell_copy=True)

def materials(out,pid,defs,masters):
 e=next(e for e in json.loads(OLD.read_text())if e['sku']==pid);m=json.loads(Path(e['model_path']).read_text());mats=copy.deepcopy(m['materials']);v=json.loads(Path(e['material_validation']).read_text());maps=[];proof=[];doc,binary=F.EX.read_glb(Path(e['glb_path']));payloads={}
 for im in doc['images']:
  bv=doc['bufferViews'][im['bufferView']];data=binary[bv.get('byteOffset',0):bv.get('byteOffset',0)+bv['byteLength']];payloads[F.hashlib.sha256(data).hexdigest()]=data
 source_glb_sha=F.sha(e['glb_path']);assert source_glb_sha==e['sha256']
 for im in v['maps']:
  src=Path(im['path']);data=payloads[im['sha256']];dst=out/src.name;dst.write_bytes(data);assert F.sha(dst)==im['sha256'];maps.append(dict(im,path=str(dst)));proof.append(dict(source=str(src),new=str(dst),source_sha256=im['sha256'],source_png_freshly_read=False,exactbytes_verified_from_frozen_GLB=True,source_glb=e['glb_path'],source_glb_sha256=source_glb_sha))
 old=Path(e['asset_dir'])
 if pid=='1341711001':
  for q in old.glob('*-crop-provenance.json'):
   a=json.loads(q.read_text());raw=out/Path(a['raw_crop']).name;Image.open(a['master']).convert('RGB').crop(a['source_crop_pixel_box']).save(raw);a.update(raw_crop=str(raw),raw_crop_sha256=F.sha(raw),raw_donor_recreated_pixel_identical_from_unchanged_JPEG=True);F.dump(out/q.name,a);mats['fabric']['extras']['crop_provenance']=str(out/q.name)
  orm=out/'fabric-orm.png';a=np.asarray(Image.open(orm).convert('RGB')).copy();a[:,:,1]=211;Image.fromarray(a,'RGB').save(orm,optimize=True)
  for im in maps:
   if im['material']=='fabric'and im['slot']=='orm':im['sha256']=F.sha(orm)
  mats['fabric'].update(sheen=.25,normalScale=.62);mats['fabric']['extras'].update(own_velvet_nap_roughness_interpretation=True,own_native_pigment_byte_identical=True)
 for rec in proof:rec['new_sha256']=F.sha(rec['new']);rec['byte_identical']=rec['source_sha256']==rec['new_sha256'];rec['difference_reason']='roughness-only own velvet nap response'if not rec['byte_identical']else None
 F.dump(out/'own-material-byte-preservation-and-roughness-proof.json',proof);return mats,maps
S={}
for sku,fn in[('1368744001',sofa),('1341711001',velvet)]:
 sp=copy.deepcopy(U.S[sku]);sp['build']=fn;sp['note']+=' Ayrı V5: Kendi tam ön ve yan fotoğrafına göre sürekli gri3oturumlu dışkabuk veya ayrı gevşek kadife minder/kol kılıfı şekli kuruldu. Kaynaklar ve önceki onaylı pilot değişmedi; yerel yumuşaklık/dikiş/kaplama evresi fotoğraf yorumudur.';S[sku]=sp
if __name__=='__main__':
 for n in['original-image-masters.json','source-queue-117.json','source-master-freeze-503.json']:shutil.copyfile(P/n,R/n)
 (R/'source-evidence').mkdir(exist_ok=True)
 for sku in S:shutil.copyfile(P/'source-evidence'/(sku+'.json'),R/'source-evidence'/(sku+'.json'))
 F.R=R;F.materials=materials;F.SPECS.update(S)
 for sku in sys.argv[1:]or S:F.build(sku)
 for n in['audit_assets.py','make_contacts.py','batch_contacts.py','freeze_batch.py']:shutil.copyfile(P/n,R/n)
