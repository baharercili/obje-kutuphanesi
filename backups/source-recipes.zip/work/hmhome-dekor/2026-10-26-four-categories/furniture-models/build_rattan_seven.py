"""Seven distinct own-reference rattan forms; every weave opening is physical geometry."""
from pathlib import Path
import sys,math
sys.dont_write_bytecode=True
import numpy as np
import build_models as F
from geometry_extra import extrude_xy
G=F.G;B=F.B;T=math.tau
def cane(name,pts,r=.008,sides=12,closed=False):return F.tube(name,'cane',pts,r,sides=sides,closed=closed)
def panel(name,w,h,c,axis='front',top=None):return F.woven_panel(name,w,h,c,axis=axis,pitch=.0055,top_curve=top)
def arched_rail(name,cx,w,top,bottom,z,r=.008):
 rad=w/2;spring=top-rad;pts=[(cx-rad,bottom,z),(cx-rad,spring,z)]+[(cx+rad*math.cos(a),spring+rad*math.sin(a),z)for a in np.linspace(math.pi,0,90)[1:]]+[(cx+rad,bottom,z)]
 return cane(name,pts,r)
def rounded_rail(name,w,d,y,r=.008):return cane(name,[(x,y,z)for x,z in G.rounded(w,d,min(w,d)*.16,18)],r,closed=True)
def binding(name,cx,z,y0,y1,r=.012):
 turns=max(3,int((y1-y0)/.003));pts=[(cx+r*math.cos(t),y0+(y1-y0)*t/(T*turns),z+r*math.sin(t))for t in np.linspace(0,T*turns,turns*10)];return F.tube(name,'rattan',pts,.0011,sides=6)
def flower_fan(name,centre,side,radius=.12):
 p=[];cx,cy,cz=centre
 for k,a in enumerate([-.88,0,.88]):
  pts=[];controls=[[(0,0),(.60,-.27),(1,-.28),(1,0)],[(1,0),(1,.28),(.60,.27),(0,0)]]
  for cp in controls:
   for t in np.linspace(0,1,40,endpoint=False):
    v=(1-t)**3*np.array(cp[0])+3*(1-t)**2*t*np.array(cp[1])+3*(1-t)*t*t*np.array(cp[2])+t**3*np.array(cp[3]);x,y=v*radius;pts.append((cx+side*(x*math.cos(a)-y*math.sin(a)),cy+x*math.sin(a)+y*math.cos(a),cz))
  p.append(cane(name+'-real-petal-'+str(k),pts,.0029,10,closed=True))
 p.append(cane(name+'-round-real-pull',[(cx,cy,cz-.012),(cx,cy,cz+.004)],.009,16));return p
def child_chair():
 p=[];weave=[]
 for sx in[-1,1]:
  for sz in[-1,1]:p.append(cane('one-of-four-splayed-rattan-chair-legs',[(sx*.198,0,sz*.169),(sx*.183,.115,sz*.153),(sx*.162,.269,sz*.133)],.0125,16))
  pts=[(sx*.168,.278,.133),(sx*.188,.343,.12),(sx*.188,.370,.065),(sx*.171,.372,-.105),(sx*.158,.321,-.139)];p.append(cane('separate-softly-bent-rattan-arm',pts,.0105,16));p.append(binding('real-front-arm-post-binding',sx*.168,.133,.250,.319,.014))
 p.append(rounded_rail('actual-rounded-rectangular-seat-frame',.338,.297,.263,.012))
 for r,top in[(.180,.475),(.139,.431),(.098,.386)]:p.append(arched_rail('one-of-three-concentric-rainbow-back-can es'.replace('can es','canes'),0,r*2,top,.275,-.132,.008))
 weave+=panel('real-open-woven-seat',.314,.276,(0,.265,0),'top');p.append(F.merge('individual-closed-chair-seat-rattan-strands','rattan',weave))
 return p,['Own child lounge chair: four splayed cane legs, two curved arms and three concentric arched rainbow back rails','Actual physical open seat weave with flattened alternating wefts/round warps, bound front joints and rounded seat frame','OfficialW43D39H48cm,seat27cm; local cane sections/curves are own-photo estimates. Styled cloth, table and other chairs excluded'],{'official_seat_height_cm':27,'rainbow_arch_count':3,'physical_open_rattan_weave':True,'leg_count':4}
def headboard():
 p=[];weave=[]
 for i,(cx,top)in enumerate([(-.3375,.505),(-.1125,.651),(.1125,.651),(.3375,.505)]):
  w=.211;p.append(arched_rail('one-of-four-joined-outer-arched-sections-'+str(i),cx,w,top,.009,0,.009));p.append(cane('own-section-bottom-cane',[(cx-w/2,.009,0),(cx+w/2,.009,0)],.007))
  iw=.175;itop=top-.077;spring=itop-iw/2;fn=lambda x,cx=cx,iw=iw,spring=spring:spring+math.sqrt(max(0,(iw/2)**2-(x-cx)**2))
  p.append(arched_rail('own-lower-inner-arch-'+str(i),cx,iw,itop,.010,.0008,.0055));weave+=panel('physical-inner-arched-weave-'+str(i),iw-.008,itop-.018,(cx,(itop+.018)/2,.001),top=fn)
  # The official description explicitly includes a fabric covering on the reverse.
  poly=[(cx-iw/2+.004,.014),(cx+iw/2-.004,.014)]+[(cx+(iw/2-.004)*math.cos(a),spring+(iw/2-.004)*math.sin(a))for a in np.linspace(0,math.pi,100)]
  p.append(extrude_xy('actual-reverse-fabric-covering-'+str(i),'backing',poly,-.0072,-.0064))
 for x in[-.22,.22]:p.append(F.board('small-reverse-metal-wall-mount-tab','hardware',.043,.025,.0012,(x,.36,-.0075),.002))
 p.append(F.merge('all-four-actual-arched-rattan-infill-weaves','rattan',weave))
 return p,['Own four arched connected panels: two taller central sections and two lower outer sections','Each section has an outer rail, separate lower inner arch and true open rattan weave; actual reverse fabric covering and metal wall fixtures are included','Official description explicitly states highest point66cm,W90D1.8cm; no bed, bedding, toys or wall staging'],{'arched_section_count':4,'official_highest_point_cm':66,'physical_open_rattan_weave':True,'reverse_fabric_covering_is_official':True}
def bench():
 p=[];weave=[];front=.120;back=-.120
 for sx in[-1,1]:
  for z in[front,back]:p.append(cane('one-of-four-exposed-storage-bench-feet',[(sx*.255,0,z),(sx*.255,.284,z)],.010,14))
 for z in[front,back]:
  p.append(cane('own-bottom-front-or-rear-rail',[(-.255,.037,z),(.255,.037,z)],.009))
  fn=(lambda x:.258-.033*math.exp(-(x/.070)**2))if z>0 else(lambda x:.258)
  p.append(cane('real-front-finger-dip-rail'if z>0 else'real-straight-rear-rail',[(x,fn(x),z)for x in np.linspace(-.255,.255,100)],.009))
  weave+=panel('own-empty-basket-front-or-rear',.493,.224,(0,.148,z),top=fn)
 for sx in[-1,1]:
  weave+=panel('real-open-bench-side',.222,.233,(sx*.255,.154,0),'side');p.append(cane('own-low-side-arch-frame',[(sx*.255,.278+.035*math.sin(a),.12*math.cos(a))for a in np.linspace(0,math.pi,90)],.010))
 lid=panel('separate-closed-curved-woven-seat-lid',.503,.223,(0,.300,0),'top')
 for g in lid:g['_vertices']=[(x,y+.016*(1-(z/.126)**2),z)for x,y,z in g['_vertices']]
 weave+=lid;g=rounded_rail('actual-independent-removable-lid-rim',.511,.242,.301,.009);g['_vertices']=[(x,y+.016*(1-(z/.126)**2),z)for x,y,z in g['_vertices']];p.append(g);weave+=panel('true-bottom-of-empty-rattan-storage',.493,.222,(0,.039,0),'top')
 for sx in[-1,1]:p.append(binding('real-front-post-bound-rattan-collar',sx*.255,front,.036,.270,.011))
 p.append(F.merge('closed-individual-strands-storage-bench-and-lid','rattan',weave))
 return p,['Own54×27×33cm empty rattan storage bench with four exposed short feet','Curved woven removable closed lid, real front central finger dip, arched side rails and actual open weave on every basket face','Local lid crown/notch/binding sections photo estimated; source plush toys and styled bedding excluded'],{'storage_has_true_empty_interior':True,'lid_pose':'closed','physical_open_rattan_weave':True,'front_finger_dip_is_geometry':True}
def cabinet_small(pid):
 bedside=pid=='1161127001';w=.32 if bedside else .647;d=.34 if bedside else .37;h=.40;r=.010;front=d/2-.012;back=-front;p=[];weave=[]
 for x in[-w/2+.012,w/2-.012]:
  for z in[front,back]:p.append(cane('actual-full-height-round-cabinet-post',[(x,0,z),(x,h-.010,z)],r,14))
 for y in[.035,.388]:
  for z in[front,back]:p.append(cane('actual-horizontal-front-or-rear-frame',[(-w/2+.012,y,z),(w/2-.012,y,z)],r,14))
  for x in[-w/2+.012,w/2-.012]:p.append(cane('actual-horizontal-side-frame',[(x,y,back),(x,y,front)],r,14))
 for sx in[-1,1]:weave+=panel('own-cabinet-side-open-weave',d-.043,.330,(sx*(w/2-.012),.212,0),'side')
 weave+=panel('own-cabinet-rear-open-weave',w-.043,.330,(0,.212,back));weave+=panel('own-cabinet-top-open-weave',w-.043,d-.043,(0,.389,0),'top')
 p.append(F.board('actual-empty-interior-MDF-floor','shelf',w-.044,.010,d-.044,(0,.040,0),.001))
 if bedside:p.append(F.board('actual-empty-interior-MDF-middle-shelf','shelf',w-.044,.009,d-.044,(0,.210,0),.001))
 doors=1 if bedside else 2;dw=(w-.046)/doors
 for i in range(doors):
  cx=(i-(doors-1)/2)*(dw+.004);left=cx-dw/2;right=cx+dw/2
  for x in[left,right]:p.append(cane('separate-door-vertical-cane-frame',[(x,.052,front+.004),(x,.377,front+.004)],.0055))
  for y in[.052,.377]:p.append(cane('separate-door-horizontal-cane-frame',[(left,y,front+.004),(right,y,front+.004)],.0055))
  weave+=panel('separate-real-rattan-door-infill-'+str(i),dw-.012,.313,(cx,.2145,front+.004))
 if bedside:p+=flower_fan('own-three-petal-left-door-handle',(-w/2+.027,.214,front+.025),1,.125)
 else:
  for sx in[-1,1]:p+=flower_fan('own-half-of-six-petal-flower-handle',(sx*.014,.214,front+.025),sx,.13)
 for sx in[-1,1]:p.append(binding('real-bound-front-post',sx*(w/2-.012),front,.040,.379,.011))
 p.append(F.merge('all-actual-cabinet-physical-weave-strands','rattan',weave))
 return p,['Own compact rattan cabinet proportions and actual empty MDF floor/shelf, finite separate cane frames','One door with own three-petal handle'if bedside else'Two independently framed doors with paired three-petal fans forming the own six-petal flower','Physical open side/rear/top/door weave, real bound front posts; no lamps, books or plush toys'],{'door_count':doors,'handle_petal_count':3 if bedside else 6,'physical_open_rattan_weave':True,'interior_shelf_count':2 if bedside else 1,'local_frame_weave_handle_and_hinge_sections_photo_estimated':True}
def tall_shelf():
 p=[];weave=[];w=.56;d=.37;front=.173;back=-.173;spring=.77;rad=.267
 top=lambda x:spring+math.sqrt(max(0,rad*rad-x*x))
 for z in[front,back]:p.append(arched_rail('own-full-height-arched-side-outline',0,rad*2,spring+rad,0,z,.010))
 for sx in[-1,1]:
  for y in[.048,.405,.770]:p.append(cane('actual-side-shelf-edge-rail',[(sx*.266,y,back),(sx*.266,y,front)],.008))
  weave+=panel('actual-full-height-open-side-rattan',d-.045,.715,(sx*.266,.405,0),'side')
 for y in[.048,.405,.770]:
  weave+=panel('one-of-three-physical-woven-shelves',.510,d-.045,(0,y,0),'top')
  for z in[front,back]:p.append(cane('actual-front-or-rear-shelf-rail',[(-.266,y,z),(.266,y,z)],.008))
 weave+=panel('actual-upper-arch-rear-infill',.512,.255,(0,.8975,back),top=top)
 crown=panel('actual-open-woven-curved-crown',.510,d-.045,(0,spring,0),'top')
 for g in crown:g['_vertices']=[(x,y+top(x)-spring,z)for x,y,z in g['_vertices']]
 weave+=crown;p.append(F.merge('all-open-physical-rattan-shelves-sides-and-arched-crown','rattan',weave))
 return p,['Own56×37×105cm tall rattan shelf with three actual woven shelves and gently arched crown','True open front/rear lower spaces, woven side panels and rear upper arch; flattened alternating wefts and round warps have real gaps','Entire rattan-only source construction; local sections photo estimated; frog, storage boxes and books excluded'],{'actual_shelf_count':3,'arched_crown':True,'physical_open_rattan_weave':True,'lower_rear_open':True}
def storage_stool():
 p=[];weave=[];r=.161;bottom=.008;top=.285;count=180
 for j,a in enumerate(np.arange(count)*T/count):
  pts=[((r+.0017*math.cos((y-bottom)/.0044*math.pi+j*math.pi))*math.cos(a),y,(r+.0017*math.cos((y-bottom)/.0044*math.pi+j*math.pi))*math.sin(a))for y in np.linspace(bottom,top,90)];weave.append(F.tube('one-real-vertical-basket-warp','rattan',pts,.00065,sides=6))
 for j,y in enumerate(np.arange(bottom,top,.0044)):
  pts=[((r+.0018*math.cos(a*count/2+j*math.pi))*math.cos(a),y,(r+.0018*math.cos(a*count/2+j*math.pi))*math.sin(a))for a in np.linspace(0,T,540,endpoint=False)];weave.append(F.tube('one-real-circumferential-flat-weft','rattan',pts,.00045,.00145,sides=6,closed=True,guide=[0,1,0]))
 for y in[bottom,top]:p.append(cane('actual-bound-basket-rim',[(r*math.cos(a),y,r*math.sin(a))for a in np.linspace(0,T,240,endpoint=False)],.005,12,closed=True))
 # Separate closed removable radial-woven lid; no opaque photo disk.
 for j,a in enumerate(np.arange(144)*T/144):
  pts=[(rr*math.cos(a),.302+.012*(1-(rr/.165)**2)+.0014*math.cos(rr/.0045*math.pi+j*math.pi),rr*math.sin(a))for rr in np.linspace(.008,.164,65)];weave.append(F.tube('actual-lid-radial-warp','rattan',pts,.0007,sides=6))
 for j,rr in enumerate(np.arange(.009,.164,.0045)):
  pts=[(rr*math.cos(a),.302+.012*(1-(rr/.165)**2)+.0014*math.cos(a*72+j*math.pi),rr*math.sin(a))for a in np.linspace(0,T,432,endpoint=False)];weave.append(F.tube('actual-lid-concentric-flat-weft','rattan',pts,.00045,.00135,sides=6,closed=True,guide=[0,1,0]))
 p.append(cane('separate-removable-round-lid-rim',[(.165*math.cos(a),.302,.165*math.sin(a))for a in np.linspace(0,T,240,endpoint=False)],.005,12,closed=True))
 for j in range(12):
  mid=(j+.5)*T/12
  for offset in[-.0015,0,.0015]:
   pts=[]
   for t in np.linspace(-1,1,48):
    a=mid+t*T/24;rr=.165+offset;pts.append((rr*math.cos(a),.298-.028*math.sqrt(max(0,1-t*t)),rr*math.sin(a)))
   p.append(F.tube('one-of-twelve-real-scalloped-rattan-lid-trim-loops','rattan',pts,.0010,sides=6))
 # The empty circular basket has a genuinely round, wall-to-wall woven floor.
 for j,x in enumerate(np.arange(-r+.003,r,.0055)):
  span=math.sqrt(max(0,r*r-x*x))
  if span<.001:continue
  pts=[(x,.009,z)for z in np.linspace(-span,span,max(3,int(span/.003)))];weave.append(F.tube('round-base-clipped-warp','rattan',pts,.00065,sides=6))
 for j,z in enumerate(np.arange(-r+.003,r,.0043)):
  span=math.sqrt(max(0,r*r-z*z))
  if span<.001:continue
  pts=[(x,.009+.0017*math.cos(math.pi*(x+r)/.0055+j*math.pi),z)for x in np.linspace(-span,span,max(3,int(span/.0025)))];weave.append(F.tube('round-base-clipped-flat-weft','rattan',pts,.00042,.0014,sides=6,guide=[0,1,0]))
 p.append(F.merge('closed-individual-storage-body-and-radial-lid-weaving-strands','rattan',weave))
 return p,['Own34cm diameter32cm tall empty rattan storage stool, with separate removable closed lid','Physical cylindrical alternating body weave, radial/concentric woven lid and twelve real scalloped hanging trim loops','No generic textured cylinder or photo card; local weave/count/rim/lid crown photo estimated, source styling excluded'],{'removable_lid_pose':'closed','physical_open_rattan_weave':True,'radial_lid_weave':True,'scalloped_trim_count_photo_observed':12,'storage_has_empty_interior':True}
S={}
def add(pid,name,dims,fn,pi,rgb,**kw):S[pid]=dict(name=name,dims=dims,build=fn,primary_index=pi,materials={'cane':('cane',rgb,.62),'rattan':('cane',[c+2 for c in rgb],.67),'shelf':('wood',[171,141,105],.67),'backing':('paint',[199,181,147],.95),'hardware':('metal',[180,181,176],.42)},color='Doğal açık rattan',note=kw.pop('note','Resmî dış ölçüler korunur. KendiSKU fotoğrafındaki gerçek kamış iskelet, açık örgü, aralıklar, kolluk/kapak/raf/kulp ve dolap bölümleri fiziksel geometridir. Yerel kamış/örgü/bağ/bağlantı kalınlığı ve görünmeyen kısımlar fotoğraf yorumudur; üretici CAD değildir. Staging dahil değildir.'),**kw)
add('1048866001','Üç kemerli rattan çocuk koltuğu',[43,48,39],child_chair,1,[211,189,151],official={'width_cm':[43],'depth_cm':[39],'total_height_cm':[48],'seat_height_cm':[27]})
add('1107974001','Dört kemerli rattan yatak başlığı',[90,66,1.8],headboard,1,[208,187,151],official={'width_cm':[90],'highest_point_height_cm':[66],'depth_cm':[1.8]},note='AynıSKU resmî açıklama en yüksek noktada66cmH,90cm en,1,8cm derinlik der. Dört bağlı dış kemer, dört alçak iç kemer, gerçek rattan örgü, resmî arka kumaş kaplaması ve duvar bağlantıları fiziksel; yerel kemer oranı/örgü/kamış/vida yeri fotoğraf yorumudur. Yatak veya oda dahil değildir.')
add('1107975001','Dalgalı tutma açıklıklı rattan sandık bank',[54,33,27],bench,0,[211,188,150])
add('1161127001','Üç yaprak kulplu rattan komodin',[32,40,34],lambda:cabinet_small('1161127001'),1,[206,181,140],official={'length_cm':[32],'depth_cm':[34],'height_cm':[40]},official_hwd=[40,None,34],estimated_axes=['source_length_mapped_to_X'])
add('1254736001','Kemerli üç raflı rattan kitaplık',[56,105,37],tall_shelf,3,[209,185,144])
add('1260539001','Çiçek kulplu alçak rattan dolap',[64.7,40,37],lambda:cabinet_small('1260539001'),1,[210,186,147])
add('1260559002','Dalgalı kapaklı yuvarlak rattan sandık tabure',[34,32,34],storage_stool,1,[202,177,136],official={'diameter_cm':[34],'height_cm':[32]})
F.SPECS.update(S)
if __name__=='__main__':
 for pid in sys.argv[1:]or S:F.build(pid)
