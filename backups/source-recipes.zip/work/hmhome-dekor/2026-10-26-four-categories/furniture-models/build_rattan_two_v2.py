"""Two bounded rattan v2 prototypes, replacing root-rejected thin homogeneous mesh.
Every strand remains a closed manufactured solid. No old frozen asset changes.
"""
from pathlib import Path
import sys,math,json,copy,shutil
sys.dont_write_bytecode=True
import numpy as np
from PIL import Image
import build_models as F
BASE=F.materials
import build_rattan_seven as OLD
P=Path(__file__).resolve().parent;R=P/'revisions/rattan-two-v2';R.mkdir(parents=True,exist_ok=True);T=math.tau;G=F.G;B=F.B
def smooth(pts,steps=14):
 a=np.asarray(pts);out=[]
 for i in range(len(a)-1):
  q0,q1,q2,q3=a[max(0,i-1)],a[i],a[i+1],a[min(len(a)-1,i+2)]
  for t in np.linspace(0,1,steps,endpoint=False):out.append(.5*((2*q1)+(-q0+q2)*t+(2*q0-5*q1+4*q2-q3)*t*t+(-q0+3*q1-3*q2+q3)*t*t*t))
 out.append(a[-1]);return out
def lash_vertical(name,cx,cz,y0,y1,rad=.016,pitch=.0022):
 turns=(y1-y0)/pitch;pts=[(cx+rad*math.cos(t),y0+(y1-y0)*t/(T*turns),cz+rad*math.sin(t))for t in np.linspace(0,T*turns,max(30,int(turns*12)))];return F.tube(name,'binding',pts,.00055,.00105,sides=8,guide=[0,1,0])
def child():
 old,_,_=OLD.child_chair();p=[g for g in old if not any(k in g['name']for k in ['softly-bent','binding','individual-closed-chair-seat'])];seat=[]
 for sx in[-1,1]:
  upper=[(sx*.167,.265,.143),(sx*.174,.307,.135),(sx*.191,.371,.100),(sx*.188,.379,-.080),(sx*.169,.374,-.145)]
  lower=[(sx*.172,.267,.143),(sx*.188,.305,.095),(sx*.190,.323,-.075),(sx*.165,.320,-.145)]
  for j,path in enumerate([upper,lower]):p.append(F.tube('own-one-of-two-continuously-bent-arm-canes-'+str(sx)+'-'+str(j),'cane',smooth(path),.0105 if j==0 else .0085,sides=20))
  p.append(lash_vertical('own-full-wide-bound-front-leg-joint',sx*.169,.140,.158,.292,.017,.0021));p.append(lash_vertical('own-wide-bound-rear-arch-joint',sx*.171,-.136,.268,.319,.0145,.0022))
 # Source has a curved under-seat front cross member, wrapped into the legs.
 p.append(F.tube('source-curved-under-front-seat-brace','cane',smooth([(-.170,.190,.145),(-.138,.237,.148),(0,.251,.151),(.138,.237,.148),(.170,.190,.145)]),.0075,sides=16))
 # The seat uses denser round interlaced reeds, independently visible at the front edge.
 xs=np.arange(-.153,.154,.0032);zs=np.arange(-.130,.131,.0032)
 for j,x in enumerate(xs):
  pts=[(x,.266+.0013*math.cos((z+.130)/.0032*math.pi+j*math.pi),z)for z in np.linspace(-.130,.130,100)];seat.append(F.tube('dense-seat-round-longitudinal-warp','rattan',pts,.00095,sides=8))
 for j,z in enumerate(zs):
  pts=[(x,.266-.0013*math.cos((x+.153)/.0032*math.pi+j*math.pi),z)for x in np.linspace(-.153,.153,116)];seat.append(F.tube('dense-seat-round-transverse-weft','rattan',pts,.00095,sides=8))
 p.append(F.merge('source-specific-dense-round-open-seat-weaving','rattan',seat))
 wraps=[]
 for j,x in enumerate(np.arange(-.157,.158,.0020)):
  pts=[(x,.263+.0135*math.sin(a),.142+.0135*math.cos(a))for a in np.linspace(0,T,20,endpoint=False)];wraps.append(F.tube('own-dense-front-seat-edge-wrap','binding',pts,.0008,sides=6,closed=True,guide=[1,0,0]))
 p.append(F.merge('actual-thick-front-seat-edge-lashing','binding',wraps))
 return p,['Own full-resolution front/rear closeups were rechecked: TWO continuously bent arm canes on each side, not one angular polyline','Seat is a separate densely interlaced round-reed weave with small real openings, plus thick front wrapped edge, broad bound front/rear joints and curved under-seat brace','Official43×39×48cm,seat27cm; no cloth/toys. Local reed diameter/pitch/binding and two-arm curvature are photo estimates, not official measurements'],{'arm_canes_per_side':2,'spline_arm_bends':True,'dense_round_seat_reeds':True,'seat_reed_diameter_mm_photo_estimate':1.9,'seat_pitch_mm_photo_estimate':3.2,'revision_replaces_thin_homogeneous_mesh':True}
def stool():
 p=[];body=[];lid=[];r=.1605;bottom=.008;top=.287;count=112
 # Own closeup has thick vertical stave bundles and paired close round horizontal reeds.
 for j,a in enumerate(np.arange(count)*T/count):
  pts=[((r+.0015*math.cos((y-bottom)/.003*math.pi+j*math.pi))*math.cos(a),y,(r+.0015*math.cos((y-bottom)/.003*math.pi+j*math.pi))*math.sin(a))for y in np.linspace(bottom,top,130)];body.append(F.tube('own-wide-vertical-basket-stave','rattan',pts,.0009,.0021,sides=8))
 for j,y in enumerate(np.arange(bottom+.002,top,.0030)):
  pts=[((r+.0018*math.cos(a*count/2+j*math.pi))*math.cos(a),y,(r+.0018*math.cos(a*count/2+j*math.pi))*math.sin(a))for a in np.linspace(0,T,448,endpoint=False)];body.append(F.tube('own-close-horizontal-rounded-reed','rattan',pts,.00112,.00125,sides=8,closed=True,guide=[0,1,0]))
 for a in np.arange(8)*T/8:
  rr=r-.008;p.append(F.tube('actual-separate-thick-inner-structural-cane','cane',[(rr*math.cos(a),bottom,rr*math.sin(a)),(rr*math.cos(a),top,rr*math.sin(a))],.0045,sides=14))
 for y in[bottom,top]:
  p.append(F.tube('source-thick-bound-upper-or-lower-basket-rim','cane',[(r*math.cos(a),y,r*math.sin(a))for a in np.linspace(0,T,280,endpoint=False)],.0065,sides=16,closed=True))
  wrap=[]
  for a in np.arange(360)*T/360:
   radial=np.array([math.cos(a),0,math.sin(a)]);centre=np.array([r*math.cos(a),y,r*math.sin(a)]);pts=[centre+.0069*math.cos(t)*radial+np.array([0,.0069*math.sin(t),0])for t in np.linspace(0,T,12,endpoint=False)];wrap.append(F.tube('one-closed-tight-rim-wrapping','binding',pts,.00065,sides=6,closed=True,guide=[0,1,0]))
  p.append(F.merge('dense-source-bound-rim-wrappings','binding',wrap))
 # Independent close woven radial lid, with large bundled trim scallops.
 for j,a in enumerate(np.arange(112)*T/112):
  pts=[(rr*math.cos(a),.307+.004*(1-(rr/.164)**2)+.0012*math.cos(rr/.0032*math.pi+j*math.pi),rr*math.sin(a))for rr in np.linspace(.005,.163,80)];lid.append(F.tube('own-dense-lid-radial-reed','rattan',pts,.0010,sides=8))
 for j,rr in enumerate(np.arange(.005,.163,.0030)):
  pts=[(rr*math.cos(a),.307+.004*(1-(rr/.164)**2)+.0012*math.cos(a*56+j*math.pi),rr*math.sin(a))for a in np.linspace(0,T,448,endpoint=False)];lid.append(F.tube('own-dense-lid-round-concentric-weft','rattan',pts,.0010,.0012,sides=8,closed=True,guide=[0,1,0]))
 p.append(F.tube('actual-wide-removable-lid-rim','cane',[(.164*math.cos(a),.307,.164*math.sin(a))for a in np.linspace(0,T,280,endpoint=False)],.0065,sides=16,closed=True))
 trims=[]
 for j in range(12):
  mid=(j+.5)*T/12
  for k in range(5):
   pts=[]
   for t in np.linspace(-1,1,50):
    a=mid+t*T/24;rr=.167+(k-2)*.0012;pts.append((rr*math.cos(a),.305-.029*math.sqrt(max(0,1-t*t))+(k-2)*.0003,rr*math.sin(a)))
   trims.append(F.tube('one-of-five-real-reeds-in-bundled-scallop','binding',pts,.0010,sides=6))
 p.append(F.merge('twelve-thick-five-reed-lid-scallop-bundles','binding',trims))
 # Same close round actual weave closes the floor; real dark cavity remains, no opaque false wall.
 for j,x in enumerate(np.arange(-r+.002,r-.001,.0032)):
  span=math.sqrt(max(0,r*r-x*x));pts=[(x,.009,z)for z in np.linspace(-span,span,max(3,int(span/.003)))];body.append(F.tube('circular-close-basket-bottom-warp','rattan',pts,.0010,sides=6))
 for j,z in enumerate(np.arange(-r+.002,r-.001,.0032)):
  span=math.sqrt(max(0,r*r-z*z));pts=[(x,.009+.0011*math.cos((x+r)/.0032*math.pi+j*math.pi),z)for x in np.linspace(-span,span,max(3,int(span/.0025)))];body.append(F.tube('circular-close-basket-bottom-weft','rattan',pts,.0010,sides=6))
 p.append(F.merge('own-dense-cylinder-body-and-round-floor-real-strands','rattan',body));p.append(F.merge('own-dense-independent-radial-lid-real-strands','rattan',lid))
 return p,['Own full-resolution closeup: wider vertical staves, close rounded horizontal reeds, eight larger internal supports and thick bound rims replace rejected fine transparent wire mesh','Own lid has tight radial/concentric weaving and twelve thick five-reed hanging scallop bundles; body and floor remain a real hollow basket with small physical interstices','OfficialD34H32cm retained. Every strand is closed; no MDF lining invented for this rattan-only SKU; reed thickness/pitch/count and lid pose are explicit photo estimates'],{'body_vertical_staves_photo_estimate':112,'body_stave_width_mm_photo_estimate':4.2,'horizontal_reed_diameter_mm_photo_estimate':2.3,'horizontal_reed_pitch_mm_photo_estimate':3.0,'inner_structural_canes':8,'lid_scallop_bundles':12,'physical_real_small_interstices':True,'no_invented_opaque_lining':True}
def materials(out,pid,defs,masters):
 mats,maps=BASE(out,pid,defs,masters);rng=np.random.default_rng(int(pid));n=2048
 for key,(_,col,rough)in defs.items():
  # Native procedural longitudinal cortex is explicitly an interpretation, not a photographed weave texture.
  low=np.asarray(Image.fromarray(rng.normal(0,1,(70,8)).astype('float32'),'F').resize((n,n),Image.Resampling.BICUBIC));low=(low-low.mean())/max(low.std(),1e-6);fine=rng.normal(0,.4,(n,n));rgb=np.clip(np.array(col)[None,None,:]+(low*4.8+fine)[...,None]*np.array([1,.92,.68]),0,255).astype('uint8');height=low*.018;dy,dx=np.gradient(height);normal=np.stack([-dx,-dy,np.ones_like(dx)],2);normal/=np.linalg.norm(normal,axis=2,keepdims=True);orm=np.zeros((n,n,3),np.uint8);orm[:,:,0]=255;orm[:,:,1]=int(rough*255)
  for slot,a in [('albedo',rgb),('normal',np.clip((normal+1)*127.5,0,255).astype('uint8')),('orm',orm)]:
   f=out/(key+'-'+slot+'.png');Image.fromarray(a,'RGB').save(f,optimize=True);maps=[x for x in maps if not(x['material']==key and x['slot']==slot)]+[dict(material=key,slot=slot,path=str(f),sha256=F.sha(f),native_resolution=[n,n])]
  mats[key].update(normalScale=.18,extras=dict(intrinsic_material=True,photo_pixels_baked=False,source_guided_palette=True,appearance_photo_interpreted=True,native_resolution=[n,n],texture_generation='Own-SKU warm cream/natural cortex palette and nonperiodic longitudinal fibre interpretation, no generic grey-green photographed weave baking.',baked_reflections=False))
 return mats,maps
S={}
for sku,fn in [('1048866001',child),('1260559002',stool)]:
 sp=copy.deepcopy(OLD.S[sku]);sp['build']=fn;sp['materials']={'cane':('cane',[234,208,168],.55),'rattan':('cane',[228,199,153],.62),'binding':('cane',[235,207,158],.62)};sp['note']+=' V2: Kaynağın sık/dolgun kendi kamış örgüsü, gerçek sarım kalınlığı ve sıcak doğal pigmenti yeniden yorumlandı; önceki ince kafes formu hazır sayılmaz.';S[sku]=sp
if __name__=='__main__':
 for file in ['original-image-masters.json','source-queue-117.json','source-master-freeze-503.json']:shutil.copyfile(P/file,R/file)
 (R/'source-evidence').mkdir(exist_ok=True)
 for sku in S:shutil.copyfile(P/'source-evidence'/(sku+'.json'),R/'source-evidence'/(sku+'.json'))
 F.R=R;F.materials=materials;F.SPECS.update(S)
 for sku in sys.argv[1:]or S:F.build(sku)
 for n in ['audit_assets.py','make_contacts.py','batch_contacts.py','freeze_batch.py']:shutil.copyfile(P/n,R/n)
