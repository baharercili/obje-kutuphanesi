"""Independent readback from final GLB bytes, native maps, source-master and scope checks."""
from pathlib import Path
import json,struct,hashlib,sys
import numpy as np
R=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def read(path):
 raw=Path(path).read_bytes();magic,ver,total=struct.unpack_from('<4sII',raw);assert(magic,ver,total)==(b'glTF',2,len(raw));jl=struct.unpack_from('<I',raw,12)[0];doc=json.loads(raw[20:20+jl]);binary=raw[28+jl:]
 def attr(i):
  a=doc['accessors'][i];v=doc['bufferViews'][a['bufferView']];dt=np.dtype({5126:'<f4',5125:'<u4',5123:'<u2',5121:'u1'}[a['componentType']]);k={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}[a['type']];return np.ndarray((a['count'],k),dtype=dt,buffer=binary,offset=v.get('byteOffset',0)+a.get('byteOffset',0),strides=(v.get('byteStride',k*dt.itemsize),dt.itemsize)).copy()
 return doc,binary,attr
def audit(e):
 doc,binary,attr=read(e['glb_path']);assert not any('uri'in x for x in doc.get('images',[]));checks=[];bounds=[];model=json.loads(Path(e['model_path']).read_text())
 for m,expected in zip(doc['meshes'],model['meshes']):
  pr=m['primitives'][0];p=attr(pr['attributes']['POSITION']);n=attr(pr['attributes']['NORMAL']);uv=attr(pr['attributes']['TEXCOORD_0']);f=attr(pr['indices']).reshape(-1,3);assert np.isfinite(p).all()and np.isfinite(n).all()and np.isfinite(uv).all();assert f.max()<len(p)
  assert np.array_equal(p,np.asarray(expected['positions'],dtype=np.float32).reshape(-1,3));assert np.array_equal(uv,np.asarray(expected['uvs'],dtype=np.float32).reshape(-1,2));nl=np.linalg.norm(n,axis=1);assert(np.abs(nl-1)<1e-4).all()
  _,weld=np.unique(p,axis=0,return_inverse=True);wf=weld[f];directed=np.concatenate([wf[:,[0,1]],wf[:,[1,2]],wf[:,[2,0]]]);undirected=np.sort(directed,axis=1);order=np.lexsort((undirected[:,1],undirected[:,0]));edges=undirected[order];starts=np.r_[True,np.any(np.diff(edges,axis=0),axis=1)];inds=np.flatnonzero(starts);counts=np.diff(np.r_[inds,len(edges)]);assert(counts==2).all(),m['name']
  sign=(directed[order,0]<directed[order,1]).astype(np.int8)*2-1;winding=np.add.reduceat(sign,inds);assert(winding==0).all();area=np.linalg.norm(np.cross(p[f[:,1]]-p[f[:,0]],p[f[:,2]]-p[f[:,0]]),axis=1)/2;assert(area>1e-14).all();volume=np.einsum('ij,ij->i',p[f[:,0]].astype(float),np.cross(p[f[:,1]].astype(float),p[f[:,2]].astype(float))).sum()/6;assert volume>0
  bounds.append([p.min(0),p.max(0)]);checks.append(dict(name=m['name'],triangles=len(f),closed_after_exact_float32_position_weld=True,winding_consistent=True,normals_unit=True,min_area_m2=float(area.min()),volume_m3=float(volume),model_GLb_positions_UV_exact_float32=True))
 lo=np.min([x[0]for x in bounds],axis=0);hi=np.max([x[1]for x in bounds],axis=0);target=np.array(e['dimensions_cm'])/100;assert np.allclose(hi-lo,target,atol=2e-7);assert abs(float(lo[1]))<1e-7 and np.max(np.abs((lo+hi)[[0,2]]))<2e-7
 actualtex={}
 for im in doc['images']:
  bv=doc['bufferViews'][im['bufferView']];payload=binary[bv.get('byteOffset',0):bv.get('byteOffset',0)+bv['byteLength']];actualtex[hashlib.sha256(payload).hexdigest()]=len(payload)
 mat=json.loads(Path(e['material_validation']).read_text());mapchecks=[]
 for im in mat['maps']:
  current=sha(im['path']);assert current==im['sha256']and current in actualtex;mapchecks.append(dict(path=im['path'],sha256=current,GLB_embedded_byte_identical=True,native_resolution=im['native_resolution']))
 originals=[]
 for im in e['original_images']:
  current=sha(im['path']);assert current==im['sha256'];originals.append(dict(path=im['path'],sha256=current,unchanged=True))
 files=[]
 for label in ['on','on-capraz','yan','arka','ustten']:
  f=Path(e['asset_dir'])/(label+'.png');assert f.exists();files.append(dict(view=label,path=str(f),sha256=sha(f)))
 return dict(sku=e['sku'],id=e['id'],valid=True,glb_path=e['glb_path'],glb_sha256=sha(e['glb_path']),model_sha256=sha(e['model_path']),bytes=Path(e['glb_path']).stat().st_size,under_96_MB=Path(e['glb_path']).stat().st_size<96000000,dimensions_metres=(hi-lo).tolist(),bottom_y=float(lo[1]),xz_center=((lo+hi)[[0,2]]/2).tolist(),meshes=checks,embedded_maps=mapchecks,originals=originals,native_views=files,native_geometry_matches_export_source=True,root_actual_browser_review_pending=True)
if __name__=='__main__':
 entries=json.loads((R/'manifest.json').read_text());output=next((x.split('=',1)[1]for x in sys.argv[1:]if x.startswith('--output=')),'working-latest-independent-qa.json');requested=[x for x in sys.argv[1:]if not x.startswith('--output=')];rows=[]
 if(R/output).exists()and(output.startswith('frozen-')or output=='independent-qa.json'):raise RuntimeError('Reserved immutable QA output already exists; choose a new batch report name.')
 for e in entries:
  if requested and e['sku']not in requested:continue
  rows.append(audit(e));print('AUDIT PASS',e['sku'],flush=True)
 dump(R/output,dict(valid=all(x['valid']for x in rows),results=rows))
