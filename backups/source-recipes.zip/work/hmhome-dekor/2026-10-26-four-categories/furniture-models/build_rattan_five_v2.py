"""Five distinct own weave/lining repairs after the accepted child-chair method gate.
Original frozen seven remain byte-identical; no opaque lining is invented for rattan-only shelves.
"""
from pathlib import Path
import sys,math,copy,shutil
sys.dont_write_bytecode=True
import numpy as np
import build_models as F
BASE=F.materials
import build_rattan_seven as O
import build_rattan_two_v2 as V
from geometry_extra import extrude_xy
P=Path(__file__).resolve().parent;R=P/'revisions/rattan-five-v2';R.mkdir(parents=True,exist_ok=True);T=math.tau;SMALL_REED_SIDES=8
def weave(name,w,h,c,axis='front',top=None,mode='vertical'):
 cx,cy,cz=c;p=[];pitch=.0043 if mode=='vertical'else .0048
 def mappt(x,y,z):return(cx+x,cy+y,cz+z)if axis=='front'else(cx+z,cy+y,cz+x)if axis=='side'else(cx+x,cy+z,cz+y)
 def upper(x):return h/2 if top is None else top(cx+x)-cy
 for j,x in enumerate(np.arange(-w/2+.002,w/2-.001,pitch)):
  lo=-h/2;hi=upper(x)
  if hi<=lo+.001:continue
  rr=.0010 if mode=='round'else .00060;rw=.0011 if mode=='round'else .00165
  p.append(F.tube(name+'-own-wide-longitudinal-cane','rattan',[mappt(x,lo,0),mappt(x,hi,0)],rr,rw,sides=8,guide=[0,0,1]if axis=='front'else[1,0,0]if axis=='side'else[0,1,0]))
 step=.0032 if mode=='round'else .0060
 for j,y in enumerate(np.arange(-h/2+.001,h/2-.001,step)):
  xx=np.arange(-w/2+.001,w/2,pitch*.45);pts=[mappt(x,y,.0012*math.cos((x+w/2-.002)/pitch*math.pi+j*math.pi))for x in xx if y<upper(x)-.0006]
  if len(pts)>1:p.append(F.tube(name+'-own-close-round-crossing-reed','rattan',pts,.0011 if mode=='round'else .00065,sides=SMALL_REED_SIDES,guide=[0,0,1]if axis=='front'else[1,0,0]if axis=='side'else[0,1,0]))
 return p
def build(pid):
 global SMALL_REED_SIDES
 # Only sub-2.2mm reeds on the large shelf use six smooth section sides.
 # Strand count, pitch, open gaps and all large structural canes stay exact.
 SMALL_REED_SIDES=6 if pid=='1254736001'else 8
 fn={'1107974001':O.headboard,'1107975001':O.bench,'1161127001':lambda:O.cabinet_small('1161127001'),'1254736001':O.tall_shelf,'1260539001':lambda:O.cabinet_small('1260539001')}[pid];old,features,extra=fn();p=[g for g in old if not any(s in g['name']for s in ['all-four-actual-arched-rattan-infill','closed-individual-strands-storage-bench-and-lid','all-actual-cabinet-physical-weave','all-open-physical-rattan-shelves-sides'])];own=[]
 if pid=='1107974001':
  for i,(cx,top)in enumerate([(-.3375,.505),(-.1125,.651),(.1125,.651),(.3375,.505)]):
   iw=.175;itop=top-.077;spring=itop-iw/2;curve=lambda x,cx=cx,iw=iw,spring=spring:spring+math.sqrt(max(0,(iw/2)**2-(x-cx)**2));own+=weave('own-flat-vertical-arched-panel-'+str(i),iw-.008,itop-.018,(cx,(itop+.018)/2,.001),top=curve)
  features+=['V2 own headboard: broader close vertical flat cane strips and finer sparse round horizontal binding, not a uniform open wire grid; official reverse fabric stays behind it.']
 elif pid=='1107975001':
  for g in p:
   if g['name']in['real-front-finger-dip-rail','real-straight-rear-rail']:g['_vertices']=[(x,y+.034,z)for x,y,z in g['_vertices']]
  for z in[.120,-.120]:
   curve=(lambda x:.292-.033*math.exp(-(x/.070)**2))if z>0 else(lambda x:.292);own+=weave('own-close-round-front-or-rear-bench-cane',.493,.258,(0,.165,z),top=curve,mode='round')
   for x in np.arange(-.23,.231,.020):p.append(F.tube('own-visible-thicker-bench-vertical-carrier','cane',[(x,.044,z+(.003 if z>0 else-.003)),(x,curve(x)-.003,z+(.003 if z>0 else-.003))],.0025,sides=10))
  for sx in[-1,1]:
   own+=weave('own-bench-side-close-round-weave',.222,.263,(sx*.255,.168,0),'side',mode='round')
   for z in np.arange(-.10,.101,.020):p.append(F.tube('own-visible-thicker-bench-side-carrier','cane',[(sx*.258,.044,z),(sx*.258,.294,z)],.0025,sides=10))
  lid=weave('own-dense-separate-curved-seat-lid',.503,.223,(0,.300,0),'top',mode='round')
  for g in lid:g['_vertices']=[(x,y+.016*(1-(z/.126)**2),z)for x,y,z in g['_vertices']]
  own+=lid
  # Official Shell rattan100 / Lining MDF100 is actual material, not a transparent gap.
  front=[(-.241,.040),(.241,.040),(.241,.290)]+[(x,.290-.027*math.exp(-(x/.070)**2))for x in np.linspace(.241,-.241,100)[1:]];p.append(extrude_xy('official-MDF-front-lining-following-real-finger-dip','mdf',front,.110,.116))
  p.append(F.board('official-MDF-rear-lining','mdf',.482,.252,.006,(0,.166,-.112),.001))
  for sx in[-1,1]:p.append(F.board('official-MDF-side-lining','mdf',.006,.252,.216,(sx*.241,.166,0),.001))
  p.extend([F.board('official-MDF-storage-floor-lining','mdf',.482,.006,.218,(0,.041,0),.001),F.board('official-MDF-lid-underside-lining','mdf',.482,.007,.211,(0,.295,0),.001),F.board('official-folded-under-lid-textile-safety-strap','strap',.015,.0012,.055,(0,.266,-.090),.0003)])
  features+=['V2 own bench: close rounded horizontal reeds dominate, structural vertical canes stay visible; real finite MDF front/rear/sides/floor/lid lining fills source opacity and keeps an empty storage cavity. Official folded safety strap included.'];extra.update(official_MDF_lining_present=True,lining_placement_and_thickness_photo_estimated=True,official_under_lid_textile_strap_present=True)
 elif pid in['1161127001','1260539001']:
  small=pid=='1161127001';w=.32 if small else .647;d=.34 if small else .37;front=d/2-.012
  for sx in[-1,1]:own+=weave('own-cabinet-close-wide-vertical-side-canes',d-.043,.330,(sx*(w/2-.012),.212,0),'side')
  own+=weave('own-cabinet-close-wide-vertical-rear',w-.043,.330,(0,.212,-front));own+=weave('own-cabinet-close-top-mat',w-.043,d-.043,(0,.389,0),'top',mode='round')
  count=1 if small else 2;dw=(w-.046)/count
  for i in range(count):
   cx=(i-(count-1)/2)*(dw+.004);own+=weave('own-separate-door-wide-vertical-rattan-infill',dw-.012,.313,(cx,.2145,front+.004))
  features+=['V2 this exact cabinet: wide vertical reed rhythm dominates each door/side, fine round transverse ties and close rounded top mat; keep distinct three/six petal handle and actual empty MDF shelf/floor. No opaque false door photograph.']
 else:
  w=.56;d=.37;front=.173;back=-.173;spring=.77;rad=.267;top=lambda x:spring+math.sqrt(max(0,rad*rad-x*x))
  for sx in[-1,1]:own+=weave('own-wide-vertical-flat-cane-tall-side',d-.045,.715,(sx*.266,.405,0),'side')
  for y in[.048,.405,.770]:own+=weave('one-of-three-own-close-reed-shelf-floors',.510,d-.045,(0,y,0),'top',mode='round')
  own+=weave('own-upper-arched-rear-close-vertical-panel',.512,.255,(0,.8975,back),top=top)
  crown=weave('own-close-round-reed-curved-crown',.510,d-.045,(0,spring,0),'top',mode='round')
  for g in crown:g['_vertices']=[(x,y+top(x)-spring,z)for x,y,z in g['_vertices']]
  own+=crown;features+=['V2 tall shelf:3 densely rounded-reed horizontal floors, broad vertical side canes and close curved crown/rear arch; lower rear remains genuinely open. No MDF/opaque lining is invented for the rattan100 source.']
 p.append(F.merge('SKU-specific-closed-strands-and-source-dominant-weave','rattan',own));extra.update(own_source_weave_reconstruction_v2=True,local_weave_dimensions_photo_estimated=True);return p,features,extra
def materials(out,pid,defs,masters):
 cane={k:v for k,v in defs.items()if v[0]=='cane'};other={k:v for k,v in defs.items()if v[0]!='cane'};m1,p1=V.materials(out,pid,cane,masters);m2,p2=BASE(out,pid,other,masters);return dict(m1,**m2),p1+p2
S={}
for sku in['1107974001','1107975001','1161127001','1254736001','1260539001']:
 sp=copy.deepcopy(O.S[sku]);sp['build']=lambda sku=sku:build(sku);sp['materials']['cane']=('cane',[234,209,170],.56);sp['materials']['rattan']=('cane',[228,200,153],.63);sp['materials']['mdf']=('paint',[183,151,107],.82);sp['materials']['strap']=('paint',[196,174,132],.95);sp['note']+=' V2: Kendi ürünün sık geniş kamış/yatay-dikey örgü ritmi ve sıcak pigmenti ayrı yeniden kurulur. Bankta resmîMDFastar gerçek kapalı iç panellerdir; diğer ürünlerde yayımlanmamış astar varsayılmadı. Yerel örgü/astar/sarım ölçüleri fotoğraf tahminidir.';S[sku]=sp
if __name__=='__main__':
 for f in ['original-image-masters.json','source-queue-117.json','source-master-freeze-503.json']:shutil.copyfile(P/f,R/f)
 (R/'source-evidence').mkdir(exist_ok=True)
 for sku in S:shutil.copyfile(P/'source-evidence'/(sku+'.json'),R/'source-evidence'/(sku+'.json'))
 F.R=R;F.materials=materials;F.SPECS.update(S)
 for sku in sys.argv[1:]or S:F.build(sku)
 for n in ['audit_assets.py','make_contacts.py','batch_contacts.py','freeze_batch.py']:shutil.copyfile(P/n,R/n)
