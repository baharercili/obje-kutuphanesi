"""One isolated material/UV-scale correction, sourced from the own light longitudinal packshot face."""
from pathlib import Path
import sys,json,copy,shutil
sys.dont_write_bytecode=True
import numpy as np
from PIL import Image,ImageFilter
import build_models as F
P=Path(__file__).resolve().parent;R=P/'revisions/mango-light-longitudinal-grain-v3';R.mkdir(parents=True,exist_ok=True);sku='1206454002'
old=next(e for e in json.loads((P/'revisions/root-four-corrections-v2/frozen-root-four-corrections-v2-manifest.json').read_text())if e['sku']==sku);src=Path(old['asset_dir']);out=R/'models'/old['id'];assert not(out/'frozen.json').exists();out.mkdir(parents=True,exist_ok=True)
before={str(p):F.sha(p)for p in src.iterdir()if p.is_file()};model=json.loads(Path(old['model_path']).read_text());baseline=copy.deepcopy(model['meshes']);mval=json.loads(Path(old['material_validation']).read_text())
for p in src.glob('*.png'):
 if p.name not in['on.png','on-capraz.png','yan.png','arka.png','ustten.png']:shutil.copyfile(p,out/p.name)
for p in src.glob('*-provenance.json'):shutil.copyfile(p,out/p.name)
masters=[x for x in json.loads((P/'original-image-masters.json').read_text())if x['sku']==sku];master=next(x for x in masters if 'ccfe42c1de0a'in x['path']);box=[1420,1290,1676,2314];raw=Image.open(master['path']).convert('RGB').crop(box);raw.save(out/'wood-native-donor.png');patch=raw.transpose(Image.Transpose.ROTATE_90);rgb=np.asarray(patch).astype(float);hh,ww=rgb.shape[:2];yy,xx=np.mgrid[:hh,:ww];A=np.c_[np.ones(hh*ww),xx.ravel()/ww,yy.ravel()/hh];plane=(A@np.linalg.lstsq(A,rgb.mean(2).ravel(),rcond=None)[0]).reshape(hh,ww);rgb=np.clip(rgb-(plane-plane.mean())[:,:,None],0,255)
grey=rgb.mean(2);lo=np.asarray(Image.fromarray(grey.astype('uint8')).filter(ImageFilter.GaussianBlur(1.5))).astype(float);dy,dx=np.gradient((grey-lo)*.010);normal=np.stack([-dx,-dy,np.ones_like(dx)],2);normal/=np.linalg.norm(normal,axis=2,keepdims=True);orm=np.zeros((hh,ww,3),np.uint8);orm[:,:,0]=255;orm[:,:,1]=125
maps=[dict(x,path=str(out/Path(x['path']).name))for x in mval['maps']if x['material']!='wood']
for slot,a in[('albedo',rgb.astype('uint8')),('normal',np.clip((normal+1)*127.5,0,255).astype('uint8')),('orm',orm)]:
 f=out/('wood-'+slot+'.png');Image.fromarray(a,'RGB').save(f,optimize=True);maps.append(dict(material='wood',slot=slot,path=str(f),sha256=F.sha(f),native_resolution=[ww,hh]))
for m,oldmesh in zip(model['meshes'],baseline):
 if m['material']!='wood':continue
 uv=np.asarray(m['uvs']).reshape(-1,2);uv[:,0]=(uv[:,0]-.5)*(.15/.439);uv[:,1]=(uv[:,1]-.3)*(.30/.12);m['uvs']=uv.reshape(-1).tolist()
 assert all(m[k]==oldmesh[k]for k in['positions','normals','indices'])
 # Both affine scales are positive: longitudinal direction and chart orientation remain unchanged.
prov=dict(master=master['path'],master_sha256=master['sha256'],source_crop_pixel_box=box,raw_crop=str(out/'wood-native-donor.png'),raw_crop_SHA=F.sha(out/'wood-native-donor.png'),native_crop_pixels=[256,1024],lossless_rotation_degrees=90,output_pixels=[1024,256],no_upscale=True,geometric_resampling_count=0,physical_extent_cm_photo_estimated=[43.9,12],UV_material_scale=[.15/.439,.30/.12],UV_direction_preserved=True,method='Light right-front leg face from the exactSKU primary packshot. A single longitudinal native grain extent covers each actual leg instead of repeating a dark centre-leg patch three times. Only fitted illumination-plane subtraction; no pattern synthesis or pixel upsampling. Positions, normals and indices remain byte-equivalent arrays; positive affine UV rescale retains grain direction. Natural grain phase of separate legs remains an approximate reconstruction.')
F.dump(out/'wood-crop-provenance.json',prov);model['materials']['wood'].update(normalScale=.30,extras=dict(intrinsic_material=True,photo_pixels_baked=True,own_photo_material_crop=True,crop_provenance=str(out/'wood-crop-provenance.json'),native_resolution=[1024,256],baked_reflections=False,natural_pattern_placement_interpreted=True))
reason='Açık mango tonu ve uzunlamasına damar kendi ana ürün fotoğrafının açık ön ayak yüzünden alınır. Koyu merkez ayak örneği kullanılmaz; tekrar ölçeği tek ayak boyunca bir native örnek olarak düzeltilir. Geometri/normal/indeksler sabit, UV yönü aynı ve pozitif ölçekle yeniden ayarlıdır; doğal tekil damar fazı yorumdur.'
model['metadata'].update(model_revision='hm-furniture-light-mango-material-v3',revision_note=reason,supersedes_glb=old['glb_path'],supersedes_glb_sha256=old['sha256']);F.dump(out/'model.json',model);geo=json.loads(Path(old['geometry_validation']).read_text());geo['revision_note']=reason;F.dump(out/'geometry-validation.json',geo);F.dump(out/'material-validation.json',dict(mval,maps=maps,revision_note=reason))
report=F.EX.export_assets(out/'model.json',out,old['id']);glb=out/(old['id']+'.glb');doc,binary=F.EX.read_glb(glb);doc['samplers']=[dict(magFilter=9729,minFilter=9987,wrapS=10497,wrapT=10497)]
for t in doc.get('textures',[]):t['sampler']=0
binary=F.G.M.embed_tangents(doc,binary);F.EX.write_glb(glb,doc,binary);report['deliverable_sha256']['glb']=F.sha(glb);report['glb_bytes']=glb.stat().st_size;report['source_sha256']=F.sha(out/'model.json');F.dump(report['files']['validation'],report)
entry=dict(old,asset_dir=str(out),model_path=str(out/'model.json'),glb_path=str(glb),sha256=F.sha(glb),bytes=glb.stat().st_size,geometry_validation=str(out/'geometry-validation.json'),material_validation=str(out/'material-validation.json'),model_revision=model['metadata']['model_revision'],revision_note=reason,supersedes_glb=old['glb_path'],supersedes_glb_sha256=old['sha256'])
for k in['independent_qa','native_render_paths','source_native_comparison']:entry.pop(k,None)
F.dump(out/'entry.json',entry);F.dump(R/'manifest.json',[entry]);assert all(F.sha(p)==s for p,s in before.items());F.dump(out/'revision-preservation.json',dict(sku=sku,old_v1_v2_unchanged=True,positions_normals_indices_exact=True,only_wood_UV_positive_affine_scale=True,stone_material_bytes_preserved=True,own_JPEG_master_SHA_unchanged=F.sha(master['path'])==master['sha256'],no_upscale=True))
for n in['audit_assets.py','make_contacts.py','freeze_batch.py']:shutil.copyfile(P/'revisions/root-four-corrections-v2'/n,R/n)
shutil.copyfile(P/'source-master-freeze-503.json',R/'source-master-freeze-503.json');print('mango v3',entry['sha256'],flush=True)
