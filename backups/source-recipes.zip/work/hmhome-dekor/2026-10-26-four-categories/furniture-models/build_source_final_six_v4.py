"""Source-front corrections isolated from every previously frozen candidate."""
from pathlib import Path
import sys,copy,math,shutil,json
sys.dont_write_bytecode=True
import numpy as np
from PIL import Image,ImageFilter
import build_models as F
BASE=F.materials
import build_upholstery_eight as U
import build_outdoor_sofas_nine as O
import build_source_shape_five_v2 as OLD
import build_live_hard_nineteen as H
import build_root_shape_three_v3 as K
import build_rattan_horizontal_four_v3 as W
import build_rattan_five_v2 as D
U.BASE=BASE;O.BASE=BASE;H.BASE=BASE;W.BASE=BASE;D.BASE=BASE
P=Path(__file__).resolve().parent;R=P/'revisions/source-final-six-v4';R.mkdir(parents=True,exist_ok=True)
G=F.G;B=F.B;T=math.tau

def padded_panel(name,outline,center,thickness,zfun,repeat=.16):
 """Closed convex padded outline with a softly rolled common perimeter seam."""
 poly=np.asarray(outline,float);c=np.asarray(center,float);n=len(poly);vv=[];uv=[];ff=[];scales=[0,.16,.34,.52,.70,.84,.93,1.0]
 for side in[-1,1]:
  off=len(vv);vv.append((c[0],c[1],zfun(*c)+side*thickness/2));uv.append((c[0]/repeat,c[1]/repeat))
  for t in scales[1:]:
   for p in poly:
    x,y=c+(p-c)*t;vv.append((x,y,zfun(x,y)+side*thickness/2*math.sqrt(max(0,1-t**4))));uv.append((x/repeat,y/repeat))
  for j in range(n):ff.append((off,off+1+j,off+1+(j+1)%n))
  for k in range(len(scales)-2):
   for j in range(n):
    a=off+1+k*n+j;b=off+1+k*n+(j+1)%n;ff.extend([(a,b,a+n),(b,b+n,a+n)])
 return B.solid(name,'fabric',vv,ff,uv)

def smooth_outline(points,steps=10):
 a=np.asarray(points,float);out=[]
 for i in range(len(a)):
  p0,p1,p2,p3=[a[j%len(a)]for j in[i-1,i,i+1,i+2]]
  for t in np.linspace(0,1,steps,endpoint=False):out.append(.5*(2*p1+(-p0+p2)*t+(2*p0-5*p1+4*p2-p3)*t*t+(-p0+3*p1-3*p2+p3)*t*t*t))
 return out

def avern():
 p,f,e=O.avern();p=[g for g in p if g['name']not in['own-one-left-architectural-arm','own-straight-low-back','own-separate-full-seat']]
 p.append(O.soft('own-soft-low-left-arm-below-source-arch',(.10,.425,.915),(-.2325,.2125,0),.045,loft=.004))
 p.append(O.soft('own-separate-seat-top-at-published-29p5cm',(.465,.115,.80),(.050,.2335,.024),.037,loft=.004))
 poly=[(-.1975,.235),(.2825,.235),(.2825,.49)]+[(.0425+.24*math.cos(a),.49+.09*math.sin(a))for a in np.linspace(0,math.pi,100)[1:]]
 p.append(padded_panel('own-genuinely-arched-padded-back-top',poly,(.0425,.365),.13,lambda x,y:-.3925,.24))
 for g in p:
  if 'arched-padded'not in g['name']:g['_uvs']=[(x*.16/.24,y*.16/.24)for x,y in g['_uvs']]
 f+=['V4 own full front and native woven closeups: source back has a true continuous elliptical top ARCH, not a rectangular panel with softened corners. One lower left arm and separate filled seat retained.','Own fabric-only1024px native crop preserves slub/pigment; local24cm repeat and seam/arch curvature are photo estimates. Official seat top29.5cm is separate from overall58cm.'];e.update(true_arched_back_top=True,official_seat_top_cm=29.5,own_native_fabric_patch=True);return p,f,e

def dining_pair():
 allp=[]
 for i in range(2):
  prof=[(0,.391),(.18,.391),(.23,.400),(.25,.425),(.25,.465),(.23,.492),(.18,.502),(0,.498)]
  seat=B.lathe('own-true-round-oval-filled-seat','fabric',prof,192,False);seat['_vertices']=[(x,y,z*.47/.50+.025)for x,y,z in seat['_vertices']];seat['_uvs']=[(x/.16,z/.16)for x,y,z in seat['_vertices']];p=[seat]
  points=[(0,.760),(.15,.748),(.224,.703),(.224,.642),(.207,.565),(.153,.440),(0,.421),(-.153,.440),(-.207,.565),(-.224,.642),(-.224,.703),(-.15,.748)]
  p.append(padded_panel('own-tapered-egg-oval-concave-back',smooth_outline(points), (0,.592),.070,lambda x,y:-.17+.10*(x/.224)**2-.020*(y-.44)/.32))
  for sx in[-1,1]:
   for sz in[-1,1]:p.append(O.tube('one-of-four-source-slender-chrome-legs',[(sx*.235,0,sz*.225),(sx*.185,.425,sz*.165)],.0075,'frame',20))
  p.append(F.tube('own-thin-closed-chrome-underseat-perimeter','frame',[(.245*math.cos(a),.401,.23*math.sin(a)+.025)for a in np.linspace(0,T,160,endpoint=False)],.0035,sides=12,closed=True))
  allp+=O.shift(O.W.fit_piece(p,.55,.76,.58),x=(-.35 if i==0 else .35),z=(-.12 if i==0 else .12))
 return allp,['BOTH actual source dining chairs: true rounded/oval filled seat and a tapered egg-shaped concave back outline, with forward-curving lateral wings; no rounded-rectangular surrogate','Each official55×58×76cm preserved before estimated two-chair display arrangement, own cream boucle and chrome frames. Local contour/concavity/seam interpretation'],dict(set_quantity=2,set_piece_dimensions_whd_cm=[[55,76,58],[55,76,58]],set_display_arrangement_estimated=True,total_leg_count=8,source_true_egg_oval_concave_back=True,source_round_filled_seat=True,own_chrome_legs=True)

def bench_weave(name,w,h,c,axis='front',top=None,mode='vertical'):
 if 'front-or-rear-bench'in name or 'bench-side'in name:mode='vertical'
 return W.weave(name,w,h,c,axis,top,mode)
def bench():
 W.CURRENT='1107975001';D.weave=bench_weave;p,f,e=D.build('1107975001');p=[g for g in p if 'own-visible-thicker-bench-'not in g['name']]
 f+=['V4 root/source-specific bench: broad HORIZONTAL flat exterior wefts with fine vertical triplet binding replace prominent vertical wires; good source lid/finger-dip profile/official finite MDF lining and empty storage cavity stay unchanged.','Local4mm weft/4.4mm pitch, fine triplet carrier and own warm honey pigment are photo-estimated. Lid retains separately rounded reed geometry.'];e.update(dominant_external_body_weave='broad horizontal flat wefts plus fine vertical triplet carriers',previous_prominent_vertical_wire_carriers_removed=True,official_MDF_lining_present=True);return p,f,e
W.PALETTE['1107975001']=[224,195,147]

def chaise():
 p,f,e=O.curved_sofa();p=[g for g in p if not any(s in g['name']for s in['own-left-thin-full-rounded-arm','own-left-full-seat-base','own-right-elongated-soft-chaise-base','small-source-wooden-foot'])]
 p+=[O.soft('own-full-low-left-arm-to-base',(.245,.58,.98),(-1.0575,.30,-.010),.10,loft=.006),O.soft('own-near-floor-full-left-seat-front',(1.06,.41,.91),(-.43,.2175,-.005),.085,loft=.010)]
 g=O.soft('own-near-floor-full-rounded-right-chaise',(1.22,.41,1.06),(.54,.2175,.035),.12,loft=.010);g['_vertices']=[(x+.045*math.sin((z+.495)/1.06*math.pi),y,z)for x,y,z in g['_vertices']];p.append(g)
 p.append(O.soft('own-continuous-fixed-rear-upholstered-support',(1.93,.23,.105),(-.085,.365,-.385),.035,loft=.004))
 for name,dims,c in[('own-recessed-dark-left-low-plinth',(.94,.028,.79),(-.43,.014,0)),('own-recessed-dark-right-low-plinth',(1.10,.028,.93),(.54,.014,.03))]:p.append(F.board(name,'lowplinth',*dims,c,.004))
 f+=['V4 exact-source straight FRONT: fill the upholstered front/base down to a narrow dark recessed support at ground, removing visible floating foot/body gaps. Low support is physically intersecting inside the base, not a detached foot pin.','Both loose pillows, continuous rear support, one left arm and source curved open right chaise remain. Local hidden support/low plinth is photo reconstruction, not newly asserted official construction.'];e.update(near_floor_filled_front=True,no_floating_leg_to_body_gap=True,dark_recessed_support_photo_estimated=True);return p,f,e

def pebble():
 old,f,e=U.pebble_lounge();p=[g for g in old if not any(s in g['name']for s in['central-rounded-seat','ellipsoidal-pebble-arm','small-separate-feet'])]
 p.append(U.soft('own-thick-low-filled-seat-top35cm',(.59,.31,.64),(0,.195,.065),.090,loft=.006))
 prof=[(0,.008),(.060,.008),(.095,.016),(.125,.045),(.137,.11),(.14,.23),(.137,.40),(.125,.52),(.10,.59),(.06,.625),(0,.634)]
 for sx in[-1,1]:
  g=B.lathe('own-upright-capsule-arm-with-broad-rounded-flat-contact','fabric',prof,192,False);g['_vertices']=[(x+sx*.359,y,z*2.75)for x,y,z in g['_vertices']];a=.14;b=.385;circ=math.pi*(3*(a+b)-math.sqrt((3*a+b)*(a+3*b)));g['_uvs']=[(math.atan2(z/b,(x-sx*.359)/a)*circ/T/.16,y/.16)for x,y,z in g['_vertices']];p.append(g)
 f+=['V4 exact-source full FRONT: two UPRIGHT padded capsule arms with broad softly rounded flat lower contacts, not pointed ellipsoids/lenses. Filled central seat extends low, with official35cm as top rather than center.','No added unsupported small foot pins; source native own fabric pigment and fibre patch retained unchanged. Arm profile/local seam/contact sections are explicit photo interpretation.'];e.update(official_seat_height_semantics='seat top, not center',upright_capsule_arms=True,broad_lower_arm_contact=True,thick_low_seat=True);return p,f,e

def full_capsule_hole(name,w,h,z0,z1,hx,hy,r,segment):
 # Uniform angular sampling of both rings is essential: corner-only rectangle
 # samples omit the slot ends and can collapse an oblong opening to a triangle.
 angles=list(np.linspace(0,T,256,endpoint=False))
 angles += [math.atan2(y-hy,x-hx)%T for x in[-w/2,w/2]for y in[0,h]]
 angles=sorted(set(angles));outer=[];inner=[]
 for a in angles:
  dx,dy=math.cos(a),math.sin(a);tx=((w/2 if dx>=0 else -w/2)-hx)/dx if abs(dx)>1e-12 else 1e9;ty=((h if dy>=0 else 0)-hy)/dy if abs(dy)>1e-12 else 1e9;t=min(tx,ty);outer.append((hx+t*dx,hy+t*dy));ti=r/max(abs(dx),1e-12)
  if abs(ti*dy)>segment:
   cy=math.copysign(segment,dy);ti=cy*dy+math.sqrt(max(0,(cy*dy)**2-cy*cy+r*r))
  inner.append((hx+ti*dx,hy+ti*dy))
 n=len(angles);vv=[(x,y,z)for z in[z0,z1]for ring in[outer,inner]for x,y in ring];ff=[]
 for j in range(n):
  k=(j+1)%n
  for o in[0,2*n]:ff.extend([(o+j,o+k,o+n+j),(o+k,o+n+k,o+n+j)])
  ff.extend([(j,j+2*n,k),(k,j+2*n,k+2*n),(n+j,n+k,n+j+2*n),(n+k,n+k+2*n,n+j+2*n)])
 return B.solid(name,'body',vv,ff,[(x/.16,y/.16)for x,y,z in vv])

def books():
 p,f,e=H.floor_books();p=[g for g in p if g['name']not in['actual-tall-book-display-rear-panel','one-of-three-real-UPPER-scalloped-book-pocket-fronts']]
 # First inclined floor stays above zero instead of translating/scaling the whole90cm rear panel.
 for g in p:
  if 'inclined-empty-book-pocket-floors'in g['name']:
   mn=min(q[1]for q in g['_vertices'])
   if mn<0:g['_vertices']=[(x,y-mn,z)for x,y,z in g['_vertices']]
 for i,(y,z,d,height)in enumerate([(.020,.027,.23,.103),(.315,-.015,.17,.110),(.610,-.071,.08,.113)]):
  lip=H.W.scalloped_apron(.394,height,6,'source-front-measured-scalloped-pocket-lip-'+str(i),amplitude=.026);lip['_vertices']=[(x,y-.020+height-yy,z+d/2+zz)for x,yy,zz in lip['_vertices']];p.append(F.ROOT.wood_uv(lip,False))
 back=full_capsule_hole('own-full-back-with-long-visible-oblong-slot',.432,.90,-.150,-.134,0,.8465,.007,.0255);p.append(F.ROOT.wood_uv(back,True));p.append(H.wood('own-source-full-horizontal-top-cap-shelf',.414,.016,.125,(0,.892,-.080)))
 f+=['V4 own exact full FRONT7ce1bc91b55e source ratios: lower the slot below the cap so its complete14×65mm local opening reads, rather than a white triangle hidden behind the cap. Slot local dimensions are photo estimates, not official numbers.','Source visible90cm panel native2224px: scalloped lip maxima approx10.3/11.0/11.3cm and six waves with2.6cm drop. Front aprons lowered accordingly, stepped sides/three empty inclined pockets stay.'];e.update(full_horizontal_top_cap_present=True,physical_oblong_hanging_through_slot=True,slot_width_height_cm_photo_estimate=[1.4,6.5],slot_center_height_cm_photo_estimate=84.65,source_front_lip_heights_cm_photo_estimate=[10.3,11.0,11.3],source_front_wave_drop_cm_photo_estimate=2.6,source_ratio_master_hint='7ce1bc91b55e',source_measurement_method='full-source frontal pixel ratios within published90cm panel');return p,f,e

def materials(out,pid,defs,masters):
 if pid=='1107975001':return W.materials(out,pid,defs,masters)
 if pid=='1281678002':return BASE(out,pid,defs,masters)
 if pid=='1338979001':return U.materials(out,pid,defs,masters)
 mats,maps=O.materials(out,pid,defs,masters)
 if pid!='1343871002':return mats,maps
 master=next(x for x in masters if '2edf285b9ef0'in x['path']);box=[500,500,1524,1524];patch=Image.open(master['path']).convert('RGB').crop(box);raw=out/'fabric-native-donor.png';patch.save(raw);a=np.asarray(patch).astype(float);low=np.asarray(patch.filter(ImageFilter.GaussianBlur(18))).astype(float);median=np.median(a.reshape(-1,3),axis=0);rgb=np.clip(a-low+median,0,255)
 for k in range(20):
  t=(20-k)/40;l=rgb[:,k].copy();r=rgb[:,-1-k].copy();rgb[:,k]=l*(1-t)+r*t;rgb[:,-1-k]=r*(1-t)+l*t;u=rgb[k].copy();v=rgb[-1-k].copy();rgb[k]=u*(1-t)+v*t;rgb[-1-k]=v*(1-t)+u*t
 grey=rgb.mean(2);lo=np.asarray(Image.fromarray(grey.astype('uint8')).filter(ImageFilter.GaussianBlur(1.2))).astype(float);dy,dx=np.gradient((grey-lo)*.030);norm=np.stack([-dx,-dy,np.ones_like(dx)],axis=2);norm/=np.linalg.norm(norm,axis=2,keepdims=True);orm=np.zeros((1024,1024,3),np.uint8);orm[:,:,0]=255;orm[:,:,1]=233
 provenance=dict(master=master['path'],master_sha256=master['sha256'],source_crop_pixel_box=box,native_crop_pixels=[1024,1024],output_pixels=[1024,1024],raw_crop=str(raw),raw_crop_sha256=F.sha(raw),no_upscale=True,geometric_resampling_count=0,physical_repeat_metres_photo_estimate=.24,method='Own native exactSKU fabric-only crop, pixel-identical raw retained.18px illumination removal plus20px periodic-edge blend; all visible yarn/slub pixels stay native. No source silhouette/staging/seams baked.')
 F.dump(out/'fabric-crop-provenance.json',provenance)
 for slot,im in[('albedo',rgb.astype('uint8')),('normal',np.clip((norm+1)*127.5,0,255).astype('uint8')),('orm',orm)]:
  q=out/('fabric-'+slot+'.png');Image.fromarray(im,'RGB').save(q,optimize=True);maps=[x for x in maps if not(x['material']=='fabric'and x['slot']==slot)]+[dict(material='fabric',slot=slot,path=str(q),sha256=F.sha(q),native_resolution=[1024,1024])]
 mats['fabric'].update(normalScale=.72,sheen=.12,extras=dict(intrinsic_material=True,photo_pixels_baked=True,own_photo_material_crop=True,crop_provenance=str(out/'fabric-crop-provenance.json'),native_resolution=[1024,1024],baked_reflections=False));return mats,maps

S={}
for sku,fn in [('1343871002',avern),('1301068001',dining_pair),('1107975001',bench),('1331378001',chaise),('1338979001',pebble),('1281678002',books)]:
 sp=copy.deepcopy(D.S[sku]if sku=='1107975001'else H.S[sku]if sku=='1281678002'else OLD.S[sku]);sp['build']=fn;sp['note']+=' Ayrı V4: Kendi TAM ÖN fotoğrafının dolgu/zemin teması, özel sırt dış konturu, görünür örgü veya delik/cep oranları kaynakla düzeltildi. Yerel yorumlar resmî ölçü değildir; önceki donmuş dosyalar değişmedi.';S[sku]=sp
S['1331378001']['materials']['lowplinth']=('paint',[28,24,20],.85)
if __name__=='__main__':
 for n in['original-image-masters.json','source-queue-117.json','source-master-freeze-503.json']:shutil.copyfile(P/n,R/n)
 (R/'source-evidence').mkdir(exist_ok=True)
 for sku in S:shutil.copyfile(P/'source-evidence'/(sku+'.json'),R/'source-evidence'/(sku+'.json'))
 F.R=R;F.materials=materials;F.SPECS.update(S)
 for sku in sys.argv[1:]or S:F.build(sku)
 for n in['audit_assets.py','make_contacts.py','batch_contacts.py','freeze_batch.py']:shutil.copyfile(P/n,R/n)
