"""Own 1331379001: thicker rounded tub/inner arms and its short draped fur."""
from pathlib import Path
import sys,math,json,copy,shutil
sys.dont_write_bytecode=True
import numpy as np
from PIL import Image,ImageFilter
import build_models as F
import build_last_soft_six as L
import build_continuous_u_pilot_v4 as C
P=Path(__file__).resolve().parent;R=P/'revisions/own-furry-tub-thick-arms-v5'
OLD=P/'revisions/last-five-soft-technical-candidates-v4/frozen-own-last-five-TECHNICAL-candidates-visual-pending-manifest.json'
B=F.B;G=F.G;T=math.tau

def tub_wall():
    path=L.smooth_path([(.378,.292),(.399,.105),(.392,-.065),(.335,-.267),(.20,-.350),(0,-.364),(-.20,-.350),(-.335,-.267),(-.392,-.065),(-.399,.105),(-.378,.292)],24)
    length=np.r_[0,np.cumsum(np.linalg.norm(np.diff(path,axis=0),axis=1))];sides=72;v=[];uv=[];faces=[];tops=[]
    for i,(x,z) in enumerate(path):
        t=path[min(i+1,len(path)-1)]-path[max(i-1,0)];t/=np.linalg.norm(t);side=np.array([-t[1],t[0]]);rear=np.clip((.292-z)/.656,0,1);top=.638+.071*rear;tops.append(top)
        for j in range(sides+1):
            a=(j%sides)*T/sides;y=.018+(top-.018)*(.5+.5*np.sign(math.cos(a))*abs(math.cos(a))**.50)
            off=.102*np.sign(math.sin(a))*abs(math.sin(a))**.58
            xx,zz=np.array([x,z])+off*side;v.append((xx,y,zz));uv.append((length[i]/.36,y/.36))
    for i in range(len(path)-1):
        for j in range(sides):
            a=i*(sides+1)+j;b=a+sides+1;faces.extend([(a,b,a+1),(a+1,b,b+1)])
    # Continuous convex arm ends (no thin pale flat inner-arm inserts).
    for endpoint,sgn in[(0,-1),(len(path)-1,1)]:
        boundary=[endpoint*(sides+1)+j for j in range(sides)];original=np.asarray(v)[boundary];centre=np.array([path[endpoint,0],(.018+tops[endpoint])/2,path[endpoint,1]]);t=path[min(endpoint+1,len(path)-1)]-path[max(endpoint-1,0)];t/=np.linalg.norm(t);outward=sgn*np.array([t[0],0,t[1]])
        for scale in[.88,.68,.44,.20]:
            ring=[]
            for q in original:
                q=centre+(q-centre)*scale+outward*.030*(1-scale**2);ring.append(len(v));v.append(tuple(q));uv.append((q[0]/.36,q[1]/.36))
            for j in range(sides):
                k=(j+1)%sides;faces.extend([(boundary[j],boundary[k],ring[j]),(boundary[k],ring[k],ring[j])])
            boundary=ring
        ci=len(v);q=centre+outward*.030;v.append(tuple(q));uv.append((q[0]/.36,q[1]/.36))
        for j in range(sides):faces.append((boundary[j],boundary[(j+1)%sides],ci))
    return B.solid('own-thick-continuous-round-inner-arms-full-height-furry-tub-shell','fabric',v,faces,uv)

def fur(parts,count,stations,long):
    rng=np.random.default_rng(1331379001+(51 if long else 52));children=12;parents=(count+children-1)//children;qq=[];nn=[];aa=[]
    for g in parts:
        if g['material']!='fabric':continue
        g=G.H.orient(g);v=np.asarray(g['_vertices']);f=np.asarray(g['_faces']);q=v[f];n=np.cross(q[:,1]-q[:,0],q[:,2]-q[:,0]);a=np.linalg.norm(n,axis=1);n/=a[:,None];keep=n[:,1]>-.45;qq.append(q[keep]);nn.append(n[keep]);aa.append(a[keep])
    q=np.concatenate(qq);n=np.concatenate(nn);a=np.concatenate(aa);idx=rng.choice(len(q),parents,p=a/a.sum());q=q[idx];pn=n[idx];u=np.sqrt(rng.random(parents));w=rng.random(parents);pr=(1-u)[:,None]*q[:,0]+(u*(1-w))[:,None]*q[:,1]+(u*w)[:,None]*q[:,2];root=np.repeat(pr,children,0)[:count];normal=np.repeat(pn,children,0)[:count]
    # Own source walls drape down; the seat and tops sweep in slow local swirls.
    phase=np.repeat(rng.uniform(0,T,parents),children)[:count]+rng.normal(0,.17,count);field=.7*np.sin(root[:,0]*26+root[:,2]*19)+.45*np.cos(root[:,2]*31-root[:,1]*12)
    flow=np.c_[.35*np.sin(field),-np.ones(count),.20*np.cos(field)];top=normal[:,1]>.67;flow[top]=np.c_[np.cos(field[top]+phase[top]*.2),np.zeros(top.sum()),np.sin(field[top]+phase[top]*.2)];flow-=normal*(normal*flow).sum(1)[:,None];flow/=np.linalg.norm(flow,axis=1)[:,None];across=np.cross(normal,flow);root+=across*rng.normal(0,.0011 if long else .0005,count)[:,None]
    lengths=np.repeat(rng.uniform(.020,.045,parents)if long else rng.uniform(.005,.013,parents),children)[:count]*rng.uniform(.72,1.20,count);f=np.linspace(0,1,stations);c=root[:,None,:]-.0007*normal[:,None,:]+normal[:,None,:]*(lengths[:,None,None]*.65*np.sin(f*math.pi*.76)[None,:,None])+flow[:,None,:]*(lengths[:,None,None]*.92*f[None,:,None]);freq=np.repeat(rng.uniform(.9,1.9,parents),children)[:count];wave=np.sin(T*freq[:,None]*f+phase[:,None])-np.sin(phase)[:,None];c+=across[:,None,:]*(lengths[:,None,None]*.16*wave[:,:,None]*f[None,:,None]**.6);c[:,:,1]-=lengths[:,None]*.20*f[None,:]**1.6
    tt=np.gradient(c,axis=1);tt/=np.linalg.norm(tt,axis=2,keepdims=True);guide=np.broadcast_to([0.,1,0],tt.shape).copy();guide[abs(tt[:,:,1])>.9]=[1,0,0];span=np.cross(tt,guide);span/=np.linalg.norm(span,axis=2,keepdims=True);up=np.cross(tt,span);ang=np.arange(3)*T/3;width=rng.uniform(.00035,.00085,count)if long else rng.uniform(.00025,.00055,count);nr=stations*3;per=nr+2;rad=width[:,None]*(.50*(1-f)**.66+.025)[None,:];rings=c[:,:,None,:]+(span[:,:,None,:]*np.cos(ang)[None,None,:,None]+up[:,:,None,:]*np.sin(ang)[None,None,:,None])*rad[:,:,None,None];v=np.concatenate([rings.reshape(count,nr,3),c[:,:1],c[:,-1:]],1)
    local=[]
    for j in range(stations-1):
        for k in range(3):
            a=j*3+k;b=j*3+(k+1)%3;cc=a+3;d=b+3;local.extend([(a,cc,b),(b,cc,d)])
    for k in range(3):local.extend([(nr,k,(k+1)%3),(nr+1,nr-3+(k+1)%3,nr-3+k)])
    ff=np.asarray(local)[None,:,:]+np.arange(count)[:,None,None]*per;trip=v.reshape(-1,3)[ff.reshape(-1,3)];vol=np.einsum('ij,ij->i',trip[:,0],np.cross(trip[:,1],trip[:,2])).reshape(count,-1).sum(1)/6;assert abs(vol).min()>1e-14;ff[vol<0]=ff[vol<0][:,:,[0,2,1]];uv=np.zeros((count,per,2));ru=rng.uniform(.004,.991,count);uv[:,:nr,0]=ru[:,None]+np.tile(np.arange(3)/3,stations)[None,:]*.003;uv[:,:nr,1]=np.repeat(f,3)[None,:]+np.tile(np.sin(ang),stations)[None,:]*.0003;uv[:,nr:,0]=ru[:,None]+.001;uv[:,nr+1,1]=1
    return B.solid(('own-medium-length-down-draping-locks-'if long else'own-conformal-dense-short-underfur-')+str(count),'pile',v.reshape(-1,3).tolist(),ff.reshape(-1,3).tolist(),uv.reshape(-1,2).tolist())

def build():
    parts=[L.plump_base('own-source-full-round-front-and-floor-contact',.925,.875,.38,.035),tub_wall(),L.soft('own-source-separate-generously-filled-back-pillow',(.66,.34,.16),(0,.548,-.255),.069,loft=.015)]
    # The lathe pole UV formerly stretched its own fine grain into long lines
    # across the seat. Physical face charts preserve isotropic native fur scale.
    for g in parts:
        C.physical_fabric_charts(g);g['_uvs']=[(a*.16/.36,b*.16/.36)for a,b in g['_uvs']]
    long=fur(parts,24000,8,True);short=fur(parts,14000,4,False);parts.extend([long,short]);return parts,['Own1331379001 packshots7199/9e42/31bb: thick continuous softly rounded inner arms and convex full-height arm ends; full round floor-supported front, separate real back pillow. No narrow inner-arm inserts.','Own closeup28b81af supplies native fur grain/colour residual on the undercoat. 24000 medium down-draping free guard fibres +14000 shorter conformal fibres have coherent slow source flow, not radial helmet or card petals.','OfficialW101/D94/H75cm retained. Local20–45mm medium fur,5–13mm underfur, arm thickness and hidden support are photo estimates; source RGB/texture lighting removal is explicitly interpreted.'],dict(own_thick_rounded_inner_arms=True,continuous_full_height_tub=True,arm_end_caps_convex=True,independent_free_guard_fibres=24000,independent_short_underfur=14000,guard_length_m_photo_estimate=[.020,.045],own_undercoat_native_crop=True)

def materials(out,pid,defs,masters):
    old=next(e for e in json.loads(OLD.read_text())if e['sku']==pid);model=json.loads(Path(old['model_path']).read_text());mats=copy.deepcopy(model['materials']);mv=json.loads(Path(old['material_validation']).read_text());doc,bin=F.EX.read_glb(old['glb_path']);payload={};assert F.sha(old['glb_path'])==old['sha256']
    for im in doc['images']:
        v=doc['bufferViews'][im['bufferView']];b=bin[v.get('byteOffset',0):v.get('byteOffset',0)+v['byteLength']];payload[F.hashlib.sha256(b).hexdigest()]=b
    maps=[]
    for im in mv['maps']:
        dst=out/Path(im['path']).name;dst.write_bytes(payload[im['sha256']]);maps.append(dict(im,path=str(dst)))
    master=next(x for x in masters if'28b81af111a7'in x['path']);box=[480,900,1504,1924];patch=Image.open(master['path']).convert('RGB').crop(box);raw=out/'fabric-native-own-fur-closeup.png';patch.save(raw);a=np.asarray(patch).astype(float);low=np.asarray(patch.filter(ImageFilter.GaussianBlur(22))).astype(float);residual=np.clip(a-low,-36,36);rgb=np.clip(np.array([237,227,210])+residual*.65,0,255).astype('uint8')
    # Deterministic periodic edge blending, derived copy only; no native master
    # alteration and no resampling. Four native tiles form a 2048 map.
    for axis in[0,1]:
        rgb=rgb.swapaxes(0,axis).copy()
        for k in range(24):
            t=(24-k)/24*.5;x=rgb[k].astype(float);y=rgb[-1-k].astype(float);mid=(x+y)/2;rgb[k]=np.clip(x*(1-t)+mid*t,0,255);rgb[-1-k]=np.clip(y*(1-t)+mid*t,0,255)
        rgb=rgb.swapaxes(0,axis)
    grey=a.mean(2);lo=np.asarray(Image.fromarray(grey.astype('uint8')).filter(ImageFilter.GaussianBlur(2))).astype(float);height=(grey-lo)*.10;dy,dx=np.gradient(height);normal=np.stack([-dx,-dy,np.ones_like(dx)],2);normal/=np.linalg.norm(normal,axis=2,keepdims=True);normal=np.clip((normal+1)*127.5,0,255).astype('uint8')
    for slot,arr in [('albedo',rgb),('normal',normal)]:
        tiled=np.tile(arr,(2,2,1));dst=out/('fabric-'+slot+'.png');Image.fromarray(tiled,'RGB').save(dst,optimize=True);maps=[m for m in maps if not(m['material']=='fabric'and m['slot']==slot)]+[dict(material='fabric',slot=slot,path=str(dst),sha256=F.sha(dst),native_resolution=[2048,2048])]
    mats['fabric'].update(normalScale=.55);mats['fabric']['extras'].update(own_photo_material_crop=True,photo_pixels_baked=True,native_resolution=[2048,2048],source_crop_native_resolution=[1024,1024],four_native_tiles_without_resampling=True,crop_provenance=str(out/'fabric-crop-provenance.json'));F.dump(out/'fabric-crop-provenance.json',dict(master=master['path'],master_sha256=master['sha256'],source_crop_pixel_box=box,native_crop_pixels=[1024,1024],output_pixels=[2048,2048],raw_crop=str(raw),raw_crop_sha256=F.sha(raw),no_upscale=True,native_tiles=[2,2],master_untouched=True,low_frequency_illumination_removed=True,undercoat_pigment_photo_interpreted=[237,227,210],derived_periodic_edge_pixels_changed=True,physical_repeat_wh_m_photo_estimate=[.36,.36],no_product_silhouette_or_staging_bake=True,method='Own fabric-only closeup1024native crop, low-frequency illumination removed in DERIVED copy; source fine fur residual retained,24px periodic-edge blend,2x2 native pixel tiling without upscaling. Fine guard fibres retain own original pigment map.'))
    F.dump(out/'own-material-preservation-and-undercoat-grain-proof.json',dict(source_glb=old['glb_path'],source_glb_sha256=old['sha256'],own_guard_pigment_maps_byte_identical=True,changed_maps=['fabric-albedo.png','fabric-normal.png'],reason='own closeup native fur grain on the conformal undercoat, not full-product photo wrapping',source_PNGs_freshly_read=False));return mats,maps

if __name__=='__main__':
    R.mkdir(parents=True,exist_ok=True)
    for n in['original-image-masters.json','source-queue-117.json','source-master-freeze-503.json','audit_assets.py','make_contacts.py','batch_contacts.py','freeze_batch.py']:shutil.copyfile(P/n,R/n)
    (R/'source-evidence').mkdir(exist_ok=True);shutil.copyfile(P/'source-evidence/1331379001.json',R/'source-evidence/1331379001.json');sp=copy.deepcopy(L.S['1331379001']);sp['build']=build;sp['note']+=' V5 kendi kaynak revizyonu: kalın yuvarlak iç kollar ve dolu U kabuk, kendi yakın planından yüzey ve aşağı yatan orta uzunlukta post. Genel tabure postu kopyası değildir.';F.R=R;F.materials=materials;F.SPECS['1331379001']=sp;F.build('1331379001')
