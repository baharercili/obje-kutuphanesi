"""Root-caught S-bend and four pebble-leg corrections; frozen11 stays intact."""
from pathlib import Path
import sys,copy,math,shutil
sys.dont_write_bytecode=True
import numpy as np
import build_models as F
BASE=F.materials
import build_live_variants_eleven as OLD
F.materials=BASE;G=F.G;B=F.B;T=math.tau;P=Path(__file__).resolve().parent;R=P/'revisions/live-three-v2';R.mkdir(parents=True,exist_ok=True)
def rounded_bends(points,r=.026):
 a=np.asarray(points);out=[a[0]]
 for i in range(1,len(a)-1):
  q=a[i];v1=a[i-1]-q;v2=a[i+1]-q;l1=np.linalg.norm(v1);l2=np.linalg.norm(v2);cut=min(r,l1*.45,l2*.45);s=q+v1/l1*cut;e=q+v2/l2*cut;out.append(s)
  for t in np.linspace(0,1,22)[1:]:out.append((1-t)**2*s+2*(1-t)*t*q+t*t*e)
 out.append(a[-1]);return out
def shelf():
 p=[]
 for j,y in enumerate([.053,.283,.513]):p.append(F.ROOT.wood_uv(F.board('own-one-of-three-natural-wood-shelves-'+str(j),'wood',.60,.012,.216,(0,y,0),.002),False))
 path=[(-.105,.655),(-.105,.590),(.105,.550),(.105,.490),(-.105,.450),(-.105,.360),(.105,.320),(.105,.260),(-.105,.220),(-.105,.130),(.105,.090),(.105,.030),(-.105,.010)]
 for sx in[-1,1]:p.append(F.tube('own-continuous-large-radius-S-bent-iron-support','frame',[(sx*.233,y,z)for z,y in rounded_bends(path)],.004,sides=20,guide=[1,0,0]))
 return p,['Own same-SKU red/sage shelf closeups: two continuous iron S supports have genuinely broad smooth physical bends around each board','Three actual wood/MDF shelves remain independent, no sharp90degree Z steps','Official60×23×66cm preserved; local bend radius up to26mm is photo reconstruction. No books/toys'],{'shelf_count':3,'continuous_S_supports':2,'smooth_physical_large_radius_bends':True,'bend_radius_mm_photo_estimate':26}
def pebble_table():
 a=np.linspace(0,T,256,endpoint=False);r=1+.025*np.sin(a*3+.7)+.009*np.cos(a*5);p2=np.c_[.23*np.sign(np.cos(a))*np.abs(np.cos(a))**.82*r,.19*np.sign(np.sin(a))*np.abs(np.sin(a))**.82*r];p2-=(p2.min(0)+p2.max(0))/2;p2*=np.array([.46,.38])/(p2.max(0)-p2.min(0));profiles=[]
 for fac,y in[(.94,.376),(.99,.382),(1,.394),(.98,.406),(.94,.41)]:profiles.append(([(x*fac,z*fac)for x,z in p2],y))
 p=[F.ROOT.wood_uv(G.capped('own-organic-soft-pebble-outline-top','body',profiles,True,.20),False)]
 profile=[(0,0),(.028,0),(.040,.008),(.053,.035),(.062,.105),(.064,.195),(.061,.280),(.052,.345),(.041,.382),(0,.382)]
 for sx in[-1,1]:
  for sz in[-1,1]:
   g=B.lathe('one-of-four-full-convex-soft-oval-pebble-legs','body',profile,192,False);g['_vertices']=[(x+sx*.122+sx*.004*math.sin(y/.382*math.pi),y,z*1.12+sz*.090)for x,y,z in g['_vertices']];g=F.ROOT.wood_uv(g,True);p.append(g)
 return p,['Own brown source has FOUR separate full softly convex oval/pebble legs, not two rounded rectangular blocks','Each leg tapers softly into its base/shoulder and has a generous mid-height oval section; own top has a soft organic outline','Official46×38×41cm maintained; local four-leg positions, convex profile and MDF wood-look grain phase interpreted'],{'source_observed_leg_count':4,'legs_are_continuously_convex_not_blocks':True,'top_has_own_organic_contour':True}
S={}
for sku in ['1096727005','1096727007','1338724001']:
 sp=copy.deepcopy(OLD.S[sku]);sp['build']=pebble_table if sku=='1338724001'else shelf;sp['note']+=' V2: Kaynakta görülen dört dolgun oval ayak/organik tabla veya sürekli geniş yarıçaplıSmetal kıvrımı gerçek geometriyle düzeltildi; frozen11 değişmez.';S[sku]=sp
if __name__=='__main__':
 for file in ['original-image-masters.json','source-queue-117.json','source-master-freeze-503.json']:shutil.copyfile(P/file,R/file)
 (R/'source-evidence').mkdir(exist_ok=True)
 for sku in S:shutil.copyfile(P/'source-evidence'/(sku+'.json'),R/'source-evidence'/(sku+'.json'))
 F.R=R;F.materials=BASE;F.SPECS.update(S)
 for sku in sys.argv[1:]or S:F.build(sku)
 for n in ['audit_assets.py','make_contacts.py','batch_contacts.py','freeze_batch.py']:shutil.copyfile(P/n,R/n)
