"""Source front has many visible triplet carriers;8 total cannot match it."""
from pathlib import Path
import sys,math,copy,shutil
sys.dont_write_bytecode=True
import numpy as np
import build_models as F
import build_rattan_two_v2 as V
P=Path(__file__).resolve().parent;R=P/'revisions/rattan-stool-source-bundles-v4';R.mkdir(parents=True,exist_ok=True);T=math.tau
def build():
 p,f,e=V.stool();p=[g for g in p if g['name']!='actual-separate-thick-inner-structural-cane'];strands=[]
 #24 around the hidden circumference is a photographic reconstruction, NOT
 # an official/exact manufacturer count. Own central eight complete visible
 # triplets and compressed edge carriers disprove the old8-total rhythm.
 for a in np.arange(24)*T/24+T/48:
  for k in[-1,0,1]:
   aa=a+k*.00205/.164;rr=.164;pts=[(rr*math.cos(aa),.008,rr*math.sin(aa)),(rr*math.cos(aa),.287,rr*math.sin(aa))];strands.append(F.tube('own-one-of-three-visible-canes-in-external-carrier-bundle','cane',pts,.00105,sides=10))
 p.append(F.merge('photo-interpreted24-external-triplet-carriers','cane',strands));f+=['Own native source115a4288474e midbody crop shows eight complete central triplet carriers plus additional foreshortened edge carriers, approximately12 rhythms across the front half. Eight total is insufficient.','24 full-circumference triplet bundles are explicitly a photo reconstruction; the hidden rear count is not verified or claimed official. Existing dense weave, real gaps, lid/scallop/rim geometry and warm intrinsic materials remain.'];e.update(photo_estimated_full_circumference_carrier_bundles=24,canes_per_carrier_bundle=3,source_visible_central_complete_bundles=8,hidden_rear_count_unverified=True,official_carrier_count_not_claimed=True);return p,f,e
sp=copy.deepcopy(V.S['1260559002']);sp['build']=build;sp['note']+=' V4: Ön kaynak fotoğrafındaki çok telli sık dış dikey ritim için24üçlü taşıyıcı demeti kullanıldı.8orta tam demet doğrudan görünür, yanlar perspektifle sıkışır; görünmeyen arka çevrenin24sayısı fotoğraf yorumudur, resmî/ölçülmüş sayı değildir.'
if __name__=='__main__':
 for n in['original-image-masters.json','source-queue-117.json','source-master-freeze-503.json']:shutil.copyfile(P/n,R/n)
 (R/'source-evidence').mkdir(exist_ok=True);shutil.copyfile(P/'source-evidence/1260559002.json',R/'source-evidence/1260559002.json');F.R=R;F.materials=V.materials;F.SPECS['1260559002']=sp;F.build('1260559002')
 for n in['audit_assets.py','make_contacts.py','batch_contacts.py','freeze_batch.py']:shutil.copyfile(P/n,R/n)
