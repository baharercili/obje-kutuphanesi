from pathlib import Path
import sys,json,subprocess
from PIL import Image
R=Path(__file__).resolve().parent;name=sys.argv[1];skus=sys.argv[2:]
subprocess.run([sys.executable,str(R/'make_contacts.py'),*skus],check=True)
for i in range(0,len(skus),3):
 im=Image.new('RGB',(2400,550*len(skus[i:i+3])),'#eeeae5')
 for j,sku in enumerate(skus[i:i+3]):im.paste(Image.open(R/'qa/source-native-comparisons'/(sku+'-comparison.jpg')),(0,550*j))
 im.save(R/'qa'/(name+'-native-'+str(i//3+1)+'.jpg'),quality=92)
