from pathlib import Path
import json,hashlib
import numpy as np
R=Path(__file__).resolve().parent;rows=json.loads((R/'manifest.json').read_text())
def a(m):return np.asarray(m['positions']).reshape(-1,3)
def intersections(m,x,z):
 q=a(m)[np.asarray(m['indices']).reshape(-1,3)];aa=q[:,0][:,[0,2]];bb=q[:,1][:,[0,2]];cc=q[:,2][:,[0,2]];v0=bb-aa;v1=cc-aa;v2=np.array([x,z])-aa;de=v0[:,0]*v1[:,1]-v1[:,0]*v0[:,1];valid=abs(de)>1e-14;u=np.zeros(len(q));w=u.copy();u[valid]=(v2[valid,0]*v1[valid,1]-v1[valid,0]*v2[valid,1])/de[valid];w[valid]=(v0[valid,0]*v2[valid,1]-v2[valid,0]*v0[valid,1])/de[valid];k=valid&(u>=-1e-8)&(w>=-1e-8)&(u+w<=1+1e-8);return(q[k,0,1]+u[k]*(q[k,1,1]-q[k,0,1])+w[k]*(q[k,2,1]-q[k,0,1])).tolist()
proof=[]
for e in rows:
 ms=json.loads(Path(e['model_path']).read_text())['meshes'];tests=[]
 def test(label,body,x,z,level):
  yy=sum([intersections(m,x,z)for m in body],[]);passed=bool(yy and min(yy)<=level+1e-7 and max(yy)>=level-1e-7);tests.append(dict(test=label,xz_m=[float(x),float(z)],support_top_y_m=float(level),body_intersections_y_m=yy,contact_or_overlap=passed));assert passed,tests[-1]
 if e['sku']=='1368744001':
  seats=[m for m in ms if 'THREE-own-full-supported-seat'in m['name']];pl=[m for m in ms if 'source-low-full-plinth'in m['name']];shell=next(m for m in ms if 'continuous-240cm-U'in m['name'])
  for m in seats:
   v=a(m);x=(v[:,0].min()+v[:,0].max())/2;support=min(pl,key=lambda q:abs((a(q)[:,0].min()+a(q)[:,0].max())/2-x));top=a(support)[:,1].max()
   for z in[-.15,0,.15]:test('each source seat on own low plinth',[m],x,z,top)
  for sx in[-1,1]:test('continuous U arm bottom intersects side plinth',[shell],sx*1.065,0,a(pl[0 if sx<0 else 2])[:,1].max())
 else:
  frame=next(m for m in ms if 'thin-soft-source-lower-frame'in m['name']);top=a(frame)[:,1].max();seat=next(m for m in ms if 'sagged-puffy-seat'in m['name']);arms=[m for m in ms if 'sloping-convex-arm'in m['name']];feet=[m for m in ms if 'small-separate-feet'in m['name']]
  for x,z in[(0,0),(.12,0),(-.12,0),(0,-.10),(0,.10)]:test('loose seat physically rests on frame',[seat],x,z,top)
  for m in arms:
   v=a(m);x=(v[:,0].min()+v[:,0].max())/2;test('loose arm cover volume on frame',[m],x,0,top)
  for m in feet:
   v=a(m);x,z=(v.min(0)+v.max(0))[[0,2]]/2;test('own real foot top meets thin frame',[frame],x,z,v[:,1].max())
 extras=[]
 for view in['on-tam','arka-tam','on-hafif']:
  f=Path(e['asset_dir'])/(view+'.png')
  if f.exists():extras.append(dict(view=view,path=str(f),sha256=hashlib.sha256(f.read_bytes()).hexdigest()))
 proof.append(dict(sku=e['sku'],valid=True,physical_contact_samples=tests,extra_true_front_views=extras,own_native_material_proof=str(Path(e['asset_dir'])/'own-material-byte-preservation-and-roughness-proof.json'),source_specific_features='continuous U+3seat/3innerback/3plinth'if e['sku']=='1368744001'else'distinct sloping sewn arms, loose plump seat/back, thin lower frame+4feet',root_actual_visual_gate_pending=True))
(R/'physical-contacts-and-own-material-proof.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n');print('PHYSICAL CONTACT PASS',[(r['sku'],len(r['physical_contact_samples']))for r in proof])
