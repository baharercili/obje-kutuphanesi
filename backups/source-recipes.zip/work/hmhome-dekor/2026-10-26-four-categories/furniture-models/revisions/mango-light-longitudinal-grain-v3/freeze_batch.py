"""Immutable candidate batch; ready/approval remains owned by actual-browser reviewer."""
from pathlib import Path
import sys,json,hashlib,subprocess,datetime
R=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
name=sys.argv[1];skus=sys.argv[2:];assert name and skus
manifest=R/('frozen-'+name+'-manifest.json');proof=R/('frozen-'+name+'-proof.json');qa=R/('frozen-'+name+'-independent-qa.json');assert not manifest.exists()and not proof.exists()
if not qa.exists():subprocess.run([sys.executable,str(R/'audit_assets.py'),'--output='+qa.name,*skus],check=True)
report=json.loads(qa.read_text());assert report['valid']and{r['sku']for r in report['results']}==set(skus)
entries=[e for e in json.loads((R/'manifest.json').read_text())if e['sku']in skus];assert len(entries)==len(skus);files=[]
for e in entries:
 out=Path(e['asset_dir']);assert not(out/'frozen.json').exists();q=next(x for x in report['results']if x['sku']==e['sku']);assert q['glb_sha256']==sha(e['glb_path'])==e['sha256']and q['model_sha256']==sha(e['model_path'])
 e.update(independent_qa=str(qa),source_native_comparison=str(R/'qa/source-native-comparisons'/(e['sku']+'-comparison.jpg')),native_render_paths={k:str(out/(k+'.png'))for k in['on','on-capraz','yan','arka','ustten']},root_actual_review_pending=True,quality_pending=True)
 dump(out/'frozen.json',dict(id=e['id'],candidate_only=True,root_actual_review_pending=True,glb_sha256=e['sha256'],model_sha256=sha(e['model_path'])))
 paths=[Path(e['model_path']),Path(e['glb_path']),out/'geometry-validation.json',out/'material-validation.json',out/'frozen.json',out/(e['id']+'.validation.json'),Path(e['source_native_comparison']),*[out/(k+'.png')for k in['on','on-capraz','yan','arka','ustten']],*list(out.glob('*-albedo.png')),*list(out.glob('*-normal.png')),*list(out.glob('*-orm.png')),*list(out.glob('*-crop-provenance.json')),*list(out.glob('*-native-donor.png')),*list(out.glob('revision-preservation.json'))]
 files.extend(dict(sku=e['sku'],path=str(x),sha256=sha(x),bytes=x.stat().st_size)for x in paths)
dump(manifest,entries);dump(proof,dict(created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),candidate_manifest=str(manifest),candidate_manifest_sha256=sha(manifest),independent_qa=str(qa),independent_qa_sha256=sha(qa),scope117_unchanged=True,source_scope_complete=False,candidate_count=len(entries),root_actual_review_pending=True,no_canonical_or_old_master_changes=True,source_master_freeze=str(R/'source-master-freeze-503.json'),source_master_freeze_sha256=sha(R/'source-master-freeze-503.json'),files=files))
print(json.dumps(dict(manifest=str(manifest),sha256=sha(manifest),proof_sha256=sha(proof),SKUs=skus),ensure_ascii=False),flush=True)
