"""1254723001: one continuous sewn beanbag shell, no arm pillar overlays."""
from pathlib import Path
import sys,math,json,copy,shutil
sys.dont_write_bytecode=True
import numpy as np
from PIL import Image
import build_models as F
import build_last_soft_six as L
import build_shell_pouf_source_v5 as S
import build_continuous_u_pilot_v4 as C
P=Path(__file__).resolve().parent;R=P/'revisions/own-shell-continuous-beanbag-v6';T=math.tau
OLD=P/'revisions/own-shell-pouf-deep-filled-rolls-v5/frozen-own-deep-filled-shell-pouf-v5-CANDIDATE-manifest.json'

def body():
    sides=256;rings=64;v=[(0,.213,0)];uv=[(0,0)];faces=[]
    def outline(a,r):return(.273*r*np.sign(math.cos(a))*abs(math.cos(a))**.79,.242*r*np.sign(math.sin(a))*abs(math.sin(a))**.84)
    def height(a,r):
        front=math.sin(a);back=np.clip(-front,0,1);side=abs(math.cos(a));upper=(.105*side**1.5+.192*back**1.15)*np.clip((.68-front)/.50,0,1)
        ridge=math.exp(-((r-.835)/.190)**2);seat=.204+.009*(1-r*r)
        # Six upper back rolls fade into the single lower beanbag, not down
        # through its floor-to-top arm ends as separate capsule pillars.
        theta=a if a>=math.pi else a+T;fan=np.clip((theta-math.pi)/math.pi,0,1);channel=math.sin(math.pi*5*fan)**2 if front<0 else 0
        channel*=min(1,back/.20);valley=.032*channel*math.exp(-((r-.82)/.25)**2)
        return seat+upper*ridge-valley
    previous=None
    for ir,r in enumerate(np.linspace(1/rings,1,rings)):
        ring=[]
        for j in range(sides):
            a=j*T/sides;x,z=outline(a,r);ring.append(len(v));v.append((x,height(a,r),z));uv.append((x/.18,z/.18))
        if previous is None:
            for j in range(sides):faces.append((0,ring[j],ring[(j+1)%sides]))
        else:
            for j in range(sides):
                k=(j+1)%sides;faces.extend([(previous[j],ring[j],previous[k]),(previous[k],ring[j],ring[k])])
        previous=ring
    # The same outer skin rolls over into a full sewn lower front and broad
    # soft floor contact; there are no separate front arm caps or body seams.
    for t in np.linspace(1/32,1,32):
        ring=[];radius=1+.025*math.sin(math.pi*t)-.085*t*t
        for j in range(sides):
            a=j*T/sides;x,z=outline(a,radius);top=height(a,1);y=.004+(top-.004)*(1-t)**.95;ring.append(len(v));v.append((x,y,z));uv.append((x/.18,y/.18))
        for j in range(sides):
            k=(j+1)%sides;faces.extend([(previous[j],ring[j],previous[k]),(previous[k],ring[j],ring[k])])
        previous=ring
    ci=len(v);v.append((0,.004,0));uv.append((0,0))
    for j in range(sides):faces.append((previous[j],ci,previous[(j+1)%sides]))
    g=F.B.solid('own-ONE-continuous-sewn-beanbag-floor-front-arms-and-six-back-rolls','fabric',v,faces,uv);C.physical_fabric_charts(g);g['_uvs']=[(a*.16/.18,b*.16/.18)for a,b in g['_uvs']];return g

def build():
    parts=S.short_plush([body()]);return parts,['Own1254723001 source: ONE watertight continuously sewn lower beanbag skin, front body and both arms; the upper six back-rolls and five fan channels fade into that same lower body. No floor-to-top independent arm capsules or end-panel plates.','Seat, inner rounded arm crests, outer sides, front and base are connected faces of ONE closed material shell. Native own short-pile RGB/normal PNGs fromV5 preserved,38k short plush follows this new shell.','Published approximateW55/H40cm retained; D49cm, local stuffing/roll phase/hidden underside are explicit photo reconstructions.'],dict(single_continuous_sewn_beanbag_surface=True,own_back_rolls_photo_interpreted=6,fan_channel_count=5,no_separate_arm_pillars=True,no_separate_base_arm_cap_interfaces=True,short_plush_independent_fibres=38000)

def materials(out,pid,defs,masters):
    old=json.loads(OLD.read_text())[0];model=json.loads(Path(old['model_path']).read_text());mats=copy.deepcopy(model['materials']);mv=json.loads(Path(old['material_validation']).read_text());doc,bin=F.EX.read_glb(old['glb_path']);payload={};assert F.sha(old['glb_path'])==old['sha256']
    for im in doc['images']:
        v=doc['bufferViews'][im['bufferView']];b=bin[v.get('byteOffset',0):v.get('byteOffset',0)+v['byteLength']];payload[F.hashlib.sha256(b).hexdigest()]=b
    maps=[]
    for im in mv['maps']:
        dst=out/Path(im['path']).name;dst.write_bytes(payload[im['sha256']]);assert F.sha(dst)==im['sha256'];maps.append(dict(im,path=str(dst)))
    for src in Path(old['asset_dir']).glob('*-crop-provenance.json'):
        a=json.loads(src.read_text());raw=out/Path(a['raw_crop']).name;Image.open(a['master']).convert('RGB').crop(a['source_crop_pixel_box']).save(raw);assert F.sha(raw)==a['raw_crop_sha256'];a['raw_crop']=str(raw);F.dump(out/src.name,a);mats['fabric']['extras']['crop_provenance']=str(out/src.name)
    F.dump(out/'own-V5-short-pile-material-preservation-proof.json',dict(source_glb=old['glb_path'],source_glb_sha256=old['sha256'],all_own_material_PNGbytes_identical=True,maps=maps,source_PNGs_freshly_read=False));return mats,maps

if __name__=='__main__':
    R.mkdir(parents=True,exist_ok=True)
    for n in['original-image-masters.json','source-queue-117.json','source-master-freeze-503.json','audit_assets.py','make_contacts.py','batch_contacts.py','freeze_batch.py']:shutil.copyfile(P/n,R/n)
    (R/'source-evidence').mkdir(exist_ok=True);shutil.copyfile(P/'source-evidence/1254723001.json',R/'source-evidence/1254723001.json');sp=copy.deepcopy(L.S['1254723001']);sp['build']=build;sp['note']+=' V6: alt gövde/ön/kol/sırt tek kapalı sürekli yumuşak kabuk; üst6rulo aynı alt gövdeye erir. Ayrı uzun kol sütunu veya ayrı kapak yüzü yok. OwnV5kısa hav haritaları aynıdır.';F.R=R;F.materials=materials;F.SPECS['1254723001']=sp;F.build('1254723001')
