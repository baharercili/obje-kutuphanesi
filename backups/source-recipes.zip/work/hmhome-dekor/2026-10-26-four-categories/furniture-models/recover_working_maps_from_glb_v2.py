"""Rehydrate only unfrozen derived PNGs from byte-identical embedded GLB data."""
import sys,json,struct,hashlib,os
from pathlib import Path
P=Path(__file__).resolve().parent
report=[]
for sku in sys.argv[1:]:
 out=next((P/'models').glob('hm-'+sku+'-*'));assert not(out/'frozen.json').exists()
 glb=next(out.glob('*.glb'));a=glb.read_bytes();n=struct.unpack_from('<I',a,12)[0];d=json.loads(a[20:20+n]);nn=struct.unpack_from('<I',a,20+n)[0];b=a[28+n:28+n+nn];content={}
 for im in d.get('images',[]):
  v=d['bufferViews'][im['bufferView']];x=b[v.get('byteOffset',0):v.get('byteOffset',0)+v['byteLength']];content[hashlib.sha256(x).hexdigest()]=x
 validation=json.loads((out/'material-validation.json').read_text())
 targets=[(Path(m['path']),m['sha256'])for m in validation['maps']]
 for f in (out/'textures').glob('*.png'):
  targets.extend((f,h)for h in content if h.startswith(f.stem))
 for f,h in targets:
  if not(f.exists()and f.stat().st_flags&0x40000000):continue
  x=content[h];assert hashlib.sha256(x).hexdigest()==h;tmp=f.with_suffix('.restore-tmp');tmp.write_bytes(x);os.replace(tmp,f);assert hashlib.sha256(f.read_bytes()).hexdigest()==h
  report.append(dict(path=str(f),sha256=h,source_glb=str(glb),unfrozen=True,byte_identical_to_current_embedded_image=True));print('RESTORED',sku,f.name,flush=True)
out=P/'qa'/('map-byte-recovery-'+sys.argv[1]+'.json');assert not out.exists();out.write_text(json.dumps(report,indent=2)+'\n')
