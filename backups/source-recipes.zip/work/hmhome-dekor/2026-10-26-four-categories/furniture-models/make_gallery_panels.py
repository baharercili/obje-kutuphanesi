from pathlib import Path
import json,sys
from PIL import Image,ImageOps,ImageDraw
R=Path(__file__).resolve().parent;name=sys.argv[1];skus=sys.argv[2:];masters=json.loads((R/'original-image-masters.json').read_text());out=R/'source-review'/name;out.mkdir(parents=True,exist_ok=True)
rows=[]
for sku in skus:
 ms=[m for m in masters if m['sku']==sku]
 for j in range(0,len(ms),6):rows.append((sku,j,ms[j:j+6]))
for start in range(0,len(rows),3):
 im=Image.new('RGB',(2100,1260),'#eeeae5');d=ImageDraw.Draw(im)
 for y,(sku,j,ms) in enumerate(rows[start:start+3]):
  for x,m in enumerate(ms):
   pic=Image.open(m['path']).convert('RGB');pic.thumbnail((340,380));im.paste(pic,(x*350+(350-pic.width)//2,y*420+20+(380-pic.height)//2));d.text((x*350+5,y*420+403),sku+' #'+str(j+x)+' '+Path(m['path']).stem[-12:],fill='black')
 p=out/('gallery-'+str(start//3+1)+'.jpg');im.save(p,quality=92);print(p)
