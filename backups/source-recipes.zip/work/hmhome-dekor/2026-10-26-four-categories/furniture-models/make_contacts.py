from pathlib import Path
import json,sys
from PIL import Image,ImageDraw
R=Path(__file__).resolve().parent
entries=json.loads((R/'manifest.json').read_text());requested=sys.argv[1:];out=R/'qa/source-native-comparisons';out.mkdir(parents=True,exist_ok=True)
for e in entries:
 if requested and e['sku']not in requested:continue
 sheet=Image.new('RGB',(2400,550),'#eeece8');dr=ImageDraw.Draw(sheet)
 for i,(f,label)in enumerate([(e['original_image'],'official'),*[(str(Path(e['asset_dir'])/(k+'.png')),k)for k in ['on','on-capraz','yan','arka','ustten']]]):
  im=Image.open(f).convert('RGBA');im.thumbnail((390,490));base=Image.new('RGBA',im.size,'#eeece8');base.alpha_composite(im);sheet.paste(base.convert('RGB'),(400*i+(400-im.width)//2,(490-im.height)//2));dr.text((400*i+8,502),e['sku']+' '+label,fill='#111111')
 sheet.save(out/(e['sku']+'-comparison.jpg'),quality=93)
 print('CONTACT',e['sku'],flush=True)
