"""Local source three-cushion crown only; accepted U/back/base/seams/maps exact."""
from pathlib import Path
import copy,json,sys
sys.dont_write_bytecode=True
import numpy as np
from revision_export_exact import export
P=Path(__file__).resolve().parent;R=P/'revisions/sofa-three-seat-crowns-v6';OLD=P/'revisions/source-sofa-and-loose-velvet-v5/frozen-own-sofa-and-loose-velvet-v5-reviewed-manifest.json'

def subdivide(v,uv,f):
 for _ in range(3):
  n=len(f);ed=np.r_[f[:,[0,1]],f[:,[1,2]],f[:,[2,0]]];edges,inv=np.unique(np.sort(ed,axis=1),axis=0,return_inverse=True);off=len(v);v=np.r_[v,(v[edges[:,0]]+v[edges[:,1]])*.5];uv=np.r_[uv,(uv[edges[:,0]]+uv[edges[:,1]])*.5];ab,bc,ca=(inv.reshape(3,n)+off);a,b,c=f.T;f=np.r_[np.c_[a,ab,ca],np.c_[ab,b,bc],np.c_[ca,bc,c],np.c_[ab,bc,ca]]
 return v,uv,f

def change(m):
 original=np.asarray(m['positions']).reshape(-1,3);oldlo,oldhi=original.min(0),original.max(0);v,uv,f=subdivide(original,np.asarray(m['uvs']).reshape(-1,2),np.asarray(m['indices']).reshape(-1,3));lo,hi=oldlo,oldhi;cx=(lo[0]+hi[0])/2;cy=(lo[1]+hi[1])/2;u=np.clip((v[:,0]-cx)/((hi[0]-lo[0])/2),-1,1);t=np.clip((v[:,1]-cy)/((hi[1]-lo[1])/2),-1,1);crown=np.sqrt(np.maximum(0,1-u*u));up=v[:,1]>=cy;v[:,1]=cy+(v[:,1]-cy)*np.where(up,.82+.18*crown,.86+.14*crown);v[:,0]=cx+(v[:,0]-cx)*(1-.08*abs(t)**2.0);front=np.clip((v[:,2]-(lo[2]+.70*(hi[2]-lo[2])))/(.30*(hi[2]-lo[2])),0,1);corner=np.clip(abs(u)**1.8+.65*abs(t)**1.8,0,1);v[:,2]-=.025*front*corner
 # Only each changed seat keeps its old exact outer bounds; the other9 meshes
 # are copied verbatim and no overall sofa scale or pose is touched.
 v=(v-v.min(0))*(oldhi-oldlo)/(v.max(0)-v.min(0))+oldlo;v=v.astype('float32');_,weld=np.unique(v,axis=0,return_inverse=True);q=v[f].astype(float);area=np.cross(q[:,1]-q[:,0],q[:,2]-q[:,0]);nn=np.zeros((weld.max()+1,3))
 for k in range(3):np.add.at(nn,weld[f[:,k]],area)
 nn=nn[weld];nn/=np.linalg.norm(nn,axis=1)[:,None];m.update(positions=v.reshape(-1).tolist(),normals=nn.astype('float32').reshape(-1).tolist(),uvs=uv.astype('float32').reshape(-1).tolist(),indices=f.reshape(-1).tolist());return dict(mesh=m['name'],old_bounds_m=[oldlo.tolist(),oldhi.tolist()],new_bounds_m=[v.min(0).tolist(),v.max(0).tolist()],same_part_bounds=True,front_crown_and_lower_corner_fullness_real_geometry=True,front_corner_recession_max_cm_photo_estimate=2.5,UV_method='Three uniform linear barycentric subdivisions, original UV field interpolated; no scale/rotation/crop/artwork change',changed_triangles=len(f))

def main():
 old=next(e for e in json.loads(OLD.read_text())if e['sku']=='1368744001');m=json.loads(Path(old['model_path']).read_text());names=[];proof=[]
 for mesh in m['meshes']:
  if 'THREE-own-full-supported-seat'in mesh['name']:names.append(mesh['name']);proof.append(change(mesh))
 assert len(names)==3;m['metadata'].update(model_revision='own-local-three-source-plump-seat-crowns-v6',source_seat_fronts_are_physically_crowned=True);m['metadata']['scale_note']+=' Ayrı V6: Yalnız3oturumun üst bombesi, alt ön köşe yuvarlaklığı ve ön dolgulu eğrisi kendi fotoğrafına göre düzeltildi. Onaylı U/sırt/alt destek/dikiş geometrileri ve own materyal baytları aynıdır; resmî dış ölçü değişmez.';export(R,old,m,names,'own-local-three-source-plump-seat-crowns-v6',dict(source_front='own full e882e64e6880 and root correct-source-front crop',only_three_seats_changed=True,seat_geometry=proof,whole_sofa_and_each_seat_bounds_preserved=True,accepted_outer_U_back_lowbase_seams_byte_exact=True,own_all_material_PNGbytes_exact=True))
if __name__=='__main__':main()
