"""Own photographed current colour variants, plus a source-specific open steel chair.
Only approved same-family forms are reused; all new materials bind their exact SKU.
"""
import sys,math
sys.dont_write_bytecode=True
import numpy as np
from PIL import Image,ImageFilter
import build_models as F
BASE=F.materials
import build_wood_furniture01 as W1
import build_wood_furniture02 as W2
import build_wood_walls as WW
import build_tables as TB
import build_stone_metal_tables as ST
from geometry_extra import extrude_xy
F.materials=BASE;G=F.G;B=F.B;T=math.tau

def oval_marble():
 p,_,_=ST.curved_pine_stone();a=np.linspace(0,T,320,endpoint=False);r=1+.028*np.sin(3*a+.6);plan=np.c_[.255*np.cos(a)*r,.21*np.sin(a)*r];plan-=(plan.max(0)+plan.min(0))/2;plan*=np.array([.51,.42])/(plan.max(0)-plan.min(0))
 b=G.H.M.G.Builder();b.slab('own-light-organic-oval-marble-top','stone',plan,.421,.440,.0025);g=list(b.groups.values())[0];g['_vertices']=[(x,z,y)for x,y,z in g['_vertices']];p[0]=ST.chart(g)
 return p,['Own light stone variant has the same organic oval51×42cm top and two crossed deep U-cut pine panels as the independently checked family','Own photographed light marble native pixels, own light-beige painted legs; local vein phase interpreted, not copied from the brown SKU'],{'crossed_U_cut_wood_panels':2,'organic_oval_top':True,'verified_family_form_reuse':'1254575001 accepted organic-oval correction, not rejected square top'}

def sculptural_u():
 # The source legs are continuously rounded across depth, not a flat extruded U cutout.
 path=[(-.145,.425,0),(-.145,.355,0)]+[(.145*math.cos(a),.355+.300*math.sin(a),0)for a in np.linspace(math.pi,T,150)[1:-1]]+[(.145,.355,0),(.145,.425,0)]
 body=F.tube('own-continuously-rounded-open-U-metal-pedestal','body',path,.115,.038,sides=36,guide=[0,0,1])
 p=[body,W2.ellipse_top('own-softly-rolled-oval-metal-top',.42,.32,.420,.45)]
 return p,['Own wine-red metal side table with a broad curved U base and real open central aperture','Separate oval rolled top; official width42cm and height45cm,32cm depth photo estimated','No painted black cutout or room reflection bake'],{'physical_open_U_support':True,'depth_cm_photo_estimated':32}

def steel_chair():
 p=[]
 def tube(name,pts,r=.008):return F.tube(name,'body',pts,r,sides=16)
 # Four slim legs meet two actual rounded U side frames.
 for sx in[-1,1]:
  pts=[(sx*.224,.005,.226),(sx*.224,.410,.190),(sx*.224,.435,.173),(sx*.224,.435,-.170),(sx*.224,.410,-.190),(sx*.224,.005,-.226)];p.append(tube('one-of-two-soft-bent-U-leg-side-frames',pts,.009))
 # Seat and back are seven continuous separate bent rods, not a printed grate.
 for x in np.linspace(-.188,.188,7):
  pts=[(x,.445,.190),(x,.444,.145),(x,.436,-.120),(x,.445,-.173),(x,.480,-.194),(x,.770,-.237),(x,.794,-.242)];p.append(tube('one-of-seven-continuous-seat-to-back-iron-rods',pts,.0065))
 p.append(tube('continuous-round-back-top-and-rear-uprights',[(-.235,.010,-.226),(-.235,.763,-.245),(-.220,.805,-.247),(-.190,.811,-.247),(.190,.811,-.247),(.220,.805,-.247),(.235,.763,-.245),(.235,.010,-.226)],.009))
 p.append(tube('real-front-seat-cross-rail',[(-.235,.440,.190),(.235,.440,.190)],.008))
 for x in[-.224,.224]:
  for z in[-.226,.226]:p.append(F.tube('small-own-dark-floor-cap','foot',[(x,0,z),(x,.010,z)],.0094,sides=16))
 return p,['Own pale painted outdoor iron chair: slim bent U side frames, four actual feet and one tall rounded back frame','Seven separate physical parallel rods continue from seat through the curved transition into the sloping back','Official53×53×81.9cm and45.6cm seat height; local rail count/sections/curvature photo interpreted. SameSKU cache age is retained; current card photo verifies colour/form'],{'official_seat_height_cm':45.6,'continuous_seat_back_rod_count_photo_observed':7,'physical_open_steel_rod_structure':True}

def materials(out,pid,defs,masters):
 mats,maps=BASE(out,pid,defs,masters)
 if pid!='1254575002':return mats,maps
 master=next(x for x in masters if '5737e4fc3229'in x['path']);box=[256,800,1792,2336];crop=Image.open(master['path']).convert('RGB').crop(box);raw=out/'stone-native-donor.png';crop.save(raw);rgb=np.asarray(crop);n=crop.width;orm=np.zeros((n,n,3),np.uint8);orm[:,:,0]=255;orm[:,:,1]=84
 for slot,a in [('albedo',rgb),('normal',np.broadcast_to([128,128,255],rgb.shape).astype('uint8')),('orm',orm)]:
  f=out/('stone-'+slot+'.png');Image.fromarray(a,'RGB').save(f,optimize=True);maps=[x for x in maps if not(x['material']=='stone'and x['slot']==slot)]+[dict(material='stone',slot=slot,path=str(f),sha256=F.sha(f),native_resolution=[n,n])]
 F.dump(out/'stone-crop-provenance.json',dict(master=master['path'],master_sha256=master['sha256'],source_crop_pixel_box=box,native_crop_pixels=[n,n],output_pixels=[n,n],raw_crop=str(raw),raw_crop_SHA=F.sha(raw),no_upscale=True,geometric_resampling_count=0,method='Own exact-SKU unbroken marble-only detail; native RGB/pixel phase retained, no quantization/recolouring. One finite component chart, no room/styling bake; natural slab phase interpretation.'))
 mats['stone'].update(normalScale=.02,extras=dict(intrinsic_material=True,photo_pixels_baked=True,own_photo_material_crop=True,native_resolution=[n,n],crop_provenance=str(out/'stone-crop-provenance.json'),baked_reflections=False));return mats,maps
F.materials=materials

S={}
NOTE='KendiSKU güncel renk ve bütün galeri fotoğrafları incelendi; aynı gerçek ailenin doğrulanmış formu kullanılır. Yerel kalınlık, küçük bağlantı, eğri ve doğal tekil damar fazı fotoğraf yorumudur. Fotoğraftaki oda, kitaplar, oyuncak ve başka renk ürünler dahil değildir.'
def add(pid,name,dims,fn,rgb,col,kind='paint',pi=0,**kw):S[pid]=dict(name=name,dims=dims,build=fn,primary_index=pi,materials={'body':(kind,rgb,.47)},color=col,note=kw.pop('note',NOTE),**kw)
for pid,rgb,col,pi in [('1038907002',[129,151,131],'Yeşil',2),('1038907004',[83,88,89],'Gri',1)]:
 add(pid,'Yuvarlak sırt çıtalı çocuk sandalyesi · '+col,[36,45,31],W1.child_chair,rgb,col,pi=pi);S[pid]['materials']['hardware']=('metal',[169,170,160],.28)
add('1038910006','Sırtlıklı sandık çocuk bankı · Açık mavi',[60,45,31],W1.child_bench,[183,211,211],'Açık mavi',official={'width_cm':[60],'depth_cm':[31],'total_height_including_back_cm':[45],'seat_height_cm':[28]},note='KendiSKU açıklaması oturma yüksekliği28cm, sırt dahil toplam45cm verir; resmî60×31cm plan korunur. Gerçek boş sandık, ayrı kapak, geniş parmak oyuğu ve tek yuvarlak sırt çubuğu; menteşe/fastener ve yerel kalınlık yorumdur. Oyuncak dahil değildir.');S['1038910006']['materials']['hardware']=('metal',[176,176,164],.3)
add('1299896001','Çift oval yüzeyli ahşap yan sehpa · Açık kahverengi',[54,55,38],W2.double_oval,[172,137,96],'Açık kahverengi',kind='wood',pi=1)
add('1338973002','Üç geniş ayaklı oval ahşap sehpa · Koyu kahverengi',[60,45,48],lambda:W2.oval_three('1338973002'),[65,38,28],'Koyu kahverengi',kind='wood',pi=1)
add('1338724001','İki organik ayaklı sehpa · Kahverengi',[46,41,38],TB.pod_table,[72,43,27],'Kahverengi',kind='wood',pi=1,note='Resmî46×38×41cm dış zarf, iki bombeli ayrı ayak ve yuvarlatılmış tabla kendi fotoğrafına göre korunur. ResmîMDF kompozisyonu korunur; görünen kahverengi ahşap desenli yüzey doğal masif ahşap iddiası olmadan kendi fotoğrafa göre yorumlanır. Yerel damar fazı/ayak eğrisi ve kalınlık tahmindir; staging yoktur.')
for pid,rgb,col,pi in [('1096727005',[186,33,27],'Kırmızı/açık ahşap',1),('1096727007',[139,162,132],'Adaçayı/açık ahşap',0)]:
 add(pid,'Kıvrımlı metal taşıyıcılı üç katlı çocuk rafı · '+col,[60,66,23],WW.iron_three,rgb,col,pi=pi);S[pid]['materials']={'wood':('wood',[178,139,97],.58),'frame':('paint',rgb,.42)}
add('1254575002','Organik oval mermer tablalı kavisli ahşap sehpa',[51,44,42],oval_marble,[212,204,184],'Açık bej/beyaz/gri',pi=1);S['1254575002']['materials']={'wood':('paint',[213,204,185],.43),'stone':('paint',[216,216,208],.33)}
add('1336013003','Derin U boşluklu oval metal sehpa · Bordo',[42,45,32],sculptural_u,[90,20,34],'Bordo',pi=0,official={'width_cm':[42],'height_cm':[45]},official_hwd=[45,42,None],estimated_axes=['depth_cm'],note='Resmî42cm en45cmH;32cm derinlik kendi fotoğrafından tahmin. Kaynaktaki heykelsi derin U boşluğu gerçek kapalı metal kabuk, ayrı oval tabla ve yuvarlatılmış kenarlardır. Yerel iç eğri/kalınlık yorumdur; yansımalar fotoğrafa basılmadı.');S['1336013003']['materials']['body']=('paint',[90,20,34],.22)
add('1263410001','İnce çubuklu açık metal bahçe sandalyesi',[53,81.9,53],steel_chair,[221,221,204],'Açık bej',pi=0,official={'width_cm':[53],'height_cm':[81.9],'depth_cm':[53],'seat_height_cm':[45.6]});S['1263410001']['materials']['foot']=('paint',[81,83,75],.68)
F.SPECS.update(S)
if __name__=='__main__':
 for pid in sys.argv[1:]or S:F.build(pid)
