"""Download only observed exact-SKU photo URLs into a separate immutable extension index."""
from pathlib import Path
import sys,json,re,hashlib,urllib.request,concurrent.futures,datetime,io
from PIL import Image
P=Path(__file__).resolve().parent;R=P.parent/'furniture-research'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
scope=json.loads((P/'live-uk-de-source-extension-2026-10-27.json').read_text());new={r['sku']for r in scope['new_products']}
by={}
def add(sku,url,alt,pdp,evidence,kind):
 if sku not in new or not url or 'image.hm.com/'not in url or '.jpg'not in url:return
 # Retain the observed URL literally. No resolution query is invented.
 row=dict(sku=sku,url=url,alt=alt or'',path=str(P/'originals-extra'/sku/(sku+'-'+hashlib.sha256(url.encode()).hexdigest()[:12]+'.jpg')),source_pdp_url=pdp,source_kind=kind,URL_evidence_file=str(evidence),URL_evidence_sha256=sha(evidence))
 by.setdefault((sku,url),row)
for name in [*[f'root-gb-photos-page{i}.json'for i in range(1,5)],*[f'root-de-photos-page{i}.json'for i in range(1,4)],'root-de-home-photos-all.json']:
 f=R/name;x=json.loads(f.read_text())
 for c in x.get('cards',x.get('products',[])):
  skus=set(re.findall(r'productpage\.(\d{10})',json.dumps(c)))
  if len(skus)!=1:continue
  sku=next(iter(skus))
  for im in c.get('images',[]):
   add(sku,im.get('src'),im.get('alt'),c.get('url'),f,'exact_official_live_category_loaded_primary')
   for key in['data_src','data_altimage']:add(sku,im.get(key),im.get('alt'),c.get('url'),f,'exact_official_live_category_hover_photo')
for sku in['1368750001','1368749001']:
 f=R/('root-pdp-'+sku+'.json');x=json.loads(f.read_text())
 for im in x['images']:add(sku,im.get('src'),im.get('alt'),x['url'],f,'exact_official_live_PDP_gallery')
anchorfile=P/'source-extras/extra-gallery-anchor-queue-working.json'
if anchorfile.exists():
 anchors=json.loads(anchorfile.read_text()); lookup={(r['ref_id'],l['id']):(r,l)for r in anchors for l in r['links']};bindings=[]
 for f in sorted((P/'source-extras').glob('extra-gallery-click-results-*.json')):
  raw=json.loads(f.read_text())['raw']
  for block in raw.split('--------------------------------------------------------------------------------'):
   click=re.search(r'Source: click\(\{"ref_id":"([^"]+)","id":(\d+)\}\)',block)
   urls=re.findall(r'https://image\.hm\.com/[^\s:]+\.jpg\?imwidth=\d+',block)
   if not click or not urls:continue
   key=(click[1],int(click[2]));r,l=lookup[key];pdp='https://www2.hm.com/'+('en_gb'if r['sku']in['1038907002','1299896001','1254575002','1038907004','1254630002','1038910006','1338973002']else'de_de')+'/productpage.'+r['sku']+'.html'
   add(r['sku'],urls[0],l['alt'],pdp,f,'exact_official_cached_PDP_gallery_link')
   bindings.append(dict(sku=r['sku'],ref_id=key[0],link_id=key[1],url=urls[0],alt=l['alt'],URL_evidence_file=str(f)))
 dump(P/'source-extras/extra-gallery-url-bindings-working.json',bindings)
tasks=list(by.values());dump(P/'extra-original-image-download-queue.json',tasks)
def download(t):
 f=Path(t['path']);f.parent.mkdir(parents=True,exist_ok=True)
 if not f.exists():
  with urllib.request.urlopen(t['url'],timeout=45)as r:raw=r.read()
  im=Image.open(io.BytesIO(raw));im.verify();tmp=f.with_suffix('.download');tmp.write_bytes(raw);tmp.rename(f)
 raw=f.read_bytes();im=Image.open(io.BytesIO(raw));profile=im.info.get('icc_profile',b'')
 return dict(t,sha256=hashlib.sha256(raw).hexdigest(),pixel_sha256=hashlib.sha256(im.tobytes()).hexdigest(),width=im.width,height=im.height,mode=im.mode,format=im.format,icc_profile_sha256=hashlib.sha256(profile).hexdigest()if profile else None,exif_orientation=im.getexif().get(274),bytes=len(raw),immutable_master=True,downloaded_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
if '--download'in sys.argv:
 done=[];failed=[]
 with concurrent.futures.ThreadPoolExecutor(max_workers=3)as pool:
  futures={pool.submit(download,t):t for t in tasks}
  for future in concurrent.futures.as_completed(futures):
   try:done.append(future.result())
   except Exception as e:failed.append(dict(futures[future],error=str(e)))
   if(len(done)+len(failed))%20==0:print('extra masters',len(done),'failed',len(failed),flush=True)
 index=P/'extra-original-image-masters-working.json';old=json.loads(index.read_text())if index.exists()else[];oldby={(x['sku'],x['url']):x for x in old}
 for x in done:
  if(x['sku'],x['url'])in oldby:assert oldby[x['sku'],x['url']]['sha256']==x['sha256']
  oldby[x['sku'],x['url']]=x
 dump(index,list(oldby.values()));dump(P/'extra-source-download-blockers.json',failed)
 print('extra source photos',len(done),'SKUs',len({x['sku']for x in done}),'failed',len(failed))
else:print('observed exact photo URLs',len(tasks),'SKUs',len({x['sku']for x in tasks}))
