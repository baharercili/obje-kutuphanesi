"""Exact-source glass silhouettes and intrinsic physical glass, without photo reflections."""
from pathlib import Path
import sys,json,copy,math,ast,shutil
import numpy as np
from PIL import Image
P=Path(__file__).resolve().parent.parent;sys.path.insert(0,str(P/'lighting-models'))
import build_lighting as L
R=Path('/private/tmp/hm-lighting-20261028/glass-007');S=Path('/private/tmp/hm-lighting-20261028/glass-source-review');R.mkdir(parents=True,exist_ok=True);L.R=R
if list(R.glob('frozen*manifest*.json')):raise RuntimeError('Frozen batch preserved; a new revision directory is required.')
IDS=['1283128003','1283146001','1296331002','1311977002','1337572001','1337573001','1337574001','1337575001','1337571001','1344588001']
registry=[x for s,xx in json.loads((S/'available-masters.json').read_text()).items()for x in xx if s in IDS]
for x in registry:assert L.sha(x['path'])==x['sha256']
L.dump(R/'original-image-masters.json',registry)
qs=L.sources();contours={x['sku']:x for x in json.loads((S/'step-source-contours.json').read_text())};bank0=L.material_bank;T=math.tau
# Reuse only these pure hardware functions; no producer top-level code is executed.
tree=ast.parse((P/'lighting-geometric-batch-006/build_geometric.py').read_text());namespace=dict(L=L,np=np,math=math,T=T)
exec(compile(ast.Module(body=[x for x in tree.body if isinstance(x,ast.FunctionDef)and x.name in['eholder','g9']],type_ignores=[]),'read-only-hardware-functions','exec'),namespace)
eholder=namespace['eholder'];g9=namespace['g9']

def downwards(parts,upper_y):
 for part in parts:part['_vertices']=[(x,upper_y-y,z)for x,y,z in part['_vertices']]
 return parts

def glass_shell(name,profile,thickness=.0025,mat='glass'):
 """Finite shell, two actual mouth rims, with inward offset in its profile plane."""
 p=np.asarray(profile,float);t=np.gradient(p,axis=0);normal=np.c_[-t[:,1],t[:,0]];normal/=np.maximum(np.linalg.norm(normal,axis=1,keepdims=True),1e-12);inside=p+thickness*normal;assert np.all(inside[:,0]>0)
 return L.B.lathe(name,mat,p.tolist()+inside[::-1].tolist(),192,True)

def table_cord(length,base,radius):
 return L.cord(length,base,radius,mat='beige_cable',switch=True)

def smooth_monotone_radius(knots,ys):
 p=np.array(knots,float);xx=p[:,1];rr=p[:,0];delta=np.diff(rr)/np.diff(xx);slopes=np.r_[delta[0],np.zeros(len(rr)-2),delta[-1]]
 for j in range(1,len(rr)-1):
  slopes[j]=0 if delta[j-1]*delta[j]<=0 else 2/(1/delta[j-1]+1/delta[j])
 out=[]
 for y in ys:
  k=max(0,min(len(rr)-2,np.searchsorted(xx,y)-1));dt=xx[k+1]-xx[k];t=(y-xx[k])/dt
  out.append((2*t**3-3*t*t+1)*rr[k]+(t**3-2*t*t+t)*dt*slopes[k]+(-2*t**3+3*t*t)*rr[k+1]+(t**3-t*t)*dt*slopes[k+1])
 return np.array(out)

def natural_profile(points,count=260):
 """C2 natural cubic spline in profile arclength; no straight-cone shortcuts."""
 pp=np.asarray(points,float);xx=np.r_[0,np.cumsum(np.linalg.norm(np.diff(pp,axis=0),axis=1))];hh=np.diff(xx);n=len(pp);A=np.zeros((n,n));rhs=np.zeros((n,2));A[0,0]=A[-1,-1]=1
 for i in range(1,n-1):A[i,i-1]=hh[i-1];A[i,i]=2*(hh[i-1]+hh[i]);A[i,i+1]=hh[i];rhs[i]=6*((pp[i+1]-pp[i])/hh[i]-(pp[i]-pp[i-1])/hh[i-1])
 second=np.linalg.solve(A,rhs);out=[]
 for x in np.linspace(0,xx[-1],count):
  i=max(0,min(n-2,np.searchsorted(xx,x)-1));h=hh[i];a=(xx[i+1]-x)/h;b=(x-xx[i])/h;out.append(a*pp[i]+b*pp[i+1]+((a**3-a)*second[i]+(b**3-b)*second[i+1])*h*h/6)
 return np.array(out)

def shared_info(q,features,estimated,kind='E14',watts=6):
 return dict(target_cm=None,official_axes=list(q.get('official_measurements',{})),estimated=estimated+['glass_wall_thickness','glass_IOR_roughness_and_diffuse_transmission','hidden_socket_positions_and_supports','stored_cord_pose'],features=features,material_overrides=dict(glass=('metal',[235,230,211],.13,0),chrome=('metal',[226,228,225],.075,1),beige_cable=('woven',[185,171,143],.86,0),brushed=('metal',[164,166,160],.31,1),ceramic=('plastic',[221,218,208],.78,0)),official_socket_type=kind,official_socket_count=1,official_source_max_led_w=watts,bulbs_included=False,source_material_interpretation='Finite glass with estimated IOR and volume/diffuse transmission; no source room reflection photograph',scale_note_override='Resmî ölçüler kendi exact SKU kaynağındaki bileşen anlamlarıyla korunmuştur. Yerel cam profili ve kalınlığı, ışık geçirgenliği, renk, görünmeyen iç bağlantılar ve kablonun sarılı duruşu fotoğraftan yorumlanmıştır. Fiziksel cam malzemesi kullanılmıştır; kaynak fotoğrafındaki ışık ve oda yansımaları yüzeye aktarılmamıştır. '+kind+' duy, azami '+str(watts)+' W LED; ampul dahil değildir. Üretici CAD dosyası değildir.')

def cage(q):
 h=.30;yb=.144;Rshade=.139
 # Own upper depression/mouth and lower fitting mouth, not a generic ellipsoid.
 profile=[(.058,yb),(.087,.149),(.115,.160),(.133,.181),(.139,.213),(.138,.246),(.128,.274),(.108,.291),(.080,.300),(.055,.296),(.034,.286),(.024,.274)]
 curve=natural_profile(profile,320);curve[:,0]*=Rshade/curve[:,0].max();curve[:,1]=yb+(curve[:,1]-curve[:,1].min())*(h-yb)/np.ptp(curve[:,1])
 parts=[glass_shell('separate-oblate-glass-shade-with-upper-depression-and-two-mouths',curve)]
 for j,a in enumerate(np.linspace(0,T,12,endpoint=False)):
  radial=[(.062,yb-.002),(.056,.130),(.052,.115),(.052,.026),(.050,.016),(.045,.008),(.038,.004)]
  yy=np.linspace(.004,yb-.002,128);rr=smooth_monotone_radius(radial[::-1],yy);points=[(r*math.cos(a),y,r*math.sin(a))for r,y in zip(rr,yy)];parts.append(L.tube('separate-curved-chrome-cage-rod-'+str(j),'chrome',points,.0024,12))
 for y,r in[(.004,.038),(yb-.002,.062)]:parts.append(L.tube('separate-round-cage-joining-ring-'+str(y),'chrome',[(r*math.cos(a),y,r*math.sin(a))for a in np.linspace(0,T,160,endpoint=False)],.0023,12,True))
 parts.append(L.lathe('separate-central-chrome-socket-housing','chrome',[(0,.071),(.019,.071),(.023,.080),(.023,yb-.005),(0,yb-.005)],128));parts+=eholder('E14',yb-.004)
 c,le=table_cord(1.6,(0,.075,-.010),.112);parts+=c
 info=shared_info(q,['Own oblate glass crown with real upper depression/mouth and lower fitting mouth','Separate curved cage rods, joining rings and central metal socket housing; nominal E14 cup/thread','Own source glass colour and local geometry interpreted; no room reflections are baked'],['upper_and_lower_mouth_diameters','cage_back_rod_count_12_photo_interpreted','rod_diameter','cage_profile_and_rings','local_oblate_profile','central_socket_housing_dimensions'])
 info.update(target_cm=[27.8,30,27.8],measured_cord_length_m=le)
 if q['sku']=='1283128003':info['estimated']+=['cord_length_160cm_not_published_in_this_SKU_size_facts'];info['scale_note_override']+=' Bu SKU için kablo boyu yayımlanmadığından 160 cm tahmindir.'
 info['scale_note_override']+=' Kafesin arkada gizlenen çubuklarının toplam adedi 12 olarak fotoğraftan yorumlanmıştır; üretici parça adedi değildir. Üst çukurun servis ağzı yorumu ve iç donanım kalınlıkları tahmindir.'
 return parts,info

def mushroom(q):
 r=.141;h=.25;yb=.140;theta=np.linspace(0,math.pi/2,100)
 outer=[(.060,0),(.063,.002),(.063,.102),(.066,.106),(.094,.106),(.099,.110),(.099,.137),(.105,.140),(r,yb)]+[(r*math.cos(a),yb+.11*math.sin(a))for a in theta[1:-1]]+[(0,h)]
 inner=[(0,h-.0025)]+[((r-.0025)*math.cos(a),yb+.1075*math.sin(a))for a in theta[-2:0:-1]]+[(r-.0025,yb+.0025),(.1025,.1425),(.0965,.137),(.0965,.1125),(.0915,.1085),(.0635,.1085),(.0605,.102),(.0605,.0025)]
 parts=[L.B.lathe('separate-continuous-coloured-glass-base-collar-and-rounded-dome','glass',outer+inner,224,True),L.B.lathe('separate-thin-dark-metal-under-base-ring','black',[(.057,0),(.063,0),(.063,.002),(.057,.002)],160,True)]
 parts+=eholder('E14',.112);parts.append(L.lathe('separate-estimated-internal-metal-holder-support','steel',[(0,.004),(.006,.004),(.006,.118),(0,.118)],80));c,le=table_cord(1.6,(0,.006,-.061),.108);parts+=c
 info=shared_info(q,['Own rounded sand-beige glass mushroom with cylindrical foot, rounded intermediate collar and oblate dome','Finite glass body with real underside access, separate dark bottom ring and hidden E14 support','Intrinsic cloudy coloured glass, volume/IOR and diffuse transmission; source highlights/reflections excluded'],['base_and_collar_component_dimensions','rounded_glass_mushroom_profile','cloudy_glass_intrinsic_colour_distribution']);info.update(target_cm=[28.2,25,28.2],measured_cord_length_m=le);return parts,info

def stepped(q):
 pendant=q['sku']=='1337571001';large=q['sku']in['1337574001','1337575001'];m=q['official_measurements'];h=m['height_cm']/100;r=m['diameter_cm']/200;e=contours[q['sku']];yb=0 if pendant else(.025 if large else .018)
 pixels=np.array(e['row_radius_px_smoothed']);kernel=np.exp(-.5*(np.arange(-27,28)/9)**2);kernel/=kernel.sum();pixels=np.convolve(np.pad(pixels,(27,27),mode='edge'),kernel,'valid');sample=np.linspace(0,len(pixels)-1,360);rad=np.interp(sample,np.arange(len(pixels)),pixels)/max(pixels)*r;yy=h-(h-yb)*sample/(len(pixels)-1);outer=list(zip(rad[::-1],yy[::-1]));th=.0025
 if pendant:
  # The own top photograph has a distinct chrome fixing plate above the glass.
  shell=glass_shell('separate-own-source-stepped-opal-glass-shell',outer,th)
 else:
  inside=[(max(.003,x-th),min(h-th,max(yb+th,y)))for x,y in outer[::-1]]
  shell=L.B.lathe('separate-own-source-stepped-opal-glass-closed-crown-shell','glass',outer+[(0,h),(0,h-th)]+inside,192,True)
 parts=[shell]
 if pendant:
  parts+=downwards(g9(0),h-.003);parts.append(L.RO.box('separate-interpreted-G9-to-upper-plate-mount','steel',.018,.003,.008,(0,h-.0025,0)));plateR=rad[0]*.98;parts.append(L.lathe('separate-upper-polished-metal-fixing-plate','chrome',[(0,h-.001),(plateR,h-.001),(plateR,h+.002),(0,h+.002)],128));parts.append(L.lathe('separate-polished-pendant-cable-neck','chrome',[(0,h),(.007,h),(.007,h+.020),(0,h+.020)],96));access,le=pendant_set(2.4,h+.02,.070,'beige_cable',False);parts+=access
 else:
  baseR=float(rad[-1])+.004;parts.append(L.B.lathe('separate-polished-metal-round-base-ring','chrome',[(0,0),(baseR-.001,0),(baseR,.001),(baseR,yb-.001),(baseR-.001,yb),(0,yb)],192,False));parts+=eholder('E14',yb+.010);c,le=table_cord(1.6,(0,yb*.60,-baseR*.96),r*.89);parts+=c
 info=shared_info(q,['Own exact-SKU warm-glass front silhouette sampled by native image row; rounded stepped shoulders are source-specific','Finite opal glass shell, own closed upper crown or separate pendant fixing plate, and real lower service mouth','Separate actual metal base or pendant canopy, exact source socket type, full cord shown in an explicitly stored pose'],['source_photo_vertical_mapping','inner_glass_profile_and_bottom_service_opening','local_chrome_hardware_dimensions','cord_length_where_not_published'],kind='G9'if pendant else'E14',watts=4 if pendant else 6)
 info.update(target_cm=None if pendant else[r*200,h*100,r*200],measured_cord_length_m=le,source_contour_evidence=str(R/'source-review/step-source-contours.json'),native_source_contour_sku=q['sku'],profile_antialias_smoothing='Own native-radius Gaussian sigma9px removes edge extraction jitter; roughly1–2mm at the source glass scale; all source step levels retained')
 if pendant:info['estimated']+=['overall_height_including_stored_pendant_assembly','canopy_diameter_and_depth'];info['scale_note_override']+=' Resmî 14,3 cm ve 15,3 cm cam gövde ankrajlarıdır. Askı donanımı, kısa sunum askısı ve tavana yakın sarılı kablo nedeniyle toplam model boyu ayrıca tahmindir; 240 cm kablo düz sarkıtılmamıştır.'
 else:info['scale_note_override']+=' Toplam resmî yükseklik ve azami çap korunmuştur. Ayrı metal kaide yüksekliği ile fotoğraf satırlarının dikey eşlenmesi tahmindir. Kablo için 160 cm tahmin kullanılmıştır.'
 return parts,info

def pendant_set(length,attachment_y,radius,mat='cable',steel_suspensions=True):
 # A short display drop plus an exact-length stored spiral near the real canopy.
 top=attachment_y+.11;coil_y=attachment_y+.065;r0=.012
 def path(turns):
  aa=np.linspace(0,T*turns,850);rr=np.linspace(r0,radius,len(aa));coil=np.c_[rr*np.sin(aa),np.full(len(aa),coil_y),rr*np.cos(aa)];lead=np.linspace([0,attachment_y,0],coil[0],50,endpoint=False);tail=np.linspace(coil[-1],[0,top-.012,0],50);return np.vstack([lead,coil,tail])
 lo,hi=.01,30
 for _ in range(35):
  mid=(lo+hi)/2;p=path(mid);le=np.linalg.norm(np.diff(p,axis=0),axis=1).sum()
  if le<length:lo=mid
  else:hi=mid
 pp=path((lo+hi)/2);assert(radius-r0)/((lo+hi)/2)>.0032
 parts=[L.tube('separate-full-length-fabric-pendant-cord-stored-near-canopy',mat,pp.tolist(),.0016,10),L.B.lathe('separate-finite-ceiling-canopy-with-lower-service-mouth','brushed',[(.005,top),(.048,top),(.048,top-.025),(.0465,top-.025),(.0465,top-.0015),(.005,top-.0015)],160,True)]
 if steel_suspensions:
  for j,a in enumerate(np.linspace(0,T,3,endpoint=False)):parts.append(L.tube('separate-metal-suspension-wire-'+str(j),'steel',[(.029*math.cos(a),attachment_y,.029*math.sin(a)),(.030*math.cos(a),top-.025,.030*math.sin(a))],.00045,8))
 return parts,float(np.linalg.norm(np.diff(pp,axis=0),axis=1).sum())

def flat_pendant(q):
 # Source-specific low glass disc with generous curved shoulders and a separate tall hub.
 profile=[(.040,.004),(.075,0),(.125,.003),(.151,.012),(.167,.028),(.170,.047),(.161,.068),(.143,.084),(.110,.090),(.045,.090)];curve=natural_profile(profile,320)
 curve[:,0]*=.170/curve[:,0].max();curve[:,1]=(curve[:,1]-curve[:,1].min())*.090/np.ptp(curve[:,1])
 parts=[glass_shell('separate-low-oblate-opal-glass-pendant-shell',curve),L.B.lathe('separate-brushed-cylindrical-upper-lamp-housing','brushed',[(.017,.087),(.040,.087),(.040,.156),(.0385,.156),(.0385,.089),(.017,.089)],160,True),L.B.lathe('separate-interpreted-hub-to-glass-fixing-flange','brushed',[(.017,.088),(.047,.088),(.047,.090),(.017,.090)],128,True)]
 parts+=downwards(eholder('E27',0),.123);parts.append(L.lathe('separate-interpreted-holder-to-hub-insulating-neck','black',[(0,.120),(.008,.120),(.008,.154),(0,.154)],96));parts.append(L.lathe('separate-black-cable-grip','black',[(0,.155),(.005,.155),(.005,.170),(0,.170)],96));access,le=pendant_set(2.0,.168,.115,'cable',True);parts+=access
 info=shared_info(q,['Own low9cm opal disc, round curved shoulders and distinct brushed metal cylindrical top housing','Finite open service mouths, real empty E27 cup/thread, three thin suspension wires and separate finite ceiling canopy','Full stated200cm fabric cord retained in compact stored pose close to canopy, with explicitly estimated display drop'],['source_low_oblate_profile','central_glass_openings','metal_hub_dimensions','canopy_dimensions','short_display_drop_and_canopy_coil','overall_height_including_stored_pendant_assembly'],kind='E27',watts=15);info.update(measured_cord_length_m=le);info['scale_note_override']+=' Resmî başlık 9 cm yükseklik ve 34 cm çaptır; bu ölçüler yalnız cam başlığa aittir. Askı, kablo sargısı ve metal donanım dahil dış zarf ayrı tahmindir. Gerçek 200 cm kablo kısa sunum askısı ve tavana yakın sargı olarak korunmuştur.';return parts,info

def bank(pid,keys,ims,out,overrides=None):
 mats,maps=bank0(pid,keys,ims,out,overrides);amber=pid=='1283128003';brown=pid in['1296331002','1311977002'];col=np.array([202,153,82]if amber else[179,132,87]if brown else[221,207,178]if pid=='1283146001'else[236,232,212],float);n=256;u,v=np.meshgrid(np.arange(n)/n,np.arange(n)/n);rng=np.random.default_rng(int(pid));phase=rng.uniform(0,T,5);cloud=sum(np.sin(T*(a*u+b*v)+p)*w for a,b,w,p in zip([2,3,5,7,1],[3,1,6,2,7],[.42,.24,.13,.10,.08],phase));variation=(.045 if amber or brown else .007)*cloud;rgb=np.clip(col[None,None,:]*(1+variation[:,:,None]),0,255).astype('uint8');orm=np.zeros((n,n,3),np.uint8);orm[:,:,0]=255;orm[:,:,1]=np.rint(np.clip(.105+cloud*.006,.08,.13)*255);normal=np.zeros((n,n,3),np.uint8);normal[:,:,0:2]=128;normal[:,:,2]=255
 for slot,a in [('albedo',rgb),('normal',normal),('orm',orm)]:
  path=out/('glass-'+slot+'.png');Image.fromarray(a).save(path,optimize=True)
  for rec in maps:
   if rec['material']=='glass'and rec['slot']==slot:rec.update(sha256=L.sha(path),native_resolution=[n,n])
 transmission=.23 if amber else .12 if brown else .08 if pid=='1283146001'else .015
 mats['glass'].update(ior=1.48,thickness=.0025,transmission=transmission,attenuationColor=[1,1,1],attenuationDistance=.02,normalScale=0,alphaMode='OPAQUE')
 mats['glass']['extras'].update(intrinsic_material=True,photo_pixels_baked=False,baked_reflections=False,native_resolution=[n,n],diffuse_transmission_factor=.36 if amber or brown else .55,optical_parameters_estimated=True,cloudy_colour_field_photo_interpreted_not_exact_wrap=True,solid_material_wall_m_estimated=.0025)
 L.dump(out/'intrinsic-glass-material-provenance.json',dict(source_SKU=pid,no_photo_pixels=True,no_source_room_reflection=True,no_emissive_material=True,physical_IOR=1.48,clear_transmission_estimated=transmission,diffuse_transmission_estimated=mats['glass']['extras']['diffuse_transmission_factor'],finite_wall_m_estimated=.0025,local_intrinsic_coloured_cloud_variation_not_exact_wrap=True,all_parameters_photo_interpreted=True))
 return mats,maps

L.material_bank=bank;L.BUILD={s:cage if s in['1283128003','1283146001']else mushroom if s in['1296331002','1311977002']else flat_pendant if s=='1344588001'else stepped for s in IDS}
if __name__=='__main__':
 for sku in sys.argv[1:]or IDS:L.build(sku)
