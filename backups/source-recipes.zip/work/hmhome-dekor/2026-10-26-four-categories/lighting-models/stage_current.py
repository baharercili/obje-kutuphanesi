"""Normal macOS per-file hydration and verified temporary current-work copies."""
from pathlib import Path
import sys,json,subprocess,hashlib,signal,time
from PIL import Image
L=Path(__file__).resolve().parent;mf=Path(sys.argv[1]);out=Path(sys.argv[2]);out.mkdir(parents=True,exist_ok=True);rows=json.loads(mf.read_text());skus={e['sku']for e in rows};registry=json.loads((L/'original-image-masters.json').read_text());proof=[];pending=[]
def alarm(a,b):raise TimeoutError('Normal cloud file read still pending')
signal.signal(signal.SIGALRM,alarm)
def read(p):
 signal.alarm(8)
 try:return Path(p).read_bytes()
 finally:signal.alarm(0)
def obtain(p):
 p=Path(p)
 if p.stat().st_flags&0x40000000:subprocess.run(['/usr/bin/brctl','download',str(p)],check=True,timeout=15)
 return read(p)
def copy(p,dest,expected=None):
 try:
  data=obtain(p);h=hashlib.sha256(data).hexdigest();assert expected is None or expected==h;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data);assert hashlib.sha256(dest.read_bytes()).hexdigest()==h;proof.append(dict(source=str(p),copy=str(dest),sha256=h,byte_identical=True));return True
 except (TimeoutError,OSError)as e:pending.append(dict(path=str(p),error=str(e)));print('PENDING',p,flush=True);return False
for x in registry:
 if x['sku']in skus:copy(x['path'],out/'originals'/Path(x['path']).name,x['sha256'])
staged=[]
for e in rows:
 if 'model_path'not in e:continue
 source=Path(e['model_path']);folder=out/'models'/e['id'];before=len(pending)
 if not copy(source,folder/'model.json'):continue
 doc=json.loads((folder/'model.json').read_text());paths=[Path(e['glb_path']),Path(e['geometry_validation']),Path(e['material_validation']),Path(e['asset_dir'])/'entry.json']
 paths+=[source.parent/ma[key]for ma in doc['materials'].values()for key in ['baseColorTexture','normalTexture','metallicRoughnessTexture']if key in ma]
 for p in set(paths):copy(p,folder/p.name,e['sha256']if str(p)==e['glb_path']else None)
 row=dict(e);row.update(asset_dir=str(folder),model_path=str(folder/'model.json'),glb_path=str(folder/Path(e['glb_path']).name),geometry_validation=str(folder/Path(e['geometry_validation']).name),material_validation=str(folder/Path(e['material_validation']).name),archival_asset_dir=e['asset_dir'],archival_model_path=e['model_path']);staged.append(row);print('STAGED',e['sku'],'pending',len(pending)-before,flush=True)
(out/'manifest.json').write_text(json.dumps(staged,ensure_ascii=False,indent=2));(out/'byte-copy-proof.json').write_text(json.dumps(dict(source_manifest=str(mf),files=proof,pending=pending,all_requested_files_staged=not pending,originals_unchanged=True),indent=2));print('COPY_PROOF',len(proof),'pending',len(pending),flush=True)
