"""Photo-inspected table/base families; exact per-SKU source anchors remain separate.
Shared geometry represents verified same-form colour/market variants, never an
uninspected product class. Unknown exterior fields are explicitly estimated.
"""
import math
import numpy as np
T=math.tau
def rgb(q):
 s=q.get('colour','').lower()
 if any(x in s for x in['silver','silber']):return [222,223,219],True
 for words,col in [(['burgundy','dark red','dunkelrot'],[87,8,19]),(['light yellow','hellgelb'],[219,197,117]),(['mustard','senf'],[205,145,30]),(['yellow','gelb'],[217,163,34]),(['dusty blue','mattblau'],[125,150,166]),(['khaki'],[108,111,78]),(['dark beige','dunkelbeige'],[151,135,111]),(['dark brown','dunkelbraun'],[56,33,24]),(['brown','braun'],[123,104,85]),(['red','rot'],[143,20,26]),(['pink','rosa'],[221,152,148]),(['green','grün'],[59,76,38]),(['black','schwarz'],[24,23,22]),(['white','weiß'],[233,231,224]),(['beige'],[216,209,192])]:
  if any(w in s for w in words):return col,False
 return [216,209,192],False
def registry(L):
 B=L.B;lathe=L.lathe;tube=L.tube
 def safe_cord(length,foot_radius,outer_radius,white=True,switch=True):
  # A real spaced spiral sits outside the foot, beneath the shade overhang.
  r0=foot_radius+.006;r1=max(r0+.018,outer_radius)
  def path(turns):
   a=np.linspace(math.pi,math.pi+T*turns,700);rr=np.linspace(r0,r1,len(a));coil=np.c_[rr*np.sin(a),np.full(len(a),.0033),rr*np.cos(a)];lead=np.linspace([0,.009,-foot_radius],coil[0],24,endpoint=False);return np.vstack([lead,coil])
  lo=.01;hi=30
  for _ in range(32):
   mid=(lo+hi)/2;p=path(mid);length_now=np.linalg.norm(np.diff(p,axis=0),axis=1).sum()
   if length_now<length:lo=mid
   else:hi=mid
  p=path((lo+hi)/2);pitch=(r1-r0)/((lo+hi)/2)
  if pitch<.0033:raise ValueError('Stored cord turns would intersect; give the source assembly more footprint')
  mat='white_cable'if white else'cable';parts=[tube('separate-spaced-full-length-fabric-cord-coil',mat,p.tolist(),.0016,10)]
  if switch:
   pt=p[int(len(p)*.78)];parts.extend([L.RO.box('separate-inline-switch-body','white_switch'if white else'black',.026,.008,.012,(pt[0],.0075,pt[2])),L.RO.box('separate-inline-rocker','white_switch'if white else'black',.016,.003,.007,(pt[0],.013,pt[2]))])
  return parts,float(np.linalg.norm(np.diff(p,axis=0),axis=1).sum()),pitch
 def matset(q,cloth=False):
  col,silver=rgb(q)
  return {'body':('metal'if silver else'paint',col,.12 if silver else .22,1 if silver else 0),'textile':('textile',col,.90,0),'lining':('plastic',[231,230,220],.68,0),'white_cable':('woven',[226,223,215],.86,0),'white_switch':('plastic',[232,231,226],.43,0),'metal':('metal',[205,207,204],.16,1)}
 def prism(name,mat,p,y0,y1,wall=None):
  p=np.array(p,float);n=len(p);loops=[(p,y0),(p,y1)]if wall is None else[(p,y0),(p,y1),(p*(1-wall/(min(np.ptp(p[:,0]),np.ptp(p[:,1]))/2)),y1),(p*(1-wall/(min(np.ptp(p[:,0]),np.ptp(p[:,1]))/2)),y0)]
  v=[];uv=[];f=[]
  for shape,y in loops:
   for x,z in shape:v.append((x,y,z));uv.append((x/.07+.5,y/.07))
  for k in range(len(loops)if wall else len(loops)-1):
   for j in range(n):a=k*n+j;b=k*n+(j+1)%n;c=((k+1)%len(loops))*n+j;d=((k+1)%len(loops))*n+(j+1)%n;f.extend([(a,b,c),(b,d,c)])
  if wall is None:
   for k in[0,1]:
    ci=len(v);v.append((0,[y0,y1][k],0));uv.append((.5,.5))
    for j in range(n):f.append((ci,k*n+j,k*n+(j+1)%n))
  return B.solid(name,mat,v,f,uv,flat=True)
 def circular_body(name,mat,r,y0,y1,wall=.001):return B.lathe(name,mat,[(r,y0),(r,y1),(r-wall,y1),(r-wall,y0)],160,True)
 def conical_rechargeable(q):
  m=q['official_measurements'];h=m.get('height_cm',18)/100;r=m.get('shade_diameter_cm',13.7)/200;yb=h*.80;foot=.0345
  parts=[lathe('separate-tapered-iron-battery-base','body',[(0,0),(foot,0),(foot+.0005,.002),(foot*.54,yb),(0,yb)],192),B.lathe('separate-open-underside-conical-iron-shade','body',[(r,yb),(r,yb+.001),(r*.035,h-.001),(0,h),(0,h-.0014),(r*.035,h-.0024),(r-.0012,yb+.001),(r-.0012,yb)],224,True),B.lathe('separate-annular-recessed-LED-diffuser','opal',[(.020,yb+.001),(.059,yb+.001),(.059,yb+.003),(.020,yb+.003)],160,True)]
  g=B.cylinder('separate-front-round-power-button','metal',.003,0,.0015,n=80);g['_vertices']=[(x,z+h*.13,y+foot*.94)for x,y,z in g['_vertices']];parts.append(g)
  parts.append(L.RO.box('separate-rear-USB-C-inset','black',.007,.0025,.001,(0,.007,-foot)))
  cord,le,pitch=safe_cord(.6,foot,.060,False,False);parts+=cord
  return parts,dict(target_cm=[r*200,h*100,r*200],official_axes=list(m),estimated=['conical_profile','local_wall_and_base_thickness','battery_housing','LED_and_button_dimensions','USB_cable_length_and_stored_pose','depth_rotational_symmetry'],features=['Own-photo low conical metal shade and tall tapered battery base; separate front power button','Open underside with annular opal diffuser and rearUSB-Cport; detached included cable in a nonintersecting stored coil','PerSKUofficial height/shade diameter; unknown local dimensions interpreted; no bulb/glow added'],material_overrides=matset(q),measured_cord_length_m=le,stored_cord_turn_pitch_m=pitch)
 def drum_table(q):
  m=q['official_measurements'];large=q['sku'][:7]in['1223813','1223603'];h=m.get('height_cm',36 if large else 22)/100;r=m.get('diameter_cm',32 if large else 20)/200;yb=h*.275;foot=r*.59
  parts=[lathe('separate-fabric-covered-cylindrical-base','textile',[(0,0),(foot,0),(foot,.002),(foot,yb+.017),(0,yb+.017)],160),circular_body('separate-open-woven-drum-shade','textile',r,yb,h,.0008),circular_body('separate-white-polystyrene-inner-liner','lining',r-.0010,yb+.0004,h-.0004,.0007)]
  for g in parts:
   if g['material']=='textile':g['_uvs']=[((math.atan2(z,x)/T+.5)*T*r/.07,y/.07)for x,y,z in g['_vertices']]
  parts+=L.holder(yb+.016,'E27')
  for j in range(3):
   a=T*j/3;parts.append(tube('separate-hidden-shade-support-'+str(j),'steel',[(.014*math.cos(a),yb+.02,.014*math.sin(a)),((r-.002)*math.cos(a),yb+.02,(r-.002)*math.sin(a))],.001,8))
  c,le,pitch=safe_cord(m.get('cord_length_cm',160)/100,foot,r*.91,True);parts+=c
  estimated=['base_width','shade_base_overlap','fabric_and_liner_thickness','socket_and_frame','stored_cord_pose']
  if'height_cm'not in m:estimated+=['height_cm','diameter_cm']
  return parts,dict(target_cm=[r*200,h*100,r*200],official_axes=list(m),estimated=estimated,features=['Own-photo straight woven drum over a shorter narrower fabric-covered cylindrical foot','Separate open cloth shade, white polystyrene inner liner, emptyE27socket and three real support spokes','Full cord in spaced coil outside the foot, with white inline switch; no artwork, props or active emission'],material_overrides=matset(q,True),measured_cord_length_m=le,stored_cord_turn_pitch_m=pitch)
 def hex_fabric(q):
  m=q['official_measurements'];floor=q['sku'][:6]=='131639';w=m.get('shade_width_cm',41 if floor else 24)/100;d=m.get('shade_depth_cm',29 if floor else 14)/100;sh=m.get('shade_height_cm',40.5 if floor else 12.3)/100;bh=m.get('base_height_cm',44.5 if floor else 14.4)/100;h=m.get('height_cm',(bh+sh)*100)/100;yb=h-sh
  p=np.array([[-w*.5,0],[-w*.25,d*.5],[w*.25,d*.5],[w*.5,0],[w*.25,-d*.5],[-w*.25,-d*.5]]);base=p*.56
  parts=[prism('separate-six-sided-fabric-covered-foot','textile',base,0,bh),prism('separate-open-six-sided-fabric-shade','textile',p,yb,h,.0007),prism('separate-six-sided-polystyrene-liner','lining',p*.988,yb+.0004,h-.0004,.0007)];parts+=L.holder(yb+.012,'E27')
  for x,z in p[::2]*.95:parts.append(tube('separate-upper-shade-mount-'+str(x),'steel',[(0,yb+.02,0),(x,yb+.02,z)],.001,8))
  footr=max(np.linalg.norm(base,axis=1));maxr=max(footr+.025,min(w,d)*.43);c,le,pitch=safe_cord(m.get('cord_length_cm',160)/100,footr,maxr,True);parts+=c
  est=['base_width_depth','shade_base_overlap','fabric_liner_thickness','socket_and_frame','stored_cord_pose','overall_footprint_including_cord']
  if not m:est+=['all_exterior_cm']
  elif'height_cm'not in m:est+=['overall_height_cm_from_component_heights']
  return parts,dict(target_cm=None,official_axes=list(m),estimated=est,features=['Actual stretched six-sided cloth drum and matching six-sided foot, individually sized to own component facts','Open upper/lower shade, finite fabric and separate polystyrene lining, emptyE27holder and frame','Component dimensions kept separate from overall height and loose-cord footprint; unlit physical textile'],material_overrides=matset(q,True),measured_cord_length_m=le,stored_cord_turn_pitch_m=pitch)
 def tall_base(q):
  m=q['official_measurements'];h=m.get('height_cm',41)/100;r=m.get('diameter_cm',9)/200;bh=h*.788;necktop=h*.857;collartop=h-.025
  parts=[lathe('separate-hollow-iron-cylinder-base','body',[(0,0),(r-.0008,0),(r,.001),(r,bh),(.009,bh),(.009,bh-.0012),(r-.0012,bh-.0012),(r-.0012,.003),(0,.003)],192),lathe('separate-chrome-top-neck','metal',[(0,bh-.002),(.010,bh-.002),(.010,necktop+.002),(0,necktop+.002)],96),lathe('separate-wide-chrome-socket-collar','metal',[(0,necktop-.001),(.022,necktop-.001),(.022,collartop),(.012,collartop),(.012,necktop+.002),(0,necktop+.002)],128),B.lathe('separate-white-empty-E27-insulator-and-flange','socket_white',[(.012,h-.026),(.025,h-.026),(.025,h-.024),(.018,h-.024),(.018,h-.005),(.0175,h),(.014,h),(.014,h-.020),(.012,h-.020)],128,True)]
  for j in range(5):
   yy=h-.019+j*.0035;parts.append(tube('separate-white-E27-external-screw-ridge-'+str(j),'socket_white',[(.0183*math.cos(a),yy,.0183*math.sin(a))for a in np.linspace(0,T,96,endpoint=False)],.00045,8,True))
  for j in range(3):
   yy=h-.018+j*.003;parts.append(tube('separate-inner-E27-metal-thread-'+str(j),'steel',[(.0136*math.cos(a),yy,.0136*math.sin(a))for a in np.linspace(0,T,96,endpoint=False)],.0005,8,True))
  mats=matset(q);mats['socket_white']=('plastic',[231,229,218],.47,0)
  if any(x in q.get('colour','').lower()for x in['brown','braun']):
   mats['body']=('woodprint',[102,72,47],.37,0);parts[0]['_uvs']=[((math.atan2(z,x)/T+.5)*4,y/.1333)for x,y,z in parts[0]['_vertices']]
  c,le,pitch=safe_cord(m.get('cord_length_cm',160)/100,r,.075,True);parts+=c
  return parts,dict(target_cm=None,official_axes=list(m),estimated=['local_wall_thickness','body_neck_collar_component_heights','E27_hardware_dimensions','cord_length_if_unpublished','stored_cord_pose','whole_model_footprint_including_cord'],features=['Own-photo long iron cylinder, distinct narrowchrome neck and broad socketcollar, plus white threaded emptyE27holder','Official41cmheight/9cmbase diameter preserved where published; cablefootprint is separately estimated','BrownSKU has wood-effect printing on iron, not wood; native material-only crop with repeat explicitly recorded'],material_overrides=mats,measured_cord_length_m=le,stored_cord_turn_pitch_m=pitch)
 out={}
 for sku,q in L.sources().items():
  if sku[:7]=='1277532':out[sku]=conical_rechargeable
  elif sku[:7]in['1223812','1223602','1223813','1223603']:out[sku]=drum_table
  elif sku[:7]in['1311994','1311993','1316391','1316390']:out[sku]=hex_fabric
  elif sku[:7]in['1257868','1257859']:out[sku]=tall_base
 return out
