"""Prepare exact per-scene JSON mesh subsets for SceneKit. Does not touch source assets."""
from pathlib import Path
import sys,json,copy,subprocess,hashlib
import build_lighting as L
manifest=Path(sys.argv[1]);Q=Path(sys.argv[2]);Q.mkdir(parents=True,exist_ok=True);rows=json.loads(manifest.read_text());out=[];proof=[]
for e in rows:
 model=json.loads(Path(e['model_path']).read_text());doc,binary=L.read_glb(e['glb_path']);assert L.sha(e['glb_path'])==e['sha256'];seen=set()
 for index,scene in enumerate(doc['scenes']):
  stack=list(scene['nodes']);nodes=[]
  while stack:
   n=stack.pop(0);assert n not in nodes;nodes.append(n);stack.extend(doc['nodes'][n].get('children',[]))
  assert seen.isdisjoint(nodes),'Viewer-compatible scenes need distinct node records';seen.update(nodes);indices=[doc['nodes'][i]['mesh']for i in nodes if'mesh'in doc['nodes'][i]];assert indices
  folder=Q/(e['id']+'-scene'+str(index));folder.mkdir(parents=True,exist_ok=True);native=copy.deepcopy(model);native['meshes']=[model['meshes'][i]for i in indices];L.dump(folder/'model.json',native)
  copied=[]
  for ma in model['materials'].values():
   for key in['baseColorTexture','normalTexture','metallicRoughnessTexture']:
    if key not in ma:continue
    src=Path(e['model_path']).parent/ma[key];dest=folder/ma[key];subprocess.run(['/bin/cp','-c',str(src),str(dest)],check=True);assert L.sha(src)==L.sha(dest);copied.append(dict(source=str(src),copy=str(dest),sha256=L.sha(src),APFS_clone_requested=True))
  label=scene.get('name',str(index));out.append(dict(id=folder.name,sku=e['sku'],view_label=e['sku']+' · '+label,model_path=str(folder/'model.json'),asset_dir=str(folder),original_image=e['original_image'],source_glb=e['glb_path'],source_glb_sha256=e['sha256'],scene_index=index,scene_name=label,exact_mesh_subset=indices));proof.append(dict(sku=e['sku'],scene_index=index,nonempty=True,node_indices=nodes,distinct_node_records_per_scene=True,exact_audited_JSON_mesh_subset_indices=indices,maps=copied))
L.dump(Q/'manifest.json',out);L.dump(Q/'scene-subset-byte-proof.json',proof);print('SCENE_NATIVE_PREPARED',len(out),'views')
