"""Merge immutable research handoffs without discarding hydrated image URLs.
Only explicit measurement/composition facts are parsed; no dimensions invented.
"""
from pathlib import Path
import json,re,urllib.parse
R=Path(__file__).resolve().parent
def valid_images(images):
 out={}
 for im in images:
  url=im.get('url')or im.get('src')or''
  if not url.startswith('https://image.hm.com/assets/')or re.search(r'energy\s*label|energielabel',im.get('alt')or'',re.I)or'43382530e8941d1ac8ff4a2b32d870f2aee80512'in url:continue
  u=urllib.parse.urlsplit(url);quality=int(urllib.parse.parse_qs(u.query).get('imwidth',['0'])[0]);key=u.path
  if key not in out or quality>out[key][0]:out[key]=(quality,im)
 return [v[1]for v in out.values()]
def load_queues():
 paths=list((R.parent/'lighting-research').glob('confirmed-queue*.json'));paths.sort(key=lambda p:(5 if 'research-final'in p.name else(4 if 'pdp-research-progress'in p.name else(3 if 'pdp-update'in p.name else(2 if 'gallery-update'in p.name else(1 if 'batch-'in p.name else 0)))),p.name));out={}
 for p in paths:
  if'.proof.'in p.name:continue
  raw=json.loads(p.read_text());rows=raw if isinstance(raw,list)else raw.get('products',raw.get('records',[]))
  for q in rows:
   sku=q['sku'];old=out.get(sku,{})
   for key,value in q.items():
    if key=='reference_images':old[key]=valid_images(value+old.get(key,[]))
    elif key=='official_measurements':old[key]={**old.get(key,{}),**value}
    elif key=='source_evidence_files':old[key]=list(dict.fromkeys(old.get(key,[])+value))
    elif value not in[None,'',[],{}]:old[key]=value
   out[sku]=old
 if (R/'root-live-overrides.json').exists():
  for q in json.loads((R/'root-live-overrides.json').read_text()):
   old=out[q['sku']]
   for key,value in q.items():
    if key=='official_measurements':old[key]={**old.get(key,{}),**value}
    elif key=='source_evidence_files':old[key]=list(dict.fromkeys(old.get(key,[])+value))
    else:old[key]=value
 for q in out.values():
  q.setdefault('reference_images',[]);q.setdefault('composition',[]);m=q.setdefault('official_measurements',{})
  for fact in q.get('official_dimension_facts',[]):
   number=re.findall(r'([0-9]+(?:[.,][0-9]+)?)\s*cm',fact,re.I)
   if not number:continue
   val=float(number[0].replace(',','.'));s=fact.lower();part='shade_'if any(x in s for x in['lampshade:','shade:','lampenschirm:'])else('base_'if any(x in s for x in['base:','sockel:'])else('cord_'if any(x in s for x in['cord','cable','kabel'])else''))
   label=next((name for words,name in[(['diameter','durchmesser','çap'],'diameter_cm'),(['height','höhe','yükseklik'],'height_cm'),(['width','breite','genişlik'],'width_cm'),(['depth','tiefe','derinlik'],'depth_cm'),(['length','länge','uzunluk'],'length_cm')]if any(w in s for w in words)),None)
   if label:
    m.setdefault(part+label,val)
    if part=='cord_'and label=='length_cm'and m.get('length_cm')==val:m.pop('length_cm')
  if not q.get('colour'):q['colour']=q.get('colour_verbatim','')
  if not q['composition']:
   for fact in q.get('composition_facts',[]):
    part,sep,text=fact.partition(':');text=text if sep else part
    values={name.strip():float(val.replace(',','.'))for name,val in re.findall(r'([^,:;0-9]+?)\s*([0-9]+(?:[.,][0-9]+)?)\s*%',text)}
    if values:q['composition'].append(dict(part=part.strip()if sep else'Main part',materials=values))
  q.setdefault('id','hm-source-'+q['sku']);q.setdefault('name',q.get('name_tr',q['sku']));q.setdefault('source_market','GB');q['source_normalization']='Only exact official fact strings parsed; photo URLs merged by observed asset and highest observed resolution.'
  q['source_evidence_files']=[str(p if p.is_absolute()else R.parents[3]/p)for p in map(Path,q.get('source_evidence_files',[]))]
 return out
