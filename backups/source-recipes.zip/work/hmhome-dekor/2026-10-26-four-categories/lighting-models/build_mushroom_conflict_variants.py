"""Preserve initial candidates; make explicitly labelled dimension interpretations.
Only two SKUs. No change to source photo masters or original candidate assets.
"""
from pathlib import Path
import sys,json,copy,hashlib,shutil,datetime
sys.dont_write_bytecode=True
import numpy as np
from PIL import Image
import build_lighting as L
import render_geometry_qa as QA
R=Path(__file__).resolve().parent
SKUS=['1225620014','1225622002']
sha=L.sha;dump=L.dump
def run():
 current=json.loads((R/'manifest.json').read_text());frozen=R/'frozen-batch-000-original-candidates-manifest.json'
 if not frozen.exists():dump(frozen,[x for x in current if x['sku']in SKUS])
 originals=json.loads(frozen.read_text());original_hashes=[];results=[]
 for e in originals:
  for key in['glb_path','model_path','geometry_validation','material_validation']:
   original_hashes.append(dict(path=e[key],sha256=sha(e[key])))
  source=json.loads(Path(e['model_path']).read_text());pid=e['sku'];variants=[]
  for label,h in [('resmî ölçü',18),('fotoğraf oranı',23.4)]:
   tag='official'if h==18 else'photo';id=f'hm-{pid}-h{str(h).replace(".","p")}-w22-d22-{tag}-v2';out=R/'variants'/id
   if (out/'entry.json').exists():raise RuntimeError('Do not overwrite an existing interpretation variant '+id)
   out.mkdir(parents=True,exist_ok=False);materials=copy.deepcopy(source['materials'])
   for ma in materials.values():
    for key in['baseColorTexture','normalTexture','metallicRoughnessTexture']:shutil.copy2(Path(e['asset_dir'])/ma[key],out/ma[key])
   if pid=='1225622002':
    # Exact white studio gallery and cord close-up establish the white cord/switch.
    for key,col in [('cable',[222,219,211]),('black',[233,233,229])]:
     path=out/materials[key]['baseColorTexture'];a=np.asarray(Image.open(path).convert('RGB')).astype(float);detail=a-a.mean(axis=(0,1),keepdims=True);Image.fromarray(np.clip(np.array(col)+detail,0,255).astype(np.uint8),'RGB').save(path,optimize=True);materials[key]['extras']['source_colour_evidence']='ExactSKUwhitecord/switch from fed91ef...fullproduct and d67dc...cordclose-up; intrinsicmap recolouring only.'
   meta=copy.deepcopy(source['metadata']);note='Resmî sayfa18cm yükseklik/22cm çap verir; ürünfotoğrafıdaha uzun görünür. İkiyorum ayrıGLB: resmîölçü18cm ve22cmçapankrajıyla fotoğraftan tahmini23.4cm. ÜreticiCADdeğildir.'
   meta.update(id=id,name=e['name']+' ('+label+')',dimensions_cm=[22,h,22],estimated_dimensions=True,quality_status='source_measurement_conflict',quality_label='Kaynak ölçü çatışması',quality_note=note,scale_note=meta['scale_note']+' '+note,source_measurement_conflict=True,dimension_interpretation=label,product_count_semantics='OneSKUproduct with two model interpretations; never count as two products.',original_candidate_glb_preserved=e['glb_path'],original_candidate_glb_sha256=e['sha256'],photo_ratio_evidence=str(R/'qa/mushroom-photo-ratio-evidence-v2.json'),model_status='pending_root_joint_interpretation_review',quality_pending=True)
   if h!=18:meta['estimated_fields']=list(dict.fromkeys(meta['estimated_fields']+['height_cm']));meta['height_source_kind']='photo_proportion_estimate_at_official22cm_diameter'
   else:meta['estimated_fields']=[x for x in meta['estimated_fields']if x!='height_cm'];meta['height_source_kind']='official_listed18cm_height'
   if pid=='1225622002':
    im=next(x for x in json.loads((R/'original-image-masters.json').read_text())if x['sku']==pid and'fed91ef1fdfc0fd21028328de26d66a04bb8bc61'in x['url']);meta.update(original_image=im['path'],original_image_url=im['url'],original_image_sha256=im['sha256'])
   meshes=[];checks=[]
   for src in source['meshes']:
    p=np.array(src['positions']).reshape(-1,3);name=src['name'];factor=h/18
    if any(s in name for s in['cylindrical-painted-iron-foot','open-bottom-rounded-iron-dome','white-inner-shade-reflector']):p[:,1]*=factor
    elif 'G9'in name:p[:,1]+=.109*(factor-1)
    raw=L.B.solid(name,src['material'],p.tolist(),np.array(src['indices']).reshape(-1,3).tolist(),np.array(src['uvs']).reshape(-1,2).tolist());raw=L.G.H.orient(raw);m,c=L._finalize(raw);L.G.H.S.flatcap_normals(m);meshes.append(m);checks.append(c)
   repairs=L.G.M.ensure_uv_faces(meshes)+L.G.H.ensure_float32_uv(meshes)
   dump(out/'model.json',dict(metadata=meta,materials=materials,meshes=meshes));dump(out/'geometry-validation.json',dict(valid=True,closed_material_solids=True,mesh_count=len(meshes),triangles=sum(x['triangles']for x in checks),meshes=checks,uv_repairs=repairs,dimension_interpretation=label))
   dump(out/'material-validation.json',dict(valid=True,original_photo_masters_unchanged=True,white_cord_and_switch_source_verified=pid=='1225622002',baked_reflections=False,unlit=True,maps=[dict(path=str(p),sha256=sha(p),native_resolution=list(Image.open(p).size))for p in out.glob('*.png')]))
   report=L.export_assets(out/'model.json',out,id);glb=out/(id+'.glb');doc,binary=L.read_glb(glb);binary=L.G.M.embed_tangents(doc,binary);L.write_glb(glb,doc,binary);report['deliverable_sha256']['glb']=sha(glb);report['glb_bytes']=glb.stat().st_size;dump(report['files']['validation'],report)
   row=dict(e);row.update(meta);row.update(asset_dir=str(out),model_path=str(out/'model.json'),glb_path=str(glb),sha256=sha(glb),bytes=glb.stat().st_size,geometry_validation=str(out/'geometry-validation.json'),material_validation=str(out/'material-validation.json'),model_revision='hm-mushroom-source-conflict-two-interpretations-2026-10-27-v2');dump(out/'entry.json',row)
   qadir=R/'qa/mushroom-conflicts'/id;qadir.mkdir(parents=True,exist_ok=True);_,parts,textures=QA.read(glb);views=[]
   for title,direction in [('front',[0,.025,1]),('threequarter',[.58,.26,1]),('side',[1,.12,.06]),('rear',[.4,.20,-1])]:
    path=qadir/(title+'.png');QA.draw(parts,textures,np.array([.22,h/100,.22]),direction,path);views.append(dict(label=title,path=str(path),sha256=sha(path)))
   dump(qadir/'render-validation.json',dict(sku=pid,id=id,actual_glb=str(glb),glb_sha256=sha(glb),geometry_source='ExactGLBaccessorbytes',dimension_interpretation=label,views=views,renderer='Softwaregeometrydiagnostics; rootactualPBRmaterialreviewpending'))
   results.append(row);variants.append(row);print('INTERPRETATION',pid,label,[22,h,22],sha(glb),flush=True)
  primary=copy.deepcopy(variants[0]);primary['model_variants']=variants;primary['actual_model_variants']=2;primary['ready_model_variants']=0
  current=[primary if x['sku']==pid else x for x in current]
 for x in original_hashes:assert sha(x['path'])==x['sha256']
 dump(R/'qa/mushroom-original-candidate-preservation.json',dict(unchanged=True,files=original_hashes))
 dump(R/'mushroom-conflict-variants.json',results);dump(R/'manifest.json',current);L.update_ledger()
if __name__=='__main__':run()
