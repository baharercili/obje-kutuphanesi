"""Change only interpreted bronze glass volume attenuation distance; immutable old payload."""
from pathlib import Path
import sys,json,copy,subprocess,hashlib
P=Path(__file__).resolve().parent.parent;sys.path.insert(0,str(P/'lighting-models'));import build_lighting as L
R=Path('/private/tmp/hm-lighting-20261028/prism-wall-bronze-optics-two-r02');R.mkdir(parents=True,exist_ok=True);OLD=P/'lighting-glass-prism-wall-three-015/frozen-own-hammered-prism-wall-three-manifest.json';IDS=['1277543002','1277798003']
if list(R.glob('frozen*manifest*.json'))or(R/'comparison-only-receipt.json').exists():raise RuntimeError('Frozen optics revision preserved.')
registry=[x for x in json.loads(Path('/private/tmp/hm-lighting-20261028/glass-prism-wall-three-015/original-image-masters.json').read_text())if x['sku']in IDS]
for x in registry:assert L.sha(x['path'])==x['sha256']
L.dump(R/'original-image-masters.json',registry);rows=[];proof=[]
for old in json.loads(OLD.read_text()):
 if old['sku']not in IDS:continue
 source=Path(old['model_path']);old_json_sha=L.sha(source);old_glb_sha=L.sha(old['glb_path']);model=json.loads(source.read_text());before=copy.deepcopy(model);doc,binary=L.read_glb(old['glb_path']);old_doc=copy.deepcopy(doc);old_binary=bytes(binary);ident=old['id']+'-bronze-absorption-r02';out=R/'models'/ident;out.mkdir(parents=True,exist_ok=True)
 for pp in source.parent.glob('*.png'):subprocess.run(['/bin/cp','-c',str(pp),str(out/pp.name)],check=True);assert L.sha(pp)==L.sha(out/pp.name)
 for pp in source.parent.glob('*provenance.json'):subprocess.run(['/bin/cp','-c',str(pp),str(out/pp.name)],check=True)
 assert model['materials']['glass']['attenuationDistance']==.008;model['materials']['glass']['attenuationDistance']=.002
 glass=next(x for x in doc['materials']if x['name']=='glass');assert glass['extensions']['KHR_materials_volume']['attenuationDistance']==.008;glass['extensions']['KHR_materials_volume']['attenuationDistance']=.002
 e=copy.deepcopy(old);e.update(id=ident,asset_dir=str(out),model_path=str(out/'model.json'),glb_path=str(out/(ident+'.glb')),geometry_validation=str(out/'geometry-validation.json'),material_validation=str(out/'material-validation.json'),model_revision='hm-bronze-glass-absorption-only-r02-2026-10-28',model_status='pending_root_visual_review',quality_pending=True,quality_label='Dumanlı cam optiği fotoğraf yorumudur',quality_note='Dumanlı camın ışık soğurması kendi fotoğraf görünümüne göre tahmin edilmiştir; ölçülmüş optik katsayı değildir.');e['scale_note']+=' Bu ayrı optik revizyonda dumanlı camın ışık soğurması kendi fotoğraf görünümüne göre yeniden yorumlanmıştır; bu bir optik ölçüm değildir. Gövde, tüm normal haritaları, diğer malzemeler ve kaynak fotoğrafları önceki dondurulmuş adayla birebir korunur.';e['diameter_semantics']=e['scale_note'];e['optics_revision']=dict(previous_attenuation_distance_m=.008,photo_interpreted_attenuation_distance_m=.002,glass_thickness_m=.003,measured_optics=False,all_other_material_parameters_unchanged=True)
 meta=copy.deepcopy(e)
 for key in ['sha256','bytes','asset_dir','model_path','glb_path','geometry_validation','material_validation']:meta.pop(key,None)
 model['metadata']=meta;doc['extras']=copy.deepcopy(meta);L.dump(out/'model.json',model);L.write_glb(e['glb_path'],doc,binary);e.update(sha256=L.sha(e['glb_path']),bytes=Path(e['glb_path']).stat().st_size)
 assert model['meshes']==before['meshes']
 check=copy.deepcopy(doc['materials']);next(x for x in check if x['name']=='glass')['extensions']['KHR_materials_volume']['attenuationDistance']=.008;assert check==old_doc['materials']
 check=copy.deepcopy(model['materials']);check['glass']['attenuationDistance']=.008;assert check==before['materials']
 for key in['nodes','meshes','accessors','bufferViews','images','textures','samplers','scenes']:assert doc[key]==old_doc[key]
 newdoc,newbinary=L.read_glb(e['glb_path']);assert newbinary==old_binary;assert L.sha(old['glb_path'])==old_glb_sha and L.sha(source)==old_json_sha
 for pp in source.parent.glob('*.png'):assert L.sha(pp)==L.sha(out/pp.name)
 record=dict(sku=e['sku'],old_frozen_glb_sha256=old_glb_sha,old_frozen_model_json_sha256=old_json_sha,old_frozen_files_unchanged=True,all_geometry_positions_normals_UVs_indices_identical=True,all_GLTF_nodes_scenes_accessors_views_images_textures_samplers_identical=True,complete_binary_chunk_identical=True,all_PNG_map_and_native_crop_bytes_identical=True,all_original_JPEG_hashes_unchanged=True,only_material_change='glass.KHR_materials_volume.attenuationDistance0.008_to0.002m',JSON_material_value_m=model['materials']['glass']['attenuationDistance'],actual_GLTF_material_value_m=next(x for x in newdoc['materials']if x['name']=='glass')['extensions']['KHR_materials_volume']['attenuationDistance'],source_optics_photo_interpreted_not_measured=True)
 L.dump(out/'optics-only-preservation-proof.json',record);L.dump(e['geometry_validation'],dict(valid=True,geometry_identical_to_frozen015=True,original_geometry_validation=old['geometry_validation']));L.dump(e['material_validation'],dict(valid=True,physical_glass_JSON_GLB_congruent=True,only_attenuation_distance_changed=True,original_maps_native_pixels_preserved=True,proof=record));L.dump(out/'entry.json',e);rows.append(e);proof.append(record)
L.dump(R/'manifest.json',rows);L.dump(R/'optics-only-preservation-proof.json',proof);print('BRONZE2 optics-only revision, binary and all maps identical',flush=True)
