"""Candle2 scene-only revision; every original mesh, material and PNG preserved."""
from pathlib import Path
import sys,json,copy,subprocess
P=Path(__file__).resolve().parent.parent;sys.path.insert(0,str(P/'lighting-models'));import build_lighting as L
R=Path('/private/tmp/hm-lighting-20261028/candle-scenes-r02');R.mkdir(parents=True,exist_ok=True)
if list(R.glob('frozen*manifest*.json')):raise RuntimeError('Frozen scene revision preserved.')
rows=[];proof=[];qa=[]
for old in json.loads((P/'lighting-portable-batch-008/frozen-portable-ten-manifest.json').read_text()):
 if old['sku']not in['1316181002','1316181003']:continue
 src=Path(old['model_path']);model=json.loads(src.read_text());doc,binary=L.read_glb(old['glb_path']);body=[i for i,m in enumerate(model['meshes'])if m['name']!='separate-included-USB-cable-loose-disconnected-stored-pose'];allnodes=list(range(len(model['meshes'])));assert len(body)==len(allnodes)-1;oldsha=L.sha(old['glb_path']);oldjsonsha=L.sha(src)
 ident=old['id']+'-fixture-default-r02';out=R/'models'/ident;out.mkdir(parents=True,exist_ok=True)
 for ma in model['materials'].values():
  for key in['baseColorTexture','normalTexture','metallicRoughnessTexture']:
   if key in ma:
    pp=src.parent/ma[key];dest=out/ma[key];subprocess.run(['/bin/cp','-c',str(pp),str(dest)],check=True);assert L.sha(pp)==L.sha(dest)
 entry=copy.deepcopy(old);entry.update(id=ident,asset_dir=str(out),model_path=str(out/'model.json'),glb_path=str(out/(ident+'.glb')),model_revision='hm-candle-fixture-default-scene-r02-2026-10-28',model_status='pending_root_visual_review',quality_pending=True,scene_variants=[dict(index=0,label='Armatür'),dict(index=1,label='USB kablosuyla')],default_scene_index=0,quality_label='USB kablosu ayrı sahnede',quality_note='İlk görünüm yalnız armatürü gösterir. Dahil USB kablosu isteğe bağlı ikinci görünümde, bağlantısız ve tahmini sarılı pozdadır.')
 entry['estimated_fields']+=['optional_USB_cable_storage_pose_only_not_product_handle'];entry['scale_note']+=' Varsayılan Armatür sahnesinde dahil şarj kablosu gösterilmez. USB kablosuyla ikinci sahnesi ayrı kabloyu tahmini sarılı pozda açar; beyaz kablo armatürün yuvarlak tutma kolunun bir parçası değildir.';entry['diameter_semantics']=entry['scale_note'];entry['geometry_limitations']=entry['estimated_fields'];metadata=copy.deepcopy(entry)
 for key in['sha256','bytes','asset_dir','model_path','glb_path','geometry_validation','material_validation']:metadata.pop(key,None)
 model['metadata']=metadata;L.dump(out/'model.json',model);doc['extras']=metadata;doc['scenes']=[dict(name='Armatür',nodes=body),dict(name='USB kablosuyla',nodes=allnodes)];doc['scene']=0;L.write_glb(entry['glb_path'],doc,binary);entry.update(sha256=L.sha(entry['glb_path']),bytes=Path(entry['glb_path']).stat().st_size,geometry_validation=str(out/'geometry-validation.json'),material_validation=str(out/'material-validation.json'));L.dump(entry['geometry_validation'],dict(valid=True,scene_only_revision=True,all_mesh_arrays_normals_UVs_indices_identical_to_frozen008=True,default_scene_mesh_indices=body,optional_scene_mesh_indices=allnodes));L.dump(entry['material_validation'],dict(valid=True,all_materials_and_PNG_bytes_identical_to_frozen008=True));L.dump(out/'entry.json',entry);rows.append(entry);proof.append(dict(sku=entry['sku'],old_frozen_glb_sha256=oldsha,old_frozen_model_json_sha256=oldjsonsha,old_files_unchanged=L.sha(old['glb_path'])==oldsha and L.sha(src)==oldjsonsha,binary_chunk_identical=True,all_mesh_JSON_arrays_identical=True,default_scene_has_no_USB_cord=True,optional_scene_includes_the_original_detached_USB_cord=True))
 # Native renderer consumes JSON meshes rather than glTF scenes; make explicit subset QA views.
 for mode,indices in [('fixture-only',body),('with-USB',allnodes)]:
  folder=R/'qa/native'/(ident+'-'+mode);folder.mkdir(parents=True,exist_ok=True);native=copy.deepcopy(model);native['meshes']=[model['meshes'][i]for i in indices];L.dump(folder/'model.json',native)
  for pp in out.glob('*.png'):subprocess.run(['/bin/cp','-c',str(pp),str(folder/pp.name)],check=True)
  qa.append(dict(id=ident+'-'+mode,model_path=str(folder/'model.json'),asset_dir=str(folder),sku=entry['sku'],source_glb=entry['glb_path'],scene_index=0 if mode=='fixture-only'else 1,exact_mesh_subset_indices=indices))
L.dump(R/'manifest.json',rows);L.dump(R/'source-body-and-scene-preservation-proof.json',proof);L.dump(R/'qa/native/manifest.json',qa);L.dump(R/'original-image-masters.json',[x for x in json.loads(Path('/private/tmp/hm-lighting-20261028/portable-008/original-image-masters.json').read_text())if x['sku']in{e['sku']for e in rows}]);print('CANDLE2 scene-only candidates generated')
