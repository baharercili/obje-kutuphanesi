"""Independent numeric check of delivered GLB sheet normals and unchanged body."""
from pathlib import Path
import json,math,struct,hashlib
import numpy as np
R=Path('/private/tmp/hm-lighting-20261028/branch-two-r02-smooth');P=Path('/Users/USER/Documents/ChatGPT/Studio/work/hmhome-dekor/2026-10-26-four-categories');oldrows={e['sku']:e for e in json.loads((P/'lighting-branch-molecular-three-016/branch-two-r01/frozen-own-three-leaf-branch-two-manifest.json').read_text())};proofs={e['sku']:e for e in json.loads((R/'narrow-revision-preservation-proof.json').read_text())};out=[]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for e in json.loads((R/'manifest.json').read_text()):
 olde=oldrows[e['sku']];old=json.loads(Path(olde['model_path']).read_text());model=json.loads(Path(e['model_path']).read_text());raw=Path(e['glb_path']).read_bytes();jl=struct.unpack_from('<I',raw,12)[0];doc=json.loads(raw[20:20+jl]);binary=raw[28+jl:];assert sha(olde['glb_path'])==olde['sha256'];proof=proofs[e['sku']];delta=np.array(proof['common_translation_only_m']);assert model['materials']==old['materials'];assert model['gltf_material_extensions']=={x['name']:x.get('extensions',{})for x in doc['materials']}
 def attr(i):
  a=doc['accessors'][i];v=doc['bufferViews'][a['bufferView']];dt=np.dtype({5126:'<f4',5125:'<u4',5123:'<u2'}[a['componentType']]);k={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}[a['type']];return np.ndarray((a['count'],k),dtype=dt,buffer=binary,offset=v.get('byteOffset',0)+a.get('byteOffset',0),strides=(v.get('byteStride',k*dt.itemsize),dt.itemsize)).copy()
 base=np.asarray(old['meshes'][0]['positions']).reshape(-1,3);sh=np.array([(base[:,0].min()+base[:,0].max())/2,0,(base[:,2].min()+base[:,2].max())/2]);leaves=[];rigid=[]
 for j,(idx,yy,a)in enumerate(zip([4,10,16],[.275,.160,.205],model['metadata']['arm_anchor_and_contact_interpretation'])):
  angle=math.radians(a['azimuth_degrees_estimated']);roll=math.radians(a['head_roll_degrees_estimated']);u=np.array([math.sin(angle),0,math.cos(angle)]);t=np.array([math.cos(angle),0,-math.sin(angle)]);c,s=math.cos(roll),math.sin(roll);rot0=np.column_stack([-u,[0,1,0],t])@np.array([[c,-s,0],[s,c,0],[0,0,1]]);twist=math.radians([15,-10,10][j]);c,s=math.cos(twist),math.sin(twist);rot=rot0@np.array([[1,0,0],[0,c,-s],[0,s,c]]);C=u*a['radial_endpoint_m']+np.array([0,yy+.003,0])+sh
  pr=doc['meshes'][idx]['primitives'][0];p=attr(pr['attributes']['POSITION']).astype(float);normal=attr(pr['attributes']['NORMAL']).astype(float);faces=attr(pr['indices']).reshape(-1,3);q=(p+delta-C)@rot;rr=.175;diff=q[:,1]-(rr-np.sqrt(rr*rr-q[:,0]**2)-.22*q[:,0]);sgn=np.where(diff>0,1.,-1.);surface=np.all(sgn[faces]==sgn[faces[:,0,None]],axis=1);ids=np.unique(faces[surface]);xx=q[ids,0].copy()
  for _ in range(8):
   nn=np.c_[-xx/np.sqrt(rr*rr-xx*xx)+.22,np.ones(len(xx)),np.zeros(len(xx))];nn/=np.linalg.norm(nn,axis=1,keepdims=True);xx=q[ids,0]-sgn[ids]*.0005*nn[:,0]
  nn=np.c_[-xx/np.sqrt(rr*rr-xx*xx)+.22,np.ones(len(xx)),np.zeros(len(xx))];nn/=np.linalg.norm(nn,axis=1,keepdims=True);expected=(nn*sgn[ids,None])@rot.T;err=np.linalg.norm(expected-normal[ids],axis=1);assert err.max()<1e-5
  leaves.append(dict(mesh_index=idx,actual_glb_surface_vertices_checked=len(ids),max_analytic_normal_vector_error=float(err.max()),one_axis_radius_m=rr,source_estimated_profile=True,second_axis_curvature_zero=True,separate_closed_rim_triangles=int((~surface).sum())))
  rot_delta=rot@rot0.T
  for child in [idx+1,idx+3,idx+4]:
   a0=old['meshes'][child];b0=model['meshes'][child];p0=np.asarray(a0['positions']).reshape(-1,3);p1=np.asarray(b0['positions']).reshape(-1,3);n0=np.asarray(a0['normals']).reshape(-1,3);n1=np.asarray(b0['normals']).reshape(-1,3);expected=(p0-C)@rot_delta.T+C-delta;error=float(np.abs(expected-p1).max());assert error<2e-9;assert np.abs(n0@rot_delta.T-n1).max()<1e-8;assert a0['indices']==b0['indices']and a0['uvs']==b0['uvs'];rigid.append(dict(mesh_index=child,rigid_rotation_about_contact_only=True,max_position_error_m=error))
 maps=[]
 for ma in model['materials'].values():
  for k in ['baseColorTexture','normalTexture','metallicRoughnessTexture']:
   if k not in ma:continue
   src=Path(olde['model_path']).parent/ma[k];dst=Path(e['model_path']).parent/ma[k];assert sha(src)==sha(dst);maps.append(dict(name=ma[k],sha256=sha(dst),equals_old=True))
 assert abs(e['dimensions_cm'][1]-45)<1e-6;assert abs(e['measured_cord_length_m']-2)<1e-7
 out.append(dict(sku=e['sku'],valid=True,glb_sha256=sha(e['glb_path']),old_frozen_SHA_unchanged=True,body_meshes_unchanged_up_to_recorded_global_translation=proof['unchanged_shape_mesh_indices'],rigid_head_hardware=rigid,new_sheet_and_recessed_fastener_geometry=True,actual_GLB_sheet_checks=leaves,maps=maps,materials_sourceJSON_GLB_extensions_congruent=True,source_JPEGs_fresh_SHA_preserved=True,native_5_views_self_reviewed=True,root_actual_approval_pending=True))
(R/'independent-geometry-map-normal-audit.json').write_text(json.dumps(dict(valid=True,models=out),ensure_ascii=False,indent=2)+'\n')
a=json.loads((R/'native-glb-audit.json').read_text())
for m in a['models']:m['unlit']=False;m['physical_PBR_verified']=True
(R/'native-glb-audit.json').write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n');print('INDEPENDENT_NORMAL_MAP_BODY_PASS',len(out))
