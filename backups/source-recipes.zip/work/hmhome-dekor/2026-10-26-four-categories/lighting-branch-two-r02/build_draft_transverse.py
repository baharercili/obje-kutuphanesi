"""Own-source branch fixture revision: one-axis bent rounded-rectangle sheets."""
from pathlib import Path
import sys,json,math,copy,hashlib,subprocess
sys.dont_write_bytecode=True
import numpy as np
P=Path('/Users/USER/Documents/ChatGPT/Studio/work/hmhome-dekor/2026-10-26-four-categories');A=Path(__file__).resolve().parent
sys.path.insert(0,str(P/'lighting-models'));import build_lighting as L
T=math.tau;R=Path(sys.argv[1]);R.mkdir(parents=True,exist_ok=False);S=Path('/private/tmp/hm-lighting-20261028/metal-glass-final-six-source-review');old_manifest=P/'lighting-branch-molecular-three-016/branch-two-r01/frozen-own-three-leaf-branch-two-manifest.json'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def clone(src,dst):
 dst=Path(dst);dst.parent.mkdir(parents=True,exist_ok=True);assert not dst.exists();subprocess.run(['/bin/cp','-c',str(src),str(dst)],check=True);assert sha(src)==sha(dst)
def sheet(name):
 # The sheet is developable: linear in radial X, circular only across Z.
 # Its rounded rectangular cut is not a radially dished bowl.
 boundary=L.G.rounded(.28,.22,.075,48);na=len(boundary);nr=45;rr=.17125;th=.001;v=[];uv=[];loops=[]
 for inside in [False,True]:
  offs=-th/2 if not inside else th/2
  def point(x,z):
   y=rr-math.sqrt(rr*rr-z*z)+.22*x
   normal=np.array([-.22,1.,-z/math.sqrt(rr*rr-z*z)]);normal/=np.linalg.norm(normal);return tuple(np.array([x,y,z])+normal*offs)
  index=[[len(v)]];v.append(point(0,0));uv.append((.5,.5))
  for rho in np.linspace(1/nr,1,nr):
   row=[]
   for xx,zz in boundary:
    x,z=xx*rho,zz*rho;row.append(len(v));v.append(point(x,z));uv.append((x/.28+.5,z/.22+.5))
   index.append(row)
  loops.append(index)
 f=[]
 for idx in loops:
  for a,b in zip(idx[:-1],idx[1:]):
   for j in range(na):
    if len(a)==1:f.append((a[0],b[j],b[(j+1)%na]))
    else:f.extend([(a[j],a[(j+1)%na],b[j]),(a[(j+1)%na],b[(j+1)%na],b[j])])
 a,b=loops[0][-1],loops[1][-1]
 for j in range(na):f.extend([(a[j],a[(j+1)%na],b[j]),(a[(j+1)%na],b[(j+1)%na],b[j])])
 return L.B.solid(name,'paint',v,f,uv,flat=False)
def matrix(angle,roll):
 u=np.array([math.sin(angle),0,math.cos(angle)]);t=np.array([math.cos(angle),0,-math.sin(angle)]);base=np.column_stack([-u,np.array([0,1,0]),t]);c,s=math.cos(roll),math.sin(roll);return base@np.array([[c,-s,0],[s,c,0],[0,0,1]])
masters=json.loads((S/'available-masters.json').read_text());reg=[];rows=[];allproof=[]
for e0 in json.loads(old_manifest.read_text()):
 sku=e0['sku'];oldm=json.loads(Path(e0['model_path']).read_text());oldglb_doc,oldglb_bin=L.read_glb(e0['glb_path']);assert sha(e0['glb_path'])==e0['sha256'];asset=R/sku;asset.mkdir();ims=[]
 for x in masters[sku]:
  assert sha(x['path'])==x['sha256'];d=R/'originals'/Path(x['path']).name;clone(x['path'],d);m=dict(x,original_path=x['path'],path=str(d));reg.append(m);ims.append(m)
 for ma in oldm['materials'].values():
  for k in ['baseColorTexture','normalTexture','metallicRoughnessTexture']:
   if k in ma:clone(Path(e0['model_path']).parent/ma[k],asset/ma[k])
 meshes=copy.deepcopy(oldm['meshes']);base=np.asarray(meshes[0]['positions']).reshape(-1,3);old_shift=np.array([(base[:,0].min()+base[:,0].max())/2,0,(base[:,2].min()+base[:,2].max())/2]);checks=[];changed=[]
 anchors=oldm['metadata']['arm_anchor_and_contact_interpretation']
 for j,(idx,y,a)in enumerate(zip([4,10,16],[.275,.160,.205],anchors)):
  angle=math.radians(a['azimuth_degrees_estimated']);roll=math.radians(a['head_roll_degrees_estimated']);u=np.array([math.sin(angle),0,math.cos(angle)]);centre=u*a['radial_endpoint_m']+np.array([0,y+.003,0])+old_shift;rot=matrix(angle,roll)
  g=sheet('separate-own-rounded-rectangle-one-axis-curled-iron-sheet-'+str(j));g['_vertices']=[tuple(rot@np.asarray(p)+centre)for p in g['_vertices']];m,c=L._finalize(L.G.H.orient(g));meshes[idx]=m;checks.append(c);changed.append(idx)
  # The small source-visible fastener keeps its centre and contacting stud;
  # only its recessed cap profile is interpreted, not an invented drive type.
  g=L.B.lathe('separate-own-small-recessed-sheet-fastener-'+str(j),'paint',[(0,-.003),(.0030,-.003),(.0035,-.004),(.0035,-.0054),(.0032,-.006),(.0012,-.006),(.0012,-.0045),(0,-.0045)],96,False);g['_vertices']=[tuple(rot@np.asarray(p)+centre)for p in g['_vertices']];m,c=L._finalize(L.G.H.orient(g));meshes[idx+2]=m;checks.append(c);changed.append(idx+2)
 L.G.M.ensure_uv_faces(meshes);L.G.H.ensure_float32_uv(meshes)
 pos=np.concatenate([np.asarray(m['positions']).reshape(-1,3)for m in meshes]);lo=pos.min(0);hi=pos.max(0);delta=np.array([(lo[0]+hi[0])/2,lo[1],(lo[2]+hi[2])/2])
 for m in meshes:m['positions']=(np.asarray(m['positions']).reshape(-1,3)-delta).round(9).reshape(-1).tolist()
 pos=np.concatenate([np.asarray(m['positions']).reshape(-1,3)for m in meshes]);lo=pos.min(0);hi=pos.max(0);dims=((hi-lo)*100).tolist();assert abs(dims[1]-45)<1e-5
 meta=copy.deepcopy(oldm['metadata']);ident='hm-'+sku+'-own-one-axis-curled-sheet-branch-r02';meta.update(id=ident,dimensions_cm=dims,source_dimensions_hwd_cm=[dims[1],dims[0],dims[2]],original_image=ims[0]['path'],original_images=[{k:x[k]for k in ['path','url','sha256']}for x in ims],unlit=False,quality_label='Tek yönde kıvrımlı metal levha · Fotoğraf yorumu',model_status='pending_root_visual_review',quality_pending=True)
 meta['scale_note']=meta['scale_note'].replace('yaprak biçimli başlığın 28/22 cm yerel zarfı','yuvarlatılmış dikdörtgen metal levhanın 28/22 cm yerel zarfı').replace('sonlu açık cupped metal yapraklar','sonlu, tek yönde kıvrımlı açık metal levhalar')
 meta['scale_note']+=' R02, her exact SKU’nun kendi üç fotoğrafı ve yakın planına göre başlığı iki yönde çukur kâseden tek yönde kıvrılan yuvarlatılmış dikdörtgen levhaya dönüştürür. 1 mm et kalınlığı, yaklaşık 17,125 cm enine eğrilik yarıçapı, 4 cm kıvrım yüksekliği ve küçük vidanın girinti profili fotoğraf yorumudur. Levhanın uzun ekseni boyunca çukur kâse eğriliği yoktur; kesit yalnız enine kıvrılır. Kol merkez çizgileri, başlıkların mevcut bağlantı merkezleri, boş E14 duylar, 45 cm toplam yükseklik ve 2 m kablo aynıdır. Tek ortak XZ merkezleme ötelemesi uygulanır; tüm ürüne ölçekleme yapılmaz.'
 meta['estimated_fields']=sorted(set(meta['estimated_fields']+['one_axis_curled_sheet_profile_corner_radius_and_fastener_recess']))
 meta['photographed_features']=['Three own curved iron arms and rounded rectangular sheets curled about one axis','Finite 1mm painted metal, rounded corners, separate small recessed fastener caps','Source45cm approximate total height and61.5cm arm boundary interpretation preserved','Empty E14 holders×3, full200cm cord and hollow canopy unchanged']
 meta['geometry_limitations']=meta['estimated_fields'];meta['sheet_profile_interpretation']=dict(rounded_rectangle_projected_xz_m=[.28,.22],corner_radius_m=.075,transverse_radius_m=.17125,transverse_edge_sag_m=.04,nominal_sheet_thickness_m=.001,radial_axis_second_derivative_zero=True,all_local_values_photo_estimated=True,old_radial_bowl_removed=True)
 model=dict(metadata=meta,materials=copy.deepcopy(oldm['materials']),meshes=meshes,gltf_material_extensions={x['name']:x.get('extensions',{})for x in oldglb_doc['materials']});dump(asset/'model.json',model);dump(asset/'geometry-validation.json',dict(valid=True,new_mesh_checks=checks,changed_mesh_indices=changed,all_other_hardware_same_shape_with_common_translation=delta.tolist(),height45cm_preserved=True,whole_object_affine_scale=False,one_axis_sheet_profile=meta['sheet_profile_interpretation']))
 maps=[dict(path=str(x),sha256=sha(x),preserved_from=str(Path(e0['model_path']).parent/x.name))for x in asset.glob('*.png')];dump(asset/'material-validation.json',dict(valid=True,maps=maps,all_R01_map_bytes_preserved=True,all_R01_material_JSON_preserved=True,no_baked_reflections=True,unlit=False))
 report=L.export_assets(asset/'model.json',asset,ident);glb=asset/(ident+'.glb');doc,binary=L.read_glb(glb);binary=L.G.M.embed_tangents(doc,binary);om={x['name']:x for x in oldglb_doc['materials']}
 for ma in doc['materials']:
  if 'extensions'in om[ma['name']]:ma['extensions']=copy.deepcopy(om[ma['name']]['extensions'])
 doc['extensionsUsed']=sorted(set(doc.get('extensionsUsed',[]))|set(oldglb_doc.get('extensionsUsed',[])));L.write_glb(glb,doc,binary);e=dict(meta,asset_dir=str(asset),model_path=str(asset/'model.json'),glb_path=str(glb),sha256=sha(glb),bytes=glb.stat().st_size,geometry_validation=str(asset/'geometry-validation.json'),material_validation=str(asset/'material-validation.json'),size_source_kind=e0['size_source_kind'],size_source_urls=e0['size_source_urls']);dump(asset/'entry.json',e);rows.append(e)
 unchanged=[]
 for i,(old,new)in enumerate(zip(oldm['meshes'],meshes)):
  if i in changed:continue
  assert old['indices']==new['indices']and old['normals']==new['normals']and old['uvs']==new['uvs'];assert np.max(np.abs(np.asarray(old['positions']).reshape(-1,3)-delta-np.asarray(new['positions']).reshape(-1,3)))<1e-8;unchanged.append(i)
 assert model['materials']==oldm['materials'];assert sha(e0['glb_path'])==e0['sha256'];allproof.append(dict(sku=sku,old_glb=e0['glb_path'],old_sha256=e0['sha256'],old_frozen_unchanged=True,changed_mesh_indices=changed,unchanged_shape_mesh_indices=unchanged,unchanged_normals_UV_indices=True,common_translation_only_m=delta.tolist(),all_material_JSON_and_PNG_bytes_equal_R01=True,source_masters=ims,official_total_height_m=.45,full_cord_m=meta['measured_cord_length_m'],no_global_scale=True))
 print('BUILT',sku,e['sha256'],dims,flush=True)
dump(R/'manifest.json',rows);dump(R/'original-image-masters.json',reg);dump(R/'narrow-revision-preservation-proof.json',allproof)
