from pathlib import Path
import json,math,struct,numpy as np
A=Path(__file__).resolve().parent;root=A.parents[1];rows=json.loads((A.parent/'frozen-own-one-axis-branch-two-r02-manifest.json').read_text());base=json.loads((A/'camera-fit-readonly-report.json').read_text());out=[]
for e,rec in zip(rows,base['models']):
 raw=Path(e['glb_path']).read_bytes();jl=struct.unpack_from('<I',raw,12)[0];doc=json.loads(raw[20:20+jl]);binary=raw[28+jl:]
 def attr(index):
  a=doc['accessors'][index];v=doc['bufferViews'][a['bufferView']];dt=np.dtype({5126:'<f4',5125:'<u4',5123:'<u2'}[a['componentType']]);n={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}[a['type']];return np.ndarray((a['count'],n),dtype=dt,buffer=binary,offset=v.get('byteOffset',0)+a.get('byteOffset',0),strides=(v.get('byteStride',n*dt.itemsize),dt.itemsize)).astype(float)
 pts=[]
 for idx in [6,12,18,21,0]:
  pr=doc['meshes'][idx]['primitives'][0];p=attr(pr['attributes']['POSITION']);pts.append((p.min(0)+p.max(0))/2)
 pts=np.array(pts);target=np.vstack([rec['manual_fastener_points_px'],[rec['source_silhouette_centroids_px'][k]for k in ['canopy','hub']]])
 def objective(x):
  yaw=(x[0]+math.pi)%(2*math.pi)-math.pi;pitch=float(np.clip(x[1],-.7,.7));dist=float(np.clip(math.exp(x[2]),.65,50));sy,cy,sp,cp=math.sin(yaw),math.cos(yaw),math.sin(pitch),math.cos(pitch);right=np.array([cy,0,-sy]);up=np.array([-sy*sp,cp,-cy*sp]);di=np.array([sy*cp,sp,cy*cp]);rel=pts-np.array([0,.225,0]);dep=rel@di
  if np.any(dist-dep<.15):return 1e12,None
  q=np.c_[rel@right,-rel@up]/(1-dep/dist)[:,None];qm=q.mean(0);tm=target.mean(0);sc=float(((q-qm)*(target-tm)).sum()/((q-qm)**2).sum())
  if sc<100:return 1e12,None
  tr=tm-sc*qm;pred=sc*q+tr;err=pred-target;cost=float((err*err).sum());return cost,dict(yaw_rad=float(yaw),pitch_rad=pitch,distance_m=dist,pixels_per_metre_at_target_depth=sc,translation_px=tr.tolist(),rms_px=math.sqrt(cost/5),residual_xy_px=err.tolist(),landmark_3D_points_metres=pts.tolist(),projection='Perspective sensitivity check using exact fastener centres and canopy/hub bounding centres; target atGLBbboxcentre. No rigid body or geometry changes.')
 fits=[]
 b=rec['fits']['fasteners']
 for dd in [.8,1.2,2,5,15,40]:
  seed=np.array([b['yaw_rad'],b['pitch_rad'],math.log(dd)]);sim=[seed,seed+np.array([.07,0,0]),seed+np.array([0,.05,0]),seed+np.array([0,0,.2])];vals=[objective(x)[0]for x in sim]
  for it in range(260):
   order=np.argsort(vals);sim=[sim[i]for i in order];vals=[vals[i]for i in order]
   if np.max(np.abs(sim[-1]-sim[0]))<1e-8:break
   mid=np.mean(sim[:-1],axis=0);refl=mid+mid-sim[-1];vr=objective(refl)[0]
   if vr<vals[0]:
    ex=mid+2*(refl-mid);ve=objective(ex)[0];sim[-1],vals[-1]=(ex,ve)if ve<vr else(refl,vr)
   elif vr<vals[-2]:sim[-1],vals[-1]=refl,vr
   else:
    co=mid+.5*((refl if vr<vals[-1]else sim[-1])-mid);vc=objective(co)[0]
    if vc<min(vr,vals[-1]):sim[-1],vals[-1]=co,vc
    else:
     for j in range(1,4):sim[j]=sim[0]+.5*(sim[j]-sim[0]);vals[j]=objective(sim[j])[0]
  idx=int(np.argmin(vals));fits.append(objective(sim[idx]))
 cost,result=min(fits,key=lambda x:x[0]);result['sku']=e['sku'];out.append(result);print(e['sku'],result['yaw_rad'],result['pitch_rad'],result['distance_m'],result['rms_px'],flush=True)
(A/'perspective-sensitivity-readonly.json').write_text(json.dumps(dict(status='diagnostic_not_pose_or_geometry_proof',models=out),ensure_ascii=False,indent=2)+'\n')
