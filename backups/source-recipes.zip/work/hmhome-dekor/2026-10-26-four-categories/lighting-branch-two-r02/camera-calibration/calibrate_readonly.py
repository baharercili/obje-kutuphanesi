"""Read-only GLB/source camera calibration; no asset or site mutation."""
from pathlib import Path
import json,struct,hashlib,math
import numpy as np
from PIL import Image,ImageDraw

P=Path('/Users/USER/Documents/ChatGPT/Studio/work/hmhome-dekor/2026-10-26-four-categories');A=Path(__file__).resolve().parent
rows=json.loads((P/'lighting-branch-two-r02/frozen-own-one-axis-branch-two-r02-manifest.json').read_text());reports=[]
rois={
 '1253907001':{'upper_head':[300,855,630,1050],'left_head':[135,1030,420,1165],'right_head':[1105,980,1440,1135],'canopy':[630,765,855,918],'hub':[695,1255,795,1405]},
 '1253907003':{'upper_head':[265,935,635,1127],'left_head':[135,1120,435,1258],'right_head':[1100,1130,1400,1265],'canopy':[650,800,900,972],'hub':[725,1320,825,1475]}}
# Small cap points are manual digitisation of visible own primary fastener faces.
# They are independent of the broad surface-centroid segmentation.
bolts={'1253907001':[[485,1027],[346,1156],[1208,1118]],'1253907003':[[514,1114],[372,1241],[1190,1243]]}
names=['upper_head','left_head','right_head','canopy','hub']
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for e in rows:
 sku=e['sku'];assert sha(e['glb_path'])==e['sha256'];assert sha(e['original_image'])==e['original_image_sha256'];im=Image.open(e['original_image']).convert('RGB');rgb=np.asarray(im);measure=[];masks={};areas=[]
 for name in names:
  x0,y0,x1,y1=rois[sku][name];patch=rgb[y0:y1,x0:x1];threshold=190 if sku.endswith('001')else 245;mask=patch.mean(2)<threshold
  yy,xx=np.where(mask);cent=[float(xx.mean()+x0),float(yy.mean()+y0)];measure.append(cent);areas.append(len(xx));masks[name]=mask
 source=np.array(measure)
 raw=Path(e['glb_path']).read_bytes();jl=struct.unpack_from('<I',raw,12)[0];d=json.loads(raw[20:20+jl]);binary=raw[28+jl:]
 def attr(index):
  a=d['accessors'][index];v=d['bufferViews'][a['bufferView']];dt=np.dtype({5126:'<f4',5125:'<u4',5123:'<u2'}[a['componentType']]);n={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}[a['type']];return np.ndarray((a['count'],n),dtype=dt,buffer=binary,offset=v.get('byteOffset',0)+a.get('byteOffset',0),strides=(v.get('byteStride',n*dt.itemsize),dt.itemsize)).astype(float)
 components=[];geom=[]
 for idx in [4,10,16,21,0]:
  pr=d['meshes'][idx]['primitives'][0];p=attr(pr['attributes']['POSITION']);f=attr(pr['indices']).astype(int).reshape(-1,3);tri=p[f];cross=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]);cent=tri.mean(1);mag=np.linalg.norm(cross,axis=1);keys=np.round(cross/np.maximum(mag[:,None],1e-30),3);_,iv=np.unique(keys,axis=0,return_inverse=True);ng=iv.max()+1;cn=np.zeros((ng,3));mom=np.zeros((ng,3,3));np.add.at(cn,iv,cross)
  for ii in range(3):
   for jj in range(3):np.add.at(mom[:,ii,jj],iv,cent[:,ii]*cross[:,jj])
  components.append((cn,mom));geom.append((p,f))
 fasteners=[]
 for idx in [6,12,18]:
  pr=d['meshes'][idx]['primitives'][0];p=attr(pr['attributes']['POSITION']);fasteners.append((p.min(0)+p.max(0))/2)
 fasteners=np.array(fasteners)
 def basis(yaw,pitch):
  sy,cy,sp,cp=math.sin(yaw),math.cos(yaw),math.sin(pitch),math.cos(pitch)
  return np.array([cy,0,-sy]),np.array([-sy*sp,cp,-cy*sp]),np.array([sy*cp,sp,cy*cp])
 def geometry_centres(yaw,pitch):
  right,up,di=basis(yaw,pitch);centres=[]
  for cn,mom in components:
   dots=cn@di;weighted=np.einsum('nij,j->ni',mom,di);centres.append((np.sign(dots)[:,None]*weighted).sum(0)/np.abs(dots).sum())
  return np.array(centres)
 def screen(params,mode):
  yaw,pitch,logscale,tx,ty=params;sc=math.exp(logscale);right,up,di=basis(yaw,pitch);c=geometry_centres(yaw,pitch)
  if mode=='fasteners':c[:3]=fasteners
  return np.c_[c@right*sc+tx,-c@up*sc+ty]
 results={}
 for mode,target in [('silhouette_centroids',source),('fasteners',np.vstack([bolts[sku],source[3:]]))]:
  def evaluate(x):
   yaw=float((x[0]+math.pi)%(2*math.pi)-math.pi);pitch=float(np.clip(x[1],-.7,.7));rr,uu,_=basis(yaw,pitch);cen=geometry_centres(yaw,pitch)
   if mode=='fasteners':cen[:3]=fasteners
   q=np.c_[cen@rr,-cen@uu];qm=q.mean(0);tm=target.mean(0);sc=float(((q-qm)*(target-tm)).sum()/((q-qm)**2).sum())
   if sc<=100:return 1e12,None
   trans=tm-sc*qm;pred=sc*q+trans;cost=float(((pred-target)**2).sum());return cost,np.array([yaw,pitch,math.log(sc),trans[0],trans[1]])
  coarse=[]
  for ya in np.linspace(-math.pi,math.pi,36,endpoint=False):
   for pi in np.linspace(-.6,.6,9):coarse.append((evaluate([ya,pi])[0],np.array([ya,pi])))
  seeds=[x[1]for x in sorted(coarse,key=lambda x:x[0])[:3]];fits=[]
  for seed in seeds:
   sim=[seed,seed+np.array([.07,0]),seed+np.array([0,.04])];vals=[evaluate(x)[0]for x in sim]
   for it in range(180):
    order=np.argsort(vals);sim=[sim[i]for i in order];vals=[vals[i]for i in order]
    if np.max(np.abs(sim[2]-sim[0]))<1e-8:break
    mid=(sim[0]+sim[1])/2;refl=mid+(mid-sim[2]);vr=evaluate(refl)[0]
    if vr<vals[0]:
     ex=mid+2*(refl-mid);ve=evaluate(ex)[0];sim[2],vals[2]=(ex,ve)if ve<vr else(refl,vr)
    elif vr<vals[1]:sim[2],vals[2]=refl,vr
    else:
     co=mid+.5*((refl if vr<vals[2]else sim[2])-mid);vc=evaluate(co)[0]
     if vc<min(vr,vals[2]):sim[2],vals[2]=co,vc
     else:
      sim[1]=sim[0]+.5*(sim[1]-sim[0]);sim[2]=sim[0]+.5*(sim[2]-sim[0]);vals[1]=evaluate(sim[1])[0];vals[2]=evaluate(sim[2])[0]
   best=int(np.argmin(vals));cost,pars=evaluate(sim[best]);fits.append((cost,pars))
  cost,pars=min(fits,key=lambda x:x[0]);pred=screen(pars,mode);err=pred-target;sc=math.exp(pars[2]);results[mode]=dict(yaw_rad=float(pars[0]),pitch_rad=float(pars[1]),yaw_deg=float(math.degrees(pars[0])),pitch_deg=float(math.degrees(pars[1])),pixels_per_metre=sc,translation_xy_px=pars[3:].tolist(),residual_xy_px=err.tolist(),point_residual_norm_px=np.linalg.norm(err,axis=1).tolist(),rms_point_error_px=float(np.sqrt(np.mean(np.sum(err*err,axis=1)))),rms_point_error_equivalent_cm=float(np.sqrt(np.mean(np.sum(err*err,axis=1)))/sc*100),target_pixels=target.tolist(),predicted_pixels=pred.tolist())
 # A final exact projected polygon-union silhouette centroid at the fitted camera.
 fit=results['silhouette_centroids'];yaw=fit['yaw_rad'];pitch=fit['pitch_rad'];sc=fit['pixels_per_metre'];tx,ty=fit['translation_xy_px'];right,up,di=basis(yaw,pitch);raster=[]
 annotated=im.copy();draw=ImageDraw.Draw(annotated)
 colours=[(210,50,35),(40,135,60),(40,90,210),(175,90,190),(225,135,20)]
 for j,((p,f),name,col)in enumerate(zip(geom,names,colours)):
  xy=np.c_[p@right*sc+tx,-p@up*sc+ty];maskim=Image.new('1',im.size);md=ImageDraw.Draw(maskim)
  for face in f:md.polygon([tuple(x)for x in xy[face]],fill=1)
  mask=np.asarray(maskim);yy,xx=np.where(mask);cen=np.array([xx.mean(),yy.mean()]);raster.append(cen.tolist());roi=rois[sku][name];draw.rectangle(roi,outline=col,width=2);sx,sy=source[j];px,py=cen;draw.line((sx-8,sy,sx+8,sy),fill=col,width=3);draw.line((sx,sy-8,sx,sy+8),fill=col,width=3);draw.ellipse((px-7,py-7,px+7,py+7),outline=col,width=3);draw.line((sx,sy,px,py),fill=col,width=2);draw.text((roi[0]+3,roi[1]+3),name+' source+ / GLB o',fill=col)
 fit['final_polygon_union_centroids_px']=raster;er=np.array(raster)-source;fit['final_polygon_union_residual_xy_px']=er.tolist();fit['final_polygon_union_rms_px']=float(np.sqrt(np.mean(np.sum(er*er,axis=1))))
 # Camera 0 is included to make the left-two/right-one ordering explicit.
 zero=geometry_centres(0,0);r0,u0,d0=basis(0,0);order=sorted(range(3),key=lambda i:zero[i]@r0)
 annotated.save(A/(sku+'-own-primary-camera-centroid-proof.png'))
 report=dict(sku=sku,GLB=e['glb_path'],GLB_sha256=e['sha256'],original_image=e['original_image'],original_image_sha256=e['original_image_sha256'],source_pixels=list(im.size),source_mask_roi=rois[sku],source_threshold=190 if sku.endswith('001')else 245,manual_fastener_points_px=bolts[sku],manual_point_uncertainty_px=3 if sku.endswith('001')else 5,source_silhouette_centroids_px=dict(zip(names,source.tolist())),source_mask_areas_pixels=dict(zip(names,areas)),GLB_centre_method='Projected triangle area weighted centroids; final exact projected polygon union raster provided as check. Head meshes4/10/16, canopy21, hub0. Fastener cap centres6/12/18 independent fit.',camera_convention='Camera direction=[sin(yaw)cos(pitch),sin(pitch),cos(yaw)cos(pitch)]. Screen right=[cos(yaw),0,-sin(yaw)], world Y up, no roll or object transform. Orthographic scale and 2D framing free.',fits=results,yaw0_pitch0_head_left_to_right_mesh_indices=[[4,10,16][i]for i in order],source_annotation_is_QA_derivative_only=True,no_GLB_model_UI_canonical_changes=True)
 reports.append(report);print(sku,json.dumps({k:{p:v[p]for p in ['yaw_rad','pitch_rad','rms_point_error_px','rms_point_error_equivalent_cm']}for k,v in results.items()}),flush=True)
(A/'camera-fit-readonly-report.json').write_text(json.dumps(dict(status='diagnostic_camera_fit_not_model_approval',models=reports),ensure_ascii=False,indent=2)+'\n')
