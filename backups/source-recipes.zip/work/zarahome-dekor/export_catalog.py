#!/usr/bin/env python3
"""Extend the shared-geometry exporter with native glTF glass and clearcoat.

API: export_assets(model_path, output_dir, name) -> validation report.
The approved exporter is imported without modification. All core geometry and
embedded texture bytes from its BIN chunk are preserved byte for byte; optional
physical-material textures are appended. OBJ geometry remains unchanged, with
an approximate d/Tf/Ni/illum glass material for compatible OBJ importers.

Physical source fields: transmission [0,1], ior >=1, thickness >=0 (metres),
attenuationColor RGB [0,1], attenuationDistance >0 (metres), clearcoat [0,1],
clearcoatRoughness [0,1]. PNG/JPEG physical texture paths are relative to the
output directory, just like the standard material textures. Native KHR factor
dictionaries are also accepted through materials.*.extensions.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import struct

_BASE_SPEC = importlib.util.spec_from_file_location('_studio_base_exporter', Path(__file__).with_name('export_assets.py'))
_BASE = importlib.util.module_from_spec(_BASE_SPEC)
_BASE_SPEC.loader.exec_module(_BASE)

PHYSICAL_TEXTURES = {
    'transmissionTexture': ('KHR_materials_transmission', 'transmissionTexture'),
    'thicknessTexture': ('KHR_materials_volume', 'thicknessTexture'),
    'clearcoatTexture': ('KHR_materials_clearcoat', 'clearcoatTexture'),
    'clearcoatRoughnessTexture': ('KHR_materials_clearcoat', 'clearcoatRoughnessTexture'),
    'clearcoatNormalTexture': ('KHR_materials_clearcoat', 'clearcoatNormalTexture'),
}


def read_glb(path):
    data = Path(path).read_bytes()
    if len(data) < 28 or struct.unpack_from('<4sII', data) != (b'glTF', 2, len(data)):
        raise ValueError('Invalid GLB header')
    json_length, json_type = struct.unpack_from('<I4s', data, 12)
    if json_type != b'JSON':
        raise ValueError('GLB JSON chunk missing')
    document = json.loads(data[20:20 + json_length])
    bin_length, bin_type = struct.unpack_from('<I4s', data, 20 + json_length)
    binary = data[28 + json_length:]
    if bin_type != b'BIN\0' or len(binary) != bin_length:
        raise ValueError('Invalid GLB BIN chunk')
    return document, binary


def write_glb(path, document, binary):
    json_data = json.dumps(document, ensure_ascii=False, separators=(',', ':'), allow_nan=False).encode('utf-8')
    json_data += b' ' * (-len(json_data) % 4)
    binary = bytes(binary) + b'\0' * (-len(binary) % 4)
    size = 12 + 8 + len(json_data) + 8 + len(binary)
    Path(path).write_bytes(struct.pack('<4sII', b'glTF', 2, size) +
                           struct.pack('<I4s', len(json_data), b'JSON') + json_data +
                           struct.pack('<I4s', len(binary), b'BIN\0') + binary)


def _rgb(value, label):
    if not isinstance(value, list) or len(value) != 3:
        raise ValueError(f'{label}: expected three RGB values')
    return [_BASE._number(component, label, 0, 1) for component in value]


def _physical(material_name, raw, output_dir):
    if not isinstance(raw, dict):
        raise ValueError(f'{material_name}: material must be an object')
    extensions = raw.get('extensions', {})
    if not isinstance(extensions, dict):
        raise ValueError(f'{material_name}.extensions: expected an object')
    for extension in ('KHR_materials_transmission', 'KHR_materials_ior', 'KHR_materials_volume', 'KHR_materials_clearcoat'):
        if extension in extensions and not isinstance(extensions[extension], dict):
            raise ValueError(f'{material_name}.{extension}: expected an object')
    tr = extensions.get('KHR_materials_transmission', {})
    volume = extensions.get('KHR_materials_volume', {})
    coat = extensions.get('KHR_materials_clearcoat', {})
    transmission = _BASE._number(raw.get('transmission', tr.get('transmissionFactor', 0)),
                                 f'{material_name}.transmission', 0, 1)
    ior = _BASE._number(raw.get('ior', extensions.get('KHR_materials_ior', {}).get('ior', 1.5)),
                       f'{material_name}.ior', 1)
    thickness = _BASE._number(raw.get('thickness', volume.get('thicknessFactor', 0)),
                             f'{material_name}.thickness', 0)
    attenuation = _rgb(raw.get('attenuationColor', volume.get('attenuationColor', [1, 1, 1])),
                       f'{material_name}.attenuationColor')
    distance = raw.get('attenuationDistance', volume.get('attenuationDistance'))
    if distance is not None:
        distance = _BASE._number(distance, f'{material_name}.attenuationDistance', 0)
        if distance == 0:
            raise ValueError(f'{material_name}.attenuationDistance: expected a positive value')
    clearcoat = _BASE._number(raw.get('clearcoat', coat.get('clearcoatFactor', 0)),
                             f'{material_name}.clearcoat', 0, 1)
    coat_roughness = _BASE._number(raw.get('clearcoatRoughness', coat.get('clearcoatRoughnessFactor', 0)),
                                  f'{material_name}.clearcoatRoughness', 0, 1)
    coat_normal_scale = _BASE._number(raw.get('clearcoatNormalScale', 1),
                                     f'{material_name}.clearcoatNormalScale', 0)
    result = {}
    textures = {}
    for field, (extension, extension_field) in PHYSICAL_TEXTURES.items():
        relative = raw.get(field, extensions.get(extension, {}).get(extension_field))
        if relative is None:
            continue
        if not isinstance(relative, str) or not relative or Path(relative).is_absolute():
            raise ValueError(f'{material_name}.{field}: expected a relative texture file path')
        path = (output_dir / relative).resolve()
        try:
            path.relative_to(output_dir)
        except ValueError as error:
            raise ValueError(f'{material_name}.{field}: texture must be inside output-dir') from error
        data = path.read_bytes()
        mime, extension_suffix = _BASE._texture(data, str(path))
        digest = hashlib.sha256(data).hexdigest()
        textures[field] = dict(data=data, mimeType=mime, sha256=digest, source=str(path),
                               relative=f'textures/{digest[:24]}{extension_suffix}')
    if transmission > 0 or 'transmission' in raw or tr or 'transmissionTexture' in textures:
        result['KHR_materials_transmission'] = dict(transmissionFactor=transmission)
    if transmission > 0 or 'ior' in raw or 'KHR_materials_ior' in extensions:
        result['KHR_materials_ior'] = dict(ior=ior)
    if thickness > 0 or any(field in raw for field in ('thickness', 'attenuationColor', 'attenuationDistance')) or volume or 'thicknessTexture' in textures:
        result['KHR_materials_volume'] = dict(thicknessFactor=thickness, attenuationColor=attenuation)
        result.setdefault('KHR_materials_transmission', dict(transmissionFactor=transmission))
        if distance is not None:
            result['KHR_materials_volume']['attenuationDistance'] = distance
    if clearcoat > 0 or any(field in raw for field in ('clearcoat', 'clearcoatRoughness')) or coat or any(key.startswith('clearcoat') for key in textures):
        result['KHR_materials_clearcoat'] = dict(clearcoatFactor=clearcoat,
                                                clearcoatRoughnessFactor=coat_roughness)
    if 'clearcoatNormalTexture' in textures and not raw.get('normalTexture'):
        raise ValueError(f'{material_name}.clearcoatNormalTexture: this shared-mesh schema requires a base normalTexture to define the tangent space')
    return dict(extensions=result, textures=textures, transmission=transmission,
                ior=ior, thickness=thickness, attenuationColor=attenuation,
                attenuationDistance=distance, clearcoat=clearcoat,
                clearcoatRoughness=coat_roughness, clearcoatNormalScale=coat_normal_scale,
                explicitAlphaMode='alphaMode' in raw)


def export_assets(model_path, output_dir, name):
    model_path, output_dir = Path(model_path).resolve(), Path(output_dir).resolve()
    source_bytes = model_path.read_bytes()
    source_hash = hashlib.sha256(source_bytes).hexdigest()
    source = json.loads(source_bytes)
    if not isinstance(source, dict) or not isinstance(source.get('materials'), dict) or not source['materials']:
        raise ValueError('materials must be a nonempty mapping')
    # Physical fields and texture paths are all checked before the base exporter
    # writes a deliverable. The base exporter validates the complete core schema.
    physical = {key: _physical(key, raw, output_dir) for key, raw in source['materials'].items()}
    report = _BASE.export_assets(model_path, output_dir, name)
    glb_path = Path(report['files']['glb'])
    document, original_binary = read_glb(glb_path)
    binary = bytearray(original_binary)
    texture_indices = {item['sha256']: index for index, item in enumerate(report['textures'])}
    physical_images = {}

    def add_texture(texture):
        digest = texture['sha256']
        if digest in texture_indices:
            return texture_indices[digest]
        binary.extend(b'\0' * (-len(binary) % 4))
        view = len(document['bufferViews'])
        document['bufferViews'].append(dict(buffer=0, byteOffset=len(binary), byteLength=len(texture['data'])))
        binary.extend(texture['data'])
        document.setdefault('samplers', [dict(magFilter=9729, minFilter=9987, wrapS=10497, wrapT=10497)])
        image = len(document.setdefault('images', []))
        document['images'].append(dict(bufferView=view, mimeType=texture['mimeType'], name=Path(texture['source']).name))
        index = len(document.setdefault('textures', []))
        document['textures'].append(dict(source=image, sampler=0))
        texture_indices[digest] = index
        physical_images[digest] = texture
        return index

    extension_names = set(document.get('extensionsUsed', []))
    for material in document['materials']:
        definition = physical[material['name']]
        extensions = dict(definition['extensions'])
        for field, texture in definition['textures'].items():
            extension, extension_field = PHYSICAL_TEXTURES[field]
            reference = dict(index=add_texture(texture), texCoord=0)
            if field == 'clearcoatNormalTexture':
                reference['scale'] = definition['clearcoatNormalScale']
            extensions.setdefault(extension, {})[extension_field] = reference
        if definition['transmission'] > 0 and not definition['explicitAlphaMode']:
            material['alphaMode'] = 'OPAQUE'
            material['pbrMetallicRoughness']['baseColorFactor'][3] = 1
        if extensions:
            material['extensions'] = extensions
            extension_names.update(extensions)
    if extension_names:
        document['extensionsUsed'] = sorted(extension_names)
    document['buffers'][0]['byteLength'] = len(binary)
    write_glb(glb_path, document, binary)
    for digest, texture in physical_images.items():
        target = output_dir / texture['relative']
        target.parent.mkdir(parents=True, exist_ok=True)
        if not target.exists() or target.read_bytes() != texture['data']:
            target.write_bytes(texture['data'])
        report['textures'].append(dict(file=texture['relative'], bytes=len(texture['data']), sha256=digest))

    names = {f'mat_{index + 1:02d}_{_BASE._safe_name(key)}': key
             for index, key in enumerate(source['materials'])}
    lines, current = [], None
    for line in Path(report['files']['mtl']).read_text(encoding='utf-8').splitlines():
        if line.startswith('newmtl '):
            current = names[line[7:]]
        item = physical.get(current)
        if item and item['transmission'] > 0:
            if line.startswith('d '):
                rgba = source['materials'][current].get('baseColorFactor', [1, 1, 1, 1])
                alpha = rgba[3] if item['explicitAlphaMode'] else 1
                line = f"d {max(0, min(1, (1 - item['transmission']) * alpha)):.9g}"
            elif line.startswith('illum '):
                line = 'illum 7'
        lines.append(line)
        if line.startswith('newmtl ') and item:
            if item['transmission'] > 0:
                tint = item['attenuationColor'] if 'KHR_materials_volume' in item['extensions'] else source['materials'][current].get('baseColorFactor', [1, 1, 1, 1])[:3]
                lines.extend([f"Ni {item['ior']:.9g}", 'Tf ' + ' '.join(f'{component:.9g}' for component in tint)])
            elif 'KHR_materials_ior' in item['extensions']:
                lines.append(f"Ni {item['ior']:.9g}")
            if 'KHR_materials_clearcoat' in item['extensions']:
                lines.extend([f"Pc {item['clearcoat']:.9g}", f"Pcr {item['clearcoatRoughness']:.9g}"])
    Path(report['files']['mtl']).write_text('\n'.join(lines) + '\n', encoding='utf-8')
    if hashlib.sha256(model_path.read_bytes()).hexdigest() != source_hash:
        raise RuntimeError('The source model changed during export')
    reopened, final_binary = read_glb(glb_path)
    if final_binary[:len(original_binary)] != original_binary:
        raise RuntimeError('Core geometry/texture BIN prefix changed')
    report.update(glb_bytes=glb_path.stat().st_size, texture_count=len(reopened.get('textures', [])),
                  source_sha256=source_hash, extensions_used=reopened.get('extensionsUsed', []),
                  physical_materials={key: {field: value for field, value in values.items() if field not in ('textures',)}
                                      for key, values in physical.items()},
                  material_note='GLB contains native glTF PBR glass/volume/IOR/clearcoat. OBJ glass is an approximate d/Tf/Ni/illum material.')
    report['validation'].update(physical_parameters_valid=True, source_model_unchanged=True,
                                core_binary_prefix_unchanged=True,
                                core_binary_prefix_sha256=hashlib.sha256(original_binary).hexdigest(),
                                physical_texture_bytes_appended=len(final_binary) - len(original_binary))
    report['deliverable_sha256'] = {key: hashlib.sha256(Path(value).read_bytes()).hexdigest()
                                    for key, value in report['files'].items() if key != 'validation'}
    Path(report['files']['validation']).write_text(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--model', required=True, type=Path)
    parser.add_argument('--output-dir', required=True, type=Path)
    parser.add_argument('--name', required=True)
    args = parser.parse_args()
    print(json.dumps(export_assets(args.model, args.output_dir, args.name), ensure_ascii=False, indent=2, allow_nan=False))
