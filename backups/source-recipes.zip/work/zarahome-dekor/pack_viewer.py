"""Pack the three vase masters into a small, self-contained material preview.

Run with the bundled Python runtime (Pillow is required):
  python3 work/zarahome-dekor/pack_viewer.py --standalone

The source meshes and PBR textures are read-only. All quantization and texture
reduction occurs in memory; the exportable full-resolution models stay intact.
"""
import argparse
import array
import base64
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import sys

from PIL import Image

ROOT = Path('/Users/USER/Documents/ChatGPT/Studio')
WORK = ROOT / 'work/zarahome-dekor'
FRAGMENT = Path('/Users/USER/.codex/visualizations/2026/10/20/01a159db-9681-7b91-933e-e9cc984d26f6/zarahome-vazolar.html')
STANDALONE = ROOT / 'output/zarahome-dekor/vazolar/vazolar-onizleme.html'
WRAPPER = Path('/Users/USER/.codex/plugins/cache/openai-bundled/visualize/1.0.50/skills/visualize/scripts/render.py')


def texture_uri(path, maximum, is_color):
    """Create an embedded viewer derivative, never modifying the master."""
    image = Image.open(path).convert('RGB')
    image.thumbnail((maximum, maximum), Image.Resampling.LANCZOS)
    stream = io.BytesIO()
    if is_color:
        image.save(stream, format='JPEG', quality=84, optimize=True, subsampling=0)
        mime = 'image/jpeg'
    else:
        image.save(stream, format='PNG', optimize=True)
        mime = 'image/png'
    return f'data:{mime};base64,' + base64.b64encode(stream.getvalue()).decode('ascii')


def pack(manifest_path, output):
    entries = json.loads(manifest_path.read_text(encoding='utf-8'))
    if isinstance(entries, dict):
        entries = entries.get('products', entries.get('models', []))
    if not entries:
        raise ValueError('The vase manifest is empty.')
    binary = bytearray()
    packed_models = []
    texture_data = []
    texture_cache = {}
    source_hashes = {}
    mesh_count = triangles = 0

    def write(values, typecode, scale=1, stride=1):
        while len(binary) % 4:
            binary.append(0)
        offset = len(binary)
        if scale != 1:
            values = [round(value * scale) for value in values]
        values = [value - (values[index - stride] if index >= stride else 0)
                  for index, value in enumerate(values)]
        if typecode == 'h':
            values = [((value + 32768) % 65536) - 32768 for value in values]
        elif typecode == 'H':
            values = [value % 65536 for value in values]
        elif typecode == 'I':
            values = [value % 4294967296 for value in values]
        data = array.array(typecode, values)
        if sys.byteorder != 'little':
            data.byteswap()
        binary.extend(data.tobytes())
        return [offset, len(data)]

    def texture_id(asset_dir, relative_path, color):
        if not relative_path:
            return None
        path = (asset_dir / relative_path).resolve()
        key = (str(path), color)
        if key not in texture_cache:
            if not path.is_file():
                raise FileNotFoundError(f'Material texture not found: {path}')
            texture_cache[key] = len(texture_data)
            texture_data.append(texture_uri(path, 256 if color else 128, color))
            source_hashes[str(path)] = hashlib.sha256(path.read_bytes()).hexdigest()
        return texture_cache[key]

    for entry in entries:
        model_path = Path(entry['model_path'])
        asset_dir = Path(entry['asset_dir'])
        source = json.loads(model_path.read_text(encoding='utf-8'))
        source_hashes[str(model_path)] = hashlib.sha256(model_path.read_bytes()).hexdigest()
        materials = {}
        for name, material in source.get('materials', entry.get('materials', {})).items():
            materials[name] = {
                'baseColorFactor': material.get('baseColorFactor', [1, 1, 1, 1]),
                'metallic': material.get('metallicFactor', material.get('metallic', 0)),
                'roughness': material.get('roughnessFactor', material.get('roughness', .5)),
                'normalScale': material.get('normalScale', .3),
                'doubleSided': material.get('doubleSided', False),
                'alphaMode': material.get('alphaMode', 'BLEND' if material.get('baseColorFactor', [1, 1, 1, 1])[3] < 1 else 'OPAQUE'),
                'alphaCutoff': material.get('alphaCutoff', .5),
                'baseColorTexture': texture_id(asset_dir, material.get('baseColorTexture'), True),
                'normalTexture': texture_id(asset_dir, material.get('normalTexture'), False),
                'metallicRoughnessTexture': texture_id(asset_dir, material.get('metallicRoughnessTexture'), False),
            }
        meshes = []
        for mesh in source['meshes']:
            index_type = 'u16' if max(mesh['indices'], default=0) < 65536 else 'u32'
            meshes.append({
                'name': mesh.get('name', entry['id']),
                'material': mesh['material'],
                'positions': write(mesh['positions'], 'i', 100000, 3),
                'normals': write([max(-1, min(1, value)) for value in mesh['normals']], 'h', 32767, 3),
                'uvs': write(mesh['uvs'], 'i', 100000, 2),
                'indices': write(mesh['indices'], 'H' if index_type == 'u16' else 'I'),
                'indexType': index_type,
            })
            mesh_count += 1
            triangles += len(mesh['indices']) // 3
        packed_models.append({key: entry[key] for key in ('id', 'name', 'sku', 'url', 'dimensions_cm')} | {
            'meshes': meshes,
            'materials': materials,
        })
    compressed = gzip.compress(binary, compresslevel=9, mtime=0)
    payload = {
        'encoding': 'component-delta-v1',
        'models': packed_models,
        'textures': texture_data,
        'data': base64.b64encode(compressed).decode('ascii'),
    }
    payload_json = json.dumps(payload, ensure_ascii=False, separators=(',', ':')).replace('</', '<\\/')
    html = (WORK / 'viewer-template.html').read_text(encoding='utf-8').replace('__PAYLOAD__', payload_json)
    size = len(html.encode('utf-8'))
    if size >= 1_000_000:
        raise ValueError(f'Fragment would exceed 1 MB: {size:,} bytes. No output written.')
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(html, encoding='utf-8')
    validation = {
        'manifest': str(manifest_path),
        'fragment': str(output),
        'fragment_bytes': size,
        'raw_binary_bytes': len(binary),
        'gzip_bytes': len(compressed),
        'models': len(packed_models),
        'meshes': mesh_count,
        'triangles': triangles,
        'textures': len(texture_data),
        'positions_max_axis_error_m': .000005,
        'same_topology': True,
        'encoding': 'component-delta-v1',
        'source_sha256': source_hashes,
    }
    (WORK / 'viewer-validation.json').write_text(json.dumps(validation, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(validation, ensure_ascii=False))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--manifest', type=Path, default=WORK / 'vazolar-manifest.json')
    parser.add_argument('--output', type=Path, default=FRAGMENT)
    parser.add_argument('--standalone', nargs='?', type=Path, const=STANDALONE)
    args = parser.parse_args()
    pack(args.manifest, args.output)
    if args.standalone:
        args.standalone.parent.mkdir(parents=True, exist_ok=True)
        subprocess.run([sys.executable, str(WRAPPER), str(args.output), str(args.standalone), '--force'], check=True)
