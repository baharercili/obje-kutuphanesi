"""Build size-bounded, selectable vase previews without changing model masters.

API: pack_catalog(manifest_path, output_dir, batch_size=8, max_bytes=262144).
CLI: python3 work/zarahome-dekor/pack_catalog.py --manifest manifest.json

Regular lathe grids are resampled only in the embedded preview. Their UV seam,
inner shell, lip and end caps remain explicit. Unrecognized topology is retained
and, if needed, placed in smaller batches. Every reduction is reported beside
the HTML. The full-resolution GLB/OBJ/JSON/texture files are read-only.
"""
from __future__ import annotations

import argparse
import array
import base64
import gzip
import hashlib
import io
import json
import math
from pathlib import Path
import re
import subprocess
import sys
import unicodedata
from urllib.parse import urlparse

import numpy as np
from PIL import Image

WORK = Path(__file__).resolve().parent
TEMPLATE = WORK / 'catalog-viewer-template.html'
WRAPPER = Path('/Users/USER/.codex/plugins/cache/openai-bundled/visualize/1.0.50/skills/visualize/scripts/render.py')
QUALITIES = [
    dict(columns=96, rows=64, positions=100000, normals=32767, uvs=100000, color=128, data=64),
    dict(columns=64, rows=48, positions=20000, normals=127, uvs=8192, color=128, data=64),
    dict(columns=48, rows=40, positions=20000, normals=127, uvs=4096, color=128, data=64),
    dict(columns=40, rows=32, positions=10000, normals=127, uvs=4096, color=64, data=64),
    dict(columns=32, rows=24, positions=10000, normals=127, uvs=4096, color=64, data=32),
]
MATERIAL_LABELS = {
    'glass': 'Cam', 'crystal': 'Kristal', 'metal': 'Metal', 'iron': 'Demir',
    'steel': 'Çelik', 'stainless steel': 'Paslanmaz çelik', 'ceramic': 'Seramik',
    'stoneware': 'Taş seramik', 'porcelain': 'Porselen', 'earthenware': 'Seramik',
    'terracotta': 'Terrakota', 'wood': 'Ahşap', 'bamboo': 'Bambu',
    'rattan': 'Rattan', 'papier mache': 'Kâğıt hamuru', 'resin': 'Reçine',
}


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def display_text(value):
    return unicodedata.normalize('NFC', value.replace('i\u0307', 'i').replace('I\u0307', 'İ')).replace('Tasarimli', 'Tasarımlı').replace('tasarimli', 'tasarımlı')


def preview_color_maximum(entry, source, quality):
    minimum = entry.get('preview_color_size', 128 if source.get('metadata', {}).get('family_code') == '47355046' else 0)
    if isinstance(minimum, bool) or not isinstance(minimum, int) or not 0 <= minimum <= 256:
        raise ValueError('preview_color_size must be an integer from 0 to 256')
    return max(quality['color'], minimum)


def source_provenance(entry, source):
    """Keep sourced versus estimated dimensions visible in every preview."""
    metadata = source.get('metadata', {})
    result = {}
    for key in ('estimated_dimensions', 'size_source_kind', 'source_market', 'size_source_urls'):
        result[key] = entry.get(key, metadata.get(key, False if key == 'estimated_dimensions' else [] if key == 'size_source_urls' else ''))
    result['estimated_dimensions'] = bool(result['estimated_dimensions'])
    if not result['size_source_kind'] and result['estimated_dimensions']:
        result['size_source_kind'] = 'photo_estimate'
    urls = result['size_source_urls']
    if isinstance(urls, str):
        urls = [urls]
    result['size_source_urls'] = [url for url in urls if isinstance(url, str)] if isinstance(urls, list) else []
    if not result['source_market'] and result['size_source_kind'] == 'official_cross_market':
        for url in result['size_source_urls']:
            parts = urlparse(url).path.strip('/').split('/')
            if parts and re.fullmatch(r'[a-zA-Z]{2}', parts[0]):
                result['source_market'] = parts[0].upper()
                break
    notes = []
    for key in ('source_notes', 'size_source_notes', 'scale_note'):
        value = entry.get(key, metadata.get(key))
        values = value if isinstance(value, list) else [value]
        for item in values:
            if isinstance(item, str) and item.strip() and item.strip() not in notes:
                notes.append(item.strip())
    result['source_notes'] = notes
    return result


def grid_indices(grid):
    """The same index reconstruction used in the browser."""
    rows, cols = grid['rows'], grid['columns']
    indices = []
    for row in range(rows - 1):
        for col in range(cols - 1):
            a = row * cols + col
            b = a + cols
            indices.extend([a, b + 1, b, a, a + 1, b + 1] if grid.get('reverse')
                           else [a, b, b + 1, a, b + 1, a + 1])
    for cap in grid.get('caps', []):
        for col in range(cols - 1):
            a = cap['row'] * cols + col
            indices.extend([cap['center'], a, a + 1] if cap['forward']
                           else [cap['center'], a + 1, a])
    return indices


def recognize_grid(mesh):
    """Recognize and verify a rectangular UV seam plus optional end-cap fans."""
    uv = np.asarray(mesh['uvs']).reshape(-1, 2)
    count = len(uv)
    columns = next((i for i in range(3, min(4096, count))
                    if abs(uv[i, 0] - uv[0, 0]) < 1e-7 and
                    abs(uv[i - 1, 0] - 1) < 1e-7), None)
    if not columns or abs(uv[0, 0]) > 1e-7:
        return None
    rows, extra = divmod(count, columns)
    if rows < 3 or extra > 4:
        return None
    grid_uv = uv[:rows * columns].reshape(rows, columns, 2)
    if not np.allclose(grid_uv[:, :, 0], np.linspace(0, 1, columns), atol=1e-6):
        return None
    if not np.allclose(grid_uv[:, :, 1], grid_uv[:, :1, 1], atol=1e-7):
        return None
    faces = np.asarray(mesh['indices']).reshape(-1, 3)
    surface_count = (rows - 1) * (columns - 1) * 2
    if len(faces) < surface_count:
        return None
    grid = dict(rows=rows, columns=columns, caps=[], vertexCount=count, reverse=False)
    reverse = faces[0].tolist() == [0, columns + 1, columns]
    grid['reverse'] = reverse
    if grid_indices(grid) != mesh['indices'][:surface_count * 3]:
        return None
    remainder = faces[surface_count:]
    for center in range(rows * columns, count):
        cap = remainder[np.any(remainder == center, axis=1)]
        if len(cap) != columns - 1:
            return None
        row_id, forward = None, None
        edges = set()
        for triangle in cap.tolist():
            at = triangle.index(center)
            a, b = triangle[(at + 1) % 3], triangle[(at + 2) % 3]
            row_a, row_b = a // columns, b // columns
            if row_a != row_b or row_a not in (0, rows - 1):
                return None
            direction = b - a == 1
            if abs(b - a) != 1 or row_id is not None and (row_id != row_a or forward != direction):
                return None
            row_id, forward = row_a, direction
            edges.add(min(a, b) % columns)
        if len(edges) != columns - 1:
            return None
        grid['caps'].append(dict(center=center, row=row_id, forward=forward))
    if len(remainder) != extra * (columns - 1):
        return None
    return grid


def profile_rows(positions, rows, columns, maximum):
    """Keep profile bends, lip extrema and the two ends when reducing rows."""
    if rows <= maximum:
        return list(range(rows))
    p = positions[:rows * columns].reshape(rows, columns, 3)
    center = p.mean(axis=1)
    radius = np.sqrt((p[:, :, 0] - center[:, 0, None]) ** 2 +
                     (p[:, :, 2] - center[:, 2, None]) ** 2).mean(axis=1)
    curve = np.stack([radius, center[:, 1]], axis=1)
    extent = max(float(np.ptp(curve, axis=0).max()), 1e-8)
    curve /= extent
    protected = {0, rows - 1, int(np.argmax(curve[:, 0])), int(np.argmax(curve[:, 1]))}
    selected = list(range(rows))
    while len(selected) > maximum:
        candidates = []
        for index in range(1, len(selected) - 1):
            row = selected[index]
            if row in protected:
                continue
            a, pnt, b = curve[selected[index - 1]], curve[row], curve[selected[index + 1]]
            segment = b - a
            t = np.clip(np.dot(pnt - a, segment) / max(np.dot(segment, segment), 1e-20), 0, 1)
            error = float(np.linalg.norm(pnt - a - t * segment))
            candidates.append((error, index))
        if not candidates:
            break
        selected.pop(min(candidates)[1])
    return selected


def preview_mesh(mesh, quality):
    grid = recognize_grid(mesh)
    original_vertices = len(mesh['positions']) // 3
    original_triangles = len(mesh['indices']) // 3
    if grid is None:
        return mesh, None, dict(sourceVertices=original_vertices,
                               previewVertices=original_vertices,
                               sourceTriangles=original_triangles,
                               previewTriangles=original_triangles,
                               topology='unchanged-unrecognized-grid')
    rows, columns = grid['rows'], grid['columns']
    angular_segments = min(columns - 1, quality['columns'])
    angles = sorted(set(round(i * (columns - 1) / angular_segments)
                        for i in range(angular_segments + 1)))
    positions = np.asarray(mesh['positions']).reshape(-1, 3)
    selected_rows = profile_rows(positions, rows, columns, quality['rows'])
    selected = [row * columns + angle for row in selected_rows for angle in angles]
    selected.extend(range(rows * columns, original_vertices))
    result = dict(name=mesh.get('name', 'vase'), material=mesh['material'])
    for name, components in [('positions', 3), ('normals', 3), ('uvs', 2)]:
        result[name] = np.asarray(mesh[name]).reshape(-1, components)[selected].reshape(-1).tolist()
    caps = [dict(center=len(selected_rows) * len(angles) + index,
                 row=0 if cap['row'] == 0 else len(selected_rows) - 1,
                 forward=cap['forward']) for index, cap in enumerate(grid['caps'])]
    small_grid = dict(rows=len(selected_rows), columns=len(angles), caps=caps,
                      vertexCount=len(selected), reverse=grid['reverse'])
    result['indices'] = grid_indices(small_grid)
    stats = dict(sourceVertices=original_vertices, previewVertices=len(selected),
                 sourceTriangles=original_triangles,
                 previewTriangles=len(result['indices']) // 3,
                 sourceGrid=[rows, columns], previewGrid=[len(selected_rows), len(angles)],
                 topology='preview-grid-resampled' if len(selected) != original_vertices else 'unchanged-grid',
                 seamAndCapsPreserved=True)
    return result, small_grid, stats


class CatalogPacker:
    def __init__(self):
        self.sources = {}
        self.source_hashes = {}
        self.texture_cache = {}
        self.template = TEMPLATE.read_text(encoding='utf-8')

    def source(self, path):
        path = str(Path(path).resolve())
        if path not in self.sources:
            raw = Path(path).read_bytes()
            self.source_hashes[path] = hashlib.sha256(raw).hexdigest()
            self.sources[path] = json.loads(raw)
        return self.sources[path]

    def texture(self, path, maximum, color):
        path = str(Path(path).resolve())
        key = (path, maximum, color)
        if key not in self.texture_cache:
            self.source_hashes[path] = sha256(path)
            image = Image.open(path).convert('RGB')
            image.thumbnail((maximum, maximum), Image.Resampling.LANCZOS)
            stream = io.BytesIO()
            if color:
                image.save(stream, format='JPEG', quality=80, subsampling=0, optimize=True)
                mime = 'image/jpeg'
            else:
                image.save(stream, format='PNG', optimize=True)
                mime = 'image/png'
            self.texture_cache[key] = f'data:{mime};base64,' + base64.b64encode(stream.getvalue()).decode('ascii')
        return self.texture_cache[key]

    def fragment(self, entries, quality_index, root_id):
        quality = QUALITIES[quality_index]
        color_maximum = quality['color']
        binary = bytearray()
        textures, texture_indices, models, mesh_stats = [], {}, [], []
        local_sources = set()

        def write(values, typecode, scale=1, stride=1):
            while len(binary) % 4:
                binary.append(0)
            offset = len(binary)
            if scale != 1:
                values = [round(value * scale) for value in values]
            values = [value - (values[index - stride] if index >= stride else 0)
                      for index, value in enumerate(values)]
            bits = {'b': 8, 'h': 16, 'H': 16, 'I': 32}.get(typecode)
            if bits:
                signed = typecode in ('b', 'h')
                shift = 2 ** (bits - 1) if signed else 0
                values = [((value + shift) % 2 ** bits) - shift for value in values]
            data = array.array(typecode, values)
            if sys.byteorder != 'little':
                data.byteswap()
            binary.extend(data.tobytes())
            return [offset, len(data)]

        def texture_index(asset_dir, relative, color=False):
            if not relative:
                return None
            path = str((asset_dir / relative).resolve())
            local_sources.add(path)
            uri = self.texture(path, color_maximum if color else quality['data'], color)
            digest = hashlib.sha256(uri.encode()).hexdigest()
            if digest not in texture_indices:
                texture_indices[digest] = len(textures)
                textures.append(uri)
            return texture_indices[digest]

        for entry in entries:
            source_path = str(Path(entry['model_path']).resolve())
            source = self.source(source_path)
            color_maximum = preview_color_maximum(entry, source, quality)
            mesh_quality = quality
            if 'preview_geometry_quality' in entry:
                geometry_quality = entry['preview_geometry_quality']
                if isinstance(geometry_quality, bool) or not isinstance(geometry_quality, int) or not 0 <= geometry_quality < len(QUALITIES):
                    raise ValueError('preview_geometry_quality must be a valid quality index')
                mesh_quality = quality | {key: QUALITIES[geometry_quality][key] for key in ('columns', 'rows')}
            local_sources.add(source_path)
            asset_dir = Path(entry['asset_dir'])
            materials = {}
            for name, raw in source.get('materials', entry.get('materials', {})).items():
                extensions = raw.get('extensions', {})
                transmission = extensions.get('KHR_materials_transmission', {})
                volume = extensions.get('KHR_materials_volume', {})
                clearcoat = extensions.get('KHR_materials_clearcoat', {})
                material = dict(
                    baseColorFactor=raw.get('baseColorFactor', [1, 1, 1, 1]),
                    metallic=raw.get('metallicFactor', raw.get('metallic', 0)),
                    roughness=raw.get('roughnessFactor', raw.get('roughness', .5)),
                    normalScale=raw.get('normalScale', .3),
                    doubleSided=raw.get('doubleSided', False),
                    alphaMode=raw.get('alphaMode', 'BLEND' if raw.get('baseColorFactor', [1, 1, 1, 1])[3] < 1 else 'OPAQUE'),
                    alphaCutoff=raw.get('alphaCutoff', .5),
                    transmission=raw.get('transmission', transmission.get('transmissionFactor', 0)),
                    ior=raw.get('ior', extensions.get('KHR_materials_ior', {}).get('ior', 1.5)),
                    thickness=raw.get('thickness', volume.get('thicknessFactor', 0)),
                    attenuationColor=raw.get('attenuationColor', volume.get('attenuationColor', [1, 1, 1])),
                    attenuationDistance=raw.get('attenuationDistance', volume.get('attenuationDistance')),
                    clearcoat=raw.get('clearcoat', clearcoat.get('clearcoatFactor', 0)),
                    clearcoatRoughness=raw.get('clearcoatRoughness', clearcoat.get('clearcoatRoughnessFactor', 0)),
                    clearcoatNormalScale=raw.get('clearcoatNormalScale', 1),
                )
                if material['transmission'] > 0 and 'alphaMode' not in raw:
                    material['alphaMode'] = 'OPAQUE'
                    material['baseColorFactor'] = [*material['baseColorFactor'][:3], 1]
                distance = material['attenuationDistance']
                if distance is not None and (not math.isfinite(distance) or distance <= 0):
                    material['attenuationDistance'] = None
                for field in ('baseColorTexture', 'normalTexture', 'metallicRoughnessTexture', 'transmissionTexture', 'thicknessTexture', 'clearcoatTexture', 'clearcoatRoughnessTexture', 'clearcoatNormalTexture'):
                    material[field] = texture_index(asset_dir, raw.get(field), field == 'baseColorTexture')
                materials[name] = material
            label = entry.get('material_label') or entry.get('materialLabel') or source.get('metadata', {}).get('material')
            if not isinstance(label, str):
                label = ('Cam' if any(material['transmission'] > 0 for material in materials.values()) else
                         'Metal' if any(material['metallic'] > .5 for material in materials.values()) else 'Seramik')
            label = MATERIAL_LABELS.get(label.lower().strip(), label)
            meshes = []
            preserve_meshes = entry.get('preview_preserve_meshes', [])
            if not isinstance(preserve_meshes, list) or any(not isinstance(name, str) for name in preserve_meshes):
                raise ValueError('preview_preserve_meshes must be a list of mesh names')
            if not set(preserve_meshes).issubset({mesh.get('name') for mesh in source['meshes']}):
                raise ValueError('preview_preserve_meshes contains an unknown mesh name')
            for original in source['meshes']:
                local_quality = mesh_quality
                if original.get('name') in preserve_meshes:
                    local_quality = mesh_quality | dict(columns=4096, rows=4096)
                mesh, grid, stats = preview_mesh(original, local_quality)
                stats.update(id=entry['id'], mesh=mesh.get('name', entry['id']))
                mesh_stats.append(stats)
                index_type = 'u16' if max(mesh['indices'], default=0) < 65536 else 'u32'
                packed = dict(name=mesh.get('name', entry['id']), material=mesh['material'],
                              positions=write(mesh['positions'], 'i', quality['positions'], 3),
                              normals=write([max(-1, min(1, value)) for value in mesh['normals']],
                                            'b' if quality['normals'] == 127 else 'h', quality['normals'], 3),
                              uvs=write(mesh['uvs'], 'i', quality['uvs'], 2),
                              indexType=index_type, triangles=len(mesh['indices']) // 3)
                if grid:
                    packed['grid'] = grid
                else:
                    packed['indices'] = write(mesh['indices'], 'H' if index_type == 'u16' else 'I')
                meshes.append(packed)
            models.append({key: entry[key] for key in ('id', 'sku', 'url', 'dimensions_cm')} |
                          dict(name=display_text(entry['name']),materials=materials, meshes=meshes, materialLabel=display_text(label),colorTextureSize=color_maximum) |
                          source_provenance(entry, source))
        compressed = gzip.compress(binary, compresslevel=9, mtime=0)
        payload = dict(encoding='component-delta-catalog-v1', batchId=root_id,
                       quality=quality_index, precision={key: quality[key] for key in ('positions', 'normals', 'uvs')},
                       models=models, textures=textures, data=base64.b64encode(compressed).decode('ascii'))
        payload_json = json.dumps(payload, ensure_ascii=False, separators=(',', ':'), allow_nan=False).replace('</', '<\\/')
        html = self.template.replace('__ROOT_ID__', root_id).replace('__PAYLOAD__', payload_json)
        report = dict(rootId=root_id, models=[entry['id'] for entry in entries],
                      fragmentBytes=len(html.encode('utf-8')), quality=quality,
                      qualityIndex=quality_index, rawBinaryBytes=len(binary), gzipBytes=len(compressed),
                      meshPreviews=mesh_stats, previewOnly=True, sourceMastersUnchanged=True,
                      textures=len(textures), sourceSha256={path: self.source_hashes[path] for path in sorted(local_sources)})
        return html, report


def pack_catalog(manifest_path, output_dir, batch_size=8, max_bytes=262144,
                 prefix='catalog-vazolar', standalone=False):
    manifest_path, output_dir = Path(manifest_path).resolve(), Path(output_dir).resolve()
    entries = json.loads(manifest_path.read_text(encoding='utf-8'))
    if isinstance(entries, dict):
        entries = entries.get('products', entries.get('models', []))
    if not entries:
        raise ValueError('Manifest has no products.')
    if len({entry['id'] for entry in entries}) != len(entries):
        raise ValueError('Manifest product IDs must be unique.')
    if batch_size < 1 or max_bytes < 20000:
        raise ValueError('Invalid batch size or byte limit.')
    prefix = re.sub(r'[^a-z0-9-]', '-', prefix.lower()).strip('-') or 'catalog-vazolar'
    packer, fitted = CatalogPacker(), []

    def fit(group):
        root_id = f'{prefix}-{len(fitted) + 1:02d}'
        for quality_index in range(len(QUALITIES)):
            html, report = packer.fragment(group, quality_index, root_id)
            if report['fragmentBytes'] <= max_bytes:
                fitted.append((html, report))
                return
        if len(group) == 1:
            raise ValueError(f"{group[0]['id']}: cannot fit a safe preview into {max_bytes} bytes; last size {report['fragmentBytes']}.")
        middle = len(group) // 2
        fit(group[:middle])
        fit(group[middle:])

    for index in range(0, len(entries), batch_size):
        fit(entries[index:index + batch_size])
    for path, before in packer.source_hashes.items():
        if sha256(path) != before:
            raise RuntimeError(f'Source changed while preview was built: {path}')
    output_dir.mkdir(parents=True, exist_ok=True)
    reports = []
    for html, report in fitted:
        output_path = output_dir / (report['rootId'] + '.html')
        output_path.write_text(html, encoding='utf-8')
        report['fragment'] = str(output_path)
        report['manifest'] = str(manifest_path)
        if standalone:
            preview_path = output_dir / (report['rootId'] + '-standalone.html')
            subprocess.run([sys.executable, str(WRAPPER), str(output_path), str(preview_path), '--force'], check=True)
            report['standalone'] = str(preview_path)
        output_path.with_suffix('.validation.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
        reports.append(report)
    (output_dir / 'index.json').write_text(json.dumps(reports, ensure_ascii=False, indent=2), encoding='utf-8')
    return reports


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--manifest', type=Path, required=True)
    parser.add_argument('--output-dir', type=Path, default=WORK / 'catalog-previews')
    parser.add_argument('--batch-size', type=int, default=8)
    parser.add_argument('--max-bytes', type=int, default=262144)
    parser.add_argument('--prefix', default='catalog-vazolar')
    parser.add_argument('--standalone', action='store_true')
    args = parser.parse_args()
    result = pack_catalog(args.manifest, args.output_dir, args.batch_size, args.max_bytes, args.prefix, args.standalone)
    print(json.dumps([dict(fragment=item['fragment'], bytes=item['fragmentBytes'],
                           products=len(item['models']), quality=item['qualityIndex']) for item in result], ensure_ascii=False))
