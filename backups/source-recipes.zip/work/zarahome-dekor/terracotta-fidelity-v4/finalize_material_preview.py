"""Assemble isolated 4355 reference models, preserving the geometry masters."""
from pathlib import Path
import copy
import hashlib
import json
import shutil
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
from export_catalog import export_assets, read_glb, write_glb


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    materials_path = HERE / 'material-source/materials-v4.json'
    materials = json.loads(materials_path.read_text())
    for material in materials.values():
        material.update(wrapS=10497, wrapT=33071)
    materials_path.write_text(json.dumps(materials, indent=2))
    manifest, report = [], []
    for entry in json.loads((HERE / 'geometry-manifest.json').read_text()):
        source = Path(entry['model_path'])
        geometry_hash = sha(source)
        model = json.loads(source.read_text())
        source_mesh_hash = hashlib.sha256(json.dumps(model['meshes'], sort_keys=True).encode()).hexdigest()
        out = HERE / 'material-preview' / entry['id']
        out.mkdir(parents=True, exist_ok=True)
        model['materials'] = copy.deepcopy(materials)
        model['metadata'].pop('material_status', None)
        model['metadata'].update(material_revision='terracotta-fidelity-v4.2',
            revision_notes=[
                '4355-specific silhouette reconstructed from product photographs, retaining the official overall dimensions for each size.',
                'Compact open paired handles are embedded in the neck and shoulder, with rounded body-normal root attachments.',
                'Two continuous physical relief rails have 37 rounded waves each; these details replace the earlier painted side stripes.',
                'New native 2048px shell and 1024px handle/relief PBR maps combine muted oxide-red glaze with porous raw ochre clay; reference photographs were not copied into textures.',
                'A real clearcoat mask leaves raw clay uncoated; circumferential texture wrapping repeats and the axial direction clamps to the edge.',
            ],
            uv_wrap={'u': 'REPEAT', 'v': 'CLAMP_TO_EDGE'})
        for material in materials.values():
            for key, filename in material.items():
                if key.endswith('Texture'):
                    shutil.copyfile(HERE / 'material-source' / filename, out / filename)
        path = out / 'model.json'
        path.write_text(json.dumps(model, separators=(',', ':'), ensure_ascii=False))
        export_assets(path, out, entry['id'])
        glb_path = out / (entry['id'] + '.glb')
        document, binary = read_glb(glb_path)
        for sampler in document.get('samplers', []):
            sampler.update(wrapS=10497, wrapT=33071)
        write_glb(glb_path, document, binary)
        document, _ = read_glb(glb_path)
        assert all(s['wrapS'] == 10497 and s['wrapT'] == 33071 for s in document['samplers'])
        assert sha(source) == geometry_hash
        assert hashlib.sha256(json.dumps(model['meshes'], sort_keys=True).encode()).hexdigest() == source_mesh_hash
        for material in document['materials']:
            extension = material['extensions']['KHR_materials_clearcoat']
            assert 'clearcoatTexture' in extension and extension['clearcoatFactor'] == .35
            assert extension['clearcoatRoughnessFactor'] == .18
        current = copy.deepcopy(entry)
        current.update(model_path=str(path), asset_dir=str(out), model_revision='terracotta-fidelity-v4.2')
        manifest.append(current)
        report.append(dict(id=entry['id'], model_path=str(path), glb_path=str(glb_path),
            bytes=glb_path.stat().st_size, sha256=sha(glb_path), source_geometry_sha256=geometry_hash,
            mesh_payload_sha256=source_mesh_hash, geometry_identical_to_revision_source=True,
            samplers_clamp_t_repeat_s=True, clearcoat_masks_embedded=True,
            material_names=[m['name'] for m in document['materials']]))
    (HERE / 'material-preview-manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2))
    (HERE / 'material-export-validation.json').write_text(json.dumps(report, ensure_ascii=False, indent=2))
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
