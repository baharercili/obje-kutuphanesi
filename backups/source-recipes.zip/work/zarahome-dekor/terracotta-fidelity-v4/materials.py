"""4355 reference reconstruction: muted red glaze and porous raw ochre clay.

API: build_materials(asset_dir) -> material-name mapping. Every bitmap is made
at its native output size from seeded procedural fields. No reference pixels,
highlights, shadows, or ambient occlusion are placed into colour textures.
Shell UV: u=theta, v=1-normalized_height; handles/relief are wholly glazed.
"""
from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path

import numpy as np
from PIL import Image

VERSION = '4355-terracotta-fidelity-v4.2'
RECIPE = {
    'version': VERSION,
    'seed': '4355-sandy-clay-and-oxide-glaze-20261020',
    'body_size': 2048,
    'handle_size': 1024,
    'relief_size': 1024,
    'glaze_rgb': [119, 43, 28],
    'clay_rgb': [184, 153, 105],
    'glaze_boundary_y': .795,
    'glaze_roughness': .275,
    'clay_roughness': .88,
    'clearcoat_factor': .35,
    'clearcoat_roughness': .18,
    'albedo_contains_lighting': False,
    'photo_pixels_used': False,
    'pore_definition': 'Sparse native pixel pits with mixed radii; roughness and tangent normals carry actual pore response.',
}


def _noise(rng, n, sigma):
    field = rng.standard_normal((n, n), dtype=np.float32)
    fy = np.fft.fftfreq(n).astype(np.float32)[:, None]
    fx = np.fft.rfftfreq(n).astype(np.float32)[None, :]
    kernel = np.exp(-2 * math.pi ** 2 * sigma ** 2 * (fx * fx + fy * fy))
    field = np.fft.irfft2(np.fft.rfft2(field) * kernel, s=(n, n)).astype(np.float32)
    field -= field.mean()
    field /= max(float(field.std()), 1e-6)
    return field


def _impulses(rng, n, density, radius):
    """Small isolated pores, never broad soft low-frequency bumps."""
    spots = (rng.random((n, n)) < density).astype(np.float32)
    fy = np.fft.fftfreq(n).astype(np.float32)[:, None]
    fx = np.fft.rfftfreq(n).astype(np.float32)[None, :]
    kernel = np.exp(-2 * math.pi ** 2 * radius ** 2 * (fx * fx + fy * fy))
    field = np.fft.irfft2(np.fft.rfft2(spots) * kernel, s=(n, n)).astype(np.float32)
    return np.clip(field * (2 * math.pi * radius ** 2), 0, 1)


def _normal(height):
    dx = (np.roll(height, -1, 1) - np.roll(height, 1, 1)) * .5
    dy = (np.roll(height, -1, 0) - np.roll(height, 1, 0)) * .5
    vectors = np.stack((-dx, -dy, np.ones_like(dx)), axis=2)
    vectors /= np.linalg.norm(vectors, axis=2, keepdims=True)
    return np.uint8(np.rint(np.clip((vectors + 1) * 127.5, 0, 255)))


def _maps(role, n):
    seed = int.from_bytes(hashlib.sha256((RECIPE['seed'] + role).encode()).digest()[:8], 'little')
    rng = np.random.default_rng(seed)
    scale = n / 2048
    yy, xx = np.mgrid[0:n, 0:n].astype(np.float32) / n
    micro = _noise(rng, n, .55)
    grit = _noise(rng, n, max(.75, scale * 1.25))
    mottles = _noise(rng, n, n * .011)
    broad_colour = _noise(rng, n, n * .05)
    pores = np.maximum(_impulses(rng, n, .010, max(.65, 1.05 * scale)),
                       _impulses(rng, n, .0010, max(.9, 2.5 * scale)))
    pores = np.maximum(pores, _impulses(rng, n, .00012, max(1.1, 4.2 * scale)) * .85)
    grit_grains = np.clip((grit - .65) * .7, 0, 1)
    # Mineral inclusions are material colour, independent of view or lighting.
    dark_grit = np.clip((-micro - 1.15) * .3, 0, .7)
    clay = np.broadcast_to(np.array(RECIPE['clay_rgb'], np.float32), (n, n, 3)).copy()
    clay += (grit * 2.9 + micro * 1.3 + mottles * 3.3 + broad_colour * 2.7)[:, :, None] * np.array([1, .9, .68])
    clay -= pores[:, :, None] * np.array([32, 28, 20])
    clay -= dark_grit[:, :, None] * np.array([18, 15, 10])
    clay += grit_grains[:, :, None] * np.array([6, 5, 3])
    # Uneven abrasive wear around the bottom 5%; no simulated contact shadow.
    foot = np.clip((yy - .94) / .06, 0, 1)
    abrasion = foot * np.clip(.6 + mottles * .22 + grit * .1, 0, 1)
    clay += abrasion[:, :, None] * np.array([4, 3, 1])
    clay -= (foot * pores)[:, :, None] * np.array([8, 7, 5])
    glaze = np.broadcast_to(np.array(RECIPE['glaze_rgb'], np.float32), (n, n, 3)).copy()
    glaze += (mottles * 2.4 + broad_colour * 2.4 + grit * .7)[:, :, None] * np.array([1, .64, .48])
    glaze -= np.clip((micro - 1.7) * 1.7, 0, 4)[:, :, None] * np.array([1, .8, .6])
    if role == 'shell':
        # Gentle hand-dipped edge variation, not large drips or a fuzzy stripe.
        edge = .205 + .0015 * np.sin(2 * math.pi * xx * 5 + .7) + .0007 * np.sin(2 * math.pi * xx * 17)
        coat = np.clip((edge - yy) / .001 + .5, 0, 1)
    else:
        coat = np.ones((n, n), np.float32)
    albedo = clay * (1 - coat[:, :, None]) + glaze * coat[:, :, None]
    clay_rough = np.clip(.88 + grit * .023 + pores * .075 + mottles * .012, .77, .99)
    glaze_rough = np.clip(.275 + mottles * .022 + grit * .013, .20, .35)
    roughness = clay_rough * (1 - coat) + glaze_rough * coat
    clay_height = micro * .07 + grit * .26 - pores * .95 + grit_grains * .10
    glaze_height = grit * .028 + micro * .010 - pores * .03
    height = clay_height * (1 - coat) + glaze_height * coat
    packed = np.empty((n, n, 3), np.uint8)
    packed[:, :, 0] = 255
    packed[:, :, 1] = np.uint8(np.rint(roughness * 255))
    packed[:, :, 2] = 0
    clearcoat = np.zeros((n, n, 3), np.uint8)
    clearcoat[:, :, 0] = np.uint8(np.rint(coat * 255))
    return {
        'baseColorTexture': np.uint8(np.clip(np.rint(albedo), 0, 255)),
        'normalTexture': _normal(height),
        'metallicRoughnessTexture': packed,
        'clearcoatTexture': clearcoat,
    }, coat, roughness


def build_materials(asset_dir):
    """Create deterministic full-size maps and return the 3-material contract."""
    asset = Path(asset_dir)
    asset.mkdir(parents=True, exist_ok=True)
    material_map = {}
    report = {'recipe': RECIPE, 'materials': {}, 'tests': {}}
    names = [('ceramic', 'shell', 2048), ('glazed_handle', 'handle', 1024), ('glazed_relief', 'relief', 1024)]
    for name, role, size in names:
        maps, coat, roughness = _maps(role, size)
        material = {
            'baseColorFactor': [1, 1, 1, 1], 'metallic': 0,
            'roughness': 1, 'normalScale': .95 if role == 'shell' else .55,
            'transmission': 0, 'ior': 1.5, 'clearcoat': .35,
            'clearcoatRoughness': .18, 'alphaMode': 'OPAQUE', 'doubleSided': False,
            'wrapS': 10497, 'wrapT': 33071,
            'extras': {'material_type': 'terracotta', 'finish': 'two_zone_glazed' if role == 'shell' else 'glazed',
                       'texture_style': VERSION, 'map_size': size, 'albedo_contains_lighting': False,
                       'photo_pixels_used': False, 'seed': RECIPE['seed'] + role},
        }
        hashes = {}
        for key, array in maps.items():
            slug = {'baseColorTexture': 'basecolor', 'normalTexture': 'normal', 'metallicRoughnessTexture': 'pbr',
                    'clearcoatTexture': 'clearcoat-mask', 'clearcoatRoughnessTexture': 'clearcoat-roughness'}[key]
            signature = hashlib.sha256(array.tobytes()).hexdigest()[:16]
            filename = f'4355-v4-{role}-{signature}-{slug}.png'
            path = asset / filename
            Image.fromarray(array).save(path, compress_level=6)
            material[key] = filename
            hashes[key] = {'filename': filename, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                           'width': size, 'height': size}
        material_map[name] = material
        pure = coat > .999
        stats = {'size': size, 'glaze_mean_rgb': maps['baseColorTexture'][pure].mean(axis=0).round(3).tolist(),
                 'glaze_mean_roughness': float(roughness[pure].mean()), 'texture_hashes': hashes,
                 'metallic_max': int(maps['metallicRoughnessTexture'][:, :, 2].max())}
        if role == 'shell':
            bare = coat == 0
            stats.update(clay_mean_rgb=maps['baseColorTexture'][bare].mean(axis=0).round(3).tolist(),
                         clay_mean_roughness=float(roughness[bare].mean()),
                         clay_clearcoat_max=int(maps['clearcoatTexture'][:, :, 0][bare].max()),
                         boundary_y=RECIPE['glaze_boundary_y'])
            assert stats['clay_clearcoat_max'] == 0
            assert .84 < stats['clay_mean_roughness'] < .94
        assert stats['metallic_max'] == 0
        assert .22 < stats['glaze_mean_roughness'] < .32
        report['materials'][name] = stats
    report['tests'] = {'native_requested_map_sizes': True, 'uncoated_clay_clearcoat_is_zero': True,
                       'metallic_is_zero': True, 'roughness_zones_are_distinct': True,
                       'generated_without_reference_pixels': True}
    (asset / 'materials-v4.json').write_text(json.dumps(material_map, indent=2))
    (asset / 'materials-v4-validation.json').write_text(json.dumps(report, indent=2))
    return material_map


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('asset_dir')
    args = parser.parse_args()
    build_materials(args.asset_dir)
