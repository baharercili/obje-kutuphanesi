"""Small material-map contract checks; all generated samples stay in a temp dir."""
import tempfile
import unittest
from pathlib import Path
import numpy as np
from PIL import Image
from catalog_materials import build_materials

class CatalogMaterialTests(unittest.TestCase):
    def test_styles_and_packed_channels(self):
        with tempfile.TemporaryDirectory(prefix='vase-materials-') as directory:
            for style in ('plain','speckled','craquelure','horizontal_bands','vertical_stripes','leaf','rustic','oxidized'):
                with self.subTest(style=style):
                    material=build_materials({'id':style,'texture_size':64,'color_rgb':[191,176,139],
                                              'texture_style':style},directory)['ceramic']
                    self.assertEqual(material['roughness'],1)
                    packed=np.asarray(Image.open(Path(directory)/material['metallicRoughnessTexture']))
                    self.assertTrue((packed[:,:,0]==255).all())
                    self.assertTrue((packed[:,:,2]==0).all())
                    self.assertGreater(packed[:,:,1].min(),0)
                    normals=np.asarray(Image.open(Path(directory)/material['normalTexture'])).astype(float)/127.5-1
                    self.assertLess(np.abs(np.linalg.norm(normals,axis=2)-1).max(),.009)
                    albedo=np.asarray(Image.open(Path(directory)/material['baseColorTexture']))
                    self.assertEqual(albedo.shape,(64,64,3))

    def test_determinism_cache_and_types(self):
        with tempfile.TemporaryDirectory(prefix='vase-materials-') as directory:
            spec={'id':'seed-example','texture_size':64,'material_type':'metal','finish':'satin'}
            a=build_materials(spec,directory)['ceramic']
            first=(Path(directory)/a['baseColorTexture']).read_bytes()
            b=build_materials(spec,directory)['ceramic']
            self.assertEqual(a,b)
            self.assertEqual(first,(Path(directory)/b['baseColorTexture']).read_bytes())
            self.assertEqual(a['metallic'],1)
            packed=np.asarray(Image.open(Path(directory)/a['metallicRoughnessTexture']))
            self.assertTrue((packed[:,:,2]==255).all())
            clay=build_materials({**spec,'material_type':'terracotta'},directory)['ceramic']
            self.assertEqual(clay['metallic'],0)
            self.assertGreater(clay['extras']['base_roughness'],a['extras']['base_roughness'])

    def test_glass_keeps_volume_properties(self):
        with tempfile.TemporaryDirectory(prefix='vase-materials-') as directory:
            material=build_materials({'material_type':'glass','color_rgb':[148,102,44]},directory)['ceramic']
            self.assertEqual(material['transmission'],1)
            self.assertEqual(material['ior'],1.5)
            self.assertGreater(material['thickness'],0)
            self.assertLess(material['roughness'],.1)
            self.assertEqual(material['alphaMode'],'OPAQUE')
            self.assertLess(material['attenuationColor'][2],material['attenuationColor'][0])
            self.assertEqual(list(Path(directory).iterdir()),[])

    def test_plain_ceramic_has_no_broad_lighting_gradient(self):
        with tempfile.TemporaryDirectory(prefix='vase-materials-') as directory:
            material=build_materials({'id':'uniform','texture_size':256,'color_rgb':[191,176,139]},directory)['ceramic']
            image=np.asarray(Image.open(Path(directory)/material['baseColorTexture'])).astype(float)
            self.assertLess(np.ptp(image.mean(axis=1),axis=0).max(),1.5)
            self.assertLess(np.abs(image.mean(axis=(0,1))-[191,176,139]).max(),.1)

    def test_patina_has_no_pixel_checker(self):
        with tempfile.TemporaryDirectory(prefix='vase-materials-') as directory:
            material=build_materials({'id':'patina','texture_size':128,'material_type':'metal',
                                      'color_rgb':[174,132,63],'texture_style':'oxidized'},directory)['ceramic']
            image=np.asarray(Image.open(Path(directory)/material['baseColorTexture'])).astype(float)
            checker=image[:-1,:-1]-image[1:,:-1]-image[:-1,1:]+image[1:,1:]
            self.assertLess(np.abs(checker).mean(),1.5)

if __name__=='__main__': unittest.main()
