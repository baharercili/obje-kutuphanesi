import base64, gzip, json, re, subprocess, sys
from pathlib import Path
import pack_catalog as pc

ROOT=Path('/Users/USER/Documents/ChatGPT/Studio')
WORK=ROOT/'work/zarahome-dekor'
DEST=Path('/Users/USER/.codex/visualizations/2026/10/20/01a159db-9681-7b91-933e-e9cc984d26f6')
entries=json.loads((WORK/'catalog-manifest.json').read_text())
assert len(entries)==89
stone=next(entry for entry in entries if entry['id']=='4536-043-450-h32-w27-d26')
assert '4536-surface-revision' in stone['model_path'], '4536 surface revision is not integrated yet'
stone['preview_color_size']=256
focus=next(entry for entry in entries if entry['id']=='4355-046-600-h31p5-w14p5-d13')
assert 'terracotta-fidelity-v4' in focus['model_path'], '4355 final V4 is not integrated yet'
focus['preview_color_size']=256
focus['preview_geometry_quality']=0
for entry in entries:
    if entry['id'].startswith('4355-046-600-'):
        assert 'terracotta-fidelity-v4' in entry['model_path'], 'Both 4355 sizes must use V4'
        source=json.loads(Path(entry['model_path']).read_text())
        assert source['metadata'].get('material_revision','').startswith('terracotta-fidelity-v4'), 'Final 4355 PBR materials are not integrated yet'
        entry['preview_preserve_meshes']=[mesh['name'] for mesh in source['meshes'] if 'physical-scalloped-seam' in mesh.get('name','')]
        assert len(entry['preview_preserve_meshes'])==2, 'Physical 4355 relief strips missing'
category_map={entry['id']:entry['category'] for entry in entries}
site_manifest=json.loads((ROOT/'sites/zarahome-vazo-kutuphanesi-publish/model-manifest.json').read_text())['models']
download_map={entry['id']:'https://bahar-vazo-kutuphanesi.createandgotr.chatgpt.site/models/'+entry['filename']+'?v='+entry['sha256'] for entry in site_manifest if entry['id'] in category_map}
assert set(category_map)==set(download_map)
for reviewed in [stone,*[entry for entry in entries if entry['id'].startswith('4355-046-600-')]]:
    site_source=next(entry for entry in site_manifest if entry['id']==reviewed['id'])
    reviewed_glb=Path(reviewed['asset_dir'])/(reviewed['id']+'.glb')
    assert site_source['sha256']==pc.sha256(reviewed_glb), 'Site manifest does not include final reviewed model: '+reviewed['id']
packer=pc.CatalogPacker()
packer.template=(WORK/'inline-catalog-template.html').read_text().replace('__CATEGORY_MAP__',json.dumps(category_map,ensure_ascii=False,separators=(',',':'))).replace('__DOWNLOAD_MAP__',json.dumps(download_map,separators=(',',':')))
for quality in [3,4]:
    html,report=packer.fragment(entries,quality,'zarahome-vazo-kutuphanesi')
    payload_match=re.search(r'(<script type="application/json" id="zarahome-vazo-kutuphanesi-payload">)(.*?)(</script>)',html,re.S)
    assert payload_match, 'Inline payload script missing'
    raw_config=payload_match.group(2).encode('utf-8')
    compressed_config=gzip.compress(raw_config,compresslevel=9,mtime=0)
    envelope=json.dumps(dict(encoding='gzip-base64-config-v1',data=base64.b64encode(compressed_config).decode('ascii')),separators=(',',':'))
    assert json.loads(gzip.decompress(base64.b64decode(json.loads(envelope)['data'])))==json.loads(raw_config)
    html=html[:payload_match.start(2)]+envelope+html[payload_match.end(2):]
    report.update(uncompressedFragmentBytes=report['fragmentBytes'],inlineConfigEncoding='gzip-base64-config-v1',inlineConfigRawBytes=len(raw_config),inlineConfigGzipBytes=len(compressed_config),fragmentBytes=len(html.encode('utf-8')))
    print(json.dumps({'quality':quality,'bytes':report['fragmentBytes'],'uncompressedBytes':report['uncompressedFragmentBytes'],'models':len(report['models'])}),flush=True)
    if report['fragmentBytes']<990000:break
else:raise RuntimeError('Unified viewer exceeds inline limit')
assert len(report['models'])==len(set(report['models']))==89
assert '__CATEGORY_MAP__' not in html and '__PAYLOAD__' not in html and '__DOWNLOAD_MAP__' not in html
assert not any(x in html for x in ['fetch(', 'XMLHttpRequest', 'WebSocket'])
for path,before in packer.source_hashes.items():
    assert pc.sha256(path)==before,path
path=DEST/'zarahome-vazo-kutuphanesi.html'
path.write_text(html)
script=re.findall(r'<script type="module">(.*?)</script>',html,re.S)[0]
(WORK/'inline-module-check.mjs').write_text(script)
(WORK/'inline-catalog-validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
subprocess.run([sys.executable,str(pc.WRAPPER),str(path),str(WORK/'inline-catalog-preview.html'),'--force'],check=True)
print(str(path),flush=True)
