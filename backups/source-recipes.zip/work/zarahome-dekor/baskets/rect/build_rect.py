"""Four photo-specific woven basket masters, actual closed fibre solids and intrinsic PBR."""
from pathlib import Path
import sys,json,math,hashlib,re,importlib.util
import numpy as np
from PIL import Image
R=Path(__file__).resolve().parent;WORK=R.parents[1]
sys.path.insert(0,str(WORK))
from export_catalog import export_assets,read_glb,write_glb
from vase_geometry import _finalize,_signed_volume
sp=importlib.util.spec_from_file_location('_noise',WORK/'bowls-trays/tray-build/tray_materials.py');noise=importlib.util.module_from_spec(sp);sp.loader.exec_module(noise)
def dump(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
class Builder:
 def __init__(self):self.groups={};self.solids=0
 def tube(self,name,points,rad,mat='fibre',flat=1.,closed=False,sides=6,normal=None):
  pts=np.array(points,float)
  if closed and np.linalg.norm(pts[0]-pts[-1])<1e-10:pts=pts[:-1]
  n=len(pts);v=[];uv=[];f=[];self.solids+=1;shift=(self.solids*.371)%13;length=np.r_[0,np.cumsum(np.linalg.norm(np.diff(pts,axis=0),axis=1))]
  for i,p in enumerate(pts):
   t=pts[(i+1)%n]-pts[(i-1)%n] if closed else pts[min(i+1,n-1)]-pts[max(i-1,0)];t/=np.linalg.norm(t)
   no=np.array(normal(i,p)if callable(normal)else (normal if normal is not None else [0,1,0]),float);no-=t*np.dot(no,t)
   if np.linalg.norm(no)<.01:no=np.cross(t,[1,0,0])
   no/=np.linalg.norm(no);bi=np.cross(t,no)
   for j in range(sides):
    a=math.tau*j/sides;v.append(tuple(p+rad*(flat*math.cos(a)*no+math.sin(a)*bi)));uv.append((j/sides*.22+shift,length[i]/.1+shift))
  end=n if closed else n-1
  for i in range(end):
   for j in range(sides):
    a=i*sides+j;b=((i+1)%n)*sides+j;c=i*sides+(j+1)%sides;d=((i+1)%n)*sides+(j+1)%sides;f.extend([(a,b,c),(c,b,d)])
  if not closed:
   a=len(v);v.extend([tuple(pts[0]),tuple(pts[-1])]);uv.extend([(shift,shift),(shift,shift+length[-1]/.1)])
   for j in range(sides):f.extend([(a,j,(j+1)%sides),(a+1,(n-1)*sides+(j+1)%sides,(n-1)*sides+j)])
  if _signed_volume(v,f)<0:f=[(a,c,b)for a,b,c in f]
  key=(name,mat)
  if key not in self.groups:self.groups[key]=dict(name=name,material=mat,_vertices=[],_uvs=[],_faces=[])
  g=self.groups[key];off=len(g['_vertices']);g['_vertices']+=v;g['_uvs']+=uv;g['_faces'] +=[(a+off,b+off,c+off)for a,b,c in f]
 def finish(self,w,h,d,features):
  vs=np.concatenate([np.array(g['_vertices'])for g in self.groups.values()]);lo=vs.min(0);hi=vs.max(0);scale=np.array([w,h,d])/(hi-lo);center=np.array([(lo[0]+hi[0])/2,lo[1],(lo[2]+hi[2])/2]);meshes=[];qa=[]
  for g in self.groups.values():
   g['_vertices']=[tuple((np.array(v)-center)*scale)for v in g['_vertices']];m,q=_finalize(g);meshes.append(m);qa.append(q)
  report=dict(valid=True,units='metres',up_axis='Y',origin='bottom bounding-box centre',dimensions_metres=[w,h,d],overall_dimensions_official=True,local_details_photo_inferred=True,closed_strand_solids=self.solids,mesh_count=len(meshes),triangles=sum(q['triangles']for q in qa),meshes=qa,photographed_features=features,construction='Each fibre, spoke, band and seam is a closed solid. Separate intersecting capped fibre solids reproduce woven manufacture; the open vessel interior and strand gaps are real geometry.',affine_fit_scale=scale.tolist())
  return meshes,report

def perimeter(w,d,r,t):
 # Continuous arclength parameter: four straight sides and quarter-circle corners.
 a=w/2;b=d/2;r=min(r,a*.9,b*.9);L=2*(w+d-4*r)+math.tau*r;s=(t%1)*L
 parts=[('line',w-2*r,(-a+r,-b),(1,0)),('arc',math.pi*r/2,(a-r,-b+r),(-math.pi/2,)),('line',d-2*r,(a,-b+r),(0,1)),('arc',math.pi*r/2,(a-r,b-r),(0,)),('line',w-2*r,(a-r,b),(-1,0)),('arc',math.pi*r/2,(-a+r,b-r),(math.pi/2,)),('line',d-2*r,(-a,b-r),(0,-1)),('arc',math.pi*r/2,(-a+r,-b+r),(math.pi,))]
 for kind,ll,p,q in parts:
  if s<=ll+1e-10:
   if kind=='line':x=p[0]+s*q[0];z=p[1]+s*q[1];normal=np.array([q[1],0,-q[0]],float)
   else:ang=q[0]+s/r;x=p[0]+r*math.cos(ang);z=p[1]+r*math.sin(ang);normal=np.array([math.cos(ang),0,math.sin(ang)])
   return np.array([x,0,z]),normal,L
  s-=ll
 raise ValueError(t)
def loop(w,d,r,y,N):return [perimeter(w,d,r,i/N)[0]+[0,y,0]for i in range(N)]
def weave(b,w,h,d,r,rows=28,stakes=64,rad=.0023,colour='fibre',taper=.94,scallops=0):
 N=stakes*2;bodytop=h-(.014 if scallops else 0);ys=np.linspace(rad*1.2,bodytop-rad,rows);rowpitch=ys[1]-ys[0]
 for j,y in enumerate(ys):
  yy=y/bodytop;ww=w*(taper+(1-taper)*yy);dd=d*(taper+(1-taper)*yy);pts=[]
  for k in range(N):
   t=k/N;p,no,_=perimeter(ww,dd,r,t);p+=no*(rad*.55*math.cos(math.tau*(k/2)+j*math.pi));p[1]=y+rad*.08*math.sin(k*.73+j*1.39);pts.append(p)
  b.tube('body-horizontal-woven-fibres',pts,rad,colour,flat=1.25,closed=True,sides=6)
 for i in range(stakes):
  t=i/stakes;top=bodytop+(.014*(.5-.5*math.cos(math.tau*scallops*t))if scallops else 0);pts=[]
  for f in np.linspace(0,1,rows*2):
   yy=rad+f*(top-rad);q=min(yy/bodytop,1);p,no,_=perimeter(w*(taper+(1-taper)*q),d*(taper+(1-taper)*q),r,t);p+=no*rad*.85*math.cos(math.pi*(yy-ys[0])/rowpitch+i*math.pi);p[1]=yy;pts.append(p)
  b.tube('body-vertical-interlaced-spokes',pts,rad*.65,colour,flat=.95,sides=6)
 if scallops:
  for rowoffset in [0,-.004,-.008]:
   pts=[]
   for k in range(N*2):
    t=k/(N*2);p,no,_=perimeter(w,d,r,t);p[1]=bodytop+.014*(.5-.5*math.cos(math.tau*scallops*t))+rowoffset;pts.append(p)
   b.tube('scalloped-wrapped-top-edge',pts,rad*1.05,colour,closed=True,sides=8)
 else:
  b.tube('rounded-bound-top-edge',loop(w,d,r,h,N*2),rad*1.35,colour,closed=True,sides=8)
 b.tube('bound-bottom-edge',loop(w*taper,d*taper,r,rad,N),rad*1.1,colour,closed=True,sides=8)
 # Crossed interlaced floor fibres, real bottom inside the open basket.
 floor(b,w*taper-.005,d*taper-.005,rad*1.4,rad,colour,pitch=max(.007,w/34),corner=r*taper)

def floor(b,w,d,y,rad,mat,pitch=.009,name='interlaced-bottom',corner=.012):
 nx=max(8,round(w/pitch));nz=max(8,round(d/pitch))
 for axis,n,length,cross in [(0,nz,w,d),(2,nx,d,w)]:
  for i in range(n):
   fixed=-cross/2+(i+.5)*cross/n;pts=[]
   rr=min(corner,cross*.45,length*.45);delta=max(0,abs(fixed)-(cross/2-rr));half=length/2-rr+math.sqrt(max(0,rr*rr-delta*delta));actual=half*2
   for t in np.linspace(-.5,.5,25):
    q=np.zeros(3);q[axis]=actual*t;q[2 if axis==0 else 0]=fixed;q[1]=y+rad*.67*math.cos(math.tau*((t+.5)*length/pitch)+i*math.pi)*(1 if axis==0 else-1);pts.append(q)
   b.tube(name,pts,rad,mat,flat=.65,sides=6)

def square_lid():
 w=h=d=.25;b=Builder();bodyh=.230;rad=.00194
 def panel(ww,hh,cy,constant,axis,tag):
  # Four triangular weave sectors meet at diagonal mitres. Concentric square
  # courses reproduce the photographed frame/diamond motif on each panel.
  rings=29
  for j in range(rings):
   inset=j*.00395;pw=ww-2*inset;ph=hh-2*inset
   if min(pw,ph)<.008:continue
   N=max(32,round((pw+ph)*160));N=((N+3)//4)*4;pts=[]
   for k in range(N):
    p,no,_=perimeter(pw,ph,min(.004,max(.001,min(pw,ph)*.07)),k/N)
    wav=.00020*math.sin(k*1.9+j*.77)
    if axis=='front':q=[p[0],p[2]+cy,constant+wav]
    elif axis=='side':q=[constant+wav,p[2]+cy,p[0]]
    else:q=[p[0],constant+wav,p[2]]
    pts.append(q)
   b.tube(tag,pts,rad,'fibre',flat=.88,closed=True,sides=6,normal=[0,0,1]if axis=='front'else [1,0,0]if axis=='side'else [0,1,0])
  # Small interwoven rosette closes the photographed centre without a plug disc.
  for direction in [0,1]:
   for i in range(5):
    fixed=(i-2)*.0032;pts=[]
    for t in np.linspace(-.009,.009,11):
     px,pz=(t,fixed)if direction==0 else(fixed,t);fuzz=.00035*math.sin(t*1500+i*math.pi)
     q=[px,pz+cy,constant+fuzz]if axis=='front'else[constant+fuzz,pz+cy,px]if axis=='side'else[px,constant+fuzz,pz];pts.append(q)
    b.tube(tag,pts,.00125,'fibre',sides=6)
 for sign in [-1,1]:
  panel(.242,.227,.115,sign*.1205,'front','four-sector-seagrass-front-back-panels')
  panel(.242,.227,.115,sign*.1205,'side','four-sector-seagrass-side-panels')
 # Rounded vertical hand-bound seams join the four dense woven faces.
 for x in [-.1205,.1205]:
  for z in [-.1205,.1205]:
   for phase in range(2):
    pts=[]
    for y in np.linspace(.002,bodyh,90):
     a=math.tau*(y/.012+phase*.5);pts.append((x+.0010*math.cos(a),y,z+.0010*math.sin(a)))
    b.tube('hand-bound-vertical-corner-seams',pts,.00135,'fibre',sides=6)
 panel(.238,.238,0,.004,'floor','woven-concentric-square-bottom')
 panel(.243,.243,0,.247,'floor','removable-square-weave-lid')
 b.tube('lid-black-contrast-piping',loop(.245,.245,.010,.232,240),.00235,'dark',closed=True,sides=8)
 # Broad 18 mm bound side band gives the removable lid its photographed thickness.
 for yy in [.236,.240,.244,.247]:
  b.tube('deep-woven-lid-side-band',loop(.241,.241,.010,yy,192),.0030,'fibre',closed=True,sides=8)
 # A thick rounded fibre lip and many wraps retain the soft bound lid silhouette.
 for phase in range(2):
  pts=[]
  for k in range(320):
   t=k/320;p,no,_=perimeter(.241,.241,.010,t);a=math.tau*(48*t+phase/2);p+=no*.0011*math.cos(a);p[1]=.246+.0011*math.sin(a);pts.append(p)
  b.tube('thick-twisted-seagrass-lid-lip',pts,.0027,'fibre',closed=True,sides=8)
 for i in range(110):
  t=i/110;p,no,_=perimeter(.241,.241,.010,t);pts=[]
  for a in np.linspace(0,math.tau,10,endpoint=False):pts.append(p+no*(.0035*math.cos(a))+[0,.246+.0035*math.sin(a),0])
  b.tube('fine-frayed-lid-wrap-stitches',pts,.00036,'fibre',closed=True,sides=5)
 return b.finish(w,h,d,['Square straight-sided seagrass box with softly bound corners','Dense four-sector concentric square / mitred diagonal face weaving matching the photographed central motif','Separate closed woven lid over a real hollow basket','Thick softly braided lid lip with narrow charcoal-black piping below it','Hand-wrapped vertical seams and genuine crossed fibre depth'])

def scallop():
 b=Builder();w=.45;h=.17;d=.35
 weave(b,w-.006,h-.003,d-.006,.013,rows=27,stakes=76,rad=.0020,taper=.98,scallops=28)
 return b.finish(w,h,d,['Low rectangular paper-wrapped iron storage basket','28 repeating rounded scallops at the raised edge','Thin horizontal twisted paper fibres alternating with fine vertical supports','Open interior and visibly woven floor; no staged toy or blanket'])

def contrast():
 b=Builder();w=.25;h=.18;d=.34;r=.025;rad=.0054;rows=15;L=perimeter(w-.010,d-.010,r,0)[2]
 # Distinct coiled seagrass bundles, not a generic lattice weave.
 for j,y in enumerate(np.linspace(rad,h-rad,rows)):
  ww=(w-.010)*(.96+.04*j/(rows-1));dd=(d-.010)*(.96+.04*j/(rows-1));pts=loop(ww,dd,r,y,148)
  b.tube('thick-horizontal-seagrass-coils',pts,rad,'fibre',flat=1.0,closed=True,sides=8)
  # White PP lacing encircles each bundle with a slight diagonal, as photographed.
  count=round(L/.0100)
  for i in range(count):
   t=i/count;pts=[]
   for a in np.linspace(0,math.tau,7,endpoint=False):
    tt=t+.0019/L*(a/math.tau-.5);p,no,_=perimeter(ww,dd,r,tt);p+=no*(rad+.0003)*math.cos(a);p[1]=y+(rad+.0003)*math.sin(a);pts.append(p)
   b.tube('white-polypropylene-coil-binding',pts,.00072,'white',closed=True,sides=4)
 # A few unobtrusive vertical reeds genuinely connect adjacent coils.
 for i in range(36):
  p,no,_=perimeter(w-.014,d-.014,r,i/36);pts=[p+[0,y,0]-no*.002 for y in np.linspace(rad,h-rad,20)];b.tube('concealed-upright-seagrass-stakes',pts,.0014,'fibre',sides=6)
 floor(b,w*.94,d*.94,.005,.0025,'fibre',pitch=.010,corner=r)
 return b.finish(w,h,d,['Rounded rectangular straight-sided storage basket','15 thick coiled seagrass bands with genuine separate white PP bindings','Open top with same wrapped upper coil','White spiral bindings on both inside and outside; interwoven bottom'])

def rattan():
 b=Builder();w=h=d=.55;body=.493;r=.117;rad=.0035
 # Rattan photograph is a rounded square taper rather than a sharp box.
 weave(b,w-.025,body,d-.025,r,rows=38,stakes=56,rad=rad,taper=.84)
 # Heavy braided upper edge uses 3 actual entwined willow/rattan strands.
 N=384
 for phase in range(3):
  pts=[]
  for k in range(N):
   t=k/N;p,no,L=perimeter(w-.025,d-.025,r,t);a=math.tau*(42*t+phase/3);p+=no*.0060*math.cos(a);p[1]=body+.0060*math.sin(a);pts.append(p)
  b.tube('three-strand-braided-heavy-rim',pts,.0054,'fibre',closed=True,sides=8)
 # Two integral rounded loop handles anchored across the opposite short sides.
 for sign in [-1,1]:
  for phase in range(3):
   pts=[]
   for a in np.linspace(0,math.pi,54):
    x=.040*math.cos(a);y=body+.036*math.sin(a);z=sign*(d-.026)/2;tw=math.tau*5*a/math.pi+math.tau*phase/3
    pts.append((x+.0027*math.cos(tw),y+.0027*math.sin(tw),z))
   b.tube('integrated-braided-loop-handles',pts,.0026,'fibre',sides=6)
 return b.finish(w,h,d,['Large dark honey-brown rounded-square rattan basket','Gently tapered body, very broad rounded corners','Interleaved horizontal rattan rods and upright stakes, with actual open gaps','Heavy three-strand plaited lip and two attached raised loop handles','Crossed rattan floor inside a genuinely hollow body'])

def materials(out,base,seed,secondary=None):
 n=2048;v=np.linspace(0,1,n,dtype=np.float32);x=np.broadcast_to(v[None,:],(n,n));y=np.broadcast_to(v[:,None],(n,n));cloud=noise._object_noise(x,y,seed,8.5);fine=noise._object_noise(x,y,seed+1,159);grain=np.sin(math.tau*(x*134+np.sin(y*22)*.8))+np.sin(math.tau*(x*211+y*.9))*.28;fuzz=noise._object_noise(x,y,seed+11,420)
 height=grain*.12+fine*.08+fuzz*.04;dx=np.gradient(height,axis=1);dy=np.gradient(height,axis=0);nn=np.stack([-dx*3.4,-dy*3.4,np.ones_like(dx)],2);nn/=np.linalg.norm(nn,axis=2,keepdims=True);normal=np.rint((nn+1)*127.5).astype(np.uint8);rough=np.clip(.77+fine*.024+cloud*.025,.66,.88);orm=np.empty((n,n,3),np.uint8);orm[:,:,0]=255;orm[:,:,1]=np.rint(rough*255);orm[:,:,2]=0
 Image.fromarray(normal,'RGB').save(out/'fibre-normal-2k.png',optimize=True);Image.fromarray(orm,'RGB').save(out/'fibre-orm-2k.png',optimize=True)
 mats={};cols={'fibre':base};cols.update(secondary or {})
 for mat,c in cols.items():
  strength=.45 if mat=='white'else 1.;arr=np.array(c,np.float32)+strength*(cloud[:,:,None]*np.array([7.3,6.4,4.9])+fine[:,:,None]*1.2+grain[:,:,None]*1.7+fuzz[:,:,None]*.55);Image.fromarray(np.clip(np.rint(arr),0,255).astype(np.uint8),'RGB').save(out/(mat+'-albedo-2k.png'),optimize=True)
  mats[mat]=dict(baseColorFactor=[1,1,1,1],metallic=0,roughness=1,baseColorTexture=mat+'-albedo-2k.png',normalTexture='fibre-normal-2k.png',metallicRoughnessTexture='fibre-orm-2k.png',normalScale=.35 if mat!='white'else .17,alphaMode='OPAQUE',doubleSided=False,extras=dict(native_resolution=2048,photo_pixels_baked=False,baked_reflections=False,material_identity=('white polypropylene binding'if mat=='white'else 'dark woven piping'if mat=='dark'else 'official plant fibre or paper-wrapped fibre as described in metadata')))
 maps={p.name:dict(bytes=p.stat().st_size,sha256=sha(p),mode='RGB',dimensions=[n,n])for p in out.glob('*-2k.png')};dump(out/'material-validation.json',dict(valid=True,native_resolution=2048,metallic=0,roughness_range=[float(rough.min()),float(rough.max())],intrinsic_material=True,photo_pixels_baked=False,baked_reflections=False,maps=maps));return mats

def main():
 products=json.loads((R/'reference-products.json').read_text());only=sys.argv[1]if len(sys.argv)>1 else None;manifest=[e for e in json.loads((R/'manifest.json').read_text())if only and e['id']!=only]if only and (R/'manifest.json').exists()else []
 specs=[('l43346049','3346-049-052-h25-w25-d25',square_lid,[201,169,118],{'dark':[39,38,32]},'Deniz yosunu · Kontrast koyu kenarlı'),('l46670049','6670-049-052-h17-w45-d35',scallop,[213,188,147],None,'Kâğıt (%52) / demir (%48) · Doğal örgü'),('l44541049','4541-049-999-h18-w25-d34',contrast,[196,175,126],{'white':[226,224,208]},'Hasır (%85) / polipropilen (%15) · Beyaz bağlamalı'),('l42325049','2325-049-700-h55-w55-d55',rattan,[117,76,45],None,'Benekli hintkamışı · %100 rattan')]
 for code,id,make,col,second,label in specs:
  if only and only!=id:continue
  p=next(q for q in products if code in q['url']);out=R/'models'/id;out.mkdir(parents=True,exist_ok=True);meshes,gqa=make();dims=[float(v)*100 for v in gqa['dimensions_metres']];sku='/'.join(id.split('-')[:3]);mats=materials(out,col,int(id[:4]),second)
  metadata=dict(id=id,name=p['title'].capitalize(),sku=sku,url=p['url'],category='Dekoratif sepetler',dimensions_cm=dims,source_dimensions_hwd_cm=[dims[1],dims[0],dims[2]],estimated_dimensions=False,source_market='Türkiye',size_source_kind='tr_live_product',size_source_urls=[p['url']],scale_note='Resmi Türkiye dış ölçüleri kullanılmıştır; örgü lifleri, sıra sayıları, kalınlıklar ve iç detaylar resmi ürün fotoğraflarından yorumlanmıştır.',units='metres',up_axis='Y',origin='bottom bounding-box centre',source_images=p['source_images'],official_materials_verbatim=p['details'].split('MALZEMELER\n')[-1],photo_pixels_baked=False,baked_reflections=False)
  model=out/'model.json';dump(model,dict(metadata=metadata,materials=mats,meshes=meshes));dump(out/'geometry-validation.json',gqa);report=export_assets(model,out,id);glb=out/(id+'.glb');doc,bin=read_glb(glb);doc['samplers']=[dict(magFilter=9729,minFilter=9987,wrapS=10497,wrapT=10497)]
  for tex in doc.get('textures',[]):tex['sampler']=0
  write_glb(glb,doc,bin);digest=sha(glb);report['deliverable_sha256']['glb']=digest;report['glb_bytes']=glb.stat().st_size;dump(report['files']['validation'],report)
  e={k:metadata[k]for k in ['id','name','sku','url','category','dimensions_cm','source_dimensions_hwd_cm','estimated_dimensions','source_market','size_source_kind','size_source_urls','scale_note']};e.update(model_path=str(model),asset_dir=str(out),glb_path=str(glb),sha256=digest,bytes=glb.stat().st_size,material_label=label,source_images=p['source_images'],geometry_validation=str(out/'geometry-validation.json'),material_validation=str(out/'material-validation.json'),model_revision='woven-baskets-photo-v1',source_anomalies=[]);manifest.append(e);dump(R/'manifest.json',manifest);print(id,e['bytes'],gqa['triangles'],gqa['closed_strand_solids'],flush=True)
 dump(R/'qa-summary.json',dict(valid=True,count=len(manifest),total_bytes=sum(e['bytes']for e in manifest),all_dimensions_live_tr=True,all_maps_native_2k=True,original_images_inspected=12,photo_pixels_baked=False,baked_reflections=False))
if __name__=='__main__':main()
