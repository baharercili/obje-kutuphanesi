"""Append photo-specific basket masters without changing existing model bytes."""
from pathlib import Path
from urllib.parse import urlsplit
import argparse, copy, hashlib, importlib.util, json, re, shutil, sys

HERE=Path(__file__).resolve().parent
WORK=HERE.parent
ROOT=WORK.parents[1]
SITE=ROOT/'sites/zarahome-vazo-kutuphanesi-publish'
sys.path.insert(0,str(WORK))

def module(name,path):
 spec=importlib.util.spec_from_file_location(name,path);value=importlib.util.module_from_spec(spec);spec.loader.exec_module(value);return value
append=module('object_append',WORK/'objects/site_workflow.py');append.HERE=HERE
validation=module('basket_validation',WORK/'candles/site_workflow.py')
audit=module('basket_topology',WORK/'objects/audit_geometry.py')

def read(p):return json.loads(Path(p).read_text())
def write(p,value):Path(p).write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def photos(entry):
 unique={}
 for image in entry['source_images']:
  url=image['url'];u=urlsplit(url)
  assert u.scheme=='https' and u.netloc=='static.zarahome.net' and u.path.endswith('.jpg')
  # Keep the largest actually observed original for each angle; never edit pixels.
  width=int(re.search(r'[?&]w=(\d+)',url).group(1)) if re.search(r'[?&]w=(\d+)',url)else 0
  previous=unique.get(u.path)
  if previous is None or width>previous[0]:unique[u.path]=(width,image)
 preferred='-p1/'if entry['sku'].split('/')[0]in {'6670','4541','4542','7290'}else'-a7/'
 ordered=sorted([v[1]for v in unique.values()],key=lambda i:(0 if preferred in i['url']else 1 if '-p1/'in i['url']else 2,i['url']))
 assert ordered
 return [dict(url=i['url'],thumbnail_url=i['url'],source_url=i.get('source_url',i['url']),alt=i.get('alt')or entry['name'],photo_type='official_product_gallery')for i in ordered]

def record(e):
 fields=('id','name','sku','url','dimensions_cm','category','material_label','estimated_dimensions','size_source_kind','size_source_urls','source_market','scale_note')
 result={k:e[k]for k in fields}
 result.update(glb_url='/models/'+e['id']+'.glb?v='+e['sha256'],reference_images=photos(e),reference_photo_scope='product_family',reference_source_url=e['url'],reference_observed_date='2026-10-21')
 result['source_dimensions_hwd_cm']=e['source_dimensions_hwd_cm']
 return result

def reference_catalog(entries):
 category='https://www.zarahome.com/tr/dekorasyon-sepet-n997'
 products=[]
 for e in entries:
  h,w,d=e['source_dimensions_hwd_cm']
  products.append(dict(id='zarahome-'+e['id'],title=e['name'],brand='Zara Home',source_id='sepetler',source_label='Dekoratif sepetler',source_url=category,url=e['url'],product_code=e['sku'],category='Dekoratif sepetler',material_label=e['material_label'],dimensions_display=f'{h:g} × {w:g} × {d:g} cm (Y × G × D)',dimension_note='Model seçilen resmi boydadır. Fotoğraflardaki diğer boylar ve sunum aksesuarları modele dahil değildir.',images=photos(e),model_id=e['id'],model_sha256=e['sha256'],model_status='ready',status='model_ready',original_source_images_preserved=True))
 return dict(schema_version=1,updated_date='2026-10-21',model_generation_deferred=False,purpose='Zara Home ürün fotoğrafları ve malzemeli 3D modeller',products=products,sources=[dict(id='sepetler',label='Dekoratif sepetler',url=category)],original_links=[dict(label='Dekoratif sepetler',url=category)]+[dict(label=e['name'],url=e['url'])for e in entries])

def main():
 parser=argparse.ArgumentParser();parser.add_argument('manifests',nargs='+',type=Path);args=parser.parse_args()
 baseline=read(HERE/'baseline-167.json');old=baseline['manifest']['models'];assert len(old)==167
 entries=[]
 for path in args.manifests:entries+=read(path)
 assert len(entries)==len({e['id']for e in entries})
 assert not {e['id']for e in entries}&{e['id']for e in old}
 assert len({e['sku']for e in entries})==len(entries)
 checks=[];topology=[]
 research={p['sku']:p for p in read(HERE/'research-baskets.json')['products']}
 names={'3346':'Kare sepet','3563':'Dalgalı yuvarlak sepet','6670':'Orta boy dalgalı sepet','4542':'Kapaklı yuvarlak sepet','4541':'Kontrast dikdörtgen sepet','7290':'Rattan ve bambu çiçek sepeti','2325':'Kare rattan sepet','8340':'Deniz sazı sepet'}
 for e in entries:
  e['dimensions_cm']=[round(float(v),6)for v in e['dimensions_cm']]
  e['source_dimensions_hwd_cm']=[round(float(v),6)for v in e['source_dimensions_hwd_cm']]
  assert e['category']=='Dekoratif sepetler'
  assert not e['estimated_dimensions']
  assert e['source_market']=='Türkiye'
  source=research[e['sku']]
  e['name']=names[e['sku'].split('/')[0]]
  assert any([v['height_cm'],v['width_cm'],v['depth_cm']]==e['source_dimensions_hwd_cm']for v in source['dimensions'])
  e['source_images']=source['images']
  checks.append(validation.validate(e));topology.append(audit.check(e))
  model=read(e['model_path'])
  e.update(preview_geometry_quality=0,preview_color_size=256,preview_preserve_meshes=[m['name']for m in model['meshes']])
 for e in old:assert sha(SITE/'model-source'/e['filename'])==e['sha256']
 write(HERE/'root-master-validation.json',checks)
 write(HERE/'root-independent-qa.json',dict(valid=True,models=len(entries),checks=topology))
 payload=append.append_preview(baseline['preview'],entries)
 catalog=copy.deepcopy(baseline['catalog'])+[record(e)for e in entries]
 manifest=copy.deepcopy(baseline['manifest'])
 for e in entries:
  shutil.copy2(e['glb_path'],SITE/'model-source'/(e['id']+'.glb'))
  manifest['models'].append(dict(id=e['id'],name=e['name'],filename=e['id']+'.glb',accepted_filenames=[e['id']+'.glb'],bytes=e['bytes'],sha256=e['sha256'],key='models/'+e['sha256']+'.glb'))
 count=len(catalog);manifest.update(model_count=count,total_bytes=sum(e['bytes']for e in manifest['models']))
 write(SITE/'model-manifest.json',manifest);write(SITE/'ui/catalog.json',catalog);(SITE/'ui/preview.json').write_text(payload)
 references=reference_catalog(entries);write(SITE/'ui/zarahome-reference-catalog.json',references);write(HERE/'zarahome-reference-catalog.json',references)
 p=SITE/'ui/index.html';html=p.read_text();html=re.sub(r'(yeniden modellenmiş )\d+( materyalli)',lambda m:m[1]+str(count)+m[2],html);html=re.sub(r'<strong>\d+</strong><span>boy ve renk varyantı<br>\d+ kategori',f'<strong>{count}</strong><span>boy ve renk varyantı<br>11 kategori',html);html=re.sub(r'\d+ model</span>',f'{count} model</span>',html);html=html.replace('fenerler ve dekoratif objeler</p>','fenerler, dekoratif objeler ve sepetler</p>');p.write_text(html)
 write(HERE/'new-models.json',entries)
 old_library=read(WORK/'library-manifest.json');old_ids={e['id']for e in old};old_library=[e for e in old_library if e['id']in old_ids];assert len(old_library)==167
 write(HERE/f'library-manifest-{count}.json',old_library+entries)
 write(WORK/'library-manifest.json',old_library+entries)
 recipes=SITE/'asset-recipes/baskets-v1';recipes.mkdir(exist_ok=True)
 for name in ('research-baskets.json','products-observed.json','category-observed.json','site_workflow.py','root-master-validation.json','root-independent-qa.json','preview-append-validation.json','zarahome-reference-catalog.json'):
  p=HERE/name
  if p.exists():shutil.copy2(p,recipes/name)
 for path in args.manifests:
  dest=recipes/path.parent.name;dest.mkdir(exist_ok=True)
  for source in [path,*path.parent.glob('*.py'),*path.parent.glob('*validation.json'),*path.parent.glob('*qa.json')]:shutil.copy2(source,dest/source.name)
 result=dict(models=count,new_models=len(entries),preserved_models=167,categories=11,old_masters_unchanged=True,old_preview_unchanged=True,photo_references=len(references['products']))
 write(HERE/'site-integration-report.json',result);print(json.dumps(result))

if __name__=='__main__':main()
