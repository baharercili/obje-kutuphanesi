"""Reference-sheet refinements; writes new JSONs, never approved source assets."""
import copy
import json
from pathlib import Path

WORK = Path(__file__).resolve().parent
source = json.loads((WORK / 'catalog_shape_overrides.json').read_text())
facts = [line.strip().split('|') for line in (WORK / 'live-vase-facts.tsv').read_text().splitlines()]
refined = copy.deepcopy(source)

# Radii and heights are normalized; the builder applies each official W/H/D.
PROFILES = {
'46194046': [[1,0],[1,.025],[1,.94],[1,1]],
'46317046': [[.74,0],[.84,.045],[.96,.17],[1,.52],[.96,.73],[.79,.88],[.53,.92],[.53,.985],[.55,1]],
'46199046': [[.96,0],[1,.025],[1,.94],[.99,1]],
'40373046': [[.31,0],[.42,.07],[.76,.16],[.96,.31],[1,.56],[.94,.75],[.72,.9],[.39,.98],[.30,1]],
'46371046': [[.55,0],[.72,.055],[.9,.22],[1,.47],[.97,.65],[.84,.79],[.64,.88],[.56,.94],[.55,1]],
'47321043': [[.46,0],[.59,.05],[.82,.23],[.98,.48],[1,.61],[.94,.75],[.72,.9],[.43,.965],[.42,1]],
'47110046': [[.47,0],[.65,.07],[.86,.2],[.98,.39],[1,.52],[.96,.67],[.82,.83],[.55,.95],[.36,.98],[.36,.995],[.39,1]],
'45318046': [[.91,0],[.98,.025],[1,.22],[.94,.46],[.83,.66],[.55,.82],[.49,.89],[.53,.96],[.62,1]],
'46380046': [[.43,0],[.65,.065],[.92,.22],[1,.40],[.91,.59],[.69,.76],[.59,.83],[.61,.89],[.71,.97],[.67,1]],
'44335046': [[.57,0],[.76,.055],[.96,.26],[1,.55],[.94,.73],[.73,.89],[.39,.98],[.29,1]],
'41245046': [[.52,0],[.69,.05],[.91,.25],[1,.48],[.96,.65],[.78,.82],[.45,.9],[.43,.94],[.60,1]],
'47346046': [[.43,0],[.49,.018],[.43,.055],[.16,.095],[.11,.15],[.15,.20],[.21,.62],[.27,.74],[.30,.79],[.59,.84],[.87,.93],[1,1]],
'47123046': [[.67,0],[.73,.025],[.56,.075],[.44,.14],[.44,.9],[.45,1]],
'46301046': [[.53,0],[.75,.04],[.94,.20],[1,.39],[.9,.60],[.65,.79],[.39,.88],[.35,.94],[.42,1]],
'42345046': [[.32,0],[.52,.045],[.83,.17],[1,.35],[.96,.62],[.8,.87],[.65,.98],[.66,1]],
'47116046': [[.77,0],[.91,.025],[.98,.07],[1,.3],[.99,.9],[1,1]],
'40383046': [[.74,0],[.83,.028],[.73,.068],[.31,.11],[.24,.19],[.35,.25],[.66,.31],[.82,.39],[.85,.65],[.87,.86],[1,1]],
'41332046': [[.39,0],[.69,.065],[.94,.24],[1,.49],[.91,.73],[.63,.91],[.29,.98],[.27,1]],
'48372046': [[.49,0],[.63,.05],[.83,.19],[.98,.40],[1,.57],[.91,.74],[.70,.88],[.62,.94],[.69,.98],[.67,1]],
'41300748': [[.48,0],[.65,.065],[.85,.23],[1,.49],[.97,.68],[.84,.83],[.67,.92],[.74,.97],[.72,1]],
'47121046': [[.67,0],[.78,.05],[.89,.23],[1,.53],[.96,.75],[.83,.91],[.85,.97],[.91,1]],
'40370046': [[.37,0],[.57,.10],[.82,.26],[1,.43],[.84,.60],[.41,.74],[.35,.84],[.48,.96],[.57,1]],
'40371046': [[.31,0],[.53,.095],[.85,.24],[1,.36],[.79,.50],[.35,.61],[.44,.68],[.61,.77],[.50,.87],[.26,.96],[.31,1]],
'49378046': [[.58,0],[.76,.065],[.98,.27],[1,.49],[.91,.68],[.56,.79],[.39,.89],[.37,1]],
'43325046': [[.65,0],[.7,.025],[.77,.19],[.92,.56],[1,.74],[.83,.89],[.55,.97],[.54,1]],
'47117046': [[.48,0],[.65,.04],[.89,.2],[1,.48],[.93,.70],[.72,.84],[.72,.91],[.82,.98],[.80,1]],
'47112046': [[.48,0],[.66,.065],[.87,.26],[1,.52],[.94,.71],[.71,.85],[.57,.92],[.58,.96],[.76,1]],
'41346046': [[.64,0],[.78,.045],[.94,.22],[1,.48],[.96,.68],[.83,.83],[.65,.91],[.65,.97],[.74,1]],
'47355046': [[.55,0],[.68,.05],[.8,.23],[.96,.49],[1,.61],[.89,.76],[.62,.87],[.61,.95],[.71,1]],
'47118046': [[.51,0],[.68,.055],[.9,.26],[1,.5],[.96,.7],[.79,.83],[.74,.9],[.76,.97],[.8,1]],
'47122046': [[.70,0],[.81,.04],[.94,.20],[1,.52],[.97,.72],[.83,.87],[.64,.93],[.66,.98],[.74,1]],
'46195046': [[.985,0],[1,.025],[1,.95],[.995,1]],
'47302046': source['47302046']['geometry_spec']['profile'],
'47111046': source['47111046']['geometry_spec']['profile'],
'47100046': [[.55,0],[.63,.065],[.80,.28],[.96,.54],[1,.70],[.97,.83],[.87,.95],[.78,1]],
'44535043': [[.43,0],[.56,.04],[.79,.15],[1,.35],[.94,.52],[.63,.66],[.33,.73],[.32,.95],[.38,1]],
'45377046': [[.40,0],[.58,.055],[.80,.23],[.98,.52],[1,.68],[.88,.84],[.67,.94],[.76,1]],
'44536043': [[.31,0],[.41,.035],[.65,.13],[.89,.31],[1,.54],[.96,.73],[.77,.88],[.43,.96],[.43,1]],
'49395046': [[.72,0],[.86,.07],[.97,.29],[1,.53],[.91,.76],[.70,.91],[.43,.96],[.51,1]],
'47811046': source['47811046']['geometry_spec']['profile'],
'47812046': source['47812046']['geometry_spec']['profile'],
'47809046': source['47809046']['geometry_spec']['profile'],
'47817046': [[.79,0],[.86,.025],[.73,.06],[.36,.10],[.37,.17],[.5,.35],[.63,.73],[.76,.94],[.88,1]],
'47816046': [[.36,0],[.41,.03],[.38,.08],[.24,.14],[.31,.23],[.44,.42],[.66,.7],[1,1]],
'47804046': [[.81,0],[.96,.018],[.86,.04],[.36,.095],[.27,.17],[.37,.41],[.54,.76],[.62,.92],[.82,.975],[1,1]],
'47814046': [[.51,0],[.6,.025],[.52,.065],[.30,.115],[.34,.19],[.63,.30],[.78,.48],[.81,.74],[.87,.91],[1,1]],
'47815046': [[.48,0],[.59,.02],[.49,.065],[.29,.12],[.47,.21],[.8,.34],[1,.55],[.96,.76],[.70,.87],[.66,.91],[.73,.96],[1,1]],
'48311046': [[.46,0],[.57,.035],[.60,.15],[.66,.39],[.78,.65],[.90,.87],[1,1]],
'48310046': [[.54,0],[.72,.05],[.92,.22],[1,.46],[.95,.68],[.76,.81],[.50,.90],[.46,.97],[.52,1]],
'46185046': [[.54,0],[.68,.05],[.88,.24],[1,.49],[.94,.72],[.76,.88],[.49,.96],[.5,1]],
'44355046': [[.47,0],[.57,.055],[.75,.23],[.90,.48],[1,.68],[.93,.80],[.55,.88],[.43,.94],[.44,.98],[.54,1]],
'40376046': source['40376046']['geometry_spec']['profile'],
'47103046': [[.91,0],[.98,.02],[1,.13],[1,.95],[.99,1]],
'44357046': [[.46,0],[.58,.055],[.75,.24],[.91,.47],[1,.67],[.92,.8],[.54,.9],[.44,.96],[.56,1]],
'44356046': [[.49,0],[.60,.055],[.77,.23],[.92,.48],[1,.68],[.91,.82],[.54,.9],[.43,.96],[.55,1]],
'45369046': [[.27,0],[.41,.065],[.76,.21],[1,.40],[.93,.58],[.62,.75],[.43,.86],[.47,.95],[.66,1]],
'47380046': [[.55,0],[.62,.04],[.70,.25],[.79,.57],[.86,.82],[.84,.93],[1,1]],
}

FEATURES = {
'46194046': dict(shape_hint='cylinder',mouth=dict(waves=1,radial_amplitude=0,start=.10,phase=0)),
'40373046': dict(lobes=dict(count=8,amplitude=.13,start=.07,end=.98)),
'46371046': dict(organic=dict(amplitude=.006)),
'47110046': dict(shape_hint='round'),
'44335046': dict(organic=dict(amplitude=.008)),
'41245046': dict(flutes=dict(count=12,amplitude=.034,start=.04,end=.97),mouth=dict(waves=6,radial_amplitude=.06,start=.86)),
'47346046': dict(lobes=dict(count=5,amplitude=.10,start=.79,end=1),mouth=dict(waves=5,radial_amplitude=.14,start=.79)),
'47123046': dict(cross_section='rectangle',superellipse_exponent=8,radial_segments=96),
'46301046': dict(lobes=dict(count=12,amplitude=.035,start=.04,end=.98,twist_turns=.045)),
'42345046': dict(organic=dict(amplitude=.035),mouth=dict(waves=1,radial_amplitude=.07,start=.76,phase=.9)),
'47116046': dict(organic=dict(amplitude=.003)),
'41332046': dict(organic=dict(amplitude=.055),mouth=dict(waves=1,radial_amplitude=.07,start=.86)),
'48372046': dict(organic=dict(amplitude=.008)),
'41300748': dict(organic=dict(amplitude=.01)),
'47121046': dict(organic=dict(amplitude=.012)),
'40370046': dict(flutes=dict(count=18,amplitude=.06,start=.025,end=1)),
'40371046': dict(flutes=dict(count=16,amplitude=.064,start=.025,end=1)),
'49378046': dict(organic=dict(amplitude=.105,offset_x=.012),mouth=dict(waves=1,radial_amplitude=.08,start=.59,phase=1.7)),
'43325046': dict(organic=dict(amplitude=.004)),
'44535043': dict(body_width_ratio=.73,handles=dict(count=1,angles=[0],y_bottom=.45,y_top=.97),flutes=dict(count=14,amplitude=.055,start=.06,end=.67)),
'45377046': dict(organic=dict(amplitude=.008)),
'44536043': dict(body_width_ratio=.77,handles=dict(count=1,angles=[0],y_bottom=.72,y_top=.98),organic=dict(amplitude=.01)),
'49395046': dict(organic=dict(amplitude=.008)),
'47804046': dict(facets=8,flat_normals=True,radial_segments=24),
'48311046': dict(organic=dict(amplitude=.014),mouth=dict(waves=2,radial_amplitude=.025,start=.8)),
'48310046': dict(organic=dict(amplitude=.009)),
'44355046': dict(body_width_ratio=.73,handles=dict(count=2,angles=[0,180],y_bottom=.81,y_top=.975)),
'47103046': dict(flutes=dict(count=48,amplitude=.009,start=.02,end=.98),radial_segments=192),
'44357046': dict(body_width_ratio=.72,handles=dict(count=2,angles=[0,180],y_bottom=.80,y_top=.975)),
'44356046': dict(body_width_ratio=.72,handles=dict(count=2,angles=[0,180],y_bottom=.8,y_top=.975)),
'45369046': dict(mouth=dict(waves=5,radial_amplitude=.045,start=.88)),
}
HEIGHT_WAVES = {'46194046':.085,'41245046':.014,'47346046':.075,'42345046':.03,
                '41332046':.018,'49378046':.035,'48311046':.012,'45369046':.02}

for code, item in refined.items():
    old = item['geometry_spec']
    geo = dict(shape_hint=old.get('shape_hint','round'),profile=PROFILES[code],
               radial_segments=96,vertical_segments=72,profile_samples=3)
    geo.update(FEATURES.get(code,{}))
    item['geometry_spec'] = geo
    item['relative_settings'] = {}
    if code in HEIGHT_WAVES:
        item['relative_settings']['mouth_height_amplitude_fraction_of_height'] = HEIGHT_WAVES[code]
    item['reference_review'] = {'reviewed':True,'source':'local product contact sheets and official TR alt text',
                                'silhouette':'photo-reference reconstruction; normalized profile is an approximation'}
    item['needs_reference_review'] = False
    item['approximation_notes'] = [
        'Güncel ürün referansının dış silüeti ve ayırt edici ayrıntılarıyla yeniden yorumlanan modeldir; tarama veya ölçülmüş kesit değildir. Dış ölçüler resmi varyant ölçüleridir.'
    ]
    item.pop('custom_geometry_required',None)
    item.pop('assembly_required',None)

for code in ('47811046','47812046'):
    refined[code]['geometry_builder'] = 'assemble_lattice_bowl'
    refined[code]['geometry_builder_kwargs'] = {'with_lattice':True}
refined['47809046']['geometry_builder'] = 'assemble_layered_bowls'
refined['47809046']['geometry_builder_kwargs'] = {'layers':3}
for code in ('40376046','47302046','47111046'):
    if source[code].get('reuse_approved_geometry'):
        refined[code]['reuse_approved_geometry'] = source[code]['reuse_approved_geometry']
refined['41332046']['approximation_notes'].append('Fotoğrafta birden fazla küçük cam form bir arada sunuluyor; tek ürün küçük, dar açıklıklı, hafif asimetrik küresel kap olarak yorumlandı. Levha fotoğraf sahnesi olarak kabul edildi; ürünün parçası olduğu doğrulanmadı.')
refined['47116046']['surface_notes'].append('Baklava kesim izi geometriye işlenmiş sayılmaz; malzeme desen/normal haritası ile ayrıca taşınmalıdır.')
refined['49378046']['surface_notes'].append('Asimetrik omuzlar 10,5% organik modülasyon ve 12 mm yatay sapmayla yorumlandı; kesin kontur taraması değildir.')

def mat(kind,color,finish='glossy',style='plain',**kw):
    return dict(material_type=kind,color_name='',color_rgb=color,finish=finish,texture_style=style,**kw)

M = {
'46194046808':mat('metal',[193,195,192],'glossy',roughness=.065,normalScale=.06),
'46317046800':mat('ceramic',[44,42,35],'textured','rustic',roughness=.89,normalScale=.72),
'46199046802':mat('ceramic',[176,162,137],'satin','plain',roughness=.50),
'40373046779':mat('ceramic',[224,216,195],'matte','plain',roughness=.74),
'46371046802':mat('ceramic',[180,171,151],'textured','rustic',roughness=.89,normalScale=.72),
'47321043802':mat('ceramic',[182,173,153],'textured','rustic',roughness=.92,normalScale=.8),
'47110046700':mat('ceramic',[46,35,25],'glossy','plain',roughness=.075,clearcoat=.55,clearcoatRoughness=.03),
'45318046716':mat('ceramic',[42,32,27],'glossy','plain',roughness=.16),
'46380046800':mat('ceramic',[26,25,24],'satin','horizontal_bands',roughness=.55,stripe_count=56,pattern_contrast=.035),
'44335046800':mat('ceramic',[35,35,31],'textured','speckled',roughness=.80),
'41245046982':mat('glass',[168,203,176],'glossy',roughness=.027,thickness=.003,attenuationDistance=.035),
'47346046254':mat('glass',[245,249,246],'glossy',roughness=.025,thickness=.002,attenuationColor=[.97,.99,.98],attenuationDistance=.7),
'47123046990':mat('glass',[245,249,247],'glossy',roughness=.025,thickness=.002,attenuationColor=[.98,.99,.985],attenuationDistance=.8),
'46301046990':mat('glass',[241,247,240],'glossy',roughness=.028,thickness=.003,attenuationColor=[.94,.98,.94],attenuationDistance=.45),
'42345046615':mat('glass',[196,160,103],'glossy',roughness=.035,thickness=.0035,attenuationDistance=.018),
'47116046990':mat('glass',[245,249,247],'glossy',roughness=.03,thickness=.003,attenuationColor=[.98,.99,.985],attenuationDistance=.8),
'40383046514':mat('glass',[244,248,239],'glossy',roughness=.026,thickness=.004,attenuationColor=[.97,.99,.96],attenuationDistance=.5),
'41332046990':mat('glass',[245,249,247],'glossy',roughness=.029,thickness=.0025,attenuationColor=[.98,.99,.985],attenuationDistance=.8),
'48372046716':mat('terracotta',[91,63,44],'textured','rustic',roughness=.86,normalScale=.8),
'41300748500':mat('terracotta',[161,140,104],'textured','rustic',roughness=.89),
'47121046712':mat('ceramic',[191,181,153],'satin','speckled',roughness=.56),
'40370046733':mat('ceramic',[222,210,176],'satin','plain',roughness=.43),
'40371046733':mat('ceramic',[220,208,172],'satin','plain',roughness=.40),
'49378046250':mat('ceramic',[222,215,195],'matte','vertical_stripes',roughness=.74,stripe_count=72,pattern_contrast=.025),
'43325046779':mat('ceramic',[201,187,158],'matte','rustic',roughness=.78),
'47117046200':mat('ceramic',[58,106,151],'glossy','plain',roughness=.13,clearcoat=.3),
'47112046044':mat('ceramic',[23,31,38],'glossy','vertical_stripes',roughness=.105,pattern_colors=[[22,29,35],[231,223,198]],stripe_count=12,clearcoat=.4),
'41346046300':mat('ceramic',[193,153,39],'glossy','speckled',roughness=.20),
'47355046305':mat('ceramic',[169,126,57],'glossy','leaf',roughness=.25,pattern_colors=[[169,126,57],[232,221,188]],leaf_columns=8,leaf_rows=2),
'47118046701':mat('ceramic',[163,101,53],'glossy','craquelure',roughness=.18,clearcoat=.30),
'47122046712':mat('ceramic',[209,199,170],'satin','speckled',roughness=.54),
'46195046712':mat('ceramic',[185,174,147],'satin','plain',roughness=.48),
'47302046700':mat('ceramic',[163,119,64],'glossy','craquelure',roughness=.20),
'47111046700':mat('ceramic',[119,78,36],'glossy','speckled',roughness=.20),
'47111046305':mat('ceramic',[164,105,25],'glossy','craquelure',roughness=.18),
'47100046712':mat('ceramic',[211,205,186],'matte','plain',roughness=.78,normalScale=.7),
'44535043450':mat('ceramic',[191,183,151],'matte','rustic',roughness=.76),
'45377046802':mat('ceramic',[206,204,189],'matte','rustic',roughness=.77),
'44536043450':mat('ceramic',[213,204,171],'textured','rustic',roughness=.86),
'49395046250':mat('ceramic',[225,218,194],'matte','rustic',roughness=.76),
'47811046725':mat('ceramic',[230,222,171],'satin','plain',roughness=.46),
'47812046506':mat('ceramic',[181,177,133],'satin','plain',roughness=.48),
'47809046712':mat('ceramic',[222,216,184],'satin','plain',roughness=.44),
'47817046990':mat('glass',[245,249,247],'glossy',roughness=.025,thickness=.0025,attenuationColor=[.98,.99,.985],attenuationDistance=.8),
'47816046990':mat('glass',[245,249,247],'glossy',roughness=.025,thickness=.003,attenuationColor=[.98,.99,.985],attenuationDistance=.8),
'47804046808':mat('metal',[174,177,171],'satin','plain',roughness=.22,normalScale=.08),
'47814046800':mat('ceramic',[22,23,22],'matte','plain',roughness=.64),
'47815046800':mat('ceramic',[23,23,23],'matte','plain',roughness=.65),
'48311046832':mat('terracotta',[118,103,81],'textured','rustic',roughness=.88,normalScale=.75),
'48310046604':mat('ceramic',[116,127,109],'textured','rustic',roughness=.86),
'46185046712':mat('ceramic',[189,174,141],'satin','vertical_stripes',roughness=.57,stripe_count=96,pattern_contrast=.055),
'44355046600':mat('terracotta',[190,162,115],'textured','rustic',roughness=.9),
'40376046712':mat('ceramic',[191,176,139],'glossy','plain',roughness=.30),
'47103046990':mat('glass',[241,247,243],'glossy',roughness=.026,thickness=.003,attenuationColor=[.96,.99,.97],attenuationDistance=.6),
'47103046500':mat('glass',[99,139,106],'glossy',roughness=.028,thickness=.003,attenuationDistance=.045),
'44357046500':mat('terracotta',[15,69,34],'glossy','craquelure',roughness=.21,clearcoat=.3),
'44356046300':mat('terracotta',[205,180,130],'textured','rustic',roughness=.88),
'45369046250':mat('ceramic',[231,222,196],'glossy','vertical_stripes',roughness=.20,pattern_colors=[[231,223,199],[33,43,64],[203,158,72]],stripe_count=15,clearcoat=.28),
'47380046250':mat('ceramic',[228,223,204],'satin','plain',roughness=.42),
}

def band(start,end,color,roughness=None,**kw):
    return dict(start=start,end=end,color_rgb=color,**({'roughness':roughness} if roughness is not None else {}),**kw)

# Root's decoration pass consumes these additional, explicitly named recipes.
# They are intentional albedo/glaze marks, never photographed illumination.
DECORATIONS = {
'46199046802':dict(height_color_bands=[band(.79,1,[74,57,37],.48,texture_style='speckled',speckle_background_rgb=[185,166,132])]),
'45318046716':dict(height_color_bands=[band(.18,.195,[173,122,74],.22),band(.47,.485,[176,124,76],.22),band(.755,.77,[180,128,81],.22)]),
'41300748500':dict(height_color_bands=[band(.87,1,[12,73,32],.13)]),
'41346046300':dict(height_color_bands=[band(0,.065,[101,82,49],.64),band(.975,1,[68,53,30],.16)]),
'47355046305':dict(height_color_bands=[band(0,.105,[145,102,55],.78),band(.14,.15,[225,210,174],.24),band(.19,.20,[225,210,174],.24),band(.91,.925,[229,216,181],.24)],pattern_height_range=[.29,.74]),
'47111046305':dict(height_color_bands=[band(.88,1,[72,43,20],.17)]),
'44535043450':dict(height_color_bands=[band(.69,1,[116,112,85],.64)]),
'48311046832':dict(height_color_bands=[band(.84,1,[74,65,52],.86),band(0,.055,[84,72,54],.88)]),
'48310046604':dict(height_color_bands=[band(.79,1,[107,62,58],.65)]),
'46185046712':dict(height_color_bands=[band(.91,1,[159,116,64],.27)]),
'44355046600':dict(height_color_bands=[band(.83,1,[146,30,14],.13)],handle_color_rgb=[146,30,14],handle_roughness=.15,
                    vertical_edge_stripes=dict(u_positions=[0,.5],width=.012,height_range=[.1,.86],color_rgb=[146,30,14])),
'44356046300':dict(height_color_bands=[band(.84,1,[218,176,42],.15)],handle_color_rgb=[218,176,42],handle_roughness=.15,
                    wave_bands=[dict(center=h,width=.025,amplitude=.025,waves=8,color_rgb=[213,170,42],roughness=.22) for h in [.19,.42,.65,.81]]),
}

sku_notes = {line[1]:line[3] for line in facts}
COLOR_NAMES = [
'Gümüş','Siyah','Gri / kahverengi üst','Kemik rengi','Gri','Gri','Koyu kahverengi',
'Koyu kahverengi / açık çizgiler','Siyah','Siyah','Yeşil','Şeffaf','Şeffaf','Şeffaf',
'Amber','Şeffaf','Şeffaf','Şeffaf','Koyu kahverengi','Yeşil / toprak','Ekru','Krem','Krem',
'Beyaz','Bej','Mavi','Mavi / beyaz','Sarı','Hardal / beyaz','Tarçın','Krem','Ekru',
'Kahverengi','Kahverengi','Hardal','Ekru','Bej','Açık gri','Bej','Beyaz','Tereyağı',
'Haki','Ekru','Şeffaf','Şeffaf','Gümüş','Siyah','Siyah','Taupe','Gri yeşil / bordo',
'Ekru','Kırmızı / bej','Ekru / kahverengi taban','Şeffaf','Yeşil','Yeşil','Sarı / bej',
'Beyaz / lacivert / hardal','Beyaz']
assert len(COLOR_NAMES)==len(M)
color_names=dict(zip(M,COLOR_NAMES))
for sku,settings in M.items():
    settings['color_name'] = color_names[sku]
    material_name={'glass':'Cam','metal':'Metal','ceramic':'Seramik','terracotta':'Terrakota'}[settings['material_type']]
    settings['material_label'] = material_name+' · '+color_names[sku]
    if settings['material_type']=='glass':
        settings.update(transmission=1,ior=1.52,clearcoat=0,normalScale=0)
    if sku in DECORATIONS:
        settings['decoration'] = DECORATIONS[sku]
        settings['height_bands'] = [dict(min=zone['start'],max=zone['end'],color_rgb=zone['color_rgb'])
                                   for zone in DECORATIONS[sku].get('height_color_bands',[])]

assert set(PROFILES)==set(source), (set(PROFILES)^set(source))
assert set(M)==set(sku_notes), (set(M)^set(sku_notes))
for code,entry in refined.items():
    points=entry['geometry_spec']['profile']
    assert points[0][1]==0 and points[-1][1]==1
    assert all(a[1]<b[1] for a,b in zip(points,points[1:])),code
for filename,value in [('catalog_shape_refined.json',refined),('catalog_material_overrides.json',M)]:
    temporary=WORK/('.'+filename+'.tmp')
    temporary.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
    temporary.replace(WORK/filename)
print(json.dumps({'physical_forms':len(refined),'material_skus':len(M),'decoration_recipes':len(DECORATIONS)},ensure_ascii=False))
