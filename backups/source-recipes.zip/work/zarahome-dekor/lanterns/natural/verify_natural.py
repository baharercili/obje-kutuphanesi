"""Independent binary readback, including closed solids, clear glass and revision bounds."""
import hashlib,importlib.util,io,json,sys
from collections import Counter
from pathlib import Path
import numpy as np
from PIL import Image
ROOT=Path(__file__).resolve().parent;CATALOG=ROOT.parents[1];sys.path.insert(0,str(CATALOG))
from export_catalog import read_glb
loader=importlib.util.spec_from_file_location('_independent_ray_helpers',CATALOG/'bowls-trays/tray-build-wood/verify_wood.py');helpers=importlib.util.module_from_spec(loader);loader.loader.exec_module(helpers)
entries=json.loads((ROOT/'manifest.json').read_text());before=json.loads((ROOT/'before-material-v2.json').read_text());records=[]
for e in entries:
 data=Path(e['glb_path']).read_bytes();assert len(data)==e['bytes'] and hashlib.sha256(data).hexdigest()==e['sha256'];doc,binary=read_glb(e['glb_path']);points=[];triangles=[];parts=[]
 for mesh in doc['meshes']:
  for prim in mesh['primitives']:
   p=helpers.accessor(doc,binary,prim['attributes']['POSITION']);f=helpers.accessor(doc,binary,prim['indices']).reshape(-1,3).astype(np.int64);n=helpers.accessor(doc,binary,prim['attributes']['NORMAL']);uv=helpers.accessor(doc,binary,prim['attributes']['TEXCOORD_0'])
   assert np.isfinite(p).all() and np.isfinite(n).all() and np.isfinite(uv).all();assert np.max(np.abs(np.linalg.norm(n,axis=1)-1))<2e-5
   _,weld=np.unique(np.round(p,8),axis=0,return_inverse=True);edges=Counter();direction=Counter()
   for a,b,c in weld[f]:
    for x,y in [(a,b),(b,c),(c,a)]:
     pair=(min(x,y),max(x,y));edges[pair]+=1;direction[pair]+=1 if x<y else -1
   assert all(v==2 for v in edges.values()) and not any(direction.values()),(e['id'],mesh['name'])
   tri=p[f];areas=np.linalg.norm(np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]),axis=1)/2;assert areas.min()>1e-14
   volume=float(np.einsum('ij,ij->i',tri[:,0],np.cross(tri[:,1],tri[:,2])).sum()/6);assert volume>0
   parts.append({'name':mesh['name'],'triangles':len(f),'closed_after_weld':True,'consistent_winding':True,'positive_volume_m3':volume});points.append(p);triangles.append(tri)
 p=np.concatenate(points);tri=np.concatenate(triangles);actual=np.ptp(p,axis=0);assert np.allclose(actual,np.array(e['dimensions_cm'])/100,atol=2e-7);assert abs(float(p[:,1].min()))<1e-7
 hits=helpers.cavity_hits(tri,0,0);assert len(hits)>=2 and max(hits)<.012,(e['id'],hits)
 model=json.loads(Path(e['model_path']).read_text());subset=[{k:m[k] for k in ['name','positions','normals','indices']} for m in model['meshes']]
 assert hashlib.sha256(json.dumps(subset,sort_keys=True,separators=(',',':')).encode()).hexdigest()==before[e['id']]['geometry_without_uv_sha256']
 assert model['materials']['glass']==before[e['id']]['glass_definition'];assert next(m for m in model['meshes'] if m['material']=='glass')==before[e['id']]['glass_mesh']
 maps={}
 for mat in model['materials'].values():
  for key,value in mat.items():
   if key.endswith('Texture') and isinstance(value,str):maps[hashlib.sha256((Path(e['asset_dir'])/value).read_bytes()).hexdigest()]=value
 embedded=set();images=[]
 for im in doc['images']:
  assert 'uri' not in im;view=doc['bufferViews'][im['bufferView']];chunk=binary[view.get('byteOffset',0):view.get('byteOffset',0)+view['byteLength']];sha=hashlib.sha256(chunk).hexdigest();assert sha in maps;embedded.add(sha);bitmap=Image.open(io.BytesIO(chunk));assert bitmap.size in [(1024,1024),(2048,2048)];images.append({'file':maps[sha],'size':list(bitmap.size),'sha256':sha})
 assert embedded==set(maps)
 glass=next(m for m in doc['materials'] if m['name']=='glass');assert glass['extensions']['KHR_materials_transmission']['transmissionFactor']==1;assert glass['extensions']['KHR_materials_ior']['ior']==1.5;assert glass['extensions']['KHR_materials_volume']['thicknessFactor']>0;assert glass['alphaMode']=='OPAQUE'
 records.append({'id':e['id'],'bytes':len(data),'sha256':e['sha256'],'actual_dimensions_metres':actual.tolist(),'center_ray_hits_metres':hits,'cavity_clearance_metres':float(actual[1]-max(hits)),'physical_glass_transmission':1.,'native_images':images,'geometry_except_uv_unchanged':True,'glass_mesh_and_material_unchanged':True,'parts':parts});print('PASS',e['id'],len(parts),'closed meshes',flush=True)
 report={'valid':True,'count':len(records),'all_dimensions_official':True,'all_cavities_open':True,'all_embedded_maps_native_1k_or_2k':True,'all_original_geometry_except_uv_preserved':True,'all_glass_unchanged':True,'total_bytes':sum(x['bytes'] for x in records),'records':records}
(ROOT/'independent-qa.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='records'}))
