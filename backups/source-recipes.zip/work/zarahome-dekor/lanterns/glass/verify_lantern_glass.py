from pathlib import Path
import json,struct,hashlib,io
import numpy as np
from PIL import Image
from collections import Counter
R=Path(__file__).resolve().parent

def array(doc,binary,index):
 a=doc['accessors'][index];v=doc['bufferViews'][a['bufferView']];types={5126:'<f4',5125:'<u4',5123:'<u2',5121:'u1'};dims={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4};n=dims[a['type']]
 return np.frombuffer(binary,dtype=types[a['componentType']],count=a['count']*n,offset=v.get('byteOffset',0)+a.get('byteOffset',0)).reshape(-1,n)

def center_floor(positions,faces):
 # Vertical line-triangle intersections solved in the XZ plane, independent
 # of the geometry author's open-mouth claim or original meridian recipe.
 tri=positions[faces];a=tri[:,0];u=tri[:,1]-a;v=tri[:,2]-a;det=u[:,0]*v[:,2]-u[:,2]*v[:,0];mask=np.abs(det)>1e-13
 a,u,v,det=a[mask],u[mask],v[mask],det[mask]
 b=(-a[:,0]*v[:,2]+a[:,2]*v[:,0])/det;c=(-u[:,0]*a[:,2]+u[:,2]*a[:,0])/det
 ok=(b>=-1e-7)&(c>=-1e-7)&(b+c<=1+1e-7)
 ys=a[:,1]+b*u[:,1]+c*v[:,1]
 return float(ys[ok].max()) if np.any(ok) else float('-inf')

rows=[]
for e in json.loads((R/'manifest.json').read_text()):
 b=Path(e['glb_path']).read_bytes();assert len(b)==e['bytes'] and hashlib.sha256(b).hexdigest()==e['sha256'];assert struct.unpack_from('<4sII',b)==(b'glTF',2,len(b));l=struct.unpack_from('<I',b,12)[0];doc=json.loads(b[20:20+l]);binary=b[28+l:]
 meshes=[];bounds=[];svol=[];tris=0
 for m in doc['meshes']:
  for p in m['primitives']:
   v=array(doc,binary,p['attributes']['POSITION']).astype(np.float64);f=array(doc,binary,p['indices']).reshape(-1,3);n=array(doc,binary,p['attributes']['NORMAL']);uv=array(doc,binary,p['attributes']['TEXCOORD_0']);assert np.isfinite(v).all() and np.isfinite(n).all() and np.isfinite(uv).all();assert np.max(np.abs(np.linalg.norm(n,axis=1)-1))<1e-4
   _,weld=np.unique(np.round(v,7),axis=0,return_inverse=True);edges=Counter();wind=Counter()
   wf=weld[f]
   for a,c,d in wf:
    for s,t in [(a,c),(c,d),(d,a)]:key=(min(s,t),max(s,t));edges[key]+=1;wind[key]+=1 if s<t else -1
   assert all(x==2 for x in edges.values()),e['id'];assert all(x==0 for x in wind.values());areas=np.linalg.norm(np.cross(v[f[:,1]]-v[f[:,0]],v[f[:,2]]-v[f[:,0]]),axis=1)/2;assert np.min(areas)>1e-14
   volume=np.sum(v[f[:,0]]*np.cross(v[f[:,1]],v[f[:,2]]))/6;assert volume>0;svol.append(float(volume));bounds.append([v.min(axis=0),v.max(axis=0)]);meshes.append((v,f));tris+=len(f)
 lo=np.min([q[0] for q in bounds],axis=0);hi=np.max([q[1] for q in bounds],axis=0);assert np.allclose(hi-lo,np.array(e['dimensions_cm'])/100,atol=3e-8)
 floors=[center_floor(v,f) for v,f in meshes];floor=max(floors);gap=float(hi[1]-floor);assert gap>.012,(e['id'],gap)
 images=[]
 for im in doc.get('images',[]):
  assert 'uri' not in im and 'bufferView' in im;v=doc['bufferViews'][im['bufferView']];im_bytes=binary[v.get('byteOffset',0):v.get('byteOffset',0)+v['byteLength']];p=Image.open(io.BytesIO(im_bytes));assert p.size==(2048,2048);images.append({'resolution':p.size,'mime':im['mimeType']})
 glass=[m for m in doc['materials'] if 'KHR_materials_transmission' in m.get('extensions',{})];assert glass
 for m in glass:
  assert m['extensions']['KHR_materials_transmission']['transmissionFactor']>=.9;assert m['extensions']['KHR_materials_ior']['ior']==1.47;assert m['extensions']['KHR_materials_volume']['thicknessFactor']>0;assert m['alphaMode']=='OPAQUE'
 rows.append({'id':e['id'],'valid':True,'bytes':len(b),'sha256':e['sha256'],'mesh_count':len(meshes),'triangles':tris,'actual_dimensions_cm':((hi-lo)*100).tolist(),'closed_welded_and_winding_consistent':True,'positive_volumes_m3':svol,'vertical_mouth_clearance_m':gap,'embedded_native_2k_images':images,'glass_material_count':len(glass),'estimated_dimensions':e['estimated_dimensions'],'source_dimensions_hwd_cm':e['source_dimensions_hwd_cm']});print(e['id'],'PASS',len(meshes),'meshes',round(gap*100,2),'cm cavity')
(R/'independent-qa.json').write_text(json.dumps({'valid':True,'count':len(rows),'entries':rows},ensure_ascii=False,indent=2)+'\n')
