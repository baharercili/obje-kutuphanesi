from pathlib import Path
from urllib.parse import urlencode
from concurrent.futures import ThreadPoolExecutor
import json,urllib.request
ROOT=Path(__file__).resolve().parent
photos=[('a7','183f/7d4a/8553403a8645/bec9f922af69','1771430745218'),('p1','ce00/0883/120949099669/d5dc99ccb458','1740736520996'),('a1','5fc6/1ac0/a8ca4bfa9fb5/94b2d69418ab','1740736320330'),('a2','63de/430e/7c8f4627aecd/8df474242025','1740736320491'),('a3','6702/6ebc/31e14cc3bfe9/20af20140158','1740736320366'),('a4','02b8/eadc/d562424aadd7/8ebee8bd825f','1740736320580'),('a6','8983/bf49/0ea04e20b368/a2ce88dc324c','1763650725580')]
images=[{'url':f'https://static.zarahome.net//assets/public/{p}/47315436990-{v}/47315436990-{v}.jpg?'+urlencode({'ts':ts,'w':1440,'f':'jpg'}),'alt':f'BOROSİLİKAT CAM FENER VAZO · {v}','view':v}for v,p,ts in photos]
def download(im):
 p=ROOT/'references'/f'47315436990-{im["view"]}.jpg'
 if p.exists():return p.name,p.stat().st_size
 req=urllib.request.Request(im['url'],headers={'User-Agent':'Mozilla/5.0','Referer':'https://www.zarahome.com/'})
 with urllib.request.urlopen(req,timeout=40)as r:
  assert r.headers.get('Content-Type','').startswith('image/jpeg');data=r.read();p.write_bytes(data)
 return p.name,len(data)
if __name__=='__main__':
 with ThreadPoolExecutor(max_workers=6)as pool:
  for v in pool.map(download,images):print(v,flush=True)
