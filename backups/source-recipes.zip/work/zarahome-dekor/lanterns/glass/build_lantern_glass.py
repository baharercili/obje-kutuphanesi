#!/usr/bin/env python3
"""Photo-specific 7315 borosilicate lantern vase. No reference pixels baked."""
from pathlib import Path
import sys,json,hashlib,math
import numpy as np
from PIL import Image
ROOT=Path(__file__).resolve().parent;WORK=ROOT.parents[1]
sys.path.insert(0,str(WORK));sys.path.insert(0,str(WORK/'candles/glass'))
from export_catalog import export_assets,read_glb,write_glb
from vase_geometry import _finalize
from build_glass import lathe
from research_7315 import images
TAU=math.tau

def dump(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def geometry(id,w,h,d):
 R=w/2;t=.00115 if w<.1 else .00125;floor=.0026
 # A single closed glass solid encloses the physical wall and bottom while
 # retaining the real open upper cavity. The very small rounding seen in a2/a4
 # is geometry, not a painted fake edge or a dark strip in the albedo.
 path=[(0,0),(R-.0012,0),(R-.00035,.00035),(R,.0014),(R,h*.25),(R,h*.55),(R,h-t*.5)]
 for j in range(1,17):
  a=math.pi*j/16;path.append((R-t*.5+t*.5*math.cos(a),h-t*.5+t*.5*math.sin(a)))
 path.extend([(R-t,h*.55),(R-t,h*.25),(R-t,floor+.0008),(R-t-.0002,floor+.0002),(R-t-.0007,floor),(R*.55,floor),(0,floor)])
 raw=lathe(id+'-open-thinwall-borosilicate-cylinder','glass',path,radial=256,steps=4)
 points=raw['_vertices'];lo=[min(p[k]for p in points)for k in range(3)];hi=[max(p[k]for p in points)for k in range(3)];scale=[q/(b-a)for q,a,b in zip((w,h,d),lo,hi)];center=[(lo[0]+hi[0])/2,lo[1],(lo[2]+hi[2])/2]
 raw['_vertices']=[tuple((p[k]-center[k])*scale[k]for k in range(3))for p in points];mesh,qa=_finalize(raw)
 qa.update(valid=True,units='metres',up_axis='Y',origin='bottom bounding-box centre',dimensions_metres=[w,h,d],requested_wall_thickness_m=t,base_thickness_m=floor,actual_mouth_inner_diameter_m=w-2*t,mouth_open=True,overall_dimensions_official=True,local_details_photo_inferred=True,notes=['Straight clear borosilicate cylinder, circular opening, thin rounded mouth edge, small rounded bottom corner and a closed transparent floor.','No metal framing, handle, lid or candle is present in this SKU; optional styled candle in a6 is not included.','Only overall dimensions are official; glass wall and base thickness are inferred from official close-up photographs.'])
 return [mesh],qa,t

def material(out,t):
 n=2048
 # The original is plain optical glass. Intrinsic maps remain neutral; lighting
 # and dark reflection strips in product photos are deliberately not painted.
 albedo=np.full((n,n,3),255,np.uint8);orm=np.empty((n,n,3),np.uint8);orm[:]=[255,8,0];normal=np.empty((n,n,3),np.uint8);normal[:]=[128,128,255]
 names=['clear-glass-albedo-2k.png','clear-glass-orm-2k.png','clear-glass-normal-2k.png']
 for name,pix in zip(names,[albedo,orm,normal]):Image.fromarray(pix,'RGB').save(out/name,optimize=True)
 mat={'glass':dict(baseColorFactor=[1,1,1,1],metallic=0,roughness=1,baseColorTexture=names[0],metallicRoughnessTexture=names[1],normalTexture=names[2],normalScale=.025,alphaMode='OPAQUE',doubleSided=False,transmission=1.,ior=1.47,thickness=t,attenuationColor=[.985,1.,.992],attenuationDistance=1.,extras={'native_resolution':2048,'intrinsic_material':'plain clear borosilicate glass','photo_pixels_baked':False,'baked_reflections':False,'local_material_properties_photo_inferred':True})}
 qa={'valid':True,'native_resolution':[n,n],'all_maps_native_2k':True,'photo_pixels_baked':False,'baked_reflections':False,'AO_white':True,'roughness_from_ORM_G':8/255,'metallic_from_ORM_B':0,'transmission':1,'ior':1.47,'thickness_m':t,'maps':{name:{'bytes':(out/name).stat().st_size,'sha256':sha(out/name),'dimensions':[n,n],'mode':'RGB'}for name in names}}
 dump(out/'material-validation.json',qa);return mat,qa

def main():
 research=json.loads((ROOT/'research.json').read_text());p=research['products'][0];manifest=[]
 assert p['sku']=='7315/436/990' and p['variants']
 for v in p['variants']:
  id=v['id'];w,h,d=[v[k]/100 for k in ('width_cm','height_cm','depth_cm')];out=ROOT/'models'/id;out.mkdir(parents=True,exist_ok=True);meshes,gqa,t=geometry(id,w,h,d);materials,mqa=material(out,t)
  metadata={'id':id,'name':p['name'],'sku':p['sku'],'url':p['official_url'],'category':'Dekoratif fenerler','dimensions_cm':[v['width_cm'],v['height_cm'],v['depth_cm']],'source_dimensions_hwd_cm':[v['height_cm'],v['width_cm'],v['depth_cm']],'estimated_dimensions':False,'overall_dimensions_official':True,'local_details_photo_inferred':True,'units':'metres','up_axis':'Y','origin':'bottom bounding-box centre','source_images':p['images'],'scale_note':v['scale_note'],'source_market':v['source_market'],'size_source_kind':v['size_source_kind'],'size_source_urls':v['size_source_urls'],'photo_pixels_baked':False,'baked_reflections':False,'material_note':'Clear glass with native 2K intrinsic maps and glTF transmission/volume/IOR. A6 styled candle is excluded from the exported product.'}
  model=out/'model.json';dump(model,dict(metadata=metadata,materials=materials,meshes=meshes));dump(out/'geometry-validation.json',gqa);report=export_assets(model,out,id);glb=out/(id+'.glb');doc,binary=read_glb(glb);doc['samplers']=[dict(magFilter=9729,minFilter=9987,wrapS=10497,wrapT=33071)]
  for tex in doc.get('textures',[]):tex['sampler']=0
  write_glb(glb,doc,binary);digest=sha(glb);size=glb.stat().st_size;report['deliverable_sha256']['glb']=digest;report['glb_bytes']=size;dump(report['files']['validation'],report)
  entry={k:metadata[k]for k in ('id','name','sku','url','category','dimensions_cm','source_dimensions_hwd_cm','estimated_dimensions','source_market','size_source_kind','size_source_urls','scale_note')}
  entry.update(model_path=str(model),asset_dir=str(out),glb_path=str(glb),sha256=digest,bytes=size,material_label='Borosilikat cam · Şeffaf',source_images=p['images'],geometry_validation=str(out/'geometry-validation.json'),material_validation=str(out/'material-validation.json'),model_revision='lantern-7315-photo-v1',source_anomalies=[])
  manifest.append(entry);print(id,size,gqa['triangles'],flush=True)
 dump(ROOT/'manifest.json',manifest);dump(ROOT/'qa-summary.json',{'valid':True,'count':len(manifest),'total_bytes':sum(e['bytes']for e in manifest),'all_dimensions_official':True,'all_maps_native_2k':True,'all_original_gallery_images_inspected':True,'native_scene_preview_is_form_only':True})
if __name__=='__main__':main()
