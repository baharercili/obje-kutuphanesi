from pathlib import Path
import json,struct,hashlib,io
import numpy as np
from PIL import Image
R=Path(__file__).resolve().parent
rows=json.loads((R/'manifest.json').read_text());assert len(rows)==15
ids=set();images=0;primitives=0;max_error=0;report=[]
def accessor(doc,binary,index):
 a=doc['accessors'][index];view=doc['bufferViews'][a['bufferView']];count=a['count'];width={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}[a['type']];dt={5126:'<f4',5125:'<u4',5123:'<u2',5121:'u1'}[a['componentType']];dtype=np.dtype(dt);stride=view.get('byteStride',dtype.itemsize*width);off=view.get('byteOffset',0)+a.get('byteOffset',0)
 return np.ndarray((count,width),dtype=dtype,buffer=binary,offset=off,strides=(stride,dtype.itemsize)).copy()
for e in rows:
 assert e['id']not in ids;ids.add(e['id']);f=Path(e['glb_path']);b=f.read_bytes();assert len(b)==e['bytes']and len(b)<=40_000_000;digest=hashlib.sha256(b).hexdigest();assert digest==e['sha256'];magic,ver,length=struct.unpack_from('<4sII',b);assert magic==b'glTF'and ver==2 and length==len(b);jl,jt=struct.unpack_from('<I4s',b,12);doc=json.loads(b[20:20+jl]);bl,bt=struct.unpack_from('<I4s',b,20+jl);binary=b[28+jl:];assert bt==b'BIN\0'and len(binary)==bl
 for im in doc['images']:
  assert 'uri'not in im;v=doc['bufferViews'][im['bufferView']];off=v.get('byteOffset',0);px=Image.open(io.BytesIO(binary[off:off+v['byteLength']]));assert px.size==(2048,2048)and px.format=='PNG';images+=1
 points=[];triangles=0
 for m in doc['meshes']:
  for p in m['primitives']:
   assert {'POSITION','NORMAL','TEXCOORD_0'}<=set(p['attributes']);v=accessor(doc,binary,p['attributes']['POSITION']).astype(float);n=accessor(doc,binary,p['attributes']['NORMAL']).astype(float);uv=accessor(doc,binary,p['attributes']['TEXCOORD_0']).astype(float);ff=accessor(doc,binary,p['indices']).reshape(-1,3);points.append(v);assert np.isfinite(v).all()and np.isfinite(n).all()and np.isfinite(uv).all();assert np.abs(np.linalg.norm(n,axis=1)-1).max()<1e-6
   a=uv[ff[:,1]]-uv[ff[:,0]];c=uv[ff[:,2]]-uv[ff[:,0]];area=np.abs(a[:,0]*c[:,1]-a[:,1]*c[:,0])/2;assert (area>1e-14).all(),(e['id'],m['name'],'UV')
   tri=v[ff];cross=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]);assert (np.linalg.norm(cross,axis=1)>2e-14).all();volume=float(np.einsum('ij,ij->i',tri[:,0],np.cross(tri[:,1],tri[:,2])).sum()/6);assert volume>0
   _,weld=np.unique(v,axis=0,return_inverse=True);wf=weld[ff];directed=np.concatenate([wf[:,[0,1]],wf[:,[1,2]],wf[:,[2,0]]]);edges=np.sort(directed,axis=1);_,inv,counts=np.unique(edges,axis=0,return_inverse=True,return_counts=True);assert (counts==2).all();direction=np.where(directed[:,0]<directed[:,1],1,-1);balance=np.bincount(inv,weights=direction);assert (balance==0).all();triangles+=len(ff);primitives+=1
 allpoints=np.concatenate(points);lo=allpoints.min(0);hi=allpoints.max(0);err=float(np.max(np.abs(hi-lo-np.array(e['dimensions_cm'])/100)));max_error=max(err,max_error);assert err<1e-6 and abs(lo[1])<1e-8 and abs(hi[0]+lo[0])<1e-8 and abs(hi[2]+lo[2])<1e-8
 assert doc['extras']['metadata']['dimensions_cm']==e['dimensions_cm']and not e['estimated_dimensions'];export=json.loads(f.with_suffix('.validation.json').read_text());assert export['deliverable_sha256']['glb']==digest and export['source_sha256']==hashlib.sha256(Path(e['model_path']).read_bytes()).hexdigest();assert e['source_images']and all(im['url'].startswith('https://static.zarahome.net/')for im in e['source_images'])
 q=json.loads(Path(e['geometry_validation']).read_text());assert q['valid']and q['degenerate_uv_triangles']==0 and all(m['closed_after_uv_seam_weld']and m['consistent_winding']and m['signed_volume_m3']>0 for m in q['meshes']);report.append(dict(id=e['id'],glb_bytes=len(b),triangles=triangles,binary_bounds_error_m=err,closed_welded_edges=True,winding_consistent=True,positive_component_volumes=True))
sources=json.loads((R/'reference-downloads.json').read_text());masters=[]
for s in sources:
 f=Path(s['local_master']);assert hashlib.sha256(f.read_bytes()).hexdigest()==s['sha256'];im=Image.open(f);assert list(im.size)==s['pixel_dimensions'];masters.append(dict(path=str(f),source_url=s['url'],sha256=s['sha256'],pixel_dimensions=list(im.size),format=im.format,mode=im.mode,icc_present=bool(im.info.get('icc_profile')),original_unchanged=True))
(R/'source-image-master-inventory.json').write_text(json.dumps(masters,ensure_ascii=False,indent=2)+'\n')
coverage=json.loads((R/'card-coverage.json').read_text());assert len(coverage['cards'])==17 and coverage['all_cards_covered'];assert sum(bool(c['new_model_ids'])for c in coverage['cards'])==13;assert not json.loads((R/'needs-measurement.json').read_text())
result=dict(valid=True,models_verified=15,unique_ids=len(ids),unique_skus=len({e['sku']for e in rows}),embedded_2048_png_images_verified=images,mesh_primitives_verified=primitives,maximum_binary_bounds_error_m=max_error,total_glb_bytes=sum(e['bytes']for e in rows),maximum_glb_bytes=max(e['bytes']for e in rows),source_master_files=len(masters),all_recorded_source_master_hashes_unchanged=True,all_manifest_and_export_hashes_match=True,all_glb_binary_topology_uv_normal_bounds_checks_pass=True,full_category_card_count=17,category_cards_with_existing_models=4,category_cards_with_new_models=13,category_cards_without_any_model=0,needs_measurement_records=0,per_model=report,visual_review_file='all-models-comparison.png',limitations=['Subcomponent thickness, curve and finish detail is reconstructed from official photos, with overall dimensions officially measured.','Each component is a closed2-manifold with consistent winding and positive volume; inter-component Boolean intersections are not tested.'])
(R/'final-validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k not in['per_model','limitations']},ensure_ascii=False,indent=2))
