from pathlib import Path
import json,hashlib
import numpy as np
from PIL import Image
R=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def components(mesh):
 pos=np.array(mesh['positions']).reshape(-1,3);_,idx=np.unique(np.round(pos,8),axis=0,return_inverse=True);parent=list(range(idx.max()+1))
 def find(x):
  while parent[x]!=x:parent[x]=parent[parent[x]];x=parent[x]
  return x
 for face in np.array(mesh['indices']).reshape(-1,3):
  a,b,c=idx[face];parent[find(b)]=find(a);parent[find(c)]=find(a)
 return len({find(i)for i in range(len(parent))})
a=json.loads((R/'manifest.json').read_text());source=json.loads((R/'resolved-source-inventory.json').read_text());order={p['url']:i for i,p in enumerate(source)};a.sort(key=lambda e:order[e['url']]);dump(R/'manifest.json',a)
qa=json.loads((R/'independent-validation.json').read_text());assert qa['valid']and qa['models']==12 and qa['all12_missing_cards_covered'];assert len(a)==12 and len({e['url']for e in a})==12;assert not json.loads((R/'pending.json').read_text());bindings=json.loads((R/'existing-model-bindings.json').read_text());assert len(bindings)==5 and all(sha(b['glb_path'])==b['sha256']for b in bindings)
checks=[];files=[];construction=[]
for e in a:
 out=Path(e['asset_dir']);assert sha(e['glb_path'])==e['sha256'];views=[]
 for view in['on','on-capraz','ustten']:
  p=out/(view+'.png');im=Image.open(p);assert im.size==(900,900)and im.mode=='RGBA';views.append(dict(path=str(p),sha256=sha(p),pixels=[900,900]))
 model=json.loads(Path(e['model_path']).read_text());geo=json.loads((out/'geometry-validation.json').read_text());names=[m['name']for m in model['meshes']];checks.append(dict(id=e['id'],valid=True,official_photo_url=e['source_images'][0]['url'],official_photo_unchanged=True,views=views,photo_specific_features=geo['features'],exterior_axes_match_official=True,local_construction_photo_interpreted=True,photo_pixels_baked=False,baked_reflections=False))
 record=dict(id=e['id'],closed_parts=len(names),valid=True)
 if e['family_path_code']=='41365073':
  assert any('full-square-oak-upper-plinth'in n for n in names)and any('recessed-square-oak-bearing-base'in n for n in names);stitches=[m for m in model['meshes']if'separate-double-row-leather-stitch'in m['name']];stitch_count=sum(components(m)for m in stitches);assert stitch_count==640;assert model['materials']['ecru_leather']['extras']['fabric_kind']=='leather';record.update(real_leather_cushion=True,real_double_row_stitches=stitch_count,separate_two_level_wood_base=True,related_product_photos_excluded=True)
 elif e['family_path_code']in['48323073','48347073']:
  assert any('actual-long-horizontal-upper-seam'in n for n in names)and any('stitched-bottom-cloth-hem'in n for n in names);record.update(real_seams_and_hem=True,physical_washed_linen=True,distinct_fixed_and_removable_cover_family=True)
  if e['family_path_code']=='48347073':assert any('small-unprinted-woven-cover-label'in n for n in names);record['separate_cover_label']=True
 else:assert any('genuine-upper-panel-belt-seam'in n for n in names);record['rounded_small_pouf_with_real_sewn_belt']=True
 construction.append(record)
 for p in[Path(e['glb_path']),Path(e['model_path']),out/(e['id']+'.scn'),out/'geometry-validation.json',out/'material-validation.json',out/'topology-validation.json',out/'on.png',out/'on-capraz.png',out/'ustten.png']:
  assert p.exists();files.append(dict(path=str(p),sha256=sha(p),bytes=p.stat().st_size))
previous=[]
for name in['mirror-models','box-models','basket-size-models','side-table-models','stool-models']:
 frozen=json.loads((R.parent/name/'frozen-delivery.json').read_text());assert all(sha(q['path'])==q['sha256']for q in frozen['deliverables']);previous.append(dict(folder=name,files=len(frozen['deliverables']),all_unchanged=True))
refs=json.loads((R/'reference-masters.json').read_text());details=json.loads((R/'detail-photo-masters.json').read_text());assert len(refs)==17 and all(sha(q['local_master'])==q['sha256']for q in refs);assert len(details)==20 and all(sha(q['path'])==q['sha256']for q in details)
base=json.loads((R.parent/'baseline-409.json').read_text());old={e['id']:e for e in base['manifest']['models']};collisions=[e['id']for e in a if e['id']in old];assert not collisions
for binding in bindings:
 if binding['model_id']in old:assert binding['sha256']==old[binding['model_id']]['sha256']
cat=json.loads((R/'official-category-17-cards.json').read_text());coverage=[]
for p in cat['products']:
 built=[e['id']for e in a if e['url']==p['url']];bound=[e['model_id']for e in bindings if e['url']==p['url']];assert bool(built)!=bool(bound);correct=next(q for q in source if q['url']==p['url']);coverage.append(dict(card_index=p['card_index'],title=correct['title'],url=p['url'],sku=correct['sku'],previous_model_ids=p['matched_model_ids'],new_model_ids=built,shared_model_ids=bound,covered=True))
corrections=[dict(url=p['url'],actual_sku=p['sku'],raw_photo_code=p['image_code'],note=p['source_anomalies'],source_evidence=str(R/'tr-live-product-details-frozen.json'))for p in source if p['source_anomalies']]
corrections.append(dict(actual_sku='6195/073/515',preserved_legacy_model_id='4619-073-515-h35-w72-d53',raw_photo_code='46195073515',note='Current Turkish copy-code button confirms6195; explicit catalog alias preserves the original physical model and its checksum.',source_evidence=str(R/'tr-live-product-details-frozen.json')));dump(R/'identity-corrections.json',corrections)
dump(R/'construction-validation.json',dict(valid=True,checks=construction))
visual=dict(valid=True,new_models=12,new_card_photographs=12,existing_shared_card_photographs=5,preview_pngs=36,native_scenes=12,comparisons=[str(p)for p in sorted(R.glob('comparison-*.png'))],reviewed_comparisons=True,source_photos_unchanged=True,detail_photos_reviewed=20,features=['Compact velvet and linen/cotton families retain distinct intrinsic yarn/nap surfaces and physically sewn corner joins','Actual8323 fixed washed-linen upholstery and8347 removable covers use different upper seams, hems and cover details','SOFA02 is a genuine leather-cushion interpretation on a two-level wooden base, with640 individual double-row stitches; no unrelated sofa modules or books'],limitations=['Exterior dimensions and actual color SKU identities are verified; local seam, filling, concealed feet and wood thickness are photographic interpretations rather than factory CAD','Three original409 models remain physically unchanged; the green velvet uses an explicit6195-to-legacy4619 catalog alias','Two official stool footrests share their frozen physical masters across Puflar and Tabureler'],checks=checks);dump(R/'visual-validation.json',visual)
dump(R/'category-completeness.json',dict(valid=True,official_card_count=17,source_cards=17,previous_existing_cards=3,shared_stool_cards=2,new_missing_cards_covered=12,all17_cards_covered=True,new_glb_assets=12,official_size_variants=12,pending=0,coverage=coverage));dump(R/'previous-frozen-deliveries-validation.json',dict(valid=True,checks=previous,existing_409_pouf_models_unchanged=True))
queue=json.loads((R/'measurement-needs.json').read_text());dump(R/'measurement-needs-resolved.json',[dict(q,status='resolved',needs_identity=False,needs_measurement=False,resolution_source=str(R/'tr-live-product-details-frozen.json'))for q in queue])
for p in[R/'manifest.json',R/'independent-validation.json',R/'visual-validation.json',R/'category-completeness.json',R/'construction-validation.json',R/'existing-model-bindings.json',R/'identity-corrections.json',R/'resolved-source-inventory.json',R/'tr-live-product-details-frozen.json',R/'reference-masters.json',R/'detail-photo-masters.json',R/'comparison-provenance.json']+sorted(R.glob('comparison-*.png')):files.append(dict(path=str(p),sha256=sha(p),bytes=p.stat().st_size))
(R/'report.md').write_text('''# Puflar · Tam kategori teslimi

Resmî17 kartın tamamı kapsanır:12 yeni model, korunmuş3 özgün master ve tabure kategorisinden2 aynı fiziksel ürüne çapraz bağlantı. Bekleyen kimlik veya ölçü yoktur. Üç ürünlük seçki yapılmadı;12 eksik kartın12 doğrulanmış resmî ölçüsü üretildi.

Soluk efektli keten ürününün resmî kopyala-kod düğmesi8323/073/701,/922,/251,/052 verir. URL48323073 ve fotoğraf48333073 kodları ayrı kaynak bilgisi olarak saklanır.8347 çıkarılabilir kılıflı ailenin dört eksik rengi ve8323 sabit döşemeli ailenin dört rengi ayrı gerçek SKU'lardır. Yeşil kadifenin güncel6195/073/515 kimliği eski4619-073-515-h35-w72-d53 masterına açık katalog aliasıyla bağlanır; fiziksel master değişmez.

Kompakt puflarda yuvarlatılmış dolgu, gerçek üst dikiş kuşağı, köşe birleşimleri ve gömülü küçük ahşap ayaklar bulunur. Keten ailelerin dikiş konumu, kılıf eteği, alt kıvırma ve küçük etiketi farklıdır. SOFA02 resmî sayfadaki ekru deri ve ahşap tabanla kuruldu; iki sıra toplam640 ayrı dikiş, yumuşak gerçek deri kıvrımı ve iki seviyeli ahşap kaide vardır. İlişkili koltukların fotoğrafları modele karışmadı.

Her GLB yerel2K PBR albedo/normal/ORM kaplamalarını gömülü taşır; tekstillerin fiziksel sheen parametreleri glTF uzantısındadır.12 model.json,12 yerel sahne,36 şeffaf900px önizleme ve3 resmî fotoğraf karşılaştırması vardır.17 kaynak fotoğraf ile20 galeri yakını değiştirilmedi; fotoğraf pikselleri ve yansımaları malzemeye işlenmedi.

Tüm modeller resmî dış ölçü, merkez/orijin, kapalı pozitif topoloji, float32 sonrası UV, birim normal, teğet ve gömülü2K denetimlerinden geçti. Yerel kesit, dolgu ve görünmeyen bağlantılar üretici CAD verisi değil, fotoğraf yorumudur. Önceki78 dondurulmuş model ve özgün3 puf masterının hashleri değişmeden doğrulandı.
''')
dump(R/'frozen-delivery.json',dict(status='frozen',date='2026-10-21',official_category_cards=17,previous_existing_cards=3,shared_stool_cards=2,new_missing_cards=12,new_cards_modeled=12,new_glb_assets=12,official_size_variants=12,pending=0,all_known_official_measurements_built=True,manifest=str(R/'manifest.json'),independent_qa=str(R/'independent-validation.json'),visual_qa=str(R/'visual-validation.json'),construction_qa=str(R/'construction-validation.json'),category_completeness=str(R/'category-completeness.json'),source_inventory=str(R/'resolved-source-inventory.json'),shared_model_bindings=str(R/'existing-model-bindings.json'),source_photos_unchanged=True,previous_78_models_unchanged=True,baseline_409_id_collisions=collisions,deliverables=files));print('FROZEN',len(a),'new assets',len(files),'core files; category17/17')
