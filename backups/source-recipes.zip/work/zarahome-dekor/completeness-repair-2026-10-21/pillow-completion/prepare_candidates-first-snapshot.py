"""All newly verified cushion sizes; exact SKU+size deduplication, no cap."""
from pathlib import Path
import json,re,hashlib
P=Path(__file__).resolve().parent;N=P.parent;ROOT=N.parents[2]
write=lambda p,x:Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
raw=(N/'live-product-details-from-root.json').read_bytes();rows=json.loads(raw);existing={}
def plan(s):
 n=[float(x.replace(',','.'))for x in re.findall(r'\d+(?:[.,]\d+)?',s)]
 return tuple(sorted(n))if len(n)==2 else None
def key(sku,p):return sku+'|'+','.join(format(v,'g')for v in p)
initial=json.loads((N/'pillow-expansion/preparation-manifest.json').read_text())
for p in initial['products']:
 for size in p['official_size_labels']:existing[key(p['sku'],plan(size))]='pillow-expansion'if p['new_model_needed']else'previous-model'
for e in json.loads((N/'pillows/manifest.json').read_text()):
 existing[key(e['sku'],tuple(sorted(e['dimensions_cm'][:2])))]=e['id']
latest={}
for index,r in enumerate(rows):
 if not r.get('sku'):continue
 hwd=r.get('source_dimensions_hwd_cm')
 if not hwd:
  match=re.search(r'Yükseklik\s+Genişlik\s+Derinlik\s+(\d+(?:[.,]\d+)?)\s*cm\s+(\d+(?:[.,]\d+)?)\s*cm\s+(\d+(?:[.,]\d+)?)\s*cm',r.get('text',''),re.I)
  if match:hwd=[float(v.replace(',','.'))for v in match.groups()]
 if hwd:r=dict(r,source_dimensions_hwd_cm=hwd)
 if not r.get('cover_size_labels')and not hwd:continue
 if not re.fullmatch(r'\d{4}/\d{3}/\d{3}',r['sku']):continue
 latest[r['sku']]=(index,r)
# Merge later gallery repairs only for the same explicitly observed exact SKU.
galleries={}
for index,r in enumerate(rows):
 sku=r.get('sku')
 if not sku:
  codes=list(dict.fromkeys(re.findall(r'\d{4}/\d{3}/\d{3}',r.get('text',''))))
  sku=codes[0]if len(codes)==1 else None
 if sku and r.get('gallery_images'):
  old=galleries.get(sku)
  if old is None or len(r['gallery_images'])>=len(old[1]['gallery_images']):galleries[sku]=(index,r)
products=[];queue=[];targets=[];pending=[]
for sku,(index,r)in latest.items():
 labels=list(dict.fromkeys(s for s in r.get('cover_size_labels',[])if plan(s)))
 variants=[dict(key=key(sku,plan(s)),official_label=s,cover_sides_cm=list(plan(s)),source_url=r['url'],new_model_needed=key(sku,plan(s))not in existing,existing_model_group=existing.get(key(sku,plan(s))))for s in labels]
 if r.get('source_dimensions_hwd_cm'):
  hwd=r['source_dimensions_hwd_cm'];h,w,d=hwd;label=' × '.join(format(v,'g')for v in hwd)+' cm (Y × G × D)';variant_key=sku+'|HWD:'+','.join(format(v,'g')for v in hwd)
  variants.append(dict(key=variant_key,official_label=label,source_dimensions_hwd_cm=hwd,source_url=r['url'],new_model_needed=True,existing_model_group=None))
 gallery_index,gallery_record=galleries.get(sku,(index,r));gallery=gallery_record.get('gallery_images',[]);photos=[]
 for im in gallery:
  u=im.get('url')or im.get('src')
  if not u:continue
  if 'w=1024'not in u and any('w=1024'in(a.get('url')or'')and(a.get('url')or'').split('?')[0]==u.split('?')[0]for a in gallery):continue
  if any(a['url']==u for a in photos):continue
  filename=u.split('?')[0].split('/')[-1];dest=P/'products'/sku.replace('/','-')/'originals'/('official-'+hashlib.sha256(u.encode()).hexdigest()[:8]+'-'+filename)
  photo=dict(url=u,alt=im.get('alt',''),source_file=str(N/'live-product-details-from-root.json'),source_record_index=gallery_index,local_master=str(dest),role='official_live_zoom_gallery');photos.append(photo);queue.append(dict(sku=sku,product_id=sku.replace('/','-'),**photo))
 has_front=any('-p1.jpg'in x['url']for x in photos);need=any(v['new_model_needed']for v in variants)
 title=r.get('title','');product_kind='cover_sheet'if any(term in title.casefold()for term in['örtü','koltuk örtüsü','throw'])else'thin_filled_mat'if'şilte'in title.casefold()else'inner_filler'if'dolgu'in title.casefold()else'cushion_cover'if'kılıf'in title.casefold()or re.search(r'k[i]*l[i]*f',title.casefold().replace('ı','i').replace('\u0307',''))else'filled_cushion_requires_form_review'
 p=dict(id=sku.replace('/','-'),product_kind=product_kind,sku=sku,title=r.get('title',''),url=r['url'],official_size_labels=labels,source_dimensions_hwd_cm=r.get('source_dimensions_hwd_cm'),variants=variants,new_model_needed=need,photos=photos,source_record_index=index,source_capture_sha256=hashlib.sha256(json.dumps(r,ensure_ascii=False,sort_keys=True).encode()).hexdigest(),official_text=r.get('text',''),review_status='needs_per_product_visual_review',front_reference_available=has_front,model_status='queued'if need else'already_modeled',quality_pending=[]if has_front else['needs_unobstructed_front_reference'],source_size_note='Every listed side pair is explicitly observed in this same exact SKU live capture. No size transferred from a related SKU.')
 products.append(p)
 for v in variants:
  if v['new_model_needed']:targets.append(dict(sku=sku,title=p['title'],url=p['url'],**v))
 if need and not has_front:pending.append(dict(sku=sku,url=r['url'],photos=len(photos),reason='No complete P1 front in supplied gallery; retain category photograph and request source repair.'))
 out=P/'products'/p['id'];out.mkdir(exist_ok=True,parents=True);write(out/'product.json',p)
summary=dict(live_capture_products=len(products),verified_size_variants=sum(len(p['variants'])for p in products),new_products=sum(p['new_model_needed']for p in products),new_sku_size_targets=len(targets),already_modeled_variants=sum(not v['new_model_needed']for p in products for v in p['variants']),original_photo_urls=len(queue),needs_front_reference_products=len(pending),per_category_cap=None,models_generated=0,source_snapshot_sha256=hashlib.sha256(raw).hexdigest(),scope='All new same-SKU verified size labels received so far, including multi-size variants; this snapshot grows with root captures.')
write(P/'candidate-inventory.json',dict(summary=summary,products=products));write(P/'new-size-targets.json',targets);write(P/'download-queue.json',queue);write(P/'quality-pending-source.json',pending);write(P/'source-snapshot.json',rows)
print(json.dumps(summary,ensure_ascii=False))
