"""Every exact SKU/size from all live cards, including later repairs and composites."""
from pathlib import Path
from urllib.parse import urlsplit,parse_qs
import json,re,hashlib,copy
P=Path(__file__).resolve().parent;N=P.parent;ROOT=N.parents[2]
write=lambda p,x:Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
raw=(N/'live-product-details-from-root.json').read_bytes();rows=json.loads(raw)
SIZE=r'(?<![\d×xX])(\d+(?:[.,]\d+)?)\s*[×xX]\s*(\d+(?:[.,]\d+)?)\s*cm'
def plan(s):
 n=[float(x.replace(',','.'))for x in re.findall(r'\d+(?:[.,]\d+)?',s)]
 return tuple(sorted(n))if len(n)==2 else None
def key(sku,p):return sku+'|'+','.join(format(v,'g')for v in p)
def urlkey(u):
 q=urlsplit(u or'');pe=parse_qs(q.query).get('pelement');return'pelement:'+pe[0]if pe else q.path.rstrip('/')
def codes(r):return list(dict.fromkeys(re.findall(r'\b\d{4}/\d{3}/\d{3}\b',r.get('text',''))))
def hwd(r):
 if r.get('source_dimensions_hwd_cm'):return r['source_dimensions_hwd_cm']
 m=re.search(r'Yükseklik(?:\([^)]*\))?\s+Genişlik(?:\([^)]*\))?\s+Derinlik(?:\([^)]*\))?\s+(\d+(?:[.,]\d+)?)\s*cm\s+(\d+(?:[.,]\d+)?)\s*cm\s+(\d+(?:[.,]\d+)?)\s*cm',r.get('text',''),re.I)
 return[float(v.replace(',','.'))for v in m.groups()]if m else None
def image_code(u):
 name=(u or'').split('?')[0].split('/')[-1];return name.split('-')[0]if name else None
initial=json.loads((N/'pillow-expansion/preparation-manifest.json').read_text());existing={};url_skus={};code_skus={}
for p in initial['products']:
 for size in p['official_size_labels']:existing[key(p['sku'],plan(size))]='pillow-expansion'if p['new_model_needed']else'previous-model'
 url_skus.setdefault(urlkey(p['url']),set()).add(p['sku'])
 for im in p['photos']:code_skus.setdefault(image_code(im['url']),set()).add(p['sku'])
for e in json.loads((N/'pillows/manifest.json').read_text()):existing[key(e['sku'],tuple(sorted(e['dimensions_cm'][:2])))]=e['id']
for r in rows:
 c=codes(r);s=r.get('sku')or(c[0]if len(c)==1 else None)
 if s:
  url_skus.setdefault(urlkey(r.get('url')),set()).add(s)
  for im in r.get('gallery_images',[]):code_skus.setdefault(image_code(im.get('url')or im.get('src')),set()).add(s)
category_inventory=json.loads((N/'furniture-textile/inventory.json').read_text())
category_cards=next(c['products']for c in category_inventory['categories']if c['category']=='Kırlentler')
category_urls={urlkey(p['url'])for p in category_cards}
for card in category_cards:
 if card.get('sku'):
  url_skus.setdefault(urlkey(card['url']),set()).add(card['sku'])
  if card.get('image_code'):code_skus.setdefault(card['image_code'],set()).add(card['sku'])
card_by_url={urlkey(p['url']):p for p in category_cards}
def in_scope(sku,r):
 return (sku and(sku.startswith('IMG')or('/'in sku and sku.split('/')[1]in['008','009'])))or(sku in['1392/073/800','5152/073/700']and urlkey(r.get('url'))in category_urls)
records={};unresolved=[];composites=[]
def add(sku,r,index,kind='explicit_sku',letter=None):
 if not in_scope(sku,r):return
 labels=list(dict.fromkeys(s for s in r.get('cover_size_labels',[])+r.get('official_plan_size_labels',[])if plan(s)));dims=hwd(r)
 if not labels and not dims:return
 rec=records.setdefault(sku,dict(sku=sku,title=r.get('title',''),url=r['url'],labels={},hwd=None,source_records=[],galleries=[],official_text=r.get('text',''),identity_evidence=kind,monogram_character=letter))
 if index is not None:rec['source_records'].append(index)
 if r.get('title'):rec['title']=r['title']
 if r.get('text'):rec['official_text']=r['text']
 if dims:rec['hwd']=dims
 if letter:rec['monogram_character']=letter
 for s in labels:rec['labels'][s]=dict(label=s,source_url=r['url'],source_record_index=index)
 for im in r.get('gallery_images',[]):
  u=im.get('url')or im.get('src')
  if u and not any(x['url']==u for x in rec['galleries']):rec['galleries'].append(dict(url=u,alt=im.get('alt',''),source_record_index=index))
for index,r in enumerate(rows):
 if not r.get('url'):continue
 c=codes(r);sku=r.get('sku')or(c[0]if len(c)==1 else None);evidence='explicit_sku'
 # Monogram page contains independently stated child SKUs and same-child sizes.
 if len(c)>5 and'harf'in r.get('title','').casefold():
  text=r.get('text','');matches=list(re.finditer(r'\b\d{4}/\d{3}/\d{3}\b',text));children=[]
  for j,m in enumerate(matches):
   s=m.group();start=matches[j-1].end()if j else 0;end=matches[j+1].start()if j+1<len(matches)else len(text);before=text[start:m.start()].splitlines();names=[line.strip()for line in before if line.strip()and not any(t in line for t in['TL','EKRU','Coming Soon','PAYLAŞ'])];title=names[-1]if names else r['title'];sm=re.search(SIZE,text[m.end():end],re.I)
   if not sm:continue
   label=' × '.join(sm.groups())+' cm';photos=[im for im in r.get('gallery_images',[])if image_code(im.get('url','')).endswith(s.replace('/',''))]
   char_match=re.search(r'[“"\']([A-Zİ])',title)or re.search(r'\b([A-Zİ])\s+HARF',title);letter=char_match.group(1)if char_match else None
   child=dict(r,sku=s,title=title,cover_size_labels=[label],gallery_images=photos);add(s,child,index,'explicit_child_sku_and_size_in_official_composite',letter);children.append(dict(sku=s,title=title,size=label,photo_count=len(photos)))
  composites.append(dict(url=r['url'],source_record_index=index,children=children));continue
 if not sku:
  known=url_skus.get(urlkey(r['url']),set())
  if len(known)==1:sku=next(iter(known));evidence='earlier_verified_exact_page_or_pelement'
 if not sku:
  known=set()
  for im in r.get('gallery_images',[]):
   mapped=code_skus.get(image_code(im.get('url')or im.get('src')),set())
   if len(mapped)==1:known|=mapped
  if len(known)==1:sku=next(iter(known));evidence='earlier_verified_exact_image_code'
 if not sku and urlkey(r['url'])in card_by_url:
  card=card_by_url[urlkey(r['url'])];code=card.get('image_code');observed={image_code(x.get('url')or x.get('src'))for x in r.get('gallery_images',[])}
  if code and code in observed:sku='IMG'+code;evidence='exact_category_card_and_zoom_image_code_only_no_sku_claim'
 if not sku:
  if urlkey(r['url'])in category_urls and(r.get('cover_size_labels')or r.get('error')):unresolved.append(dict(url=r['url'],title=r.get('title'),source_record_index=index,official_sizes=r.get('cover_size_labels'),image_codes=list(dict.fromkeys(image_code(x.get('url')or x.get('src'))for x in r.get('gallery_images',[]))),reason='No exact earlier verified SKU mapping; source image identity retained rather than invented.'))
  continue
 add(sku,r,index,evidence)
# Retain stronger pre-existing official size evidence when a later live page is
# stocked out. This is evidence union, never substitution from another SKU.
for prior in initial['products']:
 if prior['sku']not in records:
  seed=dict(sku=prior['sku'],title=prior['title'],url=prior['url'],cover_size_labels=prior['official_size_labels'],text='Earlier frozen measured official product evidence retained; current page unavailable.',gallery_images=[])
  add(prior['sku'],seed,None,'earlier_frozen_official_size_evidence_retained')
# Merge gallery-only repairs for same exact SKU or confirmed same source page.
for index,r in enumerate(rows):
 c=codes(r);sku=r.get('sku')or(c[0]if len(c)==1 else None)
 if not sku:
  known=url_skus.get(urlkey(r.get('url')),set());sku=next(iter(known))if len(known)==1 else None
 if sku in records:
  for im in r.get('gallery_images',[]):
   u=im.get('url')or im.get('src')
   if records[sku]['monogram_character']and not image_code(u).endswith(sku.replace('/','')):continue
   if u and not any(x['url']==u for x in records[sku]['galleries']):records[sku]['galleries'].append(dict(url=u,alt=im.get('alt',''),source_record_index=index))
model_lookup={}
for path in[ROOT/'work/zarahome-dekor/library-manifest.json',N/'furniture-models/final-manifest.json']:
 if path.exists():
  data=json.loads(path.read_text());data=data if isinstance(data,list)else data.get('products',[])
  for e in data:
   if e.get('sku'):model_lookup.setdefault(e['sku'],[]).append(e.get('id'))
products=[];queue=[];targets=[];pending=[];crosslinks=[]
for sku,r in records.items():
 title=r['title'];plain=title.casefold().replace('ı','i').replace('\u0307','')
 furniture=any(t in plain for t in['metal chair','ahşap ve rattan bank','ahsap ve rattan bank','ferforje sandalye'])
 kind='furniture_cross_reference'if furniture else'cover_sheet'if any(t in title.casefold()for t in['örtü','throw'])else'thin_filled_mat'if'şilte'in title.casefold()else'cushion_cover'if re.search(r'k[i]*l[i]*f',plain)else'filled_cushion_requires_form_review'
 if r['monogram_character']:kind='embroidered_monogram_cushion'
 labels=list(r['labels']);variants=[dict(key=key(sku,plan(s)),official_label=s,cover_sides_cm=list(plan(s)),source_url=r['labels'][s]['source_url'],source_record_index=r['labels'][s]['source_record_index'],new_model_needed=key(sku,plan(s))not in existing,existing_model_group=existing.get(key(sku,plan(s))))for s in labels]
 if r['hwd']:
  dims=r['hwd'];label=' × '.join(format(v,'g')for v in dims)+' cm (Y × G × D)';variants.append(dict(key=sku+'|HWD:'+','.join(format(v,'g')for v in dims),official_label=label,source_dimensions_hwd_cm=dims,source_url=r['url'],new_model_needed=not furniture,existing_model_group=model_lookup.get(sku)if furniture else None))
 photos=[]
 for im in r['galleries']:
  u=im['url']
  if'w=1024'not in u and any('w=1024'in x['url']and x['url'].split('?')[0]==u.split('?')[0]for x in r['galleries']):continue
  file=u.split('?')[0].split('/')[-1];dest=P/'products'/sku.replace('/','-')/'originals'/('official-'+hashlib.sha256(u.encode()).hexdigest()[:8]+'-'+file);photo=dict(url=u,alt=im['alt'],source_file=str(N/'live-product-details-from-root.json'),source_record_index=im['source_record_index'],local_master=str(dest),role='official_live_zoom_gallery');photos.append(photo);queue.append(dict(sku=sku,product_id=sku.replace('/','-'),**photo))
 has_front=any('-p1.jpg'in x['url']for x in photos)or(kind=='embroidered_monogram_cushion'and bool(photos));need=any(v['new_model_needed']for v in variants)and not furniture
 p=dict(id=sku.replace('/','-'),sku=sku,source_sku=None if sku.startswith('IMG')else sku,image_code=sku[3:]if sku.startswith('IMG')else None,title=title,url=r['url'],product_kind=kind,official_size_labels=labels,official_sizes=list(r['labels'].values()),source_dimensions_hwd_cm=r['hwd'],variants=variants,new_model_needed=need,photos=photos,source_record_indexes=r['source_records'],identity_evidence=r['identity_evidence'],monogram_character=r['monogram_character'],official_text=r['official_text'],review_status='needs_per_product_visual_review',front_reference_available=has_front,model_status='queued'if need else'already_modeled_or_cross_reference',quality_pending=[]if has_front or furniture else['needs_unobstructed_front_reference'])
 if furniture:crosslinks.append(dict(sku=sku,title=title,url=r['url'],matched_model_ids=model_lookup.get(sku,[]),status='existing_furniture_model'if model_lookup.get(sku)else'pending_furniture_model'))
 products.append(p)
 for v in variants:
  if v['new_model_needed']and not furniture:targets.append(dict(sku=sku,source_sku=None if sku.startswith('IMG')else sku,image_code=sku[3:]if sku.startswith('IMG')else None,title=title,url=r['url'],product_kind=kind,**v))
 if need and not has_front:pending.append(dict(sku=sku,url=r['url'],photos=len(photos),reason='No complete P1 front in current gallery; existing frontal/detail alternatives remain retained.'))
 out=P/'products'/p['id'];out.mkdir(exist_ok=True,parents=True);write(out/'product.json',p)
summary=dict(live_capture_products=len(products),verified_size_variants=sum(len(p['variants'])for p in products),new_products=sum(p['new_model_needed']for p in products),new_sku_size_targets=len(targets),already_modeled_variants=sum(not v['new_model_needed']for p in products for v in p['variants']),original_photo_urls=len(queue),needs_front_reference_products=len(pending),unresolved_source_records=len(unresolved),furniture_cross_references=len(crosslinks),explicit_monogram_children=sum(len(x['children'])for x in composites),per_category_cap=None,models_generated=len(json.loads((P/'manifest.json').read_text()))if(P/'manifest.json').exists()else 0,source_snapshot_sha256=hashlib.sha256(raw).hexdigest())
write(P/'candidate-inventory.json',dict(summary=summary,products=products));write(P/'new-size-targets.json',targets);write(P/'download-queue.json',queue);write(P/'quality-pending-source.json',pending);write(P/'unresolved-source-identities.json',unresolved);write(P/'furniture-crosslinks.json',crosslinks);write(P/'composite-child-products.json',composites);write(P/'source-snapshot.json',rows);print(json.dumps(summary,ensure_ascii=False))
