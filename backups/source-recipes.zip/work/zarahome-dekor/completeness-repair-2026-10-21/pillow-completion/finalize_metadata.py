"""Clarify source semantics, with byte-identical geometry and material buffers."""
from pathlib import Path
import sys,json,hashlib
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parent;sys.path.insert(0,str(P.parents[1]));from export_catalog import read_glb,write_glb
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,x):
 p=Path(p);tmp=p.with_name(p.name+'.tmp');tmp.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n');tmp.replace(p)
a=json.loads((P/'manifest.json').read_text());plans={r['variant']['key']:r for r in json.loads((P/'variant-photo-plan.json').read_text())};products={r['sku']:r for r in json.loads((P/'candidate-inventory.json').read_text())['products']};gallery={v['variant_key']:v['gallery']for b in json.loads((P/'gallery-bindings.json').read_text())['bindings']for v in b['variants']};proof=[];qa=json.loads((P/'geometry-independent-qa.json').read_text());qby={r['id']:r for r in qa['checks']}
for e in a:
 p=plans[e['variant_key']];prod=products[e['sku']];path=Path(e['model_path']);model=json.loads(path.read_text());meta=model['metadata'];meta['material_source_note']=meta.pop('official_materials_verbatim','Appearance follows original product photographs.');meta.update(official_text_evidence_file=str(P/'candidate-inventory.json'),source_capture_snapshot=str(P/'source-snapshot.json'),source_capture_snapshot_sha256=sha(P/'source-snapshot.json'))
 if prod['monogram_character']:
  meta.update(product_form='embroidered_monogram_cushion',filling_included_in_original_product=None,fill_inclusion_source_status='Official child block confirms cushion title, actual SKU and30×30 plan; fill inclusion is not explicitly stated in this capture.',monogram_character=prod['monogram_character'],size_source_kind='official_cushion_plan_estimated_depth',official_product_plan_dimensions_cm=p['variant']['cover_sides_cm'],estimated_presentation_depth_cm=e['dimensions_cm'][2]);meta.pop('official_cover_dimensions_cm',None);meta.pop('estimated_filling_depth_cm',None)
 if e['variant_key']in gallery:meta['source_images']=gallery[e['variant_key']];meta['source_gallery_binding_note']='Full official product front first, followed by observed same11-digit image family gallery. Cloth bake source remains separate.'
 if p.get('reference_format_note'):meta['reference_format_note']=p['reference_format_note']
 if e['quality_pending']:meta['artwork_placement_note']='Official40×60 plan; exact rectangular front is unpublished in the observed gallery. Same-SKU complete square motif is adapted to this verified rectangle, explicitly interpreted.'
 write(path,model);glb=Path(e['glb_path']);doc,binary=read_glb(glb);oldbin=hashlib.sha256(binary).hexdigest();doc['extras']['metadata']=meta;write_glb(glb,doc,binary);_,after=read_glb(glb);assert binary==after
 e.pop('official_materials_verbatim',None);e.update(meta);e.update(sha256=sha(glb),bytes=glb.stat().st_size);vp=Path(e['asset_dir'])/(e['id']+'.validation.json');v=json.loads(vp.read_text());v.update(metadata=meta,source_sha256=sha(path),glb_bytes=e['bytes']);v['deliverable_sha256']['glb']=e['sha256'];write(vp,v);qby.get(e['id'],{}).update(sha256=e['sha256'],bytes=e['bytes'],product_form=e['product_form'],filling_included_in_original_product=e['filling_included_in_original_product']);proof.append(dict(id=e['id'],unchanged_binary_sha256=oldbin,metadata_amendment_only=True,glb_sha256=e['sha256']))
write(P/'manifest.json',a);qa['metadata_only_amendment_proof']=str(P/'metadata-only-amendments.json');write(P/'geometry-independent-qa.json',qa);write(P/'metadata-only-amendments.json',dict(valid=True,models=len(proof),geometry_and_embedded_material_binary_unchanged=True,changes=proof));print('Metadata semantics checked',len(a),'identical geometry/material buffers')
