"""Freeze complete measured soft textiles; report every category-card exception."""
from pathlib import Path
from urllib.parse import urlsplit,parse_qs
import json,hashlib,re,struct
from PIL import Image
P=Path(__file__).resolve().parent;N=P.parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
write=lambda p,x:Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
assert not(P/'frozen-lock.json').exists()
a=json.loads((P/'manifest.json').read_text());qa=json.loads((P/'geometry-independent-qa.json').read_text());inv=json.loads((P/'candidate-inventory.json').read_text());snap=json.loads((P/'source-snapshot.json').read_text());plans={x['variant']['key']:x for x in json.loads((P/'variant-photo-plan.json').read_text())}
assert len(a)==192 and len({x['variant_key']for x in a})==192 and qa['valid']and len(qa['checks'])==192
old=[]
for folder in['pillow-expansion','pillow-quality-revisions']:
 f=N/folder/'frozen-sha256.json';expected=json.loads(f.read_text());expected=expected.get('files',expected);expected={r['path']:r['sha256']for r in expected}if isinstance(expected,list)else expected;changed=[rel for rel,digest in expected.items()if sha(N/folder/rel)!=digest];assert not changed,(folder,changed);old.append(dict(folder=folder,files=len(expected),all_unchanged=True,manifest_sha256=sha(N/folder/'final-manifest.json')))
masters=json.loads((P/'image-master-register.json').read_text())['masters'];changed=[x['local_master']for x in masters if sha(x['local_master'])!=x['sha256']];assert not changed
for e in a:
 assert sha(e['glb_path'])==e['sha256']
 for view in['on.png','on-capraz.png','arka.png','yan.png']:
  im=Image.open(Path(e['asset_dir'])/view);assert im.size==(1000,1000)
 assert e['source_images'][0]['url']==plans[e['variant_key']]['front']['photo']['url']
 model=json.loads(Path(e['model_path']).read_text());assert model['metadata']['source_images']==e['source_images']
 with Path(e['glb_path']).open('rb')as stream:
  stream.seek(12);length,kind=struct.unpack('<II',stream.read(8));doc=json.loads(stream.read(length));assert doc['extras']['metadata']['source_images']==e['source_images']
def key(u):
 z=urlsplit(u or'');return parse_qs(z.query).get('pelement',[z.path])[0]
cards=next(x['products']for x in json.loads((N/'live-category-cards.json').read_text())['categories']if x['category']=='Kırlentler');products=inv['products'];by_sku={}
for f in[N/'pillows/manifest.json',N/'pillow-expansion/final-manifest.json',N/'furniture-models/final-manifest.json']:
 for e in json.loads(f.read_text()):by_sku.setdefault(e['sku'],[]).append(e)
for e in a:by_sku.setdefault(e['sku'],[]).append(e)
coverage=[];unmeasured=[]
for i,c in enumerate(cards):
 matched=[]
 for prod in products:
  urls=[prod['url']]+[snap[z]['url']for z in prod.get('source_record_indexes',[])if z is not None and'url'in snap[z]]
  if key(c['url'])in{key(u)for u in urls}:matched.append(prod)
 code=next((re.search(r'/(\d{11})-',x['url']).group(1)for x in c['images']if re.search(r'/(\d{11})-',x['url'])),None)
 models=[dict(id=e['id'],sku=e['sku'],glb_path=e['glb_path'],dimensions_cm=e['dimensions_cm'])for prod in matched for e in by_sku.get(prod['sku'],[])]
 status='model_matched'if models else'pending_furniture_model'if any(p['product_kind']=='furniture_cross_reference'for p in matched)else'needs_measurement'
 if not matched:
  status='needs_measurement';unmeasured.append(dict(card_index=i+1,title=c['title'],url=c['url'],image_code=code,actual_sku=None,reason='Official source out of stock; no verified size or actual SKU available.'if code=='44176008251'else'Official source redirect failed; no verified size available. No size transferred from another colour.'))
 coverage.append(dict(card_index=i+1,title=c['title'],url=c['url'],image_code=code,matched_source_skus=[p['sku']for p in matched],source_identity_verified=bool(matched),model_status=status,matched_models=models))
assert len(coverage)==161 and sum(x['source_identity_verified']for x in coverage)==159 and len(unmeasured)==2
write(P/'card-identity-coverage.json',coverage);write(P/'needs-measurement.json',unmeasured)
pending=[dict(id=e['id'],sku=e['sku'],official_size_label=e['official_size_label'],quality_pending=e['quality_pending'])for e in a if e['quality_pending']]
write(P/'quality-pending-source.json',dict(unresolved_whole_front_references=[],full_front_A1_fallbacks=[dict(sku=s,source_status='Official gallery has no P1 file; actual whole front A1 is preserved and used.')for s in['4165/008/529','5163/008/518','5162/008/400']],unpublished_exact_format_artwork=pending))
inv['summary'].update(models_generated=len(a),known_existing_physical_variants=47,measured_furniture_variants_pending=1,soft_textile_physical_variants_total=238,category_cards_with_model=sum(x['model_status']=='model_matched'for x in coverage),category_cards_needing_measurement=2,category_furniture_card_pending=1)
inv['summary']['matched_existing_or_furniture_reference_variants']=inv['summary'].pop('already_modeled_variants',48)
write(P/'candidate-inventory.json',inv)
write(P/'final-manifest.json',a)
summary=dict(valid=True,new_models=192,new_sku_products=135,verified_soft_textile_identities=181,verified_soft_textile_size_variants=238,existing_soft_models=46,category_cards=161,category_cards_source_matched=159,category_cards_model_matched=158,category_cards_needing_measurement=2,pending_furniture_models=[dict(sku='1392/073/800',official_hwd_cm=[85,42,45],reason='Merchandised metal chair; separate furniture, no cushion generated.')],matched_furniture=[dict(sku='5152/073/700',model_folder=str(N/'furniture-models'))],per_category_cap=None,all_898_source_files_unchanged=True,original_photo_url_records=len(masters),all_prior_frozen_files_unchanged=old,all_glb_hashes_verified=True,all_geometry_checks_passed=True,embedded_texture_resolution=[2048,2048],source_native_resolution_not_invented=True,normals_roughness_are_appearance_estimates=True,native_views_per_model=4,native_view_count=768,all_four_angle_contacts_reviewed=True,non_square_cover_pose_checks=89,orientation_audit=str(P/'orientation-audit.json'),gallery_bindings=str(P/'gallery-bindings.json'),front_reference_quality_pending=pending,needs_measurement=unmeasured,maximum_glb_bytes=max(e['bytes']for e in a),checks=qa['checks'])
write(P/'final-independent-qa.json',summary)
readme='''192 yeni resmî SKU/boy modeli donduruldu. Üç veya ürün seçkisi sınırı uygulanmadı.

Kapsam: 161 kaynak kartın159'unda gerçek kimlik çözüldü; 181 bağımsız yumuşak tekstil kimliğinde238 doğrulanmış boy vardır. Önceki46 model korunur; bu paket192 ekler. 25 harf gerçek çocuk SKU kanıtıyla ayrıdır. İki kartın ölçüsü bilinmiyor; bir metal sandalye tekstil değildir ve ayrı mobilya modeli bekler. Rattan bank mevcut fiziksel modele bağlanır.

Model geometrileri metre, Y yukarı ve taban kutusu merkezindedir. GLB kapalı geometri, gömülü2048 albedo/normal/pürüzlülük haritaları ve dört1000piksel görünümle denetlendi. 898 özgün dosyanın SHA'ları değişmedi. Normal, pürüzlülük, kılıf dolgu derinliği ve gözlenmeyen arka yüz ayrıntıları açık yorumdur; resmî ölçü gibi sunulmaz. Silindir, sandalye minderi, ince şilte ve kürk örtü kendi fiziksel formlarıyla ayrıdır. Ham HWD şilte6370/009/500 normal kılıf yön varsayımına alınmadı.

Galerilerin ilk görseli kullanılan bedenin önünü içeren özgün tam ürün fotoğrafıdır. Kumaş piksel seçimi ayrı texture-provenance.json içindedir. 5160/008/710 40×60'ın resmî boyu doğrulandı; galeri yalnız kare desen sunduğundan bu bedenin motif yerleşimi quality_pending olarak açık kalır.

review/models-contact-01..12.jpg tüm modellerin dört açısını; review/final-orientation-models-01..03.jpg son17 değişikliği gösterir. orientation-audit.json89 dikdörtgen kılıfın fotoğraf yönünü ve gerçek genişlik/yükseklik ilişkisini kaydeder. Frozen önceki43 ve ayrı6368 mavi bordür revizyonu değiştirilmedi.
'''
(P/'README.txt').write_text(readme)
files={str(f.relative_to(P)):sha(f)for f in P.rglob('*')if f.is_file()and'superseded-review'not in f.parts and'__pycache__'not in f.parts and f.name not in['frozen-sha256.json','frozen-lock.json']}
write(P/'frozen-sha256.json',files);write(P/'frozen-lock.json',dict(phase='frozen',final_manifest_sha256=sha(P/'final-manifest.json'),verified_new_models=192,files=len(files),no_further_mutation=True))
print(json.dumps(dict(models=192,manifest_sha256=sha(P/'final-manifest.json'),files=len(files),source_identity_cards=159,model_matched_cards=158,needs_measurement=2,quality_pending=len(pending)),indent=2))
