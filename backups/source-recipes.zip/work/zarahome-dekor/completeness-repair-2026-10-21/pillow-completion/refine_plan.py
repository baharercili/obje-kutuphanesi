from pathlib import Path
import json,re
P=Path(__file__).resolve().parent;a=json.loads((P/'variant-photo-plan.json').read_text());inv=json.loads((P/'candidate-inventory.json').read_text());products={x['sku']:x for x in inv['products']};cache=json.loads((P/'frame-detection-cache.json').read_text())
for p in a:
 sku=p['sku'];c=p['review']
 if sku in['5313/008/251','5313/008/052','5313/008/700']:
  f=p['front']['frame'];f['quad']=[[.11,.295],[.89,.295],[.89,.705],[.11,.705]];f['mids']=[[.5,.335],[.855,.50],[.5,.687],[.145,.50]];p['front']['aspect']=1.5;p['dimensions_cm']=[60,40,p['dimensions_cm'][2]];p['portrait']=False;c['portrait']=False;p['source_photo_pose']='landscape'
 if sku=='3110/008/055':
  f=p['front']['frame'];f['quad']=[[.11,.255],[.90,.255],[.90,.747],[.11,.747]];f['mids']=[[.5,.285],[.86,.50],[.5,.718],[.15,.50]]
 if p['form']=='bolster':
  pp=products[sku];im=max([x for x in pp['photos']if'-p1.jpg'in x['url']],key=lambda x:int(re.search(r'w=(\d+)',x['url']).group(1)));frame=max(cache[im['local_master']],key=lambda x:x['area']);p['front'].update(photo=im,frame=frame,aspect=.346,portrait=True,composite=False);p['texture_rotate_clockwise']=True;p['quality_pending']=[]
 if sku=='7324/008/712':c.update(kind='long_fur',fur=.012);p['kind']='long_fur'
 if sku in['6374/009/620','6376/009/620','6370/009/500']:c['kind']='quilted_mat';p['kind']='quilted_mat';c['fur']=None;c['relief']=None
 if sku=='9284/009/710':c['kind']='chair_pad';p['kind']='chair_pad'
 if sku=='4174/008/307':c.update(kind='embroidery',relief=.0008);p['kind']='embroidery'
 if sku=='6149/008/251':c.update(kind='embroidery',relief=.0009);p['kind']='embroidery'
 if sku in['6370/008/620','6370/008/703','6370/008/485','6370/008/712']:
  # Use the independent A1/A2 fronts. The A7 styled fold is not an albedo.
  pp=products[sku];short,long=p['variant'].get('cover_sides_cm',[45,45]);tail='-a1.jpg'if short==long else'-a2.jpg';photos=[x for x in pp['photos']if tail in x['url']]
  if photos:
   im=max(photos,key=lambda x:int(re.search(r'w=(\d+)',x['url']).group(1)));frame=max(cache[im['local_master']],key=lambda x:x['area']);f=json.loads(json.dumps(frame));q=f['quad'];cx=sum(v[0]for v in q)/4;cy=sum(v[1]for v in q)/4;f['quad']=[[cx+(v[0]-cx)*.94,cy+(v[1]-cy)*.94]for v in q];x0,y0,x1,y1=f['bbox'];m=f['mids'];m[3][0]+=(x1-x0)*.085;m[1][0]-=(x1-x0)*.085;m[0][1]+=(y1-y0)*.04;m[2][1]-=(y1-y0)*.065;p['front'].update(photo=im,frame=f,aspect=long/short,portrait=False,composite=False);p['dimensions_cm'][:2]=[long,short];p['portrait']=False;c['portrait']=False;p['source_photo_pose']='landscape_or_square';p['quality_pending']=[]
 # Geometry axes follow this source pose; all plan labels remain original evidence.
 p['source_dimensions_hwd_cm']=[p['dimensions_cm'][1],p['dimensions_cm'][0],None]if p['estimated_axes']==['Z']and p['form']not in['bolster']else p['source_dimensions_hwd_cm']
(P/'variant-photo-plan.json').write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n');print(len(a),'plans refined')
