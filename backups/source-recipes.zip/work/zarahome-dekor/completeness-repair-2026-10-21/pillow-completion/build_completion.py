"""All measured cushion variants, distinct source cloth and physical textile forms."""
from pathlib import Path
import sys,importlib.util,inspect,json,math,re,hashlib,copy
sys.dont_write_bytecode=True
import numpy as np
from PIL import Image
P=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('completed_soft_geometry',P.parent/'pillow-expansion/build_expansion.py');geo=importlib.util.module_from_spec(sp);sp.loader.exec_module(geo);geo.P=P;geo.base.P=P;base=geo.base
from export_catalog import export_assets,read_glb,write_glb
from audit_geometry import check
write=lambda p,x:Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
# Reuse the approved closed sewn geometry without touching the frozen source.
source=inspect.getsource(geo.make_cushion).replace("int(prefix.replace('-',''))", "int(re.sub(r'\\D','',prefix))")
old="""    if c.get('fringe'):
        for side in([-1,1]if c['fringe']=='both'else[-1]):
            for v in np.linspace(-.95,.95,int(h/.0019)):
                p=cloth_point(float(side),float(v),w,h,d,c,None,1);p[2]=0
                for j in range(2):fiber(b,'real-loose-side-fringe-yarns',back,p,[side*rng.uniform(.005,.009),rng.uniform(-.0015,.0015),rng.uniform(-.002,.002)],.00025,(.5,.5),.0004)
"""
new="""    if c.get('fringe'):
        edges=range(4)if c['fringe']=='all'else[0,2]if c['fringe']=='top_bottom'else[1,3]
        for edge in edges:
            for t in np.linspace(-.97,.97,int((w if edge in[0,2]else h)/.0019)):
                u,v=([t,-1],[1,t],[t,1],[-1,t])[edge];p=cloth_point(float(u),float(v),w,h,d,c,None,1);p[2]=0;rad=np.array([0,-1,0])if edge==0 else np.array([1,0,0])if edge==1 else np.array([0,1,0])if edge==2 else np.array([-1,0,0])
                for j in range(2):fiber(b,'real-photo-matched-loose-fringe-yarns',back,p,rad*rng.uniform(.005,.009)+[rng.uniform(-.0005,.0005),rng.uniform(-.0005,.0005),rng.uniform(-.001,.001)],.00025,((u+1)/2,(1-v)/2),.0004)
"""
assert old in source;source=source.replace(old,new);exec(source,geo.__dict__)
source=inspect.getsource(geo.make_bolster).replace('range(3000)','range(2400 if c.get("fur")else 0)').replace("'closed-soft-animal-fur-bolster'","'closed-round-ended-textile-bolster'").replace("'Official56cm length and18cm round diameter: no invented filling depth'","'Official source label and separately stated HWD retained; symmetry-derived round depth explicitly distinguished'");exec(source,geo.__dict__)
original_point=geo.cloth_point

def point(u,v,w,h,d,c,mask=None,side=1):
 if c['kind']not in['quilted_mat','chair_pad']:return original_point(u,v,w,h,d,c,mask,side)
 body=max(0,1-u*u)**.13*max(0,1-v*v)**.13;x=.5*w*u*(1-.008*abs(u*v)**10);y=h/2+h*v/2*(1-.012*(1-u*u));z=.0007+(d*.5-.0007)*body
 if c['kind']=='quilted_mat':
  grid=[(-.48,-.78),(.46,-.65),(-.41,-.42),(.42,-.26),(-.48,-.06),(.43,.10),(-.44,.29),(.48,.47),(-.42,.68),(.42,.82)]if h>w*2 else[(0,0)]
  for a,b in grid:z-=min(d*.25,.0055)*math.exp(-((u-a)**2/.026+(v-b)**2/.006))
 return np.array([x,y,max(.0005,z)*side])
geo.cloth_point=point

def from_meshes(meshes):
 b=base.Builder()
 for m in meshes:b.add(m['name'],m['material'],np.array(m['positions']).reshape(-1,3),np.array(m['indices']).reshape(-1,3).tolist(),np.array(m['uvs']).reshape(-1,2).tolist())
 return b

def pelt(prod,rev,w,h,d):
 c=rev['review'];mat=prod['id']+'-front';back=prod['id']+'-reverse';b=base.Builder();photo=Image.open(rev['source_path']).convert('RGB');photo.thumbnail((512,635));rgb=np.asarray(photo,dtype=np.float32)/255;ih,iw=rgb.shape[:2];left=np.median(rgb[:,:12],axis=1);right=np.median(rgb[:,-12:],axis=1);bg=left[:,None,:]*(1-np.linspace(0,1,iw)[None,:,None])+right[:,None,:]*np.linspace(0,1,iw)[None,:,None];diff=np.linalg.norm(rgb-bg,axis=2);frame=rev['front_review'];x0,y0,x1,y1=frame['bbox'];cx=(x0+x1)/2;cy=(y0+y1)/2;N=160;rr=[]
 for a in np.arange(N)*math.tau/N:
  last=.75
  for r in np.linspace(.3,min(1/max(abs(math.cos(a)),.001),1/max(abs(math.sin(a)),.001)),180):
   xx=int(np.clip((cx+(x1-x0)*.5*math.cos(a)*r)*iw,0,iw-1));yy=int(np.clip((cy+(y1-y0)*.5*math.sin(a)*r)*ih,0,ih-1))
   if diff[yy,xx]>.055:last=float(r)
  rr.append(last)
 rr=np.array([np.median(np.take(rr,np.arange(i-3,i+4)%N))for i in range(N)]);outline=[(w*.5*math.cos(a)*r,h/2-h*.5*math.sin(a)*r)for a,r in zip(np.arange(N)*math.tau/N,rr)]
 for side,material in[(1,mat),(-1,back)]:
  vv=[(0,h/2,side*.001)];uv=[(.5,.5)];ff=[];rings=22
  for k in range(1,rings+1):
   t=k/rings
   for x,y in outline:
    xx=x*t;yy=h/2+(y-h/2)*t;z=side*(.0007+.0008*math.sin(t*math.pi)+.0003*math.sin(math.atan2(yy-h/2,xx)*7)*t**3);vv.append((xx,yy,z));uv.append((xx/w+.5,1-yy/h))
  for j in range(N):ff.append((0,1+j,1+(j+1)%N))
  for k in range(rings-1):
   for j in range(N):a=1+k*N+j;aa=1+k*N+(j+1)%N;bb=1+(k+1)*N+j;dd=1+(k+1)*N+(j+1)%N;ff.extend([(a,bb,aa),(aa,bb,dd)])
  # Close each half with a flat hidden interior fan and a real edge skirt.
  off=len(vv);vv.append((0,h/2,0));uv.append((.5,.5));start=len(vv)
  for x,y in outline:vv.append((x,y,0));uv.append((x/w+.5,1-y/h))
  for j in range(N):
   a=1+(rings-1)*N+j;aa=1+(rings-1)*N+(j+1)%N;bb=start+j;dd=start+(j+1)%N;ff.extend([(a,bb,aa),(aa,bb,dd),(off,dd,bb)])
  b.add('closed-irregular-fur-pelt-front'if side==1 else'closed-thin-pelt-reverse',material,vv,ff,uv)
 rng=np.random.default_rng(7324)
 for j in range(5800):
  a=rng.uniform(0,math.tau);idx=int(a/math.tau*N)%N;t=math.sqrt(rng.uniform(.001,1));rad=float(rr[idx]);x=w*.5*math.cos(a)*rad*t;y=h/2-h*.5*math.sin(a)*rad*t;ll=.012*rng.uniform(.55,1.2);geo.fiber(b,'closed-pelt-fur-strand-clusters',mat,[x,y,.0012],[rng.uniform(-.003,.003),-ll*.40,ll*.80],.00032,(x/w+.5,1-y/h),.001)
 for j,(x,y)in enumerate(outline):
  for k in range(3):
   rad=np.array([x,y-h/2,0]);rad/=np.linalg.norm(rad);geo.fiber(b,'actual-irregular-pelt-edge-hairs',mat,[x+float(rng.uniform(-.00005,.00005)),y+float(rng.uniform(-.00005,.00005)),0],rad*float(rng.uniform(.006,.009))+[0,0,.003],.00024,(x/w+.5,1-y/h))
 write(P/'products'/prod['id']/'source-outline-trace.json',dict(source=rev['source_path'],radial_outline_from_observed_pelt_mask=outline,official_plan_cm=[w*100,h*100],thickness_estimated=True,pose_foreshortening_interpreted=True))
 return b.finish([w,h,d],['Thin irregular fur cloth sheet; no cushion filling','Outline traced from this exact official front silhouette; folded/photo pose interpreted','Official35×100 plan; estimated base/fur thickness explicit','Real closed nap strands and separate irregular edge hairs'])

def make(plan,prod,rev):
 w,h,d=np.array(plan['dimensions_cm'])/100;c=rev['review'];form=plan['form']
 if form=='irregular_fur_sheet':return pelt(prod,rev,w,h,d)
 if form=='bolster':return geo.make_bolster(prod,rev,w,h,d)
 if form=='thin_chair_pad':
  meshes,qa=geo.make_cushion(prod,rev,w,d,h)
  for m in meshes:
   a=np.array(m['positions']).reshape(-1,3);old=a.copy();a[:,1]=old[:,2]+h/2;a[:,2]=d/2-old[:,1];m['positions']=a.reshape(-1).tolist();nr=np.array(m['normals']).reshape(-1,3);old=nr.copy();nr[:,1]=old[:,2];nr[:,2]=-old[:,1];m['normals']=nr.reshape(-1).tolist()
  qa.update(dimensions_metres=[w,h,d],photographed_features=['Official H3W40D40 chair pad, horizontal thin filled mat','Real centre tuft indentation and closed piping seam']);return meshes,qa
 meshes,qa=geo.make_cushion(prod,rev,w,h,d);needs_extra=c['kind']=='knit_single_horizontal'or form=='tied_chair_pad'or plan['sku'].startswith('3150/')or plan['sku']=='3110/008/055'or plan['sku'].startswith('7334/')
 if not needs_extra:return meshes,qa
 b=from_meshes(meshes);front=prod['id']+'-front';back=prod['id']+'-reverse'
 if c['kind']=='knit_single_horizontal':
  for u in np.arange(-.94,.95,.028):
   p=point(float(u),0,w,h,d,c,None,1)
   for sign in[-1,1]:geo.fiber(b,'actual-central-horizontal-knit-links',front,p+[0,sign*.0001,0],[w*.012,sign*.0012,.0007],.0004,((u+1)/2,.5),.0002)
 if form=='tied_chair_pad':
  for sign in[-1,1]:
   for j in[-1,1]:
    path=[(sign*w*.42+sign*.025*math.sin(t*math.pi),h*.91+.025*t,-d*.1+j*.002+math.sin(t*math.pi)*.002)for t in np.linspace(0,1,30)];base.textile_tube(b,'observed-upper-corner-tie-cords',back,path,.0018,8)
 if plan['sku'].startswith('7334/'):
  cord=prod['id']+'-piping'
  for edge in range(4):
   for t in np.arange(-.97,.97,.011):
    u,v=([t,-.997],[.997,t],[t,.997],[-.997,t])[edge];p=point(float(u),float(v),w,h,d,c,None,1);p[2]=.001;rad=np.array([0,-1,0])if edge==0 else np.array([1,0,0])if edge==1 else np.array([0,1,0])if edge==2 else np.array([-1,0,0]);geo.fiber(b,'actual-separated-contrast-overlock-stitches',cord,p,rad*.0009+[0,0,-.002],.00023,(.5,.5),.00015)
 if plan['sku'].startswith('3150/')or plan['sku']=='3110/008/055':
  # Native photograph has three small fabric tie bows across rear centre.
  path=[(x,h/2,-d*.49)for x in np.linspace(-w*.42,w*.42,80)];base.textile_tube(b,'actual-rear-centre-envelope-opening',back,path,.0008,8)
  for x in[-w*.22,0,w*.22]:
   for sign in[-1,1]:
    path=[(x+sign*.014*math.sin(t*math.pi),h/2+.008*math.sin(t*math.tau),-d*.49-.004*math.sin(t*math.pi))for t in np.linspace(.001,.999,38)];base.textile_tube(b,'actual-three-rear-tie-bows',back,path,.00115,8)
 return b.finish([w,h,d],qa.get('photographed_features',[])+[c['notes']])

def export_one(plan):
 prod=dict(id=plan['id'],sku=plan['sku']);rev=json.loads((P/'products'/prod['id']/'textures/texture-provenance.json').read_text());mats=geo.materials(prod,rev);base.generate_materials=lambda:mats;dims=plan['dimensions_cm'];estimated=bool(plan['estimated_axes']);form=plan['form'];record=dict(title=plan['title'],url=plan['url'],images=[dict(url=plan['front']['photo']['url'],alt=plan['front']['photo']['alt'])],materials_text='Appearance follows this exact official source photograph and product text. No unverified material percentages asserted.')
 note='Resmî ürün/boy kanıtı korundu. Kılıf dolgu derinliği ve gözlenmeyen arka ayrıntılar açık tahmindir. Normal ve pürüzlülük fotoğraftan yorumlandı; ölçülmüş tarama değildir.'
 kind='official_cover_dimensions_estimated_filling'if form=='cover'else'official_two_axis_cylindrical_symmetry_depth'if form=='bolster'and estimated else'official_textile_plan_estimated_thickness'if estimated else'tr_live_product'
 e=base.export_entry(record,plan['sku'],dims,lambda:make(plan,prod,rev),'Kırlentler',plan['kind'].replace('_',' '),estimated,kind,note,plan['source_dimensions_hwd_cm']);model=Path(e['model_path']);doc=json.loads(model.read_text());meta=doc['metadata'];meta.update(variant_key=plan['variant']['key'],official_size_label=plan['variant']['official_label'],official_size_evidence=plan['variant'],product_form=form,photo_pixels_baked=True,photo_derived_fabric=True,front_photo_rectified=True,source_lighting_normalized=True,source_lighting_residual_possible=True,normal_roughness_estimated=True,source_texture_review=str(P/'products'/prod['id']/'textures/texture-provenance.json'),source_photo_pose=plan['source_photo_pose'],source_orientation_note='Geometry width/height follows the visible official front pose; original size label retained without inventing axes.',estimated_axes=plan['estimated_axes'],estimated_reverse=rev['estimated_reverse'],quality_status='quality_pending'if plan['quality_pending']else'photo_reviewed',quality_pending=plan['quality_pending'],photo_specific_features=plan['review']['notes'],texture_detail_note=rev['unique_detail_note'],unobserved_reverse_note=rev['unobserved_reverse_note'],filling_included_in_original_product=False if form=='cover'else True if form in['bolster','thin_mattress','thin_chair_pad','tied_chair_pad','filled_long_rectangle']else None,estimated_filling_depth_cm=dims[2]if estimated and form=='cover'else None)
 if form=='bolster'and estimated:meta.update(derived_round_depth_cm=dims[2],source_dimensions_hwd_cm=[dims[1],dims[0],None],cylindrical_cross_section_observed=True,third_axis_derivation='Round cross-section observed in original photos; same diameter used for depth; source only states two axes.')
 if form=='irregular_fur_sheet':meta.update(filling_included_in_original_product=False,estimated_base_and_fur_thickness_cm=dims[2],thin_sheet_no_cushion_fill=True)
 write(model,doc);export_assets(model,Path(e['asset_dir']),e['id']);glb=Path(e['glb_path']);gd,binary=read_glb(glb)
 for m in gd['materials']:
  if m['name']in mats:m.setdefault('extensions',{})['KHR_materials_sheen']=mats[m['name']]['extras']['physical_sheen']
 gd['extensionsUsed']=sorted(set(gd.get('extensionsUsed',[]))|{'KHR_materials_sheen'});write_glb(glb,gd,binary);validation=Path(e['asset_dir'])/(e['id']+'.validation.json');v=json.loads(validation.read_text());v.update(glb_bytes=glb.stat().st_size);v['deliverable_sha256']['glb']=sha(glb);write(validation,v);e.update(meta);e.update(sha256=sha(glb),bytes=glb.stat().st_size,model_revision='complete-category-per-sku-size-photo-cloth-v1',photo_master_register=str(P/'image-master-register.json'))
 mpath=Path(e['material_validation']);md=json.loads(mpath.read_text());md.update(photo_pixels_baked=True,intrinsic_material=False,source_master_unchanged=rev['source_master_unchanged'],source_sha256=rev['source_sha256'],estimated_normal_roughness=True,front_background_excluded_by_reviewed_boundary=True,estimated_reverse=rev['estimated_reverse'],texture_provenance=meta['source_texture_review']);write(mpath,md);assert e['bytes']<25*1024*1024,(e['id'],e['bytes']);check(e);return e

def main():
 if(P/'frozen-lock.json').exists():raise SystemExit('Frozen outputs; create a separate revision.')
 a=json.loads((P/'variant-photo-plan.json').read_text());entries=json.loads((P/'manifest.json').read_text())if(P/'manifest.json').exists()else[];only=sys.argv[1:];fail=[]
 for plan in a:
  if only and plan['sku']not in only and plan['id']not in only:continue
  if not only and any(x['variant_key']==plan['variant']['key']for x in entries):continue
  if not(P/'products'/plan['id']/'textures/texture-provenance.json').exists():continue
  try:
   e=export_one(plan);entries=[x for x in entries if x['variant_key']!=e['variant_key']]+[e];write(P/'manifest.json',entries);print('BUILT',e['id'],e['bytes'],e['quality_status'],flush=True)
  except Exception as err:
   fail.append(dict(id=plan['id'],sku=plan['sku'],error=str(err)));write(P/'build-errors.json',fail);print('ERROR',plan['id'],repr(err),flush=True)
 write(P/'build-errors.json',fail);print('TOTAL',len(entries),'errors',len(fail),flush=True)
if __name__=='__main__':main()
