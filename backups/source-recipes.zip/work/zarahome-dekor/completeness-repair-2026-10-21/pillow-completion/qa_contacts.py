from pathlib import Path
import json
from PIL import Image,ImageOps,ImageDraw,ImageFont
P=Path(__file__).resolve().parent;entries=json.loads((P/'manifest.json').read_text());rows=[e for e in entries if all((Path(e['asset_dir'])/(v+'.png')).exists()for v in['on','on-capraz','arka','yan'])];out=P/'review';font=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',19)
for page in range((len(rows)+15)//16):
 sheet=Image.new('RGB',(2000,2200),'#eeede9');d=ImageDraw.Draw(sheet)
 for j,e in enumerate(rows[page*16:page*16+16]):
  x=(j%4)*500;y=(j//4)*550
  for k,v in enumerate(['on','on-capraz','arka','yan']):
   im=Image.open(Path(e['asset_dir'])/(v+'.png')).convert('RGBA');box=im.getbbox();im=ImageOps.contain(im.crop(box),(238,238));white=Image.new('RGBA',(242,242),'white');white.alpha_composite(im,((242-im.width)//2,(242-im.height)//2));sheet.paste(white.convert('RGB'),(x+(k%2)*246,y+(k//2)*246))
  d.text((x+6,y+493),e['sku']+' '+e['official_size_label'],font=font,fill='#111');d.text((x+6,y+520),e['product_form']+' '+e['quality_status'],font=font,fill='#111')
 sheet.save(out/f'four-angle-models-{page+1:02d}.jpg',quality=93)
print(len(rows),'four-angle models on',(len(rows)+15)//16,'contact pages')
