from pathlib import Path
import json,re,math
P=Path(__file__).resolve().parent;a=json.loads((P/'variant-photo-plan.json').read_text());inv=json.loads((P/'candidate-inventory.json').read_text());products={p['sku']:p for p in inv['products']};cache=json.loads((P/'frame-detection-cache.json').read_text());changed=set()
for p in a:
 sku=p['sku'];frame=p['front']['frame']
 if sku.startswith(('1321/','4165/','6370/008','5162/')):
  frame['inset_uv']=[.09,.07,.91,.93];changed.add(sku)
 if sku.startswith('6370/008'):
  ratio=max(p['variant']['cover_sides_cm'])/min(p['variant']['cover_sides_cm']);choices=[]
  for im in products[sku]['photos']:
   if not any(t in im['url']for t in['-a1.jpg','-a2.jpg'])or any(t in im['alt']for t in['detayı','yakın','köşe']):continue
   f=max(cache[im['local_master']],key=lambda x:x['area']);x0,y0,x1,y1=f['bbox'];iw,ih=f['image_size'];ar=(x1-x0)*iw/((y1-y0)*ih);choices.append((abs(math.log(max(ar,1/ar)/ratio)),im,f,ar))
  if choices:
   _,im,f,ar=min(choices,key=lambda x:x[0]);f=json.loads(json.dumps(f));f['inset_uv']=[.09,.075,.91,.925];p['front'].update(photo=im,frame=f,aspect=ar,portrait=ar<.9,composite=False);short,long=p['variant']['cover_sides_cm'];w,h=(short,long)if ar<.9 else(long,short);p['dimensions_cm'][:2]=[w,h];p['source_dimensions_hwd_cm']=[h,w,None];p['source_photo_pose']='portrait'if ar<.9 else'landscape_or_square';p['portrait']=ar<.9;p['review']['portrait']=ar<.9;p['quality_pending']=[]
 if sku in['7348/008/620','7348/008/500']and p['variant']['cover_sides_cm']==[30.0,50.0]:
  im=max([x for x in products[sku]['photos']if'-p1.jpg'in x['url']],key=lambda x:int(re.search('w=(\\d+)',x['url']).group(1)));f=dict(quad=[[.205,.655],[.79,.655],[.79,.935],[.205,.935]],mids=[[.5,.675],[.775,.80],[.5,.920],[.222,.80]],inset_uv=[.02,.02,.98,.98],bbox=[.20,.65,.80,.94]);p['front'].update(photo=im,frame=f,aspect=50/30,portrait=False,composite=False);p['dimensions_cm'][:2]=[50,30];p['source_dimensions_hwd_cm']=[30,50,None];p['portrait']=False;p['review']['portrait']=False;p['source_photo_pose']='landscape';p['review']['notes']+=' Exact lower rectangular front isolated from the two-product P1; source stripe direction retained.';p['quality_pending']=[];changed.add(sku)
 if sku=='5160/008/710'and p['variant']['cover_sides_cm']==[40.0,60.0]:
  im=max([x for x in products[sku]['photos']if'-p1.jpg'in x['url']],key=lambda x:int(re.search('w=(\\d+)',x['url']).group(1)));f=json.loads(json.dumps(max(cache[im['local_master']],key=lambda x:x['area'])));f['inset_uv']=[.065,.065,.935,.935];p['front'].update(photo=im,frame=f,aspect=1,portrait=False,composite=False);p['dimensions_cm'][:2]=[60,40];p['source_dimensions_hwd_cm']=[40,60,None];p['portrait']=False;p['review']['portrait']=False;p['source_photo_pose']='official_single_square_front_applied_to_verified_rectangle';p['quality_pending']=['exact_rectangular_format_artwork_placement_unpublished'];changed.add(sku)
 if p['form']=='bolster':
  f=frame;f['quad']=[[.37,.15],[.65,.15],[.65,.86],[.37,.86]];f['mids']=[[.51,.15],[.65,.50],[.51,.86],[.37,.50]];f['inset_uv']=[0,0,1,1];p['review']['notes']+=' Original central cylindrical cloth only, background and photographed end foreshortening excluded from body albedo.';changed.add(sku)
 if sku.startswith('5313/'):
  p['quality_pending']=[];changed.add(sku)
(P/'variant-photo-plan.json').write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n');(P/'qa-rebuild-skus.json').write_text(json.dumps(sorted(changed),ensure_ascii=False,indent=2)+'\n');print('QA texture refinements',len(changed),'SKUs')
