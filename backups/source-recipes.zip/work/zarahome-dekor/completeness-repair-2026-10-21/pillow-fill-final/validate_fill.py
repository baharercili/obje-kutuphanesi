"""Read exported buffers independently; compare every current approved input."""
from pathlib import Path
import sys,json,hashlib,io
sys.dont_write_bytecode=True
import numpy as np
from PIL import Image
P=Path(__file__).resolve().parent;N=P.parent;WORK=N.parent;sys.path.insert(0,str(WORK));sys.path.insert(0,str(WORK/'objects'))
from audit_geometry import check
from export_catalog import read_glb
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(name,data):(P/name).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
a=json.loads((P/'manifest.json').read_text());old={x['id']:x for x in json.loads((P/'baseline-manifest.json').read_text())};pilot=json.loads((N/'pillow-fill-study/candidate-b/final-manifest.json').read_text())[0];checks=[];failed=[]
only=sys.argv[1:]
if only and(P/'geometry-independent-qa.json').exists():
 prior=json.loads((P/'geometry-independent-qa.json').read_text());checks=[q for q in prior['checks']if q['id']not in only];failed=[q for q in prior['failures']if q['id']not in only]
full_count=len(a);a=[e for e in a if not only or e['id']in only]
def canonical_materials(doc):
 def norm(x):
  if isinstance(x,list):return[norm(y)for y in x]
  if not isinstance(x,dict):return x
  return{k:(doc['images'][doc['textures'][v]['source']]['name']if k=='index'else norm(v))for k,v in x.items()}
 return{m['name']:norm(m)for m in doc['materials']}

def acc(doc,binary,index):
 a=doc['accessors'][index];view=doc['bufferViews'][a['bufferView']];dt={5126:'<f4',5125:'<u4',5123:'<u2',5121:'u1'}[a['componentType']];n={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}[a['type']];size=np.dtype(dt).itemsize;return np.ndarray((a['count'],n),dtype=dt,buffer=binary,offset=view.get('byteOffset',0)+a.get('byteOffset',0),strides=(view.get('byteStride',n*size),size)).copy()
for e in a:
 try:
  source=old[e['id']];topo=check(e);assert topo['sha256']==e['sha256'];assert e['dimensions_cm'][:2]==source['dimensions_cm'][:2];od,ob=read_glb(source['glb_path']);doc,binary=read_glb(e['glb_path']);positions=[];assert canonical_materials(od)==canonical_materials(doc);assert od['textures']==doc['textures']
  assert len(od['meshes'])==len(doc['meshes']);triangles=0
  for om,m in zip(od['meshes'],doc['meshes']):
   assert om['name']==m['name'];assert len(om['primitives'])==len(m['primitives'])
   for op,p in zip(om['primitives'],m['primitives']):
    pos=acc(doc,binary,p['attributes']['POSITION']);before=acc(od,ob,op['attributes']['POSITION']);uv=acc(doc,binary,p['attributes']['TEXCOORD_0']);beforeuv=acc(od,ob,op['attributes']['TEXCOORD_0']);ix=acc(doc,binary,p['indices']);oldix=acc(od,ob,op['indices']);nr=acc(doc,binary,p['attributes']['NORMAL']);assert np.array_equal(pos[:,:2],before[:,:2]);assert np.array_equal(uv,beforeuv)and np.array_equal(ix,oldix);assert np.isfinite(pos).all()and np.isfinite(uv).all()and np.isfinite(nr).all();assert np.allclose(np.linalg.norm(nr,axis=1),1,atol=.002);positions.append(pos);triangles+=ix.size//3
  pp=np.concatenate(positions);lo=pp.min(0);hi=pp.max(0);dims=hi-lo;assert np.allclose(dims,np.array(e['dimensions_cm'])/100,atol=2e-6);assert np.allclose([(lo[0]+hi[0])/2,lo[1],(lo[2]+hi[2])/2],[0,0,0],atol=2e-6);assert e['estimated_filling_depth_cm']==e['dimensions_cm'][2];assert e['units']=='metres'and e['up_axis']=='Y';assert doc['extras']['metadata']['dimensions_cm']==e['dimensions_cm']
  textures=[]
  for im in doc['images']:
   oi=next(x for x in od['images']if x['name']==im['name'])
   def data(d,b,i):
    assert'uri'not in i;v=d['bufferViews'][i['bufferView']];return b[v.get('byteOffset',0):v.get('byteOffset',0)+v['byteLength']]
   oldpixels=data(od,ob,oi);pixels=data(doc,binary,im);assert oldpixels==pixels;size=list(Image.open(io.BytesIO(pixels)).size);assert min(size)>=2048;digest=hashlib.sha256(pixels).hexdigest();assert digest==sha(Path(e['asset_dir'])/im['name']);textures.append(dict(name=im['name'],sha256=digest,size=size,unchanged=True))
  if e['id']==pilot['id']:assert sha(e['glb_path'])==pilot['sha256']
  else:
   d=source['dimensions_cm'][2];w,h=source['dimensions_cm'][:2];assert abs(e['dimensions_cm'][2]-max(d,min(d*1.375,.45*min(w,h))))<1e-6
  checks.append(dict(id=e['id'],sku=e['sku'],glb_sha256=e['sha256'],official_xy_preserved=True,all_xy_uv_indices_exact=True,all_glb_materials_exact=True,all_embedded_image_bytes_exact=True,normals_unit=True,topology_closed_positive=True,triangles=triangles,dimensions_metres=dims.tolist(),previous_estimated_depth_cm=source['dimensions_cm'][2],new_estimated_depth_cm=e['dimensions_cm'][2],textures=textures));print('QA',len(checks),e['id'],flush=True)
 except Exception as er:failed.append(dict(id=e['id'],error=repr(er)));print('FAIL',e['id'],repr(er),flush=True)
excluded=json.loads((P/'excluded-unchanged-models.json').read_text());assert all(sha(e['glb_path'])==e['sha256']for e in excluded);write('geometry-independent-qa.json',dict(valid=not failed,models=full_count,checks=checks,failures=failed,excluded_models=len(excluded),all_excluded_glb_unchanged=True));print('VALID',len(checks),'FAILURES',len(failed),flush=True)
