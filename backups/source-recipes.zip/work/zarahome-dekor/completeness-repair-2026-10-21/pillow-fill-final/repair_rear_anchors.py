from pathlib import Path
import sys,json,copy
sys.dont_write_bytecode=True
import numpy as np
P=Path(__file__).resolve().parent;sys.path.insert(0,str(P));from build_fill import recalc,sha,export_assets,read_glb,write_glb
rows=json.loads((P/'manifest.json').read_text());old={e['id']:e for e in json.loads((P/'baseline-manifest.json').read_text())};proof=json.loads((P/'preservation-qa.json').read_text());changes=[]
for e in rows:
 if e['sku']not in['3150/008/250','3150/008/052','3110/008/055']:continue
 doc=json.loads(Path(e['model_path']).read_text());before=copy.deepcopy(doc);src=json.loads(Path(old[e['id']]['model_path']).read_text());back=next(m for m in doc['meshes']if m['name']=='closed-sewn-reverse-cloth');nn=len(back['positions'])//6;NN=round(nn**.5);grid=np.array(back['positions']).reshape(-1,3)[:nn].reshape(NN,NN,3)
 def sample(u,v):
  xx=np.clip((u+1)/2*(NN-1),0,NN-1-1e-8);yy=np.clip((v+1)/2*(NN-1),0,NN-1-1e-8);i=xx.astype(int);j=yy.astype(int);fx=(xx-i)[:,None];fy=(yy-j)[:,None];return grid[j,i]*(1-fx)*(1-fy)+grid[j,i+1]*fx*(1-fy)+grid[j+1,i]*(1-fx)*fy+grid[j+1,i+1]*fx*fy
 def atxy(xy):
  w,h=np.ptp(grid[:,:,0]),np.ptp(grid[:,:,1]);u=np.clip(xy[:,0]/(w/2),-.999,.999);v=np.clip((xy[:,1]-e['dimensions_cm'][1]/200)/(h/2),-.999,.999)
  for _ in range(8):
   q=sample(u,v);du=(sample(u+.0001,v)-sample(u-.0001,v))/.0002;dv=(sample(u,v+.0001)-sample(u,v-.0001))/.0002;res=q[:,:2]-xy;det=du[:,0]*dv[:,1]-dv[:,0]*du[:,1];stepu=(res[:,0]*dv[:,1]-res[:,1]*dv[:,0])/det;stepv=(du[:,0]*res[:,1]-du[:,1]*res[:,0])/det;u=np.clip(u-stepu,-.999,.999);v=np.clip(v-stepv,-.999,.999)
  return sample(u,v)[:,2]
 anchor=next(m for m in src['meshes']if m['name']=='actual-rear-centre-envelope-opening');plane=float(np.median(np.array(anchor['positions']).reshape(-1,3)[:,2]));repair=[]
 for m,om in zip(doc['meshes'],src['meshes']):
  if m['name']not in['actual-rear-centre-envelope-opening','actual-three-rear-tie-bows']:continue
  pp=np.array(m['positions']).reshape(-1,3);op=np.array(om['positions']).reshape(-1,3);relative=op[:,2]-plane;target=atxy(pp[:,:2]);maxgap=float(np.max(np.abs(pp[:,2]-target)));pp[:,2]=target-.0004+relative;m['positions']=pp.reshape(-1).tolist();repair.append(dict(mesh=m['name'],maximum_previous_gap_metres=maxgap,small_local_source_z_offsets_preserved=True,new_anchor_clearance_metres=.0004))
 zz=np.concatenate([np.array(m['positions']).reshape(-1,3)[:,2]for m in doc['meshes']]);scale=(e['dimensions_cm'][2]/100)/np.ptp(zz);centre=float((zz.max()+zz.min())/2);out=[]
 for m in doc['meshes']:
  pp=np.array(m['positions']).reshape(-1,3);pp[:,2]=(pp[:,2]-centre)*scale;new,vol=recalc(m,pp);out.append(new)
 doc['meshes']=out;doc['metadata']['rear_attachment_revision_note']='Arka açıklık ve bağların Z ankrajı gerçek dolgun arka yüzeye oturtuldu; özgün X/Y, UV, desen ve küçük ip kalınlıkları korundu.';model=Path(e['model_path']);model.write_text(json.dumps(doc,ensure_ascii=False,indent=2)+'\n');export_assets(model,Path(e['asset_dir']),e['id']);od,ob=read_glb(old[e['id']]['glb_path']);nd,nb=read_glb(e['glb_path']);assert[im['name']for im in od['images']]==[im['name']for im in nd['images']];nd['materials']=copy.deepcopy(od['materials']);nd['extensionsUsed']=sorted(set(nd.get('extensionsUsed',[]))|set(od.get('extensionsUsed',[])));write_glb(Path(e['glb_path']),nd,nb);e.update(doc['metadata']);e.update(sha256=sha(e['glb_path']),bytes=Path(e['glb_path']).stat().st_size)
 vp=Path(e['asset_dir'])/(e['id']+'.validation.json');v=json.loads(vp.read_text());v.update(metadata=doc['metadata'],source_sha256=sha(model),glb_bytes=e['bytes']);v['deliverable_sha256']['glb']=e['sha256'];vp.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n');q=next(q for q in proof if q['id']==e['id']);q.update(glb_sha256=e['sha256'],rear_attachment_repaired=True,rear_attachment_depth_fit_scale=scale);changes.append(dict(id=e['id'],sku=e['sku'],repairs=repair,depth_only_fit_scale=scale,official_xy_uv_material_unchanged=True));print('REAR FIXED',e['id'],scale,repair,flush=True)
(P/'manifest.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n');(P/'preservation-qa.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n');(P/'rear-attachment-qa.json').write_text(json.dumps(dict(valid=True,models=3,checks=changes),ensure_ascii=False,indent=2)+'\n');(P/'render-rear-repaired.json').write_text(json.dumps([e for e in rows if any(c['id']==e['id']for c in changes)],ensure_ascii=False,indent=2)+'\n')
