"""Retain a bookmarked source product when its first 3D size becomes ready."""
from pathlib import Path
P=Path(__file__).resolve().parents[3]/'sites/zarahome-vazo-kutuphanesi-final-378'
p=P/'src/handler.js';s=p.read_text()
old="const zarahomeReferenceIds = new Set(JSON.parse(inlineAssets['/zarahome-reference-catalog.json']?.body || '{\"products\":[]}').products.map(product => product.id));"
new="const zarahomeReferenceCatalog = JSON.parse(inlineAssets['/zarahome-reference-catalog.json']?.body || '{\"products\":[]}');\nconst zarahomeReferenceIds = new Set(zarahomeReferenceCatalog.products.map(product => product.id));\nconst zarahomeReferenceAliases = new Map(Object.entries(zarahomeReferenceCatalog.legacy_selection_aliases || {}).filter(([,target])=>zarahomeReferenceIds.has(target)));"
if 'const zarahomeReferenceAliases'not in s:
 assert old in s;s=s.replace(old,new)
 s=s.replace('referenceIds, selectionKey) {','referenceIds, selectionKey, aliases = new Map()) {')
 s=s.replace("  const change = write ? await readSmallJson(request) : null;","  const change = write ? await readSmallJson(request) : null;\n  if(change && typeof change.id === 'string' && aliases.has(change.id))change.id=aliases.get(change.id);")
 s=s.replace('current.selected_ids.filter(id => referenceIds.has(id))','current.selected_ids.map(id=>aliases.get(id)||id).filter(id => referenceIds.has(id))')
 s=s.replace('env, zarahomeReferenceIds, zarahomeSelectionKey)','env, zarahomeReferenceIds, zarahomeSelectionKey, zarahomeReferenceAliases)')
 p.write_text(s)
p=P/'scripts/test-zarahome-selection.mjs';s=p.read_text()
if 'Historical source-photo bookmarks survive'not in s:
 block='''// Historical source-photo bookmarks survive a later 3D-model delivery.
{
  const aliases=Object.entries(zara.catalog.legacy_selection_aliases||{}).filter(([old,target])=>!zara.ids.includes(old)&&zara.ids.includes(target));
  check(aliases.length>0,'Upgraded source records provide stable bookmark aliases');
  const [old,target]=aliases[0];const {bucket,request}=fixture();
  bucket.seedSelection(zara.key,[old,target,'removed-invalid-id']);
  const persisted=bucket.entries.get(zara.key).body;
  equal((await read(request,zara)).selected_ids,[target],'Old and current bookmark IDs resolve to one product');
  equal(bucket.successfulPuts,0,'Reading an upgrade does not mutate saved choices');
  equal(bucket.entries.get(zara.key).body,persisted,'Legacy storage is preserved until a user edit');
  equal((await update(request,zara,old,true)).selected_ids,[target],'A stale page can select the same upgraded product idempotently');
  equal(bucket.successfulPuts,0,'Idempotent legacy selection is read-only');
  equal((await update(request,zara,old,false)).selected_ids,[],'A stale page can deselect its upgraded product');
  equal((await update(request,zara,old,true)).selected_ids,[target],'A stale page can reselect its upgraded product');
  equal(JSON.parse(bucket.entries.get(zara.key).body).selected_ids,[target],'User edits save the current canonical product ID');
  bucket.assertOnlySelectionsTouched();
}
'''
 anchor='console.log(JSON.stringify('
 i=s.rfind(anchor);assert i>=0;s=s[:i]+block+s[i:];p.write_text(s)
print('Source-product bookmark upgrades and regression checks applied')
