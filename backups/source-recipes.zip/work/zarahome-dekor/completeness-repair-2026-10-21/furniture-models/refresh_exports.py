"""Repackage unchanged geometry with compact native 2K PBR and rebuild full manifest."""
import sys,json
from pathlib import Path
sys.dont_write_bytecode=True
import build_banks as bb
R=Path(__file__).resolve().parent
research={x['sku']:x for x in json.loads((R/'research.json').read_text())}
entries=[]
for path in sorted((R/'models').glob('*/model.json')):
 out=path.parent;model=json.loads(path.read_text());meta=model['metadata'];ident=meta['id'];sku=meta['sku'];source=research[sku]
 model['materials']=bb.materials(out,sorted(model['materials']));bb.dump(path,model)
 report=bb.f.export_assets(path,out,ident);glb=out/(ident+'.glb');doc,data=bb.f.read_glb(glb);doc['samplers']=[dict(magFilter=9729,minFilter=9987,wrapS=10497,wrapT=10497)]
 for texture in doc.get('textures',[]):texture['sampler']=0
 bb.f.write_glb(glb,doc,data);digest=bb.sha(glb);report['deliverable_sha256']['glb']=digest;report['glb_bytes']=glb.stat().st_size;bb.dump(report['files']['validation'],report)
 entry={k:meta[k]for k in['id','name','sku','url','category','dimensions_cm','source_dimensions_hwd_cm','estimated_dimensions','source_market','size_source_kind','size_source_urls','scale_note']}
 entry.update(model_path=str(path),asset_dir=str(out),glb_path=str(glb),sha256=digest,bytes=glb.stat().st_size,material_label=bb.BUILD[sku][1],source_images=source['images'],geometry_validation=str(out/'geometry-validation.json'),material_validation=str(out/'material-validation.json'),model_revision='complete-banks-photo-specific-v1',source_anomalies=source.get('source_anomalies',[]))
 bb.dump(out/'manifest-entry.json',entry);entries.append(entry);print(ident,glb.stat().st_size,flush=True)
bb.dump(R/'manifest.json',entries);bb.dump(R/'final-manifest.json',entries)
assert len(entries)==9
