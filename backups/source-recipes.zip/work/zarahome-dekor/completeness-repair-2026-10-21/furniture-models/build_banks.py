"""Complete missing official bench cards; photo-specific solids and intrinsic 2K PBR."""
from pathlib import Path
import sys,math,json,hashlib,shutil,re,io
sys.dont_write_bytecode=True
import numpy as np
from PIL import Image
ROOT=Path('/Users/USER/Documents/ChatGPT/Studio')
R=Path(__file__).resolve().parent
OLD=ROOT/'work/zarahome-dekor/ten-more-2026-10-21/furniture'
sys.path.insert(0,str(OLD))
import build_furniture as f
b=f.b;T=math.tau
dump=f.dump;sha=f.sha

def board(name,mat,size,centre=(0,0,0),radius=.004,grain=0):
 return f.rounded_board(name,mat,size,centre,radius,grain)

def merged(parts,name):
 return b.bm.merge(parts) if hasattr(b,'bm') else parts

def capped_beam(name,mat,a,d,r=.012):
 return b.tube(name,mat,[a,d],r,r,16,False,guide=[0,1,0] if abs(d[1]-a[1])<.8*np.linalg.norm(np.array(d)-a) else [1,0,0],uv_scale=.20)

def shoe_bench():
 mat='acacia';p=[board('rounded-acacia-seat',mat,(.85,.029,.31),(0,.4855,0),.012)]
 for sx in[-1,1]:
  for sz in[-1,1]:
   leg=f.profile(f'slightly-tapered-circular-leg-{sx}-{sz}',mat,[(0,0),(.0135,0),(.0155,.003),(.0163,.20),(.017,.471),(0,.477)],96)
   leg['_vertices']=[(x+sx*.391,y,z+sz*.121)for x,y,z in leg['_vertices']];p.append(leg)
 for shelf_y in[.135,.296]:
  for z in np.linspace(-.111,.111,5):p.append(board(f'open-shoe-shelf-slat-{shelf_y}-{z}',mat,(.785,.015,.030),(0,shelf_y,float(z)),.004))
  for sx in[-1,1]:p.append(board(f'short-shelf-bearer-{shelf_y}-{sx}',mat,(.020,.025,.245),(sx*.382,shelf_y-.016,0),.003,2))
 return p,['Two genuinely open slatted shoe shelves and four round tapered acacia legs','Rounded thick top and short shelf supports; no books or display accessories']

def acacia_double():
 p=[board('110cm-rounded-acacia-seat','acacia',(1.10,.028,.25),(0,.416,0),.0075),board('separate-lower-storage-plank','acacia',(1.072,.018,.172),(0,.166,0),.006)]
 for sx in[-1,1]:
  for sz in[-1,1]:p.append(board(f'four-square-acacia-leg-{sx}-{sz}','acacia',(.030,.416,.037),(sx*.50,.208,sz*.092),.003,1))
 for sz in[-1,1]:p.append(board(f'long-lower-shelf-stretcher-{sz}','acacia',(1.02,.029,.025),(0,.143,sz*.084),.0025))
 return p,['Full 110cm double bench with lower acacia shelf','Four rectangular legs and independent supporting stretchers match the official full view']

def weave(name,mat,width,depth,centre,plane='XZ',pitch=.0075,sag=0):
 """Actual capped flattened strands, alternating over/under, with open holes."""
 x0,y0,z0=centre;p=[]
 for direction in[0,1]:
  count=max(2,int((width if direction==0 else depth)/pitch))
  for i in range(count+1):
   cross=(i/count-.5)*(width if direction==0 else depth);length=depth if direction==0 else width
   steps=max(8,int(length/pitch*2));pts=[]
   for t in np.linspace(-.5,.5,steps+1):
    travel=float(t*length);xx,zz=(cross,travel)if direction==0 else(travel,cross)
    wave=.00065*math.cos(math.pi*travel/pitch+i*math.pi)*(1 if direction==0 else -1)
    yy=wave-sag*(1-(xx/(width/2))**2)*(1-(zz/(depth/2))**2)
    pts.append((x0+xx,y0+yy,z0+zz)if plane=='XZ'else(x0+xx,y0+zz,z0+yy))
   p.append(b.tube(f'{name}-strand-{direction}-{i}',mat,pts,.00042,.00112,6,False,guide=[0,1,0]if plane=='XZ'else[0,0,1],uv_scale=.08))
 return merged(p,name)

def rattan_cabinet():
 mat='darkrubberwood';p=[board('solid-rounded-rubberwood-top',mat,(1.10,.030,.430),(0,.445,0),.006),board('base-plinth',mat,(1.072,.028,.402),(0,.014,0),.004),board('inner-bottom-board',mat,(1.04,.018,.370),(0,.045,0),.003),board('rear-panel',mat,(1.055,.386,.019),(0,.238,-.199),.003)]
 for sx in[-1,1]:p.append(board(f'outer-rounded-side-{sx}',mat,(.030,.415,.410),(sx*.531,.222,0),.005,1))
 # Two square cane-front door frames are separate closed manufactured members.
 for index,cx in enumerate([-.263,.263]):
  for sx in[-1,1]:p.append(board(f'cane-door-stile-{index}-{sx}',mat,(.030,.379,.022),(cx+sx*.238,.235,.205),.004,1))
  for sy in[-1,1]:p.append(board(f'cane-door-horizontal-{index}-{sy}',mat,(.503,.031,.022),(cx,.235+sy*.174,.205),.004,0))
  p+=weave('vertical-woven-door-'+str(index),'darkcane',.444,.319,(cx,.235,.201),plane='XY',pitch=.0055)
 return p,['Two separately framed woven rattan front doors with real open mesh','Low rubberwood carcass, rounded top, base plinth and internal storage cavity','Display clothes, books and bowl excluded']

def elm_storage():
 mat='paleelm';p=[board('elm-hinged-lid',mat,(1.20,.024,.420),(0,.408,0),.002),board('inner-bottom',mat,(1.17,.017,.390),(0,.0355,0),.0015),board('back-wall',mat,(1.165,.343,.020),(0,.2165,-.200),.0015)]
 for sx in[-1,1]:p.append(board(f'elm-end-panel-{sx}',mat,(.021,.367,.398),(sx*.5795,.2115,0),.0015,2))
 p.append(board('front-full-lower-wall',mat,(1.157,.324,.021),(0,.204,.1995),.0012))
 # Real recessed centre finger notch: the upper front rim is physically absent here.
 for sx in[-1,1]:p.append(board(f'front-finger-notch-shoulder-{sx}',mat,(.428,.024,.021),(sx*.3645,.378,.1995),.0015))
 p.append(board('full-lower-plinth',mat,(1.178,.018,.400),(0,.023,0),.0015))
 for sx in[-1,1]:
  for sz in[-1,1]:p.append(board(f'small-elm-foot-{sx}-{sz}',mat,(.040,.023,.034),(sx*.489,.0115,sz*.168),.001))
 return p,['Hinged elm chest with open inner cavity, separate lid and actual front finger recess','Small timber feet and plinth; pale open-grain wood is intrinsic PBR','Books and bowls excluded']

def soft_box(name,mat,size,centre,radius=.015,quilt=False,pillow=False):
 half=np.array(size)/2;centre=np.array(centre);radius=min(radius,float(half.min())*.85);inner=half-radius
 coords=[]
 for a,h in enumerate(half):
  inset=h-radius;n=160 if a==0 and quilt else (64 if a==2 and quilt else 18)
  samples=np.r_[np.linspace(-h,-inset,7),np.linspace(-inset,inset,n),np.linspace(inset,h,7)]
  if quilt and a in[0,2]:
   seams=[-size[0]/6,size[0]/6]if a==0 else[0]
   samples=np.r_[samples,[s+d for s in seams for d in[-.012,-.008,-.004,-.002,0,.002,.004,.008,.012]]]
  coords.append(np.unique(samples))
 v=[];uv=[];faces=[]
 for axis in range(3):
  other=[a for a in range(3)if a!=axis];aa,bb=other
  for sign in[-1,1]:
   start=len(v)
   for u in coords[aa]:
    for w in coords[bb]:
     q=np.zeros(3);q[axis]=sign*half[axis];q[aa]=u;q[bb]=w;nearest=np.clip(q,-inner,inner);d=q-nearest;q=nearest+radius*d/np.linalg.norm(d)
     top=max(0,q[1]/half[1]);nx=q[0]/half[0];nz=q[2]/half[2]
     if quilt:
      indent=sum(math.exp(-((q[0]-s)/.0040)**2)for s in[-size[0]/6,size[0]/6])+.80*math.exp(-(q[2]/.0040)**2)
      q[1]+=top**3*(.012*(1-nx**8)*(1-nz**8)-.010*indent)
     elif pillow:q[1]+=top**3*.023*(1-nx**4)*(1-nz**4)
     else:q[1]+=top**3*.004*(1-nx**6)*(1-nz**6)
     q[1]+=.00045*math.sin(21*nx+13*nz)*(1-top)*max(0,abs(nx)-.8)
     q+=centre;v.append(tuple(q));uv.append((q[0]*3+.5,q[2]*3+.5)if axis==1 else(q[0]*3+q[2]*3+.5,q[1]*3+.5))
   orient=np.cross(np.eye(3)[aa],np.eye(3)[bb])[axis]*sign
   for i in range(len(coords[aa])-1):
    for j in range(len(coords[bb])-1):
     a=start+i*len(coords[bb])+j;c=a+len(coords[bb]);tri=[(a,c,a+1),(a+1,c,c+1)];faces+=tri if orient>0 else[(x,z,y)for x,y,z in tri]
 return b.solid(name,mat,v,faces,uv)

def seam_line(name,mat,pts,r=.00052):
 return b.tube(name,mat,pts,r,r,6,False,guide=[0,1,0],uv_scale=.025)

def linen_storage():
 p=[]
 p.append(soft_box('linen-upholstered-storage-body','linen',(1.595,.354,.354),(0,.197,0),.018))
 p.append(board('dark-recess-under-lid','shadowcloth',(1.56,.008,.330),(0,.378,0),.002))
 p.append(soft_box('separate-padded-linen-lid','linen',(1.60,.070,.360),(0,.416,0),.016))
 for sx in[-1,1]:
  for sz in[-1,1]:p.append(b.cylinder(f'small-recessed-wooden-foot-{sx}-{sz}','warmwood',.020,0,.020,(sx*.725,0,sz*.128),64))
 # Continuous restrained piping at the upholstered lid, never a projected shadow.
 for sz in[-1,1]:p.append(seam_line(f'linen-long-lid-stitch-{sz}','linen_thread',[(-.775,.429,sz*.179),(.775,.429,sz*.179)],.00048))
 return p,['Soft linen-covered storage chest with rounded corners and separate padded lid','Physical narrow lid gap, tiny recessed timber feet and subtle upholstery piping','Woven linen microrelief and roughness are generated intrinsically at native 2K']

def woven_bench(color):
 mat='paleash'if color=='052'else'amberash';cane='palerattan'if color=='052'else'amberrattan';p=[]
 for sz in[-1,1]:
  rail=board(f'continuous-scalloped-front-back-rail-{sz}',mat,(1.40,.058,.030),(0,.433,sz*.180),.004)
  rail['_vertices']=[(x,y+.008*math.cos(6*math.pi*x/1.4),z)for x,y,z in rail['_vertices']];p.append(rail)
 for xx in[-.681,-.226,.226,.681]:p.append(board(f'transverse-seat-frame-{xx}',mat,(.028,.043,.338),(xx,.441,0),.004,2))
 for cx in[-.454,0,.454]:p+=weave('three-inset-cane-seat-'+str(cx),cane,.421,.316,(cx,.451,0),'XZ',.0075,sag=.007)
 for sx in[-1,1]:
  for sz in[-1,1]:
   leg=f.profile(f'tapered-round-splayed-ash-leg-{sx}-{sz}',mat,[(0,0),(.012,0),(.014,.004),(.018,.27),(.020,.412),(0,.419)],96)
   leg['_vertices']=[(x+sx*(.638-.009*y/.419),y,z+sz*(.162-.010*y/.419))for x,y,z in leg['_vertices']];p.append(leg)
  # Crossed bracing occupies each short end, matching the photographic X frame.
  for k in[-1,1]:p.append(capped_beam(f'short-end-crossed-ash-brace-{sx}-{k}',mat,(sx*.635,.114,k*.159),(sx*.629,.418,-k*.151),.0090))
 return p,['Three independently woven cane seat panels with real strand holes and slight sag','Continuous subtly scalloped timber front/back profiles and four turned splayed legs','Two actual crossing brace members on each short end; no books or other accessories']

def daybed(color):
 mat='creamleather'if color=='733'else'blackleather';thread='creamthread'if color=='733'else'blackthread';p=[]
 # Nominal outside scale is fitted once to the source 202×37×80cm envelope.
 for sx in[-1,1]:
  for sz in[-1,1]:p.append(board(f'brushed-flat-steel-daybed-leg-{sx}-{sz}','satinsteel',(.013,.094,.052),(sx*.739,.047,sz*.307),.0015,1))
 for sz in[-1,1]:p.append(board(f'long-slim-steel-base-rail-{sz}','satinsteel',(1.98,.020,.026),(0,.104,sz*.371),.0015))
 for sx in[-1,1]:p.append(board(f'steel-end-base-rail-{sx}','satinsteel',(.026,.020,.742),(sx*.977,.104,0),.0015,2))
 p.append(board('concealed-mattress-platform','shadowcloth',(1.92,.016,.72),(0,.117,0),.002))
 p.append(soft_box('six-panel-capitonne-leather-mattress',mat,(2.02,.137,.80),(0,.1965,0),.018,quilt=True))
 # Loose head pillow is part of DAYBED 02 as explicitly stated by the official text.
 p.append(soft_box('included-loose-leather-head-pillow',mat,(.455,.092,.650),(-.735,.313,0),.035,pillow=True))
 # Physical welt around the mattress and repeated actual thread stitches.
 for sz in[-1,1]:
  p.append(seam_line(f'long-edge-leather-welt-{sz}',mat,[(-.984,.254,sz*.398),(.984,.254,sz*.398)],.00075))
  stitches=[]
  for i,x in enumerate(np.arange(-.978,.977,.0065)):
   stitches.append(seam_line(f'long-real-thread-{sz}-{i}',thread,[(float(x),.249,sz*.399),(float(x+.0031),.249,sz*.399)],.00020))
  p+=merged(stitches,'mattress-stitches-'+str(sz))
 for xx in[-2.02/6,2.02/6]:
  pts=[]
  for z in np.linspace(-.379,.379,140):
   crown=.012*(1-(xx/1.01)**8)*(1-(z/.40)**8)
   yy=.265+crown-.010*(1+.8*math.exp(-(z/.004)**2))+.00025;pts.append((xx,yy,float(z)))
  p.append(seam_line('physical-cross-mattress-seam-'+str(xx),thread,pts,.00043))
 pts=[]
 for xx in np.linspace(-.976,.976,220):
  indent=sum(math.exp(-((xx-s)/.0040)**2)for s in[-2.02/6,2.02/6])+.80
  pts.append((float(xx),.265+.012*(1-(xx/1.01)**8)-.010*indent+.00025,0))
 p.append(seam_line('central-lengthwise-capitonne-seam',thread,pts,.00043))
 # Double stitched perimeter of included head pillow, fitted to its visible rounded side.
 for zz in[-1,1]:p.append(seam_line(f'head-pillow-side-seam-{zz}',thread,[(-.929,.312,zz*.322),(-.541,.312,zz*.322)],.00040))
 return p,['Brushed flat steel legs and a slender separate rectangular base frame','Soft leather mattress with six actual quilted panels, physical seam troughs and fine real thread geometry','Included independent head pillow is a separate capped mesh; books and other display objects excluded','Only overall official dimensions are verified; local seam, padding and pillow proportions are photo interpreted']

f.MATERIALS.update({'acacia':([157,101,49],.44,0,'wood'),'paleelm':([171,128,76],.58,0,'wood'),'darkrubberwood':([99,58,35],.40,0,'wood'),'paleash':([171,142,94],.51,0,'wood'),'amberash':([131,79,32],.43,0,'wood'),'palerattan':([182,153,102],.66,0,'wood'),'amberrattan':([142,97,45],.58,0,'wood'),'darkcane':([101,66,39],.66,0,'wood')})
CUSTOM={'linen':([211,201,182],.82,'linen'),'linen_thread':([191,178,151],.77,'linen'),'shadowcloth':([34,30,25],.87,'cloth'),'creamleather':([224,216,198],.39,'leather'),'blackleather':([27,22,18],.34,'leather'),'creamthread':([194,179,151],.70,'thread'),'blackthread':([43,32,23],.62,'thread')}

def custom_texture(out,key):
 n=2048;rgb,rough,kind=CUSTOM[key];rng=np.random.default_rng(int.from_bytes(key.encode()[:8],'little'));u=np.arange(n,dtype=np.float32)[None,:]/n;v=np.arange(n,dtype=np.float32)[:,None]/n
 noise=rng.normal(0,1,(n,n)).astype(np.float32);cloud=f.field(rng,24,n);slub=f.field(rng,128,n)
 if kind in['linen','cloth','thread']:
  warp=np.sin(T*(u*360+.05*np.sin(v*T*22)));weft=np.sin(T*(v*362+.04*np.sin(u*T*19)));h=.35*warp+.35*weft+.13*slub+.06*noise
  variation=warp*1.7+weft*1.7+cloud*1.3+noise*.5;rr=rough+.025*warp+.023*weft+.018*slub
 else:
  pores=np.sin(T*(u*104+.30*slub))*np.sin(T*(v*109+.30*cloud));h=.17*pores+.11*slub+.08*noise
  variation=cloud*.8+pores*.6+noise*.25;rr=rough+.025*pores+.021*slub
 colour=np.clip(np.array(rgb)+variation[:,:,None],0,255).astype(np.uint8);dx=np.gradient(h,axis=1);dy=np.gradient(h,axis=0);nn=np.stack([-dx,-dy,np.ones_like(dx)],axis=2);nn/=np.linalg.norm(nn,axis=2,keepdims=True);orm=np.zeros((n,n,3),np.uint8);orm[:,:,0]=255;orm[:,:,1]=np.rint(np.clip(rr,.08,.96)*255)
 for slot,arr in [('albedo',colour),('normal',np.rint((nn+1)*127.5).astype(np.uint8)),('orm',orm)]:Image.fromarray(arr,'RGB').save(out/(key+'-'+slot+'-2k.png'),optimize=True)
 return dict(baseColorFactor=[1,1,1,1],baseColorTexture=key+'-albedo-2k.png',normalTexture=key+'-normal-2k.png',metallicRoughnessTexture=key+'-orm-2k.png',metallic=1,roughness=1,normalScale=.24 if kind=='leather'else .30,alphaMode='OPAQUE',doubleSided=False,extras=dict(native_resolution=2048,intrinsic_material=True,photo_pixels_baked=False,baked_reflections=False))

def materials(out,keys):
 cache=R/'material-cache';cache.mkdir(exist_ok=True);result={};maps={}
 for key in keys:
  marker=cache/(key+'.json')
  if not marker.exists():
   definition=custom_texture(cache,key)if key in CUSTOM else f.textures(cache,[key])[key];dump(marker,definition)
  definition=json.loads(marker.read_text());result[key]=definition
  for slot in['albedo','normal','orm']:
   name=key+'-'+slot+'-2k.png';shutil.copyfile(cache/name,out/name);maps[name]=dict(sha256=sha(out/name),dimensions=[2048,2048],bytes=(out/name).stat().st_size)
 dump(out/'material-validation.json',dict(valid=True,native_resolution=2048,maps=maps,intrinsic_pbr=True,photo_pixels_baked=False,baked_reflections=False,source_jpegs_unmodified=True));return result

BUILD={'4564/077/700':(shoe_bench,'Masif akasya · İki açık çıtalı raf'),'5152/073/700':(rattan_cabinet,'Kauçuk ağacı · İki örgü rattan kapak'),'6182/073/052':(linen_storage,'Keten astarlı/döşemeli ahşap saklama bankı'),'8335/073/052':(elm_storage,'Karaağaç · Üst kapak ve parmak girintisi'),'6170/073/052':(lambda:woven_bench('052'),'Açık ahşap · Üç örgü rattan oturak'),'6170/073/700':(lambda:woven_bench('700'),'Kahverengi ahşap · Üç örgü rattan oturak'),'1567/073/700':(acacia_double,'Masif akasya · 110cm çiftli alt raflı bank'),'1380/077/733':(lambda:daybed('733'),'Krem deri · Kapitone · Fırçalanmış çelik'),'1380/077/800':(lambda:daybed('800'),'Siyah deri · Kapitone · Fırçalanmış çelik')}

def main():
 research=json.loads((R/'research.json').read_text());old=json.loads((R/'manifest.json').read_text())if(R/'manifest.json').exists()else[];byid={x['id']:x for x in old};selected=sys.argv[1:]or list(BUILD)
 for sku in selected:
  source=next(x for x in research if x['sku']==sku);cfg,label=BUILD[sku];dims=source['dimensions_cm'];w,h,d=dims;ident=(sku.replace('/','-')+f'-h{h:g}-w{w:g}-d{d:g}').replace('.','p');out=R/'models'/ident;out.mkdir(parents=True,exist_ok=True);print('geometry',ident,flush=True);parts,features=cfg()
  vertices=np.concatenate([np.asarray(q['_vertices'])for q in parts]);lo=vertices.min(0);hi=vertices.max(0);target=np.array(dims)/100;scale=target/(hi-lo);centre=np.array([(hi[0]+lo[0])/2,lo[1],(hi[2]+lo[2])/2]);meshes=[];checks=[]
  for part in parts:
   part['_vertices']=[tuple((np.array(v)-centre)*scale)for v in part['_vertices']];mesh,check=f._finalize(part);meshes.append(mesh);checks.append(check)
  mats=materials(out,sorted({x['material']for x in meshes}));note='Resmî Türkiye ürününün dış ölçüleri kullanıldı. Kesitler, bağlantılar, örgü, dolgu ve dikişlerin yerel biçimleri orijinal ürün fotoğraflarından yorumlandı. Fotoğraf pikselleri ve fotoğraf ışığı materyallere işlenmedi.'
  meta=dict(id=ident,name=source['title'],sku=sku,url=source['url'],category='Banklar',dimensions_cm=dims,source_dimensions_hwd_cm=[h,w,d],estimated_dimensions=False,source_market='Türkiye',size_source_kind='official_tr',size_source_urls=source['size_source_urls'],scale_note=note,units='metres',up_axis='Y',origin='bottom bounding-box centre',source_images=[im['url']for im in source['images']],photo_pixels_baked=False,baked_reflections=False)
  mp=out/'model.json';dump(mp,dict(metadata=meta,materials=mats,meshes=meshes));dump(out/'geometry-validation.json',dict(valid=True,features=features,mesh_count=len(meshes),triangles=sum(x['triangles']for x in checks),dimensions_metres=target.tolist(),affine_fit_scale=scale.tolist(),source_local_details_photo_inferred=True,meshes=checks));report=f.export_assets(mp,out,ident);glb=out/(ident+'.glb');doc,data=f.read_glb(glb);doc['samplers']=[dict(magFilter=9729,minFilter=9987,wrapS=10497,wrapT=10497)]
  for tex in doc.get('textures',[]):tex['sampler']=0
  f.write_glb(glb,doc,data);digest=sha(glb);report['deliverable_sha256']['glb']=digest;report['glb_bytes']=glb.stat().st_size;dump(report['files']['validation'],report)
  entry={k:meta[k]for k in['id','name','sku','url','category','dimensions_cm','source_dimensions_hwd_cm','estimated_dimensions','source_market','size_source_kind','size_source_urls','scale_note']};entry.update(model_path=str(mp),asset_dir=str(out),glb_path=str(glb),sha256=digest,bytes=glb.stat().st_size,material_label=label,source_images=source['images'],geometry_validation=str(out/'geometry-validation.json'),material_validation=str(out/'material-validation.json'),model_revision='complete-banks-photo-specific-v1',source_anomalies=source.get('source_anomalies',[]));byid[ident]=entry;dump(out/'manifest-entry.json',entry)
  current={e['id']:e for e in json.loads((R/'manifest.json').read_text())}if(R/'manifest.json').exists()else{}
  current.update(byid);dump(R/'manifest.json',list(current.values()));print('ready',ident,glb.stat().st_size,flush=True)
if __name__=='__main__':main()
