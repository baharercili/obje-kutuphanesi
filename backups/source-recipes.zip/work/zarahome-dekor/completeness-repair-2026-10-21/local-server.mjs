import http from 'node:http';
import {readFile,writeFile,rename,mkdir,stat} from 'node:fs/promises';
import {createReadStream} from 'node:fs';
import {Readable} from 'node:stream';
import {createHash} from 'node:crypto';
import {ensureModelLocal,verifiedModelPath} from './local-model-cache.mjs';
import worker,{modelManifest,catalogAssetManifest} from '../../../sites/zarahome-vazo-kutuphanesi-final-378/worker/index.js';
const site=new URL('../../../sites/zarahome-vazo-kutuphanesi-final-378/',import.meta.url);
const stateDir=new URL('./local-state/',import.meta.url),stateFile=new URL('selections.json',stateDir);
await mkdir(stateDir,{recursive:true});
let saved={};try{saved=JSON.parse(await readFile(stateFile,'utf8'));}catch(e){if(e.code!=='ENOENT')throw e;}
const entries=new Map(Object.entries(saved));let writing=Promise.resolve();
function persist(){const snapshot=JSON.stringify(Object.fromEntries(entries),null,2)+'\n';writing=writing.then(async()=>{const temp=new URL('selections.json.tmp',stateDir);await writeFile(temp,snapshot);await rename(temp,stateFile);});return writing;}
const records=new Map();
const modelByFilename=new Map(modelManifest.models.flatMap(r=>r.accepted_filenames.map(name=>[name,r])));
const sourceFile=r=>new URL((r.route?'ui/':'model-source/')+r.filename,site);
await Promise.all([...modelManifest.models,...catalogAssetManifest].map(async r=>{try{const f=await stat(new URL((r.route?'ui/':'model-source/')+r.filename,site));if(f.isFile()&&f.size===r.bytes)records.set(r.key,r);}catch(e){if(e.code!=='ENOENT')throw e;}}));
const descriptor=r=>({key:r.key,size:r.bytes,customMetadata:{sha256:r.sha256},etag:r.sha256,httpEtag:'"'+r.sha256+'"'});
const bucket={
 async head(key){return records.has(key)?descriptor(records.get(key)):entries.get(key)||null;},
 async get(key){if(records.has(key)){const r=records.get(key);return{...descriptor(r),body:Readable.toWeb(createReadStream(r.route?sourceFile(r):verifiedModelPath(r,sourceFile(r))))};}const item=entries.get(key);return item?{...item,json:async()=>JSON.parse(item.body)}:null;},
 async list(){return{objects:[...records.values()].map(descriptor),truncated:false};},
 async put(key,body,options={}){if(!['zarahome/reference-selection/v1.json','hipicon/reference-selection/v1.json','hipicon/hidden-products/v1.json'].includes(key))throw Error('Local model files are managed in the workspace.');const old=entries.get(key),condition=options.onlyIf;if(condition?.get('If-None-Match')==='*'&&old)return null;if(condition?.has('If-Match')&&condition.get('If-Match')!==old?.httpEtag)return null;const text=String(body),etag=createHash('sha256').update(text).digest('hex');const item={body:text,etag,httpEtag:'"'+etag+'"'};entries.set(key,item);await persist();return item;}
};
const health={service:'obje-kutuphanesi-local',pid:process.pid,startedAt:new Date().toISOString(),models:modelManifest.models.length};
const server=http.createServer(async(req,res)=>{try{
if(req.url==='/_local/health'&&['GET','HEAD'].includes(req.method)){res.writeHead(200,{'content-type':'application/json; charset=utf-8','cache-control':'no-store'});res.end(req.method==='HEAD'?undefined:JSON.stringify(health));return;}
const pathname=new URL(req.url,'http://127.0.0.1:18937').pathname;
if(req.method==='GET'&&pathname.startsWith('/models/')){const model=modelByFilename.get(pathname.slice(8));if(model)await ensureModelLocal(model,sourceFile(model));}
let size=0;const parts=[];for await(const part of req){size+=part.length;if(size>131072){res.writeHead(413);res.end();return;}parts.push(part);}const init={method:req.method,headers:req.headers};if(!['GET','HEAD'].includes(req.method))init.body=Buffer.concat(parts);const response=await worker.fetch(new Request('http://127.0.0.1:18937'+req.url,init),{BUCKET:bucket},{});res.writeHead(response.status,Object.fromEntries(response.headers));if(response.body){const stream=Readable.fromWeb(response.body);stream.on('error',()=>res.destroy());stream.pipe(res);}else res.end();}catch{if(!res.headersSent)res.writeHead(500,{'content-type':'text/plain; charset=utf-8'});res.end('Yerel dosya açılamadı.');}});
server.on('error',error=>{console.error(error);process.exitCode=1;});
server.listen(18937,'127.0.0.1',async()=>{
  await writeFile(new URL('server-process.json',stateDir),JSON.stringify(health,null,2)+'\n');
  console.log('Yerel kütüphane açık: http://127.0.0.1:18937/ — '+modelManifest.models.length+' model; seçimler yerelde kaydedilir.');
});
