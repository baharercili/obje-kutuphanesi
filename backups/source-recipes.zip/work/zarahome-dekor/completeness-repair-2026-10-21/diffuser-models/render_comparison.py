from pathlib import Path
import sys,json,math
import numpy as np
from PIL import Image,ImageDraw
R=Path(__file__).resolve().parent
manifest=json.loads((R/'manifest.json').read_text());sources=json.loads((R/'reference-downloads.json').read_text());configs={p['id']:p for p in json.loads((R/'photo-classifications.json').read_text())}if(R/'photo-classifications.json').exists()else{}
sys.dont_write_bytecode=True
import importlib.util
sp=importlib.util.spec_from_file_location('builder',R/'build_diffusers.py');builder=importlib.util.module_from_spec(sp);sp.loader.exec_module(builder)
plan={p['id']:p for p in builder.PLAN};palette={k:v[0]for k,v in builder.COLOURS.items()}
def render(e,size=(300,410)):
 doc=json.loads(Path(e['model_path']).read_text());c=builder.cfg(plan[e['id']]);meshes=doc['meshes'];cam=np.array([2.2,1.5,6.]);cam/=np.linalg.norm(cam);right=np.cross([0.,1.,0.],cam);right/=np.linalg.norm(right);up=np.cross(cam,right);lamp=np.array([-3.,5.,6.]);lamp/=np.linalg.norm(lamp);allpoints=np.concatenate([np.asarray(m['positions']).reshape(-1,3)for m in meshes]);proj=np.c_[allpoints@right,allpoints@up];lo=proj.min(0);hi=proj.max(0);scale=min((size[0]-36)/(hi[0]-lo[0]),(size[1]-35)/(hi[1]-lo[1]));center=(lo+hi)/2;im=Image.new('RGB',size,(243,241,232));dr=ImageDraw.Draw(im);triangles=[]
 for m in meshes:
  v=np.asarray(m['positions']).reshape(-1,3);ff=np.asarray(m['indices']).reshape(-1,3);nn=np.asarray(m['normals']).reshape(-1,3);xy=np.c_[v@right,v@up];xy=(xy-center)*scale;xy[:,0]+=size[0]/2;xy[:,1]=size[1]/2-xy[:,1];n=nn[ff].mean(1);n/=np.linalg.norm(n,axis=1)[:,None];visible=n@cam>-.02;shade=.42+.58*np.clip(n@lamp,0,1);key=m['material'];rgb=palette.get(key,palette[c['glass']]if key.startswith('glass_')else[226,218,192]);depth=(v[ff]@cam).mean(1)
  for j in np.flatnonzero(visible):triangles.append((float(depth[j]),xy[ff[j]].tolist(),tuple(np.clip(np.array(rgb)*shade[j],0,255).astype('uint8'))))
 for _,poly,col in sorted(triangles,key=lambda t:t[0]):dr.polygon([tuple(p)for p in poly],fill=col)
 return im
(R/'previews').mkdir(exist_ok=True);(R/'comparisons').mkdir(exist_ok=True)
for page,start in enumerate(range(0,len(manifest),24)):
 group=manifest[start:start+24];cols=3;cw=640;ch=475;sheet=Image.new('RGB',(cols*cw,math.ceil(len(group)/cols)*ch),'white');draw=ImageDraw.Draw(sheet)
 for j,e in enumerate(group):
  x=j%cols*cw;y=j//cols*ch;model=render(e);model.save(R/'previews'/(e['id']+'.png'));idx=e['category_card_indices'][0];source=next(s for s in sources if s['index']==idx);photo=Image.open(source['local_master']);photo.thumbnail((300,410));sheet.paste(photo,(x+(300-photo.width)//2,y+(410-photo.height)//2));sheet.paste(model,(x+325,y));draw.text((x+6,y+418),e['id'],fill='black');draw.text((x+6,y+436),str(e['dimensions_cm'])+' '+e['profile_family']+' '+e['display_pose'],fill='black');draw.text((x+6,y+454),e['source_market'],fill='black')
 sheet.save(R/'comparisons'/('comparison-'+str(page)+'.png'));print('Rendered page',page,len(group),flush=True)
print('TOTAL',len(manifest),flush=True)
