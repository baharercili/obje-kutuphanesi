from pathlib import Path
import sys,json,hashlib,re,shutil
sys.dont_write_bytecode=True
R=Path(__file__).resolve().parent
sys.path.insert(0,str(R.parents[3]/'work/zarahome-dekor'))
from export_catalog import read_glb,write_glb
def dump(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
manifest=json.loads((R/'manifest.json').read_text());configs={p['id']:p for p in json.loads((R/'photo-classifications.json').read_text())}
for e in manifest:
 c=configs[e['id']];features=e['photographed_features'][:]
 if c['shape']=='apothecary'and c['pose']=='installed':features[2]='Exposed glass neck and rounded glass lip in the photographed ready-for-use pose; transport stopper removed'
 if c['section']=='rounded_rect':features.append('Flattened rounded-rectangle glass body with a circular neck and separate wooden stopper')
 if c['flutes']:features.append(str(c['flutes'])+' physical vertical glass ribs, restricted to the photographed lower section for tassel bottles')
 if c['tassel']:features.append('Visible flexible neck cord, binding knot,48 independently closed tassel strands and a small metal tag; tassel rotated toward the front in this display pose')
 if c['shape']=='white_powdery':features.append('Broad rounded opaque white stopper over a separately modelled visible gold neck band')
 e['photographed_features']=list(dict.fromkeys(features))
 if c['index']in[62,63,64,66,84,86]:e['measurement_evidence_temporal_note']='The identicalSKU H/W/D is preserved from an official Zara Home indexed snapshot, crawled about5–6months before this audit. The current Turkey card confirms the product identity; the snapshot supplies dimensions.'
 model=Path(e['model_path']);doc=json.loads(model.read_text())
 for key in['photographed_features','measurement_evidence_temporal_note']:
  if key in e:doc['metadata'][key]=e[key]
 dump(model,doc);gqa=Path(e['geometry_validation']);q=json.loads(gqa.read_text());q['photographed_features']=e['photographed_features'];dump(gqa,q)
 glb=Path(e['glb_path']);gd,binary=read_glb(glb);gd['extras']['metadata']=doc['metadata'];write_glb(glb,gd,binary);e['bytes']=glb.stat().st_size;e['sha256']=sha(glb);validation=glb.with_suffix('.validation.json');rep=json.loads(validation.read_text());rep['source_sha256']=sha(model);rep['glb_bytes']=e['bytes'];rep['deliverable_sha256']['glb']=e['sha256'];dump(validation,rep)
dump(R/'manifest.json',manifest)
pending=json.loads((R/'needs-measurement.json').read_text());live_source=R.parent/'live-product-details-from-root.json';shutil.copyfile(live_source,R/'raw/live-product-details-from-root.json');live=json.loads(live_source.read_text());cat=json.loads((R/'raw/category-snapshot.json').read_text());corrections=[]
for p in pending:
 family=p['url'].split('-l')[-1].split('?')[0]
 for detail in live:
  if detail.get('url','').split('-l')[-1].split('?')[0]!=family:continue
  text=detail.get('text','')+' '+json.dumps(detail.get('buttons',[]),ensure_ascii=False);skus=list(dict.fromkeys(re.findall(r'\b\d{4}/703/\d{3}\b',text)))
  if skus:p.update(observed_skus=skus,status='needs_measurement',identity_source_kind='official_tr_live_product',identity_evidence_file='raw/live-product-details-from-root.json',reason='Live Turkey identity verified; full physicalH/W/D was not observed in product text/details, and no same-product official dimensions have been found.')
pending_map={p['index']:p for p in pending}
for i,p in enumerate(cat['products']):
 hits=[m for m in manifest if i in m['category_card_indices']]
 if hits:
  m=hits[0];oldsku=p.get('sku');oldsizes=p.get('sizes');p.update(sku=m['sku'],observed_skus=[m['sku']],matched_model_ids=[e['id']for e in hits],missing_model=False,model_status='ready',model_details_complete=True,measurement_scope_note=m['scale_note'],size_source_kind=m['size_source_kind'],source_market=m['source_market'])
  p['sizes']=[dict(dimensions_hwd_cm=e['source_dimensions_hwd_cm'],source_url=e['size_source_urls'][0],source_file=str(R/e['size_evidence_file']),estimated_dimensions=False,matched_model_ids=[e['id']],missing_model=False)for e in hits]
  if oldsku!=m['sku']or len([z for z in oldsizes or []if z.get('dimensions_hwd_cm')])!=len(hits):corrections.append(dict(index=i,title=p['title'],url=p['url'],image_code=p.get('image_code'),previous_sku=oldsku,verified_sku=m['sku'],source_urls=m['size_source_urls'],note='Direct product URL/SKU evidence replaces fragrance-level sibling joins; an image code alone never creates anotherSKU.'))
 elif i in pending_map:
  need=pending_map[i];p.update(model_status=need['status'],missing_model=True,model_details_complete=False,needs_measurement_reason=need['reason'])
  if need.get('observed_skus'):p.update(sku=need['observed_skus'][0],observed_skus=need['observed_skus'])
 else:p['model_status']='existing'
dump(R/'needs-measurement.json',pending);dump(R/'identity-corrections.json',corrections);dump(R/'inventory-production.json',dict(categories=[cat],new_models=len(manifest),existing_cards=3,not_ready_cards=len(pending),all_category_products_ready=False,limitations=['Ten cards remain explicitly not ready: nine products without full confirmed product-specific measurements, plus one grouped catalogue card.','Individual reed manufacturing lengths/counts, flexible tassel placement and other local details are photo-inferred.','Some official H/W/D evidence is a cross-market indexed snapshot for the identicalSKU, recorded per model.']))
batch=json.loads((R/'batch-validation.json').read_text());batch.update(models_ready=len(manifest),total_glb_bytes=sum(e['bytes']for e in manifest),maximum_glb_bytes=max(e['bytes']for e in manifest));dump(R/'batch-validation.json',batch)
print('FROZEN_METADATA_READY',len(manifest),'models',sum(e['bytes']for e in manifest),'bytes',len(corrections),'identity/size corrections',len(pending),'pending cards',flush=True)
