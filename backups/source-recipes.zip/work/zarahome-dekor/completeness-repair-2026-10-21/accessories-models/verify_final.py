from pathlib import Path
import json,hashlib,struct,io
from PIL import Image
R=Path(__file__).resolve().parent
rows=json.loads((R/'manifest.json').read_text());ids=set();textures=0
for e in rows:
 assert e['id'] not in ids;ids.add(e['id']);f=Path(e['glb_path']);b=f.read_bytes();assert hashlib.sha256(b).hexdigest()==e['sha256'];magic,ver,length=struct.unpack_from('<4sII',b);assert magic==b'glTF' and ver==2 and length==len(b);jl,jt=struct.unpack_from('<I4s',b,12);d=json.loads(b[20:20+jl]);bl,bt=struct.unpack_from('<I4s',b,20+jl);binary=b[28+jl:];assert bt==b'BIN\0' and len(binary)==bl
 for im in d['images']:
  assert 'uri' not in im;v=d['bufferViews'][im['bufferView']];off=v.get('byteOffset',0);x=Image.open(io.BytesIO(binary[off:off+v['byteLength']]));assert x.size==(2048,2048);textures+=1
 for m in d['meshes']:
  for pr in m['primitives']:assert {'POSITION','NORMAL','TEXCOORD_0'}<=set(pr['attributes']) and 'indices' in pr
 q=json.loads(Path(e['geometry_validation']).read_text());assert q['valid'] and q['degenerate_uv_triangles']==0 and q['max_bounds_error_m']<2e-8 and q['max_unit_normal_error']<1e-6;assert all(m['closed_after_uv_seam_weld'] and m['consistent_winding'] and m['signed_volume_m3']>0 for m in q['meshes']);assert e['source_images'];assert all(i['url'].startswith('https://static.zarahome.net/') for i in e['source_images']);validation=json.loads(f.with_suffix('.validation.json').read_text());assert validation['deliverable_sha256']['glb']==e['sha256'];assert validation['source_sha256']==hashlib.sha256(Path(e['model_path']).read_bytes()).hexdigest()
 assert d['extras']['metadata']['dimensions_cm']==e['dimensions_cm'] and d['extras']['metadata']['estimated_dimensions']==e['estimated_dimensions']
 if e.get('axis_ambiguity'):assert e['estimated_dimensions'] and not q['overall_dimensions_official']

known={}
for name in ['reference-downloads.json','reference-downloads-hero.json']:
 for r in json.loads((R/name).read_text()):
  assert hashlib.sha256(Path(r['local_master']).read_bytes()).hexdigest()==r['sha256'];known[str(Path(r['local_master']).resolve())]=r
masters=[]
for f in (R/'source-images').glob('*.jpg'):
 im=Image.open(f);k=known.get(str(f.resolve()),{});masters.append({'path':str(f),'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'pixel_dimensions':list(im.size),'format':im.format,'mode':im.mode,'icc_present':bool(im.info.get('icc_profile')),'source_url':k.get('photo',{}).get('url'),'original_unchanged':True})
(R/'source-image-master-inventory.json').write_text(json.dumps(masters,ensure_ascii=False,indent=2)+'\n')
coverage=[]
source=json.loads((R/'raw/category-snapshot.json').read_text())
for r in source:
 fc=r['url'].split('-l')[-1].split('?')[0];matches=[e for e in rows if e['url'].split('-l')[-1].split('?')[0]==fc]
 coverage.append({'title':r['title'],'url':r['url'],'existing_model_ids':r['matched_model_ids'],'new_family_model_ids':[m['id'] for m in matches],'status':'existing' if r['matched_model_ids'] else 'new_family_variants_ready' if matches else 'needs_measurement','note':'Family variants include all observed colours and official visible sizes; exact card colour is preserved in each new model SKU/source URL.'})
assert len(coverage)==23 and all(c['status']!='needs_measurement' for c in coverage)
(R/'card-coverage.json').write_text(json.dumps(coverage,ensure_ascii=False,indent=2)+'\n')
result={'valid':True,'models_verified':len(rows),'unique_ids':len(ids),'unique_skus':len({e['sku'] for e in rows}),'embedded_2048_images_verified':textures,'total_glb_bytes':sum(r['bytes'] for r in rows),'all_manifest_and_export_hashes_match':True,'all_meshes_have_positions_normals_uvs_indices':True,'all_component_topology_bounds_uv_normal_checks_pass':True,'source_master_files':len(masters),'all_recorded_source_master_hashes_unchanged':True,'full_category_card_count':23,'category_cards_with_existing_models':sum(c['status']=='existing' for c in coverage),'category_cards_with_new_family_models':sum(c['status']=='new_family_variants_ready' for c in coverage),'category_cards_without_any_model':0,'explicitly_inferred_dimension_models':[e['id'] for e in rows if e.get('estimated_dimensions')],'inference_notes_file':'needs-measurement.json','visual_review_file':'all-models-comparison.png','source_limits':['Same-family official sizes from another market are identified per model.','Two dimension interpretations are explicitly marked estimated/axis_ambiguity and retain the official raw values or size label.','Parts are independently closed; global Boolean intersection tests are not performed.']}
(R/'final-validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False,indent=2))
