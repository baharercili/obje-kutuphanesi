from pathlib import Path
import json,re,urllib.parse,hashlib,shutil
R=Path(__file__).resolve().parent;N=R.parent;WORK=N.parent

def dump(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def key(u):
 x=urllib.parse.urlparse(u);m=re.search(r'-l([\dA-Za-z]+)',x.path);return(m[1]if m else x.path,urllib.parse.parse_qs(x.query).get('pelement',[''])[0])
def resolve():
 a=json.loads((R/'source-inventory-frozen.json').read_text());live=json.loads((N/'live-product-details-from-root.json').read_text());saved=[];pending=[];recovered=json.loads((R/'tr-official-search-recovery.json').read_text())if(R/'tr-official-search-recovery.json').exists()else[]
 for p in a:
  hits=[(i,q)for i,q in enumerate(live)if key(q.get('url',''))==key(p['url'])];p['source_anomalies']=p.get('source_anomalies',[]);p['raw_url_family_code']=p['family_path_code'];p['raw_gallery_image_codes']=p.get('image_codes_observed',[])
  if hits:
   index,q=hits[-1];saved.append(q);p['official_live_detail']=q;p['live_evidence_pointer']=str(N/'live-product-details-from-root.json')+'#/'+str(index)
   if q.get('sku'):
    if p.get('sku')and p['sku']!=q['sku']:p['source_anomalies'].append('Official TR copy-code button corrects prior SKU '+p['sku']+' to '+q['sku'])
    p['sku']=q['sku']
   labels=q.get('dimension_cell_labels',[]);vals=[]
   for label in labels:
    m=re.search(r'(Yükseklik|Genişlik|Derinlik)\s*:\s*(\d+(?:[.,]\d+)?)\s*cm',label,re.I)
    if m:vals.append(({'yükseklik':'height_cm','genişlik':'width_cm','derinlik':'depth_cm'}[m[1].lower()],float(m[2].replace(',','.'))))
   rows=[];current={}
   for field,value in vals:
    if field in current:current={}
    current[field]=value
    if len(current)==3:
     if current not in rows:rows.append(current)
     current={}
   if rows:p['sizes']=[dict(s,source_kind='official_tr_live_labeled_cells',source_url=q['url'],evidence_file=str(R/'tr-live-product-details-frozen.json'),status='listed',status_note='All labeled variants included; individual availability is only assigned when explicitly observed.')for s in rows];p['sizes_complete']=True
   p['gallery_images']=q.get('gallery_images',[])
  else:p['gallery_images']=[]
  recovery=next((q for q in recovered if q['url']==p['url']),None)
  if recovery:
   p['sku']=recovery['actual_sku'];p['sizes']=[dict(recovery['size'],source_url=recovery['source_url'],source_kind=recovery['source_kind'],evidence_file=str(R/'tr-official-search-recovery.json'),status='listed_in_cached_official_TR_page')];p['cached_official_recovery']=recovery;p['source_anomalies'].append(recovery['live_open_status'])
  clean=[]
  for s in p['sizes']:
   if all(isinstance(s.get(k),(int,float))for k in ['height_cm','width_cm','depth_cm']):clean.append(dict(s,source_url=s.get('source_url',p['url']),source_kind=s.get('source_kind','official_tr_prior_labeled_dimensions'),status=s.get('status','listed')))
  p['unverified_size_strings']=[s for s in p['sizes']if not all(isinstance(s.get(k),(int,float))for k in ['height_cm','width_cm','depth_cm'])];p['sizes']=clean
  p['modeling_status']='ready'if p.get('sku')and clean and(p['images']or p['gallery_images'])else'needs_identity'if not p.get('sku')else'needs_measurement'if not clean else'needs_reference'
  if p['modeling_status']!='ready':pending.append(dict(url=p['url'],category=p['category'],title=p['title'],status=p['modeling_status']))
 dump(R/'tr-live-product-details-frozen.json',saved);dump(R/'resolved-source-inventory.json',a);dump(R/'pending-evidence.json',pending);print('Resolved live',len(saved),'ready',len(a)-len(pending),'pending evidence',len(pending));return a
if __name__=='__main__':resolve()
