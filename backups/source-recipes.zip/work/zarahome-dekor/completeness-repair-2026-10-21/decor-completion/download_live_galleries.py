from pathlib import Path
import sys,json,re,hashlib,urllib.request,concurrent.futures
from PIL import Image
R=Path(__file__).resolve().parent;(R/'detail-masters').mkdir(exist_ok=True);a=json.loads((R/'resolved-source-inventory.json').read_text());category=sys.argv[1]if len(sys.argv)>1 else None;old=json.loads((R/'detail-photo-masters.json').read_text())if(R/'detail-photo-masters.json').exists()else[];known={q['image_url']:q for q in old};todo=[]
for p in a:
 if category and p['category']!=category:continue
 by={}
 for im in p['gallery_images']:
  u=im['url'];base=u.split('?')[0];w=re.search(r'[?&]w=(\d+)',u);width=int(w[1])if w else 0
  if base not in by or width>by[base][0]:by[base]=(width,im)
 for width,im in by.values():
  if im['url']not in known:todo.append((p,im))
def run(q):
 p,im=q;u=im['url'];f=R/'detail-masters'/(hashlib.sha256(u.encode()).hexdigest()[:10]+'-'+u.split('?')[0].split('/')[-1])
 if not f.exists():f.write_bytes(urllib.request.urlopen(urllib.request.Request(u,headers={'User-Agent':'Mozilla/5.0'}),timeout=30).read())
 with Image.open(f)as img:info=dict(pixels=list(img.size),format=img.format)
 return dict(category=p['category'],product_url=p['url'],sku=p['sku'],image_url=u,alt=im['alt'],path=str(f),sha256=hashlib.sha256(f.read_bytes()).hexdigest(),**info)
errors=[]
with concurrent.futures.ThreadPoolExecutor(max_workers=4)as pool:
 for fut in concurrent.futures.as_completed([pool.submit(run,q)for q in todo]):
  try:r=fut.result();known[r['image_url']]=r;print(r['sku'],r['pixels'],flush=True)
  except Exception as e:errors.append(str(e));print(type(e).__name__,str(e),flush=True)
(R/'detail-photo-masters.json').write_text(json.dumps(list(known.values()),ensure_ascii=False,indent=2)+'\n');(R/'detail-download-errors.json').write_text(json.dumps(errors,indent=2)+'\n');print('gallery masters',len(known),'errors',len(errors))
