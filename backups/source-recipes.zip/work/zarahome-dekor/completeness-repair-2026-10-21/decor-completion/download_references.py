from pathlib import Path
import urllib.request,json,hashlib,concurrent.futures,re
from PIL import Image
R=Path(__file__).resolve().parent;(R/'references').mkdir(exist_ok=True)
a=json.loads((R/'source-inventory-frozen.json').read_text());records=[];errors=[]
def run(p):
 if not p['images']:return None
 im=p['images'][0];u=im['url'];element=re.search(r'pelement=(\d+)',p['url']);stem=p['family_path_code']+'-'+(element[1]if element else str(p['card_index']));f=R/'references'/(stem+'-master.jpg')
 if not f.exists():f.write_bytes(urllib.request.urlopen(urllib.request.Request(u,headers={'User-Agent':'Mozilla/5.0'}),timeout=30).read())
 with Image.open(f)as image:info={'format':image.format,'pixel_dimensions':list(image.size)}
 return dict(category=p['category'],title=p['title'],url=p['url'],sku=p.get('sku'),image_code=p['image_code'],source_image_url=u,alt=im['alt'],local_master=str(f),sha256=hashlib.sha256(f.read_bytes()).hexdigest(),**info)
with concurrent.futures.ThreadPoolExecutor(max_workers=4)as pool:
 for fut in concurrent.futures.as_completed([pool.submit(run,p)for p in a]):
  try:
   r=fut.result()
   if r:records.append(r);print(r['image_code'],r['pixel_dimensions'],flush=True)
  except Exception as e:errors.append(dict(type=type(e).__name__,error=str(e)));print(type(e).__name__,str(e),flush=True)
(R/'reference-masters.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n');(R/'reference-download-errors.json').write_text(json.dumps(errors,ensure_ascii=False,indent=2)+'\n');print('complete',len(records),'errors',len(errors))
