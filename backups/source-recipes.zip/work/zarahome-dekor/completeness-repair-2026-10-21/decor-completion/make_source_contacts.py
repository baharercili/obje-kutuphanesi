from pathlib import Path
import json
from PIL import Image,ImageOps,ImageDraw,ImageFont
R=Path(__file__).resolve().parent;a=json.loads((R/'source-inventory-frozen.json').read_text());refs={q['url']:q for q in json.loads((R/'reference-masters.json').read_text())};font=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',16)
for cat in ['Sepetler','Vazolar','Aydınlatma']:
 pp=[p for p in a if p['category']==cat];slug={'Sepetler':'baskets','Vazolar':'vases','Aydınlatma':'lights'}[cat]
 for start in range(0,len(pp),16):
  out=Image.new('RGB',(1600,1800),'#e9e8e3');d=ImageDraw.Draw(out)
  for j,p in enumerate(pp[start:start+16]):
   x=j%4*400;y=j//4*450;ref=refs.get(p['url'])
   if ref:
    im=ImageOps.contain(Image.open(ref['local_master']).convert('RGB'),(390,370));out.paste(im,(x+(400-im.width)//2,y+(370-im.height)//2))
   d.text((x+6,y+374),str(p['card_index'])+' '+p['title'][:34],font=font,fill='#222222');d.text((x+6,y+399),p.get('sku')or'? actual SKU / raw '+str(p['image_code']),font=font,fill='#333333');d.text((x+6,y+421),str([(s.get('height_cm'),s.get('width_cm'),s.get('depth_cm'))for s in p['sizes']])[:52],font=font,fill='#333333')
  file=R/f'{slug}-sources-{start//16+1}.png';out.save(file,optimize=True);print(file.name)
