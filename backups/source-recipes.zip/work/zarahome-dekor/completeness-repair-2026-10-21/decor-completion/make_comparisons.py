from pathlib import Path
import json,hashlib
from PIL import Image,ImageOps,ImageDraw,ImageFont
R=Path(__file__).resolve().parent
font='/System/Library/Fonts/Supplemental/Arial.ttf';text=ImageFont.truetype(font,18);small=ImageFont.truetype(font,15);title=ImageFont.truetype(font,24)
a=json.loads((R/'manifest.json').read_text());a=[e for e in a if e['category']==__import__('sys').argv[1]]if len(__import__('sys').argv)>1 else a;refs={q['url']:q for q in json.loads((R/'reference-masters.json').read_text())}
photos=[]
for i in range(0,len(a),4):
 sheet=Image.new('RGB',(1500,1860),'#f0efeb');draw=ImageDraw.Draw(sheet);draw.text((24,18),'Zara Home · Dekor tamamlaması · Resmî fotoğraf ve ölçülü model',font=title,fill='#21211f')
 for j,e in enumerate(a[i:i+4]):
  y=65+j*445;draw.text((24,y),e['name']+' · '+e['sku'],font=text,fill='black');draw.text((24,y+25),'Resmî ham Y × G × D: '+' × '.join(format(v,'g')for v in e['source_dimensions_hwd_cm'])+' cm · '+('DERİNLİK TEYİDİ BEKLİYOR'if e['estimated_dimensions']else e['variant_status_verbatim']),font=small,fill='#41413c')
  if e.get('reorientation'):draw.text((24,y+44),'Model G × Y × D: '+' × '.join(format(v,'g')for v in e['dimensions_cm'])+' cm · Eksen yorumu kayıtta açıklandı',font=small,fill='#6b4b32')
  if e['sku']in['2817/049/600','2820/049/600']:draw.text((24,y+44),'MODEL: Sap içe katlanmış depolama konumu · Açık sap yüksekliği resmî ölçü değildir',font=small,fill='#6b4b32')
  views=[(refs[e['url']]['local_master'],22,410,'RESMÎ FOTOĞRAF'),(str(Path(e['asset_dir'])/'on-capraz.png'),440,390,'MODEL · ÇAPRAZ'),(str(Path(e['asset_dir'])/'on.png'),840,295,'MODEL · ÖN'),(str(Path(e['asset_dir'])/'ustten.png'),1140,330,'MODEL · ÜST')]
  for name,x,w,label in views:
   im=Image.open(name).convert('RGBA');canvas=Image.new('RGBA',im.size,'#e5e4de');canvas.alpha_composite(im);im=ImageOps.contain(canvas.convert('RGB'),(w,350),Image.Resampling.LANCZOS);sheet.paste(im,(x+(w-im.width)//2,y+59+(350-im.height)//2));draw.text((x,y+415),label,font=small,fill='#454540')
  draw.line((22,y+442,1480,y+442),fill='#c4c3bc',width=1)
 dest=R/f"comparison-{'vases'if a[0]['category']=='Vazolar'else'baskets'if a[0]['category']=='Sepetler'else'lights'}-{i//4+1:02}.png";sheet.save(dest,optimize=True);photos.append(str(dest));print(dest.name,flush=True)
record=[]
for q in refs.values():
 assert hashlib.sha256(Path(q['local_master']).read_bytes()).hexdigest()==q['sha256']
 im=Image.open(q['local_master']);record.append(dict(path=q['local_master'],sha256=q['sha256'],unchanged=True,pixel_dimensions=list(im.size),mode=im.mode,icc_profile_present=bool(im.info.get('icc_profile'))))
(R/('comparison-provenance-'+('vases'if a[0]['category']=='Vazolar'else'baskets'if a[0]['category']=='Sepetler'else'lights')+'.json')).write_text(json.dumps(dict(valid=True,original_masters_unchanged=True,operation='Separate presentation thumbnails derived once from each immutable source master with Lanczos contain; original colors and dimensions untouched. Native render PNGs alpha-composited over neutral presentation canvas.',generated_pixels=False,comparison_outputs=photos,masters=record),ensure_ascii=False,indent=2)+'\n')
