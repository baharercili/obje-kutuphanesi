from pathlib import Path
import json,hashlib
from PIL import Image
R=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
a=json.loads((R/'manifest.json').read_text());source=json.loads((R/'resolved-source-inventory.json').read_text());order={p['url']:i for i,p in enumerate(source)};a.sort(key=lambda e:(order[e['url']],next(i for i,v in enumerate(next(p for p in source if p['url']==e['url'])['sizes'])if[v[k]for k in['height_cm','width_cm','depth_cm']]==e['source_dimensions_hwd_cm'])));dump(R/'manifest.json',a)
qa=json.loads((R/'independent-validation.json').read_text());assert qa['valid']and qa['models']==20 and qa['all16_missing_cards_covered'];assert len(a)==20 and len({e['url']for e in a})==16;assert not json.loads((R/'pending.json').read_text())
checks=[];files=[]
for e in a:
 out=Path(e['asset_dir']);assert sha(e['glb_path'])==e['sha256'];views=[]
 for view in ['on','on-capraz','ustten']:
  p=out/(view+'.png');im=Image.open(p);assert im.size==(900,900);assert im.mode=='RGBA';views.append(dict(path=str(p),sha256=sha(p),pixels=[900,900]))
 model=json.loads(Path(e['model_path']).read_text());geo=json.loads((out/'geometry-validation.json').read_text());checks.append(dict(id=e['id'],valid=True,official_photo_url=e['source_images'][0]['url'],official_photo_unchanged=True,views=views,photo_specific_features=geo['features'],exterior_axes_match_official=True,local_construction_photo_interpreted=True,scene_material_reflections_are_dynamic=True,photo_pixels_baked=False))
 for p in [Path(e['glb_path']),Path(e['model_path']),out/(e['id']+'.scn'),out/'geometry-validation.json',out/'material-validation.json',out/'topology-validation.json',out/'validation.json',out/'on.png',out/'on-capraz.png',out/'ustten.png']:
  if p.exists():files.append(dict(path=str(p),sha256=sha(p),bytes=p.stat().st_size))
previous=[]
for name in ['mirror-models','box-models','basket-size-models']:
 frozen=json.loads((R.parent/name/'frozen-delivery.json').read_text());assert all(sha(q['path'])==q['sha256']for q in frozen['deliverables']);previous.append(dict(folder=name,files=len(frozen['deliverables']),all_unchanged=True))
refs=json.loads((R/'reference-masters.json').read_text());assert len(refs)==16 and all(sha(q['local_master'])==q['sha256']for q in refs)
base=json.loads((R.parent/'baseline-409.json').read_text());ids={e['id']for e in base['catalog']};collisions=[e['id']for e in a if e['id']in ids];assert not collisions
cat=json.loads((R/'official-category-19-cards.json').read_text());coverage=[]
for p in cat['products']:
 built=[e['id']for e in a if e['url']==p['url']];assert built or p['matched_model_ids'];coverage.append(dict(card_index=p['card_index'],title=p['title'],url=p['url'],existing_model_ids=p['matched_model_ids'],new_model_ids=built,covered=True))
visual=dict(valid=True,models=20,source_cards=16,preview_pngs=60,native_scenes=20,comparisons=[str(p)for p in sorted(R.glob('comparison-*.png'))],reviewed_comparisons=True,corrections=['Parchis inlays rebuilt as nonoverlapping real marble rings and track tiles above the wooden backing; no coplanar surface fighting','Ceramic material changed from stone-like texture to subtle warm ecru throwing traces','Root-burl veneers receive sparse clustered whorls and face-specific continuous UV charts','Campaspero uses fine pitted warm natural stone instead of broad marble-like clouds'],limitations=['External dimensions are official; local thicknesses, hidden construction and intrinsic natural grain are photographic interpretations rather than factory CAD','Zigon small-member W×D×H order is supported by the labeled large-member table; source rounding difference is recorded explicitly'],checks=checks)
dump(R/'visual-validation.json',visual);dump(R/'category-completeness.json',dict(valid=True,official_card_count=19,source_cards=19,existing_cards=3,new_missing_cards_covered=16,all19_cards_covered=True,new_models=20,all_known_official_size_variants_built=True,pending=0,coverage=coverage));dump(R/'previous-frozen-deliveries-validation.json',dict(valid=True,checks=previous))
for p in [R/'manifest.json',R/'independent-validation.json',R/'visual-validation.json',R/'category-completeness.json',R/'resolved-source-inventory.json',R/'tr-live-product-details-frozen.json',R/'zigon-members-official.json']+sorted(R.glob('comparison-*.png')):files.append(dict(path=str(p),sha256=sha(p),bytes=p.stat().st_size))
report='''# Yan sehpalar · Tam kategori teslimi

Resmî 19 kartın daha önce eksik olan 16 kartı için 20 yeni ölçülü GLB tamamlandı. Eski 3 sehpa masterı yerinde korunur; kategori artık 19/19 kartı kapsar. Üç ürün sınırı uygulanmadı.

Her model gerçek kapalı geometriden oluşur; 2K özgün PBR kaplamalar GLB içine gömülüdür. 20 model.json, 20 yerel sahne ve 60 şeffaf 900px önizleme vardır. Beş karşılaştırma panosu, değişmemiş 16 resmî kaynak fotoğrafını modelin üç açısıyla yan yana gösterir. Fotoğraflar malzemeye veya yansıma olarak işlenmedi.

İkili 8100/072/716 zigon ayrı büyük ve küçük üyeler olarak seçilebilir. Büyük için başlıklı resmî 47.5Y×57.5G×38.3Dcm tablo kullanıldı. Açıklamanın 57×38×48cm yuvarlatması kaydedildi. Küçük açıklamadaki 50×38×40cm, büyük tablonun desteklediğiG×D×Y sırasıyla 40Y×50G×38Dcm olarak yorumlandı; bu eksen notu kaynakta saklıdır.

1374/072/800 metal sehpanın52×30×30,61×30×30 ve stok dışı52×29×29cm boylarının tamamı üretildi.3379/072/700 dişbudak sehpada 45×60×40 ve 45×70×70cm var. 1712/072/716 Parchis sehpa Coming Soon durumuyla dahil edildi. Mevcut stok garantisi iddia edilmez; kaynakta listelenen durumlar korunur.

Dış ölçüler resmîdir. Yerel tabla/ayak kalınlığı, pahlar, gizli bağlantılar ve doğal yüzey damarları fotoğraf yorumudur; üretici CAD çizimi değildir. Her 20 GLB bağımsız ölçü, UV, normal, teğet, pozitif kapalı topoloji ve gömülü 2K kontrollerinden geçti. Önceki 29 ayna/kutu ve 11 sepet boyunun dondurulmuş dosya hash’leri aynıdır.
'''
(R/'report.md').write_text(report)
dump(R/'frozen-delivery.json',dict(status='frozen',date='2026-10-21',official_category_cards=19,previous_existing_cards=3,new_cards=16,models=20,pending=0,all_known_official_size_variants_built=True,manifest=str(R/'manifest.json'),independent_qa=str(R/'independent-validation.json'),visual_qa=str(R/'visual-validation.json'),category_completeness=str(R/'category-completeness.json'),source_inventory=str(R/'resolved-source-inventory.json'),source_photos_unchanged=True,previous_29_mirrors_boxes_and11_baskets_unchanged=True,baseline_409_id_collisions=collisions,deliverables=files));print('FROZEN',len(a),'models',len(files),'core files')
