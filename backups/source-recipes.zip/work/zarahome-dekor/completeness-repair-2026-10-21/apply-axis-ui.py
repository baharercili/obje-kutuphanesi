from pathlib import Path
p=Path(__file__).resolve().parents[3]/'sites/zarahome-vazo-kutuphanesi-final-378/ui/viewer.js'
s=p.read_text()
anchor="function sizeSourceLabel(model) {\n"
addition="  if(model.size_source_kind==='official_dimensions_photo_oriented_axes')return 'Resmî sayı değerleri · Eksenler fotoğraftan';\n  if(model.size_source_kind==='official_height_width_estimated_depth')return 'Resmî yükseklik/en · Derinlik teyit bekliyor';\n"
if "Resmî sayı değerleri · Eksenler fotoğraftan" not in s:
 assert anchor in s;s=s.replace(anchor,anchor+addition);p.write_text(s)
