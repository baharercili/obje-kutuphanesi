from pathlib import Path
import json,math,sys
import numpy as np
from PIL import Image,ImageDraw,ImageFont
R=Path(__file__).resolve().parent;rows=json.loads((R/'manifest.json').read_text());refs=json.loads((R/'reference-downloads.json').read_text());configs={c['id']:c for c in json.loads((R/'photo-classifications.json').read_text())};(R/'previews').mkdir(exist_ok=True);(R/'comparisons').mkdir(exist_ok=True);S=480;HH=550;texcache={}
def render(e):
 doc=json.loads(Path(e['model_path']).read_text());kind=configs[e['id']]['kind'];flat=e['display_pose']=='flat_on_desk';pitch=math.radians(62 if flat else 49 if kind=='accordion_case' else 19);yaw=math.radians(-27);view=np.array([math.sin(yaw)*math.cos(pitch),math.sin(pitch),math.cos(yaw)*math.cos(pitch)]);right=np.cross([0,1,0],view);right/=np.linalg.norm(right);up=np.cross(view,right);M=np.stack([right,-up,view]);allv=np.concatenate([np.array(m['positions']).reshape(-1,3)for m in doc['meshes']]);proj=allv@M.T;lo=proj.min(0);hi=proj.max(0);scale=min((S-40)/(hi[0]-lo[0]),(HH-35)/(hi[1]-lo[1]));center=(lo+hi)/2;output=np.full((HH,S,3),[242,240,230],np.uint8);zbuf=np.full((HH,S),-1e20,np.float32);light=np.array([-.4,.75,.50]);light/=np.linalg.norm(light)
 for mesh in doc['meshes']:
  vv=np.array(mesh['positions']).reshape(-1,3);nn=np.array(mesh['normals']).reshape(-1,3);uv=np.array(mesh['uvs']).reshape(-1,2);ff=np.array(mesh['indices']).reshape(-1,3);p=vv@M.T;p[:,:2]=(p[:,:2]-center[:2])*scale+[S/2,HH/2];mat=doc['materials'][mesh['material']];file=Path(e['asset_dir'])/mat['baseColorTexture'];key=str(file)
  if key not in texcache:texcache[key]=np.array(Image.open(file).convert('RGB'))
  texture=texcache[key];tn=texture.shape[0];metal=mat.get('metallic',0);rough=.25 if metal else.6
  for f in ff:
   q=p[f];x0=max(0,int(np.floor(q[:,0].min())));x1=min(S-1,int(np.ceil(q[:,0].max())));y0=max(0,int(np.floor(q[:,1].min())));y1=min(HH-1,int(np.ceil(q[:,1].max())))
   if x1<x0 or y1<y0:continue
   a,b,c=q;den=(b[1]-c[1])*(a[0]-c[0])+(c[0]-b[0])*(a[1]-c[1])
   if abs(den)<1e-7:continue
   xx,yy=np.meshgrid(np.arange(x0,x1+1)+.5,np.arange(y0,y1+1)+.5);aa=((b[1]-c[1])*(xx-c[0])+(c[0]-b[0])*(yy-c[1]))/den;bb=((c[1]-a[1])*(xx-c[0])+(a[0]-c[0])*(yy-c[1]))/den;cc=1-aa-bb;depth=aa*a[2]+bb*b[2]+cc*c[2];mask=(aa>=-1e-7)&(bb>=-1e-7)&(cc>=-1e-7)&(depth>zbuf[y0:y1+1,x0:x1+1])
   if not mask.any():continue
   aa=aa[mask];bb=bb[mask];cc=cc[mask];uvs=aa[:,None]*uv[f[0]]+bb[:,None]*uv[f[1]]+cc[:,None]*uv[f[2]];ix=np.floor((uvs[:,0]%1)*(tn-1)).astype(int);iy=np.floor((uvs[:,1]%1)*(tn-1)).astype(int);col=texture[iy,ix].astype(float)/255;normal=aa[:,None]*nn[f[0]]+bb[:,None]*nn[f[1]]+cc[:,None]*nn[f[2]];normal/=np.maximum(1e-8,np.linalg.norm(normal,axis=1,keepdims=True));lam=np.clip(normal@light,0,1);diff=.63+.37*lam;half=light+view;half/=np.linalg.norm(half);spec=np.clip(normal@half,0,1)**(35 if metal else 80);col=np.clip(col*diff[:,None]+spec[:,None]*(.22 if metal else.035),0,1);patch=output[y0:y1+1,x0:x1+1];patch[mask]=np.rint(col*255).astype(np.uint8);zbuf[y0:y1+1,x0:x1+1][mask]=depth[mask]
 return Image.fromarray(output)
font=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',13)
for start in range(0,len(rows),12):
 if len(sys.argv)>1 and str(start//12)not in sys.argv[1:]:continue
 group=rows[start:start+12];cw=640;ch=450;sheet=Image.new('RGB',(cw*3,ch*((len(group)+2)//3)),'white');dr=ImageDraw.Draw(sheet)
 for j,e in enumerate(group):
  idx=e['category_card_indices'][0];sources=[q for q in refs if q['index']==idx and e['image_code']in q['url']];candidates=[q for q in sources if '-p1/'in q['url']and q['pixel_dimensions'][0]>=1024];rec=(sources[1]if idx==8 and len(sources)>1 else max(candidates,key=lambda q:q['pixel_dimensions'][0])if idx in[43,48,49]and candidates else max(sources,key=lambda q:q['pixel_dimensions'][0]));photo=Image.open(rec['local_master']).convert('RGB');photo.thumbnail((305,ch-66));preview=render(e);preview.save(R/'previews'/(e['id']+'.png'));preview.thumbnail((305,ch-66));x=j%3*cw;y=j//3*ch;sheet.paste(photo,(x+(310-photo.width)//2,y+(ch-66-photo.height)//2));sheet.paste(preview,(x+320+(310-preview.width)//2,y+(ch-66-preview.height)//2));dr.text((x+4,y+ch-62),str(idx)+' '+e['sku']+' '+str(e['dimensions_cm']),font=font,fill='black');dr.text((x+4,y+ch-43),configs[e['id']]['kind']+' / '+e['display_pose'],font=font,fill='black');dr.text((x+4,y+ch-24),e['name'][:64],font=font,fill='black')
 sheet.save(R/'comparisons'/f'comparison-{start//12}.png');print('RENDERED',start//12,len(group),flush=True)
