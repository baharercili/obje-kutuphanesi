from pathlib import Path
import urllib.request,json,hashlib,concurrent.futures
from PIL import Image
R=Path(__file__).resolve().parent
R.joinpath('references').mkdir(exist_ok=True)
a=json.loads((R/'source-inventory-identity-corrected.json').read_text())
def run(p):
 im=p['images'][0];u=im['url'];stem=p['family_path_code']+'-'+(p['image_code'] or 'unknown')+('-a7'if p['family_path_code']=='49957073'else'')
 f=R/'references'/str(stem+'-master.jpg')
 if not f.exists():
  b=urllib.request.urlopen(urllib.request.Request(u,headers={'User-Agent':'Mozilla/5.0'}),timeout=30).read();f.write_bytes(b)
 with Image.open(f) as image:info={'format':image.format,'pixel_dimensions':list(image.size)}
 return dict(title=p['title'],url=p['url'],sku=p.get('sku'),image_code=p['image_code'],source_image_url=u,alt=im['alt'],local_master=str(f),sha256=hashlib.sha256(f.read_bytes()).hexdigest(),**info)
records=[]
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
 for fut in concurrent.futures.as_completed([pool.submit(run,p) for p in a]):
  try:r=fut.result();records.append(r);print(r['image_code'],r['pixel_dimensions'],flush=True)
  except Exception as e:print(type(e).__name__,str(e),flush=True)
(R/'reference-masters.json').write_text(json.dumps(records,ensure_ascii=False,indent=2))
