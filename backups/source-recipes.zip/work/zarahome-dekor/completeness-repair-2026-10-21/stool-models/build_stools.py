"""All missing stool cards, true identities and verified HWD; no selection limit."""
from pathlib import Path
import sys,json,math,re,shutil,hashlib
import numpy as np
from PIL import Image
R=Path(__file__).resolve().parent;WORK=R.parents[1]
sys.path.insert(0,str(R.parent/'side-table-models'));import build_side_tables as S
M=S.M;F=S.F;b=S.b;_finalize=S._finalize;flatcap_normals=S.flatcap_normals
from export_catalog import export_assets,read_glb,write_glb
T=math.tau;board=S.board;prof=S.prof;rod=S.rod;move=S.move;loft=S.loft

def dump(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dims(v):return[v[k]/100 for k in['height_cm','width_cm','depth_cm']]
def beam(name,mat,a,c,w=.03,d=.03,r=.002):
 a=np.array(a,float);c=np.array(c,float);length=np.linalg.norm(c-a);q=board(name,mat,w,length,d,y=-length/2,r=r,grain=1);up=(c-a)/length;xx=np.cross(up,[0,0,1]if abs(up[2])<.9 else[1,0,0]);xx/=np.linalg.norm(xx);zz=np.cross(xx,up);centre=(a+c)/2;q['_vertices']=[tuple(centre+xx*x+up*y+zz*z)for x,y,z in q['_vertices']];return q

def dish(name,mat,w,d,h,depth=.014,thick=.033):
 q=prof(name,mat,[(0,h-thick),(w/2-.008,h-thick),(w/2-.002,h-thick+.004),(w/2,h-.005),(w/2-.002,h),(w*.46,h-.001),(w*.35,h-depth*.5),(w*.17,h-depth*.91),(0,h-depth)],192,5);q['_vertices']=[(x,y,z*d/w)for x,y,z in q['_vertices']];q['_uvs']=[(x/w+.5,z/d+.5)if y>h-thick+.008 else uv for(x,y,z),uv in zip(q['_vertices'],q['_uvs'])];return q

def small_wood(p,v):
 h,w,d=dims(v);colour=p['sku'].split('/')[-1];mat={'999':'multistrip','700':'stoolbrown','800':'stoolblack'}[colour];parts=[board('rounded-solid-wood-small-stool-seat-'+colour,mat,w,.020,d,y=h-.020,r=.004)]
 for sx in[-1,1]:
  for sz in[-1,1]:parts.append(beam('four-real-splayed-rectangular-leg-'+str(sx)+str(sz),mat,(sx*w*.39,0,sz*d*.39),(sx*w*.32,h-.018,sz*d*.28),.026,.026,.0017))
 for sx in[-1,1]:parts.append(board('low-short-side-joining-rail-'+str(sx),mat,.018,.018,d*.65,x=sx*w*.36,y=h*.33,r=.001,grain=2))
 return parts,['Small rectangular solid-wood top with soft20mm rounded edge, four real splayed square legs and two low side rails','Actual corrected colorSKU '+p['sku']+'; same official stool family, separate source photograph and material','Multicolor card uses laminated natural strip wood rather than arbitrary colored paint'if colour=='999'else'Brown wood or black finish retains intrinsic fine fibres; no swatch image used as product reference']

def high_steel(p,v):
 h,w,d=dims(v);mat='satinsteel';parts=[];radius=.045;th=.0023;a=w/2-radius
 angles=np.r_[np.linspace(math.pi,math.pi/2,33),np.linspace(math.pi/2,0,33)]
 outer=[(-a+radius*math.cos(t),h-radius+radius*math.sin(t))for t in np.linspace(math.pi,math.pi/2,33)]
 outer +=[(xx,h)for xx in np.linspace(-a,a,65)[1:-1]]
 outer +=[(a+radius*math.cos(t),h-radius+radius*math.sin(t))for t in np.linspace(math.pi/2,0,33)]
 inner=[(-a+(radius-th)*math.cos(t),h-radius+(radius-th)*math.sin(t))for t in np.linspace(math.pi,math.pi/2,33)]
 inner +=[(xx,h-th)for xx in np.linspace(-a,a,65)[1:-1]]
 inner +=[(a+(radius-th)*math.cos(t),h-radius+(radius-th)*math.sin(t))for t in np.linspace(math.pi/2,0,33)]
 count=len(outer);verts=[];uv=[]
 for profile in[outer,inner]:
  for z in[-d/2,d/2]:
   for j,(x,y)in enumerate(profile):verts.append((x,y,z));uv.append((j/(count-1),z/d+.5))
 faces=[]
 def quad(a,c,e,f):faces.extend([(a,c,e),(a,e,f)])
 for j in range(count-1):
  of=j;ob=count+j;inf=2*count+j;ib=3*count+j
  quad(of,of+1,ob+1,ob);quad(inf,ib,ib+1,inf+1);quad(of,inf,inf+1,of+1);quad(ob,ob+1,ib+1,ib)
 quad(0,count,3*count,2*count);j=count-1;quad(j,2*count+j,3*count+j,count+j)
 parts.append(b.solid('real-continuous-waterfall-bent-stainless-sheet',mat,verts,faces,uv));xx=w*.47;zz=d*.43
 for sx in[-1,1]:
  for sz in[-1,1]:
   pts=F.smooth_curve([(sx*xx,.004,sz*zz),(sx*xx,h-.052,sz*zz),(sx*(xx-.005),h-.033,sz*zz),(sx*(xx-.020),h-.019,sz*zz)],10);parts.append(rod('thin-round-stainless-support-leg-'+str(sx)+str(sz),mat,pts,.0056,28));parts.append(b.cylinder('tiny-black-bearing-pad-'+str(sx)+str(sz),'blackrubber',.0061,0,.002,offset=(sx*xx,0,sz*zz),n=32))
 for sx in[-1,1]:parts.append(rod('side-footrest-rail-'+str(sx),mat,[(sx*xx,h*.29,-zz),(sx*xx,h*.29,zz)],.0046,24))
 for sz in[-1,1]:parts.append(rod('front-rear-footrest-rail-'+str(sz),mat,[(-xx,h*.29,sz*zz),(xx,h*.29,sz*zz)],.0046,24))
 return parts,['Continuous2.3mm bent stainless sheet with genuinely descending waterfall ends and a thin underside','Four slender round support tubes, four connected footrest rails and tiny floor pads','No solid upholstered block substituted for the pressed metal seat']

def leather_low(p,v):
 h,w,d=dims(v);parts=[prof('padded-round-leather-seat-with-soft-crowned-face','leather',[(0,h-.061),(w/2-.014,h-.061),(w/2-.002,h-.049),(w/2,h-.025),(w/2-.006,h-.010),(w/2-.031,h-.002),(0,h)],192),b.lathe('fine-continuous-leather-edge-piping','leatheredge',[(w/2-.009,h-.051),(w/2-.002,h-.051),(w/2-.001,h-.047),(w/2-.004,h-.045)],192,True),b.cylinder('polished-single-central-seat-support','polished',.014,.045,h-.058,n=96)]
 for k,a in enumerate([0,math.pi/2,math.pi,math.pi*1.5]):
  q=board('tapered-polished-flat-base-spoke-'+str(k),'polished',w*.47,.025,.017,x=w*.235,y=0,r=.001)
  vv=[]
  for x,y,z in q['_vertices']:
   t=x/(w*.47);yy=y+.018*(1-t)**2;xx=x*math.cos(a)-z*math.sin(a);zz=x*math.sin(a)+z*math.cos(a);vv.append((xx,yy,zz))
  q['_vertices']=vv;parts.append(q);parts.append(b.cylinder('small-invisible-floor-pad-'+str(k),'blackrubber',.005,0,.002,offset=(w*.45*math.cos(a),0,w*.45*math.sin(a)),n=24))
 return parts,['Crowned dark leather cushion with a real fine rounded piping ring and separate chrome support column','Four flattened tapered metal spokes curve smoothly into the central hub; discrete floor pads','Intrinsic leather pore relief and genuine polished metal PBR, with no baked reflections']

def leather_high(p,v):
 h,w,d=dims(v);seat=h*.665;parts=[]
 contour=M.G.rounded(w*.82,d*.72,.065,192);bb=M.G.Builder();bb.slab('ergonomic-rounded-leather-saddle-seat','leather',contour,seat-.056,seat,.008)
 for g in bb.groups.values():
  vv=[(x,yy+.012*(x/(w*.41))**2+.009*(-zz/(d*.36)),zz+d*.025)for x,zz,yy in g['_vertices']];parts.append(b.solid(g['name'],g['material'],vv,g['_faces']))
 shape=M.G.rounded(w*.80,.190,.055,192,cy=h-.095);bb=M.G.Builder();bb.slab('curved-rounded-padded-leather-upper-backrest','leather',shape,-d*.43-.0205,-d*.43+.0205,.006)
 for g in bb.groups.values():
  vv=[(x,y,z-.010*(x/(w*.40))**2+.050*(1-(y-(h-.190))/.190))for x,y,z in g['_vertices']];parts.append(b.solid(g['name'],g['material'],vv,g['_faces']))
 for sx in[-1,1]:
  x=sx*w*.43;pts=[(x,seat-.047,d*.29),(sx*w*.46,.045,d*.45),(sx*w*.45,.010,d*.43),(sx*w*.42,.006,-d*.36),(sx*w*.41,.025,-d*.42),(sx*w*.37,seat-.055,-d*.33),(sx*w*.35,h-.025,-d*.46)];parts.append(rod('continuous-polished-sled-and-rising-back-support-'+str(sx),'polished',F.smooth_curve(pts,12),.0062,28))
  parts.append(rod('side-diagonal-footrest-brace-'+str(sx),'polished',[(sx*w*.445,h*.28,d*.42),(sx*w*.41,h*.46,d*.34)],.0047,24))
 # Connected under-seat cradle physically joins both sled ends to the leather cushion.
 for sx in[-1,1]:
  parts.append(rod('under-seat-side-bearing-cradle-'+str(sx),'polished',[(sx*w*.37,seat-.047,-d*.33),(sx*w*.37,seat-.047,d*.29)],.0058,28));parts.append(rod('front-sled-to-seat-cradle-joining-lug-'+str(sx),'polished',[(sx*w*.43,seat-.047,d*.29),(sx*w*.37,seat-.047,d*.29)],.0058,28))
 for sz in[-1,1]:parts.append(rod('under-seat-width-bearing-cradle-'+str(sz),'polished',[(-w*.37,seat-.047,sz*d*.29),(w*.37,seat-.047,sz*d*.29)],.0058,28))
 parts.append(rod('connected-front-footrest-crossbar','polished',[(-w*.445,h*.28,d*.42),(w*.445,h*.28,d*.42)],.0050,28))
 for sx in[-1,1]:
  for yy in[h-.15,h-.04]:
   x=sx*w*.35;t=(yy-(seat-.055))/((h-.025)-(seat-.055));postz=-d*.33+t*(-d*.46+d*.33);panez=-d*.43-.0205-.010*(x/(w*.40))**2+.050*(1-(yy-(h-.190))/.190);parts.append(rod('real-rear-backrest-connecting-lug-'+str(sx)+str(yy),'polished',[(x,yy,postz),(x,yy,panez)],.0032,20))
 for yy in[h-.175,h-.04]:parts.append(rod('rear-backrest-bearing-cross-rail-'+str(yy),'polished',[(-w*.35,yy,-d*.40),(w*.35,yy,-d*.40)],.0048,24))
 return parts,['Genuinely dished upholstered leather seat and a separate curved padded backrest','Two continuously bent stainless sled frames rise to support the back; real front footrest and diagonal side braces','Source97cm is total backrest height; seat height and local cushion/frame thickness are interpreted from the inspected photograph']

def ash_dished(p,v):
 h,w,d=dims(v);parts=[dish('sculpted-ash-concave-rounded-tractor-seat','lightash',w,d,h,.018,.034)];rbot=.0115;rtop=.018
 shaped=[]
 for x,y,z in parts[0]['_vertices']:
  xn=x/(w/2);zn=z/(d/2);rho=math.hypot(xn,zn);angle=math.atan2(zn,xn);cc=math.cos(angle);ss=math.sin(angle);shaped.append((rho*w/2*math.copysign(abs(cc)**(2/2.7),cc),y,rho*d/2*math.copysign(abs(ss)**(2/2.7),ss)))
 parts[0]['_vertices']=shaped
 for sx in[-1,1]:
  for sz in[-1,1]:
   q=prof('splayed-tapering-round-ash-leg-'+str(sx)+str(sz),'lightash',[(0,0),(rbot,0),(rbot+.001,.004),(rtop,h-.035),(0,h-.034)],96,3);q['_vertices']=[(x+sx*(w*.405-(w*.405-w*.31)*y/(h-.034)),y,z+sz*(d*.405-(d*.405-d*.30)*y/(h-.034)))for x,y,z in q['_vertices']];parts.append(q)
 for sz in[-1,1]:parts.append(rod('round-low-horizontal-ash-stretcher-'+str(sz),'lightash',[(-w*.37,h*.30,sz*d*.37),(w*.37,h*.30,sz*d*.37)],.0072,24))
 for sx in[-1,1]:parts.append(rod('round-side-ash-footrest-stretcher-'+str(sx),'lightash',[(sx*w*.37,h*.34,-d*.37),(sx*w*.37,h*.34,d*.37)],.0072,24))
 return parts,['Actual sculpted ash seat with18mm central concavity, softly rolled outer edge and oval outline','Four splayed tapered turned legs and real round footrest/stretchers','Both official49cm and72cm heights are individually rebuilt; leg and rail thickness stays physical rather than uniformly scaling the whole stool']

def elm_rect(p,v):
 h,w,d=dims(v);parts=[board('rustic-elm-solid-rectangular-seat','rusticelm',w,.027,d,y=h-.027,r=.0018)]
 for sx in[-1,1]:
  for sz in[-1,1]:parts.append(beam('four-splayed-square-elm-leg-'+str(sx)+str(sz),'rusticelm',(sx*w*.42,0,sz*d*.40),(sx*w*.32,h-.025,sz*d*.28),.031,.030,.0015))
 for sx in[-1,1]:parts.append(beam('short-side-elm-stretcher-'+str(sx),'rusticelm',(sx*w*.37,h*.27,-d*.36),(sx*w*.37,h*.27,d*.36),.018,.020,.001))
 for sz in[-1,1]:parts.append(beam('long-low-elm-cross-stretcher-'+str(sz),'rusticelm',(-w*.37,h*.19,sz*d*.37),(w*.37,h*.19,sz*d*.37),.022,.022,.001))
 return parts,['Rustic rectangular elm top with a real27mm edge and sanded narrow arrises','Four distinctly splayed square legs, lower long crossbars and higher short side rails','Official46H×40W×24Dcm axes retained; wood grain follows each physical board']

def linen_foot(p,v):
 h,w,d=dims(v);bent=p['family_path_code']=='44142073';mat='lightash'if bent else'darkwood';parts=[];cushion_h=.12 if bent else .115;cy=h-cushion_h
 parts.append(board('soft-rounded-linen-upholstered-cushion','linen',w-.014,cushion_h,d-.014,y=cy,r=.035))
 for sx in[-1,1]:
  for sz in[-1,1]:parts.append(board('slim-solid-wood-leg-'+str(sx)+str(sz),mat,.038 if bent else .027,cy+.005,.038 if bent else .027,x=sx*(w/2-.032),z=sz*(d/2-.032),r=.009 if bent else .003,grain=1))
 for sz in[-1,1]:parts.append(board('under-cushion-long-frame-rail-'+str(sz),mat,w-.035,.033,.025,y=cy-.022,z=sz*(d/2-.027),r=.008 if bent else .003))
 for sx in[-1,1]:parts.append(board('under-cushion-side-frame-rail-'+str(sx),mat,.025,.033,d-.050,x=sx*(w/2-.027),y=cy-.022,r=.008 if bent else .003,grain=2))
 # Real continuous piping follows the cushion's rounded lower perimeter.
 contour=M.G.rounded(w-.024,d-.024,.032,192);points=[(x,cy+.010,z)for x,z in contour];parts.append(b.tube('continuous-linen-cushion-seam-piping','linen',points,.0012,.0012,8,True,guide=[0,1,0]))
 return parts,['Separate softly rounded linen cushion with intrinsic woven warp/weft and real perimeter piping','Warm bent-looking ash frame with broad soft corner returns'if bent else'Four slender dark wooden legs and an independent closed rectangular supporting frame','Source accessory chair and surrounding room excluded; only the separately sold footrest is modeled']

def round_tripod(p,v):
 h,w,d=dims(v);parts=[dish('rounded-thick-rustic-wood-tripod-seat','rusticelm',w,d,h,.004,.027)];ends=[]
 for k,a in enumerate([math.pi/6,math.pi*5/6,math.pi*1.5]):
  foot=np.array([w*.41*math.cos(a),0,d*.41*math.sin(a)]);top=np.array([w*.28*math.cos(a),h-.022,d*.28*math.sin(a)]);parts.append(beam('three-wedge-splayed-solid-wood-leg-'+str(k),'rusticelm',foot,top,.026,.031,.0015));t=.28;ends.append(foot+(top-foot)*t)
 for k in range(3):parts.append(beam('three-triangular-base-stretchers-'+str(k),'rusticelm',ends[k],ends[(k+1)%3],.014,.017,.001))
 return parts,['30cm round wooden seat, real softened edge and three wedge-section splayed legs','Three independent under-seat stretchers form a genuine triangular brace','Large intrinsic longitudinal grain and shallow seat tool marks, without projected source photograph']

def rush_high(p,v):
 h,w,d=dims(v);seat=h*.66;parts=[];x=w*.44;zf=d*.44;zb=-d*.43
 for sx in[-1,1]:
  parts.append(beam('continuous-tall-back-ash-post-'+str(sx),'lightash',(sx*x,0,zb),(sx*x*.92,h,zb-.007),.024,.026,.004))
  parts.append(beam('short-front-ash-upright-'+str(sx),'lightash',(sx*x,0,zf),(sx*x,seat+.010,zf),.024,.026,.004))
 for sz in[-1,1]:parts.append(board('wood-bearing-seat-front-rear-rail-'+str(sz),'lightash',w*.87,.027,.023,y=seat-.025,z=sz*d*.425,r=.003))
 for sx in[-1,1]:parts.append(board('wood-bearing-seat-side-rail-'+str(sx),'lightash',.022,.027,d*.87,x=sx*x,y=seat-.025,r=.003,grain=2))
 for sz in[-1,1]:parts.append(rod('low-turned-front-rear-ash-footrail-'+str(sz),'lightash',[(-x,h*.19,sz*d*.43),(x,h*.19,sz*d*.43)],.008,24))
 for sx in[-1,1]:parts.append(rod('higher-side-ash-footrail-'+str(sx),'lightash',[(sx*x,h*.36,zb),(sx*x,h*.36,zf)],.008,24))
 # Envelope-woven rush: independent closed coils form the four diagonal corner fields.
 sw=w*.87;sd=d*.87;pitch=.00275;count=int(min(sw,sd)/2/pitch)
 for i in range(count):
  ww=sw-2*i*pitch;dd=sd-2*i*pitch;rr=min(.005,ww*.22,dd*.22);pts=M.G.rounded(ww,dd,rr,96);yy=seat-.006+.003*(1-i/max(1,count));path=[(xx,yy,zz)for xx,zz in pts];parts.append(b.tube('real-envelope-rush-seat-coil-'+str(i),'rush',path,.00135,.00135,8,True,guide=[0,1,0]))
 # Separate rush wraps continue physically around all four thick seat edges.
 # These cover the wooden rails with the same vertical binding seen in the photograph.
 for sz in[-1,1]:
  for k,xx in enumerate(np.arange(-sw/2+.003,sw/2-.003,.0036)):
   pts=[(xx,seat-.020+math.sin(a)*.018,sz*sd/2+math.cos(a)*.011)for a in np.linspace(0,T,24,endpoint=False)];parts.append(b.tube('front-rear-seat-edge-rush-binding-'+str(sz)+'-'+str(k),'rush',pts,.00135,.00135,8,True,guide=[1,0,0]))
 for sx in[-1,1]:
  for k,zz in enumerate(np.arange(-sd/2+.003,sd/2-.003,.0036)):
   pts=[(sx*sw/2+math.cos(a)*.011,seat-.020+math.sin(a)*.018,zz)for a in np.linspace(0,T,24,endpoint=False)];parts.append(b.tube('side-seat-edge-rush-binding-'+str(sx)+'-'+str(k),'rush',pts,.00135,.00135,8,True,guide=[0,0,1]))
 # Backrest is a band of separate vertical wraps with true front and rear returns.
 bw=w*.81;by=h-.040;bh=.073
 parts.append(board('thin-wood-core-inside-woven-back-band','lightash',bw,.060,.013,y=by-bh+.006,z=zb-.008,r=.003))
 for k,xx in enumerate(np.arange(-bw/2,bw/2,.0026)):
  pts=[]
  for a in np.linspace(0,T,24,endpoint=False):pts.append((xx,by-bh/2+math.sin(a)*bh/2,zb-.008+math.cos(a)*.010))
  parts.append(b.tube('individual-rush-backrest-wrap-'+str(k),'rush',pts,.00125,.00125,8,True,guide=[1,0,0]))
 return parts,['Four slim ash uprights, genuine tall rear posts and independent round front/side footrails','Envelope-woven rush seat is made of individually closed physical coils, with diagonal corner rhythm and open spaces rather than a flat woven picture','The upper back band contains separate physical vertical fibre wraps around a concealed narrow wooden core','Official91cm total back height retained; local seat/footrail placement follows photograph proportions']

def steps(p,v):
 h,w,d=dims(v);parts=[];xx=w*.44
 for j,yy in enumerate([h/3,h*2/3,h]):
  z=d*.32-j*d*.32;parts.append(board('real-oak-stair-tread-'+str(j+1),'stepoak',w*.92,.020,d*.325,y=yy-.020,z=z,r=.003))
  for sx in[-1,1]:parts.append(board('cream-metal-under-tread-bearing-bracket-'+str(j)+str(sx),'creammetal',.012,.024,d*.31,x=sx*xx,y=yy-.034,z=z,r=.001))
 for sx in[-1,1]:
  parts.append(rod('splayed-front-rising-metal-stringer-'+str(sx),'creammetal',[(sx*xx,0,d*.46),(sx*xx,h-.023,-d*.32)],.0075,28));parts.append(rod('rear-metal-supporting-leg-'+str(sx),'creammetal',[(sx*xx,0,-d*.46),(sx*xx,h-.023,-d*.32)],.0075,28))
  parts.append(rod('side-folding-metal-restraint-crossbar-'+str(sx),'creammetal',[(sx*xx,h*.31,d*.20),(sx*xx,h*.31,-d*.41)],.004,20))
 for sz in[-1,1]:parts.append(rod('lower-floor-width-stretcher-'+str(sz),'creammetal',[(-xx,.045,sz*d*.44),(xx,.045,sz*d*.44)],.004,24))
 return parts,['Three independent20mm oak treads at ascending heights in a real61cm deep stair footprint','Cream iron side stringers, separate rear supports, physical under-tread brackets and low bracing','True three-step configuration; not a single stool with painted step lines']

def hammered(p,v):
 h,w,d=dims(v);mini=p['family_path_code']=='43562073';parts=[];th=.024 if mini else .030
 q=board('hand-hewn-concave-dark-wood-seat','wornwood',w,th,d,y=h-th-.010,r=.005)
 q['_vertices']=[(x,y+.010*(z/(d/2))**2+.00045*math.sin(x*77+z*23)*math.sin(z*51),z)for x,y,z in q['_vertices']];parts.append(q)
 for sx in[-1,1]:
  for sz in[-1,1]:
   if mini:
    leg=prof('mini-splayed-rounded-dark-wood-leg-'+str(sx)+str(sz),'wornwood',[(0,0),(.012,0),(.014,h-th+.004),(0,h-th+.006)],96,3);leg['_vertices']=[(x+sx*(w*.39-.018*y/(h-th)),y,z+sz*(d*.39-.019*y/(h-th)))for x,y,z in leg['_vertices']];parts.append(leg)
   else:parts.append(beam('tall-hand-hewn-tapered-leg-'+str(sx)+str(sz),'wornwood',(sx*w*.40,0,sz*d*.40),(sx*w*.32,h-th+.004,sz*d*.31),.025,.029,.004))
 for sx in[-1,1]:parts.append(beam('real-short-side-dark-stretcher-'+str(sx),'wornwood',(sx*w*.37,h*.32,-d*.37),(sx*w*.37,h*.32,d*.37),.015,.017,.002))
 for sz in[-1,1]:parts.append(beam('real-long-dark-stretcher-'+str(sz),'wornwood',(-w*.37,h*.25,sz*d*.36),(w*.37,h*.25,sz*d*.36),.016,.017,.002))
 return parts,['Genuine shallow saddle bend in the seat surface and softly hand-hewn edges with minute geometric tool variation','Mini model has rounded turned legs; taller model has thicker flattened tapered legs, each with real lower stretchers','Intrinsic dark wood wear/scuffs stay in the material and follow the long seat direction; no reflection or photograph texture']

def swivel(p,v):
 h,w,d=dims(v);parts=[dish('solid-round-adjustable-wood-seat','stepoak',w,d,h,.003,.027)];fixed=.50
 for sx in[-1,1]:
  for sz in[-1,1]:
   q=board('four-splayed-lacquered-metal-blade-leg-'+str(sx)+str(sz),'creammetal',.013,fixed-.035,.014,y=0,r=.001,grain=1);q['_vertices']=[(x+sx*(w*.44-(w*.44-w*.22)*y/(fixed-.035)),y,z+sz*(d*.44-(d*.44-d*.22)*y/(fixed-.035)))for x,y,z in q['_vertices']];parts.append(q)
 for sx in[-1,1]:
  for sz in[-1,1]:parts.append(beam('fixed-four-way-upper-frame-to-sleeve-bridge-'+str(sx)+str(sz),'creammetal',(sx*w*.22,fixed-.035,sz*d*.22),(0,fixed-.035,0),.015,.014,.001))
 for sz in[-1,1]:parts.append(board('cream-footrest-front-rear-'+str(sz),'creammetal',w*.74,.012,.013,y=.215,z=sz*d*.36,r=.001))
 for sx in[-1,1]:parts.append(board('cream-footrest-side-'+str(sx),'creammetal',.013,.012,d*.74,x=sx*w*.36,y=.215,r=.001,grain=2))
 shaft_bottom=.235+(h-.60);parts.append(b.cylinder('cream-bearing-adjustment-sleeve','creammetal',.018,.300,fixed,n=80));parts.append(b.cylinder('actual-black-threaded-spindle-core','threadsteel',.0080,shaft_bottom,h-.027,n=80))
 pitch=.0040;turns=(h-.029-shaft_bottom)/pitch;pts=[(.0089*math.cos(t),shaft_bottom+t/T*pitch,.0089*math.sin(t))for t in np.linspace(0,T*turns,int(turns*18)+1)];parts.append(rod('real-continuous-helical-adjustment-thread','threadsteel',pts,.0011,8))
 for k,a in enumerate([0,math.pi/2,math.pi,math.pi*1.5]):parts.append(beam('four-under-seat-bearing-arms-'+str(k),'creammetal',(0,h-.034,0),(.10*math.cos(a),h-.034,.10*math.sin(a)),.014,.013,.001))
 return parts,['Round solid wooden seat, four genuine splayed lacquered blade legs and a square connected footrest','Separate sleeve and an actual continuous helical black threaded spindle, including the visible shaft below the sleeve','Official adjustable range60–76cm is represented by two poses of this one product; fixed frame and footrest keep their physical dimensions between poses']

DISPATCH={'49957073':small_wood,'47396073':high_steel,'47390073':leather_low,'47395073':leather_high,'42365073':ash_dished,'42302073':elm_rect,'44182073':linen_foot,'44142073':linen_foot,'47329073':round_tripod,'43364073':rush_high,'47247077':steps,'43564073':hammered,'43562073':hammered,'44210073':swivel}

F.MATERIALS.update({'lightash':([153,115,65],.51,0,'wood'),'rusticelm':([162,127,81],.58,0,'wood'),'stoolbrown':([104,64,36],.43,0,'wood'),'stoolblack':([22,23,21],.38,0,'wood'),'multistrip':([179,132,74],.49,0,'wood'),'wornwood':([35,27,22],.58,0,'wood'),'stepoak':([177,137,78],.51,0,'wood'),'creammetal':([221,215,187],.38,0,'enamel'),'threadsteel':([19,21,20],.42,1,'metal')})

def make_bank(keys):
 out=R/'material-bank';out.mkdir(exist_ok=True)
 if(out/'materials.json').exists()and all((out/(k+'-albedo-2k.png')).exists()for k in keys):return out,json.loads((out/'materials.json').read_text())
 mats={};side=R.parent/'side-table-models/material-bank';side_defs=json.loads((side/'materials.json').read_text())
 for k in keys&set(side_defs):
  mats[k]=dict(side_defs[k])
  for f in ['baseColorTexture','normalTexture','metallicRoughnessTexture']:shutil.copyfile(side/mats[k][f],out/mats[k][f])
 remaining=keys-set(mats)-{'linen','leather','leatheredge','rush'};mats.update(F.textures(out,sorted(remaining)))
 # Immutable natural linen from the completed jewellery-box fabric is a material asset, not an object/photo.
 if'linen'in keys:
  src=R.parent/'box-models/material-bank';defs=json.loads((src/'materials.json').read_text());mats['linen']=dict(defs['linen'])
  for f in ['baseColorTexture','normalTexture','metallicRoughnessTexture']:shutil.copyfile(src/mats['linen'][f],out/mats['linen'][f])
  mats['linen']['normalScale']=.20
 n=2048;u=np.broadcast_to(np.arange(n,dtype=np.float32)[None,:]/n,(n,n));v=u.T
 for key in keys&{'leather','leatheredge','rush'}:
  rng=np.random.default_rng(sum(key.encode()));cloud=F.field(rng,19,n);fine=F.field(rng,710,n);pores=F.field(rng,350,n)
  if key.startswith('leather'):
   colour=np.array([42,30,27])+cloud[:,:,None]*1.3+fine[:,:,None]*.45;height=np.abs(pores)*.07+fine*.025;rough=.40+cloud*.012+pores*.01
  else:
   fibril=np.sin(T*(u*247+.040*F.field(rng,17,n)));colour=np.array([164,126,71])+cloud[:,:,None]*4+fibril[:,:,None]*3+fine[:,:,None]*.5;height=fibril*.08+pores*.02;rough=.72+cloud*.015
  dx=np.gradient(height,axis=1);dy=np.gradient(height,axis=0);nn=np.stack([-dx,-dy,np.ones_like(dx)],axis=2);nn/=np.linalg.norm(nn,axis=2,keepdims=True);orm=np.empty((n,n,3),np.uint8);orm[:,:,0]=255;orm[:,:,1]=np.clip(rough*255,0,255);orm[:,:,2]=0
  for kind,pix in [('albedo',np.clip(colour,0,255).astype(np.uint8)),('normal',np.rint((nn+1)*127.5).astype(np.uint8)),('orm',orm)]:Image.fromarray(pix,'RGB').save(out/(key+'-'+kind+'-2k.png'),optimize=True)
  mats[key]=dict(baseColorFactor=[1,1,1,1],baseColorTexture=key+'-albedo-2k.png',normalTexture=key+'-normal-2k.png',metallicRoughnessTexture=key+'-orm-2k.png',metallic=1,roughness=1,normalScale=.20,alphaMode='OPAQUE',doubleSided=False,extras=dict(native_resolution=2048,intrinsic_material=True,photo_pixels_baked=False,baked_reflections=False))
 if'multistrip'in mats:
  m=mats['multistrip'];al=np.array(Image.open(out/m['baseColorTexture'])).astype(float);idx=np.floor(u*9).astype(int)%9;shades=np.array([-10,16,-3,-23,11,-9,20,-5,4])[idx];al+=shades[:,:,None]*np.array([1,.78,.48]);Image.fromarray(np.clip(al,0,255).astype(np.uint8)).save(out/m['baseColorTexture'],optimize=True)
 if'wornwood'in mats:
  m=mats['wornwood'];al=np.array(Image.open(out/m['baseColorTexture'])).astype(float);rng=np.random.default_rng(3564);wear=np.clip(F.field(rng,100,n)-.9,0,1.8)*np.maximum(0,np.sin(T*u*81))**12;al+=wear[:,:,None]*np.array([27,22,15]);Image.fromarray(np.clip(al,0,255).astype(np.uint8)).save(out/m['baseColorTexture'],optimize=True)
 dump(out/'materials.json',mats);return out,mats

def resolve():
 data=json.loads((R/'source-inventory-identity-corrected.json').read_text());extra=json.loads((R/'tr-live-product-details-frozen.json').read_text());by={q['url']:q for q in extra};bindings=[]
 fix={'42365073':('2365/073/700',[(49,40,37),(72,40,37)]),'42302073':('2302/073/052',[(46,40,24)]),'44182073':('4182/073/731',[(35,53,42)]),'47329073':('7329/073/052',[(46,30,30)]),'43564073':('3564/073/716',[(43,27,37.5)]),'43562073':('3562/073/716',[(25,21,31.5)]),'44210073':('4210/073/733',[(60,30,30),(76,30,30)])}
 for p in data:
  p['official_live_detail']=by.get(p['url']);p['original_source_inventory_pointer']='/categories/2/products/'+str(p['card_index']-1);p['source_anomalies']=[]
  if p['family_path_code']=='48390073':
   e=next(e for e in json.loads((R.parent/'side-table-models/manifest.json').read_text())if e['sku']=='8390/073/808');p['existing_model_binding']=e['id'];bindings.append(dict(card_index=p['card_index'],url=p['url'],sku=e['sku'],model_id=e['id'],model_path=e['model_path'],glb_path=e['glb_path'],sha256=e['sha256'],category='Tabureler',additional_categories=['Tabureler','Yan sehpalar'],reason='Identical official productSKU, color, URLpelement and46×30×30cm dimensions; same frozen master is reused across categories without a duplicate GLB.'))
  if p['family_path_code']in fix:
   p['sku'],triples=fix[p['family_path_code']];p['sizes']=[dict(height_cm=h,width_cm=w,depth_cm=d,label=f'{h:g} × {w:g} × {d:g} cm (Y × G × D)',source_url=p['url'],source_kind='official_tr_live_dom',status='listed')for h,w,d in triples];p['detail_evidence_files']=[str(R/'tr-live-product-details-frozen.json')]
   if p['family_path_code']=='44210073':
    for v in p['sizes']:v['pose_kind']='minimum_adjustment'if v['height_cm']==60 else'maximum_adjustment';v['height_range_cm']=[60,76];v['label']=('En düşük'if v['height_cm']==60 else'En yüksek')+' oturak konumu · '+v['label'];v['source_kind']='official_tr_adjustable_range_endpoint'
  else:p['sizes']=[dict(height_cm=q['dimensions_cm']['height'],width_cm=q['dimensions_cm']['width'],depth_cm=q['dimensions_cm']['depth'],label=q['label'],source_url=q['source_url'],source_kind=q['source_kind'],status='listed')for q in p.get('sizes',[])if q.get('dimensions_cm')]
  if p['family_path_code']=='49957073':
   suffix=p['sku'].split('/')[-1];p['original_title']=p['title'];p['title']+=' · '+{'999':'ÇOK RENKLİ','700':'KAHVERENGİ','800':'SİYAH'}[suffix];p['source_anomalies']=['Original inventory incorrectly assigned9957/073/800 and a32px black swatch to all three cards. Correct colorSKU and actual product photo are proven by the individualpelement Turkish live page.'];p['detail_evidence_files']=[str(R/'tr-live-product-details-frozen.json')]
 evidence=R/'source-evidence';evidence.mkdir(exist_ok=True)
 for p in data:
  frozen=[]
  for name in p.get('detail_evidence_files',[]):
   src=Path(name);src=src if src.is_absolute()else WORK.parents[1]/src
   if src.exists():dest=evidence/(src.parent.name+'-'+src.name);shutil.copyfile(src,dest)if src.resolve()!=dest.resolve()else None;frozen.append(str(dest))
  p['original_detail_evidence_files']=p.get('detail_evidence_files',[]);p['detail_evidence_files']=frozen
 dump(R/'existing-model-bindings.json',bindings);dump(R/'resolved-source-inventory.json',data);return data

def main():
 data=resolve();selected=set(sys.argv[1:]);prepared=[];keys=set();pending=[]
 for p in data:
  if p.get('existing_model_binding'):continue
  if selected and p['family_path_code']not in selected:continue
  if not p.get('sku')or not p.get('sizes'):pending.append(dict(url=p['url'],status='needs_identity'if not p.get('sku')else'needs_measurement'));continue
  for v in p['sizes']:
   parts,features=DISPATCH[p['family_path_code']](p,v);prepared.append((p,v,parts,features));keys.update(q['material']for q in parts)
  if p['family_path_code']=='48100072'and not p.get('bundle_members'):pending.append(dict(url=p['url'],sku=p['sku'],status='needs_measurement',reason='Official largest47.5×57.5×38.3cm exterior is modeled; second nesting member requires explicit official member measurements. No small-table dimensions fabricated.'))
 bank,mats=make_bank(keys);manifest=json.loads((R/'manifest.json').read_text())if selected and(R/'manifest.json').exists()else[]
 for p,v,parts,features in prepared:
  h,w,d=[v[k]for k in ['height_cm','width_cm','depth_cm']];fmt=lambda n:format(n,'g').replace('.','p');id=p['sku'].replace('/','-')+'-h'+fmt(h)+'-w'+fmt(w)+'-d'+fmt(d);out=R/'models'/id;out.mkdir(parents=True,exist_ok=True);print('geometry',id,flush=True)
  vv=np.concatenate([np.array(q['_vertices'])for q in parts]);lo=vv.min(0);hi=vv.max(0);dims=np.array([w,h,d])/100;scale=dims/(hi-lo);centre=np.array([(lo[0]+hi[0])/2,lo[1],(lo[2]+hi[2])/2]);meshes=[];checks=[]
  for q in parts:
   q['_vertices']=[tuple((np.array(x)-centre)*scale)for x in q['_vertices']]
   if q['material']in ['lightburl','darkburl']:
    # Each full veneered face is one continuous0..1 chart, avoiding periodic texture seams across the cube.
    pos=np.asarray(q['_vertices']);newpos=[];newuv=[];newfaces=[]
    for face in q['_faces']:
     pts=pos[list(face)];axis=int(np.argmax(np.abs(np.cross(pts[1]-pts[0],pts[2]-pts[0]))));first=len(newpos)
     for x,y,z in pts:newpos.append((x,y,z));newuv.append((z/dims[2]+.5,y/dims[1])if axis==0 else((x/dims[0]+.5,z/dims[2]+.5)if axis==1 else(x/dims[0]+.5,y/dims[1])))
     newfaces.append((first,first+1,first+2))
    q['_vertices']=newpos;q['_uvs']=newuv;q['_faces']=newfaces
   mesh,check=_finalize(q);flatcap_normals(mesh);meshes.append(mesh);checks.append(check)
  uvrep=M.ensure_uv_faces(meshes);used={k:dict(mats[k])for k in{m['material']for m in meshes}};maps=[]
  for mat in used.values():
   for field in ['baseColorTexture','normalTexture','metallicRoughnessTexture']:
    src=bank/mat[field];dest=out/src.name;shutil.copyfile(src,dest);maps.append(dict(name=dest.name,sha256=sha(dest),resolution=[2048,2048]))
  source_pointer=f"/{data.index(p)}/sizes/{p['sizes'].index(v)}"
  meta=dict(id=id,name=M.title(p['title'])+(' · En düşük konum'if v.get('pose_kind')=='minimum_adjustment'else' · En yüksek konum'if v.get('pose_kind')=='maximum_adjustment'else''),sku=p['sku'],url=p['url'],category='Tabureler',dimensions_cm=[w,h,d],source_dimensions_hwd_cm=[h,w,d],estimated_dimensions=False,source_market='Türkiye',size_source_kind='official_tr',size_source_urls=[v['source_url']],source_size_pointer=str(R/'resolved-source-inventory.json')+'#'+source_pointer,source_evidence_files=p.get('detail_evidence_files',[]),variant_status=v['status'],variant_status_verbatim='Benzer ürünleri görüntüle'if v['status']=='out_of_stock'else'Coming Soon'if v['status']=='coming_soon'else'Resmî sayfada ölçüsü listeleniyor',scale_note='Resmî Türkiye ürününün başlıklı Y×G×D dış ölçüleri kullanıldı. Yerel kesit, tabla kalınlığı, pah, ayak/bağlantı ayrıntısı ve yüzey damarları fotoğraftan yorumlandı. Fotoğraf pikselleri ve fotoğraf yansımaları kaplamaya işlenmedi.'+(' İkili takımın küçük üyesinin ölçüsü henüz doğrulanmadığından bu model yalnızca resmî dış ölçülü büyük üyedir.'if p['family_path_code']=='48100072'and not p.get('bundle_members')else''),units='metres',up_axis='Y',origin='bottom bounding-box centre',source_images=p['images'],product_photo_code=p['image_code'],photo_pixels_baked=False,baked_reflections=False,official_materials_and_description_verbatim=p.get('official_live_detail',{}).get('text')if p.get('official_live_detail')else None,bundle_member_dimensions_verified=bool(p.get('bundle_members'))if p['family_path_code']=='48100072'else None,bundle_member_role=v.get('member_role'),bundle_source_quote=p.get('bundle_source_quote'),source_anomalies=p.get('source_anomalies',[]),pose_kind=v.get('pose_kind'),height_range_cm=v.get('height_range_cm'))
  model=out/'model.json';dump(model,dict(metadata=meta,materials=used,meshes=meshes));gqa=dict(valid=True,features=features,mesh_count=len(meshes),triangles=sum(q['triangles']for q in checks),meshes=checks,affine_fit_scale=scale.tolist(),uv_side_triangles_repaired=uvrep,official_bounds=True,local_details_photo_inferred=True);dump(out/'geometry-validation.json',gqa);dump(out/'material-validation.json',dict(valid=True,native_resolution=2048,intrinsic_material=True,photo_pixels_baked=False,baked_reflections=False,maps=maps))
  report=export_assets(model,out,id);glb=out/(id+'.glb');doc,binary=read_glb(glb);doc['samplers']=[dict(magFilter=9729,minFilter=9987,wrapS=10497,wrapT=10497)]
  for t in doc.get('textures',[]):t['sampler']=0
  binary=M.embed_tangents(doc,binary);write_glb(glb,doc,binary);report['deliverable_sha256']['glb']=sha(glb);report['glb_bytes']=glb.stat().st_size;dump(report['files']['validation'],report)
  e={k:meta[k]for k in ['id','name','sku','url','category','dimensions_cm','source_dimensions_hwd_cm','estimated_dimensions','source_market','size_source_kind','size_source_urls','source_size_pointer','scale_note','variant_status','variant_status_verbatim']};e.update(model_path=str(model),asset_dir=str(out),glb_path=str(glb),sha256=sha(glb),bytes=glb.stat().st_size,material_label=' · '.join(sorted(used)),source_images=p['images'],geometry_validation=str(out/'geometry-validation.json'),material_validation=str(out/'material-validation.json'),model_revision='complete-stool-photo-specific-v1',source_anomalies=p.get('source_anomalies',[]),card_index=p['card_index'],family_path_code=p['family_path_code'],pose_kind=v.get('pose_kind'),height_range_cm=v.get('height_range_cm'));dump(out/'topology-validation.json',M.AQ.check(e));manifest=[q for q in manifest if q['id']!=id];manifest.append(e);dump(R/'manifest.json',manifest);print('built',id,e['bytes'],gqa['triangles'],flush=True)
 dump(R/'pending.json',pending);dump(R/'qa-summary.json',dict(valid=True,models=len(manifest),cards_covered=len({e['url']for e in manifest}),target_cards=17,pending=len(pending),all_maps_native_2k_embedded=True,closed_geometry=True,photo_pixels_baked=False,baked_reflections=False));print('COMPLETE',len(manifest),'pending',len(pending),flush=True)
if __name__=='__main__':main()
