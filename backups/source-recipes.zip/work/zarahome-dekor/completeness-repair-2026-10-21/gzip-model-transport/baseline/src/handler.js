// The Sites owner-private access policy is the outer authorization boundary.
// Browser management also requires the platform's signed-in identity header.
const records = modelManifest.models;
const byId = new Map(records.map(record => [record.id, record]));
const byFilename = new Map(records.flatMap(record => record.accepted_filenames.map(name => [name, record])));
const catalogAssetsByRoute = new Map(catalogAssetManifest.map(record => [record.route, record]));
const catalogAssetsByFilename = new Map(catalogAssetManifest.map(record => [record.filename, record]));
const hipiconReferenceIds = new Set(JSON.parse(inlineAssets['/hipicon-reference-catalog.json']?.body || '{"products":[]}').products.map(product => product.id));
const hipiconSelectionKey = 'hipicon/reference-selection/v1.json';
const zarahomeReferenceCatalog = JSON.parse(inlineAssets['/zarahome-reference-catalog.json']?.body || '{"products":[]}');
const zarahomeReferenceIds = new Set(zarahomeReferenceCatalog.products.map(product => product.id));
const zarahomeReferenceAliases = new Map(Object.entries(zarahomeReferenceCatalog.legacy_selection_aliases || {}).filter(([,target])=>zarahomeReferenceIds.has(target)));
const zarahomeSelectionKey = 'zarahome/reference-selection/v1.json';
const MAX_MODEL_BYTES = 96 * 1024 * 1024;
const STREAM_MODEL_THRESHOLD_BYTES = 20 * 1024 * 1024;
const privateHeaders = { 'cache-control': 'private, no-store', 'x-content-type-options': 'nosniff' };

function json(value, status = 200) {
  return new Response(JSON.stringify(value), { status, headers: { ...privateHeaders, 'content-type': 'application/json; charset=utf-8' } });
}
function problem(message, status) { return json({ error: message }, status); }
function authorizedManagement(request, url, write) {
  if (!request.headers.get('oai-authenticated-user-id')?.trim()) return problem('Yönetim için hesabınla giriş yapmalısın.', 401);
  const origin = request.headers.get('origin');
  if ((write || origin !== null) && origin !== url.origin) return problem('İstek kaynağı doğrulanamadı.', 403);
  return null;
}
function matchesObject(object, record) {
  return object && object.size === record.bytes && object.customMetadata?.sha256 === record.sha256;
}
function storage(env) {
  if (!env?.BUCKET || typeof env.BUCKET.head !== 'function') throw new Error('storage_unavailable');
  return env.BUCKET;
}
async function mapLimited(items, concurrency, operation) {
  const output = new Array(items.length); let next = 0;
  await Promise.all(Array.from({ length: Math.min(concurrency, items.length) }, async () => {
    while (next < items.length) { const index = next++; output[index] = await operation(items[index]); }
  }));
  return output;
}
async function readSmallJson(request) {
  if (request.headers.get('content-type')?.split(';', 1)[0].trim().toLowerCase() !== 'application/json') {
    const error = new Error('JSON biçiminde bir seçim gönderilmelidir.'); error.status = 415; throw error;
  }
  const reader = request.body?.getReader();
  if (!reader) { const error = new Error('Seçim bilgisi eksik.'); error.status = 400; throw error; }
  const parts = []; let length = 0;
  try {
    while (true) {
      const { value, done } = await reader.read(); if (done) break;
      length += value.length;
      if (length > 8192) { await reader.cancel(); const error = new Error('Seçim bilgisi çok uzun.'); error.status = 413; throw error; }
      parts.push(value);
    }
  } finally { reader.releaseLock(); }
  const bytes = new Uint8Array(length); let offset = 0;
  for (const part of parts) { bytes.set(part, offset); offset += part.length; }
  try { return JSON.parse(new TextDecoder().decode(bytes)); }
  catch { const error = new Error('Seçim bilgisi okunamadı.'); error.status = 400; throw error; }
}
async function referenceSelectionResponse(request, url, env, referenceIds, selectionKey, aliases = new Map()) {
  // Selection is shared only inside this confirmed owner-private Site. The
  // platform authenticates browser and service callers before Worker dispatch.
  const write = request.method === 'PUT';
  if (!write && request.method !== 'GET') return problem('Seçim işlemi desteklenmiyor.', 405);
  const origin = request.headers.get('origin');
  if ((write || origin !== null) && origin !== url.origin) return problem('İstek kaynağı doğrulanamadı.', 403);
  const change = write ? await readSmallJson(request) : null;
  if(change && typeof change.id === 'string' && aliases.has(change.id))change.id=aliases.get(change.id);
  if (change && (!referenceIds.has(change.id) || typeof change.selected !== 'boolean' || Object.keys(change).some(key => !['id', 'selected'].includes(key)))) {
    return problem('Seçilen ürün görsel kataloğunda bulunamadı.', 400);
  }
  if (write && (!change || typeof change !== 'object' || Array.isArray(change))) return problem('Seçim bilgisi geçerli değil.', 400);
  const bucket = storage(env);
  for (let attempt = 0; attempt < 3; attempt++) {
    const object = await bucket.get(selectionKey);
    const current = object ? await object.json() : { selected_ids: [], updated_at: null };
    if (!Array.isArray(current.selected_ids)) throw new Error('selection_storage_invalid');
    const selected = new Set(current.selected_ids.map(id=>aliases.get(id)||id).filter(id => referenceIds.has(id)));
    if (!write || selected.has(change.id) === change.selected) return json({ selected_ids: [...selected], updated_at: current.updated_at || null });
    if (change.selected) selected.add(change.id); else selected.delete(change.id);
    const next = { selected_ids: [...selected].sort(), updated_at: new Date().toISOString() };
    const headers = new Headers(object ? { 'If-Match': object.httpEtag || '"' + object.etag + '"' } : { 'If-None-Match': '*' });
    const saved = await bucket.put(selectionKey, JSON.stringify(next), { onlyIf: headers, httpMetadata: { contentType: 'application/json; charset=utf-8' } });
    if (saved !== null) return json(next);
  }
  return problem('Seçimin başka bir pencerede değişti. Yeniden deneyebilirsin.', 409);
}
async function statusResponse(env) {
  const bucket = storage(env);
  const stored = new Map(); let cursor; let pages = 0;
  do {
    const listing = await bucket.list({ prefix: 'models/', limit: 1000, include: ['customMetadata'], ...(cursor ? { cursor } : {}) });
    for (const object of listing.objects) stored.set(object.key, object);
    cursor = listing.truncated ? listing.cursor : undefined;
    if (listing.truncated && (!cursor || ++pages >= 32)) throw new Error('status_listing_incomplete');
  } while (cursor);
  const models = records.map(record => {
    const object = stored.get(record.key);
    return { id: record.id, name: record.name, filename: record.filename,
      accepted_filenames: record.accepted_filenames, bytes: record.bytes, sha256: record.sha256,
      status: !object ? 'missing' : matchesObject(object, record) ? 'ready' : 'conflict' };
  });
  const ready = models.filter(model => model.status === 'ready');
  return json({ total: models.length, ready: ready.length, ready_bytes: ready.reduce((sum, model) => sum + model.bytes, 0), models });
}
async function readExactBody(request, size) {
  const declared = request.headers.get('content-length');
  if (declared !== null && (!/^\d+$/.test(declared) || Number(declared) !== size)) {
    const error = new Error('Dosya boyutu beklenen değerle eşleşmiyor.'); error.status = 400; throw error;
  }
  if (!request.body) { const error = new Error('Dosya gövdesi eksik.'); error.status = 400; throw error; }
  const body = new Uint8Array(size); let offset = 0;
  const reader = request.body.getReader();
  try {
    while (true) {
      const { value, done } = await reader.read(); if (done) break;
      if (offset + value.byteLength > size) {
        await reader.cancel(); const error = new Error('Dosya izin verilen boyutu aşıyor.'); error.status = 413; throw error;
      }
      body.set(value, offset); offset += value.byteLength;
    }
  } finally { reader.releaseLock(); }
  if (offset !== size) { const error = new Error('Dosya tamamlanmadı veya boyutu eşleşmiyor.'); error.status = 400; throw error; }
  return body;
}
async function uploadStreamedModel(request, env, record) {
  // Keep the native request stream intact: Workers/R2 know its Content-Length.
  // Do not tee, transform, buffer, or call subtle.digest on these large bodies.
  const declared = request.headers.get('content-length');
  if (declared === null || !/^\d+$/.test(declared) || Number(declared) !== record.bytes) {
    return problem('Dosya boyutu beklenen değerle eşleşmiyor.', 400);
  }
  if (!request.body) return problem('Dosya gövdesi eksik.', 400);
  const bucket = storage(env); const existing = await bucket.head(record.key);
  // Resuming a verified immutable object never replaces it or consumes a new body.
  if (existing) return matchesObject(existing, record) ? json({ id: record.id, status: 'ready', already_present: true }) : problem('Saklanan dosyanın doğrulaması eşleşmiyor.', 409);
  // R2 checks the manifest-bound SHA before committing any object. A truncated,
  // extended, changed, or failed request stream cannot leave a partial object.
  // The manifest SHA is bound to an independently validated original GLB header;
  // exact SHA equality therefore also authenticates that header for this path.
  const result = await bucket.put(record.key, request.body, {
    sha256: record.sha256,
    onlyIf: new Headers({ 'If-None-Match': '*' }),
    httpMetadata: { contentType: 'model/gltf-binary' },
    customMetadata: { sha256: record.sha256, model_id: record.id },
  });
  if (result === null && !matchesObject(await bucket.head(record.key), record)) return problem('Dosya eşzamanlı yükleme sırasında doğrulanamadı.', 409);
  return json({ id: record.id, status: 'ready', already_present: result === null }, result === null ? 200 : 201);
}
async function uploadResponse(request, env, record) {
  if (!Number.isSafeInteger(record.bytes) || record.bytes < 12 || record.bytes > MAX_MODEL_BYTES) return problem('Model dosyası izin verilen boyutu aşıyor.', 413);
  const suppliedHash = request.headers.get('x-model-sha256');
  if (suppliedHash !== record.sha256) return problem('Dosya doğrulama bilgisi eşleşmiyor.', 400);
  const type = request.headers.get('content-type')?.split(';', 1)[0].trim().toLowerCase();
  if (!['model/gltf-binary', 'application/octet-stream'].includes(type)) return problem('GLB dosyası gönderilmelidir.', 415);
  if (record.bytes > STREAM_MODEL_THRESHOLD_BYTES) return await uploadStreamedModel(request, env, record);
  const bytes = await readExactBody(request, record.bytes);
  const view = new DataView(bytes.buffer);
  if (bytes.length < 12 || view.getUint32(0, true) !== 0x46546c67 || view.getUint32(4, true) !== 2 || view.getUint32(8, true) !== bytes.length) {
    return problem('GLB başlığı geçerli değil.', 400);
  }
  const hash = [...new Uint8Array(await crypto.subtle.digest('SHA-256', bytes))].map(value => value.toString(16).padStart(2, '0')).join('');
  if (hash !== record.sha256) return problem('Dosya içeriği özgün modelle eşleşmiyor.', 400);
  const bucket = storage(env); const existing = await bucket.head(record.key);
  if (existing) return matchesObject(existing, record) ? json({ id: record.id, status: 'ready', already_present: true }) : problem('Saklanan dosyanın doğrulaması eşleşmiyor.', 409);
  // A conditional create prevents changing any existing content-addressed object.
  const result = await bucket.put(record.key, bytes, {
    onlyIf: new Headers({ 'If-None-Match': '*' }),
    httpMetadata: { contentType: 'model/gltf-binary' },
    customMetadata: { sha256: record.sha256, model_id: record.id },
  });
  if (result === null && !matchesObject(await bucket.head(record.key), record)) return problem('Dosya eşzamanlı yükleme sırasında doğrulanamadı.', 409);
  return json({ id: record.id, status: 'ready', already_present: result === null }, result === null ? 200 : 201);
}
async function modelResponse(request, url, env, record) {
  const version = url.searchParams.get('v');
  if (version !== null && version !== record.sha256) return problem('Bu model sürümü bulunamadı.', 404);
  const bucket = storage(env);
  const object = request.method === 'HEAD' ? await bucket.head(record.key) : await bucket.get(record.key);
  if (!object) return problem('Tam ayrıntılı model henüz yüklenmedi.', 404);
  if (!matchesObject(object, record)) return problem('Saklanan model doğrulanamadı.', 409);
  const headers = new Headers({
    'content-type': 'model/gltf-binary', 'content-length': String(record.bytes),
    'content-disposition': 'inline; filename="' + record.filename + '"',
    'cache-control': version ? 'private, max-age=31536000, immutable' : 'private, no-cache',
    'etag': '"' + record.sha256 + '"', 'x-content-type-options': 'nosniff',
  });
  if (request.headers.get('if-none-match') === headers.get('etag')) {
    if (object.body?.cancel) await object.body.cancel();
    headers.delete('content-length'); return new Response(null, { status: 304, headers });
  }
  return new Response(request.method === 'HEAD' ? null : object.body, { headers });
}
function assetResponse(request, path) {
  const asset = inlineAssets[path]; if (!asset) return problem('Sayfa bulunamadı.', 404);
  return new Response(request.method === 'HEAD' ? null : asset.body, {
    headers: { ...privateHeaders, 'content-type': asset.type },
  });
}
async function uploadCatalogAsset(request, env, record) {
  if(request.headers.get('x-asset-sha256')!==record.sha256)return problem('Katalog doğrulama bilgisi eşleşmiyor.',400);
  if(request.headers.get('content-type')?.split(';',1)[0].trim().toLowerCase()!=='application/json')return problem('Katalog JSON biçiminde gönderilmelidir.',415);
  const bytes=await readExactBody(request,record.bytes);
  const hash=[...new Uint8Array(await crypto.subtle.digest('SHA-256',bytes))].map(value=>value.toString(16).padStart(2,'0')).join('');
  if(hash!==record.sha256)return problem('Katalog içeriği özgün dosyayla eşleşmiyor.',400);
  const bucket=storage(env),existing=await bucket.head(record.key);
  if(existing)return matchesObject(existing,record)?json({filename:record.filename,status:'ready',already_present:true}):problem('Kayıtlı katalog doğrulanamadı.',409);
  const saved=await bucket.put(record.key,bytes,{onlyIf:new Headers({'If-None-Match':'*'}),httpMetadata:{contentType:record.type},customMetadata:{sha256:record.sha256}});
  if(saved===null&&!matchesObject(await bucket.head(record.key),record))return problem('Katalog eşzamanlı yükleme sırasında doğrulanamadı.',409);
  return json({filename:record.filename,status:'ready',already_present:saved===null},saved===null?200:201);
}
async function storedCatalogResponse(request,url,env,record){
  const version=url.searchParams.get('v');
  if(version!==null&&version!==record.sha256)return problem('Katalog sürümü bulunamadı.',404);
  const object=await storage(env).get(record.key);
  if(!matchesObject(object,record))return problem('Katalog hazırlanıyor. Biraz sonra yeniden deneyebilirsin.',503);
  const headers={...privateHeaders,'content-type':record.type,'content-length':String(record.bytes),etag:'"'+record.sha256+'"','cache-control':version?'private, max-age=31536000, immutable':'private, no-cache'};
  if(request.headers.get('if-none-match')===headers.etag){if(object.body?.cancel)await object.body.cancel();return new Response(null,{status:304,headers});}
  if(request.method==='HEAD'&&object.body?.cancel)await object.body.cancel();
  return new Response(request.method==='HEAD'?null:object.body,{headers});
}
export default {
  async fetch(request, env, ctx) {
    void ctx;
    const url = new URL(request.url); const path = url.pathname;
    try {
      if (path === '/api/hipicon/selection') return await referenceSelectionResponse(request, url, env, hipiconReferenceIds, hipiconSelectionKey);
      if (path === '/api/zarahome/selection') return await referenceSelectionResponse(request, url, env, zarahomeReferenceIds, zarahomeSelectionKey, zarahomeReferenceAliases);
      // This shared import route relies on the confirmed owner-private Sites
      // access boundary. Dispatch authenticates service access before the Worker.
      if (path.startsWith('/api/import/')) {
        const origin = request.headers.get('origin');
        if (origin !== null && origin !== url.origin) return problem('İstek kaynağı doğrulanamadı.', 403);
        if (path === '/api/import/status' && request.method === 'GET') return await statusResponse(env);
        const catalogMatch=path.match(/^\/api\/import\/assets\/([^/]+)$/);
        if(catalogMatch&&request.method==='PUT'){
          const record=catalogAssetsByFilename.get(catalogMatch[1]);
          if(!record)return problem('Katalog dosyası koleksiyonda bulunamadı.',404);
          return await uploadCatalogAsset(request,env,record);
        }
        const match = path.match(/^\/api\/import\/models\/([^/]+)$/);
        if (match && request.method === 'PUT') {
          let filename;
          try { filename = decodeURIComponent(match[1]); } catch { return problem('Dosya adı geçersiz.', 400); }
          const record = byFilename.get(filename);
          if (!record) return problem('Dosya koleksiyon listesinde bulunamadı.', 404);
          return await uploadResponse(request, env, record);
        }
        return problem('Bu aktarım işlemi desteklenmiyor.', 405);
      }
      if (path === '/manage' || path === '/manage/' || path.startsWith('/api/manage/')) {
        const denied = authorizedManagement(request, url, request.method !== 'GET' && request.method !== 'HEAD');
        if (denied) return denied;
        if ((path === '/manage' || path === '/manage/') && ['GET', 'HEAD'].includes(request.method)) {
          return new Response(request.method === 'HEAD' ? null : manageHtml, { headers: { ...privateHeaders, 'content-type': 'text/html; charset=utf-8' } });
        }
        if (path === '/api/manage/status' && request.method === 'GET') return await statusResponse(env);
        const match = path.match(/^\/api\/manage\/models\/([^/]+)$/);
        if (match && request.method === 'PUT') {
          let filename;
          try { filename = decodeURIComponent(match[1]); } catch { return problem('Dosya adı geçersiz.', 400); }
          const record = byFilename.get(filename);
          if (!record) return problem('Dosya koleksiyon listesinde bulunamadı.', 404);
          return await uploadResponse(request, env, record);
        }
        return problem('Bu yönetim işlemi desteklenmiyor.', 405);
      }
      if (!['GET', 'HEAD'].includes(request.method)) return problem('İstek yöntemi desteklenmiyor.', 405);
      const catalogAsset=catalogAssetsByRoute.get(path);
      if(catalogAsset)return await storedCatalogResponse(request,url,env,catalogAsset);
      const model = path.match(/^\/models\/([a-zA-Z0-9-]+)\.glb$/);
      if (model) {
        const record = byId.get(model[1]); if (!record) return problem('Model bulunamadı.', 404);
        return await modelResponse(request, url, env, record);
      }
      return assetResponse(request, path === '/index.html' ? '/' : path === '/hipicon/' ? '/hipicon' : path === '/zarahome-secki/' ? '/zarahome-secki' : path);
    } catch (error) {
      if (error?.status) return problem(error.message, error.status);
      return problem('Depolama işlemi tamamlanamadı. Yeniden deneyebilirsin.', 503);
    }
  },
};
