import json, re, hashlib
from pathlib import Path
from urllib.parse import urlparse, parse_qs

ROOT = Path('/Users/USER/Documents/ChatGPT/Studio')
BASE = ROOT / 'work/zarahome-dekor/completeness-repair-2026-10-21/furniture-textile'
LIVE = ROOT / 'work/zarahome-dekor/completeness-repair-2026-10-21/live-category-cards.json'
MODEL = ROOT / 'sites/zarahome-vazo-kutuphanesi-final-378/ui/catalog.json'
REF = ROOT / 'sites/zarahome-vazo-kutuphanesi-final-378/ui/zarahome-reference-catalog.json'
WANTED = ['Yan sehpalar','Tabureler','Banklar','Puflar','Kırlentler','Halılar','Oturma odası halıları']

def canonical(u): return u.split('?')[0] if u else ''
def image_code(u):
    m = re.search(r'/(\d{11}(?:[A-Z]{4})?)(?:\d{2})?-[a-z0-9]+/', u)
    return m[1] if m else None
def family(u):
    m = re.search(r'-l(\d{8})', u)
    return m[1] if m else None
def plain(s): return re.sub(r'L\d+: ?', '', s)

models = json.loads(MODEL.read_text())
references = json.loads(REF.read_text())['products']
live = json.loads(LIVE.read_text())
sources = []
for path in sorted((BASE/'research').glob('*.txt')):
    for section in re.split(r'-{30,}\n?', path.read_text()):
        if 'Content type: text/html' not in section: continue
        u = re.search(r'https://www\.zarahome\.com/tr/[^\s)]+', section)
        if not u: continue
        sku = re.search(r'Button: (\d{4}/\d{3}/\d{3})', section) or re.search(r'\b(\d{4}/\d{3}/\d{3})\b',section)
        text = plain(section)
        ref = re.search('(turn[^]+)', section)
        sizes = []
        family_ref = re.search(r'ref\.\s*(\d{4}/\d{3})(?![/\d])',text)
        # Explicit fixed dimensions are displayed in height, width, depth order.
        m = re.search(r'Yükseklik(?:\(A\))?\s*:?\s*Genişlik(?:\(B\))?\s*:?\s*Derinlik(?:\(C\))?\s*:?(.+)', text, re.S)
        if m:
            vals = re.findall(r'(?<![\d.])(\d+(?:[.,]\d+)?)\s*cm',m[1])
            for i in range(0,len(vals)-2,3):
                h,w,d = [float(x.replace(',','.')) for x in vals[i:i+3]]
                if max(h,w,d) < 1000: sizes.append({'label':f'{h:g} × {w:g} × {d:g} cm (Y × G × D)','dimensions_cm':{'height':h,'width':w,'depth':d},'source_url':u[0],'source_kind':'official_product_text'})
        inline = re.search(r'Yükseklik\s*:\s*(\d+(?:[.,]\d+)?) cm\s*Genişlik\s*:\s*(\d+(?:[.,]\d+)?) cm\s*Derinlik\s*:\s*(\d+(?:[.,]\d+)?) cm',text)
        if inline and not sizes:
            h,w,d=[float(x.replace(',','.')) for x in inline.groups()]
            sizes.append({'label':f'{h:g} × {w:g} × {d:g} cm (Y × G × D)','dimensions_cm':{'height':h,'width':w,'depth':d},'source_url':u[0],'source_kind':'official_product_text'})
        before = re.search(r'(\d+(?:[.,]\d+)?)\s+(\d+(?:[.,]\d+)?)\s+(\d+(?:[.,]\d+)?)\s+Yükseklik\s+Genişlik\s+Derinlik',text)
        if before and not sizes:
            h,w,d=[float(x.replace(',','.')) for x in before.groups()]
            sizes.append({'label':f'{h:g} × {w:g} × {d:g} (Y × G × D; birim metinde belirtilmemiş)','dimensions_raw':{'height':h,'width':w,'depth':d,'unit':None},'source_url':u[0],'source_kind':'official_dimension_columns_no_unit'})
        for m in re.finditer(r'(?<!\d)(\d+(?:[.,]\d+)?)\s*[×xX]\s*(\d+(?:[.,]\d+)?)\s*cm',text):
            label = f'{m[1]} × {m[2]} cm'
            if label not in [x['label'] for x in sizes]: sizes.append({'label':label,'source_url':u[0],'source_kind':'official_product_text'})
        sources.append({'url':u[0],'canonical_url':canonical(u[0]),'sku':sku[1] if sku else None,'family_reference':family_ref[1] if family_ref else None,'sizes':sizes,'web_ref':ref[1] if ref else None,'evidence_file':str(path.relative_to(ROOT)),'text':text})

# Existing live product captures are retained evidence, distinctly labelled.
prior=[]
for rel in ['work/zarahome-dekor/ten-more-2026-10-21/furniture/research.json','work/zarahome-dekor/ten-more-2026-10-21/furniture/research-initial4.json','work/zarahome-dekor/ten-more-2026-10-21/soft/research-from-root.json']:
    for x in json.loads((ROOT/rel).read_text()):
        code=x.get('image_code')
        if not code and x.get('sku'): code='4'+x['sku'].replace('/','')
        labels=list(dict.fromkeys(re.findall(r'(?<![\d×xX])(\d+(?:[.,]\d+)?\s*[×xX]\s*\d+(?:[.,]\d+)?\s*cm)',x.get('size_panel_text',''))))
        sizes=[{'label':re.sub(r'\s*[xX]\s*',' × ',s),'source_url':x['url'],'source_kind':'prior_official_live_size_panel','evidence_file':rel} for s in labels]
        panel=x.get('size_panel_text','')
        if '\nBeden\n' in panel:
            block=panel.split('\nBeden\n',1)[1].split('\nEKLE',1)[0]
            for line in block.splitlines():
                if re.fullmatch(r'\d+(?:[.,]\d+)?\s*cm',line.strip()) and line.strip() not in [s['label'] for s in sizes]:
                    sizes.append({'label':line.strip(),'source_url':x['url'],'source_kind':'prior_official_live_size_panel','evidence_file':rel,'note':'Single measure copied literally from the official size selector; shape is not inferred.'})
        if x.get('dimensions_cm'):
            w,h,d=x['dimensions_cm'];sizes.append({'label':f'{h:g} × {w:g} × {d:g} cm (Y × G × D)','dimensions_cm':{'height':h,'width':w,'depth':d},'source_url':x['url'],'source_kind':'prior_official_live_product','evidence_file':rel})
        material_dims=re.search(r'Yükseklik\s*:\s*(\d+(?:[.,]\d+)?) cm\s*Genişlik\s*:\s*(\d+(?:[.,]\d+)?) cm\s*Derinlik\s*:\s*(\d+(?:[.,]\d+)?) cm',x.get('materials_text',''))
        if material_dims and not any(s.get('dimensions_cm') for s in sizes):
            h,w,d=[float(v.replace(',','.')) for v in material_dims.groups()]
            sizes.append({'label':f'{h:g} × {w:g} × {d:g} cm (Y × G × D)','dimensions_cm':{'height':h,'width':w,'depth':d},'source_url':x['url'],'source_kind':'prior_official_live_material_dimensions','evidence_file':rel})
        prior.append({'url':x['url'],'canonical_url':canonical(x['url']),'image_code':code,'sku':x.get('sku'),'sizes':sizes,'images':[{k:z[k] for k in ['url','alt'] if k in z} for z in x.get('images',[])],'evidence_file':rel})

def model_codes(m):
    codes=set()
    if m.get('sku'): codes.add('4'+m['sku'].replace('/',''))
    for im in m.get('reference_images',[]):
        c=image_code(im.get('url',''))
        if c: codes.add(c)
    return codes

output={'schema_version':'1.0','scope':'Official visible category cards, without a per-category product cap','baseline_model_count':len(models),'baseline_sha256':hashlib.sha256(MODEL.read_bytes()).hexdigest(),'source_file':str(LIVE.relative_to(ROOT)),'categories':[]}
for cat in live['categories']:
    if cat['category'] not in WANTED: continue
    c={k:cat[k] for k in ['category','url','observed_at','scan_complete','official_card_count']}
    c['scan_evidence']=cat.get('scan_evidence')
    c['products']=[]
    for i,x in enumerate(cat['products']):
        p={'title':x['title'],'url':x['url'],'images':x.get('images',[]),'card_index':i+1,'source_note':['Product card and image URLs copied from root live DOM capture without changing query parameters.'],'evidence_file':str(LIVE.relative_to(ROOT))}
        codes=list(dict.fromkeys(filter(None,[image_code(im.get('url','')) for im in p['images']])))
        code=codes[0] if codes else None
        p['image_code']=code;p['observed_image_codes']=codes
        if code and not code.isdigit():
            p['composite_product']=True
            p['source_note'].append('Official card is a composite/bundle with an alphanumeric image code; it is not reduced to a single cushion SKU.')
        candidates=[s for s in sources if (s['canonical_url']==canonical(x['url']) or (code and s['sku'] and '4'+s['sku'].replace('/','')==code)) and (s['sku'] or s['family_reference'])]
        # Prefer details whose exact SKU matches the current card's photograph.
        exact=[s for s in candidates if code and s['sku'] and '4'+s['sku'].replace('/','')==code]
        family_only=[s for s in candidates if not s['sku'] and code and s['family_reference'] and ('4'+s['family_reference'].replace('/',''))==code[:8]]
        same_url=[s for s in candidates if s['url']==x['url']]
        detail=(exact or same_url or family_only or (candidates if len(set(s['sku'] for s in candidates))==1 and not code else []))
        prior_exact=[s for s in prior if code and (s['image_code']==code or (s.get('image_code') and family(x['url'])==s['image_code'][:8] and code[-3:]==s['image_code'][-3:]))]
        if detail:
            if detail[0]['sku']:p['sku']=detail[0]['sku']
            p['detail_source_urls']=list(dict.fromkeys(s['url'] for s in detail));p['detail_evidence_files']=list(dict.fromkeys(s['evidence_file'] for s in detail))
            if family_only and not exact:p['source_note'].append('Official detail identifies this family without a color-specific SKU; dimensions retain any missing source unit explicitly.')
        elif prior_exact and prior_exact[0].get('sku'):
            p['sku']=prior_exact[0]['sku'];p['source_note'].append('SKU verified in retained earlier official live capture; not revalidated in this text pass.')
        sizes=[]
        for s in detail+prior_exact:
            for z in s['sizes']:
                if z['label'] not in [v['label'] for v in sizes]:sizes.append(z)
        if sizes:p['sizes']=sizes
        p['sizes_complete']=False
        if sizes and cat['category'] in ['Yan sehpalar','Tabureler','Banklar','Puflar'] and all('dimensions_raw' not in z for z in sizes) and not any('Beden seç' in s.get('text','') for s in detail):p['sizes_complete']=True
        if not sizes:p['source_note'].append('Visible card has no size; expanded product size selector could not be verified in the public text source.')
        # A canonical family page can default to another color; preserve separately.
        family_sizes=[]
        if not sizes:
            for s in candidates:
                if not s['sku'] or family(s['url']) != ('4'+s['sku'].replace('/',''))[:8]: continue
                for z in s['sizes']:
                    if z['label'] not in [v['label'] for v in family_sizes]:family_sizes.append(z)
            if family_sizes:p['related_family_sizes']=family_sizes;p['source_note'].append('Related family sizes are not attributed as verified sizes of this color card.')
        matches=[];basis=[]
        for m in models:
            if code and code in model_codes(m):matches.append(m['id']);basis.append('exact_image_code_or_sku')
            elif p.get('sku') and p['sku']==m.get('sku'):matches.append(m['id']);basis.append('exact_sku')
            elif x['url']==m.get('url'):matches.append(m['id']);basis.append('exact_product_url')
            elif code and family(x['url'])==family(m.get('url','')) and m.get('sku','').endswith('/'+code[-3:]):matches.append(m['id']);basis.append('same_official_family_url_and_color')
        p['matched_model_ids']=list(dict.fromkeys(matches));p['match_basis']=list(dict.fromkeys(basis));p['missing_model']=not bool(matches)
        p['matched_reference_ids']=[r['id'] for r in references if (code and (r.get('product_code','').replace('/','')==code[1:] or any(image_code(im.get('url',''))==code for im in r.get('images',[])))) or r.get('url')==x['url']]
        if family(x['url']) and code and family(x['url'])!=code[:8]:p['source_note'].append('Official card photograph code differs from URL family; preserved as observed, without inventing a SKU from the photograph.')
        c['products'].append(p)
    c['limitations']=[]
    if not c['scan_complete']:c['limitations'].append('Live scan is not yet marked complete; card count is a lower bound.')
    c['limitations'].append('All listed images are observed URLs. This inventory does not rewrite image URL widths or timestamps.')
    if any(not p['sizes_complete'] for p in c['products']):c['limitations'].append('Not all color-specific sizes could be verified; sizes_complete is false on unresolved products.')
    c['observed_missing_model_card_count']=sum(p['missing_model'] for p in c['products'])
    c['observed_matching_model_card_count']=len(c['products'])-c['observed_missing_model_card_count']
    c['baseline_not_in_observed_cards']=[{'id':m['id'],'title':m['name'],'sku':m['sku'],'url':m['url']} for m in models if m['category']==cat['category'] and not any(m['id'] in p['matched_model_ids'] for p in c['products'])]
    output['categories'].append(c)

allp=[p for c in output['categories'] for p in c['products']]
# Merge repeated merchandising cards using their observed identity aliases.
# A shared historical gallery code alone is retained alongside family/color aliases.
parents=list(range(len(allp)))
def find(i):
    while parents[i]!=i:
        parents[i]=parents[parents[i]];i=parents[i]
    return i
def union(a,b):parents[find(a)]=find(b)
aliases={}
for i,p in enumerate(allp):
    labels=['url:'+p['url']]
    if p.get('image_code'):labels+=['image:'+p['image_code'],'family_color:'+str(family(p['url']))+'/'+p['image_code'][-3:]]
    if p.get('sku'):labels+=['sku:'+p['sku']]
    for label in labels:
        if label in aliases:union(i,aliases[label])
        else:aliases[label]=i
for i,p in enumerate(allp):p['identity_group']='furniture-textile-'+str(find(i)+1).zfill(4)
groups={}
for p in allp:groups.setdefault(p['identity_group'],[]).append(p)
unique_missing=sum(not any(p['matched_model_ids'] for p in ps) for ps in groups.values())
photo_key=lambda p:p.get('image_code') or p['url']
output['summary']={'observed_card_count':len(allp),'observed_unique_image_code_count':len(set(photo_key(p) for p in allp)),'missing_model_card_count':sum(p['missing_model'] for p in allp),'missing_unique_image_code_count':len(set(photo_key(p) for p in allp if p['missing_model'])),'observed_family_color_group_count':len(groups),'missing_family_color_group_count':unique_missing,'matched_unique_model_count':len(set(mid for p in allp for mid in p['matched_model_ids'])),'scan_complete':all(c['scan_complete'] for c in output['categories']),'size_verification_complete':all(p['sizes_complete'] for p in allp),'products_with_sizes':sum(bool(p.get('sizes')) for p in allp),'cards_with_sku':sum(bool(p.get('sku')) for p in allp),'identity_count_note':'Card count is authoritative for the observed list. Photo-code and family/color group counts are separate deduplication views; historical photo codes and repeated merchandising cards prevent claiming either view is an exact count of all distinct SKUs or sizes.'}
(BASE/'inventory.json').write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n')
missing=[{'category':c['category'],**p} for c in output['categories'] for p in c['products'] if p['missing_model']]
(BASE/'missing-products.json').write_text(json.dumps(missing,ensure_ascii=False,indent=2)+'\n')
(BASE/'identity-groups.json').write_text(json.dumps([{'identity_group':gid,'missing_model':not any(p['matched_model_ids'] for p in ps),'matched_model_ids':sorted(set(mid for p in ps for mid in p['matched_model_ids'])),'observed_image_codes':sorted(set(p['image_code'] for p in ps if p.get('image_code'))),'observed_skus':sorted(set(p['sku'] for p in ps if p.get('sku'))),'urls':list(dict.fromkeys(p['url'] for p in ps)),'titles':list(dict.fromkeys(p['title'] for p in ps))} for gid,ps in groups.items()],ensure_ascii=False,indent=2)+'\n')
(BASE/'product-details.json').write_text(json.dumps([s for s in sources if s['sku'] or s['family_reference']],ensure_ascii=False,indent=2)+'\n')
print(json.dumps(output['summary'],ensure_ascii=False))
for c in output['categories']:print(c['category'],len(c['products']),c['observed_missing_model_card_count'],'missing; sizes',sum(bool(p.get('sizes')) for p in c['products']))
