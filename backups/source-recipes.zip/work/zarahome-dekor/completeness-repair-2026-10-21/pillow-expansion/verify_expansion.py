"""Independent exported GLB/topology/material checks and first measured set coverage."""
from pathlib import Path
import sys,json,hashlib,io
sys.dont_write_bytecode=True
import numpy as np
from PIL import Image
P=Path(__file__).resolve().parent;N=P.parent;ROOT=N.parents[2];W=ROOT/'work/zarahome-dekor';sys.path.insert(0,str(W));sys.path.insert(0,str(W/'objects'))
from export_catalog import read_glb
from audit_geometry import check
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
write=lambda p,x:Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
a=json.loads((P/'final-manifest.json').read_text());assert len(a)==43 and len({e['sku']for e in a})==43
masters=json.loads((P/'image-master-register.json').read_text())['masters']
for r in masters:
 assert sha(r['local_master'])==r['sha256'];im=Image.open(r['local_master']);assert list(im.size)==r['source_dimensions'] and im.format=='JPEG'
checks=[]
for e in a:
 assert sha(e['glb_path'])==e['sha256'];assert Path(e['glb_path']).stat().st_size==e['bytes'] and e['bytes']<25*1024*1024;assert e['quality_pending']==[]
 qa=check(e);gd,data=read_glb(e['glb_path']);positions=[]
 def ar(i):
  v=gd['accessors'][i];b=gd['bufferViews'][v['bufferView']];dt={5126:'<f4',5125:'<u4',5123:'<u2',5121:'u1'}[v['componentType']];n={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}[v['type']];size=np.dtype(dt).itemsize
  return np.ndarray((v['count'],n),dtype=dt,buffer=data,offset=b.get('byteOffset',0)+v.get('byteOffset',0),strides=(b.get('byteStride',n*size),size))
 for m in gd['meshes']:
  for p in m['primitives']:
   attrs=p['attributes'];pos=ar(attrs['POSITION']);norm=ar(attrs['NORMAL']);uv=ar(attrs['TEXCOORD_0']);positions.append(pos);assert np.isfinite(pos).all()and np.isfinite(norm).all()and np.isfinite(uv).all();assert np.allclose(np.linalg.norm(norm,axis=1),1,atol=.003)
 v=np.concatenate(positions);lo=v.min(0);hi=v.max(0);assert np.allclose(hi-lo,np.array(e['dimensions_cm'])/100,atol=1e-6);assert abs(lo[1])<1e-7 and abs(lo[0]+hi[0])<1e-6 and abs(lo[2]+hi[2])<1e-6
 for im in gd['images']:
  assert 'uri'not in im;bv=gd['bufferViews'][im['bufferView']];pic=Image.open(io.BytesIO(data[bv.get('byteOffset',0):bv.get('byteOffset',0)+bv['byteLength']]));assert pic.size==(2048,2048)
 for angle in['on','on-capraz','arka','yan']:
  pic=Image.open(Path(e['asset_dir'])/(angle+'.png'));assert pic.size==(1000,1000)
 assert e['official_size_label']in e['official_size_labels'] and e['photo_pixels_baked'] and e['estimated_reverse']in[True,False]
 assert e['source_dimensions_hwd_cm'][2]is None and e['estimated_axes']==['Z']
 checks.append(dict(id=e['id'],sku=e['sku'],sha256=e['sha256'],bytes=e['bytes'],dimensions_metres=(hi-lo).tolist(),closed_manifold_consistent_winding_positive_volume=qa['valid'],triangles=sum(m['triangles']for m in qa['meshes']),normals_unit=True,uv_finite=True,embedded_2k_images=len(gd['images']),native_render_views=4,official_size_label=e['official_size_label'],quality_status=e['quality_status'],estimated_axes=e.get('estimated_axes',[]),estimated_reverse=e['estimated_reverse']))
 print('verified',e['sku'],flush=True)
prep=json.loads((P/'preparation-manifest.json').read_text());coverage=[]
for p in prep['products']:
 e=next((e for e in a if e['sku']==p['sku']),None)
 coverage.append(dict(sku=p['sku'],title=p['title'],url=p['url'],official_size_labels=p['official_size_labels'],matched_model_ids=[e['id']]if e else p['matched_model_ids'],status='new_photo_reviewed'if e else'existing_model',glb_path=e['glb_path']if e else None))
assert len(coverage)==45 and all(p['matched_model_ids']for p in coverage)
report=dict(valid=True,new_models=43,initial_measured_skus=45,initial_verified_size_variants=45,initial_existing_models=2,all_initial_measured_skus_matched=45,live_category_cards=161,other_category_cards_pending_completion=116,per_category_cap=None,all_source_files_unchanged=True,original_source_url_records=len(masters),unique_original_files=len({r['local_master']for r in masters}),all_glb_hashes_verified=True,all_geometry_checks_passed=True,embedded_texture_resolution=[2048,2048],source_resolution_not_invented=True,normals_roughness_are_appearance_estimates=True,estimated_filling_depth_models=sum(e['sku']!='6373/009/106'for e in a),cylindrical_symmetry_derived_depth_models=1,rear_photograph_observed_models=sum(not e['estimated_reverse']for e in a),unobserved_rear_is_labeled_estimated=True,front_reference_quality_pending=[],needs_measurement=[],native_views_per_model=4,source_photo_and_texture_review='review/contact-1..5.jpg and review/texture-contact-1..5.jpg',all_model_front_oblique_side_contacts_reviewed=True,local_fur_stitch_piping_details_photo_interpreted=True,checks=checks)
write(P/'final-independent-qa.json',report);write(P/'category-coverage.json',dict(category='Kırlentler',live_category_cards=161,initial_measured_cards=45,matched_initial_measured_cards=45,new_models=43,existing_models=2,pending_other_cards=116,per_category_cap=None,products=coverage));write(P/'quality-pending.json',[])
print(json.dumps(dict(valid=True,new_models=43,initial_matched=45,max_glb_bytes=max(e['bytes']for e in a)),ensure_ascii=False))
