from pathlib import Path
import json
from PIL import Image,ImageDraw,ImageFont,ImageOps
P=Path(__file__).resolve().parent;m=json.loads((P/'preparation-manifest.json').read_text());font=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',18)
p=[p for p in m['products']if p['new_model_needed']]
for page in range(5):
 out=Image.new('RGB',(1500,1200),'#e5e5e5');d=ImageDraw.Draw(out)
 for k,pr in enumerate(p[page*9:page*9+9]):
  f=P/'products'/pr['id']/'textures/front-albedo-2k.jpg'
  if not f.exists():continue
  im=Image.open(f);im.thumbnail((450,350));x=(k%3)*500;y=(k//3)*400;out.paste(im,(x+(500-im.width)//2,y));d.text((x+10,y+360),pr['sku']+' '+pr['title'][:26],font=font,fill='#111')
 out.save(P/'review'/f'texture-contact-{page+1}.jpg',quality=90)
