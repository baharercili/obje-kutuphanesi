from pathlib import Path
import sys,json,hashlib,shutil
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parent;ROOT=P.parents[3];W=ROOT/'work/zarahome-dekor';sys.path.insert(0,str(W));from export_catalog import export_assets,read_glb,write_glb
write=lambda p,x:Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
a=json.loads((P/'manifest.json').read_text());assert len(a)==43
for e in a:
 path=Path(e['model_path']);d=json.loads(path.read_text());md=d['metadata'];w,h,z=e['dimensions_cm'];bolster=e['sku']=='6373/009/106'
 md['source_dimensions_hwd_cm']=[h,w,None]
 if bolster:
  md.update(estimated_dimensions=True,size_source_kind='official_two_axis_cylindrical_symmetry_depth',estimated_axes=['Z'],derived_round_depth_cm=z,round_depth_source='Circular cross-section inferred from photograph; official label gives only56×18cm',official_two_axis_dimensions_cm=[56,18],scale_note='Resmî etiket56×18cm. Fotoğraftaki silindir formu56cm uzunluk ve18cm çap olarak yorumlandı; Z derinliği dairesel kesit simetrisinden türetildi, ayrı resmî üçüncü ölçü yayımlanmıyor.')
  md.pop('official_length_diameter_cm',None)
 md['photo_orientation_note']='Full official gallery P1 confirms portrait presentation; the two official cover side lengths are assigned as observed width and height.'if e['sku']in['3183/008/716','6192/008/500','7315/008/051']else'Cover plane is oriented to match the inspected official product photograph; the source size label is preserved literally.'
 if not bolster:md.update(official_cover_dimensions_cm=[h,w],estimated_axes=['Z'],estimated_filling_depth_cm=z)
 d['metadata']=md;write(path,d);export_assets(path,Path(e['asset_dir']),e['id']);glb=Path(e['glb_path']);gd,data=read_glb(glb)
 for m in gd['materials']:
  sheen=d['materials'][m['name']].get('extras',{}).get('physical_sheen')
  if sheen:m.setdefault('extensions',{})['KHR_materials_sheen']=sheen
 gd['extensionsUsed']=sorted(set(gd.get('extensionsUsed',[]))|{'KHR_materials_sheen'});write_glb(glb,gd,data)
 e.update({k:v for k,v in md.items()if k!='official_materials_verbatim'});e.update(sha256=sha(glb),bytes=glb.stat().st_size)
 vp=Path(e['asset_dir'])/(e['id']+'.validation.json');v=json.loads(vp.read_text());v['deliverable_sha256']['glb']=e['sha256'];v['glb_bytes']=e['bytes'];write(vp,v)
 print('metadata',e['sku'],flush=True)
write(P/'manifest.json',a);write(P/'final-manifest.json',a)
# Keep obsolete generated preview orientations outside the deliverable models.
active={Path(e['asset_dir']).name for e in a};old=P/'superseded-review';old.mkdir(exist_ok=True)
for folder in (P/'models').iterdir():
 if folder.is_dir()and folder.name not in active:
  dest=old/folder.name
  if not dest.exists():shutil.move(str(folder),str(dest))
write(P/'needs_measurement.json',[])
print('final',len(a),flush=True)
