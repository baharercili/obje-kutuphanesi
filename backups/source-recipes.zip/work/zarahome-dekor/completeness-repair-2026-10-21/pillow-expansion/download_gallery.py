from pathlib import Path
import json,re,hashlib,urllib.request,concurrent.futures
P=Path(__file__).resolve().parent;wanted=['3183/008/716','7316/008/051','7313/008/037','7341/008/701','7345/008/605','6192/008/500','7315/008/051','7318/008/711'];records=json.loads((P.parent/'live-product-details-from-root.json').read_text());todo=[]
for sku in wanted:
    r=next(r for r in reversed(records)if (r.get('sku')==sku or sku in r.get('text','')) and r.get('gallery_images'))
    for im in r['gallery_images']:
        u=im['url']
        if 'w=1024'not in u:continue
        file=u.split('?')[0].split('/')[-1];p=P/'products'/sku.replace('/','-')/'originals'/('gallery-'+hashlib.sha256(u.encode()).hexdigest()[:8]+'-'+file)
        todo.append(dict(sku=sku,product_id=sku.replace('/','-'),url=u,alt=im.get('alt',''),role='official_zoom_gallery',source_file=str(P.parent/'live-product-details-from-root.json'),local_master=str(p)))
def fetch(r):
 p=Path(r['local_master'])
 if not p.exists():
  req=urllib.request.Request(r['url'],headers={'User-Agent':'Mozilla/5.0'});p.write_bytes(urllib.request.urlopen(req,timeout=25).read())
 r.update(sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=p.stat().st_size,status='downloaded_immutable_original');return r
out=[]
with concurrent.futures.ThreadPoolExecutor(max_workers=5)as ex:
 for i,r in enumerate(ex.map(fetch,todo)):
  out.append(r);print(i+1,'/',len(todo),r['sku'],flush=True)
(P/'gallery-download-results.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
