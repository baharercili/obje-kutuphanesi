def apply_axis_provenance(e):
 axis_notes={
  '1373/047/658':'Resmî tabloda Y20 × G14 × D9 cm yazıyor. Fotoğraftaki yatay montajı izlemek için model G20 × Y14 × D9 cm yönlendirildi; bu eksen yorumu üretici çizimiyle doğrulanmadı.',
  '1664/047/250':'Resmî tabloda Y14,5 × G14,5 × D26,5 cm yazıyor. Fotoğraftaki dik kullanım için model G14,5 × Y26,5 × D14,5 cm yönlendirildi; bu eksen yorumu üretici çizimiyle doğrulanmadı.',
  '2239/047/727':'Resmî tabloda Y9,3 × G20 × D20 cm yazıyor. Fotoğraftaki duvar montajı için model G20 × Y20 × D9,3 cm yönlendirildi; bu eksen yorumu üretici çizimiyle doğrulanmadı.',
  '2241/047/727':'Resmî tabloda Y20 × G20 × D10 cm yazıyor. Fotoğraftaki tavan montajı için model G20 × Y10 × D20 cm yönlendirildi; bu eksen yorumu üretici çizimiyle doğrulanmadı.'}
 if e['sku']in axis_notes:
  e.update(quality_note=axis_notes[e['sku']],quality_label='Eksen yorumu',quality_status='axis_interpretation',axis_ambiguity=True,estimated_dimensions=True,size_source_kind='official_dimensions_photo_oriented_axes',scale_note=axis_notes[e['sku']],source_anomalies=[axis_notes[e['sku']]])
 if e['sku']=='1323/047/581':
  note='Resmî ham tablo Y159,6 × G20 × D159,6 cm gösteriyor. Fotoğrafla çelişen derinlik teyit edilemedi. Modelin 20 cm derinliği geçici kare taban yorumudur; resmî derinlik olarak kullanılmamalıdır.'
  e.update(quality_note=note,quality_label='Derinlik teyit bekliyor',quality_status='dimension_pending',estimated_axes=['Z'],estimated_dimensions=True,size_source_kind='official_height_width_estimated_depth',scale_note=note,source_anomalies=[note])
 return e
