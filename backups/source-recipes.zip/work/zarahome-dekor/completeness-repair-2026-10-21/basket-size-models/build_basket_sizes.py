from pathlib import Path
import sys,json,math,hashlib,shutil
import numpy as np
from PIL import Image
R=Path(__file__).resolve().parent;WORK=R.parents[1];sys.path.insert(0,str(WORK));sys.path.insert(0,str(R));sys.path.insert(0,str(R.parent/'mirror-models'))
from export_catalog import export_assets,read_glb,write_glb
from vase_geometry import _finalize
import size_geometry as S
import build_mirrors as M
AQ=M.AQ

def dump(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
BUILD={'3346/049/052':S.square_lid,'3563/049/700':S.pe_wavy,'4542/049/052':S.covered_round,'4541/049/999':S.contrast,'2325/049/700':S.rattan,'8340/049/052':S.seagrass}
NOMINAL={'3346/049/052':dict(main_fibre_diameter_mm=3.88,face_course_pitch_mm=3.95,lid_band_height_mm=18),'3563/049/700':dict(pe_lath_cross_section_mm=[2.2,3.6],frame_vertical_pitch_mm=31.7,rim_diameter_mm=6.8),'4542/049/052':dict(body_bundle_cross_section_mm=[13.6,12.24],body_course_pitch_mm=14,white_binding_cross_section_mm=[1.56,1.08]),'4541/049/999':dict(main_bundle_diameter_mm=10.8,course_pitch_mm=11.9,white_binding_diameter_mm=1.44),'2325/049/700':dict(wall_reed_diameter_mm=7,wall_course_pitch_mm=13.3,braid_member_diameter_mm=10.8),'8340/049/052':dict(coil_cross_section_mm=[5.6,5.1],course_pitch_mm=4.15,tie_diameter_mm=.86)}

def round_finish(parts,w,h,d,features):
 count=len(parts);groups=S.Round.merge(parts);allp=np.concatenate([np.asarray(p['_vertices'])for p in groups]);lo=allp.min(0);hi=allp.max(0);target=np.array([w,h,d]);scale=target/(hi-lo);center=np.array([(lo[0]+hi[0])/2,lo[1],(lo[2]+hi[2])/2]);meshes=[];checks=[]
 for raw in groups:
  raw['_vertices']=[tuple((np.asarray(v)-center)*scale)for v in raw['_vertices']];mesh,check=_finalize(raw);meshes.append(mesh);checks.append(check)
 qa=dict(valid=True,units='metres',up_axis='Y',origin='bottom bounding-box centre',dimensions_metres=target.tolist(),affine_fit_scale=scale.tolist(),mesh_count=len(meshes),triangles=sum(q['triangles']for q in checks),meshes=checks,photographed_features=features['features'],material_identity=features['material_identity'],closed_strand_solids=count,all_visible_members_closed_solids=True,has_real_open_weave=True,local_geometry_photo_inferred=True,construction='Every manufactured fibre is a closed solid. Deliberately overlapping strands and stitches form the real woven hollow vessel; no backing cylinder or painted holes.')
 return meshes,qa

def main():
 variants=json.loads((R/'source-variants-frozen.json').read_text());evidence=json.loads((R/'official-size-evidence-frozen.json').read_text());old=json.loads((R/'original-masters-sha256.json').read_text());masters={e['sku']:e for e in old['masters']};baseline=json.loads((R.parent/'baseline-409.json').read_text())['catalog'];old_ids={p['id']for p in baseline};only=sys.argv[1]if len(sys.argv)>1 else None;manifest=[e for e in json.loads((R/'manifest.json').read_text())if e['id']!=only]if only else []
 for p in variants:
  v=p['source_size'];h,w,d=[v[k]for k in ['height_cm','width_cm','depth_cm']];fmt=lambda x:format(x,'g').replace('.','p');id=p['sku'].replace('/','-')+'-h'+fmt(h)+'-w'+fmt(w)+'-d'+fmt(d);assert id not in old_ids
  if only and id!=only:continue
  out=R/'models'/id;out.mkdir(parents=True,exist_ok=True);master=masters[p['sku']];mp=Path(master['model_path']);source=json.loads(mp.read_text());dims=[w/100,h/100,d/100];print('building',id,flush=True)
  result=BUILD[p['sku']](*dims)
  if p['sku']in['3346/049/052','4541/049/999','2325/049/700']:meshes,gqa=result
  else:meshes,gqa=round_finish(result[0],*dims,result[1])
  gqa.update(nominal_weave_parameters=NOMINAL[p['sku']],weave_parameters_note='Local fibre cross-sections and physical pitch are retained from the inspected original master construction; course/stake counts are regenerated for the size. These are photo interpretations, not officially measured strand dimensions.',size_specific_regeneration=True,uv_side_triangles_repaired=M.ensure_uv_faces(meshes),all_faces_have_finite_nonzero_uv_area=True)
  # Only a small final fit closes the measured outer envelope; no master mesh is globally resized.
  assert max(gqa['affine_fit_scale'])/min(gqa['affine_fit_scale'])<1.10,(id,gqa['affine_fit_scale'])
  mats={k:dict(source['materials'][k])for k in sorted({m['material']for m in meshes})};maps=[]
  for mat in mats.values():
   for field in ['baseColorTexture','normalTexture','metallicRoughnessTexture']:
    src=mp.parent/mat[field];dest=out/src.name;shutil.copyfile(src,dest);assert Image.open(dest).size==(2048,2048);maps.append(dict(name=dest.name,sha256=sha(dest),resolution=[2048,2048],copied_from=str(src),source_sha256=sha(src)))
  proof=next(e for e in evidence if e['sku']==p['sku']);index=next(i for i,vv in enumerate(proof['dimensions'])if tuple(vv[k]for k in ['height_cm','width_cm','depth_cm'])==(h,w,d));original_pointer=proof['source_pointer']+'/dimensions/'+str(index);pointer='/'+str(next(i for i,q in enumerate(evidence)if q['sku']==p['sku']))+'/dimensions/'+str(index)
  metadata=dict(id=id,name=M.title(p['title']),sku=p['sku'],url=p['url'],category='Dekoratif sepetler',dimensions_cm=[w,h,d],source_dimensions_hwd_cm=[h,w,d],estimated_dimensions=False,source_market='Türkiye',size_source_kind='official_tr_verified_variant',size_source_urls=[p['url']],scale_note='Resmî Türkiye dış ölçüleri kullanıldı. Aynı ürün ailesinin örgü yapısı bu bedene yeniden kuruldu; lif kesitleri ve doku tekrar ölçeği korunurken sıra/dikme sayıları boyuta göre uyarlandı. Lif kalınlıkları ve yerel detaylar fotoğraf yorumudur.',units='metres',up_axis='Y',origin='bottom bounding-box centre',source_images=p['images'],official_materials_verbatim=p['material'],photo_pixels_baked=False,baked_reflections=False,product_photo_code=p['image_code'],source_card_url=p['url'],source_category_url=proof['source_url'],source_evidence_files=p['source_files'],source_size_evidence=dict(file=str(R/'official-size-evidence-frozen.json'),original_file=proof['source_file'],pointer=pointer,original_pointer=original_pointer,exact_triplet_hwd_cm=[h,w,d],source_url=proof['url']),size_variant_of=master['id'],master_reference=dict(model_path=str(mp),model_sha256=sha(mp),glb_path=master['glb_path'],glb_sha256=sha(master['glb_path'])),nominal_weave_parameters=NOMINAL[p['sku']],variant_status='listed_in_official_size_evidence')
  model=out/'model.json';dump(model,dict(metadata=metadata,materials=mats,meshes=meshes));dump(out/'geometry-validation.json',gqa);dump(out/'material-validation.json',dict(valid=True,native_resolution=2048,intrinsic_material=True,photo_pixels_baked=False,baked_reflections=False,physical_uv_repeat_preserved=True,maps=maps))
  report=export_assets(model,out,id);glb=out/(id+'.glb');doc,binary=read_glb(glb);doc['samplers']=[dict(magFilter=9729,minFilter=9987,wrapS=10497,wrapT=10497)]
  for t in doc.get('textures',[]):t['sampler']=0
  binary=M.embed_tangents(doc,binary);write_glb(glb,doc,binary);report['deliverable_sha256']['glb']=sha(glb);report['glb_bytes']=glb.stat().st_size;dump(report['files']['validation'],report)
  e={k:metadata[k]for k in ['id','name','sku','url','category','dimensions_cm','source_dimensions_hwd_cm','estimated_dimensions','source_market','size_source_kind','size_source_urls','scale_note','variant_status','size_variant_of','source_size_evidence']};e.update(model_path=str(model),asset_dir=str(out),glb_path=str(glb),sha256=sha(glb),bytes=glb.stat().st_size,material_label=p['material'],source_images=p['images'],geometry_validation=str(out/'geometry-validation.json'),material_validation=str(out/'material-validation.json'),model_revision='completeness-basket-size-photo-specific-v1',source_anomalies=p['source_anomalies']);dump(out/'topology-validation.json',AQ.check(e));manifest.append(e);dump(R/'manifest.json',manifest);print('ready',id,e['bytes'],gqa['triangles'],flush=True)
 for p in old['files']:assert sha(p['path'])==p['sha256']
 dump(R/'pending.json',[]);dump(R/'qa-summary.json',dict(valid=True,models=len(manifest),existing_families_with_added_sizes=len({p['sku']for p in variants}),existing_master_families=8,original_eight_masters_unchanged=True,all_known_eleven_size_variants_built=len(manifest)==11,new_26_unmodeled_basket_families_completed=False,all_maps_2k_embedded=True,photo_pixels_baked=False,baked_reflections=False));print('COMPLETE',len(manifest),flush=True)
if __name__=='__main__':main()
