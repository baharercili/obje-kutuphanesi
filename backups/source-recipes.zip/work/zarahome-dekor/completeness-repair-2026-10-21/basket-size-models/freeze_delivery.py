from pathlib import Path
import json,hashlib
from PIL import Image
R=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
a=json.loads((R/'manifest.json').read_text());qa=json.loads((R/'independent-validation.json').read_text());weave=json.loads((R/'weave-thickness-validation.json').read_text());assert len(a)==11 and len({e['sku']for e in a})==6 and qa['valid'] and weave['valid'] and not json.loads((R/'pending.json').read_text())
files=[];renders=[]
for e in a:
 assert sha(e['glb_path'])==e['sha256'];top=json.loads((Path(e['asset_dir'])/'topology-validation.json').read_text());assert top['valid']and top['sha256']==e['sha256']
 d=Path(e['asset_dir'])
 for v in ['on','on-capraz','ustten']:
  p=d/(v+'.png');im=Image.open(p);alpha=im.getchannel('A').getextrema();assert im.size==(900,900)and alpha[0]==0 and alpha[1]>=250;renders.append(dict(id=e['id'],view=v,path=str(p),pixels=[900,900],transparent_background=True))
 for p in [Path(e['glb_path']),Path(e['model_path']),d/(e['id']+'.scn'),d/'geometry-validation.json',d/'material-validation.json',d/'topology-validation.json']+[d/(v+'.png')for v in ['on','on-capraz','ustten']]:files.append(dict(path=str(p),sha256=sha(p),bytes=p.stat().st_size))
old=json.loads((R/'original-masters-sha256.json').read_text());assert len(old['masters'])==8
for f in old['files']:assert sha(f['path'])==f['sha256']
for f in json.loads((R/'reference-masters.json').read_text()):assert sha(f['local_master'])==f['sha256']
for folder in ['mirror-models','box-models']:
 frozen=json.loads((R.parent/folder/'frozen-delivery.json').read_text())
 for p in frozen['deliverables']:assert sha(p['path'])==p['sha256']
baseline=json.loads((R.parent/'baseline-409.json').read_text())['catalog'];assert not {e['id']for e in a}&{e['id']for e in baseline}
visual=dict(valid=True,models=11,views=33,all_six_family_official_photos_inspected=True,inspection='All eleven front/oblique views were compared to the official family references; square mitred weave, dark lid piping, wavy open PE laths, coil bindings, heavy rattan braid, belly-basket proportions, handles and tall conical-lid/knob construction were checked. Physical strand sections remain constant while course/stake counts change.',renders=renders)
(R/'visual-validation.json').write_text(json.dumps(visual,ensure_ascii=False,indent=2)+'\n')
frozen=dict(status='frozen',date='2026-10-21',scope='eleven_verified_missing_sizes_of_existing_eight_basket_masters',models=11,existing_families_with_new_sizes=6,existing_master_families=8,pending_verified_variants=0,new_26_basket_families_completed=False,manifest=str(R/'manifest.json'),independent_qa=str(R/'independent-validation.json'),weave_thickness_qa=str(R/'weave-thickness-validation.json'),visual_qa=str(R/'visual-validation.json'),original_eight_masters_unchanged=True,source_photographs_unchanged=True,previous_mirror_and_box_deliveries_unchanged=True,all_official_size_json_pointers_valid=True,baseline_409_id_collisions=[],deliverables=files)
(R/'frozen-delivery.json').write_text(json.dumps(frozen,ensure_ascii=False,indent=2)+'\n');print('FROZEN:11 verified basket size variants;33 PNG;11 SCN;8 original masters and previous mirror/box freezes unchanged. New26 families outside scope.')
