"""All measured diffuser SKUs; photo-classified silhouettes and physical components.
Original photography is reference-only. No photographed pixels/reflections baked.
"""
from pathlib import Path
import sys,json,math,hashlib,shutil,io,re
sys.dont_write_bytecode=True
import numpy as np
from PIL import Image,ImageDraw,ImageFont,ImageFilter
R=Path(__file__).resolve().parent;STUDIO=R.parents[4];W=STUDIO/'work/zarahome-dekor'
sys.path[:0]=[str(W/'ten-more-2026-10-21/accessories'),str(W)]
import base_geometry as base
from build_accessories import B,smooth_profile
from vase_geometry import _finalize,_signed_volume,_profile_sampler
from export_catalog import export_assets,read_glb,write_glb
base.R=R;T=math.tau
def dump(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
PLAN=json.loads((R/'measured-plan.json').read_text());ROWS=json.loads((R/'raw/category-snapshot.json').read_text())['products']
FONT='/System/Library/Fonts/Supplemental/Times New Roman.ttf';BOLD='/System/Library/Fonts/Supplemental/Times New Roman Bold.ttf';ITALIC='/System/Library/Fonts/Supplemental/Apple Chancery.ttf'
COLOURS={
 'winter':([8,35,24],'glass'),'salted':([101,46,11],'glass'),'ginger':([96,13,28],'glass'),'smoke':([76,65,48],'glass'),
 'amber':([154,105,34],'glass'),'olive':([57,58,29],'glass'),'gray':([56,57,53],'glass'),'brown':([82,52,31],'glass'),'blackglass':([24,30,32],'glass'),
 'frost_green':([120,158,61],'frost'),'frost_blue':([76,91,106],'frost'),'frost_yellow':([223,206,123],'frost'),'frost_beige':([193,162,116],'frost'),'frost_pink':([161,101,91],'frost'),
 'bubbly_green':([18,111,29],'bubbly'),'bubbly_lime':([155,164,22],'bubbly'),'bubbly_olive':([137,139,19],'bubbly'),'bubbly_cream':([213,205,144],'bubbly'),'bubbly_gold':([206,153,47],'bubbly'),
 'clear':([239,241,228],'glass'),'pale_gold':([219,204,144],'glass'),'pale_green':([186,196,141],'glass'),'pale_blue':([175,189,182],'glass'),'pale_rose':([218,186,176],'glass'),'pale_cream':([235,224,183],'glass'),
 'pumpkin':([123,59,17],'glass'),'burgundy':([89,38,34],'glass'),'sage':([143,164,111],'frost'),'opal':([231,229,210],'frost'),
 'cap_black':([20,20,18],'plastic'),'cap_ivory':([233,229,211],'glaze'),'cap_white':([235,236,228],'glaze'),'cap_stone':([215,200,169],'stone'),
 'wood_light':([183,143,85],'wood'),'wood_olive':([159,159,124],'wood'),'wood_gray':([160,163,150],'wood'),'wood_gold':([184,151,79],'wood'),'wood_blue':([90,117,123],'wood'),'wood_white':([220,216,194],'wood'),'wood_ball':([91,51,27],'wood'),
 'reed_black':([18,18,16],'fiber'),'reed_natural':([189,149,86],'fiber'),'reed_brown':([86,47,30],'fiber'),'thread_olive':([91,87,47],'fiber'),'thread_blue':([37,55,71],'fiber'),'thread_red':([90,36,40],'fiber'),'thread_brown':([128,80,43],'fiber'),'brass_tag':([154,123,59],'metal')}
def cfg(p):
 i=p['category_card_indices'][0];w,h,d=p['dimensions_cm'];name=p['name'];c=dict(index=i,shape='apothecary',glass='amber',cap='cap_black',pose='closed_stowed',reed='reed_black',reed_count=6,label='small_gold',body_aspect=1.65,section='round',flutes=0,tassel=None)
 if i<=2:c.update(shape='winter',glass='winter',pose='installed',label='emboss_vertical',body_aspect=2.15,section='octagon',reed_count=5)
 elif i<=5:c.update(shape='salted',glass='salted',label='emboss_salted',body_aspect=1.4,reed_count=5)
 elif i<=8:c.update(shape='ginger',glass='ginger',label='emboss_badge',body_aspect=1.95,reed_count=6)
 elif i<=13:c.update(shape='travel',glass='smoke',reed='reed_natural',body_aspect=1.65,reed_count=5)
 elif i<=17:c.update(glass='amber',body_aspect={14:2.25,15:1.55,16:1.75,17:2.15}[i],pose='closed_stowed'if i==15 else'installed')
 elif i<=27:c.update(glass=('frost_green'if i in[18,19]else'frost_blue'if i in[20,21]else'frost_yellow'if i in[22,23]else'frost_beige'if i in[24,25]else'frost_pink'),body_aspect=1.5 if i%2==0 else 1.65,label='none',reed_count=6)
 elif i<=39:c.update(glass='olive'if i<=30 else'gray'if i<=33 else'brown'if i<=36 else'blackglass',body_aspect=1.5 if i in[28,33,34,37]else 1.8 if i in[29,32,35,38]else 2.1,pose='closed_stowed'if i in[28,33,34,37]else'installed')
 elif i<=43:c.update(shape='gourmand',glass='clear',cap='wood_light',label='paper_gourmand',body_aspect=1.65,reed='reed_natural',reed_count=4)
 elif i<=53:c.update(shape='bubbly',glass='bubbly_green'if i==44 else'bubbly_lime'if i in[45,48]else'bubbly_olive'if i in[46,47]else'bubbly_gold'if i in[52,53]else'bubbly_cream',pose='installed',label='none',body_aspect=1.45,reed='reed_natural',reed_count=5)
 elif i<=56:c.update(glass='clear',pose='installed',body_aspect=1.60,reed_count=6)
 elif i<=68:c.update(shape='ball_arch',glass='burgundy'if i in[58,60,64,66]else'amber'if i in[59,65,67]else'olive'if i in[62,63]else'smoke',cap='wood_ball',section='rounded_rect',body_aspect=1.75,reed='reed_natural',reed_count=5)
 elif i<=79:c.update(shape='wood_collar',glass='pale_green'if i in[70,71]else'pale_blue'if i in[72,73,76,77]else'pale_gold'if i in[74,75]else'pale_cream',cap='wood_olive'if i in[70,71]else'wood_gray'if i in[72,73]else'wood_gold'if i in[74,75]else'wood_blue'if i in[76,77]else'wood_white',pose='installed',label='none',reed='reed_natural',reed_count=5,body_aspect=2.20 if i in[70,72,74,76,78]else 2.15)
 elif i<=83:c.update(shape='porcelain_collar',glass='pale_rose'if i==81 else'pale_blue'if i==83 else'pale_cream',cap='cap_ivory',pose='installed',label='none',reed='reed_natural',reed_count=5,body_aspect=1.65 if i==81 else 1.85)
 elif i<=87:c.update(shape='stone_collar',glass='brown'if i in[84,86]else'pale_gold',cap='cap_stone',pose='closed_stowed',body_aspect=1.95,reed='reed_natural',reed_count=6)
 elif i<=89:c.update(shape='pumpkin',glass='pumpkin',pose='installed',label='none',body_aspect=1.42,flutes=24,reed='reed_brown',reed_count=6)
 elif i<=92:c.update(glass='amber',body_aspect={90:1.55,91:1.75,92:2.15}[i],pose='closed_stowed'if i==90 else'installed')
 elif i<=107:c.update(shape='label_cylinder',glass='clear',label='paper_classic',body_aspect=1.65 if i in[93,96,99,103,104,106]else 1.75,reed='reed_natural',reed_count=7,pose='closed_stowed'if i in[93,96,99,103,104,106]else'installed')
 elif i<=115:c.update(shape='tassel_arch',glass='olive'if i in[108,109]else'gray'if i in[110,111]else'burgundy'if i in[112,113]else'amber',cap='wood_ball',section='rounded_rect',body_aspect=1.85 if i%2==0 else 2.0,reed='reed_brown',reed_count=8,flutes=32,tassel='thread_olive'if i in[108,109]else'thread_blue'if i in[110,111]else'thread_red'if i in[112,113]else'thread_brown')
 elif i<=120:c.update(shape='signature',glass='olive'if i in[116,117]else'brown',pose='installed'if i==118 else'closed_stowed',label='signature',body_aspect=2.6 if i in[116,118,120]else 1.95,reed_count=9 if i==118 else 6)
 elif i==121:c.update(shape='sunshine',glass='sage',pose='installed',label='small_black',body_aspect=1.95,reed='reed_natural',reed_count=5)
 elif i==122:c.update(shape='white_powdery',glass='opal',cap='cap_white',pose='closed_stowed',label='small_black',body_aspect=1.40,reed='reed_natural',reed_count=5)
 if i==68:c['glass']='gray'
 c['fragrance']=re.sub(r'^\([^)]*\)\s*','',name).replace('MİKADO','').replace('MIKADO','').replace('ODA KOKUSU','').replace('DİFÜZÖR','').strip()
 return c

def bank():
 out=R/'material-bank';out.mkdir(exist_ok=True);n=2048;u=np.arange(n,dtype=np.float32)[None,:]/n;v=np.arange(n,dtype=np.float32)[:,None]/n;rng=np.random.default_rng(197);small=Image.fromarray(rng.integers(0,256,(48,48),dtype=np.uint8),'L').resize((n,n),Image.Resampling.BICUBIC);cloud=(np.asarray(small,np.float32)-127)/127;fine=rng.normal(0,1,(n,n)).astype(np.float32);mats={}
 coherent_ready=(out/'coherent-v2.json').exists()
 for kind in sorted({k for rgb,k in COLOURS.values()}):
  if coherent_ready and all((out/(kind+'-'+slot+'-2k.png')).exists()for slot in['normal','orm']):continue
  rough={'glass':.10,'frost':.37,'bubbly':.22,'plastic':.43,'glaze':.22,'stone':.66,'wood':.43,'fiber':.76,'metal':.32}[kind];height=np.zeros((n,n),np.float32);rr=rough+cloud*.004
  if kind in['wood','fiber']:height=np.sin(T*(v*210+cloud*.035))*.12+cloud*.004;rr+=np.sin(T*v*210+cloud)*.025
  elif kind=='bubbly':height=base.noise._object_noise(np.broadcast_to(u,(n,n)),np.broadcast_to(v,(n,n)),431,132)*.8;rr+=height*.015
  elif kind=='stone':height=cloud*.09-np.maximum(0,fine-1.5)*.24;rr+=np.maximum(0,fine-1.5)*.02
  dx=np.gradient(height,axis=1)*2;dy=np.gradient(height,axis=0)*2;nn=np.stack([-dx,-dy,np.ones_like(dx)],2);nn/=np.linalg.norm(nn,axis=2,keepdims=True);orm=np.zeros((n,n,3),np.uint8);orm[:,:,0]=255;orm[:,:,1]=np.rint(np.clip(rr,.02,.98)*255).astype('uint8');orm[:,:,2]=255 if kind=='metal'else 0
  for slot,px in[('normal',np.rint((nn+1)*127.5).astype('uint8')),('orm',orm)]:path=out/(kind+'-'+slot+'-2k.png');Image.fromarray(px,'RGB').save(path,optimize=True)
 for key,(rgb,kind)in COLOURS.items():
  tone=cloud*(1.5 if kind in['wood','stone','fiber']else.25)+fine*(.35 if kind in['wood','stone','fiber']else.04)
  if kind in['wood','fiber']:tone+=np.sin(T*(v*210+cloud*.035))*3.5
  if kind=='stone':tone-=np.maximum(0,fine-1.5)*10
  albedo=np.clip(np.array(rgb)+tone[:,:,None],0,255).astype('uint8');af=key+'-albedo-2k.png'
  if not(out/af).exists():Image.fromarray(albedo,'RGB').save(out/af,optimize=True)
  m=dict(baseColorFactor=[1,1,1,1],baseColorTexture=af,normalTexture=kind+'-normal-2k.png',metallicRoughnessTexture=kind+'-orm-2k.png',metallic=0,roughness=1,normalScale=.42 if kind in['wood','bubbly','stone']else.07,clearcoat=.5 if kind in['glass','bubbly','glaze']else.04,clearcoatRoughness=.1 if kind in['glass','bubbly']else.3,doubleSided=False,alphaMode='OPAQUE',extras=dict(native_map_resolution=2048,intrinsic_material_maps=True,photo_pixels_baked=False,baked_reflections=False))
  if kind in['glass','frost','bubbly']:m.update(transmission=.05 if key=='opal'else.85 if kind=='glass'else.38 if kind=='frost'else.72,ior=1.52,thickness=.0025,attenuationColor=[max(.03,c/255)for c in rgb],attenuationDistance=.055 if key not in['clear','pale_gold','pale_green','pale_blue','pale_rose','pale_cream']else.45)
  if kind=='metal':m.update(metallic=1,clearcoat=0)
  mats[key]=m
 dump(out/'coherent-v2.json',dict(native_resolution=2048,smooth_glass_normal_is_physically_flat=True,wood_and_reed_have_directional_grain=True,original_reference_pixels_used=False))
 return out,mats
def text_mask(lines,fontsizes,positions,font=BOLD):
 im=Image.new('L',(2048,2048),0);dr=ImageDraw.Draw(im)
 for line,size,(x,y)in zip(lines,fontsizes,positions):
  fnt=ImageFont.truetype(font,size)
  while dr.textbbox((0,0),line,font=fnt)[2]>1760:size-=4;fnt=ImageFont.truetype(font,max(24,size))
  dr.text((x,y),line,font=fnt,fill=255,anchor='mm')
 return im
def product_materials(p,c,bank,spec,bh):
 mats={k:dict(v)for k,v in spec.items()};glasskey='glass_'+p['id'];m=dict(spec[c['glass']]);label=None;style=c['label'];name=c['fragrance'];rgb=COLOURS[c['glass']][0]
 if style=='none':return mats,c['glass'],None
 if style.startswith('paper'):
  label='label_'+p['id'];back=(225,217,191)if style=='paper_gourmand'else((207,205,166)if 'POETIC'in name else(212,219,208)if'LIGHT COTTON'in name else(216,204,180)if'DARK AMBER'in name else(234,227,203));im=Image.new('RGB',(2048,2048),back);dr=ImageDraw.Draw(im);pretty=name.title();words=pretty.split();lines=[pretty]if len(pretty)<23 else[' '.join(words[:len(words)//2]),' '.join(words[len(words)//2:])]
  for j,line in enumerate(lines):dr.text((1024,640+j*180),line,font=ImageFont.truetype(BOLD,104),anchor='mm',fill=(35,35,27))
  if style=='paper_gourmand':
   badge={40:(139,89,47),41:(78,105,141),42:(205,137,33),43:(205,183,62)}[c['index']];dr.rectangle((0,250,2048,1000),fill=back);dr.ellipse((665,305,1383,1005),fill=badge);words=name.replace('&','').split();dr.text((1024,640),words[0],font=ImageFont.truetype(BOLD,98),anchor='mm',fill=(242,236,214))
   if len(words)>1:dr.text((1024,800),' '.join(words[1:]),font=ImageFont.truetype(FONT,45),anchor='mm',fill=(241,234,211))
  dr.text((1024,1020),'Home Fragrance',font=ImageFont.truetype(FONT,84),anchor='mm',fill=(40,39,31));dr.text((1024,1740),'ZARA HOME',font=ImageFont.truetype(FONT,100),anchor='mm',fill=(156,132,74));af=label+'-albedo-2k.png';im.save(bank/af,optimize=True);mats[label]=dict(spec['cap_ivory'],baseColorTexture=af,normalTexture='plastic-normal-2k.png',metallicRoughnessTexture='stone-orm-2k.png',clearcoat=0,normalScale=.02)
  return mats,c['glass'],label
 if style=='emboss_vertical':mask=text_mask(['Winter Cypress'],[235],[(1024,1024)],ITALIC);small=mask.crop((0,750,2048,1300)).rotate(90,expand=True);mask=Image.new('L',(2048,2048));small=small.resize((340,1580),Image.Resampling.LANCZOS);mask.paste(small,(854,160))
 elif style=='emboss_salted':mask=text_mask(['SALTED','CARAMEL','ZARA HOME'],[220,200,100],[(1024,650),(1024,1050),(1024,1500)])
 elif style=='emboss_badge':
  mask=text_mask(['GINGER','BREAD','ZARA HOME'],[240,240,110],[(1024,730),(1024,1090),(1024,1470)]);dr=ImageDraw.Draw(mask);dr.ellipse((140,180,1908,1880),outline=230,width=16);dr.ellipse((185,230,1863,1830),outline=210,width=8)
 elif style=='signature':mask=text_mask(['Signature','Collection '+('II'if'II'in name and'XXL'not in name else'I'),'ZARA HOME','Home Fragrance'],[170,120,90,70],[(1024,610),(1024,820),(1024,1570),(1024,1730)],ITALIC)
 else:
  words=name.split();lines=[' '.join(words[:len(words)//2]),' '.join(words[len(words)//2:])]if len(name)>18 else[name];mask=text_mask(lines,[130]*len(lines),[(1024,1000+j*190)for j in range(len(lines))])
 # Complete bottle angular map, front centreU.5, uprightV=1-y/body-height.
 full=Image.new('L',(2048,2048));mw=.30 if style.startswith('emboss')else.23;mh=.47 if style.startswith('emboss')else.22;patch=mask.resize((int(2048*mw),int(2048*mh)),Image.Resampling.LANCZOS);cy=.35 if style.startswith('emboss')else.18 if style.startswith('small')else.45;full.paste(patch,(1024-patch.width//2,int((1-cy)*2048)-patch.height//2));arr=np.asarray(full.filter(ImageFilter.GaussianBlur(.65)),np.float32)/255;al=np.array(Image.open(bank/spec[c['glass']]['baseColorTexture'])).copy()
 if not style.startswith('emboss'):
  tint=np.array([30,33,27]if style=='small_black'else[210,190,134]);al=np.rint(al*(1-arr[:,:,None])+tint*arr[:,:,None]).astype('uint8')
 nm=glasskey+'-normal-2k.png';af=glasskey+'-albedo-2k.png';dx=np.gradient(arr,axis=1)*26;dy=np.gradient(arr,axis=0)*26;nn=np.stack([-dx,-dy,np.ones_like(dx)],2);nn/=np.linalg.norm(nn,axis=2,keepdims=True);Image.fromarray(np.rint((nn+1)*127.5).astype('uint8'),'RGB').save(bank/nm,optimize=True);Image.fromarray(al,'RGB').save(bank/af,optimize=True);m.update(baseColorTexture=af,normalTexture=nm,normalScale=.8 if style.startswith('emboss')else.13);mats[glasskey]=m;return mats,glasskey,None

def contour(rx,rz,n=144,section='round',flutes=0,amp=0):
 if section=='octagon':return[(x*rx,z*rz)for x,z in[(-.68,-1),(.68,-1),(1,-.68),(1,.68),(.68,1),(-.68,1),(-1,.68),(-1,-.68)]]
 out=[]
 for a in np.linspace(0,T,n,endpoint=False):
  x,z=math.cos(a),math.sin(a)
  if section=='rounded_rect':x=math.copysign(abs(x)**.57,x);z=math.copysign(abs(z)**.57,z)
  k=1+amp*math.cos(flutes*a)if flutes else 1;out.append((rx*x*k,rz*z*k))
 return out
def shell(b,name,mat,profile,rx,rz,section='round',flutes=0,amp=.035):
 rings=[];bh=max(y for y,k in profile);n=192 if flutes else 144
 for y,k in profile:
  strength=amp*(min(1,y/(bh*.07))*min(1,(bh-y)/(bh*.10)))if flutes else 0
  if flutes and name.startswith('tassel'):strength*=max(0,min(1,(.40-y/bh)/.07))
  zrad=rz*k
  if section=='rounded_rect'and'hollow-glass-body'in name:zrad+=(rx-rz)*k*max(0,min(1,(y/bh-.86)/.06))
  rings.append((y,contour(rx*k,zrad,n,section,flutes,strength)))
 b.solid(name,mat,rings);g=b.raw[-1];g['_uv_mode']='bottle';g['_uvs']=[((.5+math.atan2(x,z)/T)%1,1-y/bh)for x,y,z in g['_vertices']];g['_flat_normals']=section=='octagon'
def annulus(b,name,mat,profile,ellipse=1.,offset=(0,0,0),n=144):
 verts=[];faces=[]
 for y,r in profile:verts.extend([(offset[0]+r*math.cos(a),offset[1]+y,offset[2]+r*ellipse*math.sin(a))for a in np.linspace(0,T,n,endpoint=False)])
 for k in range(len(profile)):
  nxt=(k+1)%len(profile)
  for j in range(n):
   q=(j+1)%n;a=k*n+j;bb=k*n+q;c=nxt*n+j;d=nxt*n+q;faces.extend([(a,bb,c),(bb,d,c)])
 if _signed_volume(verts,faces)<0:faces=[(a,c,bb)for a,bb,c in faces]
 b.raw.append(dict(name=name,material=mat,_vertices=verts,_faces=faces,_uvs=[(0,0)]*len(verts)))
def ringpart(b,name,mat,rx,rz,y,h,hole=.0,roundness=.0006):
 inset=min(.002,rx*.04,h*.12);pr=[(y,rx-inset),(y+inset,rx),(y+h-inset,rx),(y+h,rx-inset)]
 if hole:pr +=[(y+h,hole),(y+inset,hole),(y,hole)]
 if hole:annulus(b,name,mat,pr,rz/rx)
 else:
  rings=[(yy,contour(rad,rad*rz/rx))for yy,rad in pr];b.solid(name,mat,rings)
def torus(b,name,mat,major,minor,y,x=0,z=0):
 profile=[(y+minor*math.sin(a),major+minor*math.cos(a))for a in np.linspace(0,T,12,endpoint=False)];annulus(b,name,mat,profile,offset=(x,0,z),n=64)
def add_reeds(b,c,w,h,d,bh,neck):
 count=c['reed_count'];rr=min(.00105,w*.012)
 for j in range(count):
  if c['pose']=='installed':
   a=(j-(count-1)/2)/max(1,count-1);x=a*neck*.92;z=((j%3)-1)*neck*.25;xt=a*w*.72;zt=((j%2)-.5)*d*.15;start=bh*.52
  else:
   # Bundle rests beside a circular bottle in an unused back corner of the
   # bottle's official rectangular footprint. It never penetrates the glass.
   a=j%3;row=j//3;corner=.455 if c['section']=='rounded_rect'else.405;x=w*(corner+.025*(a-1));z=-d*(corner+.025*(row-1));xt=x;zt=z;start=.001
  top=h-rr-.0006*(j%3);pts=[(x+(xt-x)*t,start+(top-start)*t,z+(zt-z)*t)for t in np.linspace(0,1,7)];b.tube('individual-'+c['reed']+'-'+str(j+1),c['reed'],pts,rr,16)
 if c['pose']=='closed_stowed':
  # Two restrained physical ties visible on the supplied upright bundle.
  for yy in[.025,min(.08,bh*.6)]:
   corner=.455 if c['section']=='rounded_rect'else.405;torus(b,'thin-bundle-tie-'+str(yy),c['reed'],.004,.00035,yy,w*corner,-d*corner)
def tassel(b,c,w,bh,neck):
 mat=c['tassel'];torus(b,'neck-wrapped-twisted-tassel-cord',mat,neck*1.2,.0008,bh*.955)
 x=-w*.29;z=w*.55;y=bh*.72
 b.tube('cord-from-neck-to-tassel-knot',mat,[(-neck*.6,bh*.955,neck*.9),(x,bh*.82,z),(x,y,z)],.0012,12)
 for i in range(48):
  a=T*i/48;rx=.0056*math.cos(a);rz=.0056*math.sin(a);bottom=max(.001,y-bh*.69+.0025*math.sin(i*2.3));pts=[(x+rx*.3,y,z+rz*.3),(x+rx,y-.012,z+rz),(x+rx*1.3,y-.030,z+rz*1.3),(x+rx*1.8,bottom,z+rz*1.8)];b.tube('separate-tassel-fiber-'+str(i),mat,pts,.00036,6)
 ringpart(b,'tassel-binding-knot',mat,.0044,.0044,y-.014,.007)
 # Move the tiny knot from the origin to the actual hanging position.
 g=b.raw[-1];g['_vertices']=[(xx+x,yy,zz+z)for xx,yy,zz in g['_vertices']]
 b.box('small-hanging-brass-fragrance-tag','brass_tag',w*.09,bh*.13,.00055,bh*.73,x=-w*.28,z=w*.54,r=.0008,bev=.00012)
def geometry(p,c,glass,label):
 ow,oh,od=np.array(p['dimensions_cm'])/100;w=ow*(.78 if c['index']==65 else .70);h=oh;d=od*.94;r=min(w,d)/2;b=B();kind=c['shape'];bh=min(h*.90,w*c['body_aspect']);neck=r*.32;bodytop=bh*.77;capheight=min(.025,w*.25);rx=w/2;rz=d/2
 if kind=='winter':
  bh=h*.48;neck=r*.46;outer=[(0,.92),(.001,1),(.004,1),(.006,.95),(bh*.70,.95),(bh*.75,.90),(bh*.84,.46),(bh*.94,.46),(bh*.96,.56),(bh,.54)]
 elif kind=='salted':
  neck=r*.36;outer=[(0,.94),(.002,1),(.005,.98),(bh*.58,.98),(bh*.62,1),(bh*.66,.98),(bh*.76,.80),(bh*.83,.40),(bh*.92,.36),(bh*.95,.54),(bh,.51)]
 elif kind=='ginger':
  neck=r*.34;outer=[(0,.94),(.001,1),(.004,.96),(bh*.74,.96),(bh*.81,.91),(bh*.87,.62),(bh*.89,.34),(bh*.96,.34),(bh,.48)]
 elif kind=='bubbly':
  bh=min(h*.58,w*1.42);neck=r*.22;outer=[(0,.73),(.002,.84),(bh*.12,.95),(bh*.35,1),(bh*.65,1),(bh*.78,.93),(bh*.88,.73),(bh*.94,.24),(bh*.985,.22),(bh,.30)]
 elif kind=='gourmand':
  neck=r*.31;outer=[(0,.94),(.002,1),(.004,1),(.006,.96),(bh*.72,.96),(bh*.76,1),(bh*.80,.97),(bh*.86,.36),(bh*.98,.31),(bh,.40)]
 elif kind in['label_cylinder','wood_collar']:
  neck=r*(.40 if kind=='label_cylinder'else.31);outer=[(0,.94),(.002,1),(.005,.98),(bh*.88,.98),(bh*.92,.92),(bh*.94,neck/r),(bh*.99,neck/r),(bh,neck/r*1.09)]
 elif kind=='porcelain_collar':
  neck=r*.27;outer=[(0,.95),(.002,1),(.005,1),(bh*.74,1),(bh*.81,.95),(bh*.89,.68),(bh*.94,.28),(bh,.28)]
 elif kind=='stone_collar':
  neck=r*.36;bh=min(h*.85,w*1.70);outer=[(0,.94),(.002,1),(.006,.98),(bh*.82,.98),(bh*.87,.93),(bh*.94,.45),(bh,.36)]
 elif kind=='pumpkin':
  bh=h*.81;neck=r*.28;outer=[(0,.87),(.002,.96),(bh*.14,.97),(bh*.68,.97),(bh*.77,.92),(bh*.91,.38),(bh*.95,.28),(bh,.36)]
 elif kind in['tassel_arch','ball_arch']:
  neck=rx*.45
  if kind=='ball_arch':bh=h*(.66 if c['index']==65 else .64)
  outer=[(0,.80),(.002,.92),(.006,.97),(bh*.62,.97),(bh*.71,.94),(bh*.79,.74),(bh*.82,.45),(bh*.97,.45),(bh,.60)]
 elif kind=='signature':
  neck=r*.30;outer=[(0,.72),(.002,.78),(.005,.81),(bh*.06,.82),(bh*.86,1),(bh*.91,1),(bh*.93,.95),(bh*.95,.30),(bh,.30)]
 elif kind=='sunshine':
  neck=r*.21;bh=h*.58;outer=[(0,.87),(.002,.93),(bh*.10,.95),(bh*.75,.95),(bh*.82,.87),(bh*.91,.40),(bh*.96,.21),(bh,.28)]
 elif kind=='white_powdery':
  neck=r*.40;outer=[(0,.84),(.002,.92),(bh*.16,1),(bh*.68,.96),(bh*.81,.79),(bh*.88,.43),(bh,.40)]
 else:
  outer=[(0,.94),(.002,1),(.005,.98),(bh*.69,.98),(bh*.76,.93),(bh*.86,.62),(bh*.90,.32),(bh*.96,.32),(bh,.46)]
 # A continuous inner wall and real bottom turn the glass into a closed solid
 # shell with open neck; liquid is an independent closed lower volume.
 lip=outer[-1][1];inner=[(bh,max(.12,lip-.075)),(bh*.91,max(.12,neck/r-.065)),(bh*.82,.60),(bh*.69,.88),(.006,.88)]
 if kind=='ball_arch':inner=[(bh,.54),(bh*.91,.39),(bh*.82,.39),(bh*.69,.86),(.006,.88)]
 sample=_profile_sampler([(rad,yy)for yy,rad in outer]);outer=[(float(yy),sample(float(yy)))for(a,_),(bb,_)in zip(outer,outer[1:])for yy in np.linspace(a,bb,5,endpoint=False)]+[outer[-1]];profile=outer+inner;shell(b,('tassel-'if kind=='tassel_arch'else'')+kind+'-hollow-glass-body',glass,profile,rx,rz,c['section'],c['flutes'])
 # Subtle raised glass heel and genuine liquid meniscus, kept within the shell.
 liqmat=c['glass'];i=c['index']
 if c['glass']=='clear':liqmat='pale_green'if i in[99,100,101]else'pale_cream'if i in[102,103]else'smoke'if i in[104,105]else'pale_blue'if i in[106,107]else'amber'if i==56 else'pale_gold'
 liquidtop=bh*.67;liq=[(.006,.83),(liquidtop-.0006,.83),(liquidtop,.82),(liquidtop-.0008,.01)];shell(b,'separate-fragrance-liquid-with-meniscus',liqmat,liq,rx,rz,c['section'])
 capy=bh-.001
 if kind in['bubbly','pumpkin','sunshine','winter']:
  ringpart(b,'thickened-open-glass-neck-lip',glass,neck*1.22,neck*1.22,bh-.002,.0035,hole=neck*.80)
 elif kind=='porcelain_collar':
  # Smooth broad ceramic-like decorative neck ring, with a genuine reed hole.
  ys=[(capy,neck*1.25),(capy+.002,neck*1.85),(capy+.006,neck*2.05),(capy+.019,neck*2.05),(capy+.023,neck*1.75),(capy+.023,neck*.80),(capy+.003,neck*.80),(capy,neck*.80)];annulus(b,'rounded-ivory-decorative-neck-ring',c['cap'],ys)
 elif kind in['tassel_arch','ball_arch']:
  ringpart(b,'black-neck-gasket','cap_black',neck*1.1,neck*1.1,bh-.003,.006,hole=0);rad=rx*.57 if kind=='ball_arch'else r*.46;ringpart(b,'wooden-stopper-inserted-plug',c['cap'],neck*.70,neck*.70,bh-.015,.020);b.bottle('spherical-removable-wooden-stopper',c['cap'],[(bh+rad*(.8-math.cos(a)),max(.00003,rad*math.sin(a)))for a in np.linspace(.01,math.pi-.01,48)],facets=96)
 elif kind=='stone_collar':ringpart(b,'porous-travertine-decorative-neck-trim',c['cap'],r*.74,r*.74,capy,min(h-bh-.001,.030),hole=neck*.75)
 elif kind=='apothecary'and c['pose']=='installed':ringpart(b,'exposed-glass-neck-lip-in-use',glass,neck*1.42,neck*1.42,bh-.002,.0035,hole=neck*.75)
 elif kind=='white_powdery':
  # The opaque white cap is much broader than the visible gold neck band in
  # the original photograph; this short bottle has a distinct broad stopper.
  ringpart(b,'visible-gold-neck-band','brass_tag',neck*1.10,neck*1.10,bh-.002,w*.070)
  ringpart(b,'broad-rounded-white-stopper',c['cap'],r*.67,r*.67,bh+w*.055,w*.31)
 else:
  capr=neck*(1.48 if kind in['wood_collar','gourmand','travel']else 1.35);ch=capheight*(1.7 if kind=='wood_collar'else 1.0 if kind not in['signature']else 1.6);ch=min(ch,h-bh-.0005)
  if kind=='wood_collar':capr=r*.76
  ringpart(b,'separate-'+c['cap']+'-neck-cap',c['cap'],capr,capr,capy,ch,hole=neck*.73 if c['pose']=='installed'else 0)
 if label:
  ph=bh*(.65 if c['label']=='paper_gourmand'else.70);pw=w*(.73 if c['label']=='paper_gourmand'else.68);b.patch('thin-physical-curved-printed-paper-label',label,pw,ph,bh*.45,r*.985)
 if c['shape']in['wood_collar']:
  # The photographed tall collars reveal a real conical glass punt at base.
  punt=[(.004,.55),(.012,.25),(.020,.02),(.020,.001)];shell(b,'internal-conical-glass-base-punt',glass,punt,rx,rz)
 add_reeds(b,c,w,h,d,bh,neck)
 for g in b.raw:
  if g['name'].startswith('individual-reed_')or g['name'].startswith('thin-bundle-tie-'):
   g['_vertices']=[(x+ow*.30,y,z+od*.10)for x,y,z in g['_vertices']]
 if c['tassel']:tassel(b,c,w,bh,neck)
 features=[kind+' silhouette, distinct heel/shoulder/neck profile and open inner wall','Separate liquid fill and meniscus','Photo-specific '+c['cap']+' cap or decorative collar',str(c['reed_count'])+' separate closed '+c['reed']+' stems',c['label']+' redrawn intrinsic lettering/label; no photograph pixels']
 if kind=='apothecary'and c['pose']=='installed':features[2]='Exposed glass neck and rounded glass lip in the photographed ready-for-use pose; transport stopper removed'
 features.append('Official product lengths bound the photographed closed-stopper plus separate side reed bundle display; individual bottle/reed manufacturing dimensions are photo-inferred')
 if c['section']=='rounded_rect':features.append('Flattened rounded-rectangle glass body with a circular neck and separate wooden stopper')
 if c['flutes']:features.append(str(c['flutes'])+' physical vertical glass ribs, restricted to the photographed lower section for tassel bottles')
 if c['tassel']:features.append('Visible flexible neck cord, binding knot,48 independently closed tassel strands and a small metal tag; tassel rotated toward the front in this display pose')
 return b.raw,features,bh

def finish(raw,w,h,d):
 allv=np.concatenate([np.asarray(g['_vertices'])for g in raw]);lo=allv.min(0);hi=allv.max(0);scale=np.array([w,h,d])/(hi-lo);centre=np.array([(lo[0]+hi[0])/2,lo[1],(lo[2]+hi[2])/2]);meshes=[];qa=[]
 for g in raw:
  vv=(np.asarray(g['_vertices'])-centre)*scale;vertices=[];uvs=[];faces=[]
  if _signed_volume(vv,g['_faces'])<0:g['_faces']=[(a,c,b)for a,b,c in g['_faces']]
  for face in g['_faces']:
   tri=vv[list(face)];normal=np.cross(tri[1]-tri[0],tri[2]-tri[0]);axis=int(np.argmax(np.abs(normal)));start=len(vertices);uv=[]
   for j in face:
    x,y,z=vv[j];vertices.append(tuple(vv[j]))
    if g.get('_uv_mode')=='bottle'and axis!=1:uv.append(tuple(g['_uvs'][j]))
    elif g.get('_uv_mode')=='patch'and abs(normal[2])>max(abs(normal[0]),abs(normal[1])):uv.append(tuple(g['_uvs'][j]))
    else:uv.append((.5+x/.60,.5+z/.60)if axis==1 else((.5+x/.60,.5+y/.60)if axis==2 else(.5+z/.60,.5+y/.60)))
   if g.get('_uv_mode')=='bottle'and max(u for u,v in uv)-min(u for u,v in uv)>.5:uv=[(u+1 if u<.5 else u,v)for u,v in uv]
   # Curved shoulders can share meridian coordinates; a physical planar chart
   # on a near-horizontal tiny bevel prevents collapsed UV triangles.
   a=np.array(uv[1])-uv[0];b=np.array(uv[2])-uv[0]
   if abs(a[0]*b[1]-a[1]*b[0])<2e-13:
    uv=[(.5+v[0]/.6,.5+v[2]/.6)if axis==1 else((.5+v[0]/.6,.5+v[1]/.6)if axis==2 else(.5+v[2]/.6,.5+v[1]/.6))for v in tri]
   uvs.extend(uv);faces.append((start,start+1,start+2))
  g.update(_vertices=vertices,_uvs=uvs,_faces=faces);m,q=_finalize(g);meshes.append(m);qa.append(q)
 return meshes,dict(valid=True,affine_fit_scale=scale.tolist(),overall_dimensions_official=True,local_details_photo_inferred=True,triangles=sum(q['triangles']for q in qa),meshes=qa)
def validate(meshes,p):
 vv=np.concatenate([np.asarray(m['positions']).reshape(-1,3)for m in meshes]);lo=vv.min(0);hi=vv.max(0);error=float(np.max(np.abs(hi-lo-np.array(p['dimensions_cm'])/100)));assert error<1e-8;deg=0;ne=0
 for m in meshes:
  uv=np.asarray(m['uvs']).reshape(-1,2);ff=np.asarray(m['indices']).reshape(-1,3);a=uv[ff[:,1]]-uv[ff[:,0]];b=uv[ff[:,2]]-uv[ff[:,0]];ar=np.abs(a[:,0]*b[:,1]-a[:,1]*b[:,0])/2;deg+=int((ar<1e-14).sum());nn=np.asarray(m['normals']).reshape(-1,3);ne=max(ne,float(np.abs(np.linalg.norm(nn,axis=1)-1).max()))
 assert deg==0,(p['id'],deg);assert ne<1e-6
 return dict(valid=True,bounds_min_m=lo.tolist(),bounds_max_m=hi.tolist(),max_bounds_error_m=error,degenerate_uv_triangles=deg,max_unit_normal_error=ne,closed_component_topology=True,global_boolean_union_tested=False)
def main():
 only=set(sys.argv[1:]);bankdir,spec=bank();manifest=json.loads((R/'manifest.json').read_text())if only and(R/'manifest.json').exists()else[];configs=[]
 for p in PLAN:
  c=cfg(p);configs.append(dict(id=p['id'],**c))
  if only and p['id']not in only and c['shape']not in only:continue
  out=R/'models'/p['id'];out.mkdir(parents=True,exist_ok=True);w,h,d=np.array(p['dimensions_cm'])/100;approx_bh=min(h*.9,w*c['body_aspect']);mats,glass,label=product_materials(p,c,bankdir,spec,approx_bh);raw,features,bh=geometry(p,c,glass,label);meshes,gqa=finish(raw,w,h,d);gqa.update(validate(meshes,p),photographed_features=features);mats={k:mats[k]for k in {m['material']for m in meshes}};maps=[]
  for m in mats.values():
   for slot in['baseColorTexture','normalTexture','metallicRoughnessTexture']:
    src=bankdir/m[slot];dst=out/src.name
    if not dst.exists():shutil.copyfile(src,dst)
    elif sha(dst)!=sha(src):shutil.copyfile(src,dst)
    maps.append(dict(file=dst.name,resolution=[2048,2048],sha256=sha(dst)))
  md={k:p[k]for k in['id','sku','name','url','image_code','dimensions_cm','source_dimensions_hwd_cm','source_market','size_source_kind','size_source_urls','source_images','size_evidence_file','category_card_indices','source_anomalies']}
  note='Resmî H/W/D dış ölçüleri kullanılmıştır. Şişe profili, duvar/dip kalınlığı, sıvı seviyesi, tıpa/kapak, kamış sayısı ve yerel ayrıntılar orijinal ürün fotoğrafından yorumlanmıştır. '
  note+=('Kamışlar fotoğraftaki kullanım gibi şişeye yerleştirilmiştir.'if c['pose']=='installed'else'Kapalı tıpa korunur; kamışlar şişenin arka köşesinde ayrı dik demet olarak yerleştirilmiştir. Yerleşim pozu resmî ölçüm iddiası taşımaz; tek tek kamış imalat boyları ayrıca doğrulanmamıştır.')
  if c['shape']=='apothecary'and c['pose']=='installed':note+=' Kullanım fotoğrafındaki çıkarılmış taşıma tıpası yerine açık cam boyun gösterilir.'
  if c['tassel']:note+=' Esnek püskül, ayrı lifleri ve boyun bağını göstermek için öne dönük serbest asılı pozdadır; püskülün imalat ölçüsü doğrulanmış değildir.'
  if p['source_market']!='Türkiye':note+=' Ölçü kanıtı aynı SKU için '+p['source_market']+' resmî Zara Home kaynağıdır.'
  caplabel='Gözenekli traverten boyun halkası'if c['cap']=='cap_stone'else'Ahşap boyun halkası / tıpa'if c['cap'].startswith('wood')else'Beyaz dekoratif boyun halkası'if c['cap']in['cap_white','cap_ivory']else'Siyah kapak / tıpa';reedlabel='Siyah kamış'if c['reed']=='reed_black'else'Kahverengi kamış'if c['reed']=='reed_brown'else'Doğal kamış'
  if c['shape']=='apothecary'and c['pose']=='installed':caplabel='Açık cam boyun'
  if c['index']==77:md['source_anomalies'].append('The official190ml Vibrant Rose page publishesH22/W4.5/D4.5cm, identical to the95ml page. The raw official chart is retained; no larger dimensions are inferred from volume or sibling products.')
  md.update(category='Çubuklu oda kokuları',source_size_scope='official_product_lengths; individual_bottle_and_reeds_photo_inferred',material_label='Fotoğrafa göre renkli / dokulu cam · '+caplabel+' · '+reedlabel,units='metres',up_axis='Y',origin='bottom bounding-box centre',estimated_dimensions=False,axis_ambiguity=False,scale_note=note,photo_pixels_baked=False,baked_reflections=False,photographed_features=features,display_pose=c['pose'],reed_count=c['reed_count'],reed_count_photo_inferred=True,local_dimensions_photo_inferred=True,model_revision='complete-diffusers-photo-specific-v1',profile_family=c['shape'],model_scope='bottle_liquid_cap_or_collar_and_reeds',packaging_excluded=True)
  model=out/'model.json';dump(model,dict(metadata=md,materials=mats,meshes=meshes));dump(out/'geometry-validation.json',gqa);dump(out/'material-validation.json',dict(valid=True,native_resolution=2048,maps=maps,photo_pixels_baked=False,baked_reflections=False));rep=export_assets(model,out,p['id']);glb=out/(p['id']+'.glb');doc,binary=read_glb(glb);doc['samplers']=[dict(magFilter=9729,minFilter=9987,wrapS=10497,wrapT=10497)]
  for tex in doc.get('textures',[]):tex['sampler']=0
  write_glb(glb,doc,binary);assert glb.stat().st_size<40_000_000;rep['deliverable_sha256']['glb']=sha(glb);rep['glb_bytes']=glb.stat().st_size;dump(Path(rep['files']['validation']),rep);embedded=[]
  for im in doc['images']:
   assert 'uri'not in im;view=doc['bufferViews'][im['bufferView']];off=view.get('byteOffset',0);data=binary[off:off+view['byteLength']];px=Image.open(io.BytesIO(data));assert px.size==(2048,2048)and px.format=='PNG';embedded.append(dict(name=im.get('name'),resolution=[2048,2048],embedded=True,format='PNG',sha256=hashlib.sha256(data).hexdigest()))
  eq=out/'embedded-texture-validation.json';dump(eq,dict(valid=True,images=embedded,glb_version=2,all_textures_embedded=True));e={**md,'model_path':str(model),'asset_dir':str(out),'glb_path':str(glb),'bytes':glb.stat().st_size,'sha256':sha(glb),'triangles':gqa['triangles'],'geometry_validation':str(out/'geometry-validation.json'),'material_validation':str(out/'material-validation.json'),'embedded_texture_validation':str(eq)};manifest=[x for x in manifest if x['id']!=e['id']]+[e];order={p['id']:j for j,p in enumerate(PLAN)};manifest.sort(key=lambda e:order[e['id']]);dump(R/'manifest.json',manifest);print(p['id'],c['shape'],glb.stat().st_size,gqa['triangles'],flush=True)
 dump(R/'photo-classifications.json',configs);originals=json.loads((R/'reference-downloads.json').read_text());assert all(sha(r['local_master'])==r['sha256']for r in originals)
 coverage=[]
 for i,row in enumerate(ROWS):
  matched=[m['id']for m in manifest if i in m['category_card_indices']];coverage.append(dict(index=i,title=row['title'],url=row['url'],image_code=row.get('image_code'),existing_model_ids=row['matched_model_ids'],new_model_ids=matched,status='existing'if row['matched_model_ids']else'ready'if matched else'needs_measurement_or_identity'))
 dump(R/'card-coverage.json',dict(official_card_count=len(ROWS),scan_complete=True,cards=coverage));dump(R/'batch-validation.json',dict(valid=True,planned=len(PLAN),models_ready=len(manifest),total_glb_bytes=sum(m['bytes']for m in manifest),maximum_glb_bytes=max(m['bytes']for m in manifest),immutable_source_photos=len(originals),source_photo_hashes_unchanged=True,all_textures_native_2048_embedded_png=True,all_component_topology_uv_normals_bounds_passed=True,needs_measurement_cards=sum(c['status']=='needs_measurement_or_identity'for c in coverage),geometry_scope='Separate closed physical components, no global Boolean union',photo_layout_inferred=True))
 print('COMPLETE',len(manifest),'models',flush=True)
if __name__=='__main__':main()
