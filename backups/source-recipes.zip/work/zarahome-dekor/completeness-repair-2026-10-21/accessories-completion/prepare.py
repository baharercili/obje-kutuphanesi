from pathlib import Path
import sys,json,re,shutil,hashlib,urllib.request,concurrent.futures,io
sys.dont_write_bytecode=True
from PIL import Image,ImageDraw,ImageFont
R=Path(__file__).resolve().parent;N=R.parent
def dump(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def fc(url):m=re.search(r'-l(\d+[A-Z\d]*)',url);return m.group(1)if m else None
cat=json.loads((R/'raw/category-snapshot.json').read_text());shutil.copyfile(N/'live-product-details-from-root.json',R/'raw/live-product-details-from-root.json');live=json.loads((R/'raw/live-product-details-from-root.json').read_text());office=json.loads((N/'office-models/manifest.json').read_text());plan=[];pending=[];cross=[];coverage=[];bykey={}
for idx,row in enumerate(cat['products']):
 family=fc(row['url']);matches=[f for f in live if fc(f.get('url',''))==family];images=row.get('images',[])[:]
 for f in matches:images+=f.get('gallery_images',[])
 row['images']=list({im['url']:im for im in images}.values());hits=[m for m in office if fc(m['url'])==family]
 if hits:
  cross.append(dict(index=idx,url=row['url'],sku=hits[0]['sku'],model_ids=[m['id']for m in hits],source_master_manifest=str(N/'office-models/manifest.json')));coverage.append(dict(index=idx,status='cross_listed_office_master',model_ids=[m['id']for m in hits]));continue
 if row.get('matched_model_ids'):coverage.append(dict(index=idx,status='existing_master',model_ids=row['matched_model_ids']));continue
 valid=[f for f in matches if f.get('sku')and f.get('dimension_cell_labels')]
 if not valid:pending.append(dict(index=idx,title=row['title'],url=row['url'],reason='ExactSKU and full official physicalH/W/D not observed'));coverage.append(dict(index=idx,status='needs_measurement'));continue
 f=valid[-1];sku=f['sku'];raw=f['dimension_cell_labels'];assert len(raw)%3==0;dims=[[float(re.search(r'([\d.,]+)\s*cm',z).group(1).replace(',','.'))for z in raw[j:j+3]]for j in range(0,len(raw),3)];code=row.get('image_code')
 if not code:
  candidates=[re.search(r'/(\d{11})(?:[-/])',im['url'])for im in row['images']];code=next((m.group(1)for m in candidates if m and m.group(1).endswith(sku[-3:])),None)
 assert code,(idx,sku);images=[im for im in row['images']if code in im['url']];assert images
 def priority(im):
  url=im['url'];width=re.search(r'[?&]w=(\d+)',url);return('-a7/'in url or'-a7.jpg'in url,'-p1/'in url or'-p1.jpg'in url,int(width.group(1))if width else 0)
 images.sort(key=priority,reverse=True)
 for h,w,d in dims:
  key=(sku,h,w,d)
  if key in bykey:bykey[key]['category_card_indices'].append(idx);continue
  flat=idx==41;whd=[w,d,h]if flat else[w,h,d];fmt=lambda n:f'{n:g}'.replace('.','p');mid=sku.replace('/','-')+'-h'+fmt(whd[1])+'-w'+fmt(whd[0])+'-d'+fmt(whd[2]);p=dict(id=mid,sku=sku,name=row['title'],url=row['url'],image_code=code,dimensions_cm=whd,source_dimensions_hwd_cm=[h,w,d],source_market='Türkiye',size_source_kind='official_tr_live_exact_sku_labelled_axes',size_source_urls=[f['url']],size_evidence_file='raw/live-product-details-from-root.json',official_product_text=f['text'],source_images=images,category_card_indices=[idx],source_anomalies=[],display_pose='flat_on_desk'if flat else'upright',axis_mapping='modelX=sourceW; modelY=sourceD; modelZ=sourceH'if flat else'modelX=sourceW; modelY=sourceH; modelZ=sourceD');bykey[key]=p;plan.append(p)
 coverage.append(dict(index=idx,status='measured_ready',model_ids=[p['id']for p in plan if idx in p['category_card_indices']]))
dump(R/'measured-plan.json',plan);dump(R/'needs-measurement.json',pending);dump(R/'cross-listed-masters.json',cross);dump(R/'card-coverage-plan.json',coverage);dump(R/'source-inventory-resolved.json',cat)
todo=[];seen=set();(R/'source-images').mkdir(exist_ok=True)
for p in plan:
 idx=p['category_card_indices'][0]
 for j,im in enumerate(p['source_images']):
  if im['url']in seen:continue
  seen.add(im['url']);todo.append(dict(index=idx,image_code=p['image_code'],product_title=p['name'],product_url=p['url'],**im,filename=f'{idx:03}-{p["image_code"]}-{j}-master.jpg'))
dump(R/'download-plan.json',todo);print('PLAN',len(plan),'SKUS',len({p['sku']for p in plan}),'PENDING',len(pending),'CROSS_CARDS',len(cross),'DOWNLOAD',len(todo),flush=True)
if '--download'in sys.argv:
 def download(rec):
  path=R/'source-images'/rec['filename']
  try:
   data=path.read_bytes()if path.exists()else urllib.request.urlopen(urllib.request.Request(rec['url'],headers={'User-Agent':'Mozilla/5.0'}),timeout=45).read()
   if not path.exists():path.write_bytes(data)
   im=Image.open(io.BytesIO(data));return{**rec,'local_master':str(path),'sha256':hashlib.sha256(data).hexdigest(),'pixel_dimensions':list(im.size),'format':im.format,'mode':im.mode,'original_unchanged':True}
  except Exception as exc:return{**rec,'error':str(exc)}
 with concurrent.futures.ThreadPoolExecutor(max_workers=4)as pool:got=list(pool.map(download,todo))
 dump(R/'reference-downloads.json',[p for p in got if'error'not in p]);dump(R/'download-results.json',got);print('DOWNLOADED',sum('error'not in p for p in got),'ERRORS',sum('error'in p for p in got),flush=True)
 cards=[]
 for p in plan:
  if p['category_card_indices'][0]not in{q['category_card_indices'][0]for q in cards}:cards.append(p)
 for start in range(0,len(cards),12):
  group=cards[start:start+12];cw=450;ch=500;sheet=Image.new('RGB',(cw*4,ch*((len(group)+3)//4)),'white');dr=ImageDraw.Draw(sheet);font=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',17)
  for j,p in enumerate(group):
   idx=p['category_card_indices'][0];rec=next(g for g in got if g['url']==p['source_images'][0]['url']and'error'not in g);im=Image.open(rec['local_master']);im.thumbnail((cw-8,ch-86));x=j%4*cw;y=j//4*ch;sheet.paste(im,(x+(cw-im.width)//2,y+(ch-86-im.height)//2));dr.text((x+4,y+ch-83),str(idx)+' '+p['sku'],font=font,fill='black');dr.text((x+4,y+ch-61),p['name'][:37],font=font,fill='black');dr.text((x+4,y+ch-39),str([q['dimensions_cm']for q in plan if idx in q['category_card_indices']]),font=font,fill='black')
  sheet.save(R/f'reference-sheet-{start//12}.png')
