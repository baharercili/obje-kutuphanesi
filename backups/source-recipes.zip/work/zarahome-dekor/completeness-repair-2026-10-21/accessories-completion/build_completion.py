"""Complete measured decorative accessories. Original photograph masters stay immutable.

All dimensions are official; part thicknesses, poses and small sculptural details
are interpreted from the exact product galleries. No generic fallback geometry.
"""
from pathlib import Path
import sys,json,math,hashlib,shutil,io
sys.dont_write_bytecode=True
import numpy as np
from PIL import Image,ImageDraw,ImageFont,ImageFilter
R=Path(__file__).resolve().parent
sys.path.insert(0,str(R.parent/'office-models'))
import build_office as O
B=O.B;move=O.move;rotate=O.rotate;torus=O.torus
O.base.R=R
T=math.tau;N=2048
PLAN=json.loads((R/'measured-plan.json').read_text())
REF=json.loads((R/'reference-downloads.json').read_text())
FONT='/System/Library/Fonts/Supplemental/Arial.ttf'
BOLD='/System/Library/Fonts/Supplemental/Arial Bold.ttf'
def dump(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
PALETTE={
 'rope':([190,184,166],'rope',.83),'linen':([199,191,170],'linen',.84),
 'paper':([207,199,172],'paper',.78),'page_edge':([220,214,190],'paper',.8),
 'black_cast':([34,32,29],'cast',.46),'black_metal':([17,21,21],'paint',.3),
 'black_fabric':([12,22,23],'linen',.85),'stitch':([151,143,123],'linen',.8),
 'red_plastic':([145,26,34],'plastic',.2),'cream_plastic':([222,216,178],'plastic',.25),
 'brown_plastic':([57,36,30],'plastic',.22),'red_face':([137,75,59],'plastic',.34),
 'teal':([40,99,93],'plastic',.25),'blue_card':([62,105,122],'paper',.6),
 'green_card':([51,99,80],'paper',.6),'rubber':([19,20,20],'plastic',.81),
 'chrome':([218,218,212],'metal',.10),'steel_face':([186,191,190],'metal',.43),
 'wood':([134,88,49],'wood',.35),'copper':([172,107,67],'metal',.23),
 'sand':([16,24,23],'sand',.88),'ceramic':([227,222,204],'glaze',.22),
 'terracotta':([110,51,32],'glaze',.12),'tray_glaze':([229,222,198],'glaze',.26),'stone_ceramic':([227,218,194],'stone',.63),
 'glass':([250,251,247],'glass',.035)}
def bank():
 out=R/'material-bank';out.mkdir(exist_ok=True);rng=np.random.default_rng(7332026)
 u=np.arange(N,dtype=np.float32)[None,:]/N;v=np.arange(N,dtype=np.float32)[:,None]/N
 cloud=np.asarray(Image.fromarray(rng.integers(0,255,(42,42),dtype=np.uint8)).resize((N,N),Image.Resampling.BICUBIC),np.float32)/255-.5
 grain=np.asarray(Image.fromarray(rng.integers(0,255,(256,256),dtype=np.uint8)).resize((N,N),Image.Resampling.BICUBIC),np.float32)/255-.5
 mats={}
 for name,(rgb,style,rough)in PALETTE.items():
  af=name+'-albedo-2k.png';nf=name+'-normal-2k.png';of=name+'-orm-2k.png'
  if not all((out/f).exists()for f in[af,nf,of]):
   h=np.zeros((N,N),np.float32);tone=cloud*.2
   if style in['rope','linen']:
    warp=np.sin(T*u*(245 if style=='linen'else 140));weft=np.sin(T*v*(245 if style=='linen'else 140));h=.13*(warp+weft)+grain*.025;tone=cloud*4+(warp+weft)*.8
   elif style=='cast':h=grain*.095+cloud*.07;tone=cloud*1.2+grain*3
   elif style=='wood':h=.07*np.sin(T*(v*132+cloud*.06));tone=cloud*9+6*np.sin(T*(v*132+cloud*.06))
   elif style=='stone':h=grain*.045+cloud*.06;tone=cloud*14+grain*10
   elif style=='glaze':h=grain*.008;tone=cloud*.65
   elif style=='sand':h=grain*.10;tone=grain*2
   al=np.clip(np.array(rgb)+tone[:,:,None],0,255).astype('uint8')
   if name=='ceramic':
    im=Image.fromarray(al,'RGB');dr=ImageDraw.Draw(im)
    for j in range(1600):
     x,y=rng.integers(0,N,2);rr=float(rng.choice([.6,.8,1.1]));co=int(rng.integers(130,195));dr.ellipse((x-rr,y-rr,x+rr,y+rr),fill=(co+7,co,co-10))
    al=np.array(im)
   dx=np.gradient(h,axis=1);dy=np.gradient(h,axis=0);nn=np.stack([-dx,-dy,np.ones_like(dx)],axis=2);nn/=np.linalg.norm(nn,axis=2,keepdims=True)
   orm=np.zeros((N,N,3),np.uint8);orm[:,:,0]=255;orm[:,:,1]=np.rint(np.clip(rough+cloud*.012,.025,.98)*255).astype('uint8');orm[:,:,2]=255 if style=='metal'else 0
   for f,a in[(af,al),(nf,np.rint((nn+1)*127.5).astype('uint8')),(of,orm)]:Image.fromarray(a,'RGB').save(out/f,optimize=True)
  mats[name]=dict(baseColorFactor=[1,1,1,1],baseColorTexture=af,normalTexture=nf,metallicRoughnessTexture=of,metallic=1 if style=='metal'else 0,roughness=1,normalScale=.4 if style in['rope','linen','cast','stone']else .12,clearcoat=.7 if style in['glaze','plastic']else 0,clearcoatRoughness=.08 if style=='glaze'else .15,doubleSided=False,alphaMode='OPAQUE',extras=dict(native_map_resolution=N,intrinsic_material_maps=True,source_photo_pixels=False,baked_reflections=False))
  if style=='glass':mats[name].update(transmission=.98,ior=1.50,thickness=.0012,attenuationColor=[.97,.99,.97],attenuationDistance=1.0)
 # The doorstop scarf has the actual navy/brown/yellow woven plaid.
 im=Image.new('RGB',(N,N),(167,143,87));dr=ImageDraw.Draw(im)
 for j in range(-1,9):
  q=j*256;dr.rectangle((q,0,q+105,N),fill=(42,42,43));dr.rectangle((0,q,N,q+105),fill=(48,43,40));dr.rectangle((q+34,0,q+52,N),fill=(129,65,48));dr.rectangle((0,q+34,N,q+52),fill=(129,65,48));dr.rectangle((q+142,0,q+155,N),fill=(204,176,99));dr.rectangle((0,q+142,N,q+155),fill=(204,176,99))
 im.save(out/'scarf-plaid-albedo-2k.png',optimize=True);mats['plaid']=dict(mats['linen'],baseColorTexture='scarf-plaid-albedo-2k.png')
 return out,mats
def raw_mesh(b,name,mat,v,f):
 v=np.asarray(v,float);f=np.asarray(f,int)
 if O._signed_volume(v,f)<0:f=f[:,[0,2,1]]
 b.raw.append(dict(name=name,material=mat,_vertices=v.tolist(),_faces=f.tolist(),_uvs=[(0,0)]*len(v)))
def ellipsoid(b,name,mat,center,radii,segments=64,rings=30):
 r=np.array(radii);c=np.array(center);vv=[c+np.array([0,-r[1],0])];ff=[]
 for a in np.linspace(math.pi,0,rings+1)[1:-1]:
  vv.extend([c+np.array([r[0]*math.sin(a)*math.cos(t),r[1]*math.cos(a),r[2]*math.sin(a)*math.sin(t)])for t in np.linspace(0,T,segments,endpoint=False)])
 top=len(vv);vv.append(c+np.array([0,r[1],0]));levels=rings-1
 for j in range(segments):
  k=(j+1)%segments;ff.extend([(0,1+k,1+j),(top,1+(levels-1)*segments+j,1+(levels-1)*segments+k)])
 for row in range(levels-1):
  for j in range(segments):
   k=(j+1)%segments;a=1+row*segments+j;bb=1+row*segments+k;cc=a+segments;dd=bb+segments;ff.extend([(a,bb,cc),(bb,dd,cc)])
 raw_mesh(b,name,mat,vv,ff)
def smooth(keys,n=5):
 # Monotonic interpolation, with smoothstep transitions and no radius overshoot.
 result=[]
 for(y,r),(yy,rr)in zip(keys,keys[1:]):
  for t in np.linspace(0,1,n,endpoint=False):result.append((y+(yy-y)*t,r+(rr-r)*(t*t*(3-2*t))))
 return result+[keys[-1]]
def loop_tube(b,name,mat,points,r,sides=10,closed=True):
 points=np.asarray(points,float);n=len(points);v=[];f=[]
 for j,p in enumerate(points):
  tangent=points[(j+1)%n]-points[(j-1)%n]if closed else points[min(j+1,n-1)]-points[max(j-1,0)];tangent/=np.linalg.norm(tangent);nn=np.cross(tangent,[0,0,1])
  if np.linalg.norm(nn)<.01:nn=np.cross(tangent,[0,1,0])
  nn/=np.linalg.norm(nn);bi=np.cross(tangent,nn)
  v.extend([p+r*(nn*math.cos(q)+bi*math.sin(q))for q in np.linspace(0,T,sides,endpoint=False)])
 for j in range(n if closed else n-1):
  for k in range(sides):a=j*sides+k;bb=j*sides+(k+1)%sides;c=((j+1)%n)*sides+k;dd=((j+1)%n)*sides+(k+1)%sides;f.extend([(a,bb,c),(bb,dd,c)])
 if not closed:
  aa=len(v);v.extend([points[0],points[-1]])
  for k in range(sides):f.extend([(aa,(k+1)%sides,k),(aa+1,(n-1)*sides+k,(n-1)*sides+(k+1)%sides)])
 raw_mesh(b,name,mat,v,f)
def earclip(poly):
 p=np.asarray(poly,float);ids=list(range(len(p)));res=[]
 signed=sum(p[j,0]*p[(j+1)%len(p),1]-p[(j+1)%len(p),0]*p[j,1]for j in range(len(p)))
 if signed<0:ids=ids[::-1]
 while len(ids)>3:
  found=False
  for k in range(len(ids)):
   a,bb,c=ids[k-1],ids[k],ids[(k+1)%len(ids)];ab=p[bb]-p[a];bc=p[c]-p[bb]
   if np.cross(ab,bc)<=1e-15:continue
   inside=False
   for m in ids:
    if m in[a,bb,c]:continue
    q=p[m];cross=[np.cross(p[bb]-p[a],q-p[a]),np.cross(p[c]-p[bb],q-p[bb]),np.cross(p[a]-p[c],q-p[c])]
    if min(cross)>-1e-14:inside=True;break
   if inside:continue
   res.append((a,bb,c));ids.pop(k);found=True;break
  if not found:raise ValueError('Cannot triangulate polygon')
 res.append(tuple(ids));return res
def extrude(b,name,mat,poly,thick,axis='x',center=(0,0,0)):
 # Physical closed extrusion with ear-clipped caps (also safe for concave profiles).
 signed=sum(poly[j][0]*poly[(j+1)%len(poly)][1]-poly[(j+1)%len(poly)][0]*poly[j][1]for j in range(len(poly)))
 if signed<0:poly=poly[::-1]
 v=[];f=[];n=len(poly);cap=earclip(poly)
 for s in[-thick/2,thick/2]:
  for a,c in poly:v.append(np.array((s,a,c)if axis=='x'else(a,c,s)if axis=='z'else(a,s,c))+center)
 f.extend([(a,c,bb)for a,bb,c in cap]);f.extend([(a+n,bb+n,c+n)for a,bb,c in cap])
 for j in range(n):k=(j+1)%n;f.extend([(j,k,j+n),(k,k+n,j+n)])
 raw_mesh(b,name,mat,v,f)
def ribbon(b,name,mat,path,width,thick):
 # A stamped, curved band with rectangular section; width runs along X.
 path=np.asarray(path,float);v=[];f=[];n=len(path)
 for j,p in enumerate(path):
  t=path[min(j+1,n-1)]-path[max(j-1,0)];normal=np.cross([1,0,0],t);normal/=np.linalg.norm(normal)
  v.extend([p+np.array([sx*width/2,0,0])+normal*sy*thick/2 for sx,sy in[(-1,-1),(1,-1),(1,1),(-1,1)]])
 for j in range(n-1):
  for k in range(4):a=j*4+k;bb=j*4+(k+1)%4;c=(j+1)*4+k;dd=(j+1)*4+(k+1)%4;f.extend([(a,bb,c),(bb,dd,c)])
 f.extend([(0,2,1),(0,3,2),((n-1)*4,(n-1)*4+1,(n-1)*4+2),((n-1)*4,(n-1)*4+2,(n-1)*4+3)])
 raw_mesh(b,name,mat,v,f)
def rope_doorstop(b,w,h,d):
 rad=min(w,d)*.37;rr=w*.034
 # Four parallel wraps in each of the three perpendicular monkey-fist planes.
 for axis in range(3):
  for band in range(4):
   offset=(band-1.5)*rr*2.12;path=[]
   for a in np.linspace(0,T,144,endpoint=False):
    # Square-rounded route is characteristic of the photographed fist knot.
    ca=math.copysign(abs(math.cos(a))**.69,math.cos(a));sa=math.copysign(abs(math.sin(a))**.69,math.sin(a));p=np.array([rad*ca,rad*sa,offset])
    if axis==1:p=p[[2,0,1]]
    elif axis==2:p=p[[1,2,0]]
    p[1]+=w*.49;path.append(p)
   path=np.asarray(path)
   for strand in range(3):
    pts=[]
    for j,p in enumerate(path):
     tangent=path[(j+1)%len(path)]-path[(j-1)%len(path)];tangent/=np.linalg.norm(tangent);normal=np.cross(tangent,[0,0,1])
     if np.linalg.norm(normal)<.01:normal=np.cross(tangent,[0,1,0])
     normal/=np.linalg.norm(normal);bi=np.cross(tangent,normal);a=T*(j/len(path)*14+strand/3);pts.append(p+rr*.52*(normal*math.cos(a)+bi*math.sin(a)))
    loop_tube(b,'monkey-fist-'+str(axis)+'-wrap-'+str(band)+'-twisted-ply-'+str(strand),'rope',pts,rr*.53,8)
 # The continuous carrying eye rises from the knot; all three plys are physical.
 path=np.array([(w*.21*math.sin(a),w*.87+(h-w*.87)*(.5-.5*math.cos(a)),0)for a in np.linspace(0,T,180,endpoint=False)])
 for s in range(3):
  pts=[]
  for j,p in enumerate(path):a=T*(j/len(path)*12+s/3);pts.append(p+np.array([rr*.47*math.cos(a),0,rr*.47*math.sin(a)]))
  loop_tube(b,'closed-carrying-eye-three-ply-'+str(s),'rope',pts,rr*.53,9)
 return ['Three perpendicular sets of four real monkey-fist rope wraps, each made from three twisted plys','Separate tall continuous braided carrying eye; woven fibre PBR, no photo shadows baked']
def face_texture(out,mats,key,lines,back,ink=(229,220,176),size=1050):
 im=Image.new('RGB',(N,N),back);dr=ImageDraw.Draw(im)
 for j,line in enumerate(lines):dr.text((N/2,N*(.50+j*.32)),line,font=ImageFont.truetype(BOLD,size),anchor='mm',fill=ink)
 f=key+'-albedo-2k.png';im.save(out/f,optimize=True);mats[key]=dict(mats['paper'],baseColorTexture=f);return key
def frontbox(b,name,mat,w,h,d,x=0,y=0,z=0,r=.004):
 b.box(name,mat,w,d,h,0,r=r,bev=.00025);g=b.raw[-1];rotate(g,'x',math.pi/2);move(g,x=x,y=y+h/2,z=z-d/2)
def clock(b,w,h,d,kind,mats,out):
 calendar=kind==7
 frontbox(b,'rounded-closed-clock-case','cream_plastic'if calendar else'red_plastic',w,h*.94,d,x=0,y=0,r=h*.12)
 frontbox(b,'recessed-dark-brown-front-bezel','brown_plastic',w*.945,h*.84,.0035,y=h*.052,z=d*.509,r=h*.09)
 frontbox(b,'cream-face-surround'if not calendar else'reddish-calendar-front-panel','red_face'if calendar else'cream_plastic',w*.88,h*.73,.0018,y=h*.107,z=d*.533,r=h*.07)
 if not calendar:
  for j,(text,mat,co)in enumerate([('10','blue_card',(62,105,122)),('55','green_card',(51,99,80))]):
   x=(j-.5)*w*.38;ww=w*.275;hh=h*.51;cy=h*.50;zz=d*.55;face_texture(out,mats,'flip_'+text,[text],co,size=1750)
   frontbox(b,'individual-'+text+'-upper-flip-leaf',mat,ww,hh*.495,.001,x,cy,zz,r=.0007)
   frontbox(b,'individual-'+text+'-lower-flip-leaf',mat,ww,hh*.495,.001,x,cy-hh*.505,zz,r=.0007)
   O.front_texture(b,'printed-'+text+'-numerals','flip_'+text,ww,hh,cy-hh/2,zz+.0007,x)
   b.tube('visible-flip-card-midline-'+str(j),'brown_plastic',[(x-ww*.49,cy,zz+.0008),(x+ww*.49,cy,zz+.0008)],.0003,8)
   for s in[-1,1]:ellipsoid(b,'flip-leaf-hinge-'+str(j)+'-'+str(s),'chrome',(x+s*ww*.51,cy,zz),(.0008,.001,.001),20,10)
 else:
  for j,text in enumerate(['THU','5']):
   xx=-w*.31+j*w*.24;ww=w*.19;hh=h*.43;zz=d*.55;face_texture(out,mats,'calendar_'+text,[text],(223,215,175),ink=(43,93,83),size=850 if j==0 else 1400)
   frontbox(b,'separate-date-flip-panel-'+str(j),'brown_plastic',ww*1.09,hh*1.08,.0012,xx,h*.26,zz,r=.003);O.front_texture(b,'printed-calendar-'+text,'calendar_'+text,ww,hh,h*.48-hh/2,zz+.001,xx)
   b.tube('date-panel-physical-midline-'+str(j),'brown_plastic',[(xx-ww*.49,h*.48,zz+.0011),(xx+ww*.49,h*.48,zz+.0011)],.00027,8)
  im=Image.new('RGB',(N,N),(220,216,176));dr=ImageDraw.Draw(im)
  for j in range(12):
   a=T*j/12;dr.line((N/2+math.sin(a)*N*.35,N/2-math.cos(a)*N*.35,N/2+math.sin(a)*N*.42,N/2-math.cos(a)*N*.42),fill=(48,105,95),width=19)
  im.save(out/'analog-face-albedo-2k.png',optimize=True);mats['analog_face']=dict(mats['paper'],baseColorTexture='analog-face-albedo-2k.png');ww=w*.265;hh=h*.51;cx=w*.277;cy=h*.48;zz=d*.552;frontbox(b,'analog-clock-rounded-frame','brown_plastic',ww*1.07,hh*1.07,.0015,cx,cy-hh/2,zz,r=.004);O.front_texture(b,'twelve-analog-clock-dial-marks','analog_face',ww,hh,cy-hh/2,zz+.001,cx)
  for a,length,rad in[(-.45,hh*.30,.0013),(1.40,hh*.40,.0007)]:b.tube('physical-green-clock-hand-'+str(a),'teal',[(cx,cy,zz+.0015),(cx+math.sin(a)*length,cy+math.cos(a)*length,zz+.0015)],rad,8)
  ellipsoid(b,'clock-hand-centre-pivot','teal',(cx,cy,zz+.0017),(.002,.002,.001),24,12)
  for j in range(3):b.disc('separate-top-alarm-button-'+str(j),'teal',w*.082,h*.075,d*.28,h*.94);move(b.raw[-1],x=(j-1)*w*.285,z=-d*.06)
 # The clear front is a closed thin pane; its surface is not an environment photo.
 frontbox(b,'clear-protective-front-pane','glass',w*.90,h*.76,.0007,0,h*.09,d*.568,r=h*.065)
 frontbox(b,'rear-battery-compartment-cover','brown_plastic'if not calendar else'cream_plastic',w*.46,h*.48,.0015,0,h*.20,-d*.513,r=.004)
 for j in range(8):frontbox(b,'rear-vent-recess-'+str(j),'brown_plastic',w*.006,h*.16,.0003,(j-3.5)*w*.029,h*.63,-d*.516,r=.0002)
 for sx in[-1,1]:
  for sy in[.18,.75]:ellipsoid(b,'rear-fastener-'+str(sx)+'-'+str(sy),'chrome',(sx*w*.40,sy*h,-d*.513),(.001,.001,.0004),16,8)
 for x in[-w*.32,w*.32]:b.box('small-rubber-foot','rubber',w*.14,.002,d*.67,-.001,x,0,r=.001,bev=.0002)
 return ['Rounded coloured housing, layered brown bezel, separate printed mechanical flip leaves and visible centre seams','Three teal top alarm controls, separate analog clock hands and date/day flaps'if calendar else'Blue hour and green minute cards with cream 10:55 digits, individual leaf pivots','Clear physical front pane, rear battery cover, vent slots, fasteners and rubber feet','Official three lengths preserved; raw axis labels are inconsistent with photographed upright clock pose and are explicitly remapped']
def magnetic_board(b,w,h,d):
 t=min(w,h)*.016;b.box('magnetic-steel-face','steel_face',w-t*1.5,h-t*1.5,d*.35,t*.75,z=0,r=.0006,bev=.0002)
 for sx in[-1,1]:b.box('vertical-warm-wood-frame-'+str(sx),'wood',t,h,d,0,x=sx*(w-t)/2,r=.0008,bev=.00025)
 for sy in[0,h-t]:b.box('horizontal-warm-wood-frame-'+str(sy),'wood',w-2*t,t,d,sy,r=.0008,bev=.00025)
 return ['Thin warm wood edge frame surrounding a separate pale grey magnetic steel face','Three official board sizes; photographed notes and magnets are removable props and are excluded']
def ashtray(b,w,h,d,stepped):
 # Both are genuine closed hollow receptacles, with an independent closed lid.
 rx=w/2;rz=d/2
 if stepped:pr=[(0,.72),(h*.04,.86),(h*.12,.91),(h*.17,.93),(h*.22,.87),(h*.28,.98),(h*.36,1),(h*.43,.96),(h*.47,.89),(h*.53,.96),(h*.62,.98),(h*.69,.88),(h*.77,.79),(h*.84,.75)]
 else:pr=[(0,.55),(h*.04,.72),(h*.15,.89),(h*.34,.99),(h*.48,1),(h*.63,.95),(h*.76,.84),(h*.84,.66)]
 n=128;outer=[(y,[(rx*r*math.cos(a),rz*r*math.sin(a))for a in np.linspace(0,T,n,endpoint=False)])for y,r in smooth(pr,4)]
 rtop=pr[-1][1];inner=[(h*.84,[(rx*(rtop-.05)*math.cos(a),rz*(rtop-.05)*math.sin(a))for a in np.linspace(0,T,n,endpoint=False)]),(h*.13,[(rx*.60*math.cos(a),rz*.60*math.sin(a))for a in np.linspace(0,T,n,endpoint=False)])]
 b.solid('stepped-round-chrome-hollow-ash-chamber'if stepped else'smooth-oval-chrome-hollow-ash-chamber','chrome',outer+inner)
 b.disc('separate-close-fitting-round-lid'if stepped else'separate-close-fitting-oval-lid','chrome',w*rtop*.96,h*.045,d*rtop*.96,h*.842)
 # Delicate butterfly hinge/handle is present on both exact galleries.
 hx=0;hz=d*.29;hy=h*.90
 b.tube('short-lid-hinge-axle','chrome',[(-w*.115,hy,hz),(w*.115,hy,hz)],h*.025,12)
 for sx in[-1,1]:
  ellipsoid(b,'butterfly-hinge-curved-wing-'+str(sx),'chrome',(sx*w*.085,hy+h*.023,hz+d*.018),(w*.095,h*.025,d*.035),32,16)
  b.tube('hinge-bracket-'+str(sx),'chrome',[(sx*w*.08,h*.81,hz-d*.015),(sx*w*.08,hy+h*.02,hz+d*.045)],h*.018,10)
 return ['Actual tiered concentric chrome body'if stepped else'Actual smooth low oval chrome body','Hollow ash chamber and separate closed fitted lid; tiny butterfly hinge, two curved wings and physical axle','Two official sizes; metal reflections are computed by the renderer, never baked from the source photograph']
def hourglass(b,w,h,d):
 r=w/2;eps=.0007;keys=[(0,r*.83),(h*.018,r*.94),(h*.06,r),(h*.29,r),(h*.37,r*.76),(h*.46,r*.20),(h*.50,r*.055),(h*.54,r*.20),(h*.63,r*.76),(h*.71,r),(h*.94,r),(h*.982,r*.94),(h,r*.83)]
 outer=smooth(keys,6);inner=[(y,max(.0002,rr-eps))for y,rr in outer[::-1]if y>eps and y<h-eps];b.bottle('closed-thin-wall-hourglass-glass-envelope','glass',outer+inner,facets=128)
 # Black sand in the upper bulb narrows to the real constricted neck.
 upper=[(h*.50,.00015),(h*.53,r*.13),(h*.61,r*.57),(h*.68,r*.87),(h*.76,r*.94)];b.bottle('upper-inverted-black-sand-cone','sand',smooth(upper,4),facets=96)
 bottom=[(h*.024,r*.78),(h*.05,r*.88),(h*.12,r*.78),(h*.20,r*.35),(h*.23,.0002)];b.bottle('lower-black-sand-pile','sand',smooth(bottom,4),facets=96);b.tube('fine-falling-sand-stream','sand',[(0,h*.23,0),(0,h*.50,0)],.00022,10)
 return ['Continuous clear hourglass wall with a narrow physical waist and capped thick glass ends','Separate upper black sand cone, lower sand pile and fine falling sand stream','Three genuine official sizes; no external frame or invented support']
def twist_path(b,name,path,r,turns=22):
 points=np.asarray(path);dist=np.r_[0,np.cumsum(np.linalg.norm(np.diff(points,axis=0),axis=1))];length=dist[-1];count=max(50,int(length/.0013));pp=np.column_stack([np.interp(np.linspace(0,length,count),dist,points[:,k])for k in range(3)])
 for s in range(2):
  out=[]
  for j,p in enumerate(pp):
   t=pp[min(j+1,len(pp)-1)]-pp[max(j-1,0)];t/=np.linalg.norm(t);nn=np.cross(t,[0,0,1])
   if np.linalg.norm(nn)<.01:nn=np.cross(t,[0,1,0])
   nn/=np.linalg.norm(nn);bb=np.cross(t,nn);a=T*(j/(count-1)*turns+s/2);out.append(p+r*.6*(nn*math.cos(a)+bb*math.sin(a)))
  loop_tube(b,name+'-twisted-wire-'+str(s),'black_metal',out,r*.61,8,False)
def display_stand(b,w,h,d,twisted):
 if twisted:
  r=min(w,h)*.012
  for sx in[-1,1]:twist_path(b,'triangular-side-'+str(sx),[(sx*w*.47,r,d*.43),(sx*w*.47,h*.99,-d*.34),(sx*w*.47,r,-d*.47),(sx*w*.47,r,d*.43)],r,24)
  twist_path(b,'front-book-rest-crossbar',[(-w*.50,h*.06,d*.45),(w*.50,h*.06,d*.45)],r,20)
  for sx in[-1,1]:twist_path(b,'short-upturned-front-end-'+str(sx),[(sx*w*.47,h*.06,d*.45),(sx*w*.47,h*.12,d*.50)],r,3)
  return ['Two physically twisted wire triangle/A supports, continuous side braces and front book ledge','Three official small/medium/wide stand sizes retain their individual proportions']
 r=min(w,h)*.012
 # The back is one narrow inverted hairpin arch with rounded top.
 path=[(-w*.36,h*.02,-d*.28),(-w*.15,h*.87,-d*.46)]
 path += [(w*.15*math.cos(a),h*.87+h*.13*math.sin(a),-d*.46)for a in np.linspace(math.pi,0,30)[1:]]
 path +=[(w*.36,h*.02,-d*.28)];b.tube('single-rounded-inverted-hairpin-back','black_metal',path,r,12)
 for sx in[-1,1]:
  # Stamped flat strips bend continuously from long rear foot to upright stop.
  curve=[(sx*w*.43,h*.015,-d*.48),(sx*w*.43,h*.018,-d*.26),(sx*w*.43,h*.065,d*.18),(sx*w*.43,h*.16,d*.39),(sx*w*.43,h*.30,d*.43)]
  pp=[];extended=[np.array(curve[0])]+[np.array(p)for p in curve]+[np.array(curve[-1])]
  for j in range(len(curve)-1):
   p0,p1,p2,p3=extended[j:j+4]
   for t in np.linspace(0,1,12,endpoint=False):pp.append(.5*((2*p1)+(-p0+p2)*t+(2*p0-5*p1+4*p2-p3)*t*t+(-p0+3*p1-3*p2+p3)*t*t*t))
  pp.append(curve[-1]);ribbon(b,'curved-stamped-front-prong-'+str(sx),'black_metal',pp,w*.08,.0013)
  b.box('small-flat-top-stop-'+str(sx),'black_metal',w*.10,.0014,d*.035,h*.30,x=sx*w*.43,z=d*.43,r=.0005,bev=.00012)
 b.tube('low-transverse-tie','black_metal',[(-w*.43,h*.045,d*.22),(w*.43,h*.045,d*.22)],r*.65,10)
 return ['Single rounded hairpin backrest, two actual curved stamped flat feet/prongs with small end pads','Long rear support feet, low transverse tie and two official height variants']

# A small vectorised implicit mesher is used only for the two sculptural dog
# castings. It blends anatomically placed ellipsoids/capsules into one closed
# manifold, instead of intersecting generic boxes or disconnected primitive legs.
def ell_sdf(p,c,r):return (np.linalg.norm((p-np.array(c))/np.array(r),axis=-1)-1)*min(r)
def cap_sdf(p,a,b,r1,r2=None):
 a=np.array(a);v=np.array(b)-a;t=np.clip(np.einsum('...i,i->...',p-a,v)/np.dot(v,v),0,1);rr=r1 if r2 is None else r1+(r2-r1)*t
 return np.linalg.norm(p-a-t[...,None]*v,axis=-1)-rr
def smin(a,b,k):
 q=np.clip(.5+.5*(b-a)/k,0,1);return b*(1-q)+a*q-k*q*(1-q)
def marching_tetra(b,name,mat,field,bounds,step):
 lo=np.array(bounds[0]);hi=np.array(bounds[1]);shape=np.maximum(8,np.ceil((hi-lo)/step).astype(int)+1);axes=[np.linspace(lo[k],hi[k],shape[k])for k in range(3)];grid=np.stack(np.meshgrid(*axes,indexing='ij'),axis=-1);values=field(grid);print('implicit grid',name,shape.tolist(),flush=True)
 # A consistent six-tetrahedra split around the same cube body diagonal.
 offsets=np.array([[0,0,0],[1,0,0],[1,1,0],[0,1,0],[0,0,1],[1,0,1],[1,1,1],[0,1,1]])
 tets=[[0,1,2,6],[0,2,3,6],[0,3,7,6],[0,7,4,6],[0,4,5,6],[0,5,1,6]]
 flat=values.reshape(-1);nx,ny,nz=shape;cell=np.stack(np.meshgrid(np.arange(nx-1),np.arange(ny-1),np.arange(nz-1),indexing='ij'),axis=-1).reshape(-1,3)
 ids=(cell[:,0,None]+offsets[None,:,0])*(ny*nz)+(cell[:,1,None]+offsets[None,:,1])*nz+cell[:,2,None]+offsets[None,:,2];vv=[];ff=[];edge_cache={};points=grid.reshape(-1,3)
 for tet in tets:
  ti=ids[:,tet];vals=flat[ti];mask=np.any(vals<0,axis=1)&np.any(vals>0,axis=1);ti=ti[mask];vals=vals[mask]
  for row,fv in zip(ti,vals):
   inside=[k for k in range(4)if fv[k]<0];outside=[k for k in range(4)if fv[k]>0];poly=[]
   if len(inside)==1:edges=[(inside[0],j)for j in outside]
   elif len(inside)==3:edges=[(outside[0],j)for j in inside]
   else:edges=[(inside[0],outside[0]),(inside[0],outside[1]),(inside[1],outside[1]),(inside[1],outside[0])]
   for a,c in edges:
    ia,ic=sorted([int(row[a]),int(row[c])]);t=flat[ia]/(flat[ia]-flat[ic])
    # Snap crossings within two percent of a grid vertex to that vertex.
    # This removes sub-micron sliver triangles without making holes. All
    # incident tetrahedra share the same cache key and exact position.
    snap=None;key=('vertex',snap)if snap is not None else('edge',ia,ic)
    if key not in edge_cache:
     edge_cache[key]=len(vv);vv.append(points[snap]if snap is not None else points[ia]+t*(points[ic]-points[ia]))
    poly.append(edge_cache[key])
   outcentre=points[row[outside]].mean(axis=0);incentre=points[row[inside]].mean(axis=0);outdir=outcentre-incentre
   faces=[poly[:3]]if len(poly)==3 else[poly[:3],[poly[0],poly[2],poly[3]]]
   for face in faces:
    if len(set(face))<3:continue
    a,c,e=[vv[j]for j in face]
    if np.dot(np.cross(c-a,e-a),outdir)<0:face=[face[0],face[2],face[1]]
    ff.append(face)
 # Collapse only numerical isosurface slivers using the manifold link
 # condition. This changes no silhouette detail at the sampling scale.
 vv=np.asarray(vv);ff=np.asarray(ff,int)
 for iteration in range(1800):
  tri=vv[ff];area=np.linalg.norm(np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]),axis=1)/2;bad=np.where(area<2e-11)[0]
  if not len(bad):break
  collapsed=False
  for ix in bad:
   face=ff[ix];edges=[(int(face[j]),int(face[(j+1)%3]))for j in range(3)];edges.sort(key=lambda e:np.linalg.norm(vv[e[0]]-vv[e[1]]))
   for a,c in edges:
    fa=ff[np.any(ff==a,axis=1)];fc=ff[np.any(ff==c,axis=1)];common=set(np.unique(fa))&set(np.unique(fc));common-={a,c};adj=ff[np.any(ff==a,axis=1)&np.any(ff==c,axis=1)]
    opposite=set(np.unique(adj))-{a,c}
    if len(adj)!=2 or common!=opposite:continue
    ff[ff==c]=a;ff=ff[(ff[:,0]!=ff[:,1])&(ff[:,1]!=ff[:,2])&(ff[:,2]!=ff[:,0])];collapsed=True;break
   if collapsed:break
  if not collapsed:raise ValueError('No manifold-preserving sliver collapse')
 else:raise ValueError('Unresolved isosurface slivers')
 print('implicit mesh',name,len(vv),len(ff),'clean passes',iteration,flush=True)
 edges=np.sort(np.concatenate([ff[:,[0,1]],ff[:,[1,2]],ff[:,[2,0]]]),axis=1);counts=np.unique(edges,axis=0,return_counts=True)[1];assert(counts==2).all(),np.unique(counts,return_counts=True)
 raw_mesh(b,name,mat,vv,ff)
def dog_cast(b,w,h,d,cocker):
 def field(p):
  # Long axis is modelZ, matching source depth. The two casts have different
  # body/leg/head/ear/tail positions taken from their exact side galleries.
  if cocker:
   body=(np.sum(np.abs((p-np.array([0,h*.36,-d*.055]))/np.array([w*.40,h*.18,d*.34]))**3,axis=-1)**(1/3)-1)*min(w*.40,h*.18);neck=cap_sdf(p,(0,h*.42,d*.22),(0,h*.77,d*.31),w*.31,w*.29);head=ell_sdf(p,(0,h*.84,d*.34),(w*.34,h*.085,d*.14));snout=cap_sdf(p,(0,h*.84,d*.35),(0,h*.88,d*.49),w*.245,w*.07);k=h*.055
  else:
   body=(np.sum(np.abs((p-np.array([0,h*.38,-d*.035]))/np.array([w*.40,h*.145,d*.355]))**4,axis=-1)**.25-1)*min(w*.40,h*.145);neck=cap_sdf(p,(0,h*.34,d*.27),(0,h*.56,d*.33),w*.29,w*.34);head=ell_sdf(p,(0,h*.59,d*.35),(w*.34,h*.14,d*.10));snout=cap_sdf(p,(0,h*.58,d*.36),(0,h*.58,d*.495),w*.235,w*.045);k=h*.04
  f=smin(smin(smin(body,neck,k),head,k),snout,k*.5)
  for sx in[-1,1]:
   for z in[-d*.27,d*.20]:
    leg=cap_sdf(p,(sx*w*.24,h*.36,z),(sx*w*.27,h*.071,z+d*.012),w*.15,w*.135);f=smin(f,leg,k*.40)
   ear=ell_sdf(p,(sx*w*.30,h*(.49 if cocker else .44),d*(.265 if cocker else .316)),(w*.105,h*(.34 if cocker else .19),d*(.075 if cocker else .054)));f=smin(f,ear,k*.35)
  tail=[(0,h*.51,-d*.34),(0,h*.69,-d*.43),(0,h*.95,-d*.48)]
  for j,(a,c)in enumerate(zip(tail,tail[1:])):f=smin(f,cap_sdf(p,a,c,w*(.14 if j==0 else .075),w*(.075 if j==0 else .013)),k*.35)
  # Flat cast contact patches; retain closed separation between all four feet.
  return np.maximum(f,h*.012-p[...,1])
 marching_tetra(b,'single-blended-cocker-casting'if cocker else'single-blended-dachshund-casting','black_cast',field,[[-w*.65,-h*.03,-d*.58],[w*.65,h*1.08,d*.59]],min(w/31,h/64,d/100))
 return ['One closed blended black cast sculpture with four distinct short legs and flattened contact feet','Raised head, tapered pointed snout, very long hanging ears, saddle-like back and upward tail'if cocker else'Exceptionally long low torso, short legs, elongated low snout, drooping ears and upright pointed tail','Surface relief is intrinsic cast texture; no invented painted eyes or photographic highlights']
def cloth_dog(b,w,h,d):
 # Filled sewn body: broad torso, tall head and long cylindrical snout.
 ellipsoid(b,'filled-linen-long-torso','linen',(0,h*.38,-d*.07),(w*.44,h*.25,d*.31))
 b.solid('filled-sewn-soft-square-head','linen',[(y,O.base.perimeter(ww,dd,min(ww,dd)*.31,12))for y,ww,dd in[(h*.49,w*.57,d*.22),(h*.56,w*.80,d*.29),(h*.88,w*.84,d*.30),(h*.97,w*.62,d*.23)]],center=(0,0,d*.245))
 ellipsoid(b,'long-rounded-canvas-muzzle','linen',(0,h*.72,d*.385),(w*.34,h*.125,d*.14))
 ellipsoid(b,'black-rounded-fabric-nose','black_fabric',(0,h*.74,d*.508),(w*.20,h*.075,d*.025))
 for sx in[-1,1]:
  for zz in[-d*.27,d*.16]:
   b.solid('flat-footed-stuffed-canvas-leg-'+str(sx)+'-'+str(zz),'linen',[(yy,O.base.perimeter(ww,dd,min(ww,dd)*.38,12))for yy,ww,dd in[(0,w*.24,d*.12),(h*.025,w*.29,d*.145),(h*.29,w*.28,d*.145),(h*.34,w*.23,d*.115)]],center=(sx*w*.285,0,zz))
   # Seams around the small foot's actual flat-ended stuffed profile.
   pp=[(sx*w*.285+w*.145*math.cos(a),h*.055,zz+d*.072*math.sin(a))for a in np.linspace(0,T,72,endpoint=False)];loop_tube(b,'stitched-foot-edge','stitch',pp,.00042,7)
  ellipsoid(b,'separate-hanging-floppy-ear-'+str(sx),'linen',(sx*w*.39,h*.70,d*.235),(w*.10,h*.24,d*.09))
  pp=[(sx*w*.475,h*.70+h*.225*math.cos(a),d*.235+d*.083*math.sin(a))for a in np.linspace(0,T,96,endpoint=False)];loop_tube(b,'ear-edge-piping-'+str(sx),'stitch',pp,.00055,8)
  ellipsoid(b,'small-black-button-eye-'+str(sx),'black_fabric',(sx*w*.395,h*.84,d*.323),(w*.036,h*.028,d*.016),32,16)
  pp=[(sx*w*.29,h*(.52+.44*t),d*(.36-.10*t))for t in np.linspace(0,1,36)];b.tube('head-panel-sewn-seam-'+str(sx),'stitch',pp,.00045,8)
 b.tube('upright-stuffed-tail','linen',[(0,h*.54,-d*.29),(0,h*.73,-d*.34),(0,h*.91,-d*.35)],w*.049,14)
 # Neck band is physical; front triangle and two tails show the actual plaid.
 torus(b,'plaid-neck-collar','plaid',w*.36,.007,(0,h*.55,d*.20),'y')
 poly=[(-w*.35,h*.55),(w*.35,h*.55),(w*.16,h*.29),(-w*.18,h*.33)]
 extrude(b,'hanging-plaid-bandana-front','plaid',poly,.001,axis='z',center=(0,0,d*.325))
 for sx in[-1,1]:extrude(b,'short-bandana-tied-end-'+str(sx),'plaid',[(sx*w*.32,h*.53),(sx*w*.51,h*.49),(sx*w*.46,h*.39),(sx*w*.29,h*.48)],.001,axis='z',center=(0,0,d*.20))
 return ['Stuffed linen dog with long muzzle, rounded black fabric nose, four padded legs and upright tail','Two hanging separate piped ears, small black button eyes, head-panel and foot seams','Actual navy/brown/yellow plaid neck bandana, hanging front and tied ends; no generic block proxy']
def pin(b,w,h,d,variant=0):
 # One measured item from the four-piece set. Four photographed head forms
 # are generated as form variants of the same SKU, never as invented SKUs.
 yy=h*.84;stem=h*.84;mat='copper'if variant<2 else'chrome'
 b.tube('long-silver-needle-shaft','chrome',[(0,.00025,0),(0,stem,0)],w*.024,10)
 if variant in[0,2]:
  n=80;cont=[(w*.49*(1+.13*math.sin(3*a)+.07*math.cos(5*a))*math.cos(a),h*.085*math.sin(a))for a in np.linspace(0,T,n,endpoint=False)]
 else:
  n=80;cont=[(w*.43*(1+.17*math.sin(2*a))*math.cos(a),h*.065*math.sin(a))for a in np.linspace(0,T,n,endpoint=False)]
 # Handformed petal head has a shallow folded/dished upper surface.
 rings=[]
 for t in[.05,.28,.60,.88,1]:rings.append((d*(.20+.14*t),[(x*t,yy+y*t)for x,y in cont]))
 for t in[1,.88,.60,.28,.05]:rings.append((d*(.43+.11*t),[(x*t,yy+y*t)for x,y in cont]))
 b.solid('irregular-handformed-petal-head-'+str(variant+1),mat,rings,axis='z')
 if variant in[0,2]:b.tube('small-silver-protective-tip-cap','chrome',[(0,.0003,0),(0,h*.039,0)],w*.038,10)
 return ['One measured silver-shaft pin from the four-piece Studio Mary Lennox set','Distinct photographed '+('copper'if variant<2 else'silver')+' irregular folded petal head, long needle shaft'+(' and protective cap'if variant in[0,2]else''),'Official dimensions apply to one pin; sold quantity4. Form variants share one actualSKU and do not create new product identities']
def album(b,w,h,d):
 ct=h*.12;b.box('lower-linen-hard-cover','linen',w,ct,d,0,r=.001,bev=.0002);b.box('cream-photograph-paper-leaf-block','paper',w*.97,h*.74,d*.975,ct,r=.0006,bev=.00015);b.box('upper-plain-linen-hard-cover','linen',w,ct,d,h-ct,r=.001,bev=.0002);b.box('linen-covered-bound-spine','linen',w*.045,h,d,0,x=-w*.477,r=.0007,bev=.0002)
 for j in range(18):b.box('visible-layered-leaf-edge-'+str(j),'page_edge',w*.968,.000055,.00018,ct+h*.73*j/18,z=d*.488,r=.00002,bev=.000005)
 return ['Plain beige linen hard covers and covered spine; no invented title label','Separate thick cream photo-paper block and physical layered leaf edges; shown flat with explicit source-axis mapping']
def ball(b,w,h,d):
 ellipsoid(b,'solid-stone-effect-ceramic-orb','stone_ceramic',(0,h*.49,0),(w*.5,h*.51,d*.5),128,64)
 # Flat contact is produced by the final analytic profile rather than an opening.
 g=b.raw[-1];g['_vertices']=[(x,max(0,y),z)for x,y,z in g['_vertices']]
 return ['Solid closed off-white ceramic orb with a small flat contact base','Restrained mottled stone-like albedo and shallow intrinsic fired surface pits; no opening']
def bookend(b,w,h,d):
 t=w*.085;b.box('tall-transverse-back-plate','terracotta',w,h,t,0,z=-d*.45,r=.006,bev=.002)
 # Side silhouette: tall at the rear, softly stepped down at the front.
 profile=[(0,-d*.43),(h,-d*.43),(h,d*.08)]
 for a in np.linspace(math.pi/2,0,18)[1:]:profile.append((h*.76+h*.24*math.sin(a),d*.08+d*.34*math.cos(a)))
 profile +=[(h*.12,d*.42),(h*.04,d*.38),(0,d*.31)]
 extrude(b,'perpendicular-stepped-front-ceramic-plate','terracotta',profile,t,'x')
 # The real inset panel follows the front support's stepped/arched shoulder.
 inset=[(h*.09,-d*.31),(h*.89,-d*.31),(h*.89,d*.06)]
 inset +=[(h*.69+h*.20*math.sin(a),d*.06+d*.26*math.cos(a))for a in np.linspace(math.pi/2,0,20)[1:]]
 inset +=[(h*.12,d*.32),(h*.09,-d*.31)]
 for sx in[-1,1]:loop_tube(b,'soft-inset-arched-panel-bead-'+str(sx),'terracotta',[(sx*t*.51,y,z)for y,z in inset[:-1]],.0011,10)
 return ['Actual glossy terracotta T-shaped bookend: broad tall rear plate plus perpendicular central projecting plate','Rounded stepped/arched front shoulder and inset relief panel on both faces; no generic L-shaped proxy']
def ceramic_vessel(b,w,h,d,footed):
 n=192;angles=np.linspace(0,T,n,endpoint=False)
 if footed:
  # Separate flared ring foot and shallow flared cup. Real wall/floor, no cap.
  b.bottle('separate-flared-pedestal-foot','ceramic',smooth([(0,w*.20),(h*.035,w*.20),(h*.20,w*.115),(h*.33,w*.10)],4)+[(h*.29,w*.07),(h*.03,w*.17)],facets=128)
  profile=[(h*.28,.095),(h*.32,.16),(h*.44,.24),(h*.68,.38),(h*.96,.50),(h,.495),(h*.985,.48),(h*.87,.454),(h*.65,.34),(h*.45,.20),(h*.36,.10)]
 else:
  profile=[(0,.27),(h*.04,.34),(h*.16,.40),(h*.53,.47),(h*.91,.50),(h,.498),(h*.97,.481),(h*.82,.477),(h*.35,.405),(h*.15,.27)]+[(h*.15+.00025*math.sin(T*r*31),r)for r in np.linspace(.26,.015,50)]
 rings=[]
 for j,(y,r)in enumerate(profile):
  contour=[]
  for a in angles:
   irregular=1+(.010 if footed else .024)*math.sin(3*a+.4)+(.006 if footed else .015)*math.cos(5*a+.8)+(.003 if footed else .008)*math.sin(9*a)
   # Wheel-thrown concentric grooves are restrained physical relief.
   contour.append((w*r*irregular*math.cos(a),d*r*irregular*math.sin(a)))
  rings.append((y,contour))
 b.solid('hollow-footed-shallow-ceramic-cup'if footed else'handformed-irregular-enameled-ceramic-tray','ceramic'if footed else'tray_glaze',rings)
 if not footed:
  g=b.raw[-1];g['_vertices']=[(x,y+h*.035*(min(1,math.hypot(x/(w/2),z/(d/2)))**4)*(math.sin(5*math.atan2(z,x))+.4*math.cos(9*math.atan2(z,x))),z)for x,y,z in g['_vertices']]
 return ['Shallow flared hollow ceramic cup, rolled slightly asymmetric rim and separate flared foot'if footed else'Handformed irregular round shallow ceramic tray with uneven wavy contour and restrained throwing rings','Actual glazed cream fired surface with sparse intrinsic speckles; closed floor, true inner wall and soft rim','All official size variants retained separately']
def prepare_plan():
 out=[]
 for p in PLAN:
  p=dict(p);i=p['category_card_indices'][0]
  if i==6:p.update(dimensions_cm=[18.,10.,7.],display_pose='upright_photo_axis_permutation',axis_mapping='modelX=sourceH; modelY=sourceD; modelZ=sourceW',axis_ambiguity=True,axis_inference='Official labelled axes conflict with the landscape clock photos. All three official lengths are retained, permuted to the photographed upright pose.')
  elif i==7:p.update(dimensions_cm=[19.,11.,6.],display_pose='upright_photo_axis_permutation',axis_mapping='modelX=sourceH; modelY=sourceW; modelZ=sourceD',axis_ambiguity=True,axis_inference='Official labelled H/W conflict with the landscape clock photos. All three official lengths are retained, permuted to the photographed upright pose.')
  elif i==16:
   hh,ww,dd=p['source_dimensions_hwd_cm'];p.update(dimensions_cm=[ww,dd,hh],display_pose='upright_photo_axis_permutation',axis_mapping='modelX=sourceW; modelY=sourceD; modelZ=sourceH',axis_ambiguity=True,axis_inference='Source H and W describe equal round face lengths; the shorter D matches physical height in both gallery sizes. Official lengths are permuted to the pictured lidded ashtray pose.')
  # Four head forms, one measured pinSKU. Each is explicitly a single-pin
  # variant, not an invented four-pin assembly with a fabricated pack box.
  if i==38:
   for j in range(4):q=dict(p,id=p['id']+'-head-'+str(j+1),form_variant=j+1,measurement_scope='one_pin',sold_quantity=4,form_variant_group=p['sku']);out.append(q)
  else:out.append(p)
 dump(R/'production-plan.json',out);return out
MATERIAL_LABEL={5:'Halat',6:'Geri dönüştürülmüş ABS plastik · şeffaf koruyucu ön yüz · metal',7:'Plastik · şeffaf koruyucu ön yüz · metal',13:'Ahşap kenar · manyetik metal',16:'Krom kaplama pirinç',18:'Krom kaplama pirinç',24:'Cam · siyah kum',25:'Örgülü metal tel',26:'Alüminyum',28:'Alüminyum',34:'Keten · geri dönüştürülmüş polyester · dolgu · düğme',35:'Siyah metal',38:'Bakır/gümüş renkli metal',41:'Keten · sert kapak · kâğıt',42:'Taş efektli seramik',47:'Sırlı seramik',48:'Sırlı seramik',49:'Emaye seramik'}
def geometry(p,mats,out):
 b=B();w,h,d=np.array(p['dimensions_cm'])/100;i=p['category_card_indices'][0]
 if i==5:f=rope_doorstop(b,w,h,d)
 elif i in[6,7]:f=clock(b,w,h,d,i,mats,out)
 elif i==13:f=magnetic_board(b,w,h,d)
 elif i in[16,18]:f=ashtray(b,w,h,d,i==16)
 elif i==24:f=hourglass(b,w,h,d)
 elif i in[25,35]:f=display_stand(b,w,h,d,i==25)
 elif i in[26,28]:f=dog_cast(b,w,h,d,i==26)
 elif i==34:f=cloth_dog(b,w,h,d)
 elif i==38:f=pin(b,w,h,d,p['form_variant']-1)
 elif i==41:f=album(b,w,h,d)
 elif i==42:f=ball(b,w,h,d)
 elif i==47:f=bookend(b,w,h,d)
 elif i in[48,49]:f=ceramic_vessel(b,w,h,d,i==48)
 else:raise ValueError('No generic fallback: '+str(i))
 return b.raw,f
def main():
 plans=prepare_plan();only=set(sys.argv[1:]);bankdir,spec=bank();manifest=json.loads((R/'manifest.json').read_text())if only and(R/'manifest.json').exists()else[]
 for p in plans:
  i=p['category_card_indices'][0]
  if only and p['id']not in only and str(i)not in only:continue
  mats={k:dict(v)for k,v in spec.items()};raw,features=geometry(p,mats,bankdir);meshes,gqa=O.finish(raw,p['dimensions_cm']);gqa.update(O.validate(meshes,p),photographed_features=features);out=R/'models'/p['id'];out.mkdir(parents=True,exist_ok=True);mats={k:mats[k]for k in{m['material']for m in meshes}};maps=[]
  for mat in mats.values():
   for slot in['baseColorTexture','normalTexture','metallicRoughnessTexture']:
    src=bankdir/mat[slot];dst=out/src.name
    if not dst.exists()or sha(src)!=sha(dst):shutil.copyfile(src,dst)
    maps.append(dict(file=dst.name,resolution=[N,N],sha256=sha(dst)))
  md={k:v for k,v in p.items()if k not in['official_product_text']};md.update(category='Dekoratif aksesuarlar',material_label=MATERIAL_LABEL[i],estimated_dimensions=False,units='metres',up_axis='Y',origin='bottom bounding-box centre',scale_note='Ham resmî H/W/D korunur. Yerel duvar kalınlığı, birleşim, kıvrım, dikiş, küçük mekanizma ayrıntıları ve fiziksel gösterim pozu tam ürün galerilerinden yorumlanmıştır.',profile_family={5:'monkey_fist_rope',6:'red_flip_clock',7:'calendar_alarm_clock',13:'wood_framed_magnetic_panel',16:'stepped_chrome_ashtray',18:'oval_chrome_ashtray',24:'black_sand_hourglass',25:'twisted_wire_display_stand',26:'cast_cocker',28:'cast_dachshund',34:'linen_dog_doorstop',35:'stamped_metal_display_stand',38:'mary_lennox_decorative_pin',41:'plain_linen_photo_album',42:'stone_ceramic_orb',47:'t_shaped_ceramic_bookend',48:'footed_shallow_ceramic_bowl',49:'irregular_enameled_tray'}[i],photo_specific_features=features,photographed_features=features,photo_pixels_baked=False,photo_derived_printed_artwork=False,baked_reflections=False,local_dimensions_photo_inferred=True,model_revision='complete-decorative-accessories-photo-specific-v1',packaging_excluded=True)
  model=out/'model.json';dump(model,dict(metadata=md,materials=mats,meshes=meshes));dump(out/'geometry-validation.json',gqa);dump(out/'material-validation.json',dict(valid=True,native_resolution=N,maps=maps,photo_master_unchanged=True,intrinsic_maps=True));rep=O.export_assets(model,out,p['id']);glb=out/(p['id']+'.glb');doc,binary=O.read_glb(glb);doc['samplers']=[dict(magFilter=9729,minFilter=9987,wrapS=10497,wrapT=10497)]
  for tex in doc.get('textures',[]):tex['sampler']=0
  O.write_glb(glb,doc,binary);assert glb.stat().st_size<40_000_000;rep['deliverable_sha256']['glb']=sha(glb);rep['glb_bytes']=glb.stat().st_size;dump(Path(rep['files']['validation']),rep);embedded=[]
  for im in doc['images']:
   view=doc['bufferViews'][im['bufferView']];off=view.get('byteOffset',0);data=binary[off:off+view['byteLength']];px=Image.open(io.BytesIO(data));assert px.size==(N,N)and px.format=='PNG';embedded.append(dict(name=im.get('name'),resolution=[N,N],embedded=True,format='PNG',sha256=hashlib.sha256(data).hexdigest()))
  eq=out/'embedded-texture-validation.json';dump(eq,dict(valid=True,images=embedded,glb_version=2,all_textures_embedded=True));e={**md,'model_path':str(model),'asset_dir':str(out),'glb_path':str(glb),'bytes':glb.stat().st_size,'sha256':sha(glb),'triangles':gqa['triangles'],'geometry_validation':str(out/'geometry-validation.json'),'material_validation':str(out/'material-validation.json'),'embedded_texture_validation':str(eq)};manifest=[q for q in manifest if q['id']!=e['id']]+[e];order={p['id']:j for j,p in enumerate(plans)};manifest.sort(key=lambda e:order.get(e['id'],order.get(e['id']+'-head-1',999)));dump(R/'manifest.json',manifest);print(p['id'],e['profile_family'],e['bytes'],e['triangles'],flush=True)
 assert all(sha(p['local_master'])==p['sha256']for p in REF);dump(R/'batch-validation.json',dict(valid=True,models_ready=len(manifest),planned=len(plans),unique_actual_skus=len({e['sku']for e in manifest}),total_glb_bytes=sum(p['bytes']for p in manifest),maximum_glb_bytes=max(p['bytes']for p in manifest),original_photo_files=len(REF),source_photo_hashes_unchanged=True));print('COMPLETE',len(manifest),'models',flush=True)
if __name__=='__main__':main()
