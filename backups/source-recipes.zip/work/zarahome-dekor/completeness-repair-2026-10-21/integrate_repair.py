"""Replace reviewed cushions, append uncapped models, expose full observed inventory."""
from pathlib import Path
from urllib.parse import urlsplit,parse_qs
import copy,hashlib,importlib.util,json,re,shutil,sys,base64,gzip
P=Path(__file__).resolve().parent;WORK=P.parent;ROOT=WORK.parents[1]
SITE=ROOT/'sites/zarahome-vazo-kutuphanesi-final-378'
sys.path.insert(0,str(WORK))
from pack_catalog import source_provenance
from axis_provenance import apply_axis_provenance
def module(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
append=module('repair_append',WORK/'objects/site_workflow.py');append.HERE=P
validate=module('repair_validate',WORK/'candles/site_workflow.py').validate
audit=module('repair_topology',WORK/'objects/audit_geometry.py').check
def read(p):return json.loads(Path(p).read_text())
def write(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
SLUGS={'Yan sehpalar':'yan-sehpalar','Tabureler':'tabureler','Sandalyeler':'sandalyeler','Banklar':'banklar','Puflar':'puflar','Kırlentler':'kirlentler','Halılar':'halilar','Oturma odası halıları':'oturma-odasi-halilari','Çubuklu oda kokuları':'oda-kokulari','Dekoratif mumlar':'dekoratif-mumlar','Havluluk ve askılar':'havluluk-askilar','Masaüstü aksesuarları':'masaustu','Vazolar':'vazolar','Dekoratif sepetler':'sepetler','Dekoratif saksılar':'saksilar','Dekoratif kutular':'kutular','Dekoratif aynalar':'aynalar','Fotoğraf çerçeveleri':'cerceveler','Dekoratif aydınlatma':'aydinlatma','Dekoratif aksesuarlar':'dekoratif-aksesuarlar','Mumluk ve şamdanlar':'mumluklar','Dekoratif kaseler':'kaseler','Dekoratif tepsiler':'tepsiler','Dekoratif objeler':'objeler','Dekoratif fenerler':'fenerler'}
def images(items,title):
 unique={}
 for raw in items:
  i=dict(url=raw,alt=title)if isinstance(raw,str)else raw
  if not i.get('url'):continue
  u=urlsplit(i['url'])
  if u.scheme!='https' or u.netloc!='static.zarahome.net' or '-r/'in u.path:continue
  width=max([int(v)for v in parse_qs(u.query).get('w',['0'])if v.isdigit()]or[0])
  if width and width<640:continue
  if u.path not in unique or width>unique[u.path][0]:unique[u.path]=(width,i)
 result=[dict(url=i['url'],thumbnail_url=i['url'],source_url=i.get('source_url',i['url']),alt=i.get('alt')or title,photo_type='official_product_gallery')for _,i in unique.values()]
 return result
PUBLIC_GALLERY_ROWS=read(P/'live-product-details-from-root.json')
def gallery_images(e):
 # A zoom overlay may also expose related products. Only retain photos with
 # the exact image-family code already verified in this model's own sources.
 selected=e['source_images'];families=set()
 for image in selected:
  match=re.search(r'/(\d{11})[-/.]',image['url'])
  if match:families.add(match.group(1))
 extras=[]
 for row in PUBLIC_GALLERY_ROWS:
  if row.get('sku')!=e['sku']:continue
  for image in row.get('gallery_images',[]):
   match=re.search(r'/(\d{11})[-/.]',image['url'])
   if match and match.group(1)in families:extras.append(image)
 # Keep a selected full-product view first. A detail-only donor should not
 # hide the source product's primary photograph in the comparison panel.
 detail_only=all(re.search(r'-a[4-9](?:\.|/)',image['url'])for image in selected)
 primary=[image for image in extras if re.search(r'-p1(?:\.|/)',image['url'])]
 return images((primary if detail_only else[])+selected+extras,e['name'])
def catalog_record(e):
 fields=('id','name','sku','url','category','dimensions_cm','source_dimensions_hwd_cm','material_label','estimated_dimensions','size_source_kind','size_source_urls','source_market','scale_note','source_anomalies','availability','axis_ambiguity','photo_derived_fabric','official_cover_dimensions_cm','estimated_axes','scene_variants','default_scene_index','set_quantity','quality_status','quality_note','quality_label','official_body_dimensions_cm')
 d={k:e[k]for k in fields if k in e};d.update(glb_url='/models/'+e['id']+'.glb?v='+e['sha256'],reference_images=gallery_images(e),reference_photo_scope='product_family',reference_source_url=e['url'],reference_observed_date='2026-10-21');assert d['reference_images'],e['id'];return d
def code(url):
 m=re.search(r'/(4\d{10})(?:\d{2})?[-/]',url);return m.group(1)if m else None
def official_sku(value):return value if re.fullmatch(r'\d{4}/\d{3}/\d{3}',value or'')else None
def get_models(manifest):
 d=read(manifest);return d if isinstance(d,list)else d.get('models',d.get('products'))

def main():
 baseline=read(P/'baseline-409.json');oldids={e['id']for e in baseline['manifest']['models']};assert len(oldids)==409
 entries=[];input_paths=[Path(s)for s in sys.argv[1:]]
 for p in input_paths:entries+=get_models(p)
 assert len(entries)==len({e['id']for e in entries})
 material_labels={'6195':'Kadife döşeme · Ahşap ayaklar','6196':'Pamuk ve keten dokulu döşeme · Ahşap ayaklar','8323':'Soluk efektli keten döşeme · Ahşap ayaklar','8347':'Soluk efektli keten kılıf · Ahşap ayaklar','1365':'Deri döşeme · Ahşap taban'}
 pillow_labels={'short fur':'Kısa tüylü kumaş','long fur':'Uzun tüylü kumaş','embroidery':'İşlemeli kumaş','block print':'Blok baskılı kumaş','leaf embroidery':'Yaprak işlemeli kumaş','floral print':'Çiçek baskılı kumaş','velvet':'Kadife kumaş','tufted':'Kabartma dokulu kumaş','crossstitch':'Kanaviçe işlemeli kumaş','jacquard':'Jakarlı kumaş','wool stripe':'Yün dokulu çizgili kumaş','fine stripe':'İnce çizgili dokuma','slub':'Düzensiz iplikli dokuma','embroidered panel':'İşlemeli dokuma panel','linen':'Keten dokulu kumaş','tufted border':'Kabartma kenarlı kumaş','gathered quilt':'Büzgülü kapitone kumaş','stripe':'Çizgili dokuma','knit center':'Örgü dokulu kumaş','chenille':'Şönil kumaş','artwork':'Desenli dokuma','bolster':'Dokuma kumaş · Silindir biçimi','knit double horizontal':'Çift yatay örgü detaylı kumaş','knit single horizontal':'Yatay örgü detaylı kumaş','velvet stripe':'Çizgili kadife','knit':'Örgü kumaş','quilted mat':'Kapitone kumaş','chair pad':'Dokuma kumaş · Sandalye minderi'}
 stool_labels={'blackrubber':'Siyah kauçuk pabuçlar','satinsteel':'Mat paslanmaz çelik','multistrip':'Çok renkli boyalı ahşap','stoolbrown':'Kahverengi boyalı ahşap','stoolblack':'Siyah boyalı ahşap','leather':'Deri döşeme','leatheredge':'Deri kenar','polished':'Parlak paslanmaz çelik','lightash':'Dişbudak ahşap','rusticelm':'Rustik karaağaç','darkwood':'Koyu ahşap','linen':'Keten kumaş','rush':'Saz örgü','creammetal':'Krem boyalı metal','stepoak':'Meşe ahşap','wornwood':'Eskitilmiş ahşap','threadsteel':'Çelik ayar mili'}
 for e in entries:
  e['category']={'Sepetler':'Dekoratif sepetler','Aydınlatma':'Dekoratif aydınlatma'}.get(e['category'],e['category'])
  e['name']=e['name'].replace('studıo mary lennox','Studio Mary Lennox').replace('kılııfı','kılıfı')
  e['name']=re.sub(r'kıl[ıi]+fı','kılıfı',e['name']).replace('kılıısı','kılıfı').replace('prınt','print').replace('anımal','animal').replace('tuftıng','tufting').replace('Tuftıng','Tufting').replace('katharıne pole','Katharine Pole').replace('Katharıne pole','Katharine Pole').replace('Xxl ','XXL ')
  if e['category']=='Puflar'and e['sku'].split('/')[0]in material_labels:e['material_label']=material_labels[e['sku'].split('/')[0]]
  if e['category']=='Kırlentler'and e.get('material_label')in pillow_labels:e['material_label']=pillow_labels[e['material_label']]
  if e['category']=='Tabureler':e['material_label']=' · '.join(stool_labels.get(part.strip(),part.strip())for part in e.get('material_label','').split('·'))
  if e.get('material_label')=='ceramic':e['material_label']='Seramik'
  if e['category']=='Halılar':e['material_label']={'wool':'Yün dokulu yüzey','woven':'Dokuma yüzey','cotton':'Pamuk dokulu yüzey','vintage':'Eskitme desenli dokuma','jute':'Jüt örgü','sisal':'Sisal dokuma','fur':'Uzun tüylü yüzey'}.get(e.get('material_label'),e.get('material_label',''))
  if 'exact_rectangular_format_artwork_placement_unpublished'in e.get('quality_pending',[]):
   e['quality_note']='Bu 40 × 60 cm bedenin tam ön fotoğrafı yayımlanmadığı için aynı ürünün kare bedenindeki motifler dikdörtgene uyarlandı. Desenin bu bedendeki kesin yerleşimi doğrulanamadı.'
   e['quality_label']='Desen yorumu'
  apply_axis_provenance(e)
  if e.get('filling_profile_parameters'):
   w,h,d=e['dimensions_cm'];e['scale_note']=f'Resmî kılıfın {w:g} × {h:g} cm en-boy ölçüsü korundu. Dolgun görünüm için {d:g} cm derinlik fotoğraftan tahmin edildi; üreticinin yayımladığı bir dolgu ölçüsü değildir. Desen ve kumaş kaplaması korundu.'
  if e.get('quality_note'):
   if e['category']=='Halılar':e['quality_label']='Desen yorumu'
   if e['id']=='9284-009-710-h36-w36-d7':
    e['quality_label']='Bağlarla dış ölçü'
    e['quality_note']='Resmî minder gövdesi 36 × 36 × 7 cm olarak korundu. Üst fiyonklar fotoğraftan modellendi; bağlarla toplam yükseklik yaklaşık 39,9 cm.'
   e['source_notes']=list(dict.fromkeys([*e.get('source_notes',[]),e['quality_note']]))
 replacing={e['id']for e in entries}&oldids;assert replacing=={e['id']for e in baseline['catalog']if e['category']=='Kırlentler'},replacing
 cache={(e['id'],e['sha256']):e for e in read(P/'root-master-validation.json')}if(P/'root-master-validation.json').exists()else{}
 tcache={(e['id'],e['sha256']):e for e in read(P/'root-independent-qa.json')['checks']}if(P/'root-independent-qa.json').exists()else{}
 checks=[];topology=[]
 for e in entries:
  assert 12<=e['bytes']<=96*1024*1024 and re.fullmatch(r'[A-Za-z0-9-]+',e['id'])
  assert sha(e['glb_path'])==e['sha256']and Path(e['glb_path']).stat().st_size==e['bytes']
  check=cache.get((e['id'],e['sha256']))or validate(e);checks.append(check)
  topology.append(tcache.get((e['id'],e['sha256']))or audit(e))
  e.update(preview_geometry_quality=0,preview_color_size=256,preview_preserve_meshes=e.get('preview_preserve_meshes',[]))
 write(P/'root-master-validation.json',checks);write(P/'root-independent-qa.json',dict(valid=True,models=len(entries),checks=topology))
 for e in baseline['manifest']['models']:
  if e['id']not in replacing:assert sha(SITE/'model-source'/e['filename'])==e['sha256']
 # Load only the selected full GLB. Growing the catalogue must not download
 # every other model's reduced geometry/textures before the first view opens.
 # The previous409-model preview remains frozen in baseline-409.json.
 preview={k:copy.deepcopy(v)for k,v in baseline['preview'].items()if k not in ['models','textures','data']}
 preview.update(loading_mode='on_demand_full_glb',textures=[],data=base64.b64encode(gzip.compress(b'\0'*4,mtime=0)).decode())
 def descriptor(e):
  return dict(id=e['id'],name=e['name'],sku=e['sku'],url=e['url'],dimensions_cm=e['dimensions_cm'],materialLabel=e['material_label'],materials={},meshes=[],**{k:e[k]for k in ['scene_variants','default_scene_index','set_quantity','quality_status','quality_note','quality_label','official_body_dimensions_cm']if k in e},**source_provenance(e,dict(metadata=e)))
 replacements={e['id']:descriptor(e)for e in entries if e['id']in replacing}
 preview['models']=[replacements.get(e['id'],{**{k:v for k,v in e.items()if k not in ['materials','meshes']},'materials':{},'meshes':[]})for e in baseline['preview']['models']]+[descriptor(e)for e in entries if e['id']not in replacing]
 catalog=[catalog_record(next(n for n in entries if n['id']==e['id']))if e['id']in replacing else e for e in baseline['catalog']]+[catalog_record(e)for e in entries if e['id']not in replacing]
 # Preserve the reviewed physical master while correcting an old catalogue typo.
 identity_corrections={'4619-073-515-h35-w72-d53':{'previous_sku':'4619/073/515','sku':'6195/073/515','source_url':'https://www.zarahome.com/tr/kadife-puf-l46195073?pelement=507790018','observed_date':'2026-10-21','official_hwd_cm':[35,72,53],'evidence':'Visible official SKU copy button and labelled dimension cells; filename retained for existing links.'}}
 for item in [*catalog,*preview['models']]:
  if item['id']in identity_corrections:
   correction=identity_corrections[item['id']];item.update(sku=correction['sku'],source_identity_correction=correction)
 manifest=copy.deepcopy(baseline['manifest']);byid={e['id']:e for e in manifest['models']}
 for e in entries:
  dest=SITE/'model-source'/(e['id']+'.glb')
  if not dest.exists()or sha(dest)!=e['sha256']:shutil.copy2(e['glb_path'],dest)
  item=dict(id=e['id'],name=e['name'],filename=e['id']+'.glb',accepted_filenames=[e['id']+'.glb'],bytes=e['bytes'],sha256=e['sha256'],key='models/'+e['sha256']+'.glb')
  if e['id']in byid:byid[e['id']].clear();byid[e['id']].update(item)
  else:manifest['models'].append(item)
 count=len(catalog);manifest.update(model_count=count,total_bytes=sum(e['bytes']for e in manifest['models']))
 write(SITE/'model-manifest.json',manifest);write(SITE/'ui/catalog.json',catalog);(SITE/'ui/preview.json').write_text(json.dumps(preview,ensure_ascii=False,separators=(',',':')))
 # All rendered retail cards are preserved, even when a size is still unknown.
 live=read(P/'live-category-cards.json')['categories'];enriched={}
 for group in ['decor','furniture-textile','accessories']:
  for category in read(P/group/'inventory.json')['categories']:
   for card in category['products']:enriched[(category['url'],card['url'])]=card
 verified_bindings={}
 for folder in ['diffuser-models','office-models','accessories-completion','accessories-completion/diffuser-addendum','decor-completion','rug-completion']:
  refined=P/folder/'inventory-production.json'
  if refined.exists():
   for category in read(refined)['categories']:
    for card in category['products']:
     key=(category['url'],card['url']);enriched[key]=card
     verified_bindings[key]=card.get('matched_model_ids',[])
 observed_by_url={}
 for row in PUBLIC_GALLERY_ROWS:
  previous=observed_by_url.get(row['url'],{});merged={**previous,**row}
  for key in ['sku','sku_copy_buttons','dimension_cell_labels','official_plan_size_labels','official_diameter_labels']:
   if not row.get(key)and previous.get(key):merged[key]=previous[key]
  observed_by_url[row['url']]=merged
 refs=copy.deepcopy(baseline['reference_catalog']);products=refs['products'];refbyid={p['id']:p for p in products};sources={s['id']:s for s in refs['sources']};links={s['url']:s for s in refs['original_links']}
 for c in live:
  slug=SLUGS[c['category']];sources.setdefault(slug,dict(id=slug,label=c['category'],url=c['url']));links.setdefault(c['url'],dict(label=c['category'],url=c['url']))
 for e in catalog:
  slug=SLUGS.get(e['category'],'vazolar')
  # Model-only category filters still point to the relevant official umbrella;
  # they do not imply that an additional retail grid was exhaustively scanned.
  sources.setdefault(slug,dict(id=slug,label=e['category'],url='https://www.zarahome.com/tr/dekorasyon-n989'))
  refid='zarahome-'+e['id'];p=refbyid.get(refid)
  if not p:p=next((x for x in products if x.get('model_id')==e['id']),None)
  if not p:p=dict(id=refid);products.append(p);refbyid[refid]=p
  w,h,d=e['dimensions_cm'];slug=SLUGS.get(e['category'],'vazolar');source=sources.get(slug,sources.get('vazolar',dict(url='https://www.zarahome.com/tr/dekoratif-vazo-n1010')))
  p.update(title=e['name'],brand='Zara Home',source_id=slug,source_label=e['category'],source_url=source['url'],url=e['url'],product_code=e['sku'],category=e['category'],material_label=e.get('material_label',''),dimensions_display=f'{h:g} × {w:g} × {d:g} cm (Y × G × D)'+(' · Kısmen yaklaşık'if e.get('estimated_dimensions')else''),dimension_note=' '.join(dict.fromkeys(filter(None,[e.get('scale_note'),e.get('quality_note')]))),images=e['reference_images'],model_id=e['id'],model_sha256=byid[e['id']]['sha256']if e['id']in byid else next(m['sha256']for m in manifest['models']if m['id']==e['id']),model_status='ready',status='model_ready',original_source_images_preserved=True)
  links.setdefault(e['url'],dict(label=e['name'],url=e['url']))
 sku_models={}
 for e in catalog:sku_models.setdefault(e['sku'],[]).append(e['id'])
 inventory=[];pendingbykey={};selection_aliases={}
 retired=set()
 for prior in [p for p in products if not p.get('model_id')]:
  matches=sku_models.get(prior.get('product_code'),[])
  if not matches:continue
  target=next(p for p in products if p.get('model_id')==sorted(matches)[0])
  target['images']=images(target.get('images',[])+prior.get('images',[]),target['title'])
  selection_aliases[prior['id']]=target['id'];retired.add(prior['id'])
 products[:]=[p for p in products if p['id']not in retired]
 oldrefs=[p for p in products if not p.get('model_id')]
 for c in live:
  category=dict(category=c['category'],source_id=SLUGS[c['category']],url=c['url'],observed_at=c['observed_at'],scan_complete=c['scan_complete'],official_card_count=c['official_card_count'],scan_evidence=c.get('scan_evidence'),products=[])
  for index,raw in enumerate(c['products']):
   card={**copy.deepcopy(raw),**copy.deepcopy(enriched.get((c['url'],raw['url']),{}))};observed=observed_by_url.get(raw['url'],{});text=observed.get('text','');found=re.search(r'\d{4}/\d{3}/\d{3}',text);live_sku=official_sku(observed.get('sku'))or(found.group()if found else None)
   if live_sku:card['sku']=live_sku;card['sku_source']='official_live_product'
   sku=official_sku(card.get('sku'));codes={code(i['url'])for i in raw.get('images',[])if code(i['url'])};matched=set(sku_models.get(sku,[]))
   matched.update(id for id in verified_bindings.get((c['url'],raw['url']),[])if any(e['id']==id for e in catalog))
   if not sku:
    for e in catalog:
     if '4'+e['sku'].replace('/','')in codes:matched.add(e['id'])
   card.update(card_index=index+1,matched_model_ids=sorted(matched),missing_model=not bool(matched),size_coverage='not_all_sizes_verified',model_status='at_least_one_size_ready'if matched else'not_modeled')
   category['products'].append(card);links.setdefault(raw['url'],dict(label=raw['title'],url=raw['url']))
   if matched:
    old_key=raw['url']+'|'+','.join(sorted(codes));legacy_id='zarahome-source-'+hashlib.sha256(old_key.encode()).hexdigest()[:20]
    target=next(p['id']for p in products if p.get('model_id')==sorted(matched)[0])
    if legacy_id!=target:selection_aliases[legacy_id]=target
    continue
   key=raw['url']+'|'+','.join(sorted(codes));slug=SLUGS[c['category']]
   existing=next((p for p in oldrefs if p.get('url')==raw['url']),None)
   if existing:
    if existing.get('source_id')!=slug:existing['additional_source_ids']=sorted(set(existing.get('additional_source_ids',[])+[slug]))
    continue
   if key in pendingbykey:
    record=pendingbykey[key]
    if record['source_id']!=slug:record['additional_source_ids']=sorted(set(record.get('additional_source_ids',[])+[slug]))
    continue
   title=raw['title'];record=dict(id='zarahome-source-'+hashlib.sha256(key.encode()).hexdigest()[:20],title=title,brand='Zara Home',source_id=slug,source_label=c['category'],source_url=c['url'],url=raw['url'],product_code=sku or'',category=c['category'],material_label=card.get('material_label',''),dimensions_display='Boy ve ölçüler doğrulanacak',dimension_note='Kategori kartı kaydedildi. Bütün renk ve bedenlerin ölçü doğrulaması henüz tamamlanmadı.',images=images(raw.get('images',[]),title),model_status='pending',status='model_pending',modeling_note='Bu ürün kaynak envanterine eklendi; 3D modeli henüz hazır değil. Zara Home kapsamına dahildir, modelleme kişisel seçime bağlı değildir.',original_source_images_preserved=True)
   missing_reason=None
   if sku in {'3470/703/803','0415/703/732','0412/703/100','0416/703/609','0414/703/803','0489/703/046'}:missing_reason='Türkiye sayfasında ve aynı ürün koduna ait incelenen diğer resmî pazar kayıtlarında fiziksel ölçü yayımlanmıyor.'
   elif '44176008251'in codes:missing_reason='Kaynak ürün sayfası stok dışı; resmî beden ölçüleri görüntülenemedi.'
   elif '46192008407'in codes:missing_reason='Kaynak ürün sayfasına erişilemiyor; resmî beden ölçüleri doğrulanamadı.'
   elif 'ÜRÜN STOKTA YOK'in text.upper()or observed.get('availability')=='product_page_unavailable':missing_reason='Kaynak ürün sayfası kullanılamıyor; resmî beden ölçüleri doğrulanamadı.'
   if missing_reason:record.update(dimensions_display='Resmî ölçü doğrulanamadı',dimension_note=missing_reason,modeling_note='Görsel kaydedildi. '+missing_reason+' Doğrulanmış ölçü olmadan model hazır sayılmadı.')
   if not record['images']:record['modeling_note']='Bu kart bir ürün grubu olabilir; özgün ürün ve fotoğraf bilgileri ayrıştırılacak. 3D model henüz hazır değil.'
   pendingbykey[key]=record;products.append(record)
  category.update(cards_with_model=sum(not p['missing_model']for p in category['products']),cards_without_model=sum(p['missing_model']for p in category['products']))
  inventory.append(category)
 # A real product shared by two retail categories has one master, and is
 # discoverable in both categories. Cross-listing never inflates model count.
 model_categories={e['category']for e in catalog};extra_categories={}
 for c in inventory:
  for card in c['products']:
   for id in card['matched_model_ids']:extra_categories.setdefault(id,set()).add(c['category'])
 for model in catalog:
  extra=sorted((extra_categories.get(model['id'],set())|set(model.get('additional_categories',[])))-{model['category']})
  if extra:model['additional_categories']=extra
  for ref in products:
   if ref.get('model_id')==model['id']:
    ref['additional_source_ids']=sorted({SLUGS[c]for c in extra if c in SLUGS and SLUGS[c]!=ref['source_id']})
 for ref in products:
  if ref.get('source_id')=='oturma-odasi-halilari':ref['additional_source_ids']=sorted(set(ref.get('additional_source_ids',[])+['halilar']))
 write(SITE/'ui/catalog.json',catalog)
 refs['legacy_selection_aliases']=selection_aliases
 refs.update(sources=list(sources.values()),original_links=list(links.values()),updated_date='2026-10-21',coverage=dict(observed_date='2026-10-21',scope='İncelenen 20 resmî kategori; bütün Zara Home sitesi veya tüm bedenler tamamlandı anlamına gelmez.',categories=[{k:v for k,v in c.items()if k!='products'}for c in inventory],card_count=sum(c['official_card_count']for c in inventory),ready_model_variants=count,ready_reference_records=sum(bool(p.get('model_id'))for p in products),pending_reference_records=sum(not bool(p.get('model_id'))for p in products),caveat='Kategori kartları renk, koleksiyon ve aynı ürünün tekrarlarını içerebilir. Hazır sayısı en az bir modeli olan kartları gösterir; tüm bedenlerin tamamlandığı anlamına gelmez.'))
 write(SITE/'ui/zarahome-reference-catalog.json',refs);write(P/'coverage-inventory-full.json',dict(observed_date='2026-10-21',categories=inventory))
 public_inventory=[]
 for c in inventory:
  item={k:v for k,v in c.items()if k!='products'};item['products']=[{k:v for k,v in p.items()if k in ['card_index','title','url','images','sku','image_code','matched_model_ids','missing_model','size_coverage','model_status','card_kind']}for p in c['products']];public_inventory.append(item)
 write(SITE/'ui/coverage-inventory.json',dict(observed_date='2026-10-21',categories=public_inventory,limitations=[refs['coverage']['scope'],refs['coverage']['caveat']]))
 library=[e for e in read(WORK/'library-manifest.json')if e['id']in oldids and e['id']not in replacing]+entries
 for item in library:
  if item['id']in identity_corrections:item.update(sku=identity_corrections[item['id']]['sku'],source_identity_correction=identity_corrections[item['id']])
 assert len(library)==count;write(WORK/'library-manifest.json',library);write(P/'library-manifest.json',library)
 assert read(SITE/'ui/hipicon-reference-catalog.json')==baseline['hipicon_catalog']
 html=SITE/'ui/index.html';s=html.read_text();s=re.sub(r'(yeniden modellenmiş )\d+( materyalli)',lambda m:m[1]+str(count)+m[2],s);s=re.sub(r'<strong>\d+</strong><span>(?:hazır )?boy ve renk varyantı',f'<strong>{count}</strong><span>hazır boy ve renk varyantı',s);s=re.sub(r'\d+ model</span>',f'{count} model</span>',s);s=re.sub(r'<br>\d+ kategori',f'<br>{len({e["category"]for e in catalog})} kategori',s);html.write_text(s)
 recipes=SITE/'asset-recipes/completeness-repair-2026-10-21';recipes.mkdir(exist_ok=True)
 provenance_inputs=read(P/'delivery-inputs.json')if(P/'delivery-inputs.json').exists()else[]
 for source in dict.fromkeys([*input_paths,*[Path(s)for s in provenance_inputs]]):
  dest=recipes/source.parent.name;dest.mkdir(exist_ok=True)
  for p in {source,*source.parent.glob('*.py'),*source.parent.glob('*validation.json'),*source.parent.glob('*delivery.json')}:
   if p.stat().st_size<10*1024*1024:shutil.copy2(p,dest/p.name)
 for p in [P/'integrate_repair.py',P/'prepare_delivery.py',P/'prevalidate_delivery.py',P/'apply-chair-ui.py',P/'apply-axis-ui.py',P/'axis_provenance.py',P/'upload-library.mjs',P/'apply-selection-aliases.py',P/'pillow-independent-spot-review.json',P/'delivery-inputs.json',P/'pillow-fill-allowed-ids.json',P/'root-master-validation.json',P/'root-independent-qa.json',P/'delivery-provenance-qa.json',P/'live-category-cards.json',P/'live-product-details-from-root.json']:
  if p.exists():shutil.copy2(p,recipes/p.name)
 report=dict(models=count,new_models=count-409,replaced_models=len(replacing),unchanged_models=409-len(replacing),reference_records=len(products),pending_reference_records=refs['coverage']['pending_reference_records'],observed_category_cards=refs['coverage']['card_count'],categories=[{k:c[k]for k in ['category','official_card_count','cards_with_model','cards_without_model']}for c in inventory],complete=False,limitation='Full inventory exposed; unmodeled products and unverified sizes remain explicitly pending.')
 write(P/'site-integration-report.json',report);print(json.dumps(report,ensure_ascii=False))

if __name__=='__main__':main()
