from pathlib import Path
import json,sys
R=Path(__file__).resolve().parent
sys.path.insert(0,str(R));import build_mirrors as B
p=next(p for p in json.loads((R/'source-inventory-frozen.json').read_text())if p['family_path_code']=='46309106')
material='Basit kenarlı ve arkasındaki ankraj sayesinde yatay veya dikey olarak asılabilen mango ağacından ahşap kenarlı dikdörtgen duvar aynası.'
urls=[p['url'],'https://www.zarahome.com/tr/dikdortgen-ahsap-kenarli-duvar-aynasi-l46309106']
note=' Kahverengi6309/106/700 güncel TR sayfasındaki mango ağacı açıklaması esas alındı. Beyaz6309/106/250 modelinin aynı ölçülü çerçeve geometrisi okuma amaçlı yeniden kullanıldı; eski beyaz renk panelinin MDF bileşimi bu yeni renk için aktarılmadı.'
entries=json.loads((R/'manifest.json').read_text());e=next(e for e in entries if e['sku']=='6309/106/700');out=Path(e['asset_dir']);model=json.loads(Path(e['model_path']).read_text());m=model['metadata'];m.update(official_materials_verbatim=material,size_source_urls=urls);m['scale_note']+=note;B.dump(Path(e['model_path']),model)
doc,binary=B.read_glb(e['glb_path']);doc['extras']['metadata']=m;B.write_glb(e['glb_path'],doc,binary)
e.update(material_label=material,size_source_urls=urls,scale_note=m['scale_note'],sha256=B.sha(e['glb_path']),bytes=Path(e['glb_path']).stat().st_size);B.dump(R/'manifest.json',entries)
reportp=out/(e['id']+'.validation.json');report=json.loads(reportp.read_text());report['metadata']=m;report['deliverable_sha256']['glb']=e['sha256'];report['glb_bytes']=e['bytes'];B.dump(reportp,report);B.dump(out/'topology-validation.json',B.AQ.check(e))
data=json.loads((R/'source-inventory-frozen.json').read_text());extra=json.loads((R/'extra-official-facts.json').read_text())
for p in data:
 q=extra.get(p['family_path_code'])
 if q:p.update(sku=q['sku'],sizes=q['sizes'],material=q['material'],source_market=q['source_market'],size_source_kind=q['size_source_kind'],product_detail_urls=q['source_urls'],product_detail_sources=[str(R/q['evidence'])],extra_note=q['note'])
 if p['family_path_code']=='46309106':p.update(material=material,product_detail_urls=urls,extra_note=note.strip())
B.dump(R/'resolved-source-inventory.json',data)
