import { readFile, writeFile, realpath, stat } from 'node:fs/promises';
import { isAbsolute, join, relative, sep } from 'node:path';
import { createHash } from 'node:crypto';
import { setTimeout as pause } from 'node:timers/promises';

const ALLOWED_ORIGIN = 'https://bahar-vazo-kutuphanesi.createandgotr.chatgpt.site';
const EXPECTED_MODELS = 89;
const CONCURRENCY = 3;
const MAX_RETRIES = 2;
const REQUEST_TIMEOUT_MS = 90_000;
const READBACK_ID = '7355-046-305-h31-w20-d20';

class SafeFailure extends Error {
  constructor(message, exitCode = 1) { super(message); this.exitCode = exitCode; }
}
function fail(message) { throw new SafeFailure(message); }
function sha256(bytes) { return createHash('sha256').update(bytes).digest('hex'); }
function safeFilename(value) {
  return typeof value === 'string' && /^[a-zA-Z0-9][a-zA-Z0-9._-]*\.glb$/.test(value) && !value.includes('..');
}

async function hiddenInput() {
  if (process.argv.length !== 2) fail('Ayarları yalnız gizli standart girdiden gönderin.');
  if (!process.stdin.isTTY || typeof process.stdin.setRawMode !== 'function') fail('Gizli girdi için etkileşimli bir terminal gerekir.');
  process.stderr.write('Ready for private model upload JSON on stdin (input is hidden).\n');
  return new Promise((resolve, reject) => {
    let value = ''; const wasRaw = Boolean(process.stdin.isRaw); let finished = false;
    const finish = (error, result) => {
      if (finished) return; finished = true;
      process.stdin.off('data', onData); process.stdin.off('end', onEnd); process.stdin.off('error', onError);
      process.stdin.setRawMode(wasRaw); process.stdin.pause(); value = '';
      error ? reject(error) : resolve(result);
    };
    const onError = () => finish(new SafeFailure('Gizli girdi okunamadı.'));
    const onEnd = () => finish(new SafeFailure('Gizli JSON girdisi tamamlanmadı.'));
    const onData = chunk => {
      value += chunk;
      if (value.includes('\u0003')) return finish(new SafeFailure('Yükleme iptal edildi.', 130));
      if (Buffer.byteLength(value, 'utf8') > 65_536) return finish(new SafeFailure('Gizli girdi izin verilen boyutu aşıyor.'));
      const newline = value.search(/[\r\n]/);
      if (newline < 0) return;
      if (value.slice(newline).trim()) return finish(new SafeFailure('Yalnız bir JSON nesnesi gönderilmelidir.'));
      let result;
      try { result = JSON.parse(value.slice(0, newline)); }
      catch { return finish(new SafeFailure('Gizli ayarlar geçerli JSON değil.')); }
      finish(null, result);
    };
    process.stdin.setEncoding('utf8'); process.stdin.setRawMode(true);
    process.stdin.on('data', onData); process.stdin.once('end', onEnd); process.stdin.once('error', onError);
    process.stdin.resume();
  });
}

async function configuration(input) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) fail('Yükleme ayarları eksik.');
  let base;
  try { base = new URL(input.baseUrl); } catch { fail('Site adresi geçersiz.'); }
  if (base.origin !== ALLOWED_ORIGIN || base.pathname !== '/' || base.search || base.hash || base.username || base.password) fail('Yalnız doğrulanmış özel Site adresi kullanılabilir.');
  if (typeof input.token !== 'string' || !input.token || input.token.length > 16_384 || !/^[\x21-\x7e]+$/.test(input.token)) fail('Servis erişim bilgisi geçersiz.');
  if (typeof input.sourceDir !== 'string' || !isAbsolute(input.sourceDir) || typeof input.manifestPath !== 'string' || !isAbsolute(input.manifestPath)) fail('Kaynak klasör ve manifest yolları mutlak olmalıdır.');
  let sourceDir, manifest;
  try {
    sourceDir = await realpath(input.sourceDir);
    if (!(await stat(sourceDir)).isDirectory()) fail('Kaynak model klasörü bulunamadı.');
    manifest = JSON.parse(await readFile(input.manifestPath, 'utf8'));
  } catch (error) {
    if (error instanceof SafeFailure) throw error;
    fail('Kaynak klasör veya model manifesti okunamadı.');
  }
  const models = manifest?.models;
  const expectedModels = input.expectedModels ?? EXPECTED_MODELS;
  if (!Number.isSafeInteger(expectedModels) || expectedModels < 1 || expectedModels > 2000 || !Array.isArray(models) || models.length !== expectedModels) fail('Manifest beklenen model sayısıyla eşleşmiyor.');
  const ids = new Set(); const names = new Set();
  for (const model of models) {
    if (!model || typeof model.id !== 'string' || !/^[a-zA-Z0-9-]+$/.test(model.id) || ids.has(model.id)) fail('Manifest model kimlikleri geçersiz.');
    if (model.filename !== model.id + '.glb' || !safeFilename(model.filename)) fail('Manifest dosya adları geçersiz.');
    if (!Number.isSafeInteger(model.bytes) || model.bytes < 12 || model.bytes > 40 * 1024 * 1024 || !/^[a-f0-9]{64}$/.test(model.sha256 || '')) fail('Manifest boyut veya doğrulama bilgisi geçersiz.');
    const aliases = model.accepted_filenames ?? [model.filename];
    if (!Array.isArray(aliases) || !aliases.length || !aliases.includes(model.filename) || aliases.some(name => !safeFilename(name))) fail('Manifest alternatif dosya adları geçersiz.');
    for (const name of aliases) { if (names.has(name)) fail('Manifest dosya adları benzersiz olmalıdır.'); names.add(name); }
    model.accepted_filenames = aliases; ids.add(model.id);
  }
  if(input.readbackIdsPath !== undefined && (typeof input.readbackIdsPath !== 'string' || !isAbsolute(input.readbackIdsPath))) fail('Model doğrulama listesi yolu mutlak olmalıdır.');
  const readbackIds = input.readbackIds ?? (input.readbackIdsPath ? JSON.parse(await readFile(input.readbackIdsPath, 'utf8')) : [READBACK_ID]);
  if (!Array.isArray(readbackIds) || !readbackIds.length || readbackIds.length > 2000 || new Set(readbackIds).size !== readbackIds.length || readbackIds.some(id => !ids.has(id))) fail('Tam model doğrulama kayıtları manifestte bulunamadı.');
  let assetSourceDir, assets;
  try { assetSourceDir = await realpath(join(sourceDir, '..', 'ui')); assets = JSON.parse(await readFile(join(sourceDir, '..', 'catalog-asset-manifest.json'), 'utf8')); }
  catch { fail('Katalog dosyası tanımı okunamadı.'); }
  if (!Array.isArray(assets) || assets.length !== 1 || assets.some(a => a.filename !== 'preview.json' || a.route !== '/preview.json' || !/^[a-f0-9]{64}$/.test(a.sha256) || a.key !== 'catalog-assets/' + a.sha256 + '.json' || !Number.isSafeInteger(a.bytes) || a.bytes < 1 || a.bytes > 80 * 1024 * 1024)) fail('Katalog dosyası tanımı geçersiz.');
  if (input.reportPath !== undefined && (typeof input.reportPath !== 'string' || !isAbsolute(input.reportPath))) fail('Doğrulama raporu yolu mutlak olmalıdır.');
  return { origin: ALLOWED_ORIGIN, token: input.token, sourceDir, models, readbackIds, assets, assetSourceDir, reportPath: input.reportPath };
}

function client(config, metrics) {
  function url(path) {
    const target = new URL(path, config.origin);
    if (target.origin !== ALLOWED_ORIGIN || target.username || target.password || target.hash) fail('İstek hedefi doğrulanamadı.');
    return target;
  }
  async function request(path, { method = 'GET', headers = {}, body, responseType = 'json' } = {}) {
    const target = url(path);
    for (let attempt = 0; attempt <= MAX_RETRIES; attempt++) {
      let response;
      try {
        const timeoutMs = responseType === 'bytes' || method === 'PUT' ? 300_000 : REQUEST_TIMEOUT_MS;
        response = await fetch(target, {
          method, redirect: 'manual', signal: AbortSignal.timeout(timeoutMs),
          headers: { ...headers, 'OAI-Sites-Authorization': 'Bearer ' + config.token },
          ...(body === undefined ? {} : { body }),
        });
      } catch {
        if (attempt === MAX_RETRIES) fail('Site bağlantısı yeniden denemelerden sonra tamamlanamadı.');
        metrics.retries++; await pause(500 * (2 ** attempt)); continue;
      }
      if (response.status >= 300 && response.status < 400) {
        await response.body?.cancel().catch(() => {});
        fail('Site bir yönlendirme döndürdü; erişim bilgisi başka bir adrese gönderilmedi.');
      }
      const transient = [408, 425, 429].includes(response.status) || response.status >= 500;
      if (transient && attempt < MAX_RETRIES) {
        const retryAfter = Number(response.headers.get('retry-after'));
        await response.body?.cancel().catch(() => {});
        metrics.retries++; await pause(Math.min(5_000, Math.max(500 * (2 ** attempt), Number.isFinite(retryAfter) ? retryAfter * 1000 : 0)));
        continue;
      }
      if (!response.ok) {
        const code = response.status; await response.body?.cancel().catch(() => {});
        if (code === 401 || code === 403) fail('Özel Site servis erişimi reddedildi (HTTP ' + code + ').');
        fail('Site isteği tamamlanamadı (HTTP ' + code + ').');
      }
      let payload;
      try { payload = responseType === 'json' ? await response.text() : Buffer.from(await response.arrayBuffer()); }
      catch {
        if (attempt === MAX_RETRIES) fail('Site yanıtı yeniden denemelerden sonra tamamlanamadı.');
        metrics.retries++; await pause(500 * (2 ** attempt)); continue;
      }
      if (responseType === 'bytes') return payload;
      try { return JSON.parse(payload); }
      catch { fail('Site beklenen JSON yanıtını döndürmedi.'); }
    }
    fail('Site isteği tamamlanamadı.');
  }
  return {
    json: (path, options) => request(path, { ...options, responseType: 'json' }),
    bytes: (path, options) => request(path, { ...options, responseType: 'bytes' }),
  };
}

function validateStatus(status, models) {
  if (!status || status.total !== models.length || !Array.isArray(status.models) || status.models.length !== models.length) fail('Site model durumu yerel kayıtlarla eşleşmiyor.');
  const remote = new Map();
  for (const row of status.models) {
    if (!row || typeof row.id !== 'string' || remote.has(row.id)) fail('Site model durumu benzersiz değil.');
    remote.set(row.id, row);
  }
  for (const model of models) {
    const row = remote.get(model.id);
    if (!row || row.sha256 !== model.sha256 || row.bytes !== model.bytes || row.filename !== model.filename) fail('Site ve yerel manifest doğrulama bilgileri eşleşmiyor.');
    if (row.status === 'conflict') fail('Saklanan bir modelde doğrulama çakışması var.');
    if (!['ready', 'missing'].includes(row.status)) fail('Site model durumu geçersiz.');
  }
  const ready = [...remote.values()].filter(row => row.status === 'ready').length;
  if (status.ready !== ready) fail('Site hazır model sayısı tutarlı değil.');
  return remote;
}

async function modelSource(config, model) {
  for (const filename of model.accepted_filenames) {
    let path;
    try { path = await realpath(join(config.sourceDir, filename)); }
    catch (error) { if (error?.code === 'ENOENT') continue; fail('Bir model kaynak dosyası okunamadı.'); }
    const child = relative(config.sourceDir, path);
    if (isAbsolute(child) || child === '..' || child.startsWith('..' + sep)) fail('Model kaynak dosyası seçilen klasörün dışında.');
    let bytes;
    try {
      const info = await stat(path);
      if (!info.isFile() || info.size !== model.bytes) fail('Bir modelin kaynak dosya boyutu eşleşmiyor: ' + model.id);
      bytes = await readFile(path);
    } catch (error) { if (error instanceof SafeFailure) throw error; fail('Bir model kaynak dosyası okunamadı.'); }
    if (bytes.length !== model.bytes || sha256(bytes) !== model.sha256) fail('Bir kaynak modelin içeriği manifestle eşleşmiyor: ' + model.id);
    if (bytes.toString('ascii', 0, 4) !== 'glTF' || bytes.readUInt32LE(4) !== 2 || bytes.readUInt32LE(8) !== bytes.length) fail('Bir modelin GLB başlığı geçerli değil: ' + model.id);
    return { filename, bytes };
  }
  fail('Bir model kaynak dosyası bulunamadı: ' + model.id);
}

async function run(config) {
  const metrics = { retries: 0 }; const api = client(config, metrics);
  const assetReadbacks = [];
  for (const asset of config.assets) {
    const bytes = await readFile(join(config.assetSourceDir, asset.filename));
    if (bytes.length !== asset.bytes || sha256(bytes) !== asset.sha256) fail('Katalog kaynak dosyası eşleşmiyor.');
    const result = await api.json('/api/import/assets/' + asset.filename, { method: 'PUT', headers: { 'content-type': 'application/json', 'x-asset-sha256': asset.sha256 }, body: bytes });
    if (result.filename !== asset.filename || result.status !== 'ready') fail('Katalog yüklemesi doğrulanamadı.');
    const actual = await api.bytes(asset.route + '?v=' + asset.sha256);
    if (actual.length !== asset.bytes || sha256(actual) !== asset.sha256) fail('Katalog tam geri okuması eşleşmiyor.');
    assetReadbacks.push({ filename: asset.filename, bytes: asset.bytes, sha256: asset.sha256, verified: true });
    process.stdout.write('Katalog hazır ve doğrulandı.\n');
  }
  const initial = validateStatus(await api.json('/api/import/status'), config.models);
  const missing = config.models.filter(model => initial.get(model.id).status !== 'ready');
  const skipped = config.models.length - missing.length; let ready = skipped; let uploaded = 0; let next = 0; let stopped = false;
  process.stdout.write('Hazır: ' + ready + '/' + config.models.length + '.\n');
  const small = missing.filter(model => model.bytes <= 20 * 1024 * 1024);
  const large = missing.filter(model => model.bytes > 20 * 1024 * 1024);
  async function uploadBatch(batch, concurrency) {
  next = 0;
  const workers = await Promise.allSettled(Array.from({ length: Math.min(concurrency, batch.length) }, async () => {
    while (!stopped && next < batch.length) {
      const model = batch[next++];
      try {
        const source = await modelSource(config, model);
        const result = await api.json('/api/import/models/' + encodeURIComponent(source.filename), {
          method: 'PUT', headers: { 'content-type': 'model/gltf-binary', 'x-model-sha256': model.sha256 }, body: source.bytes,
        });
        if (result?.id !== model.id || result.status !== 'ready') fail('Yükleme sonucu doğrulanamadı: ' + model.id);
        uploaded++; ready++; process.stdout.write('Hazır: ' + ready + '/' + config.models.length + '.\n');
      } catch (error) { stopped = true; throw error; }
    }
  }));
  const failed = workers.find(result => result.status === 'rejected');
  if (failed) throw failed.reason;
  }
  await uploadBatch(small, CONCURRENCY);
  await uploadBatch(large, 1);
  const final = validateStatus(await api.json('/api/import/status'), config.models);
  if ([...final.values()].some(row => row.status !== 'ready')) fail('Tüm modellerin hazır olduğu henüz doğrulanamadı.');
  const readbacks = [];
  let readbackNext = 0;
  const readbackWorkers = await Promise.allSettled(Array.from({ length: Math.min(CONCURRENCY, config.readbackIds.length) }, async () => {
  while(readbackNext < config.readbackIds.length) {
    const id = config.readbackIds[readbackNext++];
    const sample = config.models.find(model => model.id === id);
    const readback = await api.bytes('/models/' + sample.filename + '?v=' + sample.sha256);
    if (readback.length !== sample.bytes || sha256(readback) !== sample.sha256) fail('Tam model geri okumasının içeriği eşleşmiyor.');
    readbacks.push({ id: sample.id, bytes: readback.length, sha256: sample.sha256, verified: true });
    if (readbacks.length % 8 === 0) process.stdout.write('Tam dosya denetimi: ' + readbacks.length + '/' + config.readbackIds.length + '.\n');
  }
  }));
  const readbackFailure = readbackWorkers.find(result => result.status === 'rejected');
  if(readbackFailure) throw readbackFailure.reason;
  const report = { complete: true, ready: config.models.length, total: config.models.length, uploaded, skipped, retries: metrics.retries, asset_readbacks: assetReadbacks, readbacks };
  if (config.reportPath) await writeFile(config.reportPath, JSON.stringify(report, null, 2) + '\n');
  process.stdout.write(JSON.stringify({ complete: true, ready: report.ready, uploaded, skipped, retries: report.retries, catalog_verified: assetReadbacks.length, full_model_readbacks: readbacks.length, report_path: config.reportPath || null }) + '\n');
}

try {
  const input = await hiddenInput();
  const config = await configuration(input); input.token = undefined;
  await run(config); config.token = undefined;
} catch (error) {
  // Raw input, response bodies, fetch errors and exception stacks may contain
  // sensitive details. Only messages created locally by SafeFailure are shown.
  process.stderr.write((error instanceof SafeFailure ? error.message : 'Yükleme işlemi tamamlanamadı.') + '\n');
  process.exitCode = error instanceof SafeFailure ? error.exitCode : 1;
}
