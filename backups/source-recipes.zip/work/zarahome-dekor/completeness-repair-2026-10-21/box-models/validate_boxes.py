from pathlib import Path
import json,sys,hashlib,re,io
import numpy as np
from PIL import Image
R=Path(__file__).resolve().parent
sys.path.insert(0,str(R.parents[1]))
from export_catalog import read_glb

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def main():
 entries=json.loads((R/'manifest.json').read_text());original=json.loads((R/'resolved-source-inventory.json').read_text());checks=[]
 expected=set()
 for p in original:
  q=p
  for v in q['sizes']:
   if q['sku'] and all(isinstance(v.get(k),(int,float))for k in ['height_cm','width_cm','depth_cm']):expected.add((q['sku'],tuple(float(v[k]) for k in ['height_cm','width_cm','depth_cm'])))
 assert expected=={(e['sku'],tuple(e['source_dimensions_hwd_cm'])) for e in entries}
 for e in entries:
  doc,binary=read_glb(e['glb_path']);model=json.loads(Path(e['model_path']).read_text());allpos=[];normerr=0;uvdeg=0;uvfinite=True;triangles=0;images=[]
  def arr(i):
   a=doc['accessors'][i];v=doc['bufferViews'][a['bufferView']];dt={5126:'<f4',5125:'<u4',5123:'<u2',5121:'u1'}[a['componentType']];ch={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}[a['type']];size=np.dtype(dt).itemsize
   return np.ndarray((a['count'],ch),dtype=dt,buffer=binary,offset=v.get('byteOffset',0)+a.get('byteOffset',0),strides=(v.get('byteStride',ch*size),size)).copy()
  for mesh in doc['meshes']:
   for p in mesh['primitives']:
    v=arr(p['attributes']['POSITION']);n=arr(p['attributes']['NORMAL']);uv=arr(p['attributes']['TEXCOORD_0']);t=arr(p['attributes']['TANGENT']);idx=arr(p['indices']).reshape(-1,3)
    assert np.isfinite(v).all() and np.isfinite(n).all() and np.isfinite(uv).all() and np.isfinite(t).all()
    normerr=max(normerr,float(np.max(np.abs(np.linalg.norm(n,axis=1)-1))))
    assert normerr<2e-5
    assert np.max(np.abs((n*t[:,:3]).sum(axis=1)))<2e-5
    assert np.max(np.abs(np.linalg.norm(t[:,:3],axis=1)-1))<2e-5
    allpos.append(v);triangles+=len(idx)
    ua,ub,uc=uv[idx[:,0]],uv[idx[:,1]],uv[idx[:,2]];delta1=ub-ua;delta2=uc-ua;uvdeg+=int(np.sum(np.abs(delta1[:,0]*delta2[:,1]-delta1[:,1]*delta2[:,0])<1e-14))
  positions=np.concatenate(allpos);lo=positions.min(0);hi=positions.max(0);bounds=(hi-lo)*100
  assert uvdeg==0,(e['id'],uvdeg)
  assert np.allclose(bounds,e['dimensions_cm'],atol=1e-4),(e['id'],bounds,e['dimensions_cm'])
  assert abs(lo[1])<1e-7 and abs(lo[0]+hi[0])<1e-7 and abs(lo[2]+hi[2])<1e-7
  for im in doc.get('images',[]):
   assert 'uri' not in im and 'bufferView' in im
   v=doc['bufferViews'][im['bufferView']];offset=v.get('byteOffset',0);data=binary[offset:offset+v['byteLength']];img=Image.open(io.BytesIO(data));assert img.size==(2048,2048);images.append(dict(name=im.get('name',''),pixels=list(img.size),embedded=True,sha256=hashlib.sha256(data).hexdigest()))
  for k,m in model['materials'].items():
   if k=='glass':
    assert m['transmission']>=.98 and m['ior']==1.5
    assert 'KHR_materials_transmission' in doc.get('extensionsUsed',[])
   if k in ['polished','antique']:
    orm=np.array(Image.open(Path(e['asset_dir'])/m['metallicRoughnessTexture']));assert orm[:,:,2].min()==255
  top=json.loads((Path(e['asset_dir'])/'topology-validation.json').read_text());assert top['valid'] and top['sha256']==sha(e['glb_path'])
  assert e['source_market']=='Türkiye' and not e['estimated_dimensions']
  assert model['metadata']['photo_pixels_baked']==False and model['metadata']['baked_reflections']==False
  checks.append(dict(id=e['id'],valid=True,bounds_cm=bounds.tolist(),official_cm=e['dimensions_cm'],max_unit_normal_error=normerr,finite_uv=True,uv_degenerate_edge_triangles=uvdeg,uv_note='Every closed front, bevel and side triangle has finite nonzero UV area; side seams use their dominant local plane. Embedded tangents are finite, unit length and orthogonal to normals.',triangles=triangles,embedded_2k_images=images,closed_positive_topology=True,physical_glass_or_metal_pbr=True))
 refs=json.loads((R/'reference-masters.json').read_text());assert len(refs)==7
 for p in refs:assert sha(p['local_master'])==p['sha256']
 pending=json.loads((R/'pending.json').read_text())
 report=dict(valid=True,models=len(entries),missing_category_cards_covered=len({e['sku']for e in entries}),official_size_variants_expected=len(expected),official_size_variants_built=len(entries),all_verified_variants_covered=True,all_variants_covered=not pending,unresolved_identity=sum(p['status']=='needs_identity'for p in pending),unresolved_measurement=sum(p['status']=='needs_measurement'for p in pending),all_source_markets='Türkiye',original_reference_master_hashes_unchanged=True,all_textures_embedded_native_2k=True,checks=checks)
 dump(R/'independent-validation.json',report);print(json.dumps({k:v for k,v in report.items()if k!='checks'}))
if __name__=='__main__':main()
