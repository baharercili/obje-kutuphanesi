from pathlib import Path
import json,sys,math,hashlib,shutil,importlib.util
import numpy as np
from PIL import Image
R=Path(__file__).resolve().parent;WORK=R.parents[1]
sys.path.insert(0,str(WORK))
from export_catalog import export_assets,read_glb,write_glb
spec=importlib.util.spec_from_file_location('old_boxes',WORK/'overnight-2026-10-21/boxes/build_boxes.py');B=importlib.util.module_from_spec(spec);spec.loader.exec_module(B)
sys.path.insert(0,str(R.parent/'mirror-models'));import build_mirrors as M
G=M.G;AQ=M.AQ

def dump(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def add_geo(b,part):
 for g in part.groups.values():b.raw.append(g)
def ring(b,name,mat,profiles):
 a=G.Builder();a.ring(name,mat,[(np.array(p),y)for p,y in profiles])
 for g in a.groups.values():g['_vertices']=[(x,z,-y)for x,y,z in g['_vertices']]
 add_geo(b,a)
def rod(b,name,mat,points,r=.001,sides=20):
 a=G.Builder();a.tube(name,mat,points,r,sides);add_geo(b,a)
def hoop(b,name,mat,center,radius,wire=.00025,plane='xz'):
 x,y,z=center;pts=[]
 for t in np.linspace(0,math.tau,40,endpoint=False):
  if plane=='xz':pts.append((x+radius*math.cos(t),y,z+radius*math.sin(t)))
  else:pts.append((x+radius*math.cos(t),y+radius*math.sin(t),z))
 a=G.Builder();a.tube(name,mat,pts,wire,8,closed=True);add_geo(b,a)
def roundpts(w,d,n=256):return np.c_[np.cos(np.arange(n)*math.tau/n)*w/2,np.sin(np.arange(n)*math.tau/n)*d/2]
def shell(b,name,mat,shape,bottom,top,t=.0008):
 inside=M.offset(shape,-t)
 ring(b,name,mat,[(shape,bottom),(shape,top),(inside,top),(inside,bottom+t)])
 b.solid(name+'-real-floor',mat,[(bottom,inside),(bottom+t,inside)])
def smooth_metal(meshes):
 for m in meshes:
  if not m['name'].startswith('round-smooth-'):continue
  pos=np.array(m['positions']).reshape(-1,3);idx=np.array(m['indices']).reshape(-1,3);unique,inv=np.unique(np.round(pos,8),axis=0,return_inverse=True);fn=np.cross(pos[idx[:,1]]-pos[idx[:,0]],pos[idx[:,2]]-pos[idx[:,0]]);fn/=np.maximum(np.linalg.norm(fn,axis=1)[:,None],1e-30);sums=np.zeros_like(unique)
  for k in range(3):np.add.at(sums,inv[idx[:,k]],fn)
  sums/=np.linalg.norm(sums,axis=1)[:,None];normals=sums[inv]
  # Planar lid caps stay optically flat. Blending their fan corners with the
  # shoulder normal creates a false star reflection despite planar geometry.
  top=np.isclose(pos[:,1],pos[:,1].max(),atol=1e-9);bottom=np.isclose(pos[:,1],pos[:,1].min(),atol=1e-9)
  normals[top]=[0,1,0];normals[bottom]=[0,-1,0];m['normals']=normals.reshape(-1).tolist()
def hinges(b,w,h,d,mat='polished',axis='x'):
 # Separate capped knuckles and narrow leaves, inside the official closed bounds.
 for x in [-w*.26,w*.26]:
  b.box('rear-hinge-flat-leaf',mat,.013,.001,.008,h-.006,x=x,z=-d/2+.004,r=.0005,bev=.0001)
  for j in range(3):rod(b,'capped-hinge-knuckles',mat,[(x-.006+j*.004,h-.004,-d/2+.0005),(x-.0025+j*.004,h-.004,-d/2+.0005)],.0011,20)

def wood(p,v):
 w,h,d=[v[k]/100 for k in ['width_cm','height_cm','depth_cm']];b=B.Builder();t=.006;lid=.007;bw=w-.004
 b.tray('wooden-hollow-jewellery-body','wood',bw,h-lid-.0006,d,t,'linen')
 iw=bw-2*t;idepth=d-2*t;iy=t+.001;ih=h-lid-t-.002
 for z in [-1,1]:b.box('linen-inner-front-and-back-wall-lining','linen',iw,ih,.00065,iy,z=z*(idepth/2-.00035),r=.0002,bev=.00005)
 for x in [-1,1]:b.box('linen-inner-side-wall-lining','linen',.00065,ih,idepth,iy,x=x*(iw/2-.00035),r=.0002,bev=.00005)
 # Photograph has four rear pockets, two middle cells, and eight front ring rolls.
 back=-idepth/2;z1=back+idepth*.25;z2=back+idepth*.70
 for z in [z1,z2]:b.box('linen-horizontal-compartment-divider','linen',iw,ih,.002,iy,z=z,r=.00035,bev=.0001)
 for i in range(1,4):b.box('linen-four-rear-pocket-divider','linen',.002,ih,idepth*.25,iy,x=-iw/2+iw*i/4,z=back+idepth*.125,r=.00035,bev=.0001)
 b.box('linen-two-middle-cell-divider','linen',.002,ih,z2-z1,iy,z=(z1+z2)/2,r=.00035,bev=.0001)
 rw=iw/8;roll_d=idepth*.27;roll_h=min(ih*.82,.038)
 for i in range(8):
  points=[(math.cos(t)*rw*.48,math.sin(t)*roll_h/2)for t in np.linspace(0,math.tau,64,endpoint=False)]
  # axis z: long rolls run front-to-back; eight separate slots run across width.
  b.solid('linen-padded-ring-roll-'+str(i+1),'linen',[(-roll_d/2,points),(roll_d/2,points)],axis='z',center=(-iw/2+rw*(i+.5),iy+roll_h/2,z2+roll_d/2+.001))
 b.frame('separate-mitred-wood-glazed-lid','wood',bw,lid,d,.011,h-lid)
 b.box('real-transparent-glass-lid','glass',bw-.022,.0016,d-.022,h-.0038,r=.0005,bev=.00008)
 # Small rounded side thumb tab is part of the lid, visible at the left in source.
 tab=G.circle(.011,64);b.solid('rounded-side-lid-thumb-tab','wood',[(h-lid,tab),(h-.001,tab)],center=(-bw/2+.006,0,0))
 hinges(b,bw,h,d)
 b.features=['Warm wooden box with genuine hollow body and separate mitred glass lid','Linen-lined interior: four rear pockets, two middle compartments and eight padded front ring rolls','Small rounded side thumb tab and real capped rear hinges; jewellery in photograph excluded','Closed lid pose preserves official7cm exterior height; board and partition thickness interpreted from photograph']
 return b.finish(w,h,d)

def black_glass(p,v):
 w,h,d=[v[k]/100 for k in ['width_cm','height_cm','depth_cm']];b=B.Builder();t=.0018;gl=.00115;lh=.0022
 b.box('linen-covered-solid-bottom','linen',w-.001,.0022,d-.001,0,r=.0004,bev=.0001)
 for y in [.0018,h-lh-.0004]:b.frame('fine-black-perimeter-frame','black',w,t,d,t,y)
 for x in [-1,1]:
  for z in [-1,1]:b.box('slim-black-corner-upright','black',t,h-lh,d=t,y=.001,x=x*(w-t)/2,z=z*(d-t)/2,r=.0003,bev=.0001)
 for x in [-1,1]:b.box('clear-physical-side-glass-pane','glass',gl,h-lh-.003,d-2*t,.0027,x=x*(w/2-t-gl/2),r=.0003,bev=.00008)
 for z in [-1,1]:b.box('clear-physical-front-rear-glass-pane','glass',w-2*t,h-lh-.003,gl,.0027,z=z*(d/2-t-gl/2),r=.0003,bev=.00008)
 b.frame('separate-hinged-black-glass-lid-frame','black',w,lh,d,t,h-lh)
 b.box('real-clear-closed-lid-pane','glass',w-2*t,.0012,d-2*t,h-.0015,r=.0003,bev=.00005)
 hinges(b,w,h,d,'black')
 rod(b,'small-black-front-lid-pull','black',[(-.012,h-.001,d/2-.0004),(.012,h-.001,d/2-.0004)],.0008)
 # A short folded retaining chain is included without changing the closed pose.
 if p['family_path_code']=='44307099':
  for i in range(12):hoop(b,'folded-lid-retaining-chain-link','black',(-w*.46,.006+(i%2)*.001,-d*.38+i*.0017),.0011,.00019,'xy'if i%2 else'xz')
 b.features=['All four real transparent glass side panes in a very fine black metal framework','Linen-lined single undivided compartment; separate glazed hinged lid and small front pull','Independent capped hinge barrels'+(' and closed-pose folded retaining chain'if p['family_path_code']=='44307099'else''),'Closed neutral lid pose matches official external dimensions; no jewellery accessories from the photo included']
 return b.finish(w,h,d)

def round_steel(p,v):
 w,h,d=[v[k]/100 for k in ['width_cm','height_cm','depth_cm']];b=B.Builder();t=.0007;lid=h*.31;by=h-lid-.00035
 shape=roundpts(w-.0006,d-.0006,320);inside=M.offset(shape,-t)
 ring(b,'round-smooth-hollow-polished-stainless-body','polished',[(shape*.985,.001),(shape,.002),(shape,by-.0004),(inside,by),(inside,.0015)])
 b.solid('round-smooth-real-steel-bottom','polished',[(0,inside*.99),(.0013,inside)])
 # Separate fit-over lid has a broad shallow dome and a smoothly rolled shoulder.
 rings=[]
 for u,scale in [(0,1),(.12,1),(.60,.995),(.83,.975),(1,.915)]:rings.append((by+.00035+lid*u,roundpts(w*scale,d*scale,320)))
 b.solid('round-smooth-separate-domed-polished-lid','polished',rings)
 b.features=['Smooth polished stainless circular body with a real hollow interior and separate bottom','Fit-over circular lid with rounded shoulder and shallow convex crown','Thin continuous visible lid/body seam; no flutes, handle or photographic reflections']
 meshes,qa=b.finish(w,h,d);smooth_metal(meshes);return meshes,qa

def chamfered(w,d,cut=.23):
 corners=np.array([[-w/2+cut*w,-d/2],[w/2-cut*w,-d/2],[w/2,-d/2+cut*d],[w/2,d/2-cut*d],[w/2-cut*w,d/2],[-w/2+cut*w,d/2],[-w/2,d/2-cut*d],[-w/2,-d/2+cut*d]])
 points=[];radius=.0010
 for i,q in enumerate(corners):
  a=corners[(i-1)%8]-q;c=corners[(i+1)%8]-q;a=q+a/np.linalg.norm(a)*radius;c=q+c/np.linalg.norm(c)*radius
  for t in np.linspace(0,1,10,endpoint=False):points.append((1-t)**2*a+2*(1-t)*t*q+t*t*c)
 return np.array(points)
def antique(p,v):
 w,h,d=[v[k]/100 for k in ['width_cm','height_cm','depth_cm']];b=B.Builder();oct=p['family_path_code']=='47169099';mat='polished'if oct else'antique';knob=h*.12 if not oct else 0;lid=h*.23;bodyh=h-lid-knob-.0004
 shape=chamfered(w*.97,d*.97)if oct else roundpts(w*.97,d*.97,320);inside=M.offset(shape,-.0008)
 ring(b,'eight-sided-hollow-metal-body'if oct else'round-smooth-oval-antiqued-body',mat,[(shape*.98,.001),(shape,.002),(shape,bodyh),(inside,bodyh),(inside,.0016)])
 b.solid('real-closed-metal-base',mat,[(0,shape*.98),(.0016,shape*.98)])
 # Separate rolled beads at foot and lid lip are geometric rather than baked strips.
 for y in [.0015,bodyh-.0008]:ring(b,'round-smooth-rolled-polished-metal-edge-bead',mat,[(shape*.995,y-.0004),(shape*1.015,y),(shape*1.015,y+.0006),(shape*.995,y+.001)])
 b.solid('round-smooth-octagonal-separate-soft-bevel-lid'if oct else'round-smooth-oval-domed-separate-lid',mat,[(bodyh+.0004,shape*1.012),(bodyh+lid*.28,shape*1.012),(bodyh+lid*.75,shape*.995),(bodyh+lid,shape*.95)])
 if oct:
  for j in range(3):rod(b,'capped-side-hinge-knuckles',mat,[(w*.49,bodyh-.001,-d*.10+j*d*.068),(w*.49,bodyh-.001,-d*.045+j*d*.068)],.0014)
  b.features=['Eight-sided chamfered body, softened convex lid edges and two raised rolled metal perimeter beads','Separate fitted hinged lid, three capped side knuckles and a genuine hollow interior']
 else:
  # Twelve raised petal solids and central boss reconstruct the flower on top.
  pr=min(w,d)*.14;petal_r=pr*.64;top=bodyh+lid
  for i in range(12):
   angle=math.tau*i/12;rad=pr*.74;pts=[]
   for t in np.linspace(0,math.tau,48,endpoint=False):
    xx=math.cos(t)*petal_r;zz=math.sin(t)*petal_r*.40;pts.append((xx*math.cos(angle)-zz*math.sin(angle)+rad*math.cos(angle),xx*math.sin(angle)+zz*math.cos(angle)+rad*math.sin(angle)))
   b.solid('round-smooth-raised-flower-petal-'+str(i+1),mat,[(top,np.array(pts)*.94),(top+knob*.55,np.array(pts)),(top+knob*.78,np.array(pts)*.92)])
  b.disc('round-smooth-central-flower-boss',mat,pr*.48,knob,pr*.48,top)
  for j in range(3):rod(b,'oval-box-capped-side-hinge',mat,[(w*.49,bodyh,-d*.12+j*d*.08),(w*.49,bodyh,-d*.06+j*d*.08)],.0013)
  b.features=['Oval vintage silver-tone box with a genuinely raised twelve-petal floral medallion and central boss','Separate domed lid, real side hinge knuckles, hollow interior and rolled rim/base mouldings','Intrinsic tarnish/scuff maps express aged metal; no source photo pixels or reflected scene baked']
 meshes,qa=b.finish(w,h,d);smooth_metal(meshes);return meshes,qa

def bank():
 out=R/'material-bank';out.mkdir(exist_ok=True);m={}
 old=WORK/'overnight-2026-10-21/boxes'
 samples=[('wood','light_wood'),('linen','cotton')]
 manifest=json.loads((old/'manifest.json').read_text());defs={}
 for e in manifest:
  mm=json.loads(Path(e['model_path']).read_text())['materials']
  for k,v in mm.items():defs.setdefault(k,v)
 for key,srcname in samples:
  mat=dict(defs[srcname]);m[key]=mat
  for field in ['baseColorTexture','normalTexture','metallicRoughnessTexture']:
   src=old/'material-bank'/mat[field];shutil.copyfile(src,out/src.name)
  mat['normalScale']=.12
  if key=='wood':mat['baseColorFactor']=[.88,.78,.68,1]
 n=2048;x=np.broadcast_to(np.linspace(0,1,n,dtype=np.float32)[None,:],(n,n));y=x.T
 for key,rgb,rough,metal in [('polished',[223,225,222],.09,1),('antique',[173,171,158],.31,1),('black',[19,20,19],.42,0),('glass',[255,255,255],.025,0)]:
  pattern=np.sin(x*137+y*17)*np.sin(x*23-y*79);al=np.broadcast_to(np.array(rgb,np.float32),(n,n,3)).copy();orm=np.empty((n,n,3),np.uint8);orm[:]=[255,int(rough*255),int(metal*255)];normal=np.empty_like(orm);normal[:]=[128,128,255]
  if key=='antique':
   cloud=B.noise._object_noise(x,y,7168,7);fine=B.noise._object_noise(x,y,7169,310);patina=np.maximum(0,cloud-.18)*38;al-=patina[:,:,None]+fine[:,:,None]*2;orm[:,:,1]=np.clip(rough*255+cloud*18+fine*3,40,140).astype(np.uint8)
  elif key=='polished':al+=pattern[:,:,None]*.24
  for label,pixels in [('albedo',np.clip(al,0,255).astype(np.uint8)),('normal',normal),('orm',orm)]:Image.fromarray(pixels,'RGB').save(out/(key+'-'+label+'-2k.png'),optimize=True)
  m[key]=dict(baseColorFactor=[1,1,1,1],baseColorTexture=key+'-albedo-2k.png',normalTexture=key+'-normal-2k.png',metallicRoughnessTexture=key+'-orm-2k.png',metallic=metal,roughness=1,normalScale=0,alphaMode='OPAQUE',doubleSided=False,extras={'native_resolution':2048,'intrinsic_material':True,'photo_pixels_baked':False,'baked_reflections':False})
  if key=='glass':m[key].update(transmission=.98,ior=1.5,thickness=.0012,attenuationColor=[.94,.98,.94],attenuationDistance=1.)
 dump(out/'materials.json',m);return out,m

def resolve():
 data=json.loads((R/'source-inventory-frozen.json').read_text());extra=json.loads((R/'extra-official-facts.json').read_text())if(R/'extra-official-facts.json').exists()else{}
 for p in data:
  e=extra.get(p['family_path_code'])
  if e:p.update(e)
  if p['family_path_code']=='46176099'and not p['sizes'][0].get('height_cm'):
   p['sizes']=[dict(height_cm=5,width_cm=5,depth_cm=5,official_axis_order='equal_axes',source_display='5 × 5 × 5 cm')];p['extra_note']='Resmî üç değerin tamamı5cm olduğundan eksen sırası fiziksel boyutları değiştirmez; eksen tahmini yapılmadı.'
 dump(R/'resolved-source-inventory.json',data);return data

def main():
 data=resolve();bankpath,matdefs=bank();manifest=[];pending=[];dispatch={'47161452':wood,'44306099':black_glass,'44307099':black_glass,'46176099':round_steel,'46177099':round_steel,'47169099':antique,'47168099':antique}
 for p in data:
  valid=[v for v in p['sizes']if all(isinstance(v.get(k),(float,int))for k in ['height_cm','width_cm','depth_cm'])]
  if not p['sku'] or not valid:
   pending.append(dict(title=p['title'],url=p['url'],sku=p['sku'],image_code=p['image_code'],status='needs_identity'if not p['sku']else'needs_measurement',source_sizes=p['sizes'],reason='Gerçek renkSKU’su ve başlıklı resmî dış ölçüler bekleniyor; fotoğraf dosya kodundan SKU veya fotoğraftan ölçü üretilmedi.'));continue
  seen=set()
  for v in valid:
   vals=tuple(v[k]for k in ['height_cm','width_cm','depth_cm'])
   if vals in seen:continue
   seen.add(vals);h,w,d=vals;fmt=lambda n:format(n,'g').replace('.','p');id=p['sku'].replace('/','-')+'-h'+fmt(h)+'-w'+fmt(w)+'-d'+fmt(d);out=R/'models'/id;out.mkdir(parents=True,exist_ok=True)
   meshes,gqa=dispatch[p['family_path_code']](p,v);gqa['uv_side_triangles_repaired']=M.ensure_uv_faces(meshes);gqa['all_faces_have_finite_nonzero_uv_area']=True
   mats={k:dict(matdefs[k])for k in {m['material']for m in meshes}};maps=[]
   for mat in mats.values():
    for field in ['baseColorTexture','normalTexture','metallicRoughnessTexture']:
     src=bankpath/mat[field];dest=out/src.name;shutil.copyfile(src,dest);maps.append(dict(name=dest.name,sha256=sha(dest),resolution=[2048,2048]))
   metadata=dict(id=id,name=M.title(p['title']),sku=p['sku'],url=p['url'],category='Dekoratif kutular',dimensions_cm=[w,h,d],source_dimensions_hwd_cm=list(vals),estimated_dimensions=False,source_market='Türkiye',size_source_kind='official_equal_dimensions'if p['family_path_code']=='46176099'else'official_tr',size_source_urls=p.get('product_detail_urls')or[p['url']],scale_note='Resmî Türkiye dış ölçüleri kullanıldı. İç bölmeler, yerel kalınlıklar, kapak ve menteşe ayrıntıları özgün fotoğraftan yorumlandı. Kapak kapalı nötr konum, resmî toplam dış ölçüleri korur.'+(' '+p['extra_note']if p.get('extra_note')else''),units='metres',up_axis='Y',origin='bottom bounding-box centre',source_images=p['images'],official_materials_verbatim=p.get('material'),photo_pixels_baked=False,baked_reflections=False,source_evidence_files=p['product_detail_sources'],product_photo_code=p['image_code'],variant_status=v.get('status','listed'),variant_status_verbatim='Benzer ürünleri görüntüle'if v.get('status')=='out_of_stock'else'Resmî sayfada ölçüsü listeleniyor')
   model=out/'model.json';dump(model,dict(metadata=metadata,materials=mats,meshes=meshes));dump(out/'geometry-validation.json',gqa);dump(out/'material-validation.json',dict(valid=True,native_resolution=2048,intrinsic_material=True,photo_pixels_baked=False,baked_reflections=False,maps=maps))
   report=export_assets(model,out,id);glb=out/(id+'.glb');doc,binary=read_glb(glb);doc['samplers']=[dict(magFilter=9729,minFilter=9987,wrapS=10497,wrapT=10497)]
   for t in doc.get('textures',[]):t['sampler']=0
   binary=M.embed_tangents(doc,binary);write_glb(glb,doc,binary);report['deliverable_sha256']['glb']=sha(glb);report['glb_bytes']=glb.stat().st_size;dump(report['files']['validation'],report)
   e={k:metadata[k]for k in ['id','name','sku','url','category','dimensions_cm','source_dimensions_hwd_cm','estimated_dimensions','source_market','size_source_kind','size_source_urls','scale_note','variant_status','variant_status_verbatim']};e.update(model_path=str(model),asset_dir=str(out),glb_path=str(glb),sha256=sha(glb),bytes=glb.stat().st_size,material_label=p.get('material')or'Fotoğrafına göre metal',source_images=p['images'],geometry_validation=str(out/'geometry-validation.json'),material_validation=str(out/'material-validation.json'),model_revision='completeness-box-photo-specific-v1',source_anomalies=[])
   dump(out/'topology-validation.json',AQ.check(e));manifest.append(e);dump(R/'manifest.json',manifest);print(id,e['bytes'],gqa['triangles'],flush=True)
 dump(R/'pending.json',pending);dump(R/'qa-summary.json',dict(valid=True,models=len(manifest),cards_covered=len({e['sku']for e in manifest}),pending_cards=len(pending),all_maps_2k_embedded=True,closed_topology=True,official_bounds=True,photo_pixels_baked=False,baked_reflections=False));print('COMPLETE',len(manifest),'pending',len(pending),flush=True)
if __name__=='__main__':main()
