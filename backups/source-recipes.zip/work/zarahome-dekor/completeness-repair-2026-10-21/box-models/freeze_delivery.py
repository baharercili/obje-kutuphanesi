from pathlib import Path
import json,hashlib
from PIL import Image
R=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
entries=json.loads((R/'manifest.json').read_text());pending=json.loads((R/'pending.json').read_text());qa=json.loads((R/'independent-validation.json').read_text());assert len(entries)==8 and len({e['sku']for e in entries})==7 and not pending and qa['valid']
renders=[];files=[]
for e in entries:
 d=Path(e['asset_dir'])
 for n in ['on','on-capraz','ustten']:
  p=d/(n+'.png');im=Image.open(p);alpha=im.getchannel('A').getextrema();assert im.size==(900,900) and im.mode=='RGBA' and alpha[0]==0 and alpha[1]>=250;renders.append(dict(id=e['id'],view=n,path=str(p),pixels=[900,900],transparent_background=True,alpha_range=alpha))
 for p in [Path(e['glb_path']),Path(e['model_path']),d/(e['id']+'.scn'),d/'topology-validation.json',d/'geometry-validation.json',d/'material-validation.json']+[d/(n+'.png')for n in ['on','on-capraz','ustten']]:
  assert p.exists();files.append(dict(path=str(p),sha256=sha(p),bytes=p.stat().st_size))
for p in json.loads((R/'reference-masters.json').read_text()):assert sha(p['local_master'])==p['sha256']
mirrors=json.loads((R.parent/'mirror-models/frozen-delivery.json').read_text())
for p in mirrors['deliverables']:assert sha(p['path'])==p['sha256']
visual=dict(valid=True,models=8,views=24,all_original_card_photos_inspected=True,inspection='Individual shapes, glazing, lined compartments, eight ring rolls, hinges, rolled metal profiles and twelve raised flower petals were compared with unmodified official photographs. The final metal cap normals keep the planar top reflection flat.',native_glass_preview='SceneKit uses transparent approximation for glTF KHR_materials_transmission; GLB retains physical transmission and IOR.',renders=renders)
(R/'visual-validation.json').write_text(json.dumps(visual,ensure_ascii=False,indent=2)+'\n')
frozen=dict(status='frozen',date='2026-10-21',cards=7,models=8,pending=0,all_known_official_size_variants_built=True,out_of_stock_model_ids=[e['id']for e in entries if e['variant_status']=='out_of_stock'],manifest=str(R/'manifest.json'),independent_qa=str(R/'independent-validation.json'),visual_qa=str(R/'visual-validation.json'),source_inventory=str(R/'resolved-source-inventory.json'),tr_live_details=str(R/'tr-live-product-details-frozen.json'),source_photos_unchanged=True,frozen_mirror_delivery_unchanged=True,deliverables=files)
(R/'frozen-delivery.json').write_text(json.dumps(frozen,ensure_ascii=False,indent=2)+'\n')
print('FROZEN:7 cards,8 GLB,24 PNG,8 SCN; no pending; source photos and21 frozen mirrors unchanged.')
