#!/usr/bin/env python3
"""Export shared mesh JSON to a portable GLB and an OBJ/MTL material package.

Texture paths in each material are relative to --output-dir, not the JSON file.
No mesh is simplified, welded, transformed, or re-normalized. GLB stores the
usual float32 representation; OBJ writes the original numeric precision.
Only the Python standard library is required.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path
import re
import struct


FLOAT32_MAX = 3.4028234663852886e38
TEXTURE_KEYS = ("baseColorTexture", "normalTexture", "metallicRoughnessTexture")


def _number(value, label: str, lower=None, upper=None) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"{label}: expected a number")
    if not math.isfinite(value):
        raise ValueError(f"{label}: expected a finite number")
    if lower is not None and value < lower or upper is not None and value > upper:
        raise ValueError(f"{label}: outside the supported range {lower}..{upper}")
    return float(value)


def _float_array(value, components: int, label: str) -> list:
    if not isinstance(value, list) or not value or len(value) % components:
        raise ValueError(f"{label}: expected a nonempty array in groups of {components}")
    for index, item in enumerate(value):
        _number(item, f"{label}[{index}]", -FLOAT32_MAX, FLOAT32_MAX)
    return value


def _safe_name(value: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.-]+", "-", value).strip(".-") or "material"


def _texture(raw: bytes, label: str) -> tuple[str, str]:
    if raw.startswith(b"\x89PNG\r\n\x1a\n"):
        return "image/png", ".png"
    if raw.startswith(b"\xff\xd8\xff"):
        return "image/jpeg", ".jpg"
    raise ValueError(f"{label}: texture must be a PNG or JPEG image")


def export_assets(model_path, output_dir, name: str) -> dict:
    """Return a validation report after exporting <name>.glb/.obj/.mtl.

    Input: metadata object, materials mapping, and meshes containing name,
    material, positions, normals, uvs and triangle indices. Material properties
    are baseColorFactor (RGBA), metallic/metallicFactor, roughness/roughnessFactor,
    normalScale and optional PNG/JPEG texture paths named in TEXTURE_KEYS.
    Optional doubleSided, alphaMode and alphaCutoff are also supported.
    """
    model_path = Path(model_path).resolve()
    output_dir = Path(output_dir).resolve()
    if not isinstance(name, str) or not name or name in (".", ".."):
        raise ValueError("name must be a nonempty file basename")
    if Path(name).name != name or "/" in name or "\\" in name or "\n" in name or "\r" in name:
        raise ValueError("name must be a single file basename without path separators")
    source = json.loads(model_path.read_text(encoding="utf-8"))
    if not isinstance(source, dict):
        raise ValueError("The model must be a JSON object")
    metadata = source.get("metadata", {})
    if not isinstance(metadata, dict):
        raise ValueError("metadata must be an object")
    materials = source.get("materials")
    if not isinstance(materials, dict) or not materials:
        raise ValueError("materials must be a nonempty mapping")
    meshes = source.get("meshes")
    if not isinstance(meshes, list) or not meshes:
        raise ValueError("meshes must be a nonempty array")

    # Validate every source before writing any deliverable.
    texture_data = {}
    material_defs = []
    material_indices = {}
    material_textures = {}
    for material_name, material in materials.items():
        if not isinstance(material_name, str) or not material_name:
            raise ValueError("Each material needs a nonempty string name")
        if not isinstance(material, dict):
            raise ValueError(f"{material_name}: material must be an object")
        factor = material.get("baseColorFactor", [1, 1, 1, 1])
        if not isinstance(factor, list) or len(factor) != 4:
            raise ValueError(f"{material_name}: baseColorFactor must contain RGBA")
        factor = [_number(v, f"{material_name}.baseColorFactor", 0, 1) for v in factor]
        metallic = _number(material.get("metallicFactor", material.get("metallic", 0)),
                           f"{material_name}.metallic", 0, 1)
        roughness = _number(material.get("roughnessFactor", material.get("roughness", 0.5)),
                            f"{material_name}.roughness", 0, 1)
        normal_scale = _number(material.get("normalScale", 0.3),
                               f"{material_name}.normalScale", 0)
        double_sided = material.get("doubleSided", False)
        if not isinstance(double_sided, bool):
            raise ValueError(f"{material_name}.doubleSided: expected a boolean")
        alpha_mode = material.get("alphaMode", "BLEND" if factor[3] < 1 else "OPAQUE")
        if alpha_mode not in ("OPAQUE", "MASK", "BLEND"):
            raise ValueError(f"{material_name}.alphaMode: expected OPAQUE, MASK or BLEND")
        definition = {
            "name": material_name,
            "pbrMetallicRoughness": {"baseColorFactor": factor,
                                     "metallicFactor": metallic,
                                     "roughnessFactor": roughness},
            "doubleSided": double_sided,
            "alphaMode": alpha_mode,
        }
        if alpha_mode == "MASK":
            definition["alphaCutoff"] = _number(material.get("alphaCutoff", 0.5),
                                                f"{material_name}.alphaCutoff", 0, 1)
        material_indices[material_name] = len(material_defs)
        material_defs.append(definition)
        material_textures[material_name] = {"normalScale": normal_scale}
        for key in TEXTURE_KEYS:
            relative = material.get(key)
            if relative is None:
                continue
            if not isinstance(relative, str) or not relative:
                raise ValueError(f"{material_name}.{key}: expected a relative texture path")
            if Path(relative).is_absolute():
                raise ValueError(f"{material_name}.{key}: texture path must be relative to output-dir")
            path = (output_dir / relative).resolve()
            try:
                path.relative_to(output_dir)
            except ValueError as exc:
                raise ValueError(f"{material_name}.{key}: texture must be inside output-dir") from exc
            raw = path.read_bytes()
            mime_type, extension = _texture(raw, str(path))
            digest = hashlib.sha256(raw).hexdigest()
            if digest not in texture_data:
                texture_data[digest] = {"data": raw, "mimeType": mime_type,
                                        "relative": f"textures/{digest[:24]}{extension}",
                                        "source": str(path)}
            material_textures[material_name][key] = digest

    mesh_stats = []
    global_min = [math.inf] * 3
    global_max = [-math.inf] * 3
    for mesh_index, mesh in enumerate(meshes):
        if not isinstance(mesh, dict):
            raise ValueError(f"mesh {mesh_index}: expected an object")
        mesh_name = mesh.get("name", f"mesh-{mesh_index + 1}")
        if not isinstance(mesh_name, str) or not mesh_name:
            raise ValueError(f"mesh {mesh_index}: name must be a nonempty string")
        if mesh.get("material") not in material_indices:
            raise ValueError(f"{mesh_name}: material is missing or unknown")
        positions = _float_array(mesh.get("positions"), 3, f"{mesh_name}.positions")
        normals = _float_array(mesh.get("normals"), 3, f"{mesh_name}.normals")
        uvs = _float_array(mesh.get("uvs"), 2, f"{mesh_name}.uvs")
        vertex_count = len(positions) // 3
        if len(normals) != len(positions) or len(uvs) != vertex_count * 2:
            raise ValueError(f"{mesh_name}: normal/UV counts must match vertex count")
        indices = mesh.get("indices")
        if not isinstance(indices, list) or not indices or len(indices) % 3:
            raise ValueError(f"{mesh_name}: indices must contain complete triangles")
        if any(isinstance(i, bool) or not isinstance(i, int) or i < 0 or
               i >= vertex_count or i > 0xFFFFFFFF for i in indices):
            raise ValueError(f"{mesh_name}: triangle index is invalid")
        normal_error = 0.0
        for index in range(0, len(normals), 3):
            length = math.hypot(*normals[index:index + 3])
            if length == 0:
                raise ValueError(f"{mesh_name}: normal {index // 3} is zero")
            # A nonzero source normal could underflow to zero in a GLB float32.
            stored = struct.unpack("<3f", struct.pack("<3f", *normals[index:index + 3]))
            if not any(stored):
                raise ValueError(f"{mesh_name}: normal {index // 3} underflows float32")
            normal_error = max(normal_error, abs(length - 1))
        bounds_min = [min(positions[axis::3]) for axis in range(3)]
        bounds_max = [max(positions[axis::3]) for axis in range(3)]
        global_min = [min(a, b) for a, b in zip(global_min, bounds_min)]
        global_max = [max(a, b) for a, b in zip(global_max, bounds_max)]
        mesh_stats.append({"name": mesh_name, "material": mesh["material"],
                           "vertices": vertex_count, "triangles": len(indices) // 3,
                           "bounds_metres": {"min": bounds_min, "max": bounds_max},
                           "max_normal_length_error": normal_error})

    gltf = {
        "asset": {"version": "2.0", "generator": "Studio decor shared-geometry exporter"},
        "scene": 0, "scenes": [{"name": name, "nodes": []}],
        "nodes": [], "meshes": [], "materials": material_defs,
        "accessors": [], "bufferViews": [], "buffers": [],
        "extras": {"metadata": metadata, "coordinateSystem": "metres; Y up; Z front",
                   "sourceGeometry": model_path.name},
    }
    binary = bytearray()

    def add_view(data: bytes, target=None) -> int:
        binary.extend(b"\0" * (-len(binary) % 4))
        index = len(gltf["bufferViews"])
        view = {"buffer": 0, "byteOffset": len(binary), "byteLength": len(data)}
        if target is not None:
            view["target"] = target
        gltf["bufferViews"].append(view)
        binary.extend(data)
        return index

    def add_accessor(values: list, components: int, kind: str, integer=False, bounds=False) -> int:
        data = struct.pack(f"<{len(values)}{'I' if integer else 'f'}", *values)
        accessor = {"bufferView": add_view(data, 34963 if integer else 34962),
                    "byteOffset": 0, "componentType": 5125 if integer else 5126,
                    "count": len(values) // components, "type": kind}
        if bounds:
            stored = struct.unpack(f"<{len(values)}f", data)
            accessor["min"] = [min(stored[i::components]) for i in range(components)]
            accessor["max"] = [max(stored[i::components]) for i in range(components)]
        index = len(gltf["accessors"])
        gltf["accessors"].append(accessor)
        return index

    texture_indices = {}
    if texture_data:
        gltf["textures"] = []
        gltf["images"] = []
        gltf["samplers"] = [{"magFilter": 9729, "minFilter": 9987,
                              "wrapS": 10497, "wrapT": 10497}]
        for digest, texture in texture_data.items():
            texture_indices[digest] = len(gltf["textures"])
            image_index = len(gltf["images"])
            gltf["images"].append({"bufferView": add_view(texture["data"]),
                                    "mimeType": texture["mimeType"],
                                    "name": Path(texture["source"]).name})
            gltf["textures"].append({"source": image_index, "sampler": 0})
    for material_name, references in material_textures.items():
        material = material_defs[material_indices[material_name]]
        for key in TEXTURE_KEYS:
            if key not in references:
                continue
            reference = {"index": texture_indices[references[key]], "texCoord": 0}
            if key == "normalTexture":
                reference["scale"] = references["normalScale"]
                material[key] = reference
            else:
                material["pbrMetallicRoughness"][key] = reference

    for mesh, stats in zip(meshes, mesh_stats):
        primitive = {
            "attributes": {
                "POSITION": add_accessor(mesh["positions"], 3, "VEC3", bounds=True),
                "NORMAL": add_accessor(mesh["normals"], 3, "VEC3"),
                "TEXCOORD_0": add_accessor(mesh["uvs"], 2, "VEC2"),
            },
            "indices": add_accessor(mesh["indices"], 1, "SCALAR", integer=True),
            "material": material_indices[mesh["material"]], "mode": 4,
        }
        node_index = len(gltf["nodes"])
        gltf["meshes"].append({"name": stats["name"], "primitives": [primitive]})
        gltf["nodes"].append({"name": stats["name"], "mesh": node_index})
        gltf["scenes"][0]["nodes"].append(node_index)
    gltf["buffers"].append({"byteLength": len(binary)})
    json_data = json.dumps(gltf, ensure_ascii=False, separators=(",", ":"),
                           allow_nan=False).encode("utf-8")
    json_data += b" " * (-len(json_data) % 4)
    binary.extend(b"\0" * (-len(binary) % 4))
    glb_size = 12 + 8 + len(json_data) + 8 + len(binary)
    glb = (struct.pack("<4sII", b"glTF", 2, glb_size) +
           struct.pack("<I4s", len(json_data), b"JSON") + json_data +
           struct.pack("<I4s", len(binary), b"BIN\0") + binary)

    # OBJ vertices, UVs and normals remain in the same order as the input. OBJ
    # material names are made unique and whitespace-free for broad importer use.
    obj_names = {material: f"mat_{index + 1:02d}_{_safe_name(material)}"
                 for index, material in enumerate(materials)}
    obj = ["# Studio decor model; metres; Y up; Z front", f"mtllib {name}.mtl"]
    offset = 1
    for mesh, stats in zip(meshes, mesh_stats):
        obj.extend([f"o {_safe_name(stats['name'])}", f"usemtl {obj_names[mesh['material']]}"])
        for key, prefix, width in (("positions", "v", 3), ("uvs", "vt", 2), ("normals", "vn", 3)):
            values = mesh[key]
            obj.extend(prefix + " " + " ".join(format(float(v), ".17g") for v in values[i:i + width])
                       for i in range(0, len(values), width))
        obj.append("s 1")
        indices = mesh["indices"]
        for i in range(0, len(indices), 3):
            face = [v + offset for v in indices[i:i + 3]]
            obj.append("f " + " ".join(f"{v}/{v}/{v}" for v in face))
        offset += stats["vertices"]
    mtl = ["# PBR properties use common OBJ extensions; GLB is the material master.",
           "# Packed metallic/roughness maps: roughness=G, metallic=B."]
    for material_name, definition in zip(materials, material_defs):
        pbr = definition["pbrMetallicRoughness"]
        rgba = pbr["baseColorFactor"]
        roughness = pbr["roughnessFactor"]
        ns = min(1000, max(0, 2 / max(roughness, 0.001) ** 4 - 2))
        mtl.extend(["", f"newmtl {obj_names[material_name]}",
                    "Kd " + " ".join(format(v, ".9g") for v in rgba[:3]),
                    f"d {rgba[3]:.9g}", f"Pm {pbr['metallicFactor']:.9g}",
                    f"Pr {roughness:.9g}", f"Ns {ns:.9g}", "illum 2"])
        references = material_textures[material_name]
        if "baseColorTexture" in references:
            mtl.append("map_Kd " + texture_data[references["baseColorTexture"]]["relative"])
        if "normalTexture" in references:
            normal_path = texture_data[references["normalTexture"]]["relative"]
            mtl.append(f"norm -bm {references['normalScale']:.9g} {normal_path}")
        if "metallicRoughnessTexture" in references:
            packed_path = texture_data[references["metallicRoughnessTexture"]]["relative"]
            mtl.extend([f"map_Pr -imfchan g {packed_path}", f"map_Pm -imfchan b {packed_path}"])

    output_dir.mkdir(parents=True, exist_ok=True)
    for texture in texture_data.values():
        texture_path = output_dir / texture["relative"]
        texture_path.parent.mkdir(parents=True, exist_ok=True)
        if not texture_path.exists() or texture_path.read_bytes() != texture["data"]:
            texture_path.write_bytes(texture["data"])
    glb_path = output_dir / f"{name}.glb"
    obj_path = output_dir / f"{name}.obj"
    mtl_path = output_dir / f"{name}.mtl"
    glb_path.write_bytes(glb)
    obj_path.write_text("\n".join(obj) + "\n", encoding="utf-8")
    mtl_path.write_text("\n".join(mtl) + "\n", encoding="utf-8")
    report = {
        "source": str(model_path), "metadata": metadata,
        "files": {"glb": str(glb_path), "obj": str(obj_path), "mtl": str(mtl_path)},
        "units": "m", "up_axis": "Y", "glb_bytes": len(glb),
        "mesh_count": len(meshes), "material_count": len(materials),
        "texture_count": len(texture_data),
        "vertices": sum(s["vertices"] for s in mesh_stats),
        "triangles": sum(s["triangles"] for s in mesh_stats),
        "bounds_metres": {"min": global_min, "max": global_max,
                           "size": [b - a for a, b in zip(global_min, global_max)]},
        "meshes": mesh_stats,
        "textures": [{"file": t["relative"], "bytes": len(t["data"]), "sha256": digest}
                     for digest, t in texture_data.items()],
        "validation": {"finite_geometry": True, "valid_triangle_indices": True,
                       "nonzero_normals": True, "geometry_transformed": False,
                       "topology_preserved": True, "embedded_glb_textures": True},
        "material_note": "GLB embeds PBR materials. OBJ PBR/normal map support depends on importer.",
    }
    report_path = output_dir / f"{name}.validation.json"
    report["files"]["validation"] = str(report_path)
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False) + "\n",
                           encoding="utf-8")
    return report


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--name", required=True)
    args = parser.parse_args()
    print(json.dumps(export_assets(args.model, args.output_dir, args.name),
                     ensure_ascii=False, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
