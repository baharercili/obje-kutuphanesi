"""Reusable hollow-vase geometry, standard library only.

    meshes, validation = build_vase({
        'id': 'example', 'width': .18, 'height': .30, 'depth': .18,
        'profile': [[.48, 0], [.9, .3], [1, .55], [.5, .8], [.5, 1]],
        'wall_thickness': .003, 'base_thickness': .006,
        'radial_segments': 128, 'profile_samples': 4,
        'flutes': {'count': 24, 'amplitude': .025, 'twist_turns': .12},
        'mouth': {'waves': 3, 'height_amplitude': .005, 'start': .82},
        'handles': {'count': 2, 'reach': .05, 'tube_radius': .006},
    })

Dimensions, thickness, mouth height amplitude and handle reach/radius are metres.
Profile points are [radius/max_radius, height/total_height], from bottom to mouth.
The outer profile's y coordinates must increase; r need not be monotonic. Radii
are interpolated with a shape-preserving cubic, so narrow necks do not overshoot.
Flute/lobe/organic radial amplitudes are fractions of the local body radius.
Twist is in full turns over the height. `mouth.oval` is a ratio (default 1).
The supplied dimensions describe the entire model, including optional handles.
`body_width_ratio` may reserve body width for handles; default .68 with handles.
Final fitting preserves the requested bounding box and reports the resulting
wall-thickness range after that small affine correction. Set `fit_dimensions`
False to retain the unscaled physical construction.

Every vessel is a closed orientable solid: outside + rounded rim + inward-offset
inside + inner floor + outer base. There is no surface across the mouth opening.
Each handle is a separately capped 3D swept arch with a genuine open aperture.
Handles may overlap the body at their two attachment points, as separate parts.
Returned meshes use the shared positions/normals/uvs/indices/material JSON schema.
This module does not write assets, materials, manifests or approved product files.
"""

from __future__ import annotations

import math
from collections import Counter

TAU = math.tau

PROFILES = {
    'cylinder': [[.92, 0], [1, .025], [1, .97], [.98, 1]],
    'bottle': [[.62, 0], [.72, .025], [.9, .16], [1, .42], [.97, .62],
               [.83, .75], [.4, .84], [.34, .9], [.34, .98], [.39, 1]],
    'round': [[.48, 0], [.62, .035], [.83, .17], [.98, .39], [1, .55],
              [.94, .73], [.73, .87], [.64, .94], [.7, .98], [.69, 1]],
    'double_bulb': [[.42, 0], [.5, .025], [.73, .2], [.96, .38], [1, .48],
                    [.9, .59], [.61, .67], [.68, .72], [.85, .79], [.81, .86],
                    [.6, .93], [.58, .98], [.64, 1]],
    'flared': [[.48, 0], [.55, .025], [.62, .12], [.7, .4], [.84, .72], [1, 1]],
    'urn': [[.36, 0], [.44, .035], [.58, .12], [.84, .26], [1, .5], [.94, .7],
            [.66, .84], [.51, .9], [.52, .96], [.66, 1]],
    'amphora': [[.25, 0], [.37, .055], [.62, .2], [.89, .4], [1, .58],
                [.91, .72], [.61, .84], [.38, .9], [.38, .97], [.45, 1]],
    'organic': [[.48, 0], [.68, .07], [.93, .25], [1, .48], [.92, .7], [.76, .88], [.83, 1]],
}
PROFILES['hulu'] = PROFILES['double_bulb']
PROFILES['doublebulb'] = PROFILES['double_bulb']


def _add(a, b): return tuple(x + y for x, y in zip(a, b))
def _sub(a, b): return tuple(x - y for x, y in zip(a, b))
def _mul(a, value): return tuple(x * value for x in a)
def _dot(a, b): return sum(x * y for x, y in zip(a, b))
def _cross(a, b): return (a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0])
def _length(a): return math.sqrt(_dot(a, a))
def _unit(a):
    length = _length(a)
    if length < 1e-14: raise ValueError('Degenerate geometry direction')
    return _mul(a, 1 / length)
def _clamp(x, lo, hi): return max(lo, min(hi, x))
def _smooth(x):
    x = _clamp(x, 0, 1)
    return x*x*(3-2*x)


def _finite_number(value, label, low=None, high=None):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ValueError(f'{label} must be a finite number')
    if low is not None and value < low or high is not None and value > high:
        raise ValueError(f'{label} must be in {low}..{high}')
    return float(value)


def _integer(value, label, low, high):
    if isinstance(value, bool) or not isinstance(value, int) or not low <= value <= high:
        raise ValueError(f'{label} must be an integer in {low}..{high}')
    return value


def _profile(spec):
    hint = spec.get('shape_hint', spec.get('kind', 'round'))
    source = spec.get('profile', PROFILES.get(hint, PROFILES['round']))
    if not isinstance(source, (list, tuple)) or len(source) < 2:
        raise ValueError('profile needs at least two [r,y] points')
    points = []
    for index, point in enumerate(source):
        if not isinstance(point, (list, tuple)) or len(point) != 2:
            raise ValueError(f'profile[{index}] must contain [r,y]')
        r = _finite_number(point[0], f'profile[{index}].r', 0, 3)
        y = _finite_number(point[1], f'profile[{index}].y', 0, 1)
        if points and y <= points[-1][1]:
            raise ValueError('profile y values must strictly increase')
        points.append((r, y))
    if abs(points[0][1]) > 1e-10 or abs(points[-1][1]-1) > 1e-10:
        raise ValueError('profile must start at y=0 and end at y=1')
    if points[-1][0] <= 0 or max(r for r, _ in points) <= 0:
        raise ValueError('The vessel needs a positive mouth and body radius')
    maximum = max(r for r, _ in points)
    return [(r/maximum, y) for r, y in points]


def _profile_sampler(points):
    """Fritsch-Carlson monotone cubic interpolation of radius as a function of y."""
    rs = [p[0] for p in points]; ys = [p[1] for p in points]
    widths = [b-a for a, b in zip(ys, ys[1:])]
    slopes = [(b-a)/h for a, b, h in zip(rs, rs[1:], widths)]
    derivatives = [slopes[0]]
    for i in range(1, len(points)-1):
        left, right = slopes[i-1], slopes[i]
        if left*right <= 0:
            derivatives.append(0.)
        else:
            w1 = 2*widths[i]+widths[i-1]; w2 = widths[i]+2*widths[i-1]
            derivatives.append((w1+w2)/(w1/left+w2/right))
    derivatives.append(slopes[-1])
    def sample(y):
        y = _clamp(y, 0, 1)
        i = next((j for j in range(len(ys)-1) if y <= ys[j+1]), len(ys)-2)
        t = (y-ys[i])/widths[i]
        h = widths[i]
        return ((2*t**3-3*t*t+1)*rs[i] + (t**3-2*t*t+t)*h*derivatives[i]
                + (-2*t**3+3*t*t)*rs[i+1] + (t**3-t*t)*h*derivatives[i+1])
    return sample


def _handle_settings(spec):
    raw = spec.get('handles', 0)
    if raw is None: raw = 0
    if isinstance(raw, int) and not isinstance(raw, bool): return {'count': raw}
    if not isinstance(raw, dict): raise ValueError('handles must be a count or settings object')
    return dict(raw)


def _shape_function(spec, profile, width, height, depth):
    flutes = spec.get('flutes') or {}
    if isinstance(flutes, (int, float)): flutes = {'count': int(flutes), 'amplitude': .025}
    lobes = spec.get('lobes') or {}
    if isinstance(lobes, (int, float)): lobes = {'count': int(lobes), 'amplitude': .08}
    organic = spec.get('organic') or {}
    if isinstance(organic, (int, float)): organic = {'amplitude': float(organic)}
    mouth = spec.get('mouth') or {}
    if not isinstance(mouth, dict): raise ValueError('mouth must be a settings object')
    for label, setting in [('flutes', flutes), ('lobes', lobes), ('organic', organic)]:
        if not isinstance(setting, dict): raise ValueError(f'{label} must be settings object')
    global_twist = _finite_number(spec.get('twist_turns', 0), 'twist_turns', -4, 4)
    cross_section = spec.get('cross_section','ellipse')
    if cross_section not in ('ellipse','rectangle','superellipse'):
        raise ValueError('cross_section must be ellipse, rectangle or superellipse')
    exponent = _finite_number(spec.get('superellipse_exponent',4 if cross_section!='ellipse' else 2),
                              'superellipse_exponent',2,16)
    ox = _finite_number(organic.get('offset_x', 0), 'organic.offset_x', -width/3, width/3)
    oz = _finite_number(organic.get('offset_z', 0), 'organic.offset_z', -depth/3, depth/3)
    amplitude = _finite_number(organic.get('amplitude', 0), 'organic.amplitude', 0, .24)
    mouth_waves = _integer(mouth.get('waves', 0), 'mouth.waves', 0, 24)
    mouth_height = _finite_number(mouth.get('height_amplitude', mouth.get('amplitude', 0)),
                                   'mouth.height_amplitude', 0, height*.12)
    mouth_radius = _finite_number(mouth.get('radial_amplitude', 0), 'mouth.radial_amplitude', 0, .3)
    mouth_oval = _finite_number(mouth.get('oval', 1), 'mouth.oval', .5, 2)
    mouth_start = _finite_number(mouth.get('start', .8), 'mouth.start', 0, .99)
    phase = _finite_number(mouth.get('phase', .4), 'mouth.phase')
    components = []
    for label, settings, default in [('flutes', flutes, .025), ('lobes', lobes, .08)]:
        count = _integer(settings.get('count', 0), f'{label}.count', 0, 128)
        amp = _finite_number(settings.get('amplitude', default if count else 0), f'{label}.amplitude', 0, .3)
        twist = _finite_number(settings.get('twist_turns', global_twist), f'{label}.twist_turns', -4, 4)
        start = _finite_number(settings.get('start', 0), f'{label}.start', 0, 1)
        end = _finite_number(settings.get('end', 1), f'{label}.end', 0, 1)
        if end < start: raise ValueError(f'{label}.end must be >= start')
        components.append((count, amp, twist, start, end, float(settings.get('phase', 0))))
    def surface(y, theta):
        radius = profile(y)
        modulation = 1.
        for count, amp, twist, start, end, component_phase in components:
            if count and start <= y <= end:
                edge = min(1., (y-start)/.04 if start > 0 else 1., (end-y)/.04 if end < 1 else 1.)
                modulation += amp*_smooth(edge)*math.cos(count*(theta-TAU*twist*y)+component_phase)
        modulation += amplitude*(.65*math.sin(3*theta+1.4*y+.7)+.35*math.sin(5*theta-2.1*y))
        mouth_influence = _smooth((y-mouth_start)/(1-mouth_start))
        modulation *= 1+mouth_radius*mouth_influence*math.sin(mouth_waves*theta+phase)
        stretch = 1+(mouth_oval-1)*mouth_influence
        rotation = TAU*global_twist*y
        # A rotating elliptical section supports twisted sculptural bodies too.
        cosine=math.cos(theta);sine=math.sin(theta)
        x_section=math.copysign(abs(cosine)**(2/exponent),cosine)
        z_section=math.copysign(abs(sine)**(2/exponent),sine)
        x = width*.5*radius*modulation*x_section*stretch
        z = depth*.5*radius*modulation*z_section/stretch
        x, z = x*math.cos(rotation)-z*math.sin(rotation), x*math.sin(rotation)+z*math.cos(rotation)
        return (x+ox*math.sin(math.pi*y),
                height*y+mouth_height*mouth_influence*math.sin(mouth_waves*theta+phase),
                z+oz*math.sin(math.pi*y+.3)*math.sin(math.pi*y))
    return surface


def _normal_at(surface, y, theta):
    dy = 1e-5; dt = 1e-5
    tangent_y = _sub(surface(min(1, y+dy), theta), surface(max(0, y-dy), theta))
    tangent_theta = _sub(surface(y, theta+dt), surface(y, theta-dt))
    return _unit(_cross(tangent_y, tangent_theta))


def _raw_shell(spec, surface, profile, height, thickness, floor, n, samples):
    ys = {0., 1.}
    # Uniform vertical subdivisions keep broad profiles, long necks and waves well resolved.
    vertical = max(32, int(spec.get('vertical_segments', 96)))
    ys.update(i/vertical for i in range(vertical+1))
    for i in range(len(profile)-1):
        a = profile[i][1]; b = profile[i+1][1]
        ys.update(a+(b-a)*j/samples for j in range(samples+1))
    ys = sorted({round(y, 12) for y in ys})
    # A zero-radius bottom uses one pole rather than a degenerate stack of vertices.
    if profile[0][0] == 0: ys = [y for y in ys if y > 1e-8]
    outer, inner, pair_rows = [], [], []
    for y in ys:
        ring = [surface(y, TAU*j/n) for j in range(n)]
        inward = [_sub(p, _mul(_normal_at(surface, y, TAU*j/n), thickness)) for j, p in enumerate(ring)]
        outer.append((ring, y))
        if min(p[1] for p in inward) > floor+height*.001:
            if any(math.hypot(p[0], p[2]) < thickness*.15 for p in inward):
                raise ValueError('Wall thickness is too large for a narrow interior section')
            inner.append((inward, y))
            pair_rows.append((len(outer)-1, len(inner)-1))
    if len(inner) < 3 or inner[-1][1] < .999:
        raise ValueError('Wall/base thickness leaves no usable mouth or inner cavity')
    outer_top = outer[-1][0]; inner_top = inner[-1][0]
    # Insetting the top must actually shrink its cross section (a real open mouth).
    for a, b in zip(outer_top, inner_top):
        if math.hypot(b[0], b[2]) >= math.hypot(a[0], a[2]) or math.hypot(b[0], b[2]) < thickness*.2:
            raise ValueError('Mouth is too narrow or too steep for the selected wall thickness')
    rounding = _finite_number(spec.get('rim_rounding', 1), 'rim_rounding', 0, 1)
    rim_segments = _integer(spec.get('rim_segments', 6), 'rim_segments', 1, 24)
    rim = []
    for k in range(1, rim_segments):
        angle = math.pi*k/rim_segments
        ring = []
        for a, b in zip(outer_top, inner_top):
            gap = _sub(a, b); normal = _unit(gap); midpoint = _mul(_add(a,b), .5)
            up = _sub((0.,1.,0.), _mul(normal, normal[1]))
            up = _unit(up) if _length(up)>1e-8 else (1.,0.,0.)
            ring.append(_add(_add(midpoint, _mul(gap, .5*math.cos(angle))),
                             _mul(up, _length(gap)*.5*math.sin(angle)*rounding)))
        rim.append((ring, 1.))
    # Interior floor lies above the exterior bottom, leaving a solid base.
    inner_floor = [(p[0], floor, p[2]) for p in inner[0][0]]
    rings = outer+rim+list(reversed(inner))+[(inner_floor, floor/height)]
    vertices, uvs, faces = [], [], []
    cols = n+1
    for ring, normalized_y in rings:
        for j in range(n+1):
            vertices.append(ring[j % n])
            uvs.append((j/n, 1-normalized_y))
    for row in range(len(rings)-1):
        for j in range(n):
            a=row*cols+j; b=a+cols
            faces.extend(((a,b,b+1),(a,b+1,a+1)))
    bottom = len(vertices); floor_center = bottom+1
    # Bottom center follows the normalized profile's base at y=0.
    vertices.extend(((0.,0.,0.), (0.,floor,0.)))
    uvs.extend(((.5,1.),(.5,1-floor/height)))
    for j in range(n):
        faces.append((bottom,j,j+1))
        a=(len(rings)-1)*cols+j
        faces.append((floor_center,a+1,a))
    # Index pairs let validation report physical wall thickness after final fitting.
    correspondences = []
    for outer_row, inner_row in pair_rows:
        row_in_shell = len(outer)+len(rim)+len(inner)-1-inner_row
        correspondences.extend((outer_row*cols+j, row_in_shell*cols+j) for j in range(n))
    return {'name':str(spec.get('id','vase'))+'-hollow-shell', 'material':spec.get('material','ceramic'),
            '_vertices':vertices, '_faces':faces, '_uvs':uvs, '_wall_pairs':correspondences}


def _raw_handle(spec, settings, surface, angle_degrees, index, width, height):
    count = _integer(settings.get('path_segments', 48), 'handles.path_segments', 8, 256)
    sides = _integer(settings.get('radial_segments', 16), 'handles.radial_segments', 6, 64)
    reach = _finite_number(settings.get('reach', width*.23), 'handles.reach', .001, width*2)
    tube = _finite_number(settings.get('tube_radius', min(width,height)*.035), 'handles.tube_radius', .0002, width*.2)
    lower = _finite_number(settings.get('y_bottom', .36), 'handles.y_bottom', .02, .95)
    upper = _finite_number(settings.get('y_top', .8), 'handles.y_top', .04, .99)
    if upper-lower < .05: raise ValueError('Handle attachment heights are too close')
    angle = math.radians(angle_degrees)
    direction = (math.cos(angle),0.,math.sin(angle))
    side_direction = (-math.sin(angle),0.,math.cos(angle))
    def path(t):
        y=upper+(lower-upper)*t
        anchor=surface(y,angle)
        # Ends overlap the ceramic body slightly to avoid a detached appearance.
        displacement=reach*math.sin(math.pi*t)-tube*1.1
        return _add(anchor,_mul(direction,displacement))
    vertices, uvs, faces = [], [], []
    for i in range(count+1):
        t=i/count; position=path(t)
        tangent=_unit(_sub(path(min(1,t+1e-5)),path(max(0,t-1e-5))))
        binormal=_unit(_cross(tangent,side_direction))
        for j in range(sides+1):
            a=TAU*j/sides
            vertices.append(_add(position,_mul(_add(_mul(side_direction,math.cos(a)),_mul(binormal,math.sin(a))),tube)))
            uvs.append((j/sides,t))
    cols=sides+1
    for i in range(count):
        for j in range(sides):
            a=i*cols+j;b=a+cols
            faces.extend(((a,b+1,b),(a,a+1,b+1)))
    c0=len(vertices); c1=c0+1
    vertices.extend((path(0),path(1)));uvs.extend(((.5,0),(.5,1)))
    for j in range(sides):
        faces.append((c0,j+1,j))
        a=count*cols+j
        faces.append((c1,a,a+1))
    if _signed_volume(vertices,faces)<0: faces=[(a,c,b) for a,b,c in faces]
    return {'name':str(spec.get('id','vase'))+f'-open-handle-{index+1}',
            'material':settings.get('material',spec.get('material','ceramic')),
            '_vertices':vertices,'_faces':faces,'_uvs':uvs,'_wall_pairs':[]}


def _signed_volume(vertices, faces):
    return sum(_dot(vertices[a],_cross(vertices[b],vertices[c])) for a,b,c in faces)/6


def _finalize(raw):
    vertices=raw['_vertices'];faces=raw['_faces'];uvs=raw['_uvs']
    normals=[[0.,0.,0.] for _ in vertices]
    mapping={};weld=[];edges=Counter();direction=Counter();min_area=math.inf
    for vertex in vertices:
        key=tuple(round(v,10) for v in vertex)
        weld.append(mapping.setdefault(key,len(mapping)))
    for a,b,c in faces:
        fn=_cross(_sub(vertices[b],vertices[a]),_sub(vertices[c],vertices[a]))
        area=_length(fn)*.5
        min_area=min(min_area,area)
        if not math.isfinite(area) or area<=1e-14: raise ValueError(f"{raw['name']}: degenerate triangle")
        for index in (a,b,c):
            for axis in range(3): normals[index][axis]+=fn[axis]
        aa,bb,cc=(weld[a],weld[b],weld[c])
        for start,end in ((aa,bb),(bb,cc),(cc,aa)):
            edge=tuple(sorted((start,end)));edges[edge]+=1
            direction[edge]+=1 if start<end else -1
    if not all(value==2 for value in edges.values()): raise ValueError(f"{raw['name']}: shell has an open/nonmanifold edge")
    if any(direction.values()): raise ValueError(f"{raw['name']}: inconsistent face winding")
    grouped={}
    for index,key in enumerate(weld):
        grouped[key]=_add(grouped.get(key,(0.,0.,0.)),normals[index])
    normals=[_unit(grouped[key]) for key in weld]
    volume=_signed_volume(vertices,faces)
    if volume<=0: raise ValueError(f"{raw['name']}: nonpositive solid volume")
    if raw.get('_flat_normals',False):
        expanded_vertices=[];expanded_uvs=[];expanded_normals=[];expanded_faces=[]
        for a,b,c in faces:
            face_normal=_unit(_cross(_sub(vertices[b],vertices[a]),_sub(vertices[c],vertices[a])))
            first=len(expanded_vertices)
            expanded_vertices.extend((vertices[a],vertices[b],vertices[c]))
            expanded_uvs.extend((uvs[a],uvs[b],uvs[c]))
            expanded_normals.extend((face_normal,face_normal,face_normal))
            expanded_faces.append((first,first+1,first+2))
        vertices,uvs,normals,faces=expanded_vertices,expanded_uvs,expanded_normals,expanded_faces
    positions=[float(round(v,9)) for point in vertices for v in point]
    if not all(math.isfinite(v) for v in positions): raise ValueError('Nonfinite vertex')
    mesh={'name':raw['name'],'material':raw['material'],'positions':positions,
          'normals':[float(round(v,8)) for normal in normals for v in normal],
          'uvs':[float(round(v,8)) for uv in uvs for v in uv],
          'indices':[v for face in faces for v in face]}
    return mesh, {'name':raw['name'],'vertices':len(vertices),'triangles':len(faces),
                  'closed_after_uv_seam_weld':True,'consistent_winding':True,
                  'signed_volume_m3':volume,'min_triangle_area_m2':min_area,
                  'bounds_metres':{'min':[min(p[i] for p in vertices) for i in range(3)],
                                   'max':[max(p[i] for p in vertices) for i in range(3)]}}


def build_vase(spec):
    """Return (standard JSON meshes, validation report) without writing any files.

    Required dimensions: width/height/depth in metres, or dimensions_cm [W,H,D].
    Optional shape_hint presets: cylinder, bottle, round, double_bulb/hulu, flared,
    urn, amphora, organic. Supplying profile overrides the preset. Optional
    flutes/lobes/mouth/organic/handles settings are documented above.
    cross_section='rectangle' uses a rounded rectangular superellipse (exponent
    4 by default, or superellipse_exponent=8 for squarer corners). facets=8 sets
    a true 8-sided section. Faceted models default to flat_normals=True, with
    separate per-triangle vertices/normals; other models keep smooth normals.
    """
    if not isinstance(spec,dict): raise ValueError('spec must be an object')
    dimensions=spec.get('dimensions_cm')
    if dimensions is not None:
        if len(dimensions)!=3: raise ValueError('dimensions_cm must contain W,H,D')
        defaults=[float(v)/100 for v in dimensions]
    else: defaults=[None,None,None]
    width,height,depth=[_finite_number(spec.get(key,default),key,.002,20)
                        for key,default in zip(('width','height','depth'),defaults)]
    thickness=_finite_number(spec.get('wall_thickness',min(.004,min(width,depth)*.025)),
                             'wall_thickness',.0002,min(width,depth)*.2)
    floor=_finite_number(spec.get('base_thickness',thickness*1.75),'base_thickness',thickness*.5,height*.25)
    n=_integer(spec.get('radial_segments',128),'radial_segments',24,512)
    facets=spec.get('facets')
    if facets is not None: n=_integer(facets,'facets',3,64)
    samples=_integer(spec.get('profile_samples',4),'profile_samples',1,32)
    profile=_profile(spec);sample_profile=_profile_sampler(profile)
    handles=_handle_settings(spec)
    handle_count=_integer(handles.get('count',0),'handles.count',0,8)
    body_ratio=_finite_number(spec.get('body_width_ratio',.68 if handle_count else 1),'body_width_ratio',.15,1)
    surface=_shape_function(spec,sample_profile,width*body_ratio,height,depth)
    raw=[_raw_shell(spec,surface,profile,height,thickness,floor,n,samples)]
    raw[0]['_flat_normals']=bool(spec.get('flat_normals',facets is not None))
    angles=handles.get('angles', [360*i/handle_count for i in range(handle_count)] if handle_count else [])
    if len(angles)!=handle_count: raise ValueError('handles.angles length must equal handles.count')
    for i,angle in enumerate(angles): raw.append(_raw_handle(spec,handles,surface,float(angle),i,width,height))
    points=[p for part in raw for p in part['_vertices']]
    lower=[min(p[i] for p in points) for i in range(3)];upper=[max(p[i] for p in points) for i in range(3)]
    observed=[b-a for a,b in zip(lower,upper)]
    fit=spec.get('fit_dimensions',True)
    scale=[target/actual if fit else 1. for target,actual in zip((width,height,depth),observed)]
    center=[(lower[0]+upper[0])*.5,lower[1],(lower[2]+upper[2])*.5]
    wall_distances=[]
    for part in raw:
        part['_vertices']=[tuple((p[i]-center[i])*scale[i] for i in range(3)) for p in part['_vertices']]
        wall_distances.extend(_length(_sub(part['_vertices'][a],part['_vertices'][b])) for a,b in part['_wall_pairs'])
    meshes=[];reports=[]
    for part in raw:
        mesh,report=_finalize(part);meshes.append(mesh);reports.append(report)
    points=[p for part in raw for p in part['_vertices']]
    lower=[min(p[i] for p in points) for i in range(3)];upper=[max(p[i] for p in points) for i in range(3)]
    return meshes, {'valid':True,'units':'metres','up_axis':'Y','origin':'bottom bounding-box centre',
                    'dimensions_metres':[b-a for a,b in zip(lower,upper)],
                    'bounds_metres':{'min':lower,'max':upper},'requested_wall_thickness_m':thickness,
                    'wall_thickness_range_m':[min(wall_distances),max(wall_distances)],
                    'base_thickness_m':floor*scale[1], 'affine_fit_scale':scale,
                    'vertices':sum(r['vertices'] for r in reports),'triangles':sum(r['triangles'] for r in reports),
                    'closed_after_uv_seam_weld':True,'consistent_winding':True,
                    'signed_volume_m3':sum(r['signed_volume_m3'] for r in reports),
                    'separate_handles':handle_count,'meshes':reports,
                    'notes':['All shells are closed orientable solids with an open mouth and positive material volume.',
                             'Handle attachment overlaps are retained as separate capped parts.',
                             'Wall thickness is measured between corresponding offset surfaces; global self-intersection is not tested.']}


def _dimension_values(spec):
    defaults=[float(v)/100 for v in spec['dimensions_cm']] if 'dimensions_cm' in spec else [None]*3
    return tuple(_finite_number(spec.get(k,v),k,.002,20) for k,v in zip(('width','height','depth'),defaults))


def _raw_from_mesh(mesh):
    return {'name':mesh['name'],'material':mesh['material'],
            '_vertices':[tuple(mesh['positions'][i:i+3]) for i in range(0,len(mesh['positions']),3)],
            '_faces':[tuple(mesh['indices'][i:i+3]) for i in range(0,len(mesh['indices']),3)],
            '_uvs':[tuple(mesh['uvs'][i:i+2]) for i in range(0,len(mesh['uvs']),2)],'_wall_pairs':[]}


def _assembly_result(spec, parts, description, extra=None):
    """Fit separate closed parts as a single bottom-centred catalogue asset."""
    dimensions=_dimension_values(spec)
    points=[p for part in parts for p in part['_vertices']]
    lower=[min(p[i] for p in points) for i in range(3)];upper=[max(p[i] for p in points) for i in range(3)]
    observed=[b-a for a,b in zip(lower,upper)]
    scale=[target/actual for target,actual in zip(dimensions,observed)]
    center=[(lower[0]+upper[0])*.5,lower[1],(lower[2]+upper[2])*.5]
    meshes=[];reports=[]
    for part in parts:
        part['_vertices']=[tuple((p[i]-center[i])*scale[i] for i in range(3)) for p in part['_vertices']]
        mesh,report=_finalize(part);meshes.append(mesh);reports.append(report)
    return meshes,{'valid':True,'units':'metres','up_axis':'Y','origin':'bottom bounding-box centre',
                   'dimensions_metres':list(dimensions),
                   'bounds_metres':{'min':[-dimensions[0]/2,0,-dimensions[2]/2],
                                    'max':[dimensions[0]/2,dimensions[1],dimensions[2]/2]},
                   'affine_fit_scale':scale,'vertices':sum(x['vertices'] for x in reports),
                   'triangles':sum(x['triangles'] for x in reports),'closed_after_uv_seam_weld':True,
                   'consistent_winding':True,'signed_volume_m3':sum(x['signed_volume_m3'] for x in reports),
                   'custom_shape':description,'meshes':reports,**(extra or {}),
                   'notes':['Separate closed components intentionally overlap at structural attachment points.',
                            'Geometry is a photograph-based approximation; global self-intersection/Boolean union is not tested.']}


def _solid_pedestal(spec, width, depth, height, top_width=None, top_depth=None):
    """Closed lathed foot/stem, without the artificial open cavity of a vessel."""
    profile=[(.82,0),(.96,.025),(1,.12),(.98,.2),(.79,.29),(.56,.4),(.45,.65),(.48,.85),(.62,1)]
    sample=_profile_sampler([(r,y) for r,y in profile])
    n=64;rows=40;vertices=[];uvs=[];faces=[]
    for i in range(rows+1):
        y=i/rows;r=sample(y)
        influence=_smooth((y-.58)/.42)
        width_factor=1+(top_width/(width*.62)-1)*influence if top_width is not None else 1.
        depth_factor=1+(top_depth/(depth*.62)-1)*influence if top_depth is not None else 1.
        for j in range(n+1):
            angle=TAU*(j%n)/n
            vertices.append((r*width*.5*math.cos(angle)*width_factor,y*height,
                             r*depth*.5*math.sin(angle)*depth_factor))
            uvs.append((j/n,1-y))
    cols=n+1
    for i in range(rows):
        for j in range(n):
            a=i*cols+j;b=a+cols
            faces.extend(((a,b,b+1),(a,b+1,a+1)))
    c0=len(vertices);c1=c0+1
    vertices.extend(((0.,0.,0.),(0.,height,0.)));uvs.extend(((.5,1),(.5,0)))
    for j in range(n):
        faces.append((c0,j,j+1));a=rows*cols+j
        faces.append((c1,a+1,a))
    return {'name':str(spec.get('id','vase'))+'-solid-pedestal','material':spec.get('material','ceramic'),
            '_vertices':vertices,'_faces':faces,'_uvs':uvs,'_wall_pairs':[]}


def _bowl_part(spec, width, height, depth, y_base, index=0, mouth_waves=3):
    wall=float(spec.get('wall_thickness',min(.0035,min(width,depth)*.035)))
    child={'id':str(spec.get('id','vase'))+f'-bowl-{index+1}',
           'width':width,'height':height,'depth':depth,'material':spec.get('material','ceramic'),
           'wall_thickness':wall,'base_thickness':float(spec.get('base_thickness',wall*1.8)),
           'radial_segments':int(spec.get('radial_segments',64)),
           'vertical_segments':int(spec.get('vertical_segments',32)),'profile_samples':2,
           'profile':[[.23,0],[.34,.025],[.46,.08],[.65,.23],[.82,.46],[.94,.74],[1,1]],
           'mouth':{'waves':mouth_waves,'height_amplitude':height*.025,'start':.8,'phase':.35+index*.4},
           'organic':{'amplitude':float(spec.get('organic_amplitude',.008))}}
    meshes,_=build_vase(child)
    raw=_raw_from_mesh(meshes[0])
    x_shift=float(spec.get('layer_stagger_x',width*.025))*index
    raw['_vertices']=[(x+x_shift,y+y_base,z) for x,y,z in raw['_vertices']]
    return raw


def assemble_layered_bowls(spec, layers=3):
    """Return (meshes, validation) for nested open oval bowls on a circular foot.

    Reference family: Mary 7809. Dimensions describe the full assembly. Each
    stepped bowl is an individually closed hollow shell with a real opening;
    the pedestal is solid. Optional layer_stagger_x is an offset per layer in m.
    """
    layers=_integer(layers,'layers',1,6)
    width,height,depth=_dimension_values(spec)
    pedestal_height=height*.23
    pedestal_diameter=min(width*.39,depth*.78)
    parts=[_solid_pedestal(spec,pedestal_diameter,pedestal_diameter,pedestal_height,
                           width*.23*.94,depth*.23*.94)]
    for index in range(layers):
        fraction=index/max(layers-1,1)
        bw=width*(1-.45*fraction);bd=depth*(1-.43*fraction)
        bh=height*(.49+.11*fraction)
        top=height*(.72+.28*fraction)
        parts.append(_bowl_part(spec,bw,bh,bd,top-bh,index))
    return _assembly_result(spec,parts,'nested open oval bowls with a circular pedestal',
                            {'layers':layers,'all_bowls_have_open_cavities':True})


def _box_part(name,material,center,size):
    x,y,z=center;w,h,d=size
    vertices=[(x+sx*w*.5,y+sy*h*.5,z+sz*d*.5)
              for sx,sy,sz in [(-1,-1,-1),(1,-1,-1),(1,1,-1),(-1,1,-1),
                               (-1,-1,1),(1,-1,1),(1,1,1),(-1,1,1)]]
    # Outward winding on all six closed faces.
    quads=[(0,3,2,1),(4,5,6,7),(0,4,7,3),(1,2,6,5),(0,1,5,4),(3,7,6,2)]
    faces=[]
    for a,b,c,d0 in quads:faces.extend(((a,b,c),(a,c,d0)))
    return {'name':name,'material':material,'_vertices':vertices,'_faces':faces,
            '_uvs':[(0,0),(1,0),(1,1),(0,1),(0,0),(1,0),(1,1),(0,1)],
            '_wall_pairs':[],'_flat_normals':True}


def _oval_lattice(spec,width,depth,y):
    """Separate removable grid of capped bars, leaving genuine 3D apertures."""
    material=spec.get('material','ceramic');name=str(spec.get('id','vase'))+'-removable-open-grid'
    settings=spec.get('lattice',{})
    if not isinstance(settings,dict):settings={}
    bar=_finite_number(settings.get('bar_width',min(width,depth)*.037),'lattice.bar_width',.0005,min(width,depth)*.15)
    height=_finite_number(settings.get('bar_height',bar*.85),'lattice.bar_height',.0005,bar*3)
    spacing=_finite_number(settings.get('spacing',min(width,depth)*.18),'lattice.spacing',bar*1.7,min(width,depth)*.6)
    a=width*.5;b=depth*.5
    bars=[];counter=0
    count_z=max(1,int((depth-bar)/spacing))
    count_x=max(1,int((width-bar)/spacing))
    for index in range(count_z+1):
        z=(index-count_z/2)*spacing
        if abs(z)+bar*.5>=b:continue
        half=a*math.sqrt(1-((abs(z)+bar*.5)/b)**2)-bar*.15
        if half>bar:
            bars.append(_box_part(name,material,(0.,y,z),(2*half,height,bar)));counter+=1
    for index in range(count_x+1):
        x=(index-count_x/2)*spacing
        if abs(x)+bar*.5>=a:continue
        half=b*math.sqrt(1-((abs(x)+bar*.5)/a)**2)-bar*.15
        if half>bar:
            bars.append(_box_part(name,material,(x,y+height*.025,0.),(bar,height,2*half)));counter+=1
    if not bars:raise ValueError('Lattice spacing leaves no bars inside the opening')
    # One removable mesh contains the separate solid bars; top faces have a tiny
    # height offset between directions to avoid coincident highlights at crossings.
    combined={'name':name,'material':material,'_vertices':[],'_faces':[],'_uvs':[],
              '_wall_pairs':[],'_flat_normals':True}
    for part in bars:
        offset=len(combined['_vertices'])
        combined['_vertices'].extend(part['_vertices']);combined['_uvs'].extend(part['_uvs'])
        combined['_faces'].extend(tuple(index+offset for index in face) for face in part['_faces'])
    return combined,counter


def assemble_lattice_bowl(spec, with_lattice=True):
    """Return an open shallow oval pedestal bowl and optional removable grid.

    Reference families: Mary 7811/7812. The lattice consists of solid closed bar
    geometry with real holes. Its mesh is separate from the bowl and pedestal.
    Optional lattice settings: bar_width/bar_height/spacing (all metres).
    """
    width,height,depth=_dimension_values(spec)
    foot_height=height*.39
    foot_diameter=min(width*.34,depth*.88)
    bowl_height=height*.64
    bowl_base=height-bowl_height
    parts=[_solid_pedestal(spec,foot_diameter,foot_diameter,foot_height,
                           min(foot_diameter*.62,width*.23),min(foot_diameter*.62,depth*.23)),
           _bowl_part(spec,width,bowl_height,depth,bowl_base,0,mouth_waves=3)]
    bar_count=0
    if with_lattice:
        grid,bar_count=_oval_lattice(spec,width*.87,depth*.84,bowl_base+bowl_height*.74)
        parts.append(grid)
    return _assembly_result(spec,parts,'open oval pedestal bowl with removable open lattice',
                            {'removable_lattice':bool(with_lattice),'solid_grid_bars':bar_count,
                             'all_bowls_have_open_cavities':True})
