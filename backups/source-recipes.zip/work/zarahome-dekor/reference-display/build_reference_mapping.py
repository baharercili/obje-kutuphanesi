import json
import re
import urllib.parse
from collections import Counter
from pathlib import Path

BASE = Path(__file__).resolve().parent
WORK = BASE.parent
manifest = json.loads((WORK / 'bowls-trays/library-manifest.json').read_text())
category_photos = json.loads((BASE / 'category-dom-photos.json').read_text())
vase_photos = json.loads((BASE / 'vase-galleries-raw.json').read_text())
bowls = json.loads((WORK / 'bowls-trays/research-bowls.json').read_text())['products']
bowls_by_sku = {p['family_sku']: p for p in bowls}
family_size_counts = Counter(p['sku'] for p in manifest)

def code(url):
    match = re.search(r'/(4\d{10})(?:\d{2})?-(?:a\d+|p\d+|f)(?:/|\.)', url)
    return match.group(1) if match else None

def shot(url):
    match = re.search(r'-(a\d+|p\d+|f)\.jpg', urllib.parse.urlsplit(url).path)
    return match.group(1) if match else 'other'

def display_url(url, width):
    parts = urllib.parse.urlsplit(url)
    query = urllib.parse.parse_qs(parts.query)
    query['w'] = [str(width)]
    query['f'] = ['jpg']
    return urllib.parse.urlunsplit(parts._replace(query=urllib.parse.urlencode(query, doseq=True)))

def order(photo):
    kind = shot(photo['source_url'])
    return {'p1': 0, 'f': 1, 'a7': 2, 'a1': 3, 'a2': 4, 'a3': 5, 'a4': 6}.get(kind, 8)

models = []
for item in manifest:
    sku = item['sku']
    expected = '4' + sku.replace('/', '')
    accepted = {expected}
    exception = sku == '3325/046/779'
    if exception:
        accepted.add('48254046779')
    candidates = []
    if sku in bowls_by_sku:
        for photo in bowls_by_sku[sku]['gallery']:
            if code(photo['url']) in accepted:
                candidates.append({'source_url': photo['url'], 'alt': photo['alt'], 'source_file': 'bowls-trays/research-bowls.json'})
    else:
        for photo in vase_photos:
            if photo['sku'] == sku and code(photo['source_url']) in accepted:
                candidates.append({'source_url': photo['source_url'], 'alt': '', 'source_file': 'reference-display/vase-galleries-raw.json'})
        for photo in category_photos:
            if code(photo['url']) in accepted:
                candidates.append({'source_url': photo['url'], 'alt': photo.get('alt', ''), 'source_file': 'reference-display/category-dom-photos.json'})
    unique = {}
    for photo in candidates:
        key = urllib.parse.urlsplit(photo['source_url']).path
        if key not in unique or (photo['alt'] and not unique[key]['alt']):
            unique[key] = photo
    images = []
    for photo in sorted(unique.values(), key=order)[:6]:
        source_url = photo['source_url']
        kind = shot(source_url)
        role = {'p1': 'Ürün fotoğrafı', 'f': 'Ürün ailesi fotoğrafı', 'a7': 'Referans fotoğrafı'}.get(kind, 'Ürün detayı')
        alt = photo['alt'] or f"{item['name']} · {sku} · {role}"
        images.append({
            'url': display_url(source_url, 1440),
            'thumbnail_url': display_url(source_url, 160),
            'source_url': source_url,
            'alt': alt,
            'alt_source': 'official_photo_alt' if photo['alt'] else 'product_name_and_photo_role',
            'photo_type': 'official_product_gallery' if kind != 'f' else 'official_category_photo',
            'shot': kind,
            'photo_code': code(source_url),
            'code_match': code(source_url) == expected,
            'source_file': photo['source_file'],
        })
    entry = {
        'id': item['id'], 'sku': sku, 'category': item['category'],
        'product_url': item['url'], 'reference_images': images,
        'photo_scope': 'product_family', 'colour_matched': bool(images),
        'size_variant_count': family_size_counts[sku],
        'size_note': 'Aynı ürün ve renge ait resmi aile fotoğraflarıdır; seçili boyu tek başına göstermeyebilir.' if family_size_counts[sku] > 1 else 'Aynı ürün ve renge ait resmi ürün fotoğraflarıdır.',
    }
    if exception:
        entry['source_note'] = '3325/046/779 KEMİK RENGİ resmi ürün sayfası galerisinde 48254046779 görsel kodunu kullanıyor. Bu istisna sayfa ürün kodu ve renk metniyle doğrulandı; web-photo-pages.json içinde kayıtlı.'
        entry['code_match_method'] = 'official_product_page_sku_colour_and_gallery_code_exception'
    else:
        entry['code_match_method'] = 'exact_sku_colour_image_code'
    models.append(entry)

missing = [p['id'] for p in models if not p['reference_images']]
all_images = [g for p in models for g in p['reference_images']]
assert len(models) == 94
assert len({p['id'] for p in models}) == 94
assert not missing, missing
assert all(urllib.parse.urlsplit(g['url']).hostname == 'static.zarahome.net' for g in all_images)
assert all(urllib.parse.urlsplit(g['url']).path.endswith('.jpg') for g in all_images)
assert all(urllib.parse.parse_qs(urllib.parse.urlsplit(g['url']).query)['f'] == ['jpg'] for g in all_images)
assert all(1 <= len(p['reference_images']) <= 6 for p in models)
assert all(len({urllib.parse.urlsplit(g['url']).path for g in p['reference_images']}) == len(p['reference_images']) for p in models)
summary = {
    'model_count': len(models), 'mapped_model_count': len(models)-len(missing),
    'vase_model_count': sum(p['category'] != 'Dekoratif kaseler' for p in models),
    'bowl_model_count': sum(p['category'] == 'Dekoratif kaseler' for p in models),
    'unique_sku_colour_families': len({p['sku'] for p in models}),
    'image_count_including_shared_size_variants': len(all_images),
    'unique_image_paths': len({urllib.parse.urlsplit(g['url']).path for g in all_images}),
    'models_by_gallery_size': dict(sorted(Counter(len(p['reference_images']) for p in models).items())),
    'by_category': dict(Counter(p['category'] for p in models)),
    'missing_model_ids': missing,
    'sku_code_exception_models': [p['id'] for p in models if p['sku'] == '3325/046/779'],
    'primary_photo_types': dict(Counter(p['reference_images'][0]['shot'] for p in models)),
    'network_validation': 'Official page/gallery links were read; display JPEG parameters preserve source path and request f=jpg,width1440. Image rendering is to be verified by Site UI QA.',
    'excluded_unpublished_models': 'No researched trays or dining plates included.',
}
payload = {'retrieved_at': '2026-10-20', 'models': models, 'summary': summary}
(BASE / 'reference-images.json').write_text(json.dumps(payload, ensure_ascii=False, indent=2))
(BASE / 'validation-report.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2))
# Keep the initial small file aligned with the final gallery ordering.
(BASE / 'bowl-mapping.json').write_text(json.dumps({'models': [p for p in models if p['category'] == 'Dekoratif kaseler'], 'summary': {'mapped_models': 5, 'unique_families': 4}}, ensure_ascii=False, indent=2))
print(json.dumps(summary, ensure_ascii=False, indent=2))
