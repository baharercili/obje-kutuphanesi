"""Build the complete observed vase category with traceable scale provenance."""
import argparse, copy, hashlib, json, shutil, time
from pathlib import Path
import numpy as np
from PIL import Image
from vase_geometry import build_vase, assemble_layered_bowls, assemble_lattice_bowl
from catalog_materials import build_materials
from export_catalog import export_assets

ROOT=Path('/Users/USER/Documents/ChatGPT/Studio')
WORK=ROOT/'work/zarahome-dekor'; OUT=ROOT/'output/zarahome-dekor/tum-vazolar'
ESTIMATED_HWD={
 '47116046':[30,12,12], '42345046':[25,13,13], '44335046':[10,8,8],
 '41300748':[48,38,38], '48310046':[22,23,23], '44355046':[30,12,14],
 '47123046':[30,7,7], '47355046':[31,20,20],
}
BASELINES={
 '40376046712':('0376-rolyef',[22,22,22]),
 '47302046700':('7302-hulu',[20,7,7]),
 '47111046700':('7111-yuvarlak',[19,19,19]),
}

def read_json(name): return json.loads((WORK/name).read_text())
def observed():
    result={}
    for line in (WORK/'live-vase-facts.tsv').read_text().splitlines():
        row,sku,dims,brief,image=line.split('|')
        result[int(row)+1]=dict(image_sku=sku,dimensions_hwd=[list(map(float,s.split(','))) for s in dims.split(';') if s],
                                visual_brief=brief,image_prefix=image or sku)
    return result

def decoration(materials, spec, out, code):
    """Apply source-derived decoration, preserving the cached substrate maps.

    Return the separate handle material name when a glazed handle is specified.
    Heights are measured from the base, matching the geometry's texture V axis.
    """
    out=Path(out); m=materials['ceramic']; settings=spec.get('decoration',{})
    if (code in ('41245046','42345046','47103046') and spec.get('material_type')=='glass'
            and spec.get('color_name')!='Şeffaf'):
        # glTF base colour factors are linear; retain the photographed glass tint.
        srgb=np.asarray(spec['color_rgb'],dtype=float)/255
        linear=np.where(srgb<=.04045,srgb/12.92,((srgb+.055)/1.055)**2.4)
        m['baseColorFactor']=[*linear.tolist(),1]
    signature=hashlib.sha256(json.dumps([code,spec],sort_keys=True,separators=(',',':')).encode()).hexdigest()[:12]
    if m.get('extras',{}).get('decoration_signature')==signature:
        return 'glazed_handle' if 'glazed_handle' in materials else None
    if code=='47116046':
        # Glass has no albedo map, but still needs the etched diamond relief.
        n=spec.get('texture_size',512); yy,xx=np.mgrid[0:n,0:n]/n
        p=xx*12+yy*8; q=xx*12-yy*8
        d=np.minimum(abs(p-np.round(p)),abs(q-np.round(q)))
        height=np.exp(-(d/.035)**2)*.12
        gy,gx=np.gradient(height)
        normal=np.stack([-gx*10,-gy*10,np.ones_like(gx)],axis=-1)
        normal/=np.linalg.norm(normal,axis=-1)[:,:,None]
        normalpath=out/'diamond-normal.png'
        Image.fromarray(np.uint8((normal+1)*127.5)).save(normalpath)
        m['normalTexture']=normalpath.name;m['normalScale']=.6
    rel=m.get('baseColorTexture')
    if not rel:
        m.setdefault('extras',{})['decoration_signature']=signature
        return
    arrays={key:np.array(Image.open(out/m[key]).convert('RGB'),dtype=float)
            for key in ('baseColorTexture','normalTexture','metallicRoughnessTexture') if m.get(key)}
    a=arrays['baseColorTexture']; rows,columns=a.shape[:2]
    h=1-np.linspace(0,1,rows)[:,None]; u=np.arange(columns)[None,:]/columns
    changed=set()
    pattern_range=settings.get('pattern_height_range',spec.get('pattern_height_range'))
    if pattern_range is not None:
        # Remove the complete pattern (including its relief/roughness) elsewhere.
        plain_spec=copy.deepcopy(spec);plain_spec['texture_style']='plain'
        plain=build_materials(plain_spec,out)['ceramic']
        outside=(h[:,0]<pattern_range[0])|(h[:,0]>pattern_range[1])
        for key,array in arrays.items():
            array[outside]=np.array(Image.open(out/plain[key]).convert('RGB'),dtype=float)[outside]
            changed.add(key)

    def paint(mask, zone, index):
        mask=np.broadcast_to(mask,(rows,columns))
        if not mask.any():return
        rgb=zone.get('color_rgb',zone.get('color'))
        if rgb is not None:
            grain=a[mask].mean(axis=-1,keepdims=True)-a[mask].mean()
            colour=np.asarray(rgb,dtype=float)[None,:]+grain*.65
            if zone.get('texture_style')=='speckled':
                seed=int.from_bytes(hashlib.sha256(f'{code}:{index}'.encode()).digest()[:8],'little')
                rng=np.random.default_rng(seed)
                background=np.asarray(zone.get('speckle_background_rgb',rgb),dtype=float)[None,:]
                colour=np.where(rng.random((mask.sum(),1))>.46,colour,background+grain*.65)
            a[mask]=colour;changed.add('baseColorTexture')
        if zone.get('roughness') is not None and 'metallicRoughnessTexture' in arrays:
            arrays['metallicRoughnessTexture'][:,:,1][mask]=np.clip(zone['roughness'],0,1)*255
            changed.add('metallicRoughnessTexture')

    zones=settings.get('height_color_bands',spec.get('height_bands',spec.get('color_zones',[])))
    for index,zone in enumerate(zones):
        if not isinstance(zone,dict):
            low,high,rgb=zone[:3];zone={'start':low,'end':high,'color_rgb':rgb}
        low=zone.get('min',zone.get('start',zone.get('from',0)))
        high=zone.get('max',zone.get('end',zone.get('to',1)))
        paint((h>=low)&(h<=high),zone,index)
    for index,zone in enumerate(settings.get('wave_bands',[])):
        center=zone['center']+zone.get('amplitude',0)*np.sin(np.pi*2*zone.get('waves',1)*u)
        paint(abs(h-center)<=zone.get('width',.02)/2,zone,f'wave-{index}')
    edges=settings.get('vertical_edge_stripes')
    if edges:
        low,high=edges.get('height_range',[0,1])
        for index,position in enumerate(edges.get('u_positions',[])):
            distance=abs(u-position)%1;distance=np.minimum(distance,1-distance)
            paint((distance<=edges.get('width',.01)/2)&(h>=low)&(h<=high),edges,f'edge-{index}')
    for key in changed:
        filename=f'{Path(m[key]).stem}-decor-{signature}.png'
        Image.fromarray(np.uint8(np.clip(np.rint(arrays[key]),0,255))).save(out/filename)
        m[key]=filename
    m.setdefault('extras',{})['decoration_signature']=signature
    if settings.get('handle_color_rgb') is not None:
        handle_spec=dict(id=str(spec.get('id',code))+':handle',seed=str(spec.get('seed',code))+':handle',
                         material_name='glazed_handle',material_type=spec.get('material_type','ceramic'),
                         color_rgb=settings['handle_color_rgb'],finish='glossy',texture_style='plain',
                         texture_size=spec.get('texture_size',512),roughness=settings.get('handle_roughness',.2),
                         clearcoat=spec.get('clearcoat',.18))
        materials.update(build_materials(handle_spec,out))
        return 'glazed_handle'

def plan():
    research=read_json('current-vases-research.json'); live=observed()
    cross=read_json('cross-market-size-research.json')
    shapes=read_json('catalog_shape_refined.json')
    material_overrides=read_json('catalog_material_overrides.json')
    if isinstance(material_overrides,dict) and 'materials' in material_overrides:material_overrides=material_overrides['materials']
    entries=[];seen=set()
    for r in research:
        code='4'+r['family_id']; ob=live[r['category_row']]
        image_sku=ob['image_sku']; sku=f'{image_sku[1:5]}/{image_sku[5:8]}/{image_sku[8:]}'
        local=ob['dimensions_hwd']
        # A second category listing may expose all sizes of the same colour.
        same_live=[o for o in live.values() if o['image_sku']==image_sku and o['dimensions_hwd']]
        if same_live: local=max((o['dimensions_hwd'] for o in same_live),key=len)
        cross_record=cross.get(code,{})
        if local:
            sizes=local;source_kind='tr_live_product';size_sources=[r['variant_url']];estimated=False
        elif cross_record.get('dimensions_cm_hwd'):
            confirmed_tr=cross_record.get('tr_variant_availability_confirmed') and cross_record.get('source_market') in ('Türkiye','Turkiye','Turkey')
            sizes=cross_record['dimensions_cm_hwd'];source_kind='official_tr' if confirmed_tr else 'official_cross_market';size_sources=cross_record.get('source_urls',[]);estimated=False
        elif r.get('dimensions_cm_hwd'):
            sizes=r['dimensions_cm_hwd'];source_kind='official_tr_research';size_sources=r['source_urls'];estimated=False
        else:
            if code not in ESTIMATED_HWD:raise ValueError('No sourced or explicit estimated scale for '+code)
            sizes=[ESTIMATED_HWD[code]];source_kind='photo_estimate';size_sources=[r['variant_url']];estimated=True
        for dims in sizes:
            key=(image_sku,tuple(dims))
            if key in seen:continue
            seen.add(key)
            h,w,d=map(float,dims)
            identifier=f'{sku.replace("/","-")}-h{h:g}-w{w:g}-d{d:g}'.replace('.','p')
            name=r['name'].capitalize().replace('studio mary lennox','Studio Mary Lennox')
            baseline=BASELINES.get(image_sku)
            is_baseline=baseline and tuple(dims)==tuple(baseline[1])
            category='Studio Mary Lennox' if 'MARY LENNOX' in r['name'] else ('Cam vazolar' if 'CAM' in r['name'] else ('Metal vazolar' if 'ÇELİK' in r['name'] else ('Kulplu ve terrakota vazolar' if any(x in r['name'] for x in ['TERRAKOTA','SÜRAHİ']) else 'Seramik vazolar')))
            mat=copy.deepcopy(material_overrides.get(image_sku,{}))
            if not mat:raise ValueError('Material reference missing '+image_sku)
            e=dict(id=identifier,name=name,sku=sku,url=r['variant_url'],family_code=code,
                   dimensions_cm=[w,h,d],source_dimensions_hwd_cm=[h,w,d],size_source_kind=source_kind,
                   size_source_urls=size_sources,estimated_dimensions=estimated,
                   category=category,material_spec=mat,shape_spec=copy.deepcopy(shapes[code]),
                   visual_reference=ob['visual_brief'],reference_image_prefix=ob['image_prefix'],
                   material_label=mat.get('material_label',mat.get('color_name','')),
                   source_checked='2026-10-20',baseline=baseline[0] if is_baseline else None)
            e['source_market']=cross_record.get('source_market','') if source_kind in ('official_tr','official_cross_market') else 'Türkiye'
            e['scale_note']=('Boyutlar fotoğraftan yaklaşık ölçeklenmiştir; yayımlanmış tam ölçü doğrulanamadı.' if estimated else
                             'Ölçüler resmi başka ülke sayfasından alınmıştır; Türkiye boy seçeneği eşleşmesi ayrıca teyit edilmemiştir.' if source_kind=='official_cross_market' else
                             'Yayımlanan Türkiye ürün ölçüleri kullanılmıştır.')
            if code=='47123046':
                e['raw_source_dimensions_hwd_cm']=[5,5,h]
                e['axis_note']='Türkiye boy panelinde ham Y×G×D sırası 5×5×'+f'{h:g}'+' cm olarak gösterilmiştir. Ürün fotoğrafındaki dikey kullanım doğrultusunda uzun eksen model yüksekliği kabul edilerek Y×G×D '+f'{h:g}'+'×5×5 cm modellenmiştir; eksen yorumu yapılmıştır.'
                e['scale_note']+=' '+e['axis_note']
            elif code=='47355046' and estimated:
                e['size_source_kind']='official_tr_partial_depth_estimate'
                e['official_dimensions_cm']={'height':31,'width':20}
                e['raw_source_dimensions_cm']=[31,20]
                e['estimated_axes']=['depth']
                e['size_note']='Resmi Türkiye ölçüsü 31×20 cm: yükseklik 31 cm ve genişlik 20 cm. Derinlik yayımlanmamıştır; fotoğraftaki yuvarlak kesit esas alınarak yalnız derinlik 20 cm kabul edilmiştir.'
                e['scale_note']=e['size_note']
            if is_baseline:
                e['model_path']=str(WORK/baseline[0]/'model.json')
                e['asset_dir']=str(ROOT/'output/zarahome-dekor/vazolar'/baseline[0])
            else:
                e['model_path']=str(WORK/'catalog-models'/identifier/'model.json')
                e['asset_dir']=str(OUT/category.replace(' ','-')/identifier)
            entries.append(e)
    return entries

def build_entry(e):
    if e['baseline']:return
    asset=Path(e['asset_dir']);asset.mkdir(parents=True,exist_ok=True)
    model_path=Path(e['model_path']);model_path.parent.mkdir(parents=True,exist_ok=True)
    w,h,d=[v/100 for v in e['dimensions_cm']]
    so=e['shape_spec'];geo=copy.deepcopy(so.get('geometry_spec',so.get('geometry',so)))
    geo.update(id=e['id'],width=w,height=h,depth=d,material='ceramic')
    for key in ('relative_settings','source_features','approximation_notes','source_description','needs_reference_review'):
        geo.pop(key,None)
    rel=so.get('relative_settings',{})
    if rel.get('mouth_height_amplitude_fraction_of_height'):
        geo.setdefault('mouth',{})['height_amplitude']=h*rel['mouth_height_amplitude_fraction_of_height']
    geo['wall_thickness']=min(w,d)*(.012 if e['material_spec']['material_type']=='glass' else .022)
    geo['base_thickness']=min(w,d)*.035
    if e['family_code']=='47123046':geo.update(cross_section='rectangle',superellipse_exponent=8)
    if e['family_code']=='47804046':geo.update(facets=8,flat_normals=True,wall_thickness=.0007)
    if e['family_code']=='47809046':meshes,validation=assemble_layered_bowls(geo,layers=3)
    elif e['family_code'] in ('47811046','47812046'):meshes,validation=assemble_lattice_bowl(geo,with_lattice=True)
    else:meshes,validation=build_vase(geo)
    mat_spec=copy.deepcopy(e['material_spec']);mat_spec.update(id=e['sku'],seed=e['sku'],material_name='ceramic',texture_size=512)
    materials=build_materials(mat_spec,asset);handle_material=decoration(materials,mat_spec,asset,e['family_code'])
    if handle_material:
        for mesh in meshes:
            if '-open-handle-' in mesh.get('name',''):mesh['material']=handle_material
    metadata={k:v for k,v in e.items() if k not in ('shape_spec','material_spec','model_path','asset_dir','baseline')}
    metadata.update(units='metres',up_axis='Y',origin='bottom centre',
                    status='Reference-based reconstruction; geometry and surface decoration are approximate.',
                    approximation_notes=so.get('approximation_notes',[]))
    model=dict(metadata=metadata,materials=materials,meshes=meshes)
    model_path.write_text(json.dumps(model,ensure_ascii=False,separators=(',',':')))
    (asset/'urun-bilgisi.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2))
    (model_path.parent/'geometry-validation.json').write_text(json.dumps(validation,indent=2))
    export_assets(model_path,asset,e['id'])

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--plan-only',action='store_true');parser.add_argument('--resume',action='store_true');args=parser.parse_args()
    entries=plan();OUT.mkdir(parents=True,exist_ok=True)
    (WORK/'catalog-build-plan.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2))
    manifest=[];failures=[];start=time.time()
    for index,e in enumerate(entries):
        try:
            if not args.plan_only and not (args.resume and (Path(e['asset_dir'])/(e['id']+'.glb')).exists()):build_entry(e)
            manifest.append({k:e[k] for k in ('id','name','sku','url','dimensions_cm','model_path','asset_dir','material_label','category',
                                            'estimated_dimensions','size_source_kind','size_source_urls','source_market','scale_note',
                                            'source_dimensions_hwd_cm','raw_source_dimensions_hwd_cm','raw_source_dimensions_cm',
                                            'axis_note','size_note','official_dimensions_cm','estimated_axes') if k in e})
            print(f'{index+1}/{len(entries)} {e["id"]} '+('reused' if e['baseline'] else 'ready'),flush=True)
        except Exception as err:
            failures.append({'id':e['id'],'error':str(err)});print('FAILED '+e['id']+' '+str(err),flush=True)
    (WORK/'catalog-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
    (OUT/'katalog.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2))
    (WORK/'catalog-build-report.json').write_text(json.dumps(dict(models=len(manifest),planned=len(entries),failures=failures,seconds=time.time()-start),indent=2))
    print(json.dumps(dict(planned=len(entries),ready=len(manifest),failures=failures,seconds=round(time.time()-start,2)),ensure_ascii=False),flush=True)
    if failures:raise SystemExit(1)

if __name__=='__main__':main()
