"""Build six repaired assets into this isolated directory; never overwrite sources."""
from pathlib import Path
import copy,hashlib,json,math,shutil,sys
HERE=Path(__file__).resolve().parent;WORK=HERE.parent
sys.path.insert(0,str(WORK))
from export_catalog import export_assets,read_glb
from handle_geometry_revision import build_vase

RECIPES={
 '44535043':dict(body_width_ratio=.89,
  profile=[[.50,0],[.53,.025],[.70,.09],[.91,.21],[1,.33],[.97,.43],[.86,.52],[.55,.60],[.35,.64],[.34,.94],[.41,1]],
  flutes=dict(count=16,amplitude=.06,start=.04,end=.61),
  spout=dict(angle=180,width=.43,radial_fraction=.025,height_fraction=-.004,start=.90),
  handles=dict(count=1,angles=[0],y_top=.955,y_bottom=.545,outer_radius_fraction=.565,peak_y=.78,
               tube_radius_fraction_width=.025,lead_fraction_of_span=.39,root_radius_scale=1.12)),
 '44536043':dict(body_width_ratio=1,
  profile=[[.37,0],[.39,.035],[.62,.10],[.88,.25],[1,.43],[.96,.52],[.83,.64],[.65,.72],[.42,.79],[.36,.84],[.36,.96],[.40,1]],
  organic=dict(amplitude=.009),spout=dict(angle=180,width=.50,radial_fraction=.018,height_fraction=-.006,start=.88),
  handles=dict(count=1,angles=[0],y_top=.954,y_bottom=.675,outer_radius_fraction=.500,peak_y=.860,
               tube_radius_fraction_width=.040,lead_fraction_of_span=.36,root_radius_scale=1.15)),
 '44355046':dict(body_width_ratio=1,
  profile=[[.62,0],[.65,.035],[.82,.12],[.985,.25],[1,.30],[.96,.46],[.85,.63],[.72,.755],[.61,.80],[.40,.855],[.35,.91],[.36,.97],[.50,1]],
  handles=dict(count=2,angles=[0,180],y_top=.902,y_bottom=.798,outer_radius_fraction=.414,peak_y=.853,
               tube_radius_fraction_height=.012,lead_fraction_of_span=.40,root_radius_scale=1.14)),
 '44357046':dict(body_width_ratio=1,
  profile=[[.60,0],[.65,.04],[.81,.14],[.97,.29],[1,.355],[.96,.49],[.85,.64],[.72,.755],[.61,.80],[.41,.855],[.36,.92],[.38,.97],[.48,1]],
  handles=dict(count=2,angles=[0,180],y_top=.905,y_bottom=.798,outer_radius_fraction=.400,peak_y=.855,
               tube_radius_fraction_height=.0115,lead_fraction_of_span=.38,root_radius_scale=1.12)),
 '44356046':dict(body_width_ratio=1,
  profile=[[.60,0],[.65,.035],[.81,.12],[.98,.26],[1,.315],[.96,.46],[.85,.63],[.72,.755],[.61,.80],[.40,.855],[.35,.92],[.37,.97],[.49,1]],
  handles=dict(count=2,angles=[0,180],y_top=.903,y_bottom=.798,outer_radius_fraction=.410,peak_y=.855,
               tube_radius_fraction_height=.0115,lead_fraction_of_span=.39,root_radius_scale=1.14)),
}
for recipe in RECIPES.values():
 recipe.update(radial_segments=160,vertical_segments=120,profile_samples=5)
 recipe['handles'].update(path_mode='anchored_bezier',path_segments=96,radial_segments=24,root_embed_fraction_of_wall=.48)


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def bounds(meshes):
 points=[m['positions'][i:i+3] for m in meshes for i in range(0,len(m['positions']),3)]
 lo=[min(p[i] for p in points) for i in range(3)];hi=[max(p[i] for p in points) for i in range(3)]
 return dict(min=lo,max=hi,dimensions=[b-a for a,b in zip(lo,hi)])


def main():
 plan=json.loads((WORK/'catalog-build-plan.json').read_text());entries=[e for e in plan if e['category']=='Kulplu ve terrakota vazolar']
 assert len(entries)==6
 manifest=[];records=[];source_hashes={}
 for e in entries:
  source=Path(e['model_path']);old=json.loads(source.read_text());source_hashes[str(source)]=sha(source)
  asset=Path(e['asset_dir']);old_glb=asset/(e['id']+'.glb');source_hashes[str(old_glb)]=sha(old_glb)
  out=HERE/'models'/e['id'];out.mkdir(parents=True,exist_ok=True)
  for mat in old['materials'].values():
   for key,value in mat.items():
    if key.endswith('Texture') and isinstance(value,str):
     src=asset/value;source_hashes[str(src)]=sha(src);dst=out/value;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst)
  w,h,d=[v/100 for v in e['dimensions_cm']]
  geo=copy.deepcopy(RECIPES[e['family_code']]);settings=geo['handles']
  settings['tube_radius']=settings.pop('tube_radius_fraction_width',0)*w+settings.pop('tube_radius_fraction_height',0)*h
  if 'glazed_handle' in old['materials']:settings['material']='glazed_handle'
  geo.update(id=e['id'],width=w,height=h,depth=d,wall_thickness=min(w,d)*.022,base_thickness=min(w,d)*.035,material='ceramic')
  meshes,validation=build_vase(geo)
  metadata=copy.deepcopy(old['metadata']);metadata.update(geometry_revision='reference-handles-v2',
   revision_notes=['Handle loops rebuilt from product-specific reference proportions and body-normal root attachments.',
    'Terracotta belly maximum moved to lower body; small paired loops kept within belly width.',
    'Original PBR materials and maps preserved byte for byte; official overall bounds retained.'])
  new=dict(metadata=metadata,materials=copy.deepcopy(old['materials']),meshes=meshes)
  model_path=out/'model.json';model_path.write_text(json.dumps(new,ensure_ascii=False,separators=(',',':')))
  (out/'geometry-validation.json').write_text(json.dumps(validation,ensure_ascii=False,indent=2))
  (out/'geometry-spec.json').write_text(json.dumps(geo,ensure_ascii=False,indent=2))
  export=export_assets(model_path,out,e['id'])
  actual=bounds(meshes);assert all(abs(a-b)<2e-8 for a,b in zip(actual['dimensions'],(w,h,d)))
  assert new['materials']==old['materials']
  doc,binary=read_glb(out/(e['id']+'.glb'));assert all('bufferView' in image for image in doc.get('images',[]))
  for mat in old['materials'].values():
   for key,value in mat.items():
    if key.endswith('Texture') and isinstance(value,str):assert sha(asset/value)==sha(out/value)
  m={k:e[k] for k in ('id','name','sku','url','dimensions_cm','category','material_label','estimated_dimensions','size_source_kind','size_source_urls','source_market','scale_note') if k in e}
  m.update(model_path=str(model_path),asset_dir=str(out),geometry_revision='reference-handles-v2');manifest.append(m)
  record=dict(id=e['id'],sku=e['sku'],before_bounds=bounds(old['meshes']),after_bounds=actual,
    before_meshes=len(old['meshes']),after_meshes=len(meshes),handle_count=len(meshes)-1,
    before_vertices=sum(len(m['positions'])//3 for m in old['meshes']),after_vertices=validation['vertices'],
    before_triangles=sum(len(m['indices'])//3 for m in old['meshes']),after_triangles=validation['triangles'],
    before_parts=[dict(name=m['name'],bounds=bounds([m])) for m in old['meshes']],
    after_parts=[dict(name=m['name'],bounds=bounds([m])) for m in meshes],
    glb_path=str(out/(e['id']+'.glb')),glb_sha256=sha(out/(e['id']+'.glb')),materials_unchanged=True,textures_unchanged=True,
    geometry_valid=validation['valid'],geometry_spec=geo)
  records.append(record);print(e['id']+' ready',flush=True)
 for path,expected in source_hashes.items():assert sha(path)==expected,'Source changed: '+path
 (HERE/'geometry-overrides.json').write_text(json.dumps({code:dict(geometry_spec=recipe,reference_basis='Original product photographs; approximate normalized reconstruction, official whole-model bounds.') for code,recipe in RECIPES.items()},ensure_ascii=False,indent=2))
 (HERE/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
 (HERE/'revision-report.json').write_text(json.dumps(dict(models=len(records),source_files_unchanged=True,source_sha256=source_hashes,records=records),ensure_ascii=False,indent=2))
 print(json.dumps(dict(models=len(records),manifest=str(HERE/'manifest.json'),originals_unchanged=True)),flush=True)

if __name__=='__main__':main()
