from pathlib import Path
import json,sys,math
import numpy as np
from PIL import Image
from build_wood_objects import R,WORK,dump,sha,finalize,_noise
from dog_geometry import build
from export_catalog import export_assets,read_glb,write_glb

def material(out):
 n=2048;xx=np.linspace(-.10,.10,n,dtype=np.float32)[None,:];yy=np.linspace(0,.12,n,dtype=np.float32)[:,None];x=np.broadcast_to(xx,(n,n));y=np.broadcast_to(yy,(n,n))
 cloud=_noise._object_noise(x/.20,y/.12,1357,5.0);fine=_noise._object_noise(x/.20,y/.12,7135,499.)
 # Contours turn up through the raised neck and settle into long horizontal
 # fibres along the body, as visible in both original product photographs.
 q=y+.046*np.tanh((x+.042)/.014)+cloud*.0007
 phase=q*math.tau*205+np.sin(x*22)*.8
 growth=np.sin(phase);late=np.maximum(0,growth-.32)**1.7
 fibre=np.sin(q*math.tau*1850+cloud*2)
 pore=np.maximum(0,fibre-.68)*np.clip(.65+.35*np.sin(x*370+cloud*2),0,1)
 # The original has conspicuous dark latewood ribbons and open ash pores.
 # Their contrast is intrinsic material detail, never a reflected light band.
 tone=cloud*4.8+growth*3.4-late*12.0-pore*18+fine*.45
 a=np.clip(np.array([59,37,30],np.float32)+tone[:,:,None]*np.array([1,.74,.62]),0,255)
 rough=np.clip(.32+cloud*.014+late*.025+pore*.04,.27,.41)
 height=growth*.24-pore*.65+fibre*.12+fine*.025;dx=np.gradient(height,axis=1);dy=np.gradient(height,axis=0);nn=np.stack([-dx,-dy,np.ones_like(dx)],2);nn/=np.linalg.norm(nn,axis=2,keepdims=True)
 orm=np.zeros((n,n,3),np.uint8);orm[:,:,0]=255;orm[:,:,1]=np.rint(rough*255).astype(np.uint8)
 maps={'thermo-ash-albedo-2k.png':np.rint(a).astype(np.uint8),'thermo-ash-normal-2k.png':np.rint((nn+1)*127.5).astype(np.uint8),'thermo-ash-orm-2k.png':orm}
 for name,p in maps.items():Image.fromarray(p,'RGB').save(out/name,optimize=True)
 mat={'ash':dict(baseColorFactor=[1,1,1,1],metallic=0,roughness=1,baseColorTexture='thermo-ash-albedo-2k.png',normalTexture='thermo-ash-normal-2k.png',metallicRoughnessTexture='thermo-ash-orm-2k.png',normalScale=.48,clearcoat=.28,clearcoatRoughness=.24,doubleSided=False,alphaMode='OPAQUE',extras=dict(native_resolution=2048,photo_pixels_baked=False,baked_reflections=False,wood_species='thermally treated ash',uv_broadface_metres=[.20,.12]))}
 dump(out/'material-validation.json',dict(valid=True,native_resolution=2048,photo_pixels_baked=False,baked_reflections=False,physical_broad_face_uv_metres=[.20,.12],contour_grain_photo_informed=True,maps={name:dict(bytes=(out/name).stat().st_size,sha256=sha(out/name),resolution=[n,n],mode='RGB')for name in maps}))
 return mat

def main():
 p=next(p for p in json.loads((R.parent/'research-glass.json').read_text())['products']if p['sku']=='1357/043/700');id='1357-043-700-h12-w20-d4p5';out=R/'models'/id;out.mkdir(parents=True,exist_ok=True)
 meshes,gqa=build(finalize);mats=material(out)
 metadata=dict(id=id,name='Dişbudak dachshund obje · Vincent Van Duysen',sku=p['sku'],url=p['official_url'],category='Dekoratif objeler ve kitap destekleri',dimensions_cm=[20,12,4.5],source_dimensions_hwd_cm=[12,20,4.5],estimated_dimensions=False,source_market='Türkiye',size_source_kind='tr_live_product',size_source_urls=[p['official_url']],scale_note='Resmi Türkiye ölçüleri kullanılmıştır. Organik yüzey, kenar yuvarlaması ve sığ kulak kabartması iki ürün fotoğrafından yorumlanmıştır.',units='metres',up_axis='Y',origin='bottom bounding-box centre',source_images=p['images'],photo_pixels_baked=False,baked_reflections=False,availability_note='Resmi Türkiye sayfasında Back Soon; stokta olduğu iddia edilmez.')
 model=out/'model.json';dump(model,dict(metadata=metadata,materials=mats,meshes=meshes));dump(out/'geometry-validation.json',gqa);rep=export_assets(model,out,id);glb=out/(id+'.glb');doc,binary=read_glb(glb);doc['samplers']=[dict(magFilter=9729,minFilter=9987,wrapS=10497,wrapT=10497)]
 for tex in doc.get('textures',[]):tex['sampler']=0
 write_glb(glb,doc,binary);rep['deliverable_sha256']['glb']=sha(glb);rep['glb_bytes']=glb.stat().st_size;dump(rep['files']['validation'],rep)
 e={k:metadata[k]for k in ['id','name','sku','url','category','dimensions_cm','source_dimensions_hwd_cm','estimated_dimensions','source_market','size_source_kind','size_source_urls','scale_note']};e.update(model_path=str(model),asset_dir=str(out),glb_path=str(glb),sha256=sha(glb),bytes=glb.stat().st_size,material_label='Isıl dişbudak · Kahverengi',source_images=p['images'],geometry_validation=str(out/'geometry-validation.json'),material_validation=str(out/'material-validation.json'),model_revision='object-1357-photo-v2-oval-grain',source_anomalies=[],availability_note=metadata['availability_note'])
 manifest=json.loads((R/'manifest.json').read_text());manifest=[old for old in manifest if old['sku']!=p['sku']];manifest.append(e)
 for old in manifest:old['size_source_kind']='tr_live_product'
 dump(R/'manifest.json',manifest);print(id,e['bytes'],gqa['triangles'])
if __name__=='__main__':main()
