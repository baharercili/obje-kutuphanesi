"""Photo specific wood objects. Dimensions are metres; no product pixels baked."""
from pathlib import Path
import sys, json, math, hashlib, importlib.util
import numpy as np
from PIL import Image

R=Path(__file__).resolve().parent
WORK=R.parents[1]
sys.path.insert(0,str(WORK))
from export_catalog import export_assets, read_glb, write_glb
from vase_geometry import _finalize, _signed_volume
_s=importlib.util.spec_from_file_location('native_noise',WORK/'bowls-trays/tray-build/tray_materials.py')
_noise=importlib.util.module_from_spec(_s);_s.loader.exec_module(_noise)

def dump(p,x): Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def finalize(name,mat,verts,uvs,faces):
 if _signed_volume(verts,faces)<0: faces=[(a,c,b)for a,b,c in faces]
 return _finalize(dict(name=name,material=mat,_vertices=verts,_uvs=uvs,_faces=faces))

def rounded_yz(d,h,r,cy):
 pts=[]
 for cz,y,a in [(d/2-r,cy+h/2-r,0),(-d/2+r,cy+h/2-r,90),(-d/2+r,cy-h/2+r,180),(d/2-r,cy-h/2+r,270)]:
  for j in range(17):
   t=math.radians(a+90*j/16);pts.append((y+r*math.sin(t),cz+r*math.cos(t)))
 return pts

def wood_slab():
 # The slim dark core has rounded rectangular broad sides and a softly
 # rounded exposed vertical edge, as visible in p1/a2/a3.
 thick=.0268;h=.2297;d=.1433;cy=.11665;bev=.0010;r=.0056
 rings=[]
 for x,inset in [(-thick/2,bev),(-thick/2+.0002,.0004),(-thick/2+bev,0),(thick/2-bev,0),(thick/2-.0002,.0004),(thick/2,bev)]:
  rings.append([(x,y,z) for y,z in rounded_yz(d-2*inset,h-2*inset,r-inset,cy)])
 n=len(rings[0]);verts=[p for ring in rings for p in ring];faces=[]
 for i in range(len(rings)-1):
  for j in range(n):
   a=i*n+j;b=i*n+(j+1)%n;c=(i+1)*n+j;dd=(i+1)*n+(j+1)%n;faces.extend([(a,c,dd),(a,dd,b)])
 for ring,reverse in [(0,False),(len(rings)-1,True)]:
  mid=len(verts);verts.append((rings[ring][0][0],cy,0))
  for j in range(n):
   a=ring*n+j;b=ring*n+(j+1)%n;faces.append((mid,b,a) if reverse else (mid,a,b))
 # Use independent UV corners with the same welded positions. The long grain
 # always follows the physical 23 cm vertical board, not each mesh's bounds.
 expanded=[];uv=[];newfaces=[]
 vv=np.asarray(verts)
 for f in faces:
  a,b,c=vv[list(f)];normal=np.cross(b-a,c-a);axis=int(np.argmax(np.abs(normal)))
  offset=len(expanded)
  for k in f:
   x,y,z=verts[k];expanded.append(verts[k])
   uv.append((.5+(z if axis==0 else x)/.10,y/.24) if axis!=1 else (.5+x/.10,.5+z/.24))
  newfaces.append((offset,offset+1,offset+2))
 mesh,report=finalize('4328-rounded-solid-wood-core','wood',expanded,uv,newfaces)
 return mesh,report

def bent_plate(sign):
 # A real constant-thickness metal sheet, not an L-shaped box. Each sheet
 # opens outwards through a circular bottom bend; both feet share Y=0.
 thickness=.00085;inside=.0134;radius=.0086;foot=.04625
 foot_y=thickness/2;cx=inside+thickness/2+radius;cy=foot_y+radius
 straight=foot-cx;arc=math.pi*radius/2;vertical=.2325-cy
 length=straight+arc+vertical;depth=.145;corner=.0048
 q=np.unique(np.concatenate([np.linspace(0,straight,13),np.linspace(straight,straight+arc,33),np.linspace(straight+arc,length,72)]))
 def spine(s):
  if s<=straight:return foot-s,foot_y,-1.,0.
  if s<straight+arc:
   a=-math.pi/2-(s-straight)/radius
   return cx+radius*math.cos(a),cy+radius*math.sin(a),math.sin(a),-math.cos(a)
  return inside+thickness/2,cy+s-straight-arc,0.,1.
 verts=[];uv=[];nz=17
 for side in [-1,1]:
  for s in q:
   x,y,tx,ty=spine(float(s));nx=-ty;ny=tx
   enddist=min(float(s),length-float(s));half=depth/2
   if enddist<corner:half-=corner-math.sqrt(max(0,corner*corner-(corner-enddist)**2))
   for j in range(nz):
    z=half*(2*j/(nz-1)-1)
    verts.append((sign*(x+side*thickness/2*nx),y+side*thickness/2*ny,z));uv.append((j/(nz-1),float(s)/length))
 rows=len(q);sidecount=rows*nz;faces=[]
 for side in range(2):
  for i in range(rows-1):
   for j in range(nz-1):
    a=side*sidecount+i*nz+j;b=a+nz
    faces.extend([(a,b,b+1),(a,b+1,a+1)] if side==0 else [(a,b+1,b),(a,a+1,b+1)])
 perimeter=[i*nz for i in range(rows)]+[(rows-1)*nz+j for j in range(1,nz)]+[i*nz+nz-1 for i in range(rows-2,-1,-1)]+[j for j in range(nz-2,0,-1)]
 for a,b in zip(perimeter,perimeter[1:]+perimeter[:1]):faces.extend([(b,a,a+sidecount),(b,a+sidecount,b+sidecount)])
 return finalize('4328-'+('right' if sign>0 else 'left')+'-bent-metal-sheet','metal',verts,uv,faces)

def bookend():
 allparts=[wood_slab(),bent_plate(-1),bent_plate(1)]
 meshes=[a for a,b in allparts];points=np.concatenate([np.asarray(m['positions']).reshape(-1,3)for m in meshes]);lo=points.min(0);hi=points.max(0)
 scale=np.array([.0925,.2325,.145])/(hi-lo);centre=np.array([(lo[0]+hi[0])/2,lo[1],(lo[2]+hi[2])/2])
 for m in meshes:
  p=(np.asarray(m['positions']).reshape(-1,3)-centre)*scale;m['positions']=p.reshape(-1).tolist()
  n=np.asarray(m['normals']).reshape(-1,3)/scale;n/=np.linalg.norm(n,axis=1,keepdims=True);m['normals']=n.reshape(-1).tolist()
 return meshes,dict(valid=True,units='metres',up_axis='Y',origin='bottom bounding-box centre',dimensions_metres=[.0925,.2325,.145],overall_dimensions_official=True,local_details_photo_inferred=True,meshes=[b for a,b in allparts],triangles=sum(len(m['indices'])//3 for m in meshes),wood_core_thickness_m=.0268,metal_sheet_thickness_m=.00085,bottom_bend_radius_m=.0086,photo_features=['Two mirrored thin bent-metal sheets and one dark wood core','Bottom metal feet turn outwards; the official width is foot-to-foot, depth is broad face width','Exposed upright wood edge has vertical grain and rounded top corners','No books or styled accessories included'],affine_fit_scale=scale.tolist())

def materials(out):
 n=2048;u=np.linspace(-.5,.5,n,dtype=np.float32)[None,:];v=np.linspace(0,1,n,dtype=np.float32)[:,None];x=np.broadcast_to(u,(n,n));y=np.broadcast_to(v,(n,n));cloud=_noise._object_noise(x,y,4817,5.4);warp=_noise._object_noise(x,y,1919,22.)
 # 10 cm across fibres, 24 cm along them. Millimetre scale growth contours
 # are warped by the native wood figure; no light strips are painted.
 phase=(x+cloud*.010+warp*.0019+.003*np.sin(y*9))*math.tau*29
 growth=np.sin(phase);late=np.maximum(0,growth-.30)**2
 grain=np.sin(phase*6.2+warp*2.6);broken=np.clip(.55+.45*np.sin(y*51+cloud*2),0,1)
 fine=_noise._object_noise(x,y,3571,343.);pores=np.maximum(0,grain-.75)*broken
 tone=cloud*5.2+growth*2.1-late*5.0+fine*.45-pores*9
 albedo=np.clip(np.array([78,48,33],np.float32)+tone[:,:,None]*np.array([1,.78,.57]),0,255)
 rough=np.clip(.32+cloud*.018+late*.019+pores*.04,.27,.40)
 height=grain*.07+growth*.13-pores*.20+fine*.015
 dx=np.gradient(height,axis=1);dy=np.gradient(height,axis=0);norm=np.stack([-dx,-dy,np.ones_like(dx)],2);norm/=np.linalg.norm(norm,axis=2,keepdims=True)
 orm=np.zeros((n,n,3),np.uint8);orm[:,:,0]=255;orm[:,:,1]=np.rint(rough*255).astype(np.uint8)
 maps={'wood-albedo-2k.png':np.rint(albedo).astype(np.uint8),'wood-normal-2k.png':np.rint((norm+1)*127.5).astype(np.uint8),'wood-orm-2k.png':orm}
 mn=1024;a=np.empty((mn,mn,3),np.uint8);a[:]=[205,204,198];o=np.empty_like(a);o[:]=[255,46,255];normal=np.empty_like(a);normal[:]=[128,128,255]
 maps.update({'metal-albedo-1k.png':a,'metal-orm-1k.png':o,'metal-normal-1k.png':normal})
 for name,pix in maps.items():Image.fromarray(pix,'RGB').save(out/name,optimize=True)
 mats={'wood':dict(baseColorFactor=[1,1,1,1],metallic=0,roughness=1,baseColorTexture='wood-albedo-2k.png',metallicRoughnessTexture='wood-orm-2k.png',normalTexture='wood-normal-2k.png',normalScale=.36,clearcoat=.28,clearcoatRoughness=.25,doubleSided=False),'metal':dict(baseColorFactor=[1,1,1,1],metallic=1,roughness=1,baseColorTexture='metal-albedo-1k.png',metallicRoughnessTexture='metal-orm-1k.png',normalTexture='metal-normal-1k.png',normalScale=.02,doubleSided=False)}
 for m in mats.values():m.update(alphaMode='OPAQUE',extras={'photo_pixels_baked':False,'baked_reflections':False,'intrinsic_material_maps':True})
 qa=dict(valid=True,native_wood_resolution=2048,native_metal_resolution=1024,physical_wood_grain_uv_metres=[.10,.24],photo_pixels_baked=False,baked_reflections=False,maps={name:dict(bytes=(out/name).stat().st_size,sha256=sha(out/name),resolution=list(arr.shape[:2]),mode='RGB')for name,arr in maps.items()})
 dump(out/'material-validation.json',qa);return mats

def main():
 research=json.loads((R.parent/'research-glass.json').read_text());p=next(p for p in research['products']if p['sku']=='4328/043/700');v=p['variants'][0]
 id='4328-043-700-h23p25-w9p25-d14p5';out=R/'models'/id;out.mkdir(parents=True,exist_ok=True)
 meshes,gqa=bookend();mats=materials(out);metadata=dict(id=id,name='Ahşap ve metal kitap desteği',sku=p['sku'],url=p['official_url'],category='Dekoratif objeler ve kitap destekleri',dimensions_cm=[9.25,23.25,14.5],source_dimensions_hwd_cm=[23.25,9.25,14.5],estimated_dimensions=False,source_market='Türkiye',size_source_kind='official_tr',size_source_urls=[p['official_url']],scale_note='Resmi Türkiye ölçüleri kullanılmıştır. Metal/ahşap yerel kalınlıklar ve kavisler ürün fotoğraflarından yorumlanmıştır.',units='metres',up_axis='Y',origin='bottom bounding-box centre',source_images=p['images'],photo_pixels_baked=False,baked_reflections=False)
 model=out/'model.json';dump(model,dict(metadata=metadata,materials=mats,meshes=meshes));dump(out/'geometry-validation.json',gqa)
 rep=export_assets(model,out,id);glb=out/(id+'.glb');doc,binary=read_glb(glb);doc['samplers']=[dict(magFilter=9729,minFilter=9987,wrapS=10497,wrapT=10497)]
 for tex in doc.get('textures',[]):tex['sampler']=0
 write_glb(glb,doc,binary);rep['deliverable_sha256']['glb']=sha(glb);rep['glb_bytes']=glb.stat().st_size;dump(rep['files']['validation'],rep)
 e={k:metadata[k]for k in ['id','name','sku','url','category','dimensions_cm','source_dimensions_hwd_cm','estimated_dimensions','source_market','size_source_kind','size_source_urls','scale_note']};e.update(model_path=str(model),asset_dir=str(out),glb_path=str(glb),sha256=sha(glb),bytes=glb.stat().st_size,material_label='Ahşap ve metal · Kahverengi / gümüş',source_images=p['images'],geometry_validation=str(out/'geometry-validation.json'),material_validation=str(out/'material-validation.json'),model_revision='object-4328-photo-v1',source_anomalies=[])
 dump(R/'manifest.json',[e]);print(id,e['bytes'],gqa['triangles'])

if __name__=='__main__':main()
