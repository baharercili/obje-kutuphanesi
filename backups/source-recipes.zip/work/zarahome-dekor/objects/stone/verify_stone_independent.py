"""Independent final GLB readback. Writes only independent-qa.json, never assets."""
from pathlib import Path
from collections import Counter
import hashlib,io,json,struct,math
import numpy as np
from PIL import Image
R=Path(__file__).resolve().parent

def glb(path):
 raw=path.read_bytes();assert struct.unpack_from('<4sII',raw)==(b'glTF',2,len(raw))
 jlen,jtype=struct.unpack_from('<II',raw,12);assert jtype==0x4e4f534a
 doc=json.loads(raw[20:20+jlen]);offset=20+jlen;blen,btype=struct.unpack_from('<II',raw,offset);assert btype==0x004e4942
 binary=raw[offset+8:offset+8+blen];assert len(binary)==blen
 return raw,doc,binary

def accessor(doc,binary,index):
 a=doc['accessors'][index];view=doc['bufferViews'][a['bufferView']]
 dtype={5126:'<f4',5125:'<u4',5123:'<u2',5121:'u1'}[a['componentType']];dim={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}[a['type']]
 start=view.get('byteOffset',0)+a.get('byteOffset',0);itemsize=np.dtype(dtype).itemsize;stride=view.get('byteStride',itemsize*dim)
 end=start+(a['count']-1)*stride+itemsize*dim;assert end<=view.get('byteOffset',0)+view['byteLength']<=len(binary)
 return np.ndarray((a['count'],dim),dtype=dtype,buffer=binary,offset=start,strides=(stride,itemsize)).copy()

def cavity_hits(tri,x,z):
 a,b,c=tri[:,0],tri[:,1],tri[:,2];v0=b[:,[0,2]]-a[:,[0,2]];v1=c[:,[0,2]]-a[:,[0,2]];v2=np.array([x,z])-a[:,[0,2]]
 det=v0[:,0]*v1[:,1]-v0[:,1]*v1[:,0];ok=np.abs(det)>1e-15;u=np.zeros(len(a));v=u.copy()
 u[ok]=(v2[ok,0]*v1[ok,1]-v2[ok,1]*v1[ok,0])/det[ok];v[ok]=(v0[ok,0]*v2[ok,1]-v0[ok,1]*v2[ok,0])/det[ok]
 ok&=(u>=-1e-7)&(v>=-1e-7)&(u+v<=1+1e-7)
 return sorted(set(round(float(y),7)for y in (a[ok,1]+u[ok]*(b[ok,1]-a[ok,1])+v[ok]*(c[ok,1]-a[ok,1]))))

def topology(p,f):
 _,weld=np.unique(np.round(p,7),axis=0,return_inverse=True);wf=weld[f];edge=Counter();direction=Counter()
 for a,b,c in wf:
  for s,t in [(a,b),(b,c),(c,a)]:key=(min(s,t),max(s,t));edge[key]+=1;direction[key]+=1 if s<t else-1
 assert all(count==2 for count in edge.values()),'Open or nonmanifold welded edge'
 assert all(count==0 for count in direction.values()),'Inconsistent face winding'
 area=np.linalg.norm(np.cross(p[f[:,1]]-p[f[:,0]],p[f[:,2]]-p[f[:,0]]),axis=1)/2;assert area.min()>1e-14
 volume=float(np.sum(p[f[:,0]]*np.cross(p[f[:,1]],p[f[:,2]]))/6);assert volume>0
 parents=np.arange(len(np.unique(weld)))
 def find(a):
  while parents[a]!=a:parents[a]=parents[parents[a]];a=parents[a]
  return a
 for a,b in edge:
  aa,bb=find(a),find(b)
  if aa!=bb:parents[aa]=bb
 components=len(set(find(int(k))for k in np.unique(wf)));assert components==1
 return dict(closed_after_exported_position_weld=True,consistent_winding=True,connected_components=components,signed_volume_m3=volume,min_triangle_area_m2=float(area.min()),vertices=len(p),triangles=len(f))

def inspect(entry):
 path=Path(entry['glb_path']);raw,doc,binary=glb(path);digest=hashlib.sha256(raw).hexdigest()
 assert digest==entry['sha256'];assert len(raw)==entry['bytes'];assert entry['size_source_kind']=='tr_live_product';assert not entry['estimated_dimensions']
 positions=[];faces=[];offset=0;parts=[]
 for mesh in doc['meshes']:
  for primitive in mesh['primitives']:
   p=accessor(doc,binary,primitive['attributes']['POSITION']).astype(float);n=accessor(doc,binary,primitive['attributes']['NORMAL']);uv=accessor(doc,binary,primitive['attributes']['TEXCOORD_0']);f=accessor(doc,binary,primitive['indices']).reshape(-1,3).astype(np.int64)
   assert np.isfinite(p).all()and np.isfinite(n).all()and np.isfinite(uv).all();assert f.min()>=0 and f.max()<len(p)
   assert np.max(np.abs(np.linalg.norm(n,axis=1)-1))<2e-5
   part=topology(p,f);part['name']=mesh.get('name');part['max_normal_length_error']=float(np.max(np.abs(np.linalg.norm(n,axis=1)-1)));parts.append(part)
   positions.append(p);faces.append(f+offset);offset+=len(p)
 p=np.concatenate(positions);f=np.concatenate(faces);tri=p[f];lo=p.min(0);hi=p.max(0);dims=(hi-lo)*100
 assert np.allclose(dims,entry['dimensions_cm'],atol=2e-5);assert abs(lo[1])<1e-7;assert np.max(np.abs((hi+lo)[[0,2]]))<2e-7
 model=json.loads(Path(entry['model_path']).read_text());source={}
 for mat in model['materials'].values():
  for key,value in mat.items():
   if key.endswith('Texture')and isinstance(value,str):
    data=(Path(entry['asset_dir'])/value).read_bytes();source[hashlib.sha256(data).hexdigest()]=dict(filename=value,key=key,bytes=len(data))
 embedded=set();maps=[]
 for image in doc['images']:
  assert 'uri'not in image;view=doc['bufferViews'][image['bufferView']];start=view.get('byteOffset',0);data=binary[start:start+view['byteLength']];assert len(data)==view['byteLength']
  h=hashlib.sha256(data).hexdigest();assert h in source;embedded.add(h);im=Image.open(io.BytesIO(data));assert im.size==(2048,2048)
  # Indexed PNG is legal. Inspect actual decoded RGB channels, never palette
  # indices as roughness/metallic values (the prior glass audit found this trap).
  pixels=np.array(im.convert('RGB'));q=dict(**source[h],sha256=h,embedded_bytes_equal_source=True,dimensions=list(im.size),png_mode=im.mode)
  if source[h]['key']=='metallicRoughnessTexture':
   assert pixels[:,:,2].max()==0;q['roughness_range']=[float(pixels[:,:,1].min()/255),float(pixels[:,:,1].max()/255)];q['metallic_range']=[0,0]
  maps.append(q)
 assert embedded==set(source);assert all(m['pbrMetallicRoughness'].get('metallicFactor',1)==0 for m in doc['materials'])
 extra={};center=cavity_hits(tri,0,0)
 if entry['sku'].startswith('9359/'):
  assert len(center)==2 and abs(center[0])<1e-7 and abs(center[-1]-hi[1])<2e-7
  extra=dict(verified_solid_block=True,center_vertical_ray_y_hits_m=center)
 else:
  assert entry['sku']=='9383/222/251';assert len(center)==2 and abs(center[0])<1e-7 and abs(center[-1]-.0085)<.00035
  probes={}
  for name,x,z in [('x_positive',.070,0),('x_negative',-.070,0),('z_positive',0,.070),('z_negative',0,-.070)]:
   hits=cavity_hits(tri,x,z);assert len(hits)==2 and abs(hits[0])<1e-7;probes[name]=hits
   expected=.0232 if name.startswith('x')else .028;tol=.0008 if name.startswith('x')else .0003;assert abs(hits[-1]-expected)<tol,(name,hits)
  sample=[]
  for i in range(256):
   theta=math.tau*i/256;hits=cavity_hits(tri,.070*math.cos(theta),.070*math.sin(theta));assert len(hits)==2;sample.append(hits[-1])
  dips=np.array(sample)<.0274;run_count=sum(bool(dips[i]and not dips[(i-1)%len(dips)])for i in range(len(dips)));assert run_count==2,run_count
  radial={}
  for radius in [.020,.040,.050]:
   top=[cavity_hits(tri,radius*math.cos(a),radius*math.sin(a))[-1]for a in np.linspace(0,math.tau,16,endpoint=False)];assert max(top)-min(top)<.00025;radial[str(radius)]=[min(top),max(top)]
  assert center[-1]<radial['0.02'][0]<radial['0.04'][0]<radial['0.05'][0]<hi[1]
  extra=dict(open_single_circular_recess=True,center_vertical_ray_y_hits_m=center,opposed_rest_count_from_256_ring_rays=run_count,rest_axis='X',axis_ray_y_hits_m=probes,circular_basin_top_height_ranges_m=radial,ring_top_height_range_m=[min(sample),max(sample)])
 return dict(id=entry['id'],valid=True,sha256=digest,bytes=len(raw),dimensions_cm=dims.tolist(),bottom_y_m=float(lo[1]),origin_bottom_center=True,meshes=parts,embedded_native_2k_source_maps=maps,**extra)

def main():
 manifest=R/'manifest.json';entries=json.loads(manifest.read_text());assert len(entries)==3,'Wait for the complete 3-record final manifest; first-manifest is not accepted'
 assert Counter(e['sku']for e in entries)=={'9359/043/700':2,'9383/222/251':1}
 expected=sorted([[9.1,9.1,9.1],[9.1,14.8,9.1],[15,2.8,15]])
 assert sorted(e['dimensions_cm']for e in entries)==expected
 rows=[inspect(e)for e in entries]
 result=dict(valid=True,count=len(rows),manifest_path=str(manifest),manifest_sha256=hashlib.sha256(manifest.read_bytes()).hexdigest(),records=rows,total_glb_bytes=sum(e['bytes']for e in entries),scope='Read-only final GLB binary audit; only this script and report written. No source, manifest, model, texture or GLB edited.')
 (R/'independent-qa.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
 for row in rows:print(row['id'],'PASS',row['bytes'],row['sha256'])
 print('ALL 3 final GLBs PASS; source 2K map bytes preserved; two X rests verified')
if __name__=='__main__':main()
