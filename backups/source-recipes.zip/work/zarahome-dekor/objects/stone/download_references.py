import concurrent.futures,hashlib,json,re,urllib.request
from pathlib import Path
ROOT=Path(__file__).resolve().parent;(ROOT/'references').mkdir(exist_ok=True)
urls=json.loads((ROOT/'image-urls.json').read_text())
def get(url):
 url=re.sub(r'([?&])w=\d+',r'\g<1>w=1440',url)
 stem=re.search(r'/([^/]+)\.jpg',url).group(1);suffix=hashlib.sha256(url.split('?')[0].encode()).hexdigest()[:8];path=ROOT/'references'/(stem+'_'+suffix+'.jpg')
 if not path.exists():
  req=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0'})
  with urllib.request.urlopen(req,timeout=45) as r: data=r.read();path.write_bytes(data)
 data=path.read_bytes();return {'url':url,'path':str(path),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as p:result=list(p.map(get,urls))
(ROOT/'reference-manifest.json').write_text(json.dumps(result,indent=2));print(json.dumps({'images':len(result),'bytes':sum(x['bytes'] for x in result)}))
