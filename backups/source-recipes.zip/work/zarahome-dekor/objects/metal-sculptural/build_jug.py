"""4515: photograph-derived hollow fluted steel jug, not a scan.

Only exterior W/H/D are official. Local stock, flute count and profile are
careful gallery inferences. Source photographs never enter PBR textures.
"""
from pathlib import Path
import sys,json,math,hashlib
import numpy as np
from PIL import Image
ROOT=Path(__file__).resolve().parent
CATALOG=ROOT.parents[1]
sys.path.insert(0,str(CATALOG));sys.path.insert(0,str(CATALOG/'bowls-trays/tray-build'))
from vase_geometry import _finalize,_signed_volume
from tray_geometry import smooth_profile
from export_catalog import export_assets,read_glb,write_glb
TAU=math.tau
def dump(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,separators=(',',':'))+'\n')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def raw(name,v,f,uv):
 if _signed_volume(v,f)<0:f=[(a,c,b) for a,b,c in f]
 return {'name':name,'material':'steel','_vertices':v,'_faces':f,'_uvs':uv,'_wall_pairs':[]}
def lathe(name,profile,n=576,steps=5,fluted=False,spout=False):
 interpolated=smooth_profile(profile,steps=steps);rows=[]
 for p in interpolated:
  if not rows or math.dist(p,rows[-1])>1e-10:rows.append(p)
 v=[];uv=[];rings=[];f=[]
 arc=[0.]
 for a,b in zip(rows,rows[1:]):arc.append(arc[-1]+math.hypot(b[0]-a[0],b[1]-a[1]))
 for (r,y),length in zip(rows,arc):
  if r<1e-9:
   rings.append([len(v)]);v.append((0,y,0));uv.append((.5,length/arc[-1]));continue
  row=[]
  for j in range(n+1):
   t=TAU*j/n;rr=r;yy=y
   if fluted:
    fade=min(1,max(0,(y-.009)/.008),max(0,(.167-y)/.006))
    # The gallery ribs follow gentle bowed meridians, and end crisply below
    # the smooth upper collar. Radial relief is geometry, never dark stripes.
    phase=48*(t+.020*math.sin(math.pi*(y-.01)/.16))
    rr += .00115*fade*(.82*math.cos(phase)+.18*math.cos(2*phase))
   x=rr*math.cos(t);z=rr*math.sin(t)
   if spout and y>.166:
    influence=min(1,max(0,(y-.166)/.026))**1.7
    angle=math.atan2(math.sin(t+math.pi/2),math.cos(t+math.pi/2))
    lip=math.exp(-.5*(angle/.45)**2)
    z-=.023*influence*lip;yy+=.008*influence*lip
   row.append(len(v));v.append((x,yy,z));uv.append((j/n,length/arc[-1]))
  rings.append(row)
 for a,b in zip(rings,rings[1:]):
  if len(a)==1:
   for j in range(n):f.append((a[0],b[j],b[j+1]))
  elif len(b)==1:
   for j in range(n):f.append((a[j],b[0],a[j+1]))
  else:
   for j in range(n):f.extend(((a[j],b[j+1],a[j+1]),(a[j],b[j],b[j+1])))
 return raw(name,v,f,uv)
def spline(points,steps=10):
 out=[];p=np.asarray(points,float)
 for i in range(len(p)-1):
  a,b=p[i:i+2];prev=p[max(0,i-1)];nxt=p[min(len(p)-1,i+2)]
  for j in range(steps):
   t=j/steps;out.append((2*t**3-3*t*t+1)*a+(t**3-2*t*t+t)*.4*(b-prev)+(-2*t**3+3*t*t)*b+(t**3-t*t)*.4*(nxt-a))
 out.append(p[-1]);return out
def strap(name,points,width=.011,thickness=.00145):
 # Flattened rounded rectangle section: broad polished faces and small soft
 # stock edges, with a true clear opening under the handle.
 v=[];uv=[];faces=[];section=[];bevel=.00035
 for sx,sy,base in [(1,1,0),(-1,1,90),(-1,-1,180),(1,-1,270)]:
  for k in range(4):
   a=math.radians(base+k*30)
   section.append((sx*(width/2-bevel)+bevel*math.cos(a),sy*(thickness/2-bevel)+bevel*math.sin(a)))
 # Use an elliptically rounded rectangle boundary with consistently ordered
 # perimeter rather than treating the flat strip as a round tube.
 section=[]
 for j in range(24):
  q=TAU*j/24;c=math.cos(q);s=math.sin(q)
  section.append((width/2*math.copysign(abs(c)**.30,c),thickness/2*math.copysign(abs(s)**.30,s)))
 m=len(section)
 for i,p in enumerate(points):
  tangent=points[min(i+1,len(points)-1)]-points[max(0,i-1)];tangent/=np.linalg.norm(tangent)
  transverse=np.array([1.,0.,0.]);normal=np.cross(tangent,transverse);normal/=np.linalg.norm(normal)
  for j,(a,b) in enumerate(section+section[:1]):
   v.append(tuple(p+transverse*a+normal*b));uv.append((j/m,i/(len(points)-1)))
 for i in range(len(points)-1):
  for j in range(m):
   a=i*(m+1)+j;b=a+m+1;faces.extend(((a,b,a+1),(a+1,b,b+1)))
 k0=len(v);k1=k0+1;v.extend((tuple(points[0]),tuple(points[-1])));uv.extend(((.5,0),(.5,1)))
 for j in range(m):
  faces.append((k0,j,j+1));k=(len(points)-1)*(m+1)+j;faces.append((k1,k+1,k))
 return raw(name,v,faces,uv)
def geometry(id):
 outer=[(0,.009),(.033,.009),(.041,.012),(.053,.023),(.065,.042),(.0735,.064),(.0765,.085),(.0755,.104),(.069,.126),(.057,.144),(.043,.157),(.035,.166),(.0355,.171),(.038,.180),(.043,.1875),(.047,.192)]
 # A continuous wall wraps the lip and returns all the way to the interior
 # floor. It has no cap across the mouth. Neck stock ~0.9 mm, base ~3 mm.
 inner=[(.0467,.1922),(.0461,.1921),(.0459,.1917),(.042,.1872),(.037,.1796),(.0345,.171),(.034,.166),(.042,.157),(.056,.144),(.068,.126),(.0745,.104),(.0755,.085),(.0725,.064),(.064,.042),(.052,.023),(.040,.015),(.032,.012),(0,.012)]
 parts=[lathe(id+'-hollow-fluted-body-smooth-collar-pour-spout',outer+inner,fluted=True,spout=True)]
 parts.append(lathe(id+'-smooth-low-cylindrical-foot',[(0,0),(.035,0),(.0365,.0005),(.0368,.001),(.0368,.0095),(.0364,.010),(.034,.010),(0,.010)],n=288,steps=3))
 path=spline([(0,.190,.042),(0,.194,.061),(0,.195,.083),(0,.187,.105),(0,.172,.117),(0,.154,.119),(0,.137,.108),(0,.121,.091),(0,.110,.081),(0,.102,.0795),(0,.095,.084),(0,.092,.094)],steps=10)
 parts.append(strap(id+'-broad-flat-C-strap-with-curled-free-tip',path,width=.011,thickness=.0014))
 xyz=np.concatenate([np.asarray(p['_vertices']) for p in parts]);lo=xyz.min(axis=0);hi=xyz.max(axis=0);target=np.array([.155,.20,.195]);scale=target/(hi-lo);origin=(lo+hi)/2;origin[1]=lo[1]
 meshes=[];checks=[]
 for part in parts:
  part['_vertices']=[tuple((np.asarray(p)-origin)*scale) for p in part['_vertices']]
  mm,check=_finalize(part);meshes.append(mm);checks.append(check)
 xyz=np.concatenate([np.asarray(m['positions']).reshape(-1,3) for m in meshes]);dims=np.ptp(xyz,axis=0);assert np.allclose(dims,target,atol=1e-8)
 return meshes,{'valid':True,'units':'metres','up_axis':'Y','dimensions_metres':dims.tolist(),'bounds_metres':{'min':xyz.min(axis=0).tolist(),'max':xyz.max(axis=0).tolist()},'meshes':checks,'triangles':sum(len(m['indices'])//3 for m in meshes),'closed_after_uv_seam_weld':True,'consistent_winding':True,'positive_volume':True,'real_open_mouth':True,'real_interior_floor':True,'physical_flutes':48,'physical_flat_strap_handle':True,'physical_pour_spout':True,'affine_fit_scale':scale.tolist(),'notes':['Dış ölçüler resmî Türkiye sayfasından alınmıştır.','İç profil, 48 yiv, metal kalınlığı ve kulp kıvrımı ürün fotoğraflarından yorumlanmıştır; tarama verisi değildir.','Kulp yönü derinlik eksenidir; dökme ağzı karşı yöndedir.']}
def noise(n,k,seed):
 a=np.random.default_rng(seed).normal(size=(k,k)).astype(np.float32);return np.asarray(Image.fromarray(a,mode='F').resize((n,n),Image.Resampling.BICUBIC),np.float32)
def materials(out):
 n=2048;low=noise(n,17,4515);mid=noise(n,83,4516)
 # Neutral conductor base, fine intrinsic surface finish, no reflections or
 # lighting from source photography. Low entropy preserves resolution cheaply.
 color=np.clip(np.array([205,204,199])[None,None,:]+(.45*low+.20*mid)[...,None],0,255).astype(np.uint8)
 rough=np.clip(.205+.006*low+.004*mid,.18,.24);orm=np.empty((n,n,3),np.uint8);orm[:,:,0]=255;orm[:,:,1]=(rough*255).astype(np.uint8);orm[:,:,2]=255
 gy,gx=np.gradient(mid*.0007);normal=np.stack((-gx,gy,np.ones_like(gx)),axis=-1);normal/=np.linalg.norm(normal,axis=-1,keepdims=True);normal=np.clip((normal*.5+.5)*255,0,255).astype(np.uint8)
 a='native-albedo-2k.jpg';r='native-pbr-2k.png';b='native-normal-2k.png';Image.fromarray(color).save(out/a,quality=96,subsampling=0,optimize=True)
 indexed=Image.fromarray(orm[:,:,1],mode='P');indexed.putpalette([v for i in range(256) for v in (255,i,255)]);indexed.save(out/r,optimize=True);assert np.array_equal(orm,np.asarray(Image.open(out/r).convert('RGB')))
 Image.fromarray(normal).save(out/b,optimize=True)
 mats={'steel':{'baseColorFactor':[1,1,1,1],'metallic':1,'roughness':1,'baseColorTexture':a,'metallicRoughnessTexture':r,'normalTexture':b,'normalScale':.15,'doubleSided':False,'extras':{'native_resolution':2048,'intrinsic_PBR':True,'photo_pixels_baked':False,'baked_reflections':False}}}
 return mats,{'valid':True,'native_resolution':[n,n],'no_baked_lighting':True,'no_photo_pixels':True,'roughness_range':[float(rough.min()),float(rough.max())],'metallic_map_constant':1,'lossless_ORM_palette':True,'maps':{x:{'bytes':(out/x).stat().st_size,'sha256':sha(out/x),'resolution':[n,n]} for x in (a,r,b)}}
def main():
 p=next(p for p in json.loads((ROOT/'research.json').read_text())['products'] if p['sku'].startswith('4515'));v=p['variants'][0];id=v['id'];out=ROOT/'models'/id;out.mkdir(parents=True,exist_ok=True);meshes,gqa=geometry(id);mats,mqa=materials(out)
 imgs=[{**i,'url':i['source_url']+'?w=1440','thumbnail_url':i['source_url']+'?w=240'} for i in p['images']]
 metadata={'id':id,'sku':p['sku'],'name':p['name'],'url':p['official_url'],'category':'Dekoratif objeler','dimensions_cm':v['dimensions_cm'],'source_dimensions_hwd_cm':[20,15.5,19.5],'units':'metres','up_axis':'Y','origin':'bottom bounding-box centre','overall_dimensions_official':True,'local_details_photo_inferred':True,'source_images':imgs,'source_anomalies':[],'source_type':'official Zara Home TR product page and gallery photo reconstruction','model_revision':'objects-metal-photo-v1','baked_reflections':False,'photo_pixels_baked':False}
 model=out/'model.json';dump(model,{'metadata':metadata,'materials':mats,'meshes':meshes});dump(out/'geometry-validation.json',gqa);dump(out/'material-validation.json',mqa);export_assets(model,out,id);glb=out/(id+'.glb');doc,bin=read_glb(glb);doc['samplers']=[{'magFilter':9729,'minFilter':9987,'wrapS':10497,'wrapT':33071}]
 for t in doc.get('textures',[]):t['sampler']=0
 write_glb(glb,doc,bin);size=glb.stat().st_size;assert size<20*1024*1024
 entry={**metadata,'model_path':str(model),'asset_dir':str(out),'glb_path':str(glb),'sha256':sha(glb),'bytes':size,'material_label':'Gümüş · Paslanmaz çelik','estimated_dimensions':False,'size_source_kind':'official_tr','size_source_urls':[p['official_url']],'source_market':'Türkiye','scale_note':'Resmî dış ölçüler; iç profil, yivler ve kulp ayrıntıları ürün fotoğraflarından yorumlanmıştır.','reference_images':imgs,'officialsource':p['official_url'],'geometry_validation':str(out/'geometry-validation.json'),'material_validation':str(out/'material-validation.json')}
 dump(ROOT/'manifest-4515.json',[entry]);dump(ROOT/'manifest.json',[entry]);dump(ROOT/'qa-summary.json',{'valid':True,'count':1,'all_under_20MiB':True,'all_native_2k':True,'triangles':gqa['triangles'],'entries':[{'id':id,'sha256':entry['sha256'],'bytes':size}]});print(id,'triangles',gqa['triangles'],'bytes',size,flush=True)
if __name__=='__main__':main()
