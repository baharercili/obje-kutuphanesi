"""Detect folded projected mat caps that closed-solid topology cannot reject."""
from pathlib import Path
import json,numpy as np
P=Path(__file__).resolve().parent
f=P/'manifest-frames-all91-frozen.json'
if not f.exists():f=P/'manifest-frames-all91-pending-qa.json'
entries=json.loads(f.read_text());checks=[]
for e in entries:
    model=json.loads(Path(e['model_path']).read_text())
    for mesh in model['meshes']:
        if 'passepartout'not in mesh['name']:continue
        v=np.array(mesh['positions']).reshape(-1,3);faces=np.array(mesh['indices']).reshape(-1,3);t=v[faces]
        top=np.all(abs(t[:,:,2]-v[:,2].max())<1e-8,axis=1)
        zcross=np.cross(t[:,1]-t[:,0],t[:,2]-t[:,0])[:,2]
        reverse=int(np.sum(top&(zcross< -1e-12)));forward=int(np.sum(top&(zcross>1e-12)))
        checks.append(dict(id=e['id'],mesh=mesh['name'],front_triangles=forward,reversed_front_triangles=reverse,front_cap_uniform_positive_winding=reverse==0))
        assert reverse==0,(e['id'],reverse)
result=dict(valid=True,surfaces=len(checks),note='Flat front annulus triangles must have consistent projected positive orientation; detects angularly twisted loft folds even when closed manifold and positive volume pass.',checks=checks)
(P/'mat-surface-winding-audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(len(checks),'mat front surfaces: no inverted projected triangles')
