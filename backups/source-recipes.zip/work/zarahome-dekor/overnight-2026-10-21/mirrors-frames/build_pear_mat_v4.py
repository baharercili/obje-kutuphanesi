from pathlib import Path
import json,shutil
from build_frames_batch2 import R,matted,dump,sha,check
from export_catalog import export_assets
if (R/'manifest-frames-all91-frozen.json').exists():raise SystemExit('Preserve frozen assets; create a new revision directory.')
outlist=[]
for e in json.loads((R/'manifest-batch2-frozen.json').read_text()):
    if not e['id'].startswith('8397-045-303'):continue
    oldsha=e['sha256'];src=Path(e['asset_dir']);out=R/'revisions'/'pear-angular-mat-geometry-v4'/e['id']
    if out.exists():shutil.rmtree(out)
    shutil.copytree(src,out)
    h,w,d=e['source_dimensions_hwd_cm'];photo=[.10,.15]if h<30 else[.15,.20]
    meshes,gqa=matted(w/100,h/100,d/100,'tear',photo,'gold')
    model=json.loads((out/'model.json').read_text());model['meshes']=meshes
    model['metadata']['geometry_revision']='Pear-shaped outer mat and rectangular photo hole matched along common angular rays; no inverted front annulus triangles.'
    dump(out/'model.json',model);dump(out/'geometry-validation.json',gqa)
    export_assets(out/'model.json',out,e['id']);glb=out/(e['id']+'.glb')
    e.update(model_path=str(out/'model.json'),asset_dir=str(out),glb_path=str(glb),sha256=sha(glb),bytes=glb.stat().st_size,geometry_validation=str(out/'geometry-validation.json'),material_validation=str(out/'material-validation.json'),supersedes_sha256=oldsha,geometry_supersedes_sha256=oldsha,geometry_revision='angular-matched-pear-mat-v4')
    check(e);outlist.append(e);print(e['id'],e['bytes'],flush=True)
dump(R/'manifest-pear-mat-geometry-v4.json',outlist)
dump(R/'independent-qa-pear-mat-v4.json',dict(valid=True,count=len(outlist),checks=[check(e)for e in outlist]))
