"""Photo-specific, closed solid mirror and picture-frame masters.

Original photographs remain unedited reference masters, never baked as reflection
or fake artwork. Dimensions are official TR measurements; local profiles are
interpreted from inspected product photographs.
"""
from pathlib import Path
import sys,json,math,hashlib,importlib.util
import numpy as np
from PIL import Image
R=Path(__file__).resolve().parent
WORK=R.parents[1]
sys.path.insert(0,str(WORK))
from vase_geometry import _finalize,_signed_volume
from export_catalog import export_assets
sp=importlib.util.spec_from_file_location('_noise',WORK/'bowls-trays/tray-build/tray_materials.py');noise=importlib.util.module_from_spec(sp);sp.loader.exec_module(noise)
def dump(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def area(p):return np.sum(p[:,0]*np.roll(p[:,1],-1)-np.roll(p[:,0],-1)*p[:,1])/2

def rounded(w,h,r,n=256,cy=0,wave=0,waves=(3,4)):
    # Sample arclength around a rounded rectangle in the XY plane.
    r=min(r,w*.49,h*.49);a=w/2;b=h/2;L=2*(w+h-4*r)+math.tau*r
    segments=[('l',w-2*r,(-a+r,-b),(1,0)),('a',math.pi*r/2,(a-r,-b+r),(-math.pi/2,)),('l',h-2*r,(a,-b+r),(0,1)),('a',math.pi*r/2,(a-r,b-r),(0,)),('l',w-2*r,(a-r,b),(-1,0)),('a',math.pi*r/2,(-a+r,b-r),(math.pi/2,)),('l',h-2*r,(-a,b-r),(0,-1)),('a',math.pi*r/2,(-a+r,-b+r),(math.pi,))]
    points=[]
    for t in np.arange(n)/n:
        s=t*L
        for kind,ll,p,q in segments:
            if s<=ll+1e-9:
                if kind=='l':x,y=p[0]+s*q[0],p[1]+s*q[1]
                else:ang=q[0]+s/r;x,y=p[0]+r*math.cos(ang),p[1]+r*math.sin(ang)
                break
            s-=ll
        if wave:
            # Waves follow the four physical edges, with a soft blend at corners.
            vx=(abs(x)/a)**8;vy=(abs(y)/b)**8
            x+=np.sign(x)*wave*math.cos(math.pi*waves[1]*y/b)*vx/(vx+vy+1e-8)
            y+=np.sign(y)*wave*math.cos(math.pi*waves[0]*x/a)*vy/(vx+vy+1e-8)
        points.append((x,y+cy))
    return np.array(points)

def circle(r,n=256,cy=0):
    a=np.arange(n)*math.tau/n;return np.c_[r*np.cos(a),cy+r*np.sin(a)]
def octagon(r,n=256,cy=0):
    a=np.arange(n)*math.tau/n;rad=r/np.maximum(np.abs(np.cos(a)),np.maximum(np.abs(np.sin(a)),(np.abs(np.cos(a))+np.abs(np.sin(a)))/math.sqrt(2)))
    # The regular octagon has horizontal/vertical edges and four chamfers.
    return np.c_[rad*np.cos(a),cy+rad*np.sin(a)]
def arch(w,h,cy=0,n=256):
    # Shallow elliptical crown, straight side rails and a straight bottom.
    a=w/2;y0=cy-h/2;y1=cy+h/2;rise=h*.10
    raw=[]
    raw.extend([(x,y0)for x in np.linspace(-a,a,64,endpoint=False)])
    raw.extend([(a,y)for y in np.linspace(y0,y1-rise,64,endpoint=False)])
    raw.extend([(a*math.cos(t),y1-rise+rise*math.sin(t))for t in np.linspace(0,math.pi,64,endpoint=False)])
    raw.extend([(-a,y)for y in np.linspace(y1-rise,y0,64,endpoint=False)])
    return np.array(raw)

class Builder:
    def __init__(self):self.groups={};self.solids=0
    def add(self,name,mat,v,f,uv=None):
        v=np.array(v,float);f=list(f)
        if _signed_volume(v,f)<0:f=[(a,c,b)for a,b,c in f]
        if uv is None:uv=[(p[0]*3+0.5,p[1]*3+0.5)for p in v]
        key=(name,mat)
        if key not in self.groups:self.groups[key]=dict(name=name,material=mat,_vertices=[],_uvs=[],_faces=[])
        g=self.groups[key];off=len(g['_vertices']);g['_vertices']+=v.tolist();g['_uvs']+=list(uv);g['_faces'] +=[(a+off,b+off,c+off)for a,b,c in f];self.solids+=1
    def ring(self,name,mat,profiles):
        # A toroidal solid with a real open centre and a separately shaped profile.
        N=len(profiles[0][0]);v=[];f=[]
        for points,z in profiles:v.extend([(x,y,z)for x,y in points])
        for j in range(len(profiles)):
            for i in range(N):
                a=j*N+i;b=j*N+(i+1)%N;c=((j+1)%len(profiles))*N+i;d=((j+1)%len(profiles))*N+(i+1)%N;f.extend([(a,b,c),(b,d,c)])
        self.add(name,mat,v,f)
    def slab(self,name,mat,points,z0,z1,bevel=0):
        N=len(points);p=np.array(points);c=p.mean(0)
        layers=[(p,z0),(p,z1)]
        if bevel:
            scale=1-bevel/max(np.ptp(p[:,0]),np.ptp(p[:,1]))*2
            layers=[(c+(p-c)*scale,z0),(p,z0+bevel),(p,z1-bevel),(c+(p-c)*scale,z1)]
        v=[(x,y,z)for p,z in layers for x,y in p];f=[]
        for j in range(len(layers)-1):
            for i in range(N):a=j*N+i;b=j*N+(i+1)%N;c0=(j+1)*N+i;d=(j+1)*N+(i+1)%N;f.extend([(a,b,c0),(b,d,c0)])
        back=len(v);front=back+1;v.extend([(float(c[0]),float(c[1]),z0),(float(c[0]),float(c[1]),z1)])
        for i in range(N):f.extend([(back,(i+1)%N,i),(front,(len(layers)-1)*N+i,(len(layers)-1)*N+(i+1)%N)])
        self.add(name,mat,v,f)
    def tube(self,name,mat,points,r,sides=12,closed=False,flatten=1):
        pts=np.array(points,float);N=len(pts);v=[];f=[]
        for i,p in enumerate(pts):
            t=pts[(i+1)%N]-pts[(i-1)%N]if closed else pts[min(i+1,N-1)]-pts[max(i-1,0)];t/=np.linalg.norm(t);normal=np.cross(t,[0,0,1])
            if np.linalg.norm(normal)<.01:normal=np.cross(t,[0,1,0])
            normal/=np.linalg.norm(normal);bi=np.cross(t,normal)
            rad=r(i/(N-1))if callable(r)else r
            for j in range(sides):v.append(p+rad*(normal*math.cos(j*math.tau/sides)+bi*flatten*math.sin(j*math.tau/sides)))
        for i in range(N if closed else N-1):
            for j in range(sides):a=i*sides+j;b=i*sides+(j+1)%sides;c=((i+1)%N)*sides+j;d=((i+1)%N)*sides+(j+1)%sides;f.extend([(a,b,c),(b,d,c)])
        if not closed:
            a=len(v);v.extend([pts[0],pts[-1]])
            for j in range(sides):f.extend([(a,(j+1)%sides,j),(a+1,(N-1)*sides+j,(N-1)*sides+(j+1)%sides)])
        self.add(name,mat,v,f)
    def finish(self,dims,features):
        vs=np.concatenate([np.array(g['_vertices'])for g in self.groups.values()]);lo=vs.min(0);hi=vs.max(0);scale=np.array(dims)/(hi-lo);center=np.array([(lo[0]+hi[0])/2,lo[1],(lo[2]+hi[2])/2]);meshes=[];qa=[]
        for g in self.groups.values():g['_vertices']=[tuple((np.array(v)-center)*scale)for v in g['_vertices']];m,q=_finalize(g);meshes.append(m);qa.append(q)
        return meshes,dict(valid=True,units='metres',up_axis='Y',origin='bottom bounding-box centre',dimensions_metres=dims,official_bounds=True,local_profile_photo_interpreted=True,closed_solids=self.solids,mesh_count=len(meshes),triangles=sum(q['triangles']for q in qa),meshes=qa,photographed_features=features,affine_fit_scale=scale.tolist())

def mirror_oct():
    b=Builder();outer=octagon(.36,cy=.36);inner=circle(.211,cy=.36)
    b.ring('wide-eight-sided-mango-surround','wood',[(outer*.999,-.009),(outer,.006),(outer*.997,.010),(inner*1.012,.010),(inner,.007),(inner,-.009)])
    b.groups[('wide-eight-sided-mango-surround','wood')]['_flat_normals']=True
    b.slab('silvered-circular-mirror','mirror',circle(.212,cy=.36),-.003,.007,.0004)
    b.slab('MDF-rear-circular-support','back',octagon(.352,cy=.36),-.010,-.008,.0003)
    for x in [-.12,.12]:b.ring('rear-hanging-eyelets','steel',[(circle(.006,32,cy=.51)+[x,0],-.01),(circle(.006,32,cy=.51)+[x,0],-.008),(circle(.0028,32,cy=.51)+[x,0],-.008),(circle(.0028,32,cy=.51)+[x,0],-.01)])
    return b.finish([.72,.72,.02],['Very broad eight-sided dark mango wood surround','Truly circular recessed reflecting opening, approximately59% of outsidewidth','Shallow bevels and solid MDF back with hanging eyelets'])

def scroll(b,sign,x,y,scale=1):
    # Photograph-specific paired acanthus stem and curling side shoots.
    for k,(dy,reach)in enumerate([(0,.045),(.042,.043),(.083,.034),(.125,.026),(.167,.020)]):
        pts=[]
        for t in np.linspace(0,1,50):
            xx=x+sign*(reach*(math.sin(t*math.pi*.9))+.010*math.sin(t*math.tau)*t)
            yy=y+dy+.045*t-.020*math.sin(t*math.pi)
            pts.append((xx,yy,.009+.002*math.sin(t*math.pi)))
        b.tube('carved-acanthus-curl-relief','gold',pts,lambda t:.004*(.35+.65*math.sin(math.pi*(.1+.85*t))),12)
        # Broad pointed acanthus leaf blades flank each carved curling stem.
        for side in [-1,1]:
            leaf=[]
            for t in np.linspace(0,1,25):
                leaf.append((x+sign*(reach*.38+.029*t+side*.008*math.sin(t*math.pi)),y+dy+.012+.035*t,.009+.001*math.sin(t*math.pi)))
            b.tube('solid-pointed-acanthus-leaf-blades','gold',leaf,lambda t:.00035+.0082*math.sin(t*math.pi)**.8,12,flatten=.25)
    pts=[(x+sign*.006*math.sin(t*3),y+t*.215,.008)for t in np.linspace(0,1,70)]
    b.tube('carved-side-leaf-stems','gold',pts,.0036,12)

def mirror_gold():
    b=Builder();outer=arch(.464,.694,cy=.347);inner=arch(.420,.651,cy=.348)
    # Repeated convex moulding, narrow inner bead, and dark recess are geometric.
    mix=lambda t:outer*(1-t)+inner*t
    b.ring('stepped-gilt-arched-moulding','gold',[(outer,-.009),(outer,.003),(mix(.12),.009),(mix(.35),.010),(mix(.48),.006),(mix(.62),.009),(mix(.83),.008),(inner,.004),(inner,-.009)])
    b.slab('arch-silvered-mirror','mirror',inner,-.004,.0035,.0003)
    b.slab('MDF-rear-panel','back',arch(.45,.68,cy=.347),-.010,-.008,.0005)
    for sign in [-1,1]:
        scroll(b,sign,sign*.226,.024)
        # Volute at the lower plinth; curl is open geometry, not a disk ornament.
        pts=[]
        for t in np.linspace(0,math.tau*1.15,90):
            rad=.026*(1-t/(math.tau*1.35));pts.append((sign*(.252+rad*math.cos(t)),.036+rad*math.sin(t),.009))
        b.tube('lower-scroll-volutes','gold',pts,.0038,12)
        b.slab('gilt-bottom-acanthus-plinth','gold',rounded(.105,.020,.007,96,cy=.011)+[sign*.238,0],-.008,.010,.001)
        # Paired crown scrollwork follows the photograph's top crest.
        pts=[]
        for t in np.linspace(0,1,70):pts.append((sign*(.024+.115*t),.713+.022*math.sin(t*math.pi)-.009*t,.009))
        b.tube('crown-acanthus-main-scrolls','gold',pts,.0045,12)
        for k in range(4):
            pts=[(sign*(.05+k*.023+.017*math.sin(t*math.pi)),.718-.024*t+.003*k,.010)for t in np.linspace(0,1,24)]
            b.tube('crown-carved-leaf-ribs','gold',pts,lambda t:.0004+.006*math.sin(t*math.pi),12,flatten=.32)
    # A real fanned shell silhouette, centred above the shallow arch.
    for a in np.linspace(-1,1,9):
        pts=[(.034*a*t,.700+.049*t*(1-.20*abs(a)),.009+.003*math.sin(t*math.pi))for t in np.linspace(.05,1,25)]
        b.tube('crown-scallop-shell-radial-ribs','gold',pts,lambda t:.0026+.0008*math.sin(t*math.pi),12)
    return b.finish([.58,.75,.021],['Shallow arched mirror with straight lower rail','Antique gold double convex moulding with inner bevel','Centred nine-rib shell crest and paired curled acanthus leaves','Raised branching side acanthus and open lower volutes','Photograph ornament curls reconstructed locally; no reflectedphoto baked'])

def frame(w,h,d,kind='wave',color='red'):
    b=Builder();cy=h/2
    if kind=='wave':
        outer=rounded(w-.003,h-.003,.014,320,cy=cy,wave=.0026,waves=(3,4));inner=rounded(w-.027,h-.027,.011,320,cy=cy,wave=.0028,waves=(3,4));mix=lambda t:outer*(1-t)+inner*t
        profiles=[(outer,-d*.38),(outer,d*.08),(mix(.10),d*.30),(mix(.25),d*.40),(mix(.40),d*.28),(mix(.55),d*.23),(mix(.66),d*.35),(mix(.81),d*.29),(inner,d*.12),(inner,-d*.38)]
        b.ring('wavy-lacquered-double-ogee-MDF-moulding','red',profiles);paper=inner*.999;mat='red'
        feats=['Four flowing waved sides with3 horizontal and4 vertical scallops','Glossy burgundy-red lacquered MDF, double-ogee carved profile','Real inset glass and unprinted neutral replaceable paper','Black hinged easel stored folded within official depth']
    else:
        outer=rounded(w,h,.0055,256,cy=cy);inner=rounded(w-.020,h-.020,.0018,256,cy=cy);mix=lambda t:outer*(1-t)+inner*t
        b.ring('polished-silver-rounded-rectangle-frame','silver',[(outer,-d*.34),(outer,d*.20),(mix(.10),d*.48),(mix(.35),d*.50),(mix(.80),d*.46),(inner,d*.16),(inner,-d*.34)]);paper=inner*.999;mat='silver'
        feats=['Slim10 mm polished silver metal surround','Small rounded outer corners and tighter inner corners','Convex rolled outer edge and fine recessed inner return','Real inset glass and neutral replaceable paper; folded black easel']
    b.slab('replaceable-unprinted-photo-insert','paper',paper,-d*.10,d*.09,.0001)
    b.slab('clear-front-glazing','glass',paper*.998,d*.10,d*.13,.00008)
    b.slab('black-MDF-rear-backing','back',rounded(w-.020,h-.020,.004,160,cy=cy),-d*.45,-d*.36,.0002)
    # Folded easel pose preserves the official packeddepth rather than inventing
    # an undocumented openstand footprint. Hinge and hanging tabs are separate.
    stand=rounded(w*.36,h*.64,.0025,96,cy=h*.40)
    b.slab('folded-black-easel-stand','back',stand,-d*.50,-d*.46,.00015)
    for x in [-w*.28,w*.28]:b.slab('rear-rotating-photo-retainers','steel',rounded(.008,.014,.0015,32,cy=h*.58)+[x,0],-d*.47,-d*.43,.0001)
    b.slab('easel-upper-hinge','steel',rounded(w*.20,.004,.001,32,cy=h*.71),-d*.49,-d*.45,.0001)
    return b.finish([w,h,d],feats)

def materials(out):
    n=2048;v=np.linspace(0,1,n,dtype=np.float32);x=np.broadcast_to(v[None,:],(n,n));y=np.broadcast_to(v[:,None],(n,n));cloud=noise._object_noise(x,y,814,5);fine=noise._object_noise(x,y,815,160)
    grain=np.sin(math.tau*(x*52+np.sin(y*9)*.9+noise._object_noise(x,y,816,14)*.4))
    defs={'wood':([65,35,20],.42,0,10),'gold':([148,101,39],.38,1,7),'silver':([225,225,220],.095,1,.6),'red':([113,11,21],.19,0,1.7),'back':([30,28,25],.82,0,2),'paper':([236,233,222],.86,0,1),'steel':([110,111,109],.29,1,.5),'mirror':([239,244,242],.025,1,0),'glass':([255,255,255],.035,0,0)}
    mats={};maps={}
    for name,(col,rough,metal,strength)in defs.items():
        detail=grain*.13+cloud*.95+fine*.10 if name=='wood'else cloud*.8+fine*.15
        color=np.array(col,np.float32)+detail[:,:,None]*strength;Image.fromarray(np.clip(np.rint(color),0,255).astype(np.uint8),'RGB').save(out/(name+'-albedo-2k.png'),optimize=True)
        height=(grain*.035+fine*.005)if name=='wood'else fine*.0008;dx=np.gradient(height,axis=1);dy=np.gradient(height,axis=0);nn=np.stack([-dx*1.5,-dy*1.5,np.ones_like(dx)],2);nn/=np.linalg.norm(nn,axis=2,keepdims=True)
        Image.fromarray(np.rint((nn+1)*127.5).astype(np.uint8),'RGB').save(out/(name+'-normal-2k.png'),optimize=True)
        orm=np.zeros((n,n,3),np.uint8);orm[:,:,0]=255;orm[:,:,1]=np.rint(np.clip(rough+(cloud*.018+fine*.004)*(strength>0),.01,.99)*255);orm[:,:,2]=255 if metal else 0
        Image.fromarray(orm,'RGB').save(out/(name+'-orm-2k.png'),optimize=True)
        m=dict(baseColorFactor=[1,1,1,1],metallic=1,roughness=1,baseColorTexture=name+'-albedo-2k.png',normalTexture=name+'-normal-2k.png',metallicRoughnessTexture=name+'-orm-2k.png',normalScale=.30 if name=='wood'else .12,alphaMode='OPAQUE',doubleSided=False,extras=dict(native_resolution=2048,photo_pixels_baked=False,baked_reflections=False,intrinsic_material=True))
        if name=='red':m.update(clearcoat=.65,clearcoatRoughness=.12)
        if name=='glass':m.update(baseColorFactor=[1,1,1,.11],alphaMode='BLEND',transmission=.98,ior=1.5,thickness=.0003)
        mats[name]=m
    for p in out.glob('*-2k.png'):maps[p.name]=dict(bytes=p.stat().st_size,sha256=sha(p),dimensions=[n,n],mode='RGB')
    dump(out/'material-validation.json',dict(valid=True,native_resolution=2048,intrinsic_material=True,photo_pixels_baked=False,baked_reflections=False,maps=maps))
    return mats

def make_specs():
    mirrors=json.loads((R.parent/'inventory/mirrors-products.json').read_text());red=json.loads((R/'frame-red-raw.json').read_text());roundr=json.loads((R/'frame-round-raw.json').read_text())
    products=[(mirrors[0],mirror_oct,'6180-106-700-h72-w72-d2',[72,2,72],'Mango ahşap / ayna camı / MDF'),(mirrors[1],mirror_gold,'2377-106-303-h75-w58-d2p1',[75,58,2.1],'Antik altın kaplamalı MDF / ayna camı')]
    red.update(official_url=red['url'],sku='46309045600',panel='50% MDF levha, 40% cam, 10% kâgit',category='frames');roundr.update(official_url=roundr['url'],sku='48029045808',category='frames')
    products.extend([(red,lambda:frame(.18,.23,.018),'6309-045-600-h23-w18-d1p8',[23,18,1.8],'Bordo kırmızı parlak lake MDF / cam'),(roundr,lambda:frame(.12,.17,.01,'round'),'8029-045-808-h17-w12-d1',[17,12,1],'Parlak gümüş demir / MDF / cam')])
    return products

def main():
    manifest=[];only=sys.argv[1]if len(sys.argv)>1 else None
    if only and (R/'manifest.json').exists():manifest=[e for e in json.loads((R/'manifest.json').read_text())if e['id']!=only]
    for p,make,id,hwd,label in make_specs():
        if only and id!=only:continue
        out=R/'models'/id;out.mkdir(parents=True,exist_ok=True);meshes,gqa=make();used={m['material']for m in meshes};mats={k:v for k,v in materials(out).items()if k in used};dims=[round(v*100,6)for v in gqa['dimensions_metres']]
        images=[]
        for im in p['images']:
            if not any(im['url']==q['url']for q in images)and any('w='+str(w)in im['url']for w in [768,1024]):images.append(im)
        cat='Fotoğraf çerçeveleri'if p.get('category')=='frames'else 'Dekoratif aynalar'
        scale_note='Resmi Türkiye dış ölçüleri kullanılmıştır; profil, yerel süsler ve görünmeyen arka yapı fotoğraflardan yorumlanmıştır.'
        if hwd==[72,2,72]:scale_note+=' Resmi H/W/D 72/2/72 cm bilgisi korunur; fiziksel ön yüz 72×72 cm ve kalınlık2 cm olarak Y-up modele yerleştirilmiştir.'
        if cat=='Fotoğraf çerçeveleri':scale_note+=' Resmi kalınlık sınırı için destek ayağı kapalı pozdadır; değiştirilebilir fotoğraf alanı nötr, baskısız bırakılmıştır.'
        metadata=dict(id=id,name=p['title'].capitalize(),sku='/'.join(id.split('-')[:3]),url=p['official_url'],category=cat,dimensions_cm=dims,source_dimensions_hwd_cm=hwd,estimated_dimensions=False,source_market='Türkiye',size_source_kind='tr_live_product',size_source_urls=[p['official_url']],scale_note=scale_note,units='metres',up_axis='Y',origin='bottom bounding-box centre',source_images=images,official_materials_verbatim=p.get('panel',''),photo_pixels_baked=False,baked_reflections=False)
        model=out/'model.json';dump(model,dict(metadata=metadata,materials=mats,meshes=meshes));dump(out/'geometry-validation.json',gqa);report=export_assets(model,out,id);glb=out/(id+'.glb');e={k:metadata[k]for k in ['id','name','sku','url','category','dimensions_cm','source_dimensions_hwd_cm','estimated_dimensions','source_market','size_source_kind','size_source_urls','scale_note']};e.update(model_path=str(model),asset_dir=str(out),glb_path=str(glb),sha256=sha(glb),bytes=glb.stat().st_size,material_label=label,source_images=images,geometry_validation=str(out/'geometry-validation.json'),material_validation=str(out/'material-validation.json'),model_revision='photo-specific-mirrors-frames-v1',source_anomalies=[]);manifest.append(e);dump(R/'manifest.json',manifest);print(id,e['bytes'],gqa['triangles'],flush=True)
    dump(R/'qa-summary.json',dict(valid=True,count=len(manifest),all_dimensions_live_tr=True,all_maps_native_2k=True,photo_pixels_baked=False,baked_reflections=False))
if __name__=='__main__':main()
