"""Correct reference aliases without changing frozen source assets or binary geometry.

Zara's galleries sometimes mix legacy reference codes. Retain only an actually
observed current-code photo, preserve the immutable originals, and issue new
metadata-only GLBs with byte-identical BIN chunks and all material extensions.
"""
from pathlib import Path
import copy, hashlib, json, re, shutil, sys
P=Path(__file__).resolve().parent
sys.path.insert(0,str(P.parents[1]))
sys.path.insert(0,str(P.parents[1]/'objects'))
from export_catalog import read_glb,write_glb
from audit_geometry import check

def dump(p,o):p.write_text(json.dumps(o,ensure_ascii=False,indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def title(s):
    s=s.translate(str.maketrans({'I':'ı','İ':'i'})).lower()
    return {'i':'İ','ı':'I'}.get(s[0],s[0].upper())+s[1:]
def code(im):
    m=re.search(r'/(\d{11})-[a-z]\d',im['url'])
    return m.group(1)if m else None

def main():
    if (P/'manifest-frames-all91-frozen.json').exists():raise SystemExit('This source revision is frozen. Preserve these assets and use a new revision directory.')
    entries=[]
    for f in ['manifest-batch1-frozen.json','manifest-batch2-frozen.json','manifest-batch3.json']:
        entries.extend(e for e in json.loads((P/f).read_text())if e['category']=='Fotoğraf çerçeveleri')
    old={e['id']:copy.deepcopy(e)for e in entries}
    for filename in ['manifest-frame-geometry-v3.json','manifest-pear-mat-geometry-v4.json']:
        geometry=P/filename
        if geometry.exists():
            replacement={e['id']:e for e in json.loads(geometry.read_text())}
            entries=[copy.deepcopy(replacement.get(e['id'],e))for e in entries]
    gold={e['id']:e for e in json.loads((P/'manifest-gold-frame-source-v2-frozen.json').read_text())}
    entries=[copy.deepcopy(gold.get(e['id'],e))for e in entries]
    records=json.loads((P/'frames-products-unique.json').read_text())
    double=json.loads((P/'double-frame-correct-source.json').read_text())
    finalrecords=[]
    for r in records:
        r=copy.deepcopy(r)
        if '-l44368045?'in r['url']:
            r['images']=double['images'];r['local_originals']=double['local_originals'];r['sku']=double['sku']
        expected=re.search(r'-l(\d+)',r['url']).group(1)
        colors={e['sku'].split('/')[-1]for e in entries if e['url']==r['url']}
        if '-l44368045?'in r['url']:colors={'990'}
        assert len(colors)==1,(r['url'],colors)
        current=expected+next(iter(colors))
        kept=[im for im in r['images']if code(im)==current and int(re.search(r'[?&]w=(\d+)',im['url']).group(1))>=512]
        assert kept,(r['url'],r['images'])
        removed=[im for im in r['images']if im not in kept]
        r['images']=kept
        r['source_image_filter_note']='Only actually observed gallery photographs matching the current page reference code are retained. Legacy gallery aliases are excluded.'
        if removed:r['excluded_legacy_gallery_images']=removed
        if r.get('local_originals'):
            tokens={re.search(r'/(\d{11}-[a-z]\d)',im['url']).group(1)for im in kept}
            r['local_originals']=[x for x in r['local_originals']if any(t in x for t in tokens)]
        finalrecords.append(r)
    byurl={r['url']:r for r in finalrecords}
    final=[];revisions=[];checks=[];deletions=[]
    for e in entries:
        baseline=old[e['id']];e=copy.deepcopy(e);r=byurl[e['url']]
        desired=copy.deepcopy(e)
        desired['source_images']=r['images'];desired['name']=title(r['title'])
        if e['id'].startswith('4368-045-303-'):
            desired['id']=e['id'].replace('4368-045-303-','4368-045-990-')
            desired['sku']='4368/045/990';deletions.append(e['id'])
        # Also include the four pre-existing gold-source revisions in the single
        # final override manifest so the parent needs only one authoritative set.
        changed=any(desired.get(k)!=e.get(k)for k in ['source_images','name','sku','id'])
        if not changed:
            if e['id']in gold:revisions.append(e)
            final.append(e);continue
        src=Path(e['asset_dir']);out=P/'revisions'/'frame-source-final-v2'/desired['id']
        if out.exists():shutil.rmtree(out)
        shutil.copytree(src,out)
        model=json.loads((out/'model.json').read_text());meta=model['metadata']
        for k in ['source_images','name','sku','id']:meta[k]=desired[k]
        meta['source_image_filter_note']=r['source_image_filter_note']
        if desired['id']!=e['id']:
            meta['source_reference_correction']='The current official gallery confirms SKU 4368/045/990; the earlier 303 metadata code is superseded. Geometry is unchanged.'
        dump(out/'model.json',model)
        doc,binary=read_glb(e['glb_path']);doc['extras']['metadata']=meta
        glb=out/(desired['id']+'.glb');write_glb(glb,doc,binary)
        checkdoc,checkbin=read_glb(glb);assert checkbin==binary
        # Keep exported OBJ and original validation names as audit provenance;
        # the GLB, model.json and manifest identify the corrected current SKU.
        desired.update(model_path=str(out/'model.json'),asset_dir=str(out),glb_path=str(glb),sha256=sha(glb),bytes=glb.stat().st_size,geometry_validation=str(out/'geometry-validation.json'),material_validation=str(out/'material-validation.json'),supersedes_sha256=baseline['sha256'],source_revision='observed-current-reference-code-v2')
        if desired['id']!=e['id']:desired['supersedes_id']=e['id']
        for f in out.glob('*.validation.json'):
            v=json.loads(f.read_text());v['deliverable_sha256']['glb']=desired['sha256'];v['glb_bytes']=desired['bytes'];v['metadata_only_revision']=True;dump(f,v)
        q=check(desired);q['binary_geometry_and_textures_identical_to_previous']=True
        q['binary_comparison_sha256']=e['sha256'];q['binary_comparison_glb_path']=e['glb_path']
        checks.append(q);revisions.append(desired);final.append(desired)
        print(desired['id'], 'metadata only',flush=True)
    assert len(final)==91 and len({e['id']for e in final})==91
    for e in final:
        expected=re.search(r'-l(\d+)',e['url']).group(1)
        assert e['source_images'] and all(code(im).startswith(expected)for im in e['source_images'])
        assert all(code(im).endswith(e['sku'].split('/')[-1])for im in e['source_images']),(e['id'],e['source_images'])
    dump(P/'frames-products-final-source-v2.json',finalrecords)
    dump(P/'manifest-frames-all91-pending-qa.json',final)
    dump(P/'manifest-frame-source-overrides-final-v2.json',revisions)
    dump(P/'frame-source-final-v2-audit.json',dict(valid=True,frames=91,live_cards=41,metadata_revisions=len(revisions),remove_superseded_ids=deletions,unchanged_binary_chunks=True,comparison_note='Metadata-only source revisions preserve the immediately preceding geometry version. The three separately audited silver stepped-frame geometry v3 revisions are listed in manifest-frame-geometry-v3.json.',checks=checks))
    print('TOTAL',len(final),'overrides',len(revisions),'remove',deletions)

if __name__=='__main__':main()
