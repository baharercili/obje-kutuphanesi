"""Index verified native views and compose disposable reference/preview boards."""
import hashlib,json,re
from pathlib import Path
from PIL import Image,ImageOps,ImageDraw,ImageFont
P=Path(__file__).resolve().parent
final=P/'manifest-frames-all91-frozen.json'
if not final.exists():final=P/'manifest-frames-all91-pending-qa.json'
entries=json.loads(final.read_text());records={r['url']:r for r in json.loads((P/'frames-products-final-source-v2.json').read_text())}
report=[];families={}
for e in entries:
    imgs=[]
    for name in ['on-capraz.png','ustten.png']:
        f=Path(e['asset_dir'])/name
        assert f.exists()and f.stat().st_size>1000,(e['id'],name)
        im=Image.open(f);assert min(im.size)>=600,(e['id'],im.size)
        imgs.append(dict(path=str(f),dimensions=list(im.size),sha256=hashlib.sha256(f.read_bytes()).hexdigest()))
    report.append(dict(id=e['id'],render_images=imgs))
    if e['sku']in families:continue
    r=records[e['url']];code=re.search(r'/(\d{11})-[a-z]\d',e['source_images'][0]['url']).group(1)
    masters=list(r.get('local_originals',[]))or[str(x)for x in P.glob(code+'-*-master.webp')]
    assert masters,e['sku']
    families[e['sku']]=dict(sku=e['sku'],title=e['name'],original_master_paths=masters,model_front=imgs[0]['path'],model_top=imgs[1]['path'],model_path=e['model_path'],url=e['url'])
(P/'frame-native-preview-coverage.json').write_text(json.dumps(dict(valid=True,models=91,views=182,checks=report),ensure_ascii=False,indent=2)+'\n')
items=list(families.values());(P/'visual-qa-items-final41.json').write_text(json.dumps(items,ensure_ascii=False,indent=2)+'\n')
font=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',17)
for page in range(6):
    group=items[page*7:(page+1)*7];canvas=Image.new('RGB',(800,len(group)*245),(242,240,235));draw=ImageDraw.Draw(canvas)
    for i,r in enumerate(group):
        masters=r['original_master_paths'];original=next((x for x in masters if '-p1-'in x),masters[0])
        for j,path in enumerate([original,r['model_front'],r['model_top']]):
            im=Image.open(path).convert('RGBA');bg=Image.new('RGBA',im.size,(242,240,235,255));bg.alpha_composite(im);im=ImageOps.contain(bg.convert('RGB'),(245,210));canvas.paste(im,(j*260+(250-im.width)//2,i*245+30+(210-im.height)//2))
        draw.text((10,i*245+4),r['sku']+' '+r['title'],font=font,fill=(30,30,30))
    canvas.save(P/('frame-final-source-native-contact-'+str(page)+'.png'))
print('91 native preview pairs, 41 correct-source comparisons, 6 overview pages')
