"""Three observed planter families, six actual TR sizes; intrinsic 2K metal PBR."""
from pathlib import Path
import sys,json,math,hashlib,importlib.util,shutil
import numpy as np
from PIL import Image
R=Path(__file__).resolve().parent;WORK=R.parents[1]
sys.path.insert(0,str(WORK));sys.path.insert(0,str(WORK/'bowls-trays/models-build'));sys.path.insert(0,str(WORK/'candles/ceramic-stone'))
from export_catalog import export_assets,read_glb,write_glb
from vase_geometry import _assembly_result,_signed_volume
from bowls_geometry import raw_lathe
from candle_geometry import tube_path
sp=importlib.util.spec_from_file_location('_planter_noise',WORK/'bowls-trays/tray-build/tray_materials.py');noise=importlib.util.module_from_spec(sp);sp.loader.exec_module(noise)
def dump(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def fmt(v):return f'{v:g}'.replace('.','p')
def ring(name,mat,r,y,rad):
 return tube_path(name,mat,[(r*math.cos(math.tau*i/256),y,r*math.sin(math.tau*i/256))for i in range(256)],rad,True,n=16)
def geometry(e,h,w,d):
 r=w/2;parts=[];sku=e['sku'];features=[]
 if sku=='40374043728':
  mat='antique';base=.009;bh=h-base;br=r*.973
  # The fluted pressed body has rounded lower corners, a broad plain rolled
  # neck band and a real corrugated inside. Saucer remains a separate basin.
  profile=[(0,.005),(.60,.005),(.77,.013),(.85,.035),(.92,.085),(.968,.16),(.989,.28),(1,.52),(1,.83),(.999,.928),(1,.936),(1,.99),(.999,1),(.987,1),(.985,.992),(.985,.936),(.983,.927),(.984,.83),(.984,.52),(.974,.28),(.953,.16),(.90,.085),(.83,.043),(.73,.025),(.58,.021),(0,.021)]
  body=raw_lathe('corrugated-iron-body-with-open-interior',mat,profile,br,bh,base,n=768)
  vv=[]
  for x,y,z in body['_vertices']:
   rr=math.hypot(x,z);a=math.atan2(z,x);yn=(y-base)/bh
   amp=.00155*max(0,min(1,(yn-.015)/.07))*max(0,min(1,(.932-yn)/.014)) if rr>br*.55 else 0
   rr2=rr+amp*math.cos(88*a)
   vv.append((x*rr2/rr,y,z*rr2/rr)if rr>1e-9 else(x,y,z))
  body['_vertices']=vv;parts.append(body)
  saucer=[(0,0),(.83,0),(.94,.05),(.985,.20),(1,.48),(1,.88),(.993,1),(.975,1),(.966,.84),(.954,.43),(.91,.24),(.81,.22),(0,.22)]
  parts.append(raw_lathe('separate-shallow-metal-saucer',mat,saucer,r,.011,n=512))
  features=['88 real longitudinal corrugations continuing inside the open planter','Rounded lower body on its own shallow matching saucer','Wide plain neck band and thin continuous rolled rim','No plant, soil, room, reflections or product-photo pixels included']
 else:
  gold=sku=='43309748303';mat='gold'if gold else'black';rod=.0023 if w<.25 else .00265
  br=r-(rod*2.5 if gold else .0030);top=h;bodyh=(.175 if h<.45 else .215)if gold else(.190 if h<.5 else .207);bottom=top-bodyh
  thickness=.0011 if gold else .00135
  profile=[(0,0),(.70,0),(.82,.018),(.91,.052),(.966,.12),(.990,.20),(1,.30),(1,.985),(.998,1),(1-thickness/br,1),(1-thickness/br,.985),(1-thickness/br,.30),(.980,.205),(.953,.135),(.892,.073),(.80,.042),(.68,.034),(0,.034)]
  parts.append(raw_lathe('removable-open-rounded-bottom-metal-cup',mat,profile,br,bodyh,bottom,n=512))
  standr=r-rod;ground=rod;upper=top-(bodyh*.28 if gold else .0030)
  parts.extend([ring('continuous-round-floor-ring',mat,standr,ground,rod),ring('upper-support-collar',mat,standr,upper,rod)])
  for i in range(3):
   a=math.tau*i/3+math.pi/2
   parts.append(tube_path(f'three-leg-upright-{i+1}',mat,[(standr*math.cos(a),yy,standr*math.sin(a))for yy in np.linspace(ground,upper,7)],rod,n=20))
   # Inward welded support tabs beneath the removable inner vessel.
   parts.append(tube_path(f'inner-vessel-support-tab-{i+1}',mat,[(rr*math.cos(a),bottom+.006,rr*math.sin(a))for rr in np.linspace(standr,br*.69,8)],rod*.88,n=16))
  features=['Three narrow actual uprights welded to a continuous circular floor ring','Separate thin-walled removable cylindrical cup with softly rounded bottom','Real open cup interior and visible clear space below it','Upper external support collar '+('below the rim'if gold else'at the rim'),'Different photographed bowl-to-stand proportions retained for each official size','No plant or styled scene included']
 return _assembly_result(dict(id=sku,dimensions_cm=[w*100,h*100,d*100]),parts,'Official planter silhouette, separate hollow cup, collar and supporting structure',dict(overall_dimensions_official=True,local_details_photo_inferred=True,photographed_features=features))

def materials(out,kind):
 n=2048;u=np.linspace(0,1,n,dtype=np.float32);x=np.broadcast_to(u[None,:],(n,n));y=np.broadcast_to(u[:,None],(n,n));seed={'antique':374,'black':1311,'gold':3309}[kind]
 cloud=noise._object_noise(x,y,seed,11.0);grain=noise._object_noise(x,y,seed+1,290.);pore=noise._object_noise(x,y,seed+2,630.);brush=np.sin(y*math.tau*710+noise._object_noise(x,y,seed+3,31)*.6)
 if kind=='antique':
  oxidation=np.clip((-cloud-.12)*1.2,0,.78);c=np.array([77,64,51],np.float32)+cloud[:,:,None]*np.array([17,15,11])-oxidation[:,:,None]*np.array([24,20,14])+grain[:,:,None]*1.25
  rough=np.clip(.57+cloud*.065+oxidation*.17+grain*.017,.44,.81);metal=np.clip(.92-oxidation*.75,.3,.96);bump=grain*.13+pore*.05
 elif kind=='black':
  c=np.array([25,26,25],np.float32)+cloud[:,:,None]*.8+grain[:,:,None]*.35;rough=np.clip(.59+grain*.021+pore*.01,.50,.68);metal=np.zeros_like(x);bump=grain*.055+pore*.03
 else:
  c=np.array([177,137,69],np.float32)+cloud[:,:,None]*np.array([4.2,3.3,2.5])+grain[:,:,None]*.28+brush[:,:,None]*.12;rough=np.clip(.31+cloud*.013+brush*.012+grain*.005,.25,.38);metal=np.ones_like(x);bump=brush*.022+grain*.015
 dx=np.gradient(bump,axis=1);dy=np.gradient(bump,axis=0);nn=np.stack([-dx,-dy,np.ones_like(dx)],2);nn/=np.linalg.norm(nn,axis=2,keepdims=True);orm=np.stack([np.ones_like(x),rough,metal],2)
 maps={f'{kind}-albedo-2k.png':np.clip(np.rint(c),0,255).astype(np.uint8),f'{kind}-normal-2k.png':np.rint((nn+1)*127.5).astype(np.uint8),f'{kind}-orm-2k.png':np.rint(orm*255).astype(np.uint8)}
 for name,a in maps.items():Image.fromarray(a,'RGB').save(out/name,optimize=True)
 dump(out/'material-validation.json',dict(valid=True,native_resolution=n,photo_pixels_baked=False,baked_reflections=False,roughness_range=[float(rough.min()),float(rough.max())],maps={name:dict(bytes=(out/name).stat().st_size,sha256=sha(out/name),dimensions=[n,n],mode='RGB')for name in maps}))
 return {kind:dict(baseColorFactor=[1,1,1,1],metallic=1,roughness=1,baseColorTexture=f'{kind}-albedo-2k.png',normalTexture=f'{kind}-normal-2k.png',metallicRoughnessTexture=f'{kind}-orm-2k.png',normalScale=.3,alphaMode='OPAQUE',doubleSided=False,extras=dict(native_resolution=n,photo_pixels_baked=False,baked_reflections=False))}

def main():
 research=json.loads((R.parent/'inventory/planters-products.json').read_text());entries=[]
 size_map={'40374043728':[(46,37,37),(50.5,44,44)],'41311748800':[(45.5,21.5,21.5),(60,31,31)],'43309748303':[(40,20,20),(50,30,30)]}
 names={'40374043728':'Yivli antika metal saksı ve altlık','41311748800':'Siyah metal ayaklı saksı','43309748303':'Altın rengi metal ayaklı saksı'}
 kinds={'40374043728':'antique','41311748800':'black','43309748303':'gold'}
 for p in research:
  sku=p['sku']
  if sku not in size_map:continue
  images=json.loads((R/'0374-gallery.json').read_text())if sku=='40374043728'and(R/'0374-gallery.json').exists()else p['images']
  for h,w,d in size_map[sku]:
   short=sku[1:];code=short[:4]+'/'+short[4:7]+'/'+short[7:];id=code.replace('/','-')+'-h'+fmt(h)+'-w'+fmt(w)+'-d'+fmt(d);out=R/'models'/id;out.mkdir(parents=True,exist_ok=True)
   meshes,gqa=geometry(p,h/100,w/100,d/100);mats=materials(out,kinds[sku]);meta=dict(id=id,name=names[sku],sku=code,url=p['official_url'],category='Dekoratif saksılar',dimensions_cm=[w,h,d],source_dimensions_hwd_cm=[h,w,d],estimated_dimensions=False,size_source_kind='tr_live_product',size_source_urls=[p['official_url']],source_market='Türkiye',scale_note='Dış ölçüler resmi Türkiye ürün sayfasından; duvar, ayak kesitleri, yivler ve yerel detaylar ürün fotoğraflarından yorumlanmıştır.',units='metres',up_axis='Y',origin='bottom bounding-box centre',source_images=images,photo_pixels_baked=False,baked_reflections=False)
   model=out/'model.json';dump(model,dict(metadata=meta,materials=mats,meshes=meshes));dump(out/'geometry-validation.json',gqa);report=export_assets(model,out,id);glb=out/(id+'.glb');doc,binary=read_glb(glb)
   doc['samplers']=[dict(magFilter=9729,minFilter=9987,wrapS=10497,wrapT=10497)]
   for t in doc.get('textures',[]):t['sampler']=0
   write_glb(glb,doc,binary);digest=sha(glb);report['deliverable_sha256']['glb']=digest;report['glb_bytes']=glb.stat().st_size;dump(report['files']['validation'],report)
   e={k:v for k,v in meta.items()if k not in ('units','up_axis','origin','photo_pixels_baked','baked_reflections')};e.update(model_path=str(model),asset_dir=str(out),glb_path=str(glb),sha256=digest,bytes=glb.stat().st_size,material_label={'antique':'Eskitme demir · Taba','black':'Mat boyalı demir · Siyah','gold':'Çelik ve demir · Altın rengi'}[kinds[sku]],geometry_validation=str(out/'geometry-validation.json'),material_validation=str(out/'material-validation.json'),model_revision='planters-photo-v1');entries.append(e);dump(R/'manifest.json',entries);print(id,e['bytes'],gqa['triangles'],flush=True)
 dump(R/'qa-summary.json',dict(valid=True,models=len(entries),families=3,all_official_sizes=True,native_2k_materials=True,photos_immutable=True))
if __name__=='__main__':main()
