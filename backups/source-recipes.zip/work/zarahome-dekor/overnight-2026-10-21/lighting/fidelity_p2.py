"""Separate photo-fidelity revisions; frozen earlier deliverables remain immutable."""
import expand_lighting as e
b=e.b
import numpy as np, math, json
from PIL import Image
T=math.tau

def smooth_path(points,n=14):
 a=np.asarray(points,float);out=[]
 for k in range(len(a)-1):
  p0=a[max(0,k-1)];p1=a[k];p2=a[k+1];p3=a[min(len(a)-1,k+2)]
  for t in np.linspace(0,1,n,endpoint=False):out.append(.5*((2*p1)+(-p0+p2)*t+(2*p0-5*p1+4*p2-p3)*t*t+(-p0+3*p1-3*p2+p3)*t*t*t))
 out.append(a[-1]);return out

def brown_linen_floor():
 p,features=e.floor_metal()
 for q in p:
  if q['name']=='tapered-cone-metal-foot':q['material']='matteblack'
  if q['material']=='linen':q['material']='coffeelinen'
 p.append(b.cylinder('real-upper-lampholder-sleeve','matteblack',.0105,1.175,1.270))
 pts=smooth_path([(0,.06,-.065),(-.025,.018,-.110),(-.055,.003,-.145),(-.110,.003,-.160),(-.155,.003,-.170)])
 p.append(b.tube('curved-floor-power-flex','cable',pts,.0018,.0018,8,False,guide=[0,1,0]))
 p.append(b.cylinder('floor-switch-round-off-button','matteblack',.016,.001,.009,offset=(-.110,0,-.16),n=96))
 return p,['Coffee-brown linen drum and matte-black tapered weighted foot matched to official photo','Upper socket sleeve and curved floor cable with round foot switch','Room-length cable continuation excluded from official fixture bounds']

def continuous_wood_floor():
 p,features=e.floor_wood();p=[q for q in p if not q['name'].startswith('turned-wood-bead')]
 for q in p:
  if q['name']=='central-brass-long-pole':q['material']='brownwood';q['name']='dark-brown-wood-long-upright'
  if q['material']=='wooddark':q['material']='brownwood'
 prof=[(0,.050)]
 for y in np.linspace(.050,.452,449):
  t=(y-.050)/.402;phase=T*8*t
  r=.0140+.0128*(.5-.5*math.cos(phase))**.62+.0015*math.sin(phase*2)**2
  prof.append((r,float(y)))
 prof +=[(0,.452)]
 p.append(b.lathe('continuous-eight-double-turned-wood-balusters','brownwood',prof,160,False))
 return p,['Dark brown wood upright replaces incorrect bright brass pole','One continuous eight-lobed turned profile with narrow connecting rings; no separate spheres','Stepped wood foot, white glass half-dome and two brass pull chains retained']

def knee_tripod_floor():
 p,features=e.floor_tripod();p=[q for q in p if not q['name'].startswith('curved-long-tripod-leg')]
 for q in p:
  if q['material']=='cotton':q['material']='warmcotton'
 radial=smooth_path([(.006,.056),(.048,.063),(.115,.066),(.143,.060),(.161,.023),(.174,.008),(.185,.010)],18)
 for k in range(3):
  a=T*k/3;pts=[(r*math.cos(a),y,r*math.sin(a))for r,y in radial]
  p.append(b.tube('wide-kneed-upturned-tripod-foot-'+str(k),'matteblack',pts,.0058,.0058,14,False,guide=[0,1,0]))
 return p,['Three wider physically connected legs with raised knees and upturned rounded tips','Warm cream cotton cone retains exact60cm source diameter and155cm total height','Curved legs meet the upright at the same hub height']

def rounded_rustic_ceramic():
 p,features=e.ceramic_small();p=[q for q in p if q['name']!='rustic-brown-shouldered-ceramic-base']
 prof=[(0,0),(.050,0),(.056,.004),(.061,.014),(.066,.039),(.073,.073),(.080,.112),(.080,.139),(.075,.160),(.064,.178),(.044,.190),(.030,.194),(.030,.201),(.039,.202),(.038,.207),(0,.207)]
 p.append(b.lathe('rounded-shoulder-aged-rustic-ceramic-body','agedceramic',e.curved_profile(prof,14),192,False))
 return p,['Full rounded ceramic shoulder, narrow neck and projecting upper lip matched from original','Intrinsic irregular red-brown wear, pale mineral patches and pores; no baked lighting','Wide cream linen cone and real black neck/cable preserved']

def natural_wood_table():
 p,features=b.glass_wood()
 for q in p:
  if q['material']=='wood':q['material']='naturalwood'
 return p,['Turned foot and slender stem retain exact official20.25cm exterior','Natural billet growth rings and axial fibres mapped through true lathe profile','Vanilla opal shell remains unlit and physically thick; natural wood no photo pixels']

def irregular_flower():
 p,features=b.flower()
 for q in p:
  if q['material']!='paper':continue
  phase=0 if q['name'].startswith('upper')else 1.13
  out=[]
  for x,y,z in q['_vertices']:
   a=math.atan2(z/.887,x);rad=math.hypot(x,z/.887);old=1+.055*math.cos(4*a+(0 if phase==0 else 2.6))+.025*math.sin(7*a+(0 if phase==0 else 2.6));r=rad/old;t=max(0,min(1,(r-.015)/.160))
   edge=1+.110*math.cos(3*a+phase)+.045*math.sin(5*a+.63+phase)+.020*math.cos(2*a+1.4)
   newx=r*math.cos(a)*edge;newz=r*.887*math.sin(a)*edge
   yy=y-.007*t*t*math.cos(4*a+(0 if phase==0 else 2.6))+.013*t*t*math.cos(3*a+phase)+.006*t*t*math.sin(5*a+.63+phase)
   out.append((newx,yy,newz))
  q['_vertices']=out
 return p,['Two offset paper sheets with broad unequal waves and physical radial pleats','Irregular3/5-lobe perimeter replaces small repeated scallops','Official120cm full suspension retained; source photographed bulb excluded explicitly']

b.MATERIALS.update({'matteblack':([26,25,23],.69,0,'metal'),'coffeelinen':([145,120,88],.9,0,'fabric'),'warmcotton':([210,192,159],.89,0,'fabric'),'brownwood':([112,68,44],.36,0,'wood'),'agedceramic':([102,72,57],.72,0,'ceramic'),'naturalwood':([131,83,45],.37,0,'wood')})
orig=b.textures
def field(rng,size,n):
 a=rng.normal(0,1,(size,size)).astype(np.float32);q=np.asarray(Image.fromarray(a,'F').resize((n,n),Image.Resampling.BICUBIC),dtype=np.float32);return q/(q.std()+1e-6)
def textures(out,keys):
 mats=orig(out,keys);n=2048;u=np.arange(n,dtype=np.float32)[None,:]/n;v=np.arange(n,dtype=np.float32)[:,None]/n;rng=np.random.default_rng(63692238)
 for key in keys:
  if key not in['naturalwood','agedceramic','brownwood']:continue
  fine=rng.normal(0,1,(n,n)).astype(np.float32);cloud=field(rng,9,n);grain=field(rng,257,n)
  if key in['naturalwood','brownwood']:
   if key=='naturalwood':
    pr=np.array([(0,0),(.047,0),(.052,.002),(.054,.006),(.054,.011),(.052,.015),(.049,.016),(.051,.019),(.051,.021),(.046,.024),(.032,.025),(.020,.029),(.012,.034),(.008,.042),(.007,.105),(.010,.113),(0,.113)])
    r=np.interp(v[:,0],np.linspace(0,1,len(pr)),pr[:,0])[:,None];yy=np.interp(v[:,0],np.linspace(0,1,len(pr)),pr[:,1])[:,None]
   else:r=np.broadcast_to(.018,(n,1));yy=v*.45
   xx=r*np.cos(T*u);zz=r*np.sin(T*u);dist=np.sqrt((xx+.036+.002*np.sin(yy*41))**2+(zz-.014+.002*np.sin(yy*33))**2)
   growth=dist/.0032+.09*field(rng,22,n);rings=np.sin(T*growth)*.4+np.sin(T*growth*1.91)*.12
   fibre=np.sin(T*(190*u+.08*np.sin(yy*17)+.025*cloud))*.30+grain*.15
   rgb=np.array([131,83,45]if key=='naturalwood'else[112,68,44]);colour=rgb+rings[:,:,None]*np.array([15,10,5])+fibre[:,:,None]*np.array([7,5,3])+cloud[:,:,None]*2
   height=fibre*.10+grain*.045+fine*.012;rough=.36+rings*.025+grain*.018;mats[key].update(clearcoat=.18,clearcoatRoughness=.32)
  else:
   mottles=field(rng,14,n)*.55+field(rng,41,n)*.28+field(rng,109,n)*.17;wear=np.clip((field(rng,31,n)-.65)*.47,0,1);pores=np.clip((fine-2.2)*1.4,0,1)
   streak=field(rng,47,n)*.2+np.sin(T*(67*u+.09*field(rng,11,n)))*.13
   colour=np.array([102,72,57])+mottles[:,:,None]*np.array([16,12,9])+wear[:,:,None]*np.array([35,32,26])+streak[:,:,None]*4-pores[:,:,None]*22+fine[:,:,None]*1.5
   height=grain*.30+streak*.25-pores*.65;rough=np.clip(.73+wear*.14+mottles*.055,.58,.94)
  dx=np.gradient(height,axis=1);dy=np.gradient(height,axis=0);nn=np.stack([-dx,-dy,np.ones_like(dx)],axis=2);nn/=np.linalg.norm(nn,axis=2,keepdims=True)
  orm=np.empty((n,n,3),np.uint8);orm[:,:,0]=255;orm[:,:,1]=np.rint(np.clip(rough,.05,.98)*255);orm[:,:,2]=0
  for slot,a in [('albedo',np.clip(np.rint(colour),0,255).astype(np.uint8)),('normal',np.rint((nn+1)*127.5).astype(np.uint8)),('orm',orm)]:Image.fromarray(a,'RGB').save(out/(key+'-'+slot+'-2k.png'),optimize=True)
 data=json.loads((out/'material-validation.json').read_text());data['fidelity_revision']='photo-specific rounded shoulders / continuous wood turning / natural billet grain / irregular ceramic wear'
 for path in out.glob('*2k.png'):
  if path.name in data['maps']:data['maps'][path.name].update(sha256=b.sha(path),bytes=path.stat().st_size)
 b.dump(out/'material-validation.json',data);return mats
b.textures=textures
REVISIONS={'43383047':brown_linen_floor,'42814047':continuous_wood_floor,'42316047':knee_tripod_floor,'46369047':rounded_rustic_ceramic,'42238763':natural_wood_table,'44341047':irregular_flower}
for f,fn in REVISIONS.items():b.CONFIG[f].update(build=fn,output_group='revisions-p2/models',model_revision='lighting-fidelity-p2')
b.CONFIG['43383047']['label']='Kahverengi keten · Mat siyah metal kaide'
b.CONFIG['42814047']['label']='Koyu kahverengi ahşap · Beyaz cam · Pirinç zincir'
b.CONFIG['44341047']['scale_note_append']='Sarkıtın resmî120cm toplam asma yüksekliği ve kablosu dahildir; fotoğraftaki ampul dahil değildir.'
if __name__=='__main__':
 selected=b.sys.argv[1:]or list(REVISIONS);b.sys.argv=['build']+selected;b.main();a=json.loads((b.ROOT/'manifest.json').read_text());b.dump(b.ROOT/'fidelity-p2-manifest.json',[q for q in a if q.get('model_revision')=='lighting-fidelity-p2'])
