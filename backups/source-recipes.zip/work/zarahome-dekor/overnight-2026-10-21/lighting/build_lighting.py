"""Photo-specific lighting meshes, intrinsic 2K PBR, official Turkish outer dimensions.
Original source JPEG files are read-only references and never baked into materials.
"""
from pathlib import Path
import sys,json,math,hashlib,re,importlib.util
import numpy as np
from PIL import Image
ROOT=Path(__file__).resolve().parent;WORK=ROOT.parents[1]
sys.path.insert(0,str(WORK))
from export_catalog import export_assets,read_glb,write_glb
from vase_geometry import _finalize,_signed_volume
spec=importlib.util.spec_from_file_location('basketmesh',WORK/'baskets/round/build_round.py'); bm=importlib.util.module_from_spec(spec);spec.loader.exec_module(bm)
tube=bm.tube
TAU=math.tau

def dump(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def solid(name,mat,v,f,uv=None,flat=False):
 if _signed_volume(v,f)<0:f=[(a,c,b)for a,b,c in f]
 return dict(name=name,material=mat,_vertices=[tuple(q)for q in v],_faces=f,_uvs=uv or[(q[0]*5,q[1]*5)for q in v],_flat_normals=flat)
def lathe(name,mat,profile,n=128,closed=True,offset=(0,0,0),ellipse=1.):
 v=[];uv=[];rings=[];offset=np.array(offset,float)
 for k,(r,y)in enumerate(profile):
  ring=[]
  for j in range(1 if r==0 else n+1):
   a=TAU*(j%n)/n;ring.append(len(v));v.append(tuple(offset+np.array([r*math.cos(a),y,r*ellipse*math.sin(a)])));uv.append((j/n,k/max(1,len(profile)-1)))
  rings.append(ring)
 f=[]
 for k in range(len(rings)if closed else len(rings)-1):
  a=rings[k];b=rings[(k+1)%len(rings)]
  if len(a)==len(b)==1:continue
  for j in range(n):
   if len(a)==1:f.append((a[0],b[j],b[j+1]))
   elif len(b)==1:f.append((a[j],b[0],a[j+1]))
   else:f.extend([(a[j],b[j],a[j+1]),(a[j+1],b[j],b[j+1])])
 return solid(name,mat,v,f,uv)
def cylinder(name,mat,r,y0,y1,offset=(0,0,0),n=96):return lathe(name,mat,[(0,y0),(r*.96,y0),(r,y0+.0006),(r,y1-.0006),(r*.96,y1),(0,y1)],n,False,offset)
def shade(name,mat,r0,r1,y0,y1,th=.0013,n=160):
 return lathe(name,mat,[(r0,y0),(r1,y1),(r1-th,y1),(r0-th,y0)],n)
def box(name,mat,width,height,depth,center=(0,0,0)):
 x,y,z=np.array(center,float);w=width/2;h=height/2;d=depth/2
 v=[(x+sx*w,y+sy*h,z+sz*d)for sx,sy,sz in[(-1,-1,-1),(1,-1,-1),(1,1,-1),(-1,1,-1),(-1,-1,1),(1,-1,1),(1,1,1),(-1,1,1)]]
 f=[(0,2,1),(0,3,2),(4,5,6),(4,6,7),(0,1,5),(0,5,4),(3,7,6),(3,6,2),(0,4,7),(0,7,3),(1,2,6),(1,6,5)]
 return solid(name,mat,v,f,flat=True)
def move(part,x=0,y=0,z=0):
 part['_vertices']=[(a+x,b+y,c+z)for a,b,c in part['_vertices']];return part
def glass_wood():
 p=[]
 # Turned double-disc wood foot, flared stem and stepped opal saucer shade.
 prof=[(0,0),(.047,0),(.052,.002),(.054,.006),(.054,.011),(.052,.015),(.049,.016),(.051,.019),(.051,.021),(.046,.024),(.032,.025),(.020,.029),(.012,.034),(.008,.042),(.007,.105),(.010,.113),(0,.113)]
 p.append(lathe('turned-wood-double-foot-and-tapered-stem','wood',prof,160,False))
 prof=[(.014,.109),(.027,.109),(.033,.112),(.039,.119),(.044,.128),(.055,.131),(.070,.135),(.081,.141),(.085,.147),(.084,.152),(.079,.157),(.069,.161),(.056,.163),(.052,.163),(.052,.173),(.051,.179),(.046,.183),(.033,.187),(.014,.189),(0,.190),(0,.186),(.014,.185),(.032,.183),(.044,.179),(.048,.174),(.048,.159),(.056,.159),(.069,.157),(.078,.152),(.081,.147),(.078,.144),(.069,.140),(.054,.135),(.042,.132),(.036,.122),(.029,.116),(.014,.113)]
 p.append(lathe('stepped-opal-glass-open-shell','opal',prof,192))
 p.append(cylinder('small-brass-finial','brass',.004,.189,.198))
 p.append(lathe('round-touch-switch-cap','brass',[(0,.197),(.0037,.197),(.0042,.199),(.0036,.2025),(0,.2025)],96,False))
 return p,['Turned wood double-disc foot and slender flared stem','Tiered opaque vanilla opal-glass saucer with true shell thickness','Separate small warm brass top button; lamp unlit']
def tripod():
 p=[]
 for k in range(3):
  a=TAU*k/3;pts=[]
  for t in np.linspace(0,1,64):
   r=.086*(1-t)+.010*t;y=.009+.045*math.sin(t*math.pi/2)
   pts.append((r*math.cos(a),y,r*math.sin(a)))
  p.append(tube('curved-three-leg-foot-'+str(k),'black',pts,.0055,.0055,12,False,guide=[0,1,0]))
 p.append(cylinder('slender-black-upright','black',.0068,.043,.438))
 p.append(cylinder('shade-holder-collar','black',.009,.414,.433))
 p.append(shade('cotton-conical-shade','cotton',.200,.067,.426,.640,.0016,192))
 for y,r in[(.426,.200),(.639,.067)]:p.append(tube('bound-cotton-rim-'+str(y),'cotton',bm.circle(r,y,192),.0012,.0012,8,True))
 for a in [0,TAU/3,2*TAU/3]:p.append(tube('internal-shade-spoke-'+str(a),'black',[(.008,.429,0),(.17*math.cos(a),.429,.17*math.sin(a))],.0011,.0011,8,False,guide=[0,1,0]))
 # Cable reaches the foot without distorting official fixture dimensions.
 p.append(tube('lower-real-cable','cable',[(0,.11,-.008),(0,.06,-.010),(.008,.012,-.013),(.040,.005,-.018),(.080,.005,-.035)],.0018,.0018,8,False,guide=[0,1,0]))
 return p,['Three separate bent black-metal legs with connected upright','Physical tapered cotton shade, bound rims and internal three-wire support','Real cable segment; neutral unlit project asset']
def adjustable():
 p=[box('slim-rectangular-metal-foot','black',.29,.009,.18,(0,.0045,0)),cylinder('telescoping-lower-upright','black',.0064,.009,.766,offset=(.104,0,0)),cylinder('telescoping-upper-upright','black',.0046,.748,1.350,offset=(.104,0,0)),cylinder('height-lock-ring','black',.0094,.744,.766,offset=(.104,0,0))]
 pts=[]
 for t in np.linspace(0,math.pi/2,32):pts.append((.104-.023*(1-math.cos(t)),1.350+.023*math.sin(t),0))
 pts +=[(.046,1.373,0),(.021,1.373,0)]
 p.append(tube('bent-neck-top-arm','black',pts,.0045,.0045,12,False,guide=[0,0,1]))
 p +=[box('rectangular-hood-top','black',.205,.006,.081,(-.075,1.397,0)),box('rectangular-hood-front','black',.205,.071,.003,(-.075,1.362,-.039)),box('rectangular-hood-back','black',.205,.071,.003,(-.075,1.362,.039)),box('hood-left-return','black',.003,.071,.081,(-.176,1.362,0)),box('hood-right-return','black',.003,.071,.081,(.026,1.362,0)),box('recessed-downward-diffuser','diffuser',.192,.002,.065,(-.075,1.335,0))]
 p.append(tube('power-cable-down-stem','cable',[(.110,1.3,.005),(.111,.8,.005),(.112,.1,.005),(.115,.012,.018),(.14,.003,.064)],.0019,.0019,8,False,guide=[1,0,0]))
 return p,['Thin rectangular heavy foot and genuine telescoping pair of uprights','Curved top elbow connected to a five-sided downward-open rectangular metal hood','Recessed neutral diffuser; lamp unlit; loose room extension cable excluded from fixture bounds']
def petal_sheet(name,phase=0,top=.145):
 n=256;m=32;v=[];uv=[];rings=[]
 for side in[0,1]:
  for k in range(m+1):
   t=k/m;ring=[]
   for j in range(n+1):
    a=TAU*(j%n)/n;r=.015+(.175-.015)*t
    # Four wide paired lobes, small pleated ribs; these are physical folds.
    edge=1+.055*math.cos(4*a+phase)+.025*math.sin(7*a+phase)
    x=r*math.cos(a)*edge;z=r*.887*math.sin(a)*edge
    y=top-.067*(t**.67)+.007*(t**2)*math.cos(4*a+phase)+.0019*t*math.sin(64*a+phase)
    y-=side*.0012;ring.append(len(v));v.append((x,y,z));uv.append(((x/.35)+.5,(z/.31)+.5))
   rings.append(ring)
 f=[];off=m+1
 for side in[0,1]:
  for k in range(m):
   a=rings[side*off+k];b=rings[side*off+k+1]
   for j in range(n):
    tris=[(a[j],b[j],a[j+1]),(a[j+1],b[j],b[j+1])]
    f.extend(tris if side==0 else[(a,c,b)for a,b,c in tris])
 for k in[0,m]:
  a=rings[k];b=rings[off+k]
  for j in range(n):
   f.extend([(a[j],a[j+1],b[j]),(a[j+1],b[j+1],b[j])]if k==0 else[(a[j],b[j],a[j+1]),(a[j+1],b[j],b[j+1])])
 return solid(name,'paper',v,f,uv)
def flower():
 p=[petal_sheet('upper-pleated-four-lobed-paper',0,.145),petal_sheet('lower-offset-paper-petal',2.6,.141),cylinder('brass-lampholder','brass',.017,.126,.193),cylinder('brass-lampholder-top-neck','brass',.005,.188,.201),cylinder('ivory-suspension-cable','whitecable',.00165,.197,1.185),cylinder('ceiling-metal-canopy','ivory',.028,1.175,1.2)]
 # Small socket recess and cap visible below the open folded shade; bulb not supplied.
 p.append(cylinder('dark-recessed-E27-socket','black',.012,.113,.134))
 return p,['Two offset organic four-lobed paper petals with 64 actual radial pleats','Closed 1.2 mm paper thickness, real central aperture, brass holder and socket','Full suspension cable and ceiling canopy; official overall hanging height120 cm; bulb excluded']

CONFIG={
'42238763':dict(dims=[17,20.25,17],build=glass_wood,label='Ahşap · Vanilya opal cam · Pirinç'),
'41331047':dict(dims=[40,64,40],build=tripod,label='Siyah metal · Pamuklu başlık'),
'46177047':dict(dims=[30,140,18],build=adjustable,label='Siyah metal · Kablo · Opal difüzör'),
'44341047':dict(dims=[35,120,31],build=flower,label='Kâğıt çiçek yaprakları · Pirinç · Demir'),
}

MATERIALS={
'wood':([128,81,42],.38,0,'wood'),'opal':([244,220,153],.19,0,'opal'),'brass':([157,118,56],.27,1,'metal'),
'black':([30,28,25],.39,0,'metal'),'cotton':([220,205,174],.86,0,'fabric'),'cable':([21,20,19],.76,0,'rubber'),
'whitecable':([232,229,216],.78,0,'rubber'),'diffuser':([224,224,210],.64,0,'opal'),'paper':([235,232,220],.84,0,'paper'),'ivory':([233,231,219],.43,0,'metal')}
def textures(out,keys):
 n=2048;u=np.arange(n,dtype=np.float32)[None,:]/n;v=np.arange(n,dtype=np.float32)[:,None]/n
 cloud=(np.sin(TAU*(3*u+2*v)+.7)*.45+np.sin(TAU*(5*u-3*v)+2.1)*.25)
 fine=np.sin(TAU*(311*u+37*v))*np.sin(TAU*(159*u-41*v))*.23; mats={};validation={}
 for key in keys:
  rgb,rough,metal,kind=MATERIALS[key]
  if kind=='wood':
   wav=u+.009*np.sin(TAU*2*v)+.003*np.sin(TAU*(5*v+u));grain=np.sin(TAU*61*wav)*.5+np.sin(TAU*143*wav)*.24+np.sin(TAU*(257*wav+2*v))*.13;colour=np.array(rgb)+grain[:,:,None]*np.array([15,11,6])+cloud[:,:,None]*np.array([7,5,2]);height=grain*.22+fine*.07;rr=rough+grain*.055
  elif kind=='fabric':
   weave=(np.sin(TAU*177*u)*np.sin(TAU*173*v)+.35*np.sin(TAU*354*u)+.35*np.sin(TAU*346*v));colour=np.array(rgb)+weave[:,:,None]*3.3+cloud[:,:,None]*2;height=weave*.44;rr=rough+weave*.025
  elif kind=='paper':
   fibre=np.sin(TAU*(67*u+13*v))*.27+fine;colour=np.array(rgb)+fibre[:,:,None]*1.8+cloud[:,:,None]*1.5;height=fibre*.19;rr=rough+fibre*.027
  else:
   colour=np.array(rgb)+cloud[:,:,None]*(1.1 if kind!='opal'else.6)+fine[:,:,None]*.35;height=fine*(.035 if kind=='metal'else.07);rr=rough+fine*.015
  rr=np.broadcast_to(np.clip(rr,.05,.98),(n,n));dx=np.gradient(height,axis=1);dy=np.gradient(height,axis=0);normal=np.stack([-dx,-dy,np.ones_like(dx)],axis=2);normal/=np.linalg.norm(normal,axis=2,keepdims=True)
  orm=np.empty((n,n,3),np.uint8);orm[:,:,0]=255;orm[:,:,1]=np.rint(rr*255);orm[:,:,2]=round(metal*255)
  arrays={'albedo':np.clip(np.rint(colour),0,255).astype(np.uint8),'normal':np.clip(np.rint((normal+1)*127.5),0,255).astype(np.uint8),'orm':orm}
  for slot,a in arrays.items():
   file=out/(key+'-'+slot+'-2k.png');Image.fromarray(a,'RGB').save(file,optimize=True);validation[file.name]=dict(sha256=sha(file),dimensions=[n,n],mode='RGB',bytes=file.stat().st_size)
  mat=dict(baseColorFactor=[1,1,1,1],baseColorTexture=key+'-albedo-2k.png',normalTexture=key+'-normal-2k.png',metallicRoughnessTexture=key+'-orm-2k.png',normalScale=.35,metallic=1,roughness=1,alphaMode='OPAQUE',doubleSided=False,extras=dict(native_resolution=n,photo_pixels_baked=False,baked_reflections=False,unlit_intrinsic_colour=True))
  if key=='opal':mat.update(transmission=.12,ior=1.5,thickness=.002,attenuationColor=[1,.93,.72],attenuationDistance=.03,clearcoat=.22,clearcoatRoughness=.19)
  if key=='brass':mat.update(clearcoat=.15,clearcoatRoughness=.3)
  mats[key]=mat
 dump(out/'material-validation.json',dict(valid=True,native_resolution=n,photo_pixels_baked=False,baked_reflections=False,maps=validation,source_jpegs_unmodified=True))
 return mats

def main():
 observed=json.loads((ROOT/'products-observed.json').read_text());selected=sys.argv[1:]or list(CONFIG);old=json.loads((ROOT/'manifest.json').read_text())if(ROOT/'manifest.json').exists()else[];byid={q['id']:q for q in old}
 for family in selected:
  cfg=CONFIG[family];p=next(p for p in observed if re.search(r'-l(\d+)',p['url']).group(1)==family);sku=re.search(r'\d{4}/\d{3}/\d{3}',p['text_content']).group();w,h,d=cfg['dims'];id=(sku.replace('/','-')+f'-h{h}-w{w}-d{d}').replace('.','p');out=ROOT/cfg.get('output_group','models')/id;out.mkdir(parents=True,exist_ok=True)
  print('geometry',id,flush=True);parts,features=cfg['build']();verts=np.concatenate([np.array(q['_vertices'])for q in parts]);lo=verts.min(0);hi=verts.max(0);target=np.array([w,h,d])/100;scale=target/(hi-lo);centre=np.array([(lo[0]+hi[0])/2,lo[1],(lo[2]+hi[2])/2]);meshes=[];checks=[]
  for raw in parts:
   raw['_vertices']=[tuple((np.array(v)-centre)*scale)for v in raw['_vertices']];mesh,check=_finalize(raw);meshes.append(mesh);checks.append(check)
  print('textures',id,flush=True);mats=textures(out,sorted({q['material']for q in meshes}));sources=[];seen=set()
  for im in p['images']:
   url=im['url'];base=url.split('?')[0]
   if base not in seen and not re.search('-d\\d',base):sources.append(url);seen.add(base)
  meta=dict(id=id,name=p['title'].replace('I','ı').replace('İ','i').lower().capitalize()+cfg.get('name_suffix',''),sku=sku,url=p['url'],category='Dekoratif aydınlatma',dimensions_cm=[w,h,d],source_dimensions_hwd_cm=[h,w,d],estimated_dimensions=False,size_source_kind='tr_live_product',size_source_urls=[p['url']],source_market='Türkiye',variant_label=cfg.get('variant_label','Tek boy · Işık kapalı'),scale_note='Resmî Türkiye ürün sayfasındaki dış ölçülere göre ölçeklendi. Yerel profil, başlık kalınlığı, bağlantı ve kıvrımlar özgün ürün fotoğraflarından yorumlandı. Işık kapalı; ortam ve fotoğraf yansımaları kaplamaya işlenmedi. '+cfg.get('scale_note_append',''),units='metres',up_axis='Y',origin='bottom bounding-box centre',source_images=sources,photo_pixels_baked=False,baked_reflections=False)
  model=out/'model.json';dump(model,dict(metadata=meta,materials=mats,meshes=meshes));dump(out/'geometry-validation.json',dict(valid=True,features=features,all_members_closed_solids=True,source_local_details_photo_inferred=True,affine_fit_scale=scale.tolist(),dimensions_metres=target.tolist(),mesh_count=len(meshes),triangles=sum(q['triangles']for q in checks),meshes=checks,units='metres',up_axis='Y',origin='bottom bounding-box centre'))
  print('export',id,flush=True);report=export_assets(model,out,id);glb=out/(id+'.glb');doc,binary=read_glb(glb);doc['samplers']=[dict(magFilter=9729,minFilter=9987,wrapS=10497,wrapT=10497)]
  for tex in doc.get('textures',[]):tex['sampler']=0
  write_glb(glb,doc,binary);digest=sha(glb);report['deliverable_sha256']['glb']=digest;report['glb_bytes']=glb.stat().st_size;dump(report['files']['validation'],report)
  entry={k:meta[k]for k in['id','name','sku','url','category','dimensions_cm','source_dimensions_hwd_cm','estimated_dimensions','source_market','size_source_kind','size_source_urls','scale_note']};entry.update(model_path=str(model),asset_dir=str(out),glb_path=str(glb),sha256=digest,bytes=glb.stat().st_size,material_label=cfg['label'],source_images=sources,geometry_validation=str(out/'geometry-validation.json'),material_validation=str(out/'material-validation.json'),model_revision=cfg.get('model_revision','lighting-photo-v1'),source_anomalies=[]);byid[id]=entry;dump(ROOT/'manifest.json',list(byid.values()));print('ready',id,glb.stat().st_size,flush=True)
if __name__=='__main__':main()
