from pathlib import Path
import json,urllib.request,hashlib,re,subprocess
from PIL import Image,ImageOps,ImageDraw
ROOT=Path(__file__).resolve().parent
records=json.loads((ROOT/'products-observed.json').read_text()); index=[]
for p in records:
 fam=re.search(r'-l(\d+)',p['url']).group(1); out=ROOT/'reference-masters'/fam;out.mkdir(parents=True,exist_ok=True)
 seen=set();refs=[]
 for im in p['images']:
  url=im['url'];base=url.split('?')[0]
  if base in seen:continue
  seen.add(base); name=base.split('/')[-1];target=out/name
  try:
   if not target.exists():
    subprocess.run(['curl','-L','--silent','--fail','--max-time','20',url,'-o',str(target)],check=True)
   with Image.open(target)as img: wh=img.size
   refs.append(dict(url=url,path=str(target),sha256=hashlib.sha256(target.read_bytes()).hexdigest(),dimensions=wh))
  except Exception as e:print('failed',fam,name,str(e),flush=True)
 p['reference_masters']=refs;index.append(p)
 print(fam,len(refs),flush=True)
(ROOT/'research-lighting.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n')
# Thumbnail review only; master files remain byte-identical.
sel=[]
for p in index:
 refs=p['reference_masters'];refs=sorted(refs,key=lambda q:('p1'not in q['path'],-q['dimensions'][0]))
 if refs:sel.append((p,refs[0]))
canvas=Image.new('RGB',(500*min(4,len(sel)),620*((len(sel)+3)//4)),(245,245,245));draw=ImageDraw.Draw(canvas)
for i,(p,r)in enumerate(sel):
 with Image.open(r['path'])as im: thumb=ImageOps.contain(im.convert('RGB'),(490,565))
 x=(i%4)*500;y=(i//4)*620;canvas.paste(thumb,(x+(500-thumb.width)//2,y));draw.text((x+8,y+570),re.search(r'-l(\d+)',p['url']).group(1)+' '+p['title'][:33],fill=(0,0,0))
canvas.save(ROOT/'reference-review.png')
