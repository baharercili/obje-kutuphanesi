from pathlib import Path
import json,re,subprocess,concurrent.futures,hashlib
from urllib.parse import urlparse,parse_qs
from PIL import Image,ImageOps,ImageDraw
ROOT=Path(__file__).resolve().parent;products=json.loads((ROOT/'products-observed.json').read_text()); jobs=[]
for p in products:
 family=re.search('-l(\\d+)',p['url']).group(1);best={}
 for im in p['images']:
  url=im['url'];base=url.split('?')[0];w=int(parse_qs(urlparse(url).query).get('w',['0'])[0]);old=best.get(base)
  if w>=768 and(old is None or w>old[0]):best[base]=(w,url,im.get('alt',''))
 images=sorted(best.values(),key=lambda x:('p1'not in x[1],'-a7'not in x[1]))[:2]
 for w,url,alt in images:
  basename=urlparse(url).path.split('/')[-1];path=ROOT/'reference-masters'/family/(Path(basename).stem+f'-source-w{w}'+Path(basename).suffix);path.parent.mkdir(parents=True,exist_ok=True);jobs.append((family,url,alt,path))
def fetch(t):
 family,url,alt,path=t
 try:
  if not path.exists():subprocess.run(['curl','-L','--silent','--fail','--max-time','30',url,'-o',str(path)],check=True)
  with Image.open(path)as im:wh=im.size
  return dict(family_code=family,url=url,alt=alt,path=str(path),sha256=hashlib.sha256(path.read_bytes()).hexdigest(),dimensions=wh,unmodified_source=True)
 except Exception as e:return dict(family_code=family,url=url,error=str(e))
masters=[fetch(job)for job in jobs]
(ROOT/'primary-source-provenance.json').write_text(json.dumps(masters,ensure_ascii=False,indent=2)+'\n');print('Primary source masters',len(masters),'failed',sum('error'in x for x in masters),flush=True)
for group in range((len(products)+11)//12):
 sample=products[group*12:(group+1)*12];canvas=Image.new('RGB',(1600,550*((len(sample)+3)//4)),(245,245,245));draw=ImageDraw.Draw(canvas)
 for i,p in enumerate(sample):
  family=re.search('-l(\\d+)',p['url']).group(1);found=[m for m in masters if m['family_code']==family and'error'not in m];found=sorted(found,key=lambda m:'p1'not in m['url'])
  if found:
   with Image.open(found[0]['path'])as im:thumb=ImageOps.contain(im.convert('RGB'),(395,500))
   x=(i%4)*400;y=(i//4)*550;canvas.paste(thumb,(x+(400-thumb.width)//2,y));draw.text((x+8,y+506),family+' '+p['title'][:26],fill='black')
 canvas.save(ROOT/f'reference-review-group-{group+1}.png')
