"""12 inspected mirror SKUs / 16 official sizes. Source photos remain untouched.

No room, reflected photo or faux reflection is baked into any material. Mirror
panes are actual planar reflective surfaces; wood / tarnish are intrinsic PBR.
"""
from pathlib import Path
import sys,json,math,hashlib,shutil,importlib.util
import numpy as np
from PIL import Image
R=Path(__file__).resolve().parent;WORK=R.parents[1];sys.path.insert(0,str(WORK))
from export_catalog import export_assets,read_glb,write_glb
from vase_geometry import _finalize
spec=importlib.util.spec_from_file_location('base_geometry',R/'base_geometry.py');geo=importlib.util.module_from_spec(spec);spec.loader.exec_module(geo)
ns=importlib.util.spec_from_file_location('native_noise',WORK/'bowls-trays/tray-build/tray_materials.py');noise=importlib.util.module_from_spec(ns);ns.loader.exec_module(noise)
def dump(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def title(s):
 s=s.translate(str.maketrans({'I':'ı','İ':'i'})).lower();return s[0].upper()+s[1:]
def rect(w,h,r=.001,n=320):return geo.rounded(w,h,r,n,cy=h/2)
def offset(p,a):
 t=np.roll(p,-1,axis=0)-np.roll(p,1,axis=0);n=np.c_[t[:,1],-t[:,0]];n/=np.linalg.norm(n,axis=1)[:,None];return p+n*a
def arch(w,h):
 r=w/2;rise=r;rb=.032;out=[]
 out.extend([(x,0)for x in np.linspace(-r+rb,r-rb,80,endpoint=False)])
 out.extend([(r-rb+rb*math.cos(a),rb+rb*math.sin(a))for a in np.linspace(-math.pi/2,0,24,endpoint=False)])
 out.extend([(r,y)for y in np.linspace(rb,h-rise,80,endpoint=False)])
 out.extend([(r*math.cos(a),h-rise+rise*math.sin(a))for a in np.linspace(0,math.pi,96,endpoint=False)])
 out.extend([(-r,y)for y in np.linspace(h-rise,rb,80,endpoint=False)])
 out.extend([(-r+rb+rb*math.cos(a),rb+rb*math.sin(a))for a in np.linspace(math.pi,math.pi*1.5,24,endpoint=False)])
 return np.array(out)
def squircle(w,h,n=384):
 a=np.arange(n)*math.tau/n;power=.47;return np.c_[np.sign(np.cos(a))*np.abs(np.cos(a))**power*w/2,h/2+np.sign(np.sin(a))*np.abs(np.sin(a))**power*h/2]
def chamfer(w,h,c):return np.array([[-w/2+c,0],[w/2-c,0],[w/2,c],[w/2,h-c],[w/2-c,h],[-w/2+c,h],[-w/2,h-c],[-w/2,c]])

class Builder(geo.Builder):
 def finish(self,dims,features):
  w,h,d=dims
  # All maps stay inside one positive atlas so nonperiodic natural grain does
  # not produce a repeat-boundary line through the middle of a plank.
  for (name,mat),g in self.groups.items():
   g['_uvs']=[(.5+x/(w*1.04),.02+y/(h*1.04))for x,y,z in g['_vertices']]
   if 'aged-mirror-tile' in name or 'central-mirror-pane' in name:
    a=np.array(g['_vertices']);lo=a.min(0);hi=a.max(0)
    g['_uvs']=[((x-lo[0])/(hi[0]-lo[0]),(y-lo[1])/(hi[1]-lo[1]))for x,y,z in g['_vertices']]
   if any(k in name for k in ['mirror-pane','mirror-tile','backing','flat','beveled-border']):g['_flat_normals']=True
  return super().finish(dims,features)

def back(b,shape,d):
 b.slab('flat-MDF-rear-backing','back',offset(shape,-.001),-d/2,-d/2+.003,.0003)
 w=np.ptp(shape[:,0]);h=np.ptp(shape[:,1])
 for x in [-w*.22,w*.22]:
  c=geo.circle(.006,48,cy=h*.80)+[x,0];inner=geo.circle(.003,48,cy=h*.80)+[x,0]
  b.ring('rear-recessed-hanging-eyelet','steel',[(c,-d/2+.001),(c,-d/2+.003),(inner,-d/2+.003),(inner,-d/2+.001)])

def standard(b,w,h,d,shape,width,mat,kind):
 inner=offset(shape,-width);mix=lambda t:shape*(1-t)+inner*t
 z=-d/2
 b.ring(kind+'-profiled-surround',mat,[(shape,z),(shape,d*.28),(mix(.12),d*.46),(mix(.34),d/2),(mix(.68),d*.36),(inner,d*.17),(inner,z+.002)])
 b.slab('flat-silvered-mirror-pane','mirror',offset(inner,.0005),-.001,d*.16,.0002)
 back(b,shape,d)
 return b.finish([w,h,d],[kind,'Surround profile, opening width and corner radii reconstructed from inspected original product photos','Flat reflecting pane and closed MDF rear panel; no photographed reflection baked into the model','Recessed rear hanging hardware retained inside official thickness'])

def build(p,v):
 w=v['width']/100;h=v['height']/100;d=v['depth']/100;sku=p['sku'];b=Builder()
 if sku=='43336106581':
  shape=rect(w,h,.0008);inner=offset(shape,-.0023)
  b.ring('fine-2mm-silver-metal-surround','steel',[(shape,-d/2),(shape,d/2),(offset(shape,-.00045),d/2),(inner,d/2-.001),(inner,-d/2+.001)])
  b.slab('flat-silvered-mirror-pane','mirror',offset(inner,.0005),d/2-.003,d/2-.001,.00015);back(b,shape,d)
  return b.finish([w,h,d],['Straight rectangular fine silver metal profile approximately2.3mm wide','Very thin visible perimeter in the original gallery, deeper rear MDF support','Unprinted planar reflective mirror pane with physical polished silver response'])
 if sku=='44318106990':
  width=.065;outer=chamfer(w,h,.055);inner=chamfer(w-2*width,h-2*width,.0005)+[0,width]
  b.ring('eight-mitred-beveled-border-mirror-panels','antique',[(outer,-d*.30),(outer,d*.42),(inner,d*.10),(inner,-d*.30)])
  b.slab('flat-aged-silvered-central-mirror-pane','antique',inner,-.001,d*.095,.0002);back(b,outer,d)
  return b.finish([w,h,d],['Chamfered eight-corner outer silhouette','Approximately6cm beveled mirror border with diagonal corner mitres and recessed central pane','Tarnish is intrinsic silver backing variation; reflected room and styled objects are not baked'])
 if sku=='44329106990':
  outer=rect(w,h,.0003);back(b,outer,d);gap=.0015;cell=w/3
  for row in range(3):
   for col in range(3):
    pts=rect(cell-gap,cell-gap,.0003,96)+[-w/2+(col+.5)*cell,row*cell+gap/2]
    # rect is bottom based; centre each square in its allotted tile row.
    b.slab(f'flat-aged-mirror-tile-{row+1}-{col+1}','antique',pts,-d*.10,d*.42,.0004)
  for x in [-w/6,w/6]:
   for y in [h/3,2*h/3]:
    a=np.arange(96)*math.tau/96;r=.006*(1+.10*np.cos(8*a));p=np.c_[x+r*np.cos(a),y+r*np.sin(a)]
    b.slab('silver-eight-lobed-junction-rosette','steel',p,d*.42,d/2,.0002)
  return b.finish([w,h,d],['Nine individual square antiqued-mirror tiles in a3×3 grid','Four small eight-lobed rosette studs at grid intersections','Narrow dark joints and intrinsic irregular silver patina, with no source-photo reflection'])
 if sku=='46309106250':
  # The product name says rectangular, but the observed front has a beaded
  # double-scalloped solid edge. Its54 bead rhythm must remain real geometry.
  centre=rect(w-.045,h-.045,.006,1008)+[0,.0225];points=[(x,y,.0015)for x,y in centre]
  b.tube('continuous-ivory-beaded-wood-surround','ivory',points,lambda t:.014+.0095*(.5+.5*math.cos(math.tau*54*t)),16,closed=True,flatten=.64)
  # The mirror extends behind every narrow bead neck, so the scalloped inner
  # edge never exposes a black gap between the glass and its surround.
  opening=rect(w-.065,h-.065,.005,320)+[0,.0325]
  b.slab('flat-silvered-mirror-pane','mirror',opening,-.004,.003,.0002);back(b,rect(w-.025,h-.025,.005)+[0,.0125],d)
  return b.finish([w,h,d],['Ivory solid scalloped/beaded wood border matching the observed frontal reference','54 repeating rounded bead swellings are actual geometry, including the inner scalloped silhouette','Rectangular rear MDF support and recessed planar silver mirror'])
 if sku=='43317106825':
  return standard(b,w,h,d,arch(w,h),.045,'ivory','Tall pale wood mirror with full semicircular crown and gently rounded convex profile')
 if sku in ['46167106052','46166106052']:
  return standard(b,w,h,d,rect(w,h,.001),.045,'elm','Straight mitered elm wood frame with broad stepped bevel and recessed mirror')
 if sku in ['43131106052','43130106052','43131106700','43130106700']:
  radius=.075 if w>.8 else .066;mat='pale_oak'if sku.endswith('052')else'brown_oak'
  return standard(b,w,h,d,rect(w,h,radius),.023 if w>.8 else .018,mat,'Slim rounded-corner oak surround with continuous inner return')
 if sku=='47511106303':
  shape=squircle(w,h);inner=offset(shape,-.0009)
  b.ring('fine-brass-squircle-edge','gold',[(shape,-d/2),(shape,d/2),(inner,d/2),(inner,-d/2)])
  b.slab('flat-silvered-mirror-pane','mirror',offset(inner,.0001),-.001,d/2-.00015,.0001);back(b,shape,d)
  return b.finish([w,h,d],['Soft squircle outline with broad flowing corners rather than a capsule','Extremely fine brass perimeter and planar mirror glass','The official depth is only6mm; hardware stays within it'])
 raise ValueError(sku)

def material_bank():
 out=R/'material-bank';out.mkdir(exist_ok=True)
 if (out/'materials.json').exists():return out,json.loads((out/'materials.json').read_text())
 source=R.parent/'mirrors-frames/material-cache';allm=json.loads((source/'materials.json').read_text());mats={}
 for key in ['mirror','gold','steel','back']:
  mats[key]=dict(allm[key])
  for field in ['baseColorTexture','normalTexture','metallicRoughnessTexture']:shutil.copyfile(source/mats[key][field],out/mats[key][field])
 # Palette changes are deterministic intrinsic-map derivations from untouched
 # generated wood masters; no original product pixels are used.
 woodsource=R.parent/'boxes/material-bank';defs={'elm':([146,103,63],'oak_wood'), 'pale_oak':([211,185,144],'light_wood'),'brown_oak':([117,78,42],'oak_wood'),'ivory':([219,210,185],'light_wood')}
 for name,(rgb,base)in defs.items():
  af=woodsource/f'{base}-albedo-2k-v2.png';nf=woodsource/f'{base}-normal-2k-v2.png';of=woodsource/f'{base}-orm-2k-v2.png'
  a=np.array(Image.open(af),dtype=np.float32);delta=a-a.mean((0,1));a=np.clip(np.array(rgb)+delta*(.23 if name=='ivory'else .90),0,255).astype('uint8');Image.fromarray(a,'RGB').save(out/f'{name}-albedo-2k.png',optimize=True);shutil.copyfile(nf,out/f'{name}-normal-2k.png');shutil.copyfile(of,out/f'{name}-orm-2k.png')
  mats[name]=dict(baseColorFactor=[1,1,1,1],metallic=0,roughness=1,baseColorTexture=f'{name}-albedo-2k.png',normalTexture=f'{name}-normal-2k.png',metallicRoughnessTexture=f'{name}-orm-2k.png',normalScale=.16 if name!='ivory'else .035,clearcoat=.12,clearcoatRoughness=.42,alphaMode='OPAQUE',doubleSided=False)
 n=2048;x=np.broadcast_to(np.linspace(0,1,n,dtype=np.float32)[None,:],(n,n));y=np.broadcast_to(np.linspace(0,1,n,dtype=np.float32)[:,None],(n,n));cloud=noise._object_noise(x,y,2419,11.);fine=noise._object_noise(x,y,481,379);edge=np.minimum(np.minimum(x,1-x),np.minimum(y,1-y));patina=np.clip((.028+.016*cloud-edge)/.030,0,1);flecks=np.maximum(0,fine-.78)*.20;wear=np.clip(patina*.58+flecks,0,.70);rgb=np.array([225,231,225])*(1-wear[:,:,None])+np.array([79,65,47])*wear[:,:,None];rgb=np.clip(rgb+cloud[:,:,None]*1.1,0,255).astype('uint8');orm=np.empty((n,n,3),np.uint8);orm[:,:,0]=255;orm[:,:,1]=np.rint((.025+wear*.28)*255);orm[:,:,2]=np.rint((1-wear*.74)*255);normal=np.empty_like(orm);normal[:]=[128,128,255]
 for k,pix in [('albedo',rgb),('orm',orm),('normal',normal)]:Image.fromarray(pix,'RGB').save(out/f'antique-{k}-2k.png',optimize=True)
 mats['antique']=dict(baseColorFactor=[1,1,1,1],metallic=1,roughness=1,baseColorTexture='antique-albedo-2k.png',normalTexture='antique-normal-2k.png',metallicRoughnessTexture='antique-orm-2k.png',normalScale=.01,alphaMode='OPAQUE',doubleSided=False)
 dump(out/'materials.json',mats)
 return out,mats

def main():
 data=json.loads((R/'research.json').read_text());bank,specs=material_bank();selected=set(sys.argv[1:]);manifest=json.loads((R/'manifest.json').read_text())if selected else []
 for p in data:
  if selected and p['sku'] not in selected:continue
  for v in p['variants']:
   sku=p['sku'][1:5]+'/'+p['sku'][5:8]+'/'+p['sku'][8:11];fmt=lambda x:f'{x:g}'.replace('.','p');id=sku.replace('/','-')+'-h'+fmt(v['height'])+'-w'+fmt(v['width'])+'-d'+fmt(v['depth']);out=R/'models'/id;out.mkdir(parents=True,exist_ok=True)
   meshes,gqa=build(p,v);used={m['material']for m in meshes};mats={k:dict(specs[k])for k in specs if k in used};maps=[]
   for mat in mats.values():
    for key in ['baseColorTexture','normalTexture','metallicRoughnessTexture']:
     f=bank/mat[key];dest=out/f.name;shutil.copyfile(f,dest);maps.append(dict(name=f.name,sha256=sha(dest),resolution=[2048,2048]))
   metadata=dict(id=id,name=title(p['title']),sku=sku,url=p['official_url'],category='Aynalar',dimensions_cm=[v['width'],v['height'],v['depth']],source_dimensions_hwd_cm=[v['height'],v['width'],v['depth']],estimated_dimensions=False,source_market='Türkiye',size_source_kind='official_tr',size_source_urls=[p['official_url']],scale_note='Resmi Türkiye ölçüleri kullanılmıştır. Çerçeve profilleri, yerel kalınlıklar ve yüzey patinası incelenen orijinal ürün fotoğraflarından yorumlanmıştır; aynada kaynak fotoğraf yansıması kullanılmaz.',units='metres',up_axis='Y',origin='bottom bounding-box centre',source_images=p['images'],photo_pixels_baked=False,baked_reflections=False)
   model=out/'model.json';dump(model,dict(metadata=metadata,materials=mats,meshes=meshes));dump(out/'geometry-validation.json',gqa);dump(out/'material-validation.json',dict(valid=True,native_resolution=2048,intrinsic_material=True,photo_pixels_baked=False,baked_reflections=False,maps=maps));report=export_assets(model,out,id);glb=out/(id+'.glb');doc,binary=read_glb(glb);doc['samplers']=[dict(magFilter=9729,minFilter=9987,wrapS=10497,wrapT=10497)]
   for tex in doc.get('textures',[]):tex['sampler']=0
   write_glb(glb,doc,binary);report['deliverable_sha256']['glb']=sha(glb);report['glb_bytes']=glb.stat().st_size;dump(report['files']['validation'],report)
   e={k:metadata[k]for k in ['id','name','sku','url','category','dimensions_cm','source_dimensions_hwd_cm','estimated_dimensions','source_market','size_source_kind','size_source_urls','scale_note']};e.update(model_path=str(model),asset_dir=str(out),glb_path=str(glb),sha256=sha(glb),bytes=glb.stat().st_size,material_label=p['material_verbatim'].replace('\n',' · '),source_images=p['images'],geometry_validation=str(out/'geometry-validation.json'),material_validation=str(out/'material-validation.json'),model_revision='mirror-photo-specific-v1',source_anomalies=p.get('source_anomalies',[]))
   positions=[j for j,q in enumerate(manifest)if q['id']==id]
   if positions:manifest[positions[0]]=e
   else:manifest.append(e)
   dump(R/'manifest.json',manifest);print(id,e['bytes'],gqa['triangles'],flush=True)
 print('COMPLETE',len(manifest),'mirrors',sum(x['bytes']for x in manifest),flush=True)
if __name__=='__main__':main()
