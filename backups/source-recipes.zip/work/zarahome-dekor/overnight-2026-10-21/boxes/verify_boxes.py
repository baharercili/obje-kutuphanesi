"""Independent verification of GLB bytes, geometry, UVs and embedded maps."""
from pathlib import Path
import json,struct,hashlib,io
from collections import Counter
import numpy as np
from PIL import Image
R=Path(__file__).resolve().parent
def array(doc,binary,index):
 a=doc['accessors'][index];v=doc['bufferViews'][a['bufferView']];dt={5126:'<f4',5125:'<u4',5123:'<u2',5121:'u1'}[a['componentType']];dim={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}[a['type']]
 return np.frombuffer(binary,dtype=dt,count=a['count']*dim,offset=v.get('byteOffset',0)+a.get('byteOffset',0)).reshape(-1,dim)
def intersections(v,f,x,z):
 t=v[f];a=t[:,0];u=t[:,1]-a;w=t[:,2]-a;det=u[:,0]*w[:,2]-u[:,2]*w[:,0];mask=np.abs(det)>1e-14;a,u,w,det=a[mask],u[mask],w[mask],det[mask]
 b=((x-a[:,0])*w[:,2]-(z-a[:,2])*w[:,0])/det;c=(u[:,0]*(z-a[:,2])-u[:,2]*(x-a[:,0]))/det
 valid=(b>=-1e-8)&(c>=-1e-8)&(b+c<=1+1e-8)
 return sorted((a[:,1]+b*u[:,1]+c*w[:,1])[valid].tolist())
rows=[]
for e in json.loads((R/'manifest.json').read_text()):
 raw=Path(e['glb_path']).read_bytes();assert len(raw)==e['bytes'];assert hashlib.sha256(raw).hexdigest()==e['sha256'];assert struct.unpack_from('<4sII',raw)==(b'glTF',2,len(raw));length=struct.unpack_from('<I',raw,12)[0];doc=json.loads(raw[20:20+length]);binary=raw[28+length:];bounds=[];meshq=[];allgeo=[]
 for m in doc['meshes']:
  for p in m['primitives']:
   v=array(doc,binary,p['attributes']['POSITION']).astype(float);f=array(doc,binary,p['indices']).reshape(-1,3);n=array(doc,binary,p['attributes']['NORMAL']);uv=array(doc,binary,p['attributes']['TEXCOORD_0']);assert np.isfinite(v).all()and np.isfinite(n).all()and np.isfinite(uv).all();assert np.max(np.abs(np.linalg.norm(n,axis=1)-1))<1e-4;assert f.max()<len(v)
   # Float export precision requires a scale-appropriate 0.1 micron weld.
   _,weld=np.unique(np.round(v,7),axis=0,return_inverse=True);edges=Counter();direction=Counter()
   for a,b,c in weld[f]:
    for s,t in [(a,b),(b,c),(c,a)]:key=(min(s,t),max(s,t));edges[key]+=1;direction[key]+=1 if s<t else-1
   assert all(q==2 for q in edges.values()),e['id'];assert all(q==0 for q in direction.values()),e['id'];a=v[f[:,0]];b=v[f[:,1]];c=v[f[:,2]];area=np.linalg.norm(np.cross(b-a,c-a),axis=1)/2;assert area.min()>1e-14;volume=np.sum(a*np.cross(b,c))/6;assert volume>0
   bounds.append([v.min(0),v.max(0)]);meshq.append(dict(name=m.get('name'),vertices=len(v),triangles=len(f),positive_volume_m3=float(volume),min_triangle_area_m2=float(area.min()),closed_after_position_weld=True,consistent_winding=True));allgeo.append((v,f))
 lo=np.min([q[0]for q in bounds],axis=0);hi=np.max([q[1]for q in bounds],axis=0);assert np.allclose((hi-lo)*100,e['dimensions_cm'],atol=5e-6);assert abs(lo[1])<1e-8;assert np.max(np.abs((hi+lo)[[0,2]]))<1e-8
 textures=[]
 for image in doc.get('images',[]):
  assert 'uri'not in image;view=doc['bufferViews'][image['bufferView']];b=binary[view.get('byteOffset',0):view.get('byteOffset',0)+view['byteLength']];im=Image.open(io.BytesIO(b));assert im.mode=='RGB';assert min(im.size)>=2048;textures.append(dict(name=image.get('name'),mode=im.mode,size=im.size,bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
 rows.append(dict(id=e['id'],valid=True,bytes=len(raw),sha256=e['sha256'],actual_dimensions_cm=((hi-lo)*100).tolist(),bottom_y_m=float(lo[1]),origin_bottom_center=True,meshes=meshq,embedded_maps=textures,estimated_dimensions=e['estimated_dimensions'],source_kind=e['size_source_kind']));print(e['id'],'PASS',len(meshq),'meshes',len(textures),'embedded maps',flush=True)
(R/'independent-qa.json').write_text(json.dumps(dict(valid=True,count=len(rows),entries=rows),ensure_ascii=False,indent=2)+'\n')
