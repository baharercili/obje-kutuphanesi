"""Append overnight verified assets while preserving all 175 approved masters."""
from pathlib import Path
from urllib.parse import urlsplit,parse_qs
import argparse,copy,hashlib,importlib.util,json,re,shutil,sys
HERE=Path(__file__).resolve().parent;WORK=HERE.parent;ROOT=WORK.parents[1];SITE=ROOT/'sites/zarahome-vazo-kutuphanesi-final-378'
sys.path.insert(0,str(WORK))
def module(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
append=module('overnight_append',WORK/'objects/site_workflow.py');append.HERE=HERE
validate=module('overnight_validate',WORK/'candles/site_workflow.py').validate
audit=module('overnight_topology',WORK/'objects/audit_geometry.py').check
def read(p):return json.loads(Path(p).read_text())
def write(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
CATEGORIES={
 'Dekoratif aynalar':('aynalar','https://www.zarahome.com/tr/dekorasyon-ayna-oturma-odasi-n993'),
 'Fotoğraf çerçeveleri':('cerceveler','https://www.zarahome.com/tr/dekorasyon-cerceve-n1000'),
 'Dekoratif saksılar':('saksilar','https://www.zarahome.com/tr/dekorasyon-saksi-n1402'),
 'Dekoratif kutular':('kutular','https://www.zarahome.com/tr/yatak-odasi-taki-kutusu-n971'),
 'Dekoratif aydınlatma':('aydinlatma','https://www.zarahome.com/tr/aydinlatma-lamba-n4847')}
def photos(e):
 unique={}
 for raw in e['source_images']:
  i=dict(url=raw,alt=e['name'])if isinstance(raw,str)else raw
  u=urlsplit(i['url']);assert u.scheme=='https'and u.netloc=='static.zarahome.net'and u.path.endswith('.jpg')
  width=max([int(v)for v in parse_qs(u.query).get('w',['0'])]);
  if width and width<768:continue
  if u.path not in unique or width>unique[u.path][0]:unique[u.path]=(width,i)
 assert unique,('No observed large photo',e['id'])
 images=sorted([i for _,i in unique.values()],key=lambda i:(0 if '-p1/'in i['url']else 1 if '-a7/'in i['url']else 2,i['url']))
 return [dict(url=i['url'],thumbnail_url=i['url'],source_url=i.get('source_url',i['url']),alt=(i.get('alt')if i.get('alt')and not re.search(r'üzgünüm|yardımcı olamam',i['alt'],re.I)else e['name']+' · Resmî ürün fotoğrafı'),photo_type='official_product_gallery')for i in images]
def catalog_record(e):
 fields=('id','name','sku','url','category','dimensions_cm','source_dimensions_hwd_cm','material_label','estimated_dimensions','size_source_kind','size_source_urls','source_market','scale_note')
 result={k:e[k]for k in fields if k in e};result.update(glb_url='/models/'+e['id']+'.glb?v='+e['sha256'],reference_images=photos(e),reference_photo_scope='product_family',reference_source_url=e['url'],reference_observed_date='2026-10-21')
 for k in ('source_anomalies','availability'):
  if k in e:result[k]=e[k]
 return result
def ref_record(e):
 slug,category_url=CATEGORIES[e['category']];w,h,d=e['dimensions_cm']
 return dict(id='zarahome-'+e['id'],title=e['name'],brand='Zara Home',source_id=slug,source_label=e['category'],source_url=category_url,url=e['url'],product_code=e['sku'],category=e['category'],material_label=e['material_label'],dimensions_display=f'{h:g} × {w:g} × {d:g} cm (Y × G × D)',dimension_note='Model seçilen resmî boydadır. Fotoğraflardaki diğer boylar ve sunum aksesuarları modele dahil değildir.',images=photos(e),model_id=e['id'],model_sha256=e['sha256'],model_status='ready',status='model_ready',original_source_images_preserved=True)
def main():
 p=argparse.ArgumentParser();p.add_argument('manifests',nargs='+',type=Path);a=p.parse_args();baseline=read(HERE/'baseline-175.json');old=baseline['manifest']['models'];old_ids={e['id']for e in old};assert len(old_ids)==175
 entries=[];names=read(HERE/'names-corrections.json')if(HERE/'names-corrections.json').exists()else{}
 for path in a.manifests:
  value=read(path);entries+=value if isinstance(value,list)else value['models']
 assert len(entries)==len({e['id']for e in entries})and not old_ids&{e['id']for e in entries}
 validations=[];topology=[]
 cached_checks={(e['id'],e['sha256']):e for e in read(HERE/'root-master-validation.json')}if(HERE/'root-master-validation.json').exists()else{}
 cached_topology={(e['id'],e['sha256']):e for e in read(HERE/'root-independent-qa.json')['checks']}if(HERE/'root-independent-qa.json').exists()else{}
 for e in entries:
  e['category']={'Aynalar':'Dekoratif aynalar','Çerçeveler':'Fotoğraf çerçeveleri'}.get(e['category'],e['category'])
  e['name']=names.get(e['sku'],e['name']).replace('i\u0307','i')
  e['material_label']=re.sub(r'^DIŞ\s*·\s*·?\s*','',e['material_label']).replace('MDF levha ve kalınlığı','MDF').replace('MEŞE AĞACI','Meşe ağacı')
  assert e['category']in CATEGORIES,e['category'];assert re.fullmatch('[a-zA-Z0-9-]+',e['id']),e['id'];assert e['bytes']<40*1024*1024,e['id']
  assert not e['estimated_dimensions']and e['source_market']=='Türkiye';assert e['url'].startswith('https://www.zarahome.com/tr/')
  e['dimensions_cm']=[round(float(x),6)for x in e['dimensions_cm']];e['source_dimensions_hwd_cm']=[round(float(x),6)for x in e['source_dimensions_hwd_cm']]
  assert Path(e['glb_path']).stat().st_size==e['bytes']and sha(e['glb_path'])==e['sha256'],e['id']
  checked=cached_checks.get((e['id'],e['sha256']))
  if checked is None or checked['dimensions_cm']!=e['dimensions_cm']:checked=validate(e)
  assert all(size==[2048,2048]for size in checked['embedded_image_sizes']),e['id'];validations.append(checked);topology.append(cached_topology.get((e['id'],e['sha256']))or audit(e));model=read(e['model_path']);e.update(preview_geometry_quality=0,preview_color_size=256,preview_preserve_meshes=[m['name']for m in model['meshes']]);photos(e)
 for e in old:assert sha(SITE/'model-source'/e['filename'])==e['sha256']
 write(HERE/'root-master-validation.json',validations);write(HERE/'root-independent-qa.json',dict(valid=True,models=len(entries),checks=topology))
 preview=append.append_preview(baseline['preview'],entries);catalog=copy.deepcopy(baseline['catalog'])+[catalog_record(e)for e in entries];manifest=copy.deepcopy(baseline['manifest'])
 for product in catalog:
  if product['sku']=='1300/748/500':product['additional_categories']=['Dekoratif saksılar']
 for e in entries:
  shutil.copy2(e['glb_path'],SITE/'model-source'/(e['id']+'.glb'));manifest['models'].append(dict(id=e['id'],name=e['name'],filename=e['id']+'.glb',accepted_filenames=[e['id']+'.glb'],bytes=e['bytes'],sha256=e['sha256'],key='models/'+e['sha256']+'.glb'))
 count=len(catalog);categories=len({e['category']for e in catalog});manifest.update(model_count=count,total_bytes=sum(e['bytes']for e in manifest['models']))
 write(SITE/'model-manifest.json',manifest);write(SITE/'ui/catalog.json',catalog);(SITE/'ui/preview.json').write_text(preview)
 refs=copy.deepcopy(baseline['reference_catalog']);refs['products']+=[ref_record(e)for e in entries];refs.update(updated_date='2026-10-21')
 for e in read(WORK/'library-manifest.json'):
  if e['id']in old_ids and e['sku']=='1300/748/500':
   planter=copy.deepcopy(e);planter['category']='Dekoratif saksılar';planter['sha256']=next(p['sha256']for p in old if p['id']==e['id']);planter['source_images']=next(p['images']for p in read(HERE/'inventory/planters-products.json')if p['sku']=='41300748500');refs['products'].append(ref_record(planter))
 lighting_research=read(HERE/'lighting/research-lighting-normalized.json')if(HERE/'lighting/research-lighting-normalized.json').exists()else{}
 for p in lighting_research.get('products',[]):
  if p.get('model_status')!='research_only_measurement_conflict':continue
  code=p['sku'];dimensions={'1323/047/581':'159,6 × 20 × 159,6 cm · Derinlik bilgisi çelişkili','2241/047/727':'20 × 20 × 10 cm · Eksenler kontrol edilecek','0270/047/727':'36 × 29 × 17 cm · Eksenler belirtilmemiş'}.get(code)
  if not dimensions:
   size=next(iter(p.get('sizes',[])),{});dimensions=(' × '.join(f'{size[k]:g}'for k in ('height_cm','width_cm','depth_cm'))+' cm · Ölçüler kontrol edilecek')if all(k in size for k in ('height_cm','width_cm','depth_cm'))else'Ölçüler kontrol edilecek'
  label='Metal · Gümüş rengi'if code.startswith('1323/')else'Opal cam · Tekstil kaplı kablo'if 'cam'in p['title'].lower()else'Seramik'if'seramik'in p['title'].lower()else'Ürün açıklamasındaki malzeme'
  source=dict(name=p['title'],source_images=p['images']);refs['products'].append(dict(id='zarahome-reference-'+code.replace('/','-'),title=p['title'],brand='Zara Home',source_id='aydinlatma',source_label='Dekoratif aydınlatma',source_url=CATEGORIES['Dekoratif aydınlatma'][1],url=p['url'],product_code=code,category='Dekoratif aydınlatma',material_label=label,dimensions_display=dimensions,dimension_note=' '.join(p['source_anomalies']),modeling_note='Resmî ölçü bilgisi netleşene kadar görsel referans olarak saklanıyor.',images=photos(source),status='measurement_review',model_status='measurement_review',original_source_images_preserved=True))
 existing={s['id']for s in refs['sources']}
 for category,(slug,url)in CATEGORIES.items():
  if any(e['category']==category for e in entries)and slug not in existing:refs['sources'].append(dict(id=slug,label=category,url=url));refs['original_links'].append(dict(label=category,url=url));existing.add(slug)
 urls={s['url']for s in refs['original_links']}
 for e in entries:
  if e['url']not in urls:refs['original_links'].append(dict(label=e['name'],url=e['url']));urls.add(e['url'])
 for source in lighting_research.get('source_links',[]):
  url=source.get('url')if isinstance(source,dict)else source
  if url and url not in urls:refs['original_links'].append(dict(label=source.get('label','Aydınlatma kaynağı')if isinstance(source,dict)else'Aydınlatma kaynağı',url=url));urls.add(url)
 for p in refs['products']:
  if p['url']not in urls:refs['original_links'].append(dict(label=p['title'],url=p['url']));urls.add(p['url'])
 assert refs['products'][:len(baseline['reference_catalog']['products'])]==baseline['reference_catalog']['products']
 write(SITE/'ui/zarahome-reference-catalog.json',refs);write(HERE/'zarahome-reference-catalog.json',refs)
 p=SITE/'ui/index.html';s=p.read_text();s=re.sub(r'(yeniden modellenmiş )\d+( materyalli)',lambda m:m[1]+str(count)+m[2],s);s=re.sub(r'<strong>\d+</strong><span>boy ve renk varyantı<br>\d+ kategori',f'<strong>{count}</strong><span>boy ve renk varyantı<br>{categories} kategori',s);s=re.sub(r'\d+ model</span>',f'{count} model</span>',s);s=re.sub(r'<p class="sidebar-footnote">.*?</p>','<p class="sidebar-footnote">Vazolar, kaseler, tepsiler, mumluklar, fenerler, objeler, sepetler, aynalar, çerçeveler, saksılar, kutular ve aydınlatma</p>',s);p.write_text(s)
 write(HERE/'new-models.json',entries);library=[e for e in read(WORK/'library-manifest.json')if e['id']in old_ids];assert len(library)==175;write(WORK/'library-manifest.json',library+entries);write(HERE/f'library-manifest-{count}.json',library+entries)
 recipes=SITE/'asset-recipes/overnight-2026-10-21';recipes.mkdir(exist_ok=True)
 for name in ('integrate.py','root-master-validation.json','root-independent-qa.json','preview-append-validation.json','zarahome-reference-catalog.json'):
  shutil.copy2(HERE/name,recipes/name)
 for path in a.manifests:
  dest=recipes/path.parent.name;dest.mkdir(exist_ok=True)
  for source in [path,*path.parent.glob('*.py'),*path.parent.glob('*products.json'),*path.parent.glob('*qa*.json'),*path.parent.glob('*research*.json')]:shutil.copy2(source,dest/source.name)
 for directory in {Path(e['asset_dir']).parent.parent for e in entries}:
  dest=recipes/directory.name;dest.mkdir(exist_ok=True)
  for pattern in ('*.py','*frozen*.json','*products*.json','*qa*.json','*research*.json','*proof*.json'):
   for source in directory.glob(pattern):shutil.copy2(source,dest/source.name)
 result=dict(models=count,new_models=len(entries),preserved_models=175,categories=categories,new_category_counts={c:sum(e['category']==c for e in entries)for c in CATEGORIES},old_masters_unchanged=True,old_preview_unchanged=True,photo_references=len(refs['products']),original_photo_count=sum(len(e['images'])for e in refs['products']))
 write(HERE/'site-integration-report.json',result);print(json.dumps(result))
if __name__=='__main__':main()
