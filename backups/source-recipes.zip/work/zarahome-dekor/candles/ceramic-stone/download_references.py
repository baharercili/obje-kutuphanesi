import concurrent.futures, hashlib, json, re, urllib.request
from pathlib import Path
ROOT=Path(__file__).resolve().parent
urls=json.loads((ROOT/'image-urls.json').read_text())
out=ROOT/'references';out.mkdir(exist_ok=True)
def get(url):
 url=re.sub(r'w=\d+','w=1440',url)
 name=re.search(r'/([^/]+\.jpg)',url).group(1)
 path=out/name
 if not path.exists():
  req=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0'})
  with urllib.request.urlopen(req,timeout=45) as r: path.write_bytes(r.read())
 data=path.read_bytes()
 return {'url':url,'path':str(path),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool: results=list(pool.map(get,urls))
(ROOT/'reference-manifest.json').write_text(json.dumps(results,indent=2))
print(json.dumps({'images':len(results),'bytes':sum(x['bytes'] for x in results)}))
