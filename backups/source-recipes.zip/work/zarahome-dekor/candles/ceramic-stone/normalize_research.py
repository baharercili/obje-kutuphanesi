"""Restore the checked final research snapshot; requires no network or browser."""
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
data=json.loads((ROOT/'research-final.json').read_text())
assert len(data['products'])==6 and sum(len(p['variants']) for p in data['products'])==10
assert next(p for p in data['products'] if p['sku'].startswith('2460'))['estimated_dimensions']
(ROOT.parent/'research-ceramic-stone.json').write_text(json.dumps(data,ensure_ascii=False,indent=2))
print('6 families, 10 variants; checked final snapshot restored.')
