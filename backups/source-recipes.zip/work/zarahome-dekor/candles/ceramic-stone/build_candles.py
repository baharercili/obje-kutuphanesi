import argparse,hashlib,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent;CATALOG=ROOT.parents[1];sys.path.insert(0,str(CATALOG))
from export_catalog import export_assets,read_glb,write_glb
from candle_geometry import build
from candle_materials import build_materials
parser=argparse.ArgumentParser();parser.add_argument('--families',nargs='*');args=parser.parse_args()
research=json.loads((ROOT.parent/'research-ceramic-stone.json').read_text());entries=[]
for p in research['products']:
 family=p['sku'][:4]
 if args.families and family not in args.families:continue
 for v in p['variants']:
  if v.get('height_cm') is None:continue
  estimated=bool(v.get('height_estimated',False));source_hwd=[None if estimated else v['height_cm'],v['width_cm'],v['depth_cm']]
  spec={'id':v['id'],'family':family,'name':p['name'],'sku':p['sku'],'url':p['official_url'],'width':v['width_cm']/100,'height':v['height_cm']/100,'depth':v['depth_cm']/100,'colour':p['colour'],'source_dimensions_hwd_cm':source_hwd,'official_exterior_dimensions':not estimated,'estimated_height_cm':v['height_cm'] if estimated else None,'local_dimensions_inferred_from_photographs':True}
  out=ROOT/'models'/spec['id'];out.mkdir(parents=True,exist_ok=True)
  meshes,geometry,atlas=build(spec);materials=build_materials(spec,out,atlas)
  model={'metadata':{**spec,'category':'Mumluk ve şamdanlar','units':'metres','up_axis':'Y','origin':'bottom bounding-box centre','geometry_only_qa':False,'source_type':'official photograph reconstruction','photo_pixels_baked':False},'materials':materials,'meshes':meshes}
  model_path=out/'model.json';model_path.write_text(json.dumps(model,separators=(',',':'),ensure_ascii=False));(out/'geometry-validation.json').write_text(json.dumps(geometry,indent=2));(out/'atlas.json').write_text(json.dumps(atlas,indent=2))
  exported=export_assets(model_path,out,spec['id']);glb=out/(spec['id']+'.glb');doc,binary=read_glb(glb)
  # Cylindrical atlas repeats horizontally, clamps at true closed meridian ends.
  doc['samplers']=[{'magFilter':9729,'minFilter':9987,'wrapS':10497,'wrapT':33071}]
  write_glb(glb,doc,binary);digest=hashlib.sha256(glb.read_bytes()).hexdigest()
  assert glb.stat().st_size<16*1024*1024,(spec['id'],glb.stat().st_size)
  entry={'id':spec['id'],'name':p['name'],'sku':p['sku'],'url':p['official_url'],'dimensions_cm':[v['width_cm'],v['height_cm'],v['depth_cm']],'source_dimensions_hwd_cm':source_hwd,'estimated_height_cm':v['height_cm'] if estimated else None,'model_path':str(model_path),'asset_dir':str(out),'material_label':' · '.join(x['official_name'] for x in p['materials'])+' · '+str(p['colour']),'category':'Mumluk ve şamdanlar','estimated_dimensions':estimated,'size_source_kind':'official_tr_with_photo_estimated_height' if estimated else 'official_tr' if 'official_tr' in v.get('dimensions_source','') else 'official_other_markets','size_source_urls':p['size_source_urls'],'source_market':'Türkiye' if 'official_tr' in v.get('dimensions_source','') else 'Official same SKU, international','scale_note':'Genişlik ve derinlik16cm resmi; yükseklik4,5cm fotoğraftaki oranlardan yaklaşık. İç profil ve desenler görsel yorumdur.' if estimated else 'Resmi dış ölçüler; iç profil, et kalınlığı ve yüzey desenleri fotoğraflardan yorumlanmıştır.','model_revision':'candles-photo-v1','glb_path':str(glb),'bytes':glb.stat().st_size,'sha256':digest,'reference_images':p['images']}
  exported['deliverable_sha256']['glb']=digest;Path(exported['files']['validation']).write_text(json.dumps(exported,indent=2));entries.append(entry)
  print(spec['id'],geometry['triangles'],glb.stat().st_size,flush=True)
target=ROOT/('manifest-'+ '-'.join(args.families)+'.json' if args.families else 'manifest.json');target.write_text(json.dumps(entries,ensure_ascii=False,indent=2));print('complete',len(entries),target,flush=True)
