import json, re
from pathlib import Path
ROOT=Path(__file__).resolve().parent
groups=json.loads((ROOT/'latest-gallery-urls.json').read_text())
extra={
'44322468800':[
'https://static.zarahome.net//assets/public/c69a/234b/7d794289abf1/517134952520/44322468800-a7/44322468800-a7.jpg',
'https://static.zarahome.net//assets/public/d01f/ba21/16d94e5c825d/73414b68bda0/44322468800-p1/44322468800-p1.jpg',
'https://static.zarahome.net//assets/public/d037/5139/f1bc4ae390b8/d1cf195e3102/44322468800-a1/44322468800-a1.jpg',
'https://static.zarahome.net//assets/public/aebb/8552/d3f54392ba9b/1015801412a4/44322468800-a2/44322468800-a2.jpg',
'https://static.zarahome.net//assets/public/771c/418f/d4d24f9f99d1/4dfc213a0d88/44322468800-a3/44322468800-a3.jpg',
'https://static.zarahome.net//assets/public/8019/a949/068c4fc085d5/1952e8b1bdbb/44322468800-a4/44322468800-a4.jpg'],
'46388048808':[
'https://static.zarahome.net//assets/public/aa41/7867/3d8148858ec1/0c473ae28e89/46388048808-a7/46388048808-a7.jpg',
'https://static.zarahome.net//assets/public/5a61/f4a1/20cf4128be5b/ebe8401f65b7/46388048808-p1/46388048808-p1.jpg',
'https://static.zarahome.net//assets/public/1353/7c73/d750462888c0/487156744738/46388048808-a1/46388048808-a1.jpg',
'https://static.zarahome.net//assets/public/5b9c/1500/e8204094abf2/0e0fca1297c7/46388048808-a2/46388048808-a2.jpg']}
groups.update(extra)
rows=[
('3325/048/800','PİRİNÇ ŞAMDAN','Siyah','pirinc-samdan-l43325048',[], 'Uzun geometrik pirinç gövde ve mum için iç destek.'),
('4322/468/800','DEMİR ŞAMDAN','Siyah','demir-samdan-l44322468',[[7.5,20,7.5],[7.5,24,7.5]], 'Dengeli taban; dikey ince demir silüet. Ürün beden metni H×W×D.'),
('6388/048/808','PARLAK ÇELİK MUMLUK','Gümüş','parlak-celik-mumluk-l46388048?pelement=507793266',[[4,7,4]], 'Kadeh biçimi, 2,2 cm mum yuvası, parlak çelik.'),
('4321/468/251','ALÜMİNYUM ŞAMDAN','Kırık beyaz','aluminyum-samdan-l44321468',[], 'Üst üste binen dairesel formlar; emaye döküm alüminyum. Renk etiketi kırık beyaz, açıklamadaki koyu sözü çelişkili; fotoğraf esas alınacak.'),
('9398/468/303','ALTIN RENGİ ŞAMDAN','Altın','altin-rengi-samdan-l49398468',[[13.5,6.5,11]], 'Yuvarlak tabanlı dore alüminyum şamdan.'),
('1327/468/800','UZUN DEMİR MUMLUK','Siyah','uzun-demir-mumluk-l41327468',[[6,7,6]], '2,2 cm mum için demir yuva.'),
('1325/468/800','KÜÇÜK DEMİR MUMLUK','Siyah','kucuk-demir-mumluk-l41325468',[[5.5,4.5,5.5]], '2,2 cm mum için kısa demir yuva.'),
('4368/468/800','DEMİR ŞAMDAN YAN SAPI','Siyah','demir-samdan-yan-sapi-l44368468?pelement=507793077',[[9.5,6.5,10]], 'Tek renkli demir şamdan; gerçek yan sap açıklığı.'),
('1222/468/250','DALGALI DEMİR ŞAMDAN','Beyaz','dalgali-demir-samdan-l41222468?pelement=507772379',[[12,4.5,13]], 'Dalgalı yuvarlak taban ve yan sap.'),
('6471/048/823','DİKDÖRTGEN METAL MUMLUK','Eskitilmiş metal','dikdortgen-metal-mumluk-l46471048?pelement=513184749',[], 'Canlı kategori SKU ve JPEG teyitli, boy paneli bekleniyor.'),
('4323/468/312','DALGALI DEMİR ŞAMDAN','Altın','dalgali-demir-samdan-l44323468?pelement=508353211',[], 'Dalgalı çizgi tasarımı; beden paneli ve yakın fotoğraflar bekleniyor.')]
live=json.loads((ROOT.parent/'live-category-dom.json').read_text())
for p in live['images']:
 if not p.get('src','').split('?')[0].endswith('.jpg'):continue
 m=re.search(r'/(4\d{10})-[ap]\d/',p['src'])
 if m:groups.setdefault(m.group(1),[]).append(p['src'])
products=[]
for sku,title,color,slug,sizes,notes in rows:
 code='4'+sku.replace('/',''); urls=[]; seen=set()
 for raw in groups.get(code,[]):
  raw=raw.split('?')[0].replace('net//','net/')
  if raw in seen: continue
  seen.add(raw); urls.append({'url':raw+'?w=1440','thumbnail_url':raw+'?w=160','view':re.search(r'-([ap]\d)\.jpg',raw).group(1),'source_url':raw})
 urls.sort(key=lambda x:(0 if x['view']=='p1' else 1 if x['view']=='a7' else 2,x['view']))
 products.append({'sku':sku,'name':title,'color':color,'source_url':'https://www.zarahome.com/tr/'+slug,'source_category_url':'https://www.zarahome.com/tr/oturma-odasi-samdan-n1003','dimensions_order':'width_height_depth_cm','variants':[{'dimensions_cm':x,'dimensions_source':'official_product_page_visible_size_text'} for x in sizes], 'reference_images':urls,'shape_notes':notes,'research_status':'dimensions_verified' if sizes else 'size_panel_pending'})
out={'retrieved_at':'2026-10-21','category':'Şamdan ve mumluklar','scope':'metal candlesticks; original official photo gallery; W/H/D cm','status':'partial_research_awaiting_live_size_panels_and_missing_families','products':products,'pending_families':['DALGALI DEMİR ŞAMDAN 4323/468 (renk ve boy canlı panel teyidi)','DALGALI DEMİR ŞAMDAN ikinci aile','DİKDÖRTGEN METAL MUMLUK']}
(ROOT.parent/'research-metal.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
print(len(products),'families;',sum(len(x['variants']) for x in products),'verified sizes')
