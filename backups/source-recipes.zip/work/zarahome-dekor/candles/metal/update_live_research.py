import json,re
from pathlib import Path
from prepare_research import ROOT
p=ROOT.parent/'research-metal.json';d=json.loads(p.read_text());live=json.loads((ROOT.parent/'live-product-dom.json').read_text())
sizes={'3325':[[6.5,23,6.5],[6.5,33,6.5]],'4321':[[7.2,17.2,7.5],[7.3,23.4,7.4]],'4323':[[6.5,17,6.5],[6.5,25,6.5]],'6471':[[9.8,.5,9.8]]}
for product in d['products']:
 f=product['sku'].split('/')[0]
 key=next((k for k,v in live.items() if '-l4'+f in v['url']),None)
 if key:
  l=live[key];product['source_url']=l['url'];product['live_main_text']=l['main_text']
  urls={}
  for img in l['images']:
   u=img['url'].split('?')[0].replace('net//','net/');m=re.search(r'-([ap]\d)\.jpg',u)
   if not m:continue
   urls[u]={'url':u+'?w=1440','thumbnail_url':u+'?w=160','view':m.group(1),'source_url':u,'alt':img.get('alt','')}
  product['reference_images']=sorted(urls.values(),key=lambda i:(0 if i['view']=='p1' else 1 if i['view']=='a7' else 2,i['view']))
 if f in sizes:
  product['variants']=[{'dimensions_cm':dim,'dimensions_source':'official_live_TR_product_panel' if f!='3325' else 'official_height_and_photo_proportioned_base','estimated_dimensions':f=='3325'} for dim in sizes[f]]
  product['research_status']='dimensions_verified' if f!='3325' else 'official_width_anomaly_photo_proportioned'
  if f=='4323':
   product['source_anomalies']=['Color code312 and official label Altın conflict with current product photos/description showing black finish; material follows the photographed black finish with subtle warm wear.']
  if f=='3325':
   product['source_anomalies']=['Official W/D2.75 cm conflicts with photographed broad base (approx6.5 cm at official23/33 cm height); overall model W/D inferred from photos, official source kept.']
   for v,h in zip(product['variants'],[23,33]):v['source_dimensions_hwd_cm']=[h,2.75,2.75]
d['status']='production_authorized_remaining_live_galleries_pending';d['verified_variant_count']=sum(len(p['variants']) for p in d['products']);p.write_text(json.dumps(d,ensure_ascii=False,indent=2))
print(len(d['products']),d['verified_variant_count'])
