"""Independent final GLB/image/geometry read-back; does not mutate masters."""
from pathlib import Path
import json,struct,hashlib,io
import numpy as np
from PIL import Image
ROOT=Path(__file__).resolve().parent
manifest=json.loads((ROOT/'manifest.json').read_text());reports=[]
for e in manifest:
 p=Path(e['glb_path']);raw=p.read_bytes();assert len(raw)==e['bytes'];assert hashlib.sha256(raw).hexdigest()==e['sha256'];assert raw[:4]==b'glTF';assert struct.unpack_from('<I',raw,8)[0]==len(raw)
 size,kind=struct.unpack_from('<I4s',raw,12);assert kind==b'JSON';doc=json.loads(raw[20:20+size]);bsize,bkind=struct.unpack_from('<I4s',raw,20+size);assert bkind==b'BIN\0';binary=raw[28+size:28+size+bsize]
 assert all('uri' not in im for im in doc['images'])
 imgs=[]
 for im in doc['images']:
  v=doc['bufferViews'][im['bufferView']];b=binary[v.get('byteOffset',0):v.get('byteOffset',0)+v['byteLength']]
  with Image.open(io.BytesIO(b)) as img:assert img.size==(2048,2048);imgs.append({'dimensions':list(img.size),'format':img.format})
 model=json.loads(Path(e['model_path']).read_text());lo=np.full(3,np.inf);hi=-lo;triangles=0;parts=[]
 for mesh in model['meshes']:
  v=np.asarray(mesh['positions']).reshape(-1,3);f=np.asarray(mesh['indices']).reshape(-1,3);n=np.asarray(mesh['normals']).reshape(-1,3);uv=np.asarray(mesh['uvs']).reshape(-1,2)
  assert np.isfinite(v).all() and np.isfinite(n).all() and np.isfinite(uv).all();assert np.max(abs(np.linalg.norm(n,axis=1)-1))<1e-5
  assert f.min()>=0 and f.max()<len(v);q=v[f];cross=np.cross(q[:,1]-q[:,0],q[:,2]-q[:,0]);assert np.linalg.norm(cross,axis=1).min()>1e-14
  _,weld=np.unique(np.round(v,8),axis=0,return_inverse=True);wf=weld[f];edges=np.concatenate([wf[:,[0,1]],wf[:,[1,2]],wf[:,[2,0]]]);sort=np.sort(edges,axis=1);_,counts=np.unique(sort,axis=0,return_counts=True);assert (counts==2).all(),(e['id'],mesh['name'],'unclosed')
  volume=np.einsum('ij,ij->i',q[:,0],np.cross(q[:,1],q[:,2])).sum()/6;assert volume>0
  lo=np.minimum(lo,v.min(axis=0));hi=np.maximum(hi,v.max(axis=0));triangles+=len(f);parts.append({'mesh':mesh['name'],'closed_after_position_weld':True,'positive_volume':True,'triangles':len(f)})
 dims=(hi-lo)*100;assert np.allclose(dims,e['dimensions_cm'],atol=2e-5);assert abs(lo[1])<1e-8
 reports.append({'id':e['id'],'valid':True,'bytes':len(raw),'sha256':e['sha256'],'dimensions_cm':dims.tolist(),'embedded_native_images':imgs,'triangles':triangles,'parts':parts,'estimated_dimensions':e['estimated_dimensions']});print(e['id'],'PASS',flush=True)
(ROOT/'independent-qa.json').write_text(json.dumps({'valid':True,'count':len(reports),'entries':reports},ensure_ascii=False,indent=2));print('ALL PASS',len(reports))
