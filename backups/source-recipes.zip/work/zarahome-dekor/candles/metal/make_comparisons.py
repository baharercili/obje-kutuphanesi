from pathlib import Path
import json,hashlib
from PIL import Image,ImageDraw,ImageFont,ImageOps
ROOT=Path(__file__).resolve().parent;entries=json.loads((ROOT/'manifest.json').read_text());out=ROOT/'qa';out.mkdir(exist_ok=True)
font=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',20);big=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',27)
outputs=[];records=[]
for start in range(0,len(entries),3):
 selected=entries[start:start+3];canvas=Image.new('RGB',(1500,100+len(selected)*500),'#f7f4ee');draw=ImageDraw.Draw(canvas);draw.text((20,17),'Resmi ürün fotoğrafı | Gerçek model ön çapraz | Aynı model üstten',font=big,fill='#2a2926')
 for row,e in enumerate(selected):
  top=83+row*500;draw.text((20,top),e['sku']+'  ·  '+' × '.join('%g'%x for x in e['dimensions_cm'])+' cm',font=font,fill='#2a2926')
  code='4'+e['sku'].replace('/','');ref=ROOT/'references'/(code+'-p1.jpg')
  if not ref.exists():ref=ROOT/'references'/(code+'-a7.jpg')
  sources=[ref,Path(e['asset_dir'])/'on-capraz.png',Path(e['asset_dir'])/'ustten.png']
  for col,p in enumerate(sources):
   before=hashlib.sha256(p.read_bytes()).hexdigest()
   with Image.open(p) as im:
    im=ImageOps.exif_transpose(im).convert('RGBA');im.thumbnail((475,445),Image.Resampling.LANCZOS);x=15+col*500+(475-im.width)//2;y=top+35+(445-im.height)//2;canvas.paste(im,(x,y),im)
   assert hashlib.sha256(p.read_bytes()).hexdigest()==before
   records.append({'path':str(p),'sha256':before})
 path=out/f'comparison-{start//3+1:02d}.png';canvas.save(path,optimize=True);outputs.append(str(path))
(ROOT/'render-qa.json').write_text(json.dumps({'valid':True,'models':len(entries),'original_inputs_unmodified':True,'two_views_per_model':True,'image_render_size':1200,'outputs':outputs,'input_records':records},ensure_ascii=False,indent=2));print('\n'.join(outputs))
