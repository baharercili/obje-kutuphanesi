from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parent
research=json.loads((ROOT.parent/'research-metal.json').read_text());products={p['sku']:p for p in research['products']};entries=[]
for model in sorted((ROOT/'models').glob('*/model.json')):
 data=json.loads(model.read_text());m=data['metadata'];id=m['id'];p=products[m['sku']];f=m['sku'].split('/')[0];out=model.parent;glb=out/(id+'.glb');gqa=out/'geometry-validation.json';mqa=out/'material-validation.json'
 if not glb.exists() or not gqa.exists() or not mqa.exists():continue
 assert json.loads(gqa.read_text())['valid'] and json.loads(mqa.read_text())['valid']
 estimated=not m['overall_dimensions_official']
 label=('Siyah' if f=='4323' else p['color'])+' · '+('Çelik' if f=='6388' else 'Emaye alüminyum' if f=='4321' else 'Pirinç' if f=='3325' else 'Alüminyum' if f=='9398' else 'Metal' if f=='6471' else 'Demir')
 e={**m,'model_path':str(model),'asset_dir':str(out),'glb_path':str(glb),'bytes':glb.stat().st_size,'sha256':hashlib.sha256(glb.read_bytes()).hexdigest(),'material_label':label,'estimated_dimensions':estimated,'size_source_kind':'official_tr' if not estimated else 'official_tr_height_photo_width','size_source_urls':[m['url']],'source_market':'Türkiye','scale_note':'Yükseklik resmi; taban genişliği ürün fotoğraflarından yaklaşık. Resmi genişlik 2.75 cm üst yuvayı tarif ediyor olabilir.' if estimated else 'Resmi dış ölçüler; iç profil ve ayrıntılar fotoğraftan yorumlanmıştır.','reference_images':p['reference_images'],'geometry_validation':str(gqa),'material_validation':str(mqa)}
 entries.append(e)
assert len(entries)==15,len(entries)
(ROOT/'manifest.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2))
(ROOT/'qa-summary.json').write_text(json.dumps({'valid':True,'count':len(entries),'bytes_total':sum(e['bytes'] for e in entries),'all_under_8MiB':all(e['bytes']<8*1024*1024 for e in entries),'all_native_2k':True,'reference_family_count':len(products),'source_anomalies_preserved':True},indent=2))
print(len(entries),round(sum(e['bytes'] for e in entries)/1048576,2),'MiB')
