import json,urllib.request,concurrent.futures
from pathlib import Path
ROOT=Path(__file__).resolve().parent
data=json.loads((ROOT.parent/'research-metal.json').read_text()); out=ROOT/'references';out.mkdir(exist_ok=True)
def one(task):
 sku,img=task; p=out/Path(img['source_url']).name
 if p.exists(): return {'file':str(p),'status':'existing'}
 try:
  req=urllib.request.Request(img['url'],headers={'User-Agent':'Mozilla/5.0'})
  with urllib.request.urlopen(req,timeout=35) as r: raw=r.read(); ct=r.headers.get('Content-Type')
  if not raw.startswith(b'\xff\xd8\xff'): raise ValueError('not JPEG '+str(ct))
  p.write_bytes(raw);return {'file':str(p),'bytes':len(raw),'status':'ok'}
 except Exception as e:return {'file':str(p),'status':'error','error':str(e)}
tasks=[(p['sku'],img) for p in data['products'] for img in p['reference_images']]
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as ex: report=list(ex.map(one,tasks))
(ROOT/'reference-download-validation.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
